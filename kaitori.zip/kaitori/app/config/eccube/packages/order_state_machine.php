<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

use Eccube\Entity\Master\OrderStatus as Status;
use Eccube\Service\OrderStateMachineContext;

$container->loadFromExtension('framework', [
    'workflows' => [
        'order' => [
            'type' => 'state_machine',
            'marking_store' => [
                'type' => 'single_state',
                'arguments' => 'status',
            ],
            'supports' => [
                OrderStateMachineContext::class,
            ],
            'initial_place' => (string) Status::NEW,
            'places' => [
                (string) Status::NEW,
                (string) Status::CANCEL,
                //(string) Status::IN_PROGRESS,
                //(string) Status::DELIVERED,
                (string) Status::PAID,
                (string) Status::PENDING,
                (string) Status::PROCESSING,
                (string) Status::RETURNED,
                (string) Status::WAIT,
            ],
            'transitions' => [
               // 新規受付ー＞顧客確認待ち
               'new_wait' => [
                   'from' => (string) Status::NEW,
                    'to' => (string) Status::WAIT,
                ],
                // 新規受付/顧客確認待ちー＞入荷待ち
               'return' => [
                    'from' => [(string) Status::NEW,(string) Status::WAIT],
                    'to' => (string) Status::RETURNED,
                ],
                // 入荷待ちー＞送金待ち
                'packing' => [
                    'from' => (string) Status::RETURNED,
                    'to' => (string) Status::PENDING,
                ],
                // 入荷待ちー＞/送金済み
                'returned_to_paid' => [
                    'from' => (string) Status::RETURNED,
                    'to' => (string) Status::PAID,
                ],
                // 送金待ちー＞送金済
                'pay' => [
                    'from' => (string) Status::PENDING,
                    'to' => (string) Status::PAID,
                ],
                //'cancel' => [
                //    'from' => (string) Status::NEW,
                //    'to' => (string) Status::CANCEL,
                //],
                //'ship' => [
                //    'from' => [(string) Status::NEW, (string) Status::PAID, (string) Status::IN_PROGRESS],
                //    'to' => [(string) Status::DELIVERED],
                //],
               // 'cancel' => [
               //     'from' => [(string) Status::NEW, (string) Status::IN_PROGRESS, (string) Status::PAID],
               //     'to' => (string) Status::CANCEL,
              //  ],
               // 'back_to_in_progress' => [
               //     'from' => (string) Status::CANCEL,
               //    'to' => (string) Status::IN_PROGRESS,
               // ],
                // 新規受付ちー＞取り消し
               'cancel_new' => [
                    'from' => (string) Status::NEW,
                    'to' => (string) Status::CANCEL,
                ],
                // 顧客確認待ちー＞取り消し
                'cancel_wait' => [
                    'from' => (string) Status::WAIT,
                    'to' => (string) Status::CANCEL,
                ],
                // 入荷待ちー＞取り消し
               'cancel_return' => [
                    'from' => (string) Status::RETURNED,
                    'to' => (string) Status::CANCEL,
                ],
                // 送金待ちー＞入荷待ち
                'cancel_pending' => [
                    'from' => (string) Status::PENDING,
                    'to' => (string) Status::RETURNED,
                ],
                // 送金済みー＞送金待ち
                'cancel_paid' => [
                    'from' => (string) Status::PAID,
                    'to' => (string) Status::PENDING,
                ],
                 // 入荷待ちー＞顧客確認待ち
                'cancel_returned_mail' => [
                    'from' => (string) Status::RETURNED,
                    'to' => [(string) Status::WAIT],
                ],
                // 入荷待ちー＞新規受付
                'cancel_returned_status' => [
                    'from' => (string) Status::RETURNED,
                    'to' => [(string) Status::NEW],
                ],
            ],
        ],
    ],
]);
