
from bottle import route, run, template
from namedivider import NameDivider

name_divider = NameDivider()

@route('/divide/<name>')
def index(name):
    divided_name = name_divider.divide_name(name)
    return template('{{name}}', name=divided_name)

run(host='0.0.0.0', port=9090)
