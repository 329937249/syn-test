<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Entity;

use Doctrine\ORM\Mapping as ORM;

if (!class_exists('\Eccube\Entity\BulkMailHistory')) {
    /**
     * MailHistory
     *
     * @ORM\Table(name="dtb_bulk_mail_history")
     * @ORM\InheritanceType("SINGLE_TABLE")
     * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
     * @ORM\HasLifecycleCallbacks()
     * @ORM\Entity(repositoryClass="Eccube\Repository\BulkMailHistoryRepository")
     */
    class BulkMailHistory extends AbstractEntity
    {
        /**
         * @return string
         */
        public function __toString()
        {
            return (string) $this->getMailSubject();
        }

        /**
         * @var int
         *
         * @ORM\Column(name="id", type="integer", options={"unsigned":true})
         * @ORM\Id
         * @ORM\GeneratedValue(strategy="IDENTITY")
         */
        private $id;
        
        /**
         * @var \Eccube\Entity\Customer
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Customer", inversedBy="BulkMailHistories")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="customer_id", referencedColumnName="id")
         * })
         */
        private $Customer;

        /**
         * @var \Eccube\Entity\Member
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Member")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="member_id", referencedColumnName="id", nullable=true)
         * })
         */
        private $Member;
        
        /**
         * @var \Eccube\Entity\BulkMailTemplate
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\BulkMailTemplate")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="mail_template_id", referencedColumnName="id", nullable=true)
         * })
         */
        private $BulkMailTemplate;
        
        /**
         * @var boolean
         *
         * @ORM\Column(name="send_mail_status", type="boolean", options={"default":false})
         */
        private $send_mail_status = false;

        /**
         * @var \DateTime|null
         *
         * @ORM\Column(name="send_date", type="datetimetz", nullable=true)
         */
        private $send_date;
        
        /**
         * @var \DateTime|null
         *
         * @ORM\Column(name="create_date", type="datetimetz", nullable=true)
         */
        private $create_date;
        
        /**
         * @var \DateTime|null
         *
         * @ORM\Column(name="update_date", type="datetimetz", nullable=true)
         */
        private $update_date;

        /**
         * Get id.
         *
         * @return int
         */
        public function getId()
        {
            return $this->id;
        }
        
        
        /**
         * Set customer.
         *
         * @param \Eccube\Entity\Customer|null $customer
         *
         * @return BulkMailHistory
         */
        public function setCustomer(\Eccube\Entity\Customer $customer = null)
        {
            $this->Customer = $customer;

            return $this;
        }

        /**
         * Get customer.
         *
         * @return \Eccube\Entity\Customer|null
         */
        public function getCustomer()
        {
            return $this->Customer;
        }

        /**
         * Set member.
         *
         * @param \Eccube\Entity\Member|null $member
         *
         * @return BulkMailHistory
         */
        public function setMember(\Eccube\Entity\Member $member = null)
        {
            $this->Member = $member;

            return $this;
        }

        /**
         * Get member.
         *
         * @return \Eccube\Entity\Member|null
         */
        public function getMember()
        {
            return $this->Member;
        }
        
        /**
         * Set bulkMailTemplate.
         *
         * @param \Eccube\Entity\BulkMailTemplate|null $bulkMailTemplate
         *
         * @return BulkMailHistory
         */
        public function setBulkMailTemplate(\Eccube\Entity\BulkMailTemplate $bulkMailTemplate = null)
        {
            $this->BulkMailTemplate = $bulkMailTemplate;

            return $this;
        }

        /**
         * Get bulkMailTemplate.
         *
         * @return \Eccube\Entity\BulkMailTemplate|null
         */
        public function getBulkMailTemplate()
        {
            return $this->BulkMailTemplate;
        }
        
         /**
         * Set sendMailStatus
         *
         * @param boolean $send_mail_status
         *
         * @return BulkMailHistory
         */
        public function setSendMailStatus($sendMailStatus)
        {
            $this->send_mail_status = $sendMailStatus;

            return $this;
        }

        /**
         * Get send_mail_status
         *
         * @return boolean
         */
        public function getSendMailStatus()
        {
            return $this->send_mail_status;
        }

        /**
         * Set sendDate.
         *
         * @param \DateTime|null $sendDate
         *
         * @return BulkMailHistory
         */
        public function setSendDate($sendDate = null)
        {
            $this->send_date = $sendDate;

            return $this;
        }

        /**
         * Get sendDate.
         *
         * @return \DateTime|null
         */
        public function getSendDate()
        {
            return $this->send_date;
        }
        
        /**
         * Set createDate.
         *
         * @param \DateTime|null $createDate
         *
         * @return BulkMailHistory
         */
        public function setCreateDate($createDate = null)
        {
            $this->create_date = $createDate;

            return $this;
        }

        /**
         * Get createDate.
         *
         * @return \DateTime|null
         */
        public function getCreateDate()
        {
            return $this->create_date;
        }
        
        /**
         * Set updateDate.
         *
         * @param \DateTime|null $updateDate
         *
         * @return BulkMailHistory
         */
        public function setUpdateDate($updateDate = null)
        {
            $this->update_date = $updateDate;

            return $this;
        }

        /**
         * Get updateDate.
         *
         * @return \DateTime|null
         */
        public function getUpdateDate()
        {
            return $this->update_date;
        }
       
    }
}
