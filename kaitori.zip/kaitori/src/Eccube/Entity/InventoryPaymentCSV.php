<?php

namespace Eccube\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * プログラム名 ： InventoryPaymentCSV,php
 * 概　　要     ： 受付照会CSV用エンティティ
 * 作　　成     ： 2021/08/21 CNC
 *
 */
class InventoryPaymentCSV extends AbstractEntity
{

    /**
     * Inventory constructor.
     */
    public function __construct()
    {
    }

    /**
     * @var string
     *
     */
    private $purchase_date;

    /**
     * @var string
     *
     */
    private $type;

    /**
     * @var string
     *
     */
    private $payee_voucher_no;

    /**
     * @var string
     *
     */
    private $state;

    /**
     * @var string
     *
     */
    private $payee_name;

    /**
     * @var string
     *
     */
    private $in_count;

    /**
     * @var string
     *
     */
    private $out_count;

    /**
     * @var string
     *
     */
    private $place;

    /**
     * @var string
     *
     */
    private $serial_no;

    /**
     * @return string
     */
    public function getSerialNo(): ?string
    {
        return $this->serial_no;
    }

    /**
     * @param string $serial_no
     */
    public function setSerialNo(?string $serial_no): void
    {
        $this->serial_no = $serial_no;
    }


    /**
     * @return string
     */
    public function getPurchaseDate(): ?string
    {
        return $this->purchase_date;
    }

    /**
     * @param string $purchase_date
     */
    public function setPurchaseDate(?string $purchase_date): void
    {
        $this->purchase_date = $purchase_date;
    }

    /**
     * @return string
     */
    public function getType(): ?string
    {
        return $this->type;
    }

    /**
     * @param string $type
     */
    public function setType(?string $type): void
    {
        $this->type = $type;
    }

    /**
     * @return string
     */
    public function getPayeeVoucherNo(): ?string
    {
        return $this->payee_voucher_no;
    }

    /**
     * @param string $payee_voucher_no
     */
    public function setPayeeVoucherNo(?string $payee_voucher_no): void
    {
        $this->payee_voucher_no = $payee_voucher_no;
    }

    /**
     * @return string
     */
    public function getState(): ?string
    {
        return $this->state;
    }

    /**
     * @param string $state
     */
    public function setState(?string $state): void
    {
        $this->state = $state;
    }

    /**
     * @return string
     */
    public function getPayeeName(): string
    {
        return $this->payee_name;
    }

    /**
     * @param string $payee_name
     */
    public function setPayeeName(?string $payee_name): void
    {
        $this->payee_name = $payee_name;
    }

    /**
     * @return string
     */
    public function getInCount(): ?string
    {
        return $this->in_count;
    }

    /**
     * @param string $in_count
     */
    public function setInCount(?string $in_count): void
    {
        $this->in_count = $in_count;
    }

    /**
     * @return string
     */
    public function getOutCount(): ?string
    {
        return $this->out_count;
    }

    /**
     * @param string $out_count
     */
    public function setOutCount(?string $out_count): void
    {
        $this->out_count = $out_count;
    }

    /**
     * @return string
     */
    public function getPlace(): ?string
    {
        return $this->place;
    }

    /**
     * @param string $place
     */
    public function setPlace(?string $place): void
    {
        $this->place = $place;
    }
}
