<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Entity;

use Doctrine\ORM\Mapping as ORM;

if (!class_exists('\Eccube\Entity\CategoryTopMatrix')) {
    /**
     * AmazonRule
     *
     * @ORM\Table(name="dtb_category_top_matrix")
     * @ORM\InheritanceType("SINGLE_TABLE")
     * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
     * @ORM\HasLifecycleCallbacks()
     * @ORM\Entity(repositoryClass="Eccube\Repository\CategoryTopMatrixRepository")
     */
    class CategoryTopMatrix extends \Eccube\Entity\AbstractEntity
    {
        /**
         * @return string
         */
        public function __toString()
        {
            return (string) $this->getName();
        }

        /**
         * @var integer
         *
         * @ORM\Column(name="id", type="integer", options={"unsigned":true})
         * @ORM\Id
         * @ORM\GeneratedValue(strategy="IDENTITY")
         */
        private $id;

        /**
         * @var \Eccube\Entity\Master\SaleType
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Master\SaleType")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="sale_type_id", referencedColumnName="id")
         * })
         */
        private $SaleType;

        /**
         * @var \Eccube\Entity\Category
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Category")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="category_id", referencedColumnName="id")
         * })
         */
        private $Category;

        /**
         * @var \Eccube\Entity\Category
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Category")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="recommend_category_id", referencedColumnName="id")
         * })
         */
        private $RecommendCategory;

        /**
         * Get id.
         *
         * @return int
         */
        public function getId()
        {
            return $this->id;
        }

        /**
         * Set SaleType.
         *
         * @param \Eccube\Entity\Master\SaleType|null $SaleType
         *
         * @return CategoryTopMatrix
         */
        public function setSaleType(\Eccube\Entity\Master\SaleType $SaleType = null)
        {
            $this->SaleType = $SaleType;

            return $this;
        }

        /**
         * Get SaleType.
         *
         * @return \Eccube\Entity\Master\SaleType|null
         */
        public function getSaleType()
        {
            return $this->SaleType;
        }

        /**
         * Set Category.
         *
         * @param \Eccube\Entity\Category|null $Category
         *
         * @return CategoryTopMatrix
         */
        public function setCategory(\Eccube\Entity\Category $Category = null)
        {
            $this->Category = $Category;

            return $this;
        }

        /**
         * Get Category.
         *
         * @return \Eccube\Entity\Category|null
         */
        public function getCategory()
        {
            return $this->Category;
        }

        /**
         * Set Category.
         *
         * @param \Eccube\Entity\Category|null $Category
         *
         * @return CategoryTopMatrix
         */
        public function setRecommendCategory(\Eccube\Entity\Category $Category = null)
        {
            $this->RecommendCategory = $Category;

            return $this;
        }

        /**
         * Get RecommendCategory.
         *
         * @return \Eccube\Entity\Category|null
         */
        public function getRecommendCategory()
        {
            return $this->RecommendCategory;
        }


    }
}
