<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Entity;

use Doctrine\ORM\Mapping as ORM;

if (!class_exists('\Eccube\Entity\CategorySeo')) {
    /**
     * CategorySeo
     *
     * @ORM\Table(name="dtb_category_seo")
     * @ORM\InheritanceType("SINGLE_TABLE")
     * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
     * @ORM\HasLifecycleCallbacks()
     * @ORM\Entity(repositoryClass="Eccube\Repository\CategorySeoRepository")
     */
    class CategorySeo extends \Eccube\Entity\AbstractEntity
    {
        /**
         * @return string
         */
        public function __toString()
        {
            return (string) $this->getName();
        }

        /**
         * @var int
         *
         * @ORM\Column(name="id", type="integer", options={"unsigned":true})
         * @ORM\Id
         * @ORM\GeneratedValue(strategy="IDENTITY")
         */
        private $id;

        /**
         * @var string|null
         *
         * @ORM\Column(name="title", type="string", length=255, nullable=true)
         */
        private $title;
        
        /**
         * @var string|null
         *
         * @ORM\Column(name="keyword", type="string", length=255, nullable=true)
         */
        private $keyword;

        /**
         * @var string|null
         *
         * @ORM\Column(name="description", type="text", nullable=true)
         */
        private $description;

        /**
         * Get id.
         *
         * @return int
         */
        public function getId()
        {
            return $this->id;
        }

        /**
         * Set title.
         *
         * @param string $title
         *
         * @return CategorySeo
         */
        public function setTitle($title)
        {
            $this->title = $title;

            return $this;
        }

        /**
         * Get title.
         *
         * @return string
         */
        public function getTitle()
        {
            return $this->title;
        }
        
        /**
         * Set keyword.
         *
         * @param string $keyword
         *
         * @return CategorySeo
         */
        public function setKeyword($keyword)
        {
            $this->keyword = $keyword;

            return $this;
        }

        /**
         * Get keyword.
         *
         * @return string
         */
        public function getKeyword()
        {
            return $this->keyword;
        }

        /**
         * Set description.
         *
         * @param string $description
         *
         * @return CategorySeo
         */
        public function setDescription($description)
        {
            $this->description = $description;

            return $this;
        }

        /**
         * Get description.
         *
         * @return string
         */
        public function getDescription()
        {
            return $this->description;
        }

    }
}
