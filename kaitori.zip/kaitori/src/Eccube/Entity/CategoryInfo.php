<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Entity;

use Doctrine\ORM\Mapping as ORM;

if (!class_exists('\Eccube\Entity\CategoryInfo')) {
    /**
     * CategoryInfo
     *
     * @ORM\Table(name="dtb_category_info")
     * @ORM\InheritanceType("SINGLE_TABLE")
     * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
     * @ORM\HasLifecycleCallbacks()
     * @ORM\Entity(repositoryClass="Eccube\Repository\CategoryInfoRepository")
     */
    class CategoryInfo extends \Eccube\Entity\AbstractEntity
    {
        /**
         * @return string
         */
        public function __toString()
        {
            return (string) $this->getName();
        }

        /**
         * @var int
         *
         * @ORM\Column(name="id", type="integer", options={"unsigned":true})
         * @ORM\Id
         * @ORM\GeneratedValue(strategy="IDENTITY")
         */
        private $id;

        /**
         * @var string|null
         *
         * @ORM\Column(name="category_image", type="string", length=255, nullable=true)
         */
        private $category_image;

        /**
         * @var string|null
         *
         * @ORM\Column(name="category_comment1", type="string", length=255, nullable=true)
         */
        private $category_comment1;

        /**
         * @var string|null
         *
         * @ORM\Column(name="category_comment2", type="string", length=1024, nullable=true)
         */
        private $category_comment2;

        /**
         * @var \Eccube\Entity\Category
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Category")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="category_id", referencedColumnName="id")
         * })
         */
        private $Category;


        /**
         * Get id.
         *
         * @return int
         */
        public function getId()
        {
            return $this->id;
        }

        /**
         * Set category_comment1.
         *
         * @param string|null $category_comment1
         *
         * @return CategoryInfo
         */
        public function setCategoryComment1($category_comment1 = null)
        {
            $this->category_comment1 = $category_comment1;

            return $this;
        }

        /**
         * Get category_comment1.
         *
         * @return string|null
         */
        public function getCategoryComment1()
        {
            return $this->category_comment1;
        }

        /**
         * Set category_comment2.
         *
         * @param string|null $category_comment2
         *
         * @return CategoryInfo
         */
        public function setCategoryComment2($category_comment2 = null)
        {
            $this->category_comment2 = $category_comment2;

            return $this;
        }

        /**
         * Get category_comment2.
         *
         * @return string|null
         */
        public function getCategoryComment2()
        {
            return $this->category_comment2;
        }


        /**
         * Set categoryImage.
         *
         * @param string|null $categoryImage
         *
         * @return CategoryInfo
         */
        public function setCategoryImage($categoryImage = null)
        {
            $this->category_image = $categoryImage;

            return $this;
        }

        /**
         * Get categoryImage.
         *
         * @return string|null
         */
        public function getCategoryImage()
        {
            return $this->category_image;
        }


        /**
         * Set Category.
         *
         * @param \Eccube\Entity\Category|null $Category
         *
         * @return CategoryInfo
         */
        public function setCategory(\Eccube\Entity\Category $Category = null)
        {
            $this->Category = $Category;

            return $this;
        }

        /**
         * Get Category.
         *
         * @return \Eccube\Entity\Category|null
         */
        public function getCategory()
        {
            return $this->Category;
        }

    }
}
