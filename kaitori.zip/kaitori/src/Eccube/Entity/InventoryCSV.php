<?php

namespace Eccube\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * プログラム名 ： InventoryCSV,php
 * 概　　要     ： 在庫照会CSV用エンティティ
 * 作　　成     ： 2021/07/29 CNC
 *
 */
class InventoryCSV extends AbstractEntity
{

    /**
     * Inventory constructor.
     */
    public function __construct()
    {
    }

    /**
     * @var string
     *
     */
    private $categoryname1;

    /**
     * @var string
     *
     */
    private $categoryname2;

    /**
     * @var string
     *
     */
    private $categoryname3;

    /**
     * @var string
     *
     */
    private $place;

    /**
     * @var string
     *
     */
    private $product_code;

    /**
     * @var string
     *
     */
    private $product_name;

    /**
     * @var string
     *
     */
    private $serial;

    /**
     * @var string
     *
     */
    private $state;

    /**
     * @var string
     *
     */
    private $stateId;

    /**
     * @var string
     *
     */
    private $stock_quantity;

    /**
     * @var string
     *
     */
    private $order_quantity;

    /**
     * @var string
     *
     */
    private $provisional_shipment_quantity;

    /**
     * @var string
     *
     */
    private $remaining_stock_quantity;

    /**
     * @var string
     *
     */
    private $average_unit_price;

    /**
     * @var string
     *
     */
    private $payee_price;

    /**
     * @var string
     *
     */
    private $reservation_quantity;

    /**
     * @var string
     *
     */
    private $stock_amount;

    /**
     * @var string
     *
     */
    private $payee_date;

    // ADD-START CNC 2022/12/03 ネット連動情報
    /**
     * @var string
     *
     */
    private $rakuten_stock_interlocking;

    /**
     * @var string
     *
     */
    private $rakuten_price_interlocking;

    /**
     * @var string
     *
     */
    private $yahoo_stock_interlocking;

    /**
     * @var string
     *
     */
    private $yahoo_price_interlocking;

    /**
     * @var string
     *
     */
    private $yahoo2_stock_interlocking;

    /**
     * @var string
     *
     */
    private $yahoo2_price_interlocking;

    /**
     * @var string
     *
     */
    private $amazon_stock_interlocking;

    /**
     * @var string
     *
     */
    private $amazon_price_interlocking;

    /**
     * @var string
     *
     */
    private $kakaku_stock_interlocking;

    /**
     * @var string
     *
     */
    private $kakaku_price_interlocking;
    // ADD-END CNC 2022/12/03 ネット連動情報

    /**
     * @return string
     */
    public function getCategoryname1(): ?string
    {
        return $this->categoryname1;
    }

    /**
     * @param string $categoryname1
     */
    public function setCategoryname1(?string $categoryname1): void
    {
        $this->categoryname1 = $categoryname1;
    }

    /**
     * @return string
     */
    public function getCategoryname2(): ?string
    {
        return $this->categoryname2;
    }

    /**
     * @param string $categoryname2
     */
    public function setCategoryname2(?string $categoryname2): void
    {
        $this->categoryname2 = $categoryname2;
    }

    /**
     * @return string
     */
    public function getCategoryname3(): ?string
    {
        return $this->categoryname3;
    }

    /**
     * @param string $categoryname3
     */
    public function setCategoryname3(?string $categoryname3): void
    {
        $this->categoryname3 = $categoryname3;
    }

    /**
     * @return string
     */
    public function getPlace(): ?string
    {
        return $this->place;
    }

    /**
     * @param string $place
     */
    public function setPlace(?string $place): void
    {
        $this->place = $place;
    }

    /**
     * @return string
     */
    public function getProductCode(): ?string
    {
        return $this->product_code;
    }

    /**
     * @param string $product_code
     */
    public function setProductCode(?string $product_code): void
    {
        $this->product_code = $product_code;
    }

    /**
     * @return string
     */
    public function getProductName(): ?string
    {
        return $this->product_name;
    }

    /**
     * @param string $product_name
     */
    public function setProductName(?string $product_name): void
    {
        $this->product_name = $product_name;
    }

    /**
     * @return string
     */
    public function getSerial(): ?string
    {
        return $this->serial;
    }

    /**
     * @param string $serial
     */
    public function setSerial(?string $serial): void
    {
        $this->serial = $serial;
    }

    /**
     * @return string
     */
    public function getState(): ?string
    {
        return $this->state;
    }

    /**
     * @param string $state
     */
    public function setState(?string $state): void
    {
        $this->state = $state;
    }

    /**
     * @return string
     */
    public function getStateId(): ?string
    {
        return $this->stateId;
    }

    /**
     * @param string $stateId
     */
    public function setStateId(?string $stateId): void
    {
        $this->stateId = $stateId;
    }

    /**
     * @return string
     */
    public function getStockQuantity(): ?string
    {
        return $this->stock_quantity;
    }

    /**
     * @param string $stock_quantity
     */
    public function setStockQuantity(?string $stock_quantity): void
    {
        $this->stock_quantity = $stock_quantity;
    }

    /**
     * @return string
     */
    public function getOrderQuantity(): ?string
    {
        return $this->order_quantity;
    }

    /**
     * @param string $order_quantity
     */
    public function setOrderQuantity(?string $order_quantity): void
    {
        $this->order_quantity = $order_quantity;
    }

    /**
     * @return string
     */
    public function getProvisionalShipmentQuantity(): ?string
    {
        return $this->provisional_shipment_quantity;
    }

    /**
     * @param string $provisional_shipment_quantity
     */
    public function setProvisionalShipmentQuantity(?string $provisional_shipment_quantity): void
    {
        $this->provisional_shipment_quantity = $provisional_shipment_quantity;
    }

    /**
     * @return string
     */
    public function getRemainingStockQuantity(): ?string
    {
        return $this->remaining_stock_quantity;
    }

    /**
     * @param string $remaining_stock_quantity
     */
    public function setRemainingStockQuantity(?string $remaining_stock_quantity): void
    {
        $this->remaining_stock_quantity = $remaining_stock_quantity;
    }

    /**
     * @return string
     */
    public function getAverageUnitPrice(): ?string
    {
        return $this->average_unit_price;
    }

    /**
     * @param string $average_unit_price
     */
    public function setAverageUnitPrice(?string $average_unit_price): void
    {
        $this->average_unit_price = $average_unit_price;
    }

    /**
     * @return string
     */
    public function getPayeePrice(): ?string
    {
        return $this->payee_price;
    }

    /**
     * @param string $payee_price
     */
    public function setPayeePrice(?string $payee_price): void
    {
        $this->payee_price = $payee_price;
    }

    /**
     * @return string
     */
    public function getStockAmount(): ?string
    {
        return $this->stock_amount;
    }

    /**
     * @param string $stock_amount
     */
    public function setStockAmount(?string $stock_amount): void
    {
        $this->stock_amount = $stock_amount;
    }

    /**
     * @return string
     */
    public function getPayeeDate()
    {
        return $this->payee_date;
    }

    /**
     * @param string $payee_date
     */
    public function setPayeeDate(string $payee_date)
    {
        $this->payee_date = $payee_date;
        return $this;
    }

    /**
     * @return string
     */
    public function getReservationQuantity(): ?string
    {
        return $this->reservation_quantity;
    }

    /**
     * @param string $reservation_quantity
     */
    public function setReservationQuantity(?string $reservation_quantity): void
    {
        $this->reservation_quantity = $reservation_quantity;
    }

    // ADD-START CNC 2022/12/03 ネット連動情報
    /**
     * @return string
     */
    public function getRakutenStockInterlocking(): ?string
    {
        return $this->rakuten_stock_interlocking;
    }

    /**
     * @param string $rakuten_stock_interlocking
     */
    public function setRakutenStockInterlocking(?string $rakuten_stock_interlocking): void
    {
        $this->rakuten_stock_interlocking = $rakuten_stock_interlocking;
    }

    /**
     * @return string
     */
    public function getRakutenPriceInterlocking(): ?string
    {
        return $this->rakuten_price_interlocking;
    }

    /**
     * @param string $rakuten_price_interlocking
     */
    public function setRakutenPriceInterlocking(?string $rakuten_price_interlocking): void
    {
        $this->rakuten_price_interlocking = $rakuten_price_interlocking;
    }

    /**
     * @return string
     */
    public function getYahooStockInterlocking(): ?string
    {
        return $this->yahoo_stock_interlocking;
    }

    /**
     * @param string $yahoo_stock_interlocking
=     */
    public function setYahooStockInterlocking(?string $yahoo_stock_interlocking): void
    {
        $this->yahoo_stock_interlocking = $yahoo_stock_interlocking;
    }

    /**
     * @return string
     */
    public function getYahooPriceInterlocking(): ?string
    {
        return $this->yahoo_price_interlocking;
    }

    /**
     * @param string $yahoo_price_interlocking
     */
    public function setYahooPriceInterlocking(?string $yahoo_price_interlocking): void
    {
        $this->yahoo_price_interlocking = $yahoo_price_interlocking;
    }

    /**
     * @return string
     */
    public function getYahoo2StockInterlocking(): ?string
    {
        return $this->yahoo2_stock_interlocking;
    }

    /**
     * @param string $yahoo2_stock_interlocking
     */
    public function setYahoo2StockInterlocking(?string $yahoo2_stock_interlocking): void
    {
        $this->yahoo2_stock_interlocking = $yahoo2_stock_interlocking;
    }

    /**
     * @return string
     */
    public function getYahoo2PriceInterlocking(): ?string
    {
        return $this->yahoo2_price_interlocking;
    }

    /**
     * @param string $yahoo2_price_interlocking
     */
    public function setYahoo2PriceInterlocking(?string $yahoo2_price_interlocking): void
    {
        $this->yahoo2_price_interlocking = $yahoo2_price_interlocking;
    }

    /**
     * @return string
     */
    public function getAmazonStockInterlocking(): ?string
    {
        return $this->amazon_stock_interlocking;
    }

    /**
     * @param string $amazon_stock_interlocking
     */
    public function setAmazonStockInterlocking(?string $amazon_stock_interlocking): void
    {
        $this->amazon_stock_interlocking = $amazon_stock_interlocking;
    }

    /**
     * @return string
     */
    public function getAmazonPriceInterlocking(): ?string
    {
        return $this->amazon_price_interlocking;
    }

    /**
     * @param string $amazon_price_interlocking
     */
    public function setAmazonPriceInterlocking(?string $amazon_price_interlocking): void
    {
        $this->amazon_price_interlocking = $amazon_price_interlocking;
    }

    /**
     * @return string
     */
    public function getKakakuStockInterlocking(): ?string
    {
        return $this->kakaku_stock_interlocking;
    }

    /**
     * @param string $kakaku_stock_interlocking
     */
    public function setKakakuStockInterlocking(?string $kakaku_stock_interlocking): void
    {
        $this->kakaku_stock_interlocking = $kakaku_stock_interlocking;
    }

    /**
     * @return string
     */
    public function getKakakuPriceInterlocking(): ?string
    {
        return $this->kakaku_price_interlocking;
    }

    /**
     * @param string $kakaku_price_interlocking
     */
    public function setKakakuPriceInterlocking(?string $kakaku_price_interlocking): void
    {
        $this->kakaku_price_interlocking = $kakaku_price_interlocking;
    }
    // ADD-END CNC 2022/12/03 ネット連動情報
}
