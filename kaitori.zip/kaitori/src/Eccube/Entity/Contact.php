<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Entity;

use Doctrine\ORM\Mapping as ORM;

if (!class_exists('\Eccube\Entity\Contact')) {
    /**
     * Contact
     * @ORM\Table(name="dtb_contact")
     * @ORM\InheritanceType("SINGLE_TABLE")
     * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
     * @ORM\HasLifecycleCallbacks()
     * @ORM\Entity(repositoryClass="Eccube\Repository\ContactRepository")
     */
    class Contact extends \Eccube\Entity\AbstractEntity
    {
        /**
         * @var integer
         *
         * @ORM\Column(name="id", type="integer", options={"unsigned":true})
         * @ORM\Id
         * @ORM\GeneratedValue(strategy="IDENTITY")
         */
        private $id;

        /**
         * @var string|null
         *
         * @ORM\Column(name="status", type="string", length=50, nullable=true)
         */
        private $status;
        
        /**
         * @var string|null
         *
         * @ORM\Column(name="note", type="string", length=4000, nullable=true)
         */
        private $note;

        /**
         * @var \Eccube\Entity\Customer
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Customer")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="customer_id", referencedColumnName="id")
         * })
         */
        private $Customer;

        /**
         * @var \Eccube\Entity\Member
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Member", inversedBy="Contacts")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="member_id", referencedColumnName="id")
         * })
         */
        private $Member;

        /**
         * @var string|null
         *
         * @ORM\Column(name="name01", type="string", length=255, nullable=true)
         */
        private $name01;

        /**
         * @var string|null
         *
         * @ORM\Column(name="name02", type="string", length=255, nullable=true)
         */
        private $name02;

        /**
         * @var string|null
         *
         * @ORM\Column(name="kana01", type="string", length=255, nullable=true)
         */
        private $kana01;

        /**
         * @var string|null
         *
         * @ORM\Column(name="kana02", type="string", length=255, nullable=true)
         */
        private $kana02;
        
        /**
         * @var string|null
         *
         * @ORM\Column(name="postal_code", type="string", length=8, nullable=true)
         */
        private $postal_code;

        /**
         * @var \Eccube\Entity\Master\Pref
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Master\Pref")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="pref_id", referencedColumnName="id")
         * })
         */
        private $Pref;

        /**
         * @var string|null
         *
         * @ORM\Column(name="addr01", type="string", length=255, nullable=true)
         */
        private $addr01;

        /**
         * @var string|null
         *
         * @ORM\Column(name="addr02", type="string", length=255, nullable=true)
         */
        private $addr02;

        /**
         * @var string|null
         *
         * @ORM\Column(name="phone_number", type="string", length=14, nullable=true)
         */
        private $phone_number;

        /**
         * @var string|null
         *
         * @ORM\Column(name="email", type="string", length=255, nullable=true)
         */
        private $email;

        /**
         * @var string|null
         *
         * @ORM\Column(name="contents", type="string", length=4000, nullable=true)
         */
        private $contents;

        /**
         * @var string|null
         *
         * @ORM\Column(name="items", type="string", length=5000, nullable=true)
         */
        private $items;

        /**
         * @var string|null
         *
         * @ORM\Column(name="items_html", type="string", length=5000, nullable=true)
         */
        private $items_html;

        /**
         * @var string|null
         *
         * @ORM\Column(name="items_html_adjust", type="string", length=5000, nullable=true)
         */
        private $items_html_adjust;

        /**
         * @var \DateTime
         *
         * @ORM\Column(name="create_date", type="datetimetz")
         */
        private $create_date;

        /**
         * @var \DateTime
         *
         * @ORM\Column(name="update_date", type="datetimetz")
         */
        private $update_date;

        /**
         * Get id.
         *
         * @return int
         */
        public function getId()
        {
            return $this->id;
        }

        /**
         * Set status.
         *
         * @param string|null $status
         *
         * @return Contact
         */
        public function setStatus($status = null)
        {
            $this->status = $status;
            return $this;
        }

        /**
         * Get status.
         *
         * @return string|null
         */
        public function getStatus()
        {
            return $this->status;
        }

        /**
         * Set name01.
         *
         * @param string|null $name01
         *
         * @return Contact
         */
        public function setName01($name01 = null)
        {
            $this->name01 = $name01;

            return $this;
        }

        /**
         * Get name01.
         *
         * @return string|null
         */
        public function getName01()
        {
            return $this->name01;
        }

        /**
         * Set name02.
         *
         * @param string|null $name02
         *
         * @return Contact
         */
        public function setName02($name02 = null)
        {
            $this->name02 = $name02;

            return $this;
        }

        /**
         * Get name02.
         *
         * @return string|null
         */
        public function getName02()
        {
            return $this->name02;
        }

        /**
         * Set kana01.
         *
         * @param string|null $kana01
         *
         * @return Contact
         */
        public function setKana01($kana01 = null)
        {
            $this->kana01 = $kana01;

            return $this;
        }

        /**
         * Get kana01.
         *
         * @return string|null
         */
        public function getKana01()
        {
            return $this->kana01;
        }

        /**
         * Set kana02.
         *
         * @param string|null $kana02
         *
         * @return Contact
         */
        public function setKana02($kana02 = null)
        {
            $this->kana02 = $kana02;

            return $this;
        }

        /**
         * Get kana02.
         *
         * @return string|null
         */
        public function getKana02()
        {
            return $this->kana02;
        }

        /**
         * Set email.
         *
         * @param string|null $email
         *
         * @return Contact
         */
        public function setEmail($email = null)
        {
            $this->email = $email;

            return $this;
        }

        /**
         * Get email.
         *
         * @return string|null
         */
        public function getEmail()
        {
            return $this->email;
        }

        /**
         * Set phone_number.
         *
         * @param string|null $phone_number
         *
         * @return Contact
         */
        public function setPhoneNumber($phone_number = null)
        {
            $this->phone_number = $phone_number;

            return $this;
        }

        /**
         * Get phone_number.
         *
         * @return string|null
         */
        public function getPhoneNumber()
        {
            return $this->phone_number;
        }

        /**
         * Set postal_code.
         *
         * @param string|null $postal_code
         *
         * @return Contact
         */
        public function setPostalCode($postal_code = null)
        {
            $this->postal_code = $postal_code;

            return $this;
        }

        /**
         * Get postal_code.
         *
         * @return string|null
         */
        public function getPostalCode()
        {
            return $this->postal_code;
        }

        /**
         * Set addr01.
         *
         * @param string|null $addr01
         *
         * @return Contact
         */
        public function setAddr01($addr01 = null)
        {
            $this->addr01 = $addr01;

            return $this;
        }

        /**
         * Get addr01.
         *
         * @return string|null
         */
        public function getAddr01()
        {
            return $this->addr01;
        }

        /**
         * Set addr02.
         *
         * @param string|null $addr02
         *
         * @return Contact
         */
        public function setAddr02($addr02 = null)
        {
            $this->addr02 = $addr02;

            return $this;
        }

        /**
         * Get addr02.
         *
         * @return string|null
         */
        public function getAddr02()
        {
            return $this->addr02;
        }

        /**
         * Set contents.
         *
         * @param string|null $contents
         *
         * @return Contact
         */
        public function setContents($contents = null)
        {
            $this->contents = $contents;

            return $this;
        }

        /**
         * Get contents.
         *
         * @return string|null
         */
        public function getContents()
        {
            return $this->contents;
        }

        /**
         * Set items.
         *
         * @param string|null $items
         *
         * @return Contact
         */
        public function setItems($items = null)
        {
            $this->items = $items;

            return $this;
        }

        /**
         * Get items.
         *
         * @return string|null
         */
        public function getItems()
        {
            return $this->items;
        }

        /**
         * Set items_html.
         *
         * @param string|null $items_html
         *
         * @return Contact
         */
        public function setItemsHtml($items_html = null)
        {
            $this->items_html = $items_html;

            return $this;
        }

        /**
         * Get items_html.
         *
         * @return string|null
         */
        public function getItemsHtml()
        {
            return $this->items_html;
        }

        /**
         * Set items_html_adjust.
         *
         * @param string|null $items_html_adjust
         *
         * @return Contact
         */
        public function setItemsHtmlAdjust($items_html_adjust = null)
        {
            $this->items_html_adjust = $items_html_adjust;

            return $this;
        }

        /**
         * Get items_html_adjust.
         *
         * @return string|null
         */
        public function getItemsHtmlAdjust()
        {
            return $this->items_html_adjust;
        }

        /**
         * Set createDate.
         *
         * @param \DateTime $createDate
         *
         * @return Contact
         */
        public function setCreateDate($createDate)
        {
            $this->create_date = $createDate;

            return $this;
        }

        /**
         * Get createDate.
         *
         * @return \DateTime
         */
        public function getCreateDate()
        {
            return $this->create_date;
        }

        /**
         * Set updateDate.
         *
         * @param \DateTime $updateDate
         *
         * @return Contact
         */
        public function setUpdateDate($updateDate)
        {
            $this->update_date = $updateDate;

            return $this;
        }

        /**
         * Get updateDate.
         *
         * @return \DateTime
         */
        public function getUpdateDate()
        {
            return $this->update_date;
        }

        /**
         * Set customer.
         *
         * @param \Eccube\Entity\Customer|null $customer
         *
         * @return Contact
         */
        public function setCustomer(\Eccube\Entity\Customer $customer = null)
        {
            $this->Customer = $customer;

            return $this;
        }

        /**
         * Get customer.
         *
         * @return \Eccube\Entity\Customer|null
         */
        public function getCustomer()
        {
            return $this->Customer;
        }

        /**
         * Set member.
         *
         * @param \Eccube\Entity\Member|null $member
         *
         * @return Contact
         */
        public function setMember(\Eccube\Entity\Member $member = null)
        {
            $this->Member = $member;

            return $this;
        }

        /**
         * Get member.
         *
         * @return \Eccube\Entity\Member|null
         */
        public function getMember()
        {
            return $this->Member;
        }

        /**
         * Set pref.
         *
         * @param \Eccube\Entity\Master\Pref|null $pref
         *
         * @return Contact
         */
        public function setPref(\Eccube\Entity\Master\Pref $pref = null)
        {
            $this->Pref = $pref;

            return $this;
        }

        /**
         * Get pref.
         *
         * @return \Eccube\Entity\Master\Pref|null
         */
        public function getPref()
        {
            return $this->Pref;
        }
        
        /**
         * Set note.
         *
         * @param string|null $note
         *
         * @return Order
         */
        public function setNote($note = null)
        {
            $this->note = $note;

            return $this;
        }

        /**
         * Get note.
         *
         * @return string|null
         */
        public function getNote()
        {
            return $this->note;
        }
    }
}
