<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Validator\Mapping\ClassMetadata;

if (!class_exists('\Eccube\Entity\Customer')) {
    /**
     * Customer
     *
     * @ORM\Table(name="dtb_customer", uniqueConstraints={@ORM\UniqueConstraint(name="secret_key", columns={"secret_key"})}, indexes={@ORM\Index(name="dtb_customer_buy_times_idx", columns={"buy_times"}), @ORM\Index(name="dtb_customer_buy_total_idx", columns={"buy_total"}), @ORM\Index(name="dtb_customer_create_date_idx", columns={"create_date"}), @ORM\Index(name="dtb_customer_update_date_idx", columns={"update_date"}), @ORM\Index(name="dtb_customer_last_buy_date_idx", columns={"last_buy_date"}), @ORM\Index(name="dtb_customer_email_idx", columns={"email"})})
     * @ORM\InheritanceType("SINGLE_TABLE")
     * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
     * @ORM\HasLifecycleCallbacks()
     * @ORM\Entity(repositoryClass="Eccube\Repository\CustomerRepository")
     */
    class Customer extends \Eccube\Entity\AbstractEntity implements UserInterface
    {
      /**
       * @var string
       *
       *@ORM\Column(name="account_name", type="string", length=255)
       */
       private $account_name;
        
       /**
         * @var string
         *
         *@ORM\Column(name="account_bank", type="string", length=255)
         */
        private $account_bank;
        
       /**
         * @var string
         *
         *@ORM\Column(name="account_branch", type="string", length=255)
         */
        private $account_branch;
        
        /**
         * @var \Eccube\Entity\Master\AccountType
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Master\AccountType")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="account_type", referencedColumnName="id")
         * })
         */
        private $account_type;
        
        /**
         * @var \Eccube\Entity\Master\BlackListType
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Master\BlackListType")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="black_list_type", referencedColumnName="id")
         * })
         */
        private $black_list_type;
        
        /**
         * @var \Eccube\Entity\Master\PersionType
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Master\PersionType")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="persion_type", referencedColumnName="id")
         * })
         */
        private $persion_type;
         
       /**
         * @var string
         *
         *@ORM\Column(name="account_no", type="string", length=14)
         */
        private $account_no; 
        
        /**
         * @var int
         *
         * @ORM\Column(name="id", type="integer", options={"unsigned":true})
         * @ORM\Id
         * @ORM\GeneratedValue(strategy="IDENTITY")
         */
        private $id;

        /**
         * @var string
         *
         * @ORM\Column(name="name01", type="string", length=255)
         */
        private $name01;

        /**
         * @var string
         *
         * @ORM\Column(name="name02", type="string", length=255)
         */
        private $name02;

        /**
         * @var string|null
         *
         * @ORM\Column(name="kana01", type="string", length=255, nullable=true)
         */
        private $kana01;

        /**
         * @var string|null
         *
         * @ORM\Column(name="kana02", type="string", length=255, nullable=true)
         */
        private $kana02;

        /**
         * @var string|null
         *
         * @ORM\Column(name="company_name", type="string", length=255, nullable=true)
         */
        private $company_name;
        
        /**
         * @var string|null
         *
         * @ORM\Column(name="company_name_kana", type="string", length=255, nullable=true)
         */
        private $company_name_kana;
        
        /**
         * @var string|null
         *
         * @ORM\Column(name="postal_code", type="string", length=8, nullable=true)
         */
        private $postal_code;
        
        /**
         * @var string|null
         *
         * @ORM\Column(name="company_postal_code", type="string", length=8, nullable=true)
         */
        private $company_postal_code;

        /**
         * @var string|null
         *
         * @ORM\Column(name="company_addr01", type="string", length=255, nullable=true)
         */
        private $company_addr01;
        
        /**
         * @var string|null
         *
         * @ORM\Column(name="addr01", type="string", length=255, nullable=true)
         */
        private $addr01;

        /**
         * @var string|null
         *
         * @ORM\Column(name="addr02", type="string", length=255, nullable=true)
         */
        private $addr02;
        
        /**
         * @var string|null
         *
         * @ORM\Column(name="company_addr02", type="string", length=255, nullable=true)
         */
        private $company_addr02;

        /**
         * @var string
         *
         * @ORM\Column(name="email", type="string", length=255)
         */
        private $email;

        /**
         * @var string|null
         *
         * @ORM\Column(name="phone_number", type="string", length=14, nullable=true)
         */
        private $phone_number;
        
        /**
         * @var string|null
         *
         * @ORM\Column(name="company_phone_number", type="string", length=14, nullable=true)
         */
        private $company_phone_number;

        /**
         * @var \DateTime|null
         *
         * @ORM\Column(name="birth", type="datetimetz", nullable=true)
         */
        private $birth;

        /**
         * @var string|null
         *
         * @ORM\Column(name="password", type="string", length=255)
         */
        private $password;

        /**
         * @var string|null
         *
         * @ORM\Column(name="salt", type="string", length=255, nullable=true)
         */
        private $salt;

        /**
         * @var string
         *
         * @ORM\Column(name="secret_key", type="string", length=255)
         */
        private $secret_key;

        /**
         * @var \DateTime|null
         *
         * @ORM\Column(name="first_buy_date", type="datetimetz", nullable=true)
         */
        private $first_buy_date;

        /**
         * @var \DateTime|null
         *
         * @ORM\Column(name="last_buy_date", type="datetimetz", nullable=true)
         */
        private $last_buy_date;

        /**
         * @var string|null
         *
         * @ORM\Column(name="buy_times", type="decimal", precision=10, scale=0, nullable=true, options={"unsigned":true,"default":0})
         */
        private $buy_times = 0;
        
        /**
         * @var string|null
         *
         * @ORM\Column(name="cancel_times", type="decimal", precision=10, scale=0, nullable=true, options={"unsigned":true,"default":0})
         */
        private $cancel_times = 0;

        /**
         * @var string|null
         *
         * @ORM\Column(name="buy_total", type="decimal", precision=12, scale=2, nullable=true, options={"unsigned":true,"default":0})
         */
        private $buy_total = 0;

        /**
         * @var \DateTime|null
         *
         * @ORM\Column(name="amazon_first_buy_date", type="datetimetz", nullable=true)
         */
        private $amazon_first_buy_date;

        /**
         * @var \DateTime|null
         *
         * @ORM\Column(name="amazon_last_buy_date", type="datetimetz", nullable=true)
         */
        private $amazon_last_buy_date;

        /**
         * @var string|null
         *
         * @ORM\Column(name="amazon_buy_times", type="decimal", precision=10, scale=0, nullable=true, options={"unsigned":true,"default":0})
         */
        private $amazon_buy_times = 0;

        /**
         * @var string|null
         *
         * @ORM\Column(name="amazon_buy_total", type="decimal", precision=12, scale=2, nullable=true, options={"unsigned":true,"default":0})
         */
        private $amazon_buy_total = 0;

        /**
         * @var string|null
         *
         * @ORM\Column(name="note", type="string", length=4000, nullable=true)
         */
        private $note;

        /**
         * @var string|null
         *
         * @ORM\Column(name="reset_key", type="string", length=255, nullable=true)
         */
        private $reset_key;

        /**
         * @var \DateTime|null
         *
         * @ORM\Column(name="reset_expire", type="datetimetz", nullable=true)
         */
        private $reset_expire;

        /**
         * @var string
         *
         * @ORM\Column(name="point", type="decimal", precision=12, scale=0, options={"unsigned":false,"default":0})
         */
        private $point = '0';

        /**
         * @var string
         *
         * @ORM\Column(name="point_org", type="decimal", precision=12, scale=0, options={"unsigned":false,"default":0})
         */
        private $point_org = '0';

        /**
         * @var \DateTime|null
         *
         * @ORM\Column(name="point_effective_date", type="datetimetz", nullable=true)
         */
        private $point_effective_date;

        /**
         * @var \DateTime|null
         *
         * @ORM\Column(name="point_expiration_date", type="datetimetz", nullable=true)
         */
        private $point_expiration_date;

        /**
         * @var \DateTime|null
         *
         * @ORM\Column(name="point_effective_org_date", type="datetimetz", nullable=true)
         */
        private $point_effective_org_date;

        /**
         * @var \DateTime|null
         *
         * @ORM\Column(name="point_expiration_org_date", type="datetimetz", nullable=true)
         */
        private $point_expiration_org_date;

        /**
         * @var \DateTime
         *
         * @ORM\Column(name="create_date", type="datetimetz")
         */
        private $create_date;

        /**
         * @var \DateTime
         *
         * @ORM\Column(name="update_date", type="datetimetz")
         */
        private $update_date;

        /**
         * @var string|null
         *
         * @ORM\Column(name="user_id", type="string", length=8, nullable=true)
         */
        private $old_id;

        /**
         * @var \Doctrine\Common\Collections\Collection
         *
         * @ORM\OneToMany(targetEntity="Eccube\Entity\CustomerFavoriteProduct", mappedBy="Customer", cascade={"remove"})
         */
        private $CustomerFavoriteProducts;

        /**
         * @var \Doctrine\Common\Collections\Collection
         *
         * @ORM\OneToMany(targetEntity="Eccube\Entity\CustomerAddress", mappedBy="Customer", cascade={"remove"})
         * @ORM\OrderBy({
         *     "id"="ASC"
         * })
         */
        private $CustomerAddresses;

        /**
         * @var \Doctrine\Common\Collections\Collection
         *
         * @ORM\OneToMany(targetEntity="Eccube\Entity\Order", mappedBy="Customer")
         */
        private $Orders;

        /**
         * @var \Eccube\Entity\Master\CustomerStatus
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Master\CustomerStatus")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="customer_status_id", referencedColumnName="id")
         * })
         */
        private $Status;

        /**
         * @var \Eccube\Entity\Master\Sex
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Master\Sex")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="sex_id", referencedColumnName="id")
         * })
         */
        private $Sex;

        /**
         * @var \Eccube\Entity\Master\Job
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Master\Job")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="job_id", referencedColumnName="id")
         * })
         */
        private $Job;
        
        /**
         * @var \Eccube\Entity\Master\Country
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Master\Country")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="country_id", referencedColumnName="id")
         * })
         */
        private $Country;
        
        /**
         * @var \Eccube\Entity\Master\Pref
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Master\Pref")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="pref_id", referencedColumnName="id")
         * })
         */
        private $Pref;
        
        /**
         * @var \Eccube\Entity\Master\Pref
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Master\Pref")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="company_pref_id", referencedColumnName="id")
         * })
         */
        private $CompanyPref;


        /**
         * @var \Eccube\Entity\CustomerCertsDoc
         * 
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\CustomerCertsDoc", cascade={"persist"})
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="customer_certs_doc_id1", referencedColumnName="id")
         * })
         */
        private $PersonalDocFile;

         /**
         * @var \Eccube\Entity\CustomerCertsDoc
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\CustomerCertsDoc", cascade={"persist"})
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="customer_certs_doc_id2", referencedColumnName="id")
         * })
         * 
         */
        private $CorporationDocFile;

        /**
         * @var boolean
         *
         * @ORM\Column(name="modified_flg", type="boolean", options={"default":false})
         */
        private $modified_flg = false;
        
        /**
         * @var boolean
         *
         * @ORM\Column(name="modified_verified", type="boolean", options={"default":false})
         */
        private $modified_verified = false;
        
        /**
         * @var \Eccube\Entity\Master\ModifiedReason
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Master\ModifiedReason")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="modified_reason", referencedColumnName="id")
         * })
         */
        private $ModifiedReason;

        /**
         * Constructor
         */
        public function __construct()
        {
            $this->CustomerFavoriteProducts = new \Doctrine\Common\Collections\ArrayCollection();
            $this->CustomerAddresses = new \Doctrine\Common\Collections\ArrayCollection();
            $this->Orders = new \Doctrine\Common\Collections\ArrayCollection();

            $this->setBuyTimes(0);
            $this->setBuyTotal(0);
        }

        /**
         * @return string
         */
        public function __toString()
        {
            return (string) ($this->getName01().' '.$this->getName02());
        }

        /**
         * {@inheritdoc}
         */
        public function getRoles()
        {
            return ['ROLE_USER'];
        }

        /**
         * {@inheritdoc}
         */
        public function getUsername()
        {
            return $this->email;
        }

        /**
         * {@inheritdoc}
         */
        public function eraseCredentials()
        {
        }

        // TODO: できればFormTypeで行いたい
        public static function loadValidatorMetadata(ClassMetadata $metadata)
        {
            $metadata->addConstraint(new UniqueEntity([
                'fields' => 'email',
                'message' => 'form_error.customer_already_exists',
                'repositoryMethod' => 'getNonWithdrawingCustomers',
            ]));
        }

        /**
         * Get id.
         *
         * @return int
         */
        public function getId()
        {
            return $this->id;
        }

        /**
         * Get oldid.
         *
         * @return string
         */
        public function getOldId()
        {
            return $this->old_id;
        }


        /**
         * Set name01.
         *
         * @param string $name01
         *
         * @return Customer
         */
        public function setName01($name01)
        {
            $this->name01 = $name01;

            return $this;
        }

        /**
         * Get name01.
         *
         * @return string
         */
        public function getName01()
        {
            return $this->name01;
        }
        
         /**
         * Set accountBank.
         *
         * @param string|null $accountBank
         *
         * @return Customer
         */
        public function setAccountBank($accountBank = null)
        {
            $this->account_bank = $accountBank;

            return $this;
        }

        /**
         * Get accountBank.
         *
         * @return string|null
         */
        public function getAccountBank()
        {
            return $this->account_bank;
        }
        
        /**
         * Set accountType.
         *
         * @param string|null $accountType
         *
         * @return Customer
         */
        public function setAccountType($accountType = null)
        {
            $this->account_type = $accountType;

            return $this;
        }

        /**
         * Get accountType.
         *
         * @return string|null
         */
        public function getAccountType()
        {
            return $this->account_type;
        }
        
        /**
         * Set blackListType.
         *
         * @param string|null $blackListType
         *
         * @return Customer
         */
        public function setBlackListType($blackListType = null)
        {
            $this->black_list_type = $blackListType;

            return $this;
        }

        /**
         * Get blackListType.
         *
         * @return string|null
         */
        public function getBlackListType()
        {
            return $this->black_list_type;
        }
        
        /**
         * Set persionType.
         *
         * @param string|null $persionType
         *
         * @return Customer
         */
        public function setPersionType($persionType = null)
        {
            $this->persion_type = $persionType;

            return $this;
        }

        /**
         * Get persionType.
         *
         * @return string|null
         */
        public function getPersionType()
        {
            return $this->persion_type;
        }
        
         /**
         * Set accountBranch.
         *
         * @param string|null $accountBranch
         *
         * @return Customer
         */
        public function setAccountBranch($accountBranch = null)
        {
            $this->account_branch = $accountBranch;

            return $this;
        }

        /**
         * Get accountBranch.
         *
         * @return string|null
         */
        public function getAccountBranch()
        {
            return $this->account_branch;
        }
        
         /**
         * Set accountName.
         *
         * @param string|null $accountName
         *
         * @return Customer
         */
        public function setAccountName($accountName = null)
        {
            $this->account_name = $accountName;

            return $this;
        }
        
        /**
         * Get accountName.
         *
         * @return string|null
         */
        public function getAccountName()
        {
            return $this->account_name;
        }
        
        
        /**
         * Set accountNo.
         *
         * @param string|null $accountNo
         *
         * @return Customer
         */
        public function setAccountNo($accountNo = null)
        {
            $this->account_no = $accountNo;

            return $this;
        }

        /**
         * Get accountNo.
         *
         * @return string|null
         */
        public function getAccountNo()
        {
            return $this->account_no;
        }
        

        /**
         * Set name02.
         *
         * @param string $name02
         *
         * @return Customer
         */
        public function setName02($name02)
        {
            $this->name02 = $name02;

            return $this;
        }

        /**
         * Get name02.
         *
         * @return string
         */
        public function getName02()
        {
            return $this->name02;
        }

        /**
         * Set kana01.
         *
         * @param string|null $kana01
         *
         * @return Customer
         */
        public function setKana01($kana01 = null)
        {
            $this->kana01 = $kana01;

            return $this;
        }

        /**
         * Get kana01.
         *
         * @return string|null
         */
        public function getKana01()
        {
            return $this->kana01;
        }

        /**
         * Set kana02.
         *
         * @param string|null $kana02
         *
         * @return Customer
         */
        public function setKana02($kana02 = null)
        {
            $this->kana02 = $kana02;

            return $this;
        }

        /**
         * Get kana02.
         *
         * @return string|null
         */
        public function getKana02()
        {
            return $this->kana02;
        }

        /**
         * Set companyName.
         *
         * @param string|null $companyName
         *
         * @return Customer
         */
        public function setCompanyName($companyName = null)
        {
            $this->company_name = $companyName;

            return $this;
        }

        /**
         * Get companyName.
         *
         * @return string|null
         */
        public function getCompanyName()
        {
            return $this->company_name;
        }
        
         /**
         * Set companyNameKana.
         *
         * @param string|null $companyNameKana
         *
         * @return Customer
         */
        public function setCompanyNameKana($companyNameKana = null)
        {
            $this->company_name_kana = $companyNameKana;

            return $this;
        }

        /**
         * Get companyNameKana.
         *
         * @return string|null
         */
        public function getCompanyNameKana()
        {
            return $this->company_name_kana;
        }

        /**
         * Set postal_code.
         *
         * @param string|null $postal_code
         *
         * @return Customer
         */
        public function setPostalCode($postal_code = null)
        {
            $this->postal_code = $postal_code;

            return $this;
        }

        /**
         * Get postal_code.
         *
         * @return string|null
         */
        public function getPostalCode()
        {
            return $this->postal_code;
        }
        
        /**
         * Set company_postal_code.
         *
         * @param string|null $company_postal_code
         *
         * @return Customer
         */
        public function setCompanyPostalCode($company_postal_code = null)
        {
            $this->company_postal_code = $company_postal_code;

            return $this;
        }

        /**
         * Get company_postal_code.
         *
         * @return string|null
         */
        public function getCompanyPostalCode()
        {
            return $this->company_postal_code;
        }

        /**
         * Set addr01.
         *
         * @param string|null $addr01
         *
         * @return Customer
         */
        public function setAddr01($addr01 = null)
        {
            $this->addr01 = $addr01;

            return $this;
        }

        /**
         * Get addr01.
         *
         * @return string|null
         */
        public function getAddr01()
        {
            return $this->addr01;
        }
        
        /**
         * Set company_addr01.
         *
         * @param string|null $company_addr01
         *
         * @return Customer
         */
        public function setCompanyAddr01($company_addr01 = null)
        {
            $this->company_addr01 = $company_addr01;

            return $this;
        }

        /**
         * Get company_addr01.
         *
         * @return string|null
         */
        public function getCompanyAddr01()
        {
            return $this->company_addr01;
        }

        /**
         * Set addr02.
         *
         * @param string|null $addr02
         *
         * @return Customer
         */
        public function setAddr02($addr02 = null)
        {
            $this->addr02 = $addr02;

            return $this;
        }

        /**
         * Get addr02.
         *
         * @return string|null
         */
        public function getAddr02()
        {
            return $this->addr02;
        }
        
        /**
         * Set company_addr02.
         *
         * @param string|null $company_addr02
         *
         * @return Customer
         */
        public function setCompanyAddr02($company_addr02 = null)
        {
            $this->company_addr02 = $company_addr02;

            return $this;
        }

        /**
         * Get company_addr02.
         *
         * @return string|null
         */
        public function getCompanyAddr02()
        {
            return $this->company_addr02;
        }

        /**
         * Set email.
         *
         * @param string $email
         *
         * @return Customer
         */
        public function setEmail($email)
        {
            $this->email = $email;

            return $this;
        }

        /**
         * Get email.
         *
         * @return string
         */
        public function getEmail()
        {
            return $this->email;
        }

        /**
         * Set phone_number.
         *
         * @param string|null $phone_number
         *
         * @return Customer
         */
        public function setPhoneNumber($phone_number = null)
        {
            $this->phone_number = $phone_number;

            return $this;
        }

        /**
         * Get phone_number.
         *
         * @return string|null
         */
        public function getPhoneNumber()
        {
            return $this->phone_number;
        }
        
        /**
         * Set company_phone_number.
         *
         * @param string|null $company_phone_number
         *
         * @return Customer
         */
        public function setCompanyPhoneNumber($company_phone_number = null)
        {
            $this->company_phone_number = $company_phone_number;

            return $this;
        }

        /**
         * Get company_phone_number.
         *
         * @return string|null
         */
        public function getCompanyPhoneNumber()
        {
            return $this->company_phone_number;
        }

        /**
         * Set birth.
         *
         * @param \DateTime|null $birth
         *
         * @return Customer
         */
        public function setBirth($birth = null)
        {
            $this->birth = $birth;

            return $this;
        }

        /**
         * Get birth.
         *
         * @return \DateTime|null
         */
        public function getBirth()
        {
            return $this->birth;
        }

        /**
         * Set password.
         *
         * @param string|null $password
         *
         * @return Customer
         */
        public function setPassword($password = null)
        {
            $this->password = $password;

            return $this;
        }

        /**
         * Get password.
         *
         * @return string|null
         */
        public function getPassword()
        {
            return $this->password;
        }

        /**
         * Set salt.
         *
         * @param string|null $salt
         *
         * @return Customer
         */
        public function setSalt($salt = null)
        {
            $this->salt = $salt;

            return $this;
        }

        /**
         * Get salt.
         *
         * @return string|null
         */
        public function getSalt()
        {
            return $this->salt;
        }

        /**
         * Set secretKey.
         *
         * @param string $secretKey
         *
         * @return Customer
         */
        public function setSecretKey($secretKey)
        {
            $this->secret_key = $secretKey;

            return $this;
        }

        /**
         * Get secretKey.
         *
         * @return string
         */
        public function getSecretKey()
        {
            return $this->secret_key;
        }

        /**
         * Set firstBuyDate.
         *
         * @param \DateTime|null $firstBuyDate
         *
         * @return Customer
         */
        public function setFirstBuyDate($firstBuyDate = null)
        {
            $this->first_buy_date = $firstBuyDate;

            return $this;
        }

        /**
         * Get firstBuyDate.
         *
         * @return \DateTime|null
         */
        public function getFirstBuyDate()
        {
            return $this->first_buy_date;
        }

        /**
         * Set lastBuyDate.
         *
         * @param \DateTime|null $lastBuyDate
         *
         * @return Customer
         */
        public function setLastBuyDate($lastBuyDate = null)
        {
            $this->last_buy_date = $lastBuyDate;

            return $this;
        }

        /**
         * Get lastBuyDate.
         *
         * @return \DateTime|null
         */
        public function getLastBuyDate()
        {
            return $this->last_buy_date;
        }

        /**
         * Set buyTimes.
         *
         * @param string|null $buyTimes
         *
         * @return Customer
         */
        public function setBuyTimes($buyTimes = null)
        {
            $this->buy_times = $buyTimes;

            return $this;
        }

        /**
         * Get buyTimes.
         *
         * @return string|null
         */
        public function getBuyTimes()
        {
            return $this->buy_times;
        }
        
        /**
         * Set cancelTimes.
         *
         * @param string|null $cancelTimes
         *
         * @return Customer
         */
        public function setCancelTimes($cancelTimes = null)
        {
            $this->cancel_times = $cancelTimes;

            return $this;
        }

        /**
         * Get cancelTimes.
         *
         * @return string|null
         */
        public function getCancelTimes()
        {
            return $this->cancel_times;
        }

        /**
         * Set buyTotal.
         *
         * @param string|null $buyTotal
         *
         * @return Customer
         */
        public function setBuyTotal($buyTotal = null)
        {
            $this->buy_total = $buyTotal;

            return $this;
        }

        /**
         * Get buyTotal.
         *
         * @return string|null
         */
        public function getBuyTotal()
        {
            return $this->buy_total;
        }

        /**
         * Set amazonFirstBuyDate.
         *
         * @param \DateTime|null $amazonFirstBuyDate
         *
         * @return Customer
         */
        public function setAmazonFirstBuyDate($amazonFirstBuyDate = null)
        {
            $this->amazon_first_buy_date = $amazonFirstBuyDate;

            return $this;
        }

        /**
         * Get amazonFirstBuyDate.
         *
         * @return \DateTime|null
         */
        public function getAmazonFirstBuyDate()
        {
            return $this->amazon_first_buy_date;
        }

        /**
         * Set amazonLastBuyDate.
         *
         * @param \DateTime|null $amazonLastBuyDate
         *
         * @return Customer
         */
        public function setAmazonLastBuyDate($amazonLastBuyDate = null)
        {
            $this->amazon_last_buy_date = $amazonLastBuyDate;

            return $this;
        }

        /**
         * Get amazonLastBuyDate.
         *
         * @return \DateTime|null
         */
        public function getAmazonLastBuyDate()
        {
            return $this->amazon_last_buy_date;
        }

        /**
         * Set amazonBuyTimes.
         *
         * @param string|null $amazonBuyTimes
         *
         * @return Customer
         */
        public function setAmazonBuyTimes($amazonBuyTimes = null)
        {
            $this->amazon_buy_times = $amazonBuyTimes;

            return $this;
        }

        /**
         * Get amazonBuyTimes.
         *
         * @return string|null
         */
        public function getAmazonBuyTimes()
        {
            return $this->amazon_buy_times;
        }

        /**
         * Set amazonBuyTotal.
         *
         * @param string|null $amazonBuyTotal
         *
         * @return Customer
         */
        public function setAmazonBuyTotal($amazonBuyTotal = null)
        {
            $this->amazon_buy_total = $amazonBuyTotal;

            return $this;
        }

        /**
         * Get AmazonBuyTotal.
         *
         * @return string|null
         */
        public function getAmazonBuyTotal()
        {
            return $this->amazon_buy_total;
        }

        /**
         * Set note.
         *
         * @param string|null $note
         *
         * @return Customer
         */
        public function setNote($note = null)
        {
            $this->note = $note;

            return $this;
        }

        /**
         * Get note.
         *
         * @return string|null
         */
        public function getNote()
        {
            return $this->note;
        }

        /**
         * Set resetKey.
         *
         * @param string|null $resetKey
         *
         * @return Customer
         */
        public function setResetKey($resetKey = null)
        {
            $this->reset_key = $resetKey;

            return $this;
        }

        /**
         * Get resetKey.
         *
         * @return string|null
         */
        public function getResetKey()
        {
            return $this->reset_key;
        }

        /**
         * Set resetExpire.
         *
         * @param \DateTime|null $resetExpire
         *
         * @return Customer
         */
        public function setResetExpire($resetExpire = null)
        {
            $this->reset_expire = $resetExpire;

            return $this;
        }

        /**
         * Get resetExpire.
         *
         * @return \DateTime|null
         */
        public function getResetExpire()
        {
            return $this->reset_expire;
        }

        /**
         * Set createDate.
         *
         * @param \DateTime $createDate
         *
         * @return Customer
         */
        public function setCreateDate($createDate)
        {
            $this->create_date = $createDate;

            return $this;
        }

        /**
         * Get createDate.
         *
         * @return \DateTime
         */
        public function getCreateDate()
        {
            return $this->create_date;
        }

        /**
         * Set updateDate.
         *
         * @param \DateTime $updateDate
         *
         * @return Customer
         */
        public function setUpdateDate($updateDate)
        {
            $this->update_date = $updateDate;

            return $this;
        }

        /**
         * Get updateDate.
         *
         * @return \DateTime
         */
        public function getUpdateDate()
        {
            return $this->update_date;
        }

        /**
         * Add customerFavoriteProduct.
         *
         * @param \Eccube\Entity\CustomerFavoriteProduct $customerFavoriteProduct
         *
         * @return Customer
         */
        public function addCustomerFavoriteProduct(\Eccube\Entity\CustomerFavoriteProduct $customerFavoriteProduct)
        {
            $this->CustomerFavoriteProducts[] = $customerFavoriteProduct;

            return $this;
        }

        /**
         * Remove customerFavoriteProduct.
         *
         * @param \Eccube\Entity\CustomerFavoriteProduct $customerFavoriteProduct
         *
         * @return boolean TRUE if this collection contained the specified element, FALSE otherwise.
         */
        public function removeCustomerFavoriteProduct(\Eccube\Entity\CustomerFavoriteProduct $customerFavoriteProduct)
        {
            return $this->CustomerFavoriteProducts->removeElement($customerFavoriteProduct);
        }

        /**
         * Get customerFavoriteProducts.
         *
         * @return \Doctrine\Common\Collections\Collection
         */
        public function getCustomerFavoriteProducts()
        {
            return $this->CustomerFavoriteProducts;
        }

        /**
         * Add customerAddress.
         *
         * @param \Eccube\Entity\CustomerAddress $customerAddress
         *
         * @return Customer
         */
        public function addCustomerAddress(\Eccube\Entity\CustomerAddress $customerAddress)
        {
            $this->CustomerAddresses[] = $customerAddress;

            return $this;
        }

        /**
         * Remove customerAddress.
         *
         * @param \Eccube\Entity\CustomerAddress $customerAddress
         *
         * @return boolean TRUE if this collection contained the specified element, FALSE otherwise.
         */
        public function removeCustomerAddress(\Eccube\Entity\CustomerAddress $customerAddress)
        {
            return $this->CustomerAddresses->removeElement($customerAddress);
        }

        /**
         * Get customerAddresses.
         *
         * @return \Doctrine\Common\Collections\Collection
         */
        public function getCustomerAddresses()
        {
            return $this->CustomerAddresses;
        }

        /**
         * Add order.
         *
         * @param \Eccube\Entity\Order $order
         *
         * @return Customer
         */
        public function addOrder(\Eccube\Entity\Order $order)
        {
            $this->Orders[] = $order;

            return $this;
        }

        /**
         * Remove order.
         *
         * @param \Eccube\Entity\Order $order
         *
         * @return boolean TRUE if this collection contained the specified element, FALSE otherwise.
         */
        public function removeOrder(\Eccube\Entity\Order $order)
        {
            return $this->Orders->removeElement($order);
        }

        /**
         * Get orders.
         *
         * @return \Doctrine\Common\Collections\Collection
         */
        public function getOrders()
        {
            return $this->Orders;
        }

        /**
         * Set status.
         *
         * @param \Eccube\Entity\Master\CustomerStatus $status
         *
         * @return Customer
         */
        public function setStatus(\Eccube\Entity\Master\CustomerStatus $status = null )
        {
            $this->Status = $status;

            return $this;
        }

        /**
         * Get status.
         *
         * @return \Eccube\Entity\Master\CustomerStatus|null
         */
        public function getStatus()
        {
            return $this->Status;
        }

        /**
         * Set sex.
         *
         * @param \Eccube\Entity\Master\Sex|null $sex
         *
         * @return Customer
         */
        public function setSex(\Eccube\Entity\Master\Sex $sex = null)
        {
            $this->Sex = $sex;

            return $this;
        }

        /**
         * Get sex.
         *
         * @return \Eccube\Entity\Master\Sex|null
         */
        public function getSex()
        {
            return $this->Sex;
        }

        /**
         * Set job.
         *
         * @param \Eccube\Entity\Master\Job|null $job
         *
         * @return Customer
         */
        public function setJob(\Eccube\Entity\Master\Job $job = null)
        {
            $this->Job = $job;

            return $this;
        }

        /**
         * Get job.
         *
         * @return \Eccube\Entity\Master\Job|null
         */
        public function getJob()
        {
            return $this->Job;
        }
        
        
        /**
         * Set country.
         *
         * @param \Eccube\Entity\Master\Country|null $country
         *
         * @return Customer
         */
        public function setCountry(\Eccube\Entity\Master\Country $country = null)
        {
            $this->Country = $country;

            return $this;
        }

        /**
         * Get country.
         *
         * @return \Eccube\Entity\Master\Country|null
         */
        public function getCountry()
        {
            return $this->Country;
        }
        
        /**
         * Set pref.
         *
         * @param \Eccube\Entity\Master\Pref|null $pref
         *
         * @return Customer
         */
        public function setPref(\Eccube\Entity\Master\Pref $pref = null)
        {
            $this->Pref = $pref;

            return $this;
        }

        /**
         * Get pref.
         *
         * @return \Eccube\Entity\Master\Pref|null
         */
        public function getPref()
        {
            return $this->Pref;
        }
        
        /**
         * Set company_pref.
         *
         * @param \Eccube\Entity\Master\Pref|null $company_pref
         *
         * @return Customer
         */
        public function setCompanyPref(\Eccube\Entity\Master\Pref $company_pref = null)
        {
            $this->CompanyPref = $company_pref;

            return $this;
        }

        /**
         * Get company_pref.
         *
         * @return \Eccube\Entity\Master\Pref|null
         */
        public function getCompanyPref()
        {
            return $this->CompanyPref;
        }

        /**
         * Set point
         *
         * @param string $point
         *
         * @return Customer
         */
        public function setPoint($point)
        {
            $this->point = $point;

            return $this;
        }

        /**
         * Get point
         *
         * @return string
         */
        public function getPoint()
        {
            return $this->point;
        }

        /**
         * Set point_org
         *
         * @param string $point_org
         *
         * @return Customer
         */
        public function setPointOrg($point_org)
        {
            $this->point_org = $point_org;

            return $this;
        }

        /**
         * Get point_org
         *
         * @return string
         */
        public function getPointOrg()
        {
            return $this->point_org;
        }


        /**
         * Set point_effective_date.
         *
         * @param \DateTime $point_effective_date
         *
         * @return Customer
         */
        public function setPointEffectiveDate($point_effective_date)
        {
            $this->point_effective_date = $point_effective_date;

            return $this;
        }

        /**
         * Get point_effective_date.
         *
         * @return \DateTime
         */
        public function getPointEffectiveDate()
        {
            return $this->point_effective_date;
        }

        /**
         * Set point_effective_org_date.
         *
         * @param \DateTime $point_effective_org_date
         *
         * @return Customer
         */
        public function setPointEffectiveOrgDate($point_effective_org_date)
        {
            $this->point_effective_org_date = $point_effective_org_date;

            return $this;
        }

        /**
         * Get point_effective_org_date.
         *
         * @return \DateTime
         */
        public function getPointEffectiveOrgDate()
        {
            return $this->point_effective_org_date;
        }

        /**
         * Set point_expiration_date.
         *
         * @param \DateTime $point_expiration_date
         *
         * @return Customer
         */
        public function setPointExpirationDate($point_expiration_date)
        {
            $this->point_expiration_date = $point_expiration_date;

            return $this;
        }

        /**
         * Get point_expiration_date.
         *
         * @return \DateTime
         */
        public function getPointExpirationDate()
        {
            return $this->point_expiration_date;
        }

        /**
         * Set point_expiration_org_date.
         *
         * @param \DateTime $point_expiration_org_date
         *
         * @return Customer
         */
        public function setPointExpirationOrgDate($point_expiration_org_date)
        {
            $this->point_expiration_org_date = $point_expiration_org_date;

            return $this;
        }

        /**
         * Get point_expiration_org_date.
         *
         * @return \DateTime
         */
        public function getPointExpirationOrgDate()
        {
            return $this->point_expiration_org_date;
        }

         /**
         * Set personalDocFile.
         *
         * @param \Eccube\Entity\CustomerCertsDoc|null $personalDocFile
         *
         * @return Order
         */
        public function setPersonalDocFile(\Eccube\Entity\CustomerCertsDoc $personalDocFile = null)
        {
            $this->PersonalDocFile = $personalDocFile;

            return $this;
        }

        /**
         * Get personalDocFile.
         *
         * @return \Eccube\Entity\CustomerCertsDoc|null
         */
        public function getPersonalDocFile()
        {
            return $this->PersonalDocFile;
        }

        /**
         * Set corporationDocFile.
         *
         * @param \Eccube\Entity\CustomerCertsDoc|null $corporationDocFile
         *
         * @return Order
         */
        public function setCorporationDocFile(\Eccube\Entity\CustomerCertsDoc $corporationDocFile = null)
        {
            $this->CorporationDocFile = $corporationDocFile;

            return $this;
        }

        /**
         * Get corporationDocFile.
         *
         * @return \Eccube\Entity\CustomerCertsDoc|null
         */
        public function getCorporationDocFile()
        {
            return $this->CorporationDocFile;
        }
        
        /**
         * Set modifiedFlg
         *
         * @param boolean $modifiedFlg
         *
         * @return Customer
         */
         public function setModifiedFlg($modifiedFlg)
         {
             $this->modified_flg = $modifiedFlg;
             return $this;
         }

        /**
         * Get modifiedFlg
         *
         * @return boolean
         */
         public function getModifiedFlg()
         {
           return $this->modified_flg;
         }
         
         /**
         * Set modifiedVerified
         *
         * @param boolean $modifiedVerified
         *
         * @return Customer
         */
         public function setModifiedVerified($modifiedVerified)
         {
             $this->modified_verified = $modifiedVerified;
             return $this;
         }

        /**
         * Get modifiedVerified
         *
         * @return boolean
         */
         public function getModifiedVerified()
         {
           return $this->modified_verified;
         }
        
        /**
         * Set modifiedReason.
         *
         * @param \Eccube\Entity\Master\ModifiedReason|null|object $modifiedReason
         *
         * @return Customer
         */
        public function setModifiedReason(\Eccube\Entity\Master\ModifiedReason $modifiedReason = null)
        {
            $this->ModifiedReason = $modifiedReason;

            return $this;
        }

        /**
         * Get modifiedReason.
         *
         * @return \Eccube\Entity\Master\ModifiedReason|null
         */
        public function getModifiedReason()
        {
            return $this->ModifiedReason;
        }

        private $personalDocList;
        /**
         * Set personalDocList.
         *
         * @param string|null $personalDocList
         *
         * @return Order
         */
        public function setPersonalDocList($personalDocList = null)
        {
            $this->personalDocList = $personalDocList;

            return $this;
        }

        /**
         * Get personalDocList.
         *
         * @return string|null
         */
        public function getPersonalDocList()
        {
            return $this->personalDocList;
        }

        private $corporationDocList;

        /**
         * Set corporationDocList.
         *
         * @param string|null $corporationDocList
         *
         * @return Order
         */
        public function setCorporationDocList($corporationDocList = null)
        {
            $this->corporationDocList = $corporationDocList;

            return $this;
        }

        /**
         * Get corporationDocList.
         *
         * @return string|null
         */
        public function getCorporationDocList()
        {
            return $this->corporationDocList;
        }

    }
}
