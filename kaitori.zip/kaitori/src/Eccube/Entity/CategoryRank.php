<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Entity;

use Doctrine\ORM\Mapping as ORM;

if (!class_exists('\Eccube\Entity\CategoryRank')) {
    /**
     * CategoryRank
     *
     * @ORM\Table(name="dtb_category_rank")
     * @ORM\InheritanceType("SINGLE_TABLE")
     * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
     * @ORM\HasLifecycleCallbacks()
     * @ORM\Entity(repositoryClass="Eccube\Repository\CategoryRankRepository")
     */
    class CategoryRank extends \Eccube\Entity\AbstractEntity
    {
        /**
         * @return string
         */
        public function __toString()
        {
            return (string) $this->getName();
        }

        /**
         * @var int
         *
         * @ORM\Column(name="id", type="integer", options={"unsigned":true})
         * @ORM\Id
         * @ORM\GeneratedValue(strategy="IDENTITY")
         */
        private $id;

        /**
         * @var string|null
         *
         * @ORM\Column(name="name", type="string", length=255, nullable=true)
         */
        private $name;
        
        /**
         * @var string|null
         *
         * @ORM\Column(name="url", type="string", length=255, nullable=true)
         */
        private $url;

        /**
         * @var string|null
         *
         * @ORM\Column(name="img_url", type="string", length=255, nullable=true)
         */
        private $img_url;

        /**
         * @var int
         *
         * @ORM\Column(name="sort_no", type="integer", options={"unsigned":true})
         */
        private $sort_no;

        /**
         * @var bool|null
         *
         * @ORM\Column(name="display_top", type="boolean", nullable=true, options={"comment"="表示:0:OFF；1:ON"})
         */
        private $display_top;

        /**
         * @var bool|null
         *
         * @ORM\Column(name="display_keitai", type="boolean", nullable=true, options={"comment"="表示:0:OFF；1:ON"})
         */
        private $display_keitai;

        /**
         * @var bool|null
         *
         * @ORM\Column(name="display_kaden", type="boolean", nullable=true, options={"comment"="表示:0:OFF；1:ON"})
         */
        private $display_kaden;

        /**
         * @var bool|null
         *
         * @ORM\Column(name="display_nitiyouhin", type="boolean", nullable=true, options={"comment"="表示:0:OFF；1:ON"})
         */
        private $display_nitiyouhin;

        /**
         * Get id.
         *
         * @return int
         */
        public function getId()
        {
            return $this->id;
        }

        /**
         * Set name.
         *
         * @param string $name
         *
         * @return CategoryRank
         */
        public function setName($name)
        {
            $this->name = $name;

            return $this;
        }

        /**
         * Get name.
         *
         * @return string
         */
        public function getName()
        {
            return $this->name;
        }
        
        /**
         * Set url.
         *
         * @param string $url
         *
         * @return CategoryRank
         */
        public function setUrl($url)
        {
            $this->url = $url;

            return $this;
        }

        /**
         * Get url.
         *
         * @return string
         */
        public function getUrl()
        {
            return $this->url;
        }

        /**
         * Set img_url.
         *
         * @param string $img_url
         *
         * @return CategoryRank
         */
        public function setImgUrl($img_url)
        {
            $this->img_url = $img_url;

            return $this;
        }

        /**
         * Get img_url.
         *
         * @return string
         */
        public function getImgUrl()
        {
            return $this->img_url;
        }

        /**
         * Set sort_no.
         *
         * @param string $sort_no
         *
         * @return CategoryRank
         */
        public function setSortNo($sort_no)
        {
            $this->sort_no = $sort_no;

            return $this;
        }

        /**
         * Get sort_no.
         *
         * @return string
         */
        public function getSortNo()
        {
            return $this->sort_no;
        }

        /**
         * Set display_top.
         *
         * @param bool $display_top
         *
         * @return CategoryRank
         */
        public function setDisplayTop($display_top)
        {
            $this->display_top = $display_top;

            return $this;
        }

        /**
         * Get display_top.
         *
         * @return bool
         */
        public function getDisplayTop()
        {
            return $this->display_top;
        }

        /**
         * Set display_keitai.
         *
         * @param bool $display_keitai
         *
         * @return CategoryRank
         */
        public function setDisplayKeitai($display_keitai)
        {
            $this->display_keitai = $display_keitai;

            return $this;
        }

        /**
         * Get display_keitai.
         *
         * @return bool
         */
        public function getDisplayKeitai()
        {
            return $this->display_keitai;
        }

        /**
         * Set display_kaden.
         *
         * @param bool $display_kaden
         *
         * @return CategoryRank
         */
        public function setDisplayKaden($display_kaden)
        {
            $this->display_kaden = $display_kaden;

            return $this;
        }

        /**
         * Get display_kaden.
         *
         * @return bool
         */
        public function getDisplayKaden()
        {
            return $this->display_kaden;
        }

        /**
         * Set display_nitiyouhin.
         *
         * @param bool $display_nitiyouhin
         *
         * @return CategoryRank
         */
        public function setDisplayNitiyouhin($display_nitiyouhin)
        {
            $this->display_nitiyouhin = $display_nitiyouhin;

            return $this;
        }

        /**
         * Get display_nitiyouhin.
         *
         * @return bool
         */
        public function getDisplayNitiyouhin()
        {
            return $this->display_nitiyouhin;
        }

    }
}
