<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Entity;

use Doctrine\ORM\Mapping as ORM;

if (!class_exists('\Eccube\Entity\CustomerCertsDoc')) {
    /**
     * CertsOption
     *
     * @ORM\Table(name="dtb_customer_certs_doc")
     * @ORM\InheritanceType("SINGLE_TABLE")
     * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
     * @ORM\HasLifecycleCallbacks()
     * @ORM\Entity(repositoryClass="Eccube\Repository\CustomerCertsDocRepository")
     */
    class CustomerCertsDoc extends \Eccube\Entity\AbstractEntity
    {

        /**
         * @var integer
         *
         * @ORM\Column(name="id", type="integer", options={"unsigned":true})
         * @ORM\Id
         * @ORM\GeneratedValue(strategy="IDENTITY")
         */
        private $id;

        /**
         * @var integer
         *
         * @ORM\Column(name="customer_id", type="integer")
         * 
         */
        private $customer_id;

        /**
         * @var integer
         * @ORM\Column(name="certs_doc_id", type="integer")
         */
        private $certs_doc_id;

        /**
         * @var \DateTime
         *
         * @ORM\Column(name="valid_date", type="datetimetz")
         */
        private $valid_date;

        /**
         * @var MEDIUMBLOB
         * @ORM\Column(name="picture1", type="blob")
         * 
         */
        private $picture1;

        /**
         * @var string
         *
         * @ORM\Column(name="extension1", type="string", length=100, nullable=true)
         */
        private $extension1;

        /**
         * @var MEDIUMBLOB
         * @ORM\Column(name="picture2", type="blob")
         * 
         */
        private $picture2;

        /**
         * @var string
         *
         * @ORM\Column(name="extension2", type="string", length=100, nullable=true)
         */
        private $extension2;

        /**
         * @var MEDIUMBLOB
         * @ORM\Column(name="picture3", type="blob")
         * 
         */
        private $picture3;

        /**
         * @var string
         *
         * @ORM\Column(name="extension3", type="string", length=100, nullable=true)
         */
        private $extension3;

        /**
         * @var MEDIUMBLOB
         * @ORM\Column(name="picture4", type="blob")
         * 
         */
        private $picture4;

        /**
         * @var string
         *
         * @ORM\Column(name="extension4", type="string", length=100, nullable=true)
         */
        private $extension4;

        /**
         * @var MEDIUMBLOB
         * @ORM\Column(name="picture5", type="blob")
         * 
         */
        private $picture5;

        /**
         * @var string
         *
         * @ORM\Column(name="extension5", type="string", length=100, nullable=true)
         */
        private $extension5;

        /**
         * @var MEDIUMBLOB
         * @ORM\Column(name="picture6", type="blob")
         * 
         */
        private $picture6;

        /**
         * @var string
         *
         * @ORM\Column(name="extension6", type="string", length=100, nullable=true)
         */
        private $extension6;

        /**
         * @var MEDIUMBLOB
         * @ORM\Column(name="picture7", type="blob")
         * 
         */
        private $picture7;

        /**
         * @var string
         *
         * @ORM\Column(name="extension7", type="string", length=100, nullable=true)
         */
        private $extension7;

        /**
         * @var MEDIUMBLOB
         * @ORM\Column(name="picture8", type="blob")
         * 
         */
        private $picture8;

        /**
         * @var string
         *
         * @ORM\Column(name="extension8", type="string", length=100, nullable=true)
         */
        private $extension8;

        /**
         * @var MEDIUMBLOB
         * @ORM\Column(name="picture9", type="blob")
         * 
         */
        private $picture9;

        /**
         * @var string
         *
         * @ORM\Column(name="extension9", type="string", length=100, nullable=true)
         */
        private $extension9;

        /**
         * @var tinyint
         * @ORM\Column(name="visible", type="boolean")
         * 
         */
        private $visible;
        
        /**
         * @var boolean
         *
         * @ORM\Column(name="modified_flg", type="boolean", options={"default":false})
         */
        private $modified_flg = false;
        
        /**
         * @var boolean
         *
         * @ORM\Column(name="modified_verified", type="boolean", options={"default":false})
         */
        private $modified_verified = false;
        
        /**
         * @var \Eccube\Entity\Master\ModifiedReason
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Master\ModifiedReason", inversedBy="Orders")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="modified_reason", referencedColumnName="id")
         * })
         */
        private $ModifiedReason;

        /**
         * @var \DateTime
         *
         * @ORM\Column(name="create_date", type="datetimetz")
         */
        private $create_date;

        /**
         * @var \DateTime
         *
         * @ORM\Column(name="update_date", type="datetimetz")
         */
        private $update_date;

        /**
         * Get id.
         *
         * @return int
         */
        public function getId()
        {
            return $this->id;
        }

        /**
         * Set id.
         *
         * @param int $id
         *
         * @return $this
         */
        public function setId($id)
        {
            $this->id = $id;

            return $this;
        }

        /**
         * Set customer_id.
         *
         * @param int $customer_id
         *
         * @return CustomerCertsDoc
         */
        public function setCustomerId($customerid)
        {
            $this->customer_id = $customerid;

            return $this;
        }

        /**
         * Get customer_id.
         *
         * @return int
         */
        public function getCustomerId()
        {
            return $this->customer_id;
        }

        /**
         * Set certsdocid.
         *
         * @param int $certsdocid
         *
         * @return CustomerCertsDoc
         */
        public function setCertsDocId($certsdocid)
        {
            $this->certs_doc_id = $certsdocid;

            return $this;
        }

        /**
         * Get certs_doc_id.
         *
         * @return int
         */
        public function getCertsDocId()
        {
            return $this->certs_doc_id;
        }

        /**
         * Set CertsType.
         *
         * @param validdate
         *
         * @return CustomerCertsDoc
         */
        public function setValidDate($validdate)
        {
            $this->valid_date = $validdate;

            return $this;
        }

        /**
         * Get valid_date.
         *
         * @return \DateTime
         */
        public function getValidDate()
        {
            return $this->valid_date;
        }

        /**
         * Set CertsDoc.
         *
         * @param picture1
         *
         * @return CustomerCertsDoc
         */
        public function setPicture1($picture1)
        {
            $this->picture1 = $picture1;

            return $this;
        }

        /**
         * Get CertsDoc.
         *
         * @return string
         */
        public function getPicture1()
        {
            return $this->picture1;
        }

        /**
         * Set CertsDoc.
         *
         * @param picture2
         *
         * @return CustomerCertsDoc
         */
        public function setPicture2($picture2)
        {
            $this->picture2 = $picture2;

            return $this;
        }

        /**
         * Get picture2.
         *
         * @return string
         */
        public function getPicture2()
        {
            return $this->picture2;
        }

        /**
         * Set visible.
         *
         * @param visible
         *
         * @return CustomerCertsDoc
         */
        public function setVisible($visible)
        {
            $this->visible = $visible;

            return $this;
        }

        /**
         * Get visible.
         *
         * @return boolean
         */
        public function getVisible()
        {
            return $this->visible;
        }

        /**
         * Set createDate.
         *
         * @param \DateTime $createDate
         *
         * @return CustomerCertsDoc
         */
        public function setCreateDate($createDate)
        {
            $this->create_date = $createDate;

            return $this;
        }

        /**
         * Get createDate.
         *
         * @return \DateTime
         */
        public function getCreateDate()
        {
            return $this->create_date;
        }

        /**
         * Set updateDate.
         *
         * @param \DateTime $updateDate
         *
         * @return CustomerCertsDoc
         */
        public function setUpdateDate($updateDate)
        {
            $this->update_date = $updateDate;

            return $this;
        }

        /**
         * Get updateDate.
         *
         * @return \DateTime
         */
        public function getUpdateDate()
        {
            return $this->update_date;
        } 
        
        /**
         * Set extension1.
         *
         * @param string $extension1
         *
         * @return CustomerCertsDoc
         */
        public function setExtension1($extension1)
        {
            $this->extension1 = $extension1;

            return $this;
        }

        /**
         * Get name.
         *
         * @return string
         */
        public function getExtension1()
        {
            return $this->extension1;
        }

        /**
         * Set extension2.
         *
         * @param string $extension2
         *
         * @return CustomerCertsDoc
         */
        public function setExtension2($extension2)
        {
            $this->extension2 = $extension2;

            return $this;
        }

        /**
         * Get extension2.
         *
         * @return string
         */
        public function getExtension2()
        {
            return $this->extension2;
        }

        /**
         * picture1_encode
         */
        private $picture1_encode;

        /**
         * Set picture1_encode.
         *
         * @param string $picture1_encode
         *
         * @return CustomerCertsDoc
         */
        public function setPicture1Encode($picture1_encode)
        {
            $this->picture1_encode = $picture1_encode;

            return $this;
        }

        /**
         * Get picture1_encode.
         *
         * @return string
         */
        public function getPicture1Encode()
        {
            return $this->picture1_encode;
        }

        /**
         * picture2_encode
         */
        private $picture2_encode;

        /**
         * Set picture2_encode.
         *
         * @param string $picture2_encode
         *
         * @return CustomerCertsDoc
         */
        public function setPicture2Encode($picture2_encode)
        {
            $this->picture2_encode = $picture2_encode;

            return $this;
        }

        /**
         * Get picture2_encode.
         *
         * @return string
         */
        public function getPicture2Encode()
        {
            return $this->picture2_encode;
        }

        /**
         * certs_doc_name
         */
        private $certs_doc_name;

        /**
         * Set certs_doc_name.
         *
         * @param string $certs_doc_name
         *
         * @return CustomerCertsDoc
         */
        public function setCertsDocName($certs_doc_name)
        {
            $this->certs_doc_name = $certs_doc_name;

            return $this;
        }

        /**
         * Get certs_doc_name.
         *
         * @return string
         */
        public function getCertsDocName()
        {
            return $this->certs_doc_name;
        }
        
        /**
         * Set modifiedFlg
         *
         * @param boolean $modifiedFlg
         *
         * @return CustomerCertsDoc
         */
         public function setModifiedFlg($modifiedFlg)
         {
             $this->modified_flg = $modifiedFlg;
             return $this;
         }

        /**
         * Get modifiedFlg
         *
         * @return boolean
         */
         public function getModifiedFlg()
         {
           return $this->modified_flg;
         }
         
         /**
         * Set modifiedVerified
         *
         * @param boolean $modifiedVerified
         *
         * @return CustomerCertsDoc
         */
         public function setModifiedVerified($modifiedVerified)
         {
             $this->modified_verified = $modifiedVerified;
             return $this;
         }

        /**
         * Get modifiedVerified
         *
         * @return boolean
         */
         public function getModifiedVerified()
         {
           return $this->modified_verified;
         }
        
        /**
         * Set modifiedReason.
         *
         * @param \Eccube\Entity\Master\ModifiedReason|null|object $modifiedReason
         *
         * @return CustomerCertsDoc
         */
        public function setModifiedReason(\Eccube\Entity\Master\ModifiedReason $modifiedReason = null)
        {
            $this->ModifiedReason = $modifiedReason;

            return $this;
        }

        /**
         * Get modifiedReason.
         *
         * @return \Eccube\Entity\Master\ModifiedReason|null
         */
        public function getModifiedReason()
        {
            return $this->ModifiedReason;
        }

        /**
         * picture3_encode
         */
        private $picture3_encode;

        /**
         * Set picture3_encode.
         *
         * @param string $picture3_encode
         *
         * @return CustomerCertsDoc
         */
        public function setPicture3Encode($picture3_encode)
        {
            $this->picture3_encode = $picture3_encode;

            return $this;
        }

        /**
         * Get picture3_encode.
         *
         * @return string
         */
        public function getPicture3Encode()
        {
            return $this->picture3_encode;
        }

        /**
         * picture4_encode
         */
        private $picture4_encode;

        /**
         * Set picture4_encode.
         *
         * @param string $picture4_encode
         *
         * @return CustomerCertsDoc
         */
        public function setPicture4Encode($picture4_encode)
        {
            $this->picture4_encode = $picture4_encode;

            return $this;
        }

        /**
         * Get picture4_encode.
         *
         * @return string
         */
        public function getPicture4Encode()
        {
            return $this->picture4_encode;
        }

        /**
         * picture5_encode
         */
        private $picture5_encode;

        /**
         * Set picture5_encode.
         *
         * @param string $picture5_encode
         *
         * @return CustomerCertsDoc
         */
        public function setPicture5Encode($picture5_encode)
        {
            $this->picture5_encode = $picture5_encode;

            return $this;
        }

        /**
         * Get picture5_encode.
         *
         * @return string
         */
        public function getPicture5Encode()
        {
            return $this->picture5_encode;
        }

        /**
         * picture6_encode
         */
        private $picture6_encode;

        /**
         * Set picture6_encode.
         *
         * @param string $picture6_encode
         *
         * @return CustomerCertsDoc
         */
        public function setPicture6Encode($picture6_encode)
        {
            $this->picture6_encode = $picture6_encode;

            return $this;
        }

        /**
         * Get picture6_encode.
         *
         * @return string
         */
        public function getPicture6Encode()
        {
            return $this->picture6_encode;
        }

        /**
         * picture7_encode
         */
        private $picture7_encode;

        /**
         * Set picture7_encode.
         *
         * @param string $picture7_encode
         *
         * @return CustomerCertsDoc
         */
        public function setPicture7Encode($picture7_encode)
        {
            $this->picture7_encode = $picture7_encode;

            return $this;
        }

        /**
         * Get picture7_encode.
         *
         * @return string
         */
        public function getPicture7Encode()
        {
            return $this->picture7_encode;
        }

        /**
         * picture8_encode
         */
        private $picture8_encode;

        /**
         * Set picture8_encode.
         *
         * @param string $picture8_encode
         *
         * @return CustomerCertsDoc
         */
        public function setPicture8Encode($picture8_encode)
        {
            $this->picture8_encode = $picture8_encode;

            return $this;
        }

        /**
         * Get picture8_encode.
         *
         * @return string
         */
        public function getPicture8Encode()
        {
            return $this->picture8_encode;
        }

        /**
         * picture9_encode
         */
        private $picture9_encode;

        /**
         * Set picture9_encode.
         *
         * @param string $picture9_encode
         *
         * @return CustomerCertsDoc
         */
        public function setPicture9Encode($picture9_encode)
        {
            $this->picture9_encode = $picture9_encode;

            return $this;
        }

        /**
         * Get picture9_encode.
         *
         * @return string
         */
        public function getPicture9Encode()
        {
            return $this->picture9_encode;
        }

        /**
         * Set CertsDoc.
         *
         * @param picture3
         *
         * @return CustomerCertsDoc
         */
        public function setPicture3($picture3)
        {
            $this->picture3 = $picture3;

            return $this;
        }

        /**
         * Get CertsDoc.
         *
         * @return string
         */
        public function getPicture3()
        {
            return $this->picture3;
        }

        /**
         * Set CertsDoc.
         *
         * @param picture4
         *
         * @return CustomerCertsDoc
         */
        public function setPicture4($picture4)
        {
            $this->picture4 = $picture4;

            return $this;
        }

        /**
         * Get CertsDoc.
         *
         * @return string
         */
        public function getPicture4()
        {
            return $this->picture4;
        }

        /**
         * Set CertsDoc.
         *
         * @param picture5
         *
         * @return CustomerCertsDoc
         */
        public function setPicture5($picture5)
        {
            $this->picture5 = $picture5;

            return $this;
        }

        /**
         * Get CertsDoc.
         *
         * @return string
         */
        public function getPicture5()
        {
            return $this->picture5;
        }

        /**
         * Set CertsDoc.
         *
         * @param picture6
         *
         * @return CustomerCertsDoc
         */
        public function setPicture6($picture6)
        {
            $this->picture6 = $picture6;

            return $this;
        }

        /**
         * Get CertsDoc.
         *
         * @return string
         */
        public function getPicture6()
        {
            return $this->picture6;
        }

        /**
         * Set CertsDoc.
         *
         * @param picture7
         *
         * @return CustomerCertsDoc
         */
        public function setPicture7($picture7)
        {
            $this->picture7 = $picture7;

            return $this;
        }

        /**
         * Get CertsDoc.
         *
         * @return string
         */
        public function getPicture7()
        {
            return $this->picture7;
        }

        /**
         * Set CertsDoc.
         *
         * @param picture8
         *
         * @return CustomerCertsDoc
         */
        public function setPicture8($picture8)
        {
            $this->picture8 = $picture8;

            return $this;
        }

        /**
         * Get CertsDoc.
         *
         * @return string
         */
        public function getPicture8()
        {
            return $this->picture8;
        }

        /**
         * Set CertsDoc.
         *
         * @param picture9
         *
         * @return CustomerCertsDoc
         */
        public function setPicture9($picture9)
        {
            $this->picture9 = $picture9;

            return $this;
        }

        /**
         * Get CertsDoc.
         *
         * @return string
         */
        public function getPicture9()
        {
            return $this->picture9;
        }

        /**
         * Set extension3.
         *
         * @param string $extension3
         *
         * @return CustomerCertsDoc
         */
        public function setExtension3($extension3)
        {
            $this->extension3 = $extension3;

            return $this;
        }

        /**
         * Get extension3.
         *
         * @return string
         */
        public function getExtension3()
        {
            return $this->extension3;
        }

        /**
         * Set extension4.
         *
         * @param string $extension4
         *
         * @return CustomerCertsDoc
         */
        public function setExtension4($extension4)
        {
            $this->extension4 = $extension4;

            return $this;
        }

        /**
         * Get extension4.
         *
         * @return string
         */
        public function getExtension4()
        {
            return $this->extension4;
        }

        /**
         * Set extension5.
         *
         * @param string $extension5
         *
         * @return CustomerCertsDoc
         */
        public function setExtension5($extension5)
        {
            $this->extension5 = $extension5;

            return $this;
        }

        /**
         * Get extension5.
         *
         * @return string
         */
        public function getExtension5()
        {
            return $this->extension5;
        }

        /**
         * Set extension6.
         *
         * @param string $extension6
         *
         * @return CustomerCertsDoc
         */
        public function setExtension6($extension6)
        {
            $this->extension6 = $extension6;

            return $this;
        }

        /**
         * Get extension6.
         *
         * @return string
         */
        public function getExtension6()
        {
            return $this->extension6;
        }

        /**
         * Set extension7.
         *
         * @param string $extension7
         *
         * @return CustomerCertsDoc
         */
        public function setExtension7($extension7)
        {
            $this->extension7 = $extension7;

            return $this;
        }

        /**
         * Get extension7.
         *
         * @return string
         */
        public function getExtension7()
        {
            return $this->extension7;
        }

        /**
         * Set extension8.
         *
         * @param string $extension8
         *
         * @return CustomerCertsDoc
         */
        public function setExtension8($extension8)
        {
            $this->extension8 = $extension8;

            return $this;
        }

        /**
         * Get extension8.
         *
         * @return string
         */
        public function getExtension8()
        {
            return $this->extension8;
        }

        /**
         * Set extension9.
         *
         * @param string $extension9
         *
         * @return CustomerCertsDoc
         */
        public function setExtension9($extension9)
        {
            $this->extension9 = $extension9;

            return $this;
        }

        /**
         * Get name.
         *
         * @return string
         */
        public function getExtension9()
        {
            return $this->extension9;
        }

    }
}
