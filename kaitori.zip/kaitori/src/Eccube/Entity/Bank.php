<?php

namespace Eccube\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Bank
 *
 * @ORM\Table(name="mtb_bank")
 * @ORM\InheritanceType("SINGLE_TABLE")
 * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
 * @ORM\HasLifecycleCallbacks()
 * @ORM\Entity(repositoryClass="Eccube\Repository\BankRepository")
 */
class Bank extends \Eccube\Entity\AbstractEntity
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="smallint", nullable=false, options={"unsigned"=true,"comment"="ID"})
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="transferor_account", type="string", length=255, nullable=false, options={"comment"="振込口座"})
     */
    private $transferorAccount;

    /**
     * @var string
     *
     * @ORM\Column(name="branch_name", type="string", length=255, nullable=false, options={"comment"="支店名"})
     */
    private $branchName;

    /**
     * @var string
     *
     * @ORM\Column(name="account_number", type="string", length=255, nullable=false, options={"comment"="口座番号"})
     */
    private $accountNumber;

    /**
     * @var string
     *
     * @ORM\Column(name="account_name", type="string", length=255, nullable=false, options={"comment"="口座名義"})
     */
    private $accountName;

    /**
     * @var int
     *
     * @ORM\Column(name="sort_no", type="smallint", nullable=false, options={"unsigned"=true,"comment"="ソート順"})
     */
    private $sortNo;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="create_date", type="datetime", nullable=false, options={"comment"="作成日時"})
     */
    private $createDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="update_date", type="datetime", nullable=false, options={"comment"="更新日時"})
     */
    private $updateDate;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    /**
     * @return string
     */
    public function getTransferorAccount()
    {
        return $this->transferorAccount;
    }

    /**
     * @param string $transferorAccount
     */
    public function setTransferorAccount(string $transferorAccount): void
    {
        $this->transferorAccount = $transferorAccount;
    }

    /**
     * @return string
     */
    public function getBranchName()
    {
        return $this->branchName;
    }

    /**
     * @param string $branchName
     */
    public function setBranchName(string $branchName): void
    {
        $this->branchName = $branchName;
    }

    /**
     * @return string
     */
    public function getAccountNumber()
    {
        return $this->accountNumber;
    }

    /**
     * @param string $accountNumber
     */
    public function setAccountNumber(string $accountNumber): void
    {
        $this->accountNumber = $accountNumber;
    }

    /**
     * @return string
     */
    public function getAccountName()
    {
        return $this->accountName;
    }

    /**
     * @param string $accountName
     */
    public function setAccountName(string $accountName): void
    {
        $this->accountName = $accountName;
    }

    /**
     * @return int
     */
    public function getSortNo()
    {
        return $this->sortNo;
    }

    /**
     * @param int $sortNo
     */
    public function setSortNo(int $sortNo): void
    {
        $this->sortNo = $sortNo;
    }

    /**
     * @return \DateTime
     */
    public function getCreateDate(): \DateTime
    {
        return $this->createDate;
    }

    /**
     * @param \DateTime $createDate
     */
    public function setCreateDate(\DateTime $createDate): void
    {
        $this->createDate = $createDate;
    }

    /**
     * @return \DateTime
     */
    public function getUpdateDate(): \DateTime
    {
        return $this->updateDate;
    }

    /**
     * @param \DateTime $updateDate
     */
    public function setUpdateDate(\DateTime $updateDate): void
    {
        $this->updateDate = $updateDate;
    }

}
