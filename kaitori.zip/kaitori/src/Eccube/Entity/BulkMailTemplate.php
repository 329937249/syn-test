<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * BulkMailTemplate 
 *
 * @ORM\Table(name="dtb_bulk_mail_template")
 * @ORM\InheritanceType("SINGLE_TABLE")
 * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
 * @ORM\HasLifecycleCallbacks()
 * @ORM\Entity(repositoryClass="Eccube\Repository\BulkMailTemplateRepository")
 * @ORM\Cache(usage="NONSTRICT_READ_WRITE")
 */
class BulkMailTemplate extends \Eccube\Entity\AbstractEntity
{

    /**
     * @return string
     */
    public function __toString()
    {
        return (string) $this->getTitle();
    }
    
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", options={"unsigned":true})
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var string|null
     *
     * @ORM\Column(name="name", type="string", length=255, nullable=true)
     */
    private $name;
    
    /**
     * @var string|null
     *
     * @ORM\Column(name="title", type="string", length=255, nullable=true)
     */
    private $title;
    
     /**
      * @var \DateTime
      *
      * @ORM\Column(name="create_date", type="datetimetz")
      */
      private $create_date;

      /**
       * @var \DateTime
       *
       * @ORM\Column(name="update_date", type="datetimetz")
       */
      private $update_date;

    /**
     * @var string|null
     *
     * @ORM\Column(name="description", type="text", nullable=true)
     */
    private $description;

    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set id.
     *
     * @param string|null $id
     *
     * @return BulkMailTemplate
     */
    public function setId($id = null)
    {
        $this->id = $id;

        return $this;
    }
    
    /**
     * Set name.
     *
     * @param string $name
     *
     * @return BulkMailTemplate
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name.
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set title.
     *
     * @param string $title
     *
     * @return BulkMailTemplate
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title.
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set description.
     *
     * @param string $description
     *
     * @return BulkMailTemplate
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description.
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }
    
    /**
     * Set createDate.
     *
     * @param \DateTime $createDate
     *
     * @return BulkMailTemplate
     */
      public function setCreateDate($createDate)
      {
           $this->create_date = $createDate;

           return $this;
      }

      /**
       * Get createDate.
       *
       * @return \DateTime
       */
       public function getCreateDate()
       {
           return $this->create_date;
       }

        /**
         * Set updateDate.
         *
         * @param \DateTime $updateDate
         *
         * @return BulkMailTemplate
         */
        public function setUpdateDate($updateDate)
        {
            $this->update_date = $updateDate;

            return $this;
        }

        /**
         * Get updateDate.
         *
         * @return \DateTime
         */
        public function getUpdateDate()
        {
            return $this->update_date;
        }

}