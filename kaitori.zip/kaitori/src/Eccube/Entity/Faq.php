<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Entity;

use Doctrine\ORM\Mapping as ORM;

if (!class_exists('\Eccube\Entity\Faq')) {
    /**
     * Faq
     *
     * @ORM\Table(name="dtb_faq")
     * @ORM\InheritanceType("SINGLE_TABLE")
     * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
     * @ORM\HasLifecycleCallbacks()
     * @ORM\Entity(repositoryClass="Eccube\Repository\FaqRepository")
     * @ORM\Cache(usage="NONSTRICT_READ_WRITE")
     */
    class Faq extends AbstractEntity
    {
        /**
         * @return string
         */
        public function __toString()
        {
            return (string) $this->getTitle();
        }

        /**
         * @var int
         *
         * @ORM\Column(name="id", type="integer", options={"unsigned":true})
         * @ORM\Id
         * @ORM\GeneratedValue(strategy="IDENTITY")
         */
        private $id;

        /**
         * @var string
         *
         * @ORM\Column(name="title", type="string", length=255)
         */
        private $title;

        /**
         * @var string
         *
         * @ORM\Column(name="question", type="string", length=255)
         */
        private $question;

        /**
         * @var string
         *
         * @ORM\Column(name="answer", type="string", length=1024)
         */
        private $answer;

        /**
         * @var int|null
         *
         * @ORM\Column(name="site_id", type="smallint", nullable=true, options={"unsigned":true})
         */
        private $site_id;

        /**
         * @var int|null
         *
         * @ORM\Column(name="sort_no", type="smallint", nullable=true, options={"unsigned":true})
         */
        private $sort_no;

        /**
         * Get id.
         *
         * @return int
         */
        public function getId()
        {
            return $this->id;
        }

        /**
         * Set title.
         *
         * @param string $title
         *
         * @return Faq
         */
        public function setTitle($title)
        {
            $this->title = $title;

            return $this;
        }

        /**
         * Get title.
         *
         * @return string
         */
        public function getTitle()
        {
            return $this->title;
        }

        /**
         * Set question.
         *
         * @param string|null $question
         *
         * @return Faq
         */
        public function setQuestion($question = null)
        {
            $this->question = $question;

            return $this;
        }

        /**
         * Get question.
         *
         * @return string|null
         */
        public function getQuestion()
        {
            return $this->question;
        }

        /**
         * Set answer.
         *
         * @param string|null $answer
         *
         * @return Faq
         */
        public function setAnswer($answer = null)
        {
            $this->answer = $answer;

            return $this;
        }

        /**
         * Get answer.
         *
         * @return string|null
         */
        public function getAnswer()
        {
            return $this->answer;
        }

        /**
         * Set sortNo.
         *
         * @param int|null $sortNo
         *
         * @return Faq
         */
        public function setSortNo($sortNo = null)
        {
            $this->sort_no = $sortNo;

            return $this;
        }

        /**
         * Get sortNo.
         *
         * @return int|null
         */
        public function getSortNo()
        {
            return $this->sort_no;
        }

        /**
         * Set siteId.
         *
         * @param int|null $siteId
         *
         * @return Faq
         */
        public function setSiteId($siteId = null)
        {
            $this->site_id = $siteId;

            return $this;
        }

        /**
         * Get siteId.
         *
         * @return int|null
         */
        public function getSiteId()
        {
            return $this->site_id;
        }

    }
}
