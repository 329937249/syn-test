<?php

namespace Eccube\Entity;

class LogControllable
{
    const LOG_CONTROLLABLE_ENABLE = 1;

    /**
     * @param string $message message
     * @param array $context context array
     * @param string $path used by
     */
    public static function print_log(string $path, string $message, array $context = [])
    {
        if (self::LOG_CONTROLLABLE_ENABLE) {
            log_info($message.'['.$path.']', $context);
        }
    }
}