<?php

namespace Eccube\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Batch
 *
 * @ORM\Table(name="dtb_batch")
 * @ORM\InheritanceType("SINGLE_TABLE")
 * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
 * @ORM\HasLifecycleCallbacks()
 * @ORM\Entity(repositoryClass="Eccube\Repository\BatchRepository")
 */
class Batch
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(name="name", type="string", length=255)
     */
    private $name;

    /**
     * @ORM\Column(name="status", type="string", length=255)
     */
    private $status;

    /**
     * @ORM\Column(name="desc", type="string", length=255)
     */
    private $desc;

    /**
     * @var \DateTime
     * 
     * @ORM\Column(name="last_start_time", type="datetimetz")
     */
    private $last_start_time;

    /**
     * @var \DateTime
     * 
     * @ORM\Column(name="last_finish_time", type="datetimetz")
     */
    private $last_finish_time;

    /**
     * @ORM\Column(name="jenkins_token", type="string", length=255)
     */
    private $jenkins_token;

    /**
     * @ORM\Column(name="jenkins_url", type="string", length=255)
     */
    private $jenkins_url;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="create_date", type="datetimetz")
     */
    private $create_date;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="update_date", type="datetimetz")
     */
    private $update_date;

    /**
     * Set name.
     *
     * @return Batch
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name.
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set status.
     *
     * @return Batch
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status.
     *
     * @return string
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set desc.
     *
     * @return Batch
     */
    public function setDesc($desc)
    {
        $this->desc = $desc;

        return $this;
    }

    /**
     * Get desc.
     *
     * @return string
     */
    public function getDesc()
    {
        return $this->desc;
    }

    /**
     * Set jenkins_url.
     *
     * @return Batch
     */
    public function setJenkinsUrl($jenkins_url)
    {
        $this->jenkins_url = $jenkins_url;

        return $this;
    }

    /**
     * Get jenkins_url.
     *
     * @return string
     */
    public function getJenkinsUrl()
    {
        return $this->jenkins_url;
    }

    /**
     * Set jenkins_token.
     *
     * @return Batch
     */
    public function setJenkinsToken($jenkins_token)
    {
        $this->jenkins_token = $jenkins_token;

        return $this;
    }

    /**
     * Get jenkins_token.
     *
     * @return string
     */
    public function getJenkinsToken()
    {
        return $this->jenkins_token;
    }

    /**
     * Set last_start_time.
     *
     * @param \DateTime $last_start_time
     *
     * @return Batch
     */
    public function setLastStartTime($last_start_time)
    {
        $this->last_start_time = $last_start_time;

        return $this;
    }

    /**
     * Get last_start_time.
     *
     * @return \DateTime
     */
    public function getLastStartTime()
    {
        return $this->last_start_time;
    }

    /**
     * Set last_finish_time.
     *
     * @param \DateTime $last_finish_time
     *
     * @return Batch
     */
    public function setLastFinishTime($last_finish_time)
    {
        $this->last_finish_time = $last_finish_time;

        return $this;
    }

    /**
     * Get last_start_time.
     *
     * @return \DateTime
     */
    public function getLastFinishTime()
    {
        return $this->last_finish_time;
    }

    /**
     * Set id.
     *
     * @return Batch
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set createDate.
     *
     * @param \DateTime $createDate
     *
     * @return Batch
     */
    public function setCreateDate($createDate)
    {
        $this->create_date = $createDate;

        return $this;
    }

    /**
     * Get createDate.
     *
     * @return \DateTime
     */
    public function getCreateDate()
    {
        return $this->create_date;
    }

    /**
     * Set updateDate.
     *
     * @param \DateTime $updateDate
     *
     * @return Batch
     */
    public function setUpdateDate($updateDate)
    {
        $this->update_date = $updateDate;

        return $this;
    }

    /**
     * Get updateDate.
     *
     * @return \DateTime
     */
    public function getUpdateDate()
    {
        return $this->update_date;
    }
}
