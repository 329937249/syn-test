<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Entity;

use Doctrine\ORM\Mapping as ORM;

if (!class_exists('\Eccube\Entity\CertsOption')) {
    /**
     * CertsOption
     *
     * @ORM\Table(name="dtb_certs_option")
     * @ORM\InheritanceType("SINGLE_TABLE")
     * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
     * @ORM\HasLifecycleCallbacks()
     * @ORM\Entity(repositoryClass="Eccube\Repository\CertsOptionRepository")
     */
    class CertsOption extends \Eccube\Entity\AbstractEntity
    {
        /**
         * @var int
         *
         * @ORM\Column(name="certs_type_id", type="integer", options={"unsigned":true})
         * @ORM\Id
         * @ORM\GeneratedValue(strategy="NONE")
         */
        private $certs_type_id;

        /**
         * @var int
         *
         * @ORM\Column(name="certs_doc_id", type="integer", options={"unsigned":true})
         * @ORM\Id
         * @ORM\GeneratedValue(strategy="NONE")
         */
        private $certs_doc_id;

        /**
         * @var \Eccube\Entity\Master\CertsType
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Master\CertsType", inversedBy="CertsOptions")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="certs_type_id", referencedColumnName="id")
         * })
         */
        private $CertsType;

        /**
         * @var \Eccube\Entity\Master\CertsDoc
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Master\CertsDoc", inversedBy="CertsOptions")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="certs_doc_id", referencedColumnName="id")
         * })
         */
        private $CertsDoc;

        /**
         * Set certs_type_id.
         *
         * @param int $certs_type_id
         *
         * @return CertsOption
         */
        public function setCertsTypeId($certs_type_id)
        {
            $this->certs_type_id = $certs_type_id;

            return $this;
        }

        /**
         * Get certs_type_id.
         *
         * @return int
         */
        public function getCertsTypeId()
        {
            return $this->certs_type_id;
        }

        /**
         * Set certs_doc_id.
         *
         * @param int $certs_doc_id
         *
         * @return CertsOption
         */
        public function setCertsDocId($certs_doc_id)
        {
            $this->certs_doc_id = $certs_doc_id;

            return $this;
        }

        /**
         * Get certs_doc_id.
         *
         * @return int
         */
        public function getCertsDocId()
        {
            return $this->certs_doc_id;
        }

        /**
         * Set CertsType.
         *
         * @param \Eccube\Entity\Master\CertsType|null $certsType
         *
         * @return CertsOption
         */
        public function setCertsType(\Eccube\Entity\Master\CertsType $certsType = null)
        {
            $this->CertsType = $certsType;

            return $this;
        }

        /**
         * Get CertsType.
         *
         * @return \Eccube\Entity\Master\CertsType|null
         */
        public function getCertsType()
        {
            return $this->CertsType;
        }

        /**
         * Set CertsDoc.
         *
         * @param \Eccube\Entity\Master\CertsDoc|null $certsDoc
         *
         * @return CertsOption
         */
        public function setCertsDoc(\Eccube\Entity\Master\CertsDoc $certsDoc = null)
        {
            $this->CertsDoc = $certsDoc;

            return $this;
        }

        /**
         * Get CertsDoc.
         *
         * @return \Eccube\Entity\Master\CertsDoc|null
         */
        public function getCertsDoc()
        {
            return $this->CertsDoc;
        }
    }
}
