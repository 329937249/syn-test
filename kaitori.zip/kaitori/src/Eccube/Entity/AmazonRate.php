<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Entity;

use Doctrine\ORM\Mapping as ORM;

if (!class_exists('\Eccube\Entity\AmazonRate')) {
    /**
     * AmazonRate
     *
     * @ORM\Table(name="dtb_amazon_rate")
     * @ORM\InheritanceType("SINGLE_TABLE")
     * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
     * @ORM\HasLifecycleCallbacks()
     * @ORM\Entity(repositoryClass="Eccube\Repository\AmazonRateRepository")
     */
    class AmazonRate extends \Eccube\Entity\AbstractEntity
    {
        /**
         * @return string
         */
        public function __toString()
        {
            return (string) $this->getName();
        }

        /**
         * @var integer
         *
         * @ORM\Column(name="id", type="integer", options={"unsigned":true})
         * @ORM\Id
         * @ORM\GeneratedValue(strategy="IDENTITY")
         */
        private $id;

        /**
         * @var string
         *
         * @ORM\Column(name="name", type="string", length=255)
         */
        private $name;

        /**
         * @var boolean
         *
         * @ORM\Column(name="first_rate", type="boolean", options={"default":false})
         */
        private $first_rate = false;

        /**
         * @var string|null
         *
         * @ORM\Column(name="rate", type="decimal", precision=12, scale=2)
         */
        private $rate;

        /**
         * @var string|null
         *
         * @ORM\Column(name="price_min", type="decimal", precision=12, scale=2)
         */
        private $price_min;

        /**
         * @var string|null
         *
         * @ORM\Column(name="price_max", type="decimal", precision=12, scale=2)
         */
        private $price_max;

        /**
         * @var boolean
         *
         * @ORM\Column(name="price_unlimited", type="boolean", options={"default":false})
         */
        private $price_unlimited = false;

        /**
         * @var \Eccube\Entity\AmazonRule
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\AmazonRule", inversedBy="AmazonRates")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="rule_id", referencedColumnName="id")
         * })
         */
        private $AmazonRule;

        public function __clone()
        {
            $this->id = null;
        }
                
        /**
         * Get id.
         *
         * @return int
         */
        public function getId()
        {
            return $this->id;
        }

        /**
         * Set name.
         *
         * @param string $name
         *
         * @return AmazonRate
         */
        public function setName($name)
        {
            $this->name = $name;

            return $this;
        }

        /**
         * Get name.
         *
         * @return string
         */
        public function getName()
        {
            return $this->name;
        }

        /**
         * Set firstRate.
         *
         * @param boolean $firstRate
         *
         * @return AmazonRate
         */
        public function setFirstRate($firstRate)
        {
            $this->first_rate = $firstRate;

            return $this;
        }

        /**
         * Get firstRate.
         *
         * @return boolean
         */
        public function isFirstRate()
        {
            return $this->first_rate;
        }

        /**
         * Set rate.
         *
         * @param string|null $rate
         *
         * @return AmazonRate
         */
        public function setRate($rate = null)
        {
            $this->rate = $rate;

            return $this;
        }

        /**
         * Get rate.
         *
         * @return string|null
         */
        public function getRate()
        {
            return $this->rate;
        }

        /**
         * Set priceUnlimited.
         *
         * @param boolean $priceUnlimited
         *
         * @return AmazonRate
         */
        public function setPriceUnlimited($priceUnlimited)
        {
            $this->price_unlimited = $priceUnlimited;

            return $this;
        }

        /**
         * Get priceUnlimited.
         *
         * @return boolean
         */
        public function isPriceUnlimited()
        {
            return $this->price_unlimited;
        }

        /**
         * Set price_min.
         *
         * @param string|null $price_min
         *
         * @return AmazonRate
         */
        public function setPriceMin($price_min = null)
        {
            $this->price_min = $price_min;

            return $this;
        }

        /**
         * Get price_min.
         *
         * @return string|null
         */
        public function getPriceMin()
        {
            return $this->price_min;
        }

        /**
         * Set price_max.
         *
         * @param string|null $price_max
         *
         * @return AmazonRate
         */
        public function setPriceMax($price_max = null)
        {
            $this->price_max = $price_max;

            return $this;
        }

        /**
         * Get price_max.
         *
         * @return string|null
         */
        public function getPriceMax()
        {
            return $this->price_max;
        }

        /**
         * Set amazonRule.
         *
         * @param \Eccube\Entity\AmazonRule|null $amazonRule
         *
         * @return AmazonRate
         */
        public function setAmazonRule(\Eccube\Entity\AmazonRule $amazonRule = null)
        {
            $this->AmazonRule = $amazonRule;

            return $this;
        }

        /**
         * Get amazonRule.
         *
         * @return \Eccube\Entity\AmazonRule|null
         */
        public function getAmazonRule()
        {
            return $this->AmazonRule;
        }
    }
}
