<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Entity;

use Doctrine\ORM\Mapping as ORM;

if (!class_exists('\Eccube\Entity\CartItem')) {
    /**
     * CartItem
     *
     * @ORM\Table(name="dtb_cart_item")
     * @ORM\InheritanceType("SINGLE_TABLE")
     * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
     * @ORM\HasLifecycleCallbacks()
     * @ORM\Entity(repositoryClass="Eccube\Repository\CartItemRepository")
     */
    class CartItem extends \Eccube\Entity\AbstractEntity implements ItemInterface
    {
        use PointRateTrait;

        /**
         * @var integer
         *
         * @ORM\Column(name="id", type="integer", options={"unsigned":true})
         * @ORM\Id
         * @ORM\GeneratedValue(strategy="IDENTITY")
         */
        private $id;

        /**
         * @var string
         *
         * @ORM\Column(name="price", type="decimal", precision=12, scale=2, options={"default":0})
         */
        private $price = 0;

        /**
         * @var string
         *
         * @ORM\Column(name="price_change", type="decimal", precision=12, scale=2, options={"default":0})
         */
        private $price_change = 0;

        /**
         * @var string
         *
         * @ORM\Column(name="price_org", type="decimal", precision=12, scale=2, options={"default":0})
         */
        private $price_org = 0;

        /**
         * @var string|null
         *
         * @ORM\Column(name="stock_org", type="decimal", precision=10, scale=0, nullable=true)
         */
        private $stock_org = 0;


        /**
         * @var string
         *
         * @ORM\Column(name="quantity", type="decimal", precision=10, scale=0, options={"default":0})
         */
        private $quantity = 0;

        /**
         * @var \Eccube\Entity\ProductClass
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\ProductClass")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="product_class_id", referencedColumnName="id")
         * })
         */
        private $ProductClass;

        /**
         * @var \Eccube\Entity\Master\AmazonGiftType
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Master\AmazonGiftType")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="gift_type_id", referencedColumnName="id")
         * })
         */
        private $AmazonGiftType;

        /**
         * @var string
         *
         * @ORM\Column(name="gift_key", type="string", nullable=true)
         */
        private $gift_key;

        /**
         * @var \DateTime
         *
         * @ORM\Column(name="valid_date", type="datetimetz")
         */
        private $valid_date;

        /**
         * @var \Eccube\Entity\Master\RankType
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Master\RankType")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="rank_type_id", referencedColumnName="id")
         * })
         */
        private $RankType;

        /**
         * @var \Doctrine\Common\Collections\Collection
         */
        private $ProductRanks;

        /**
         * @var \Doctrine\Common\Collections\Collection
         */
        private $ProductRank2s;

        /**
         * @var \Doctrine\Common\Collections\Collection|ProductRankOption[]
         *
         * @ORM\OneToMany(targetEntity="Eccube\Entity\ProductRankOption", mappedBy="CartItem", cascade={"persist","remove"})
         */
        private $ProductRankOptions;

        /**
         * @var \Eccube\Entity\Cart
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Cart", inversedBy="CartItems")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="cart_id", referencedColumnName="id", onDelete="CASCADE")
         * })
         */
        private $Cart;

        /**
         * sessionのシリアライズのために使われる
         *
         * @var int
         */
        private $product_class_id;

        public function __sleep()
        {
            return ['product_class_id', 'price', 'quantity'];
        }

        public function __construct()
        {
            $this->ProductRankOptions = new \Doctrine\Common\Collections\ArrayCollection();
            $this->ProductRanks = new \Doctrine\Common\Collections\ArrayCollection();
            $this->ProductRank2s = new \Doctrine\Common\Collections\ArrayCollection();
        }

        /**
         * @return int
         */
        public function getId()
        {
            return $this->id;
        }
        
        /**
         * @param  integer  $price
         *
         * @return CartItem
         */
        public function setPrice($price)
        {
            $this->price = $price;

            return $this;
        }

        /**
         * @return string
         */
        public function getPrice()
        {
            return $this->price;
        }

        /**
         * @param  integer  $price_change
         *
         * @return CartItem
         */
        public function setPriceChange($price_change)
        {
            $this->price_change = $price_change;

            return $this;
        }

        /**
         * @return string
         */
        public function getPriceChange()
        {
            return $this->price_change;
        }


        /**
         * @param  integer  $price_org
         *
         * @return CartItem
         */
        public function setPriceOrg($price_org)
        {
            $this->price_org = $price_org;

            return $this;
        }

        /**
         * @return string
         */
        public function getPriceOrg()
        {
            return $this->price_org;
        }

        /**
         * Set stock_org.
         *
         * @param string $stock_org
         *
         * @return OrderItem
         */
        public function setStockOrg($stock_org)
        {
            $this->stock_org = $stock_org;

            return $this;
        }

        /**
         * Get stock_org.
         *
         * @return string
         */
        public function getStockOrg()
        {
            return $this->stock_org;
        }

        /**
         * @param  integer  $quantity
         *
         * @return CartItem
         */
        public function setQuantity($quantity)
        {
            $this->quantity = $quantity;

            return $this;
        }

        /**
         * @return string
         */
        public function getQuantity()
        {
            return $this->quantity;
        }

        /**
         * @return integer
         */
        public function getTotalPrice()
        {
            return $this->getPrice() * $this->getQuantity();
        }

        /**
         * 商品明細かどうか.
         *
         * @return boolean 商品明細の場合 true
         */
        public function isProduct()
        {
            return true;
        }

        /**
         * 送料明細かどうか.
         *
         * @return boolean 送料明細の場合 true
         */
        public function isDeliveryFee()
        {
            return false;
        }

        /**
         * 手数料明細かどうか.
         *
         * @return boolean 手数料明細の場合 true
         */
        public function isCharge()
        {
            return false;
        }

        /**
         * 値引き明細かどうか.
         *
         * @return boolean 値引き明細の場合 true
         */
        public function isDiscount()
        {
            return false;
        }

        /**
         * 税額明細かどうか.
         *
         * @return boolean 税額明細の場合 true
         */
        public function isTax()
        {
            return false;
        }

        /**
         * ポイント明細かどうか.
         *
         * @return boolean ポイント明細の場合 true
         */
        public function isPoint()
        {
            return false;
        }

        public function getOrderItemType()
        {
            // TODO OrderItemType::PRODUCT
            $ItemType = new \Eccube\Entity\Master\OrderItemType();

            return $ItemType;
        }

        /**
         * Set RankType.
         *
         * @param \Eccube\Entity\Master\RankType|null $RankType
         *
         * @return CartItem
         */
        public function setRankType(\Eccube\Entity\Master\RankType $RankType = null)
        {
            $this->RankType = $RankType;

            return $this;
        }

        /**
         * Get RankType.
         *
         * @return \Eccube\Entity\Master\RankType|null
         */
        public function getRankType()
        {
            return $this->RankType;
        }

        /**
         * Set AmazonGiftType.
         *
         * @param \Eccube\Entity\Master\AmazonGiftType|null $AmazonGiftType
         *
         * @return CartItem
         */
        public function setAmazonGiftType(\Eccube\Entity\Master\AmazonGiftType $AmazonGiftType = null)
        {
            $this->AmazonGiftType = $AmazonGiftType;

            return $this;
        }

        /**
         * Get AmazonGiftType.
         *
         * @return \Eccube\Entity\Master\AmazonGiftType|null
         */
        public function getAmazonGiftType()
        {
            return $this->AmazonGiftType;
        }

        /**
         * Set giftKey.
         *
         * @param string $giftKey
         *
         * @return CartItem
         */
        public function setGiftKey($giftKey)
        {
            $this->gift_key = $giftKey;

            return $this;
        }

        /**
         * Get giftKey.
         *
         * @return string
         */
        public function getGiftKey()
        {
            return $this->gift_key;
        }

        /**
         * Set validDate.
         *
         * @param \DateTime $validDate
         *
         * @return CartItem
         */
        public function setValidDate($validDate)
        {
            $this->valid_date = $validDate;

            return $this;
        }

        /**
         * Get validDate.
         *
         * @return \DateTime
         */
        public function getValidDate()
        {
            return $this->valid_date;
        }

        /**
         * @param ProductClass $ProductClass
         *
         * @return $this
         */
        public function setProductClass(ProductClass $ProductClass)
        {
            $this->ProductClass = $ProductClass;

            $this->product_class_id = is_object($ProductClass) ?
            $ProductClass->getId() : null;

            return $this;
        }

        /**
         * @return ProductClass
         */
        public function getProductClass()
        {
            return $this->ProductClass;
        }

        /**
         * @return int|null
         */
        public function getProductClassId()
        {
            return $this->product_class_id;
        }

        public function getPriceIncTax()
        {
            // TODO ItemInterfaceに追加, Cart::priceは税込み金額が入っているので,フィールドを分ける必要がある
            return $this->price;
        }


        /**
         * Add ProductRank.
         *
         * @param \Eccube\Entity\ProductRank $ProductRank
         *
         * @return CartItem
         */
        public function addProductRank(\Eccube\Entity\ProductRank $ProductRank)
        {
            $this->ProductRanks[] = $ProductRank;

            return $this;
        }

        /**
         * Remove ProductRank.
         *
         * @param \Eccube\Entity\ProductRank $ProductRank
         *
         * @return boolean TRUE if this collection contained the specified element, FALSE otherwise.
         */
        public function removeProductRank(\Eccube\Entity\ProductRank $ProductRank)
        {
            return $this->ProductRanks->removeElement($ProductRank);
        }

        /**
         * Get ProductRank.
         *
         * @return \Doctrine\Common\Collections\Collection
         */
        public function getProductRanks()
        {
            return $this->ProductRanks;
        }

        /**
         * Add ProductRank.
         *
         * @param \Eccube\Entity\ProductRank $ProductRank
         *
         * @return CartItem
         */
        public function addProductRank2(\Eccube\Entity\ProductRank $ProductRank)
        {
            $this->ProductRank2s[] = $ProductRank;

            return $this;
        }

        /**
         * Remove ProductRank.
         *
         * @param \Eccube\Entity\ProductRank $ProductRank
         *
         * @return boolean TRUE if this collection contained the specified element, FALSE otherwise.
         */
        public function removeProductRank2(\Eccube\Entity\ProductRank $ProductRank)
        {
            return $this->ProductRank2s->removeElement($ProductRank);
        }

        /**
         * Get ProductRank.
         *
         * @return \Doctrine\Common\Collections\Collection
         */
        public function getProductRank2s()
        {
            return $this->ProductRank2s;
        }

        /**
         * Add ProductRankOption.
         *
         * @param \Eccube\Entity\ProductRankOption $ProductRankOption
         *
         * @return CartItem
         */
        public function addProductRankOption(\Eccube\Entity\ProductRankOption $ProductRankOption)
        {
            $this->ProductRankOptions[] = $ProductRankOption;

            return $this;
        }

        /**
         * Remove ProductRankOption.
         *
         * @param \Eccube\Entity\ProductRankOption $ProductRankOption
         *
         * @return boolean TRUE if this collection contained the specified element, FALSE otherwise.
         */
        public function removeProductRankOption(\Eccube\Entity\ProductRankOption $ProductRankOption)
        {
            return $this->ProductRankOptions->removeElement($ProductRankOption);
        }

        /**
         * Get ProductRankOption.
         *
         * @return \Doctrine\Common\Collections\Collection
         */
        public function getProductRankOptions()
        {
            return $this->ProductRankOptions;
        }

        /**
         * @return Cart
         */
        public function getCart()
        {
            return $this->Cart;
        }

        /**
         * @param Cart $Cart
         */
        public function setCart(Cart $Cart)
        {
            $this->Cart = $Cart;
        }

        /**
         * @var \DateTime
         *
         * @ORM\Column(name="add_date", type="datetimetz")
         */
        private $add_date;

        /**
         * Set createDate.
         *
         * @param \DateTime $add_date
         *
         * @return CartItem
         */
        public function setAddDate($add_date)
        {
            $this->add_date = $add_date;

            return $this;
        }

        /**
         * Get add_date.
         *
         * @return \DateTime
         */
        public function getAddDate()
        {
            return $this->add_date;
        }
    }
}
