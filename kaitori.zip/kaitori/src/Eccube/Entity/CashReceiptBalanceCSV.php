<?php

namespace Eccube\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * プログラム名 ： CashReceiptBalanceCSV
 * 概　　要     ： 売上入金残高CSV用エンティティ
 * 作　　成     ： 2021/08/30 CNC
 *
 */
class CashReceiptBalanceCSV extends AbstractEntity
{

    /**
     * SalesDepositBalance constructor.
     */
    public function __construct()
    {
    }

    /**
     * @var string
     *
     */
    private $salesVoucherNo;

    /**
     * @var \DateTime
     *
     */
    private $salesDate;

    /**
     * @var string
     *
     */
    private $customerName;

    /**
     * @var string
     *
     */
    private $salesMoneyTotalAmount;

    /**
     * @var string
     *
     */
    private $grossProfitTotalAmount;

    /**
     * @var string|null
     *
     */
    private $personnelName;

    /**
     * @var string
     *
     */
    private $depositAmount;


    /**
     * @var string
     *
     */
    private $depositNotAmount;

    /**
     * @var string|null
     *
     */
    private $returnsPrice;

    /**
     * @var \DateTime|null
     *
     */
    private $depositDate;

    /**
     * @var string|null
     *
     */
    private $depositUserName;

    /**
     * @var string|null
     *
     */
    private $personnelMemo;

    /**
     * @return string
     */
    public function getSalesVoucherNo(): string
    {
        return $this->salesVoucherNo;
    }

    /**
     * @param string $salesVoucherNo
     */
    public function setSalesVoucherNo(string $salesVoucherNo): void
    {
        $this->salesVoucherNo = $salesVoucherNo;
    }

    /**
     * @return \DateTime
     */
    public function getSalesDate(): \DateTime
    {
        return $this->salesDate;
    }

    /**
     * @param \DateTime $salesDate
     */
    public function setSalesDate(\DateTime $salesDate): void
    {
        $this->salesDate = $salesDate;
    }

    /**
     * @return string
     */
    public function getCustomerName(): string
    {
        return $this->customerName;
    }

    /**
     * @param string $customerName
     */
    public function setCustomerName(string $customerName): void
    {
        $this->customerName = $customerName;
    }

    /**
     * @return string
     */
    public function getSalesMoneyTotalAmount(): string
    {
        return $this->salesMoneyTotalAmount;
    }

    /**
     * @param string $salesMoneyTotalAmount
     */
    public function setSalesMoneyTotalAmount(string $salesMoneyTotalAmount): void
    {
        $this->salesMoneyTotalAmount = $salesMoneyTotalAmount;
    }

    /**
     * @return string
     */
    public function getGrossProfitTotalAmount(): string
    {
        return $this->grossProfitTotalAmount;
    }

    /**
     * @param string $grossProfitTotalAmount
     */
    public function setGrossProfitTotalAmount(string $grossProfitTotalAmount): void
    {
        $this->grossProfitTotalAmount = $grossProfitTotalAmount;
    }

    /**
     * @return string|null
     */
    public function getPersonnelName(): ?string
    {
        return $this->personnelName;
    }

    /**
     * @param string|null $personnelName
     */
    public function setPersonnelName(?string $personnelName): void
    {
        $this->personnelName = $personnelName;
    }

    /**
     * @return string
     */
    public function getDepositAmount(): string
    {
        return $this->depositAmount;
    }

    /**
     * @param string $depositAmount
     */
    public function setDepositAmount(string $depositAmount): void
    {
        $this->depositAmount = $depositAmount;
    }

    /**
     * @return string
     */
    public function getDepositNotAmount(): string
    {
        return $this->depositNotAmount;
    }

    /**
     * @param string $depositNotAmount
     */
    public function setDepositNotAmount(string $depositNotAmount): void
    {
        $this->depositNotAmount = $depositNotAmount;
    }

    /**
     * @return string|null
     */
    public function getReturnsPrice(): ?string
    {
        return $this->returnsPrice;
    }

    /**
     * @param string|null $returnsPrice
     */
    public function setReturnsPrice(?string $returnsPrice): void
    {
        $this->returnsPrice = $returnsPrice;
    }

    /**
     * @return \DateTime|null
     */
    public function getDepositDate(): ?\DateTime
    {
        return $this->depositDate;
    }

    /**
     * @param \DateTime|null $depositDate
     */
    public function setDepositDate(?\DateTime $depositDate): void
    {
        $this->depositDate = $depositDate;
    }

    /**
     * @return string|null
     */
    public function getDepositUserName(): ?string
    {
        return $this->depositUserName;
    }

    /**
     * @param string|null $depositUserName
     */
    public function setDepositUserName(?string $depositUserName): void
    {
        $this->depositUserName = $depositUserName;
    }

    /**
     * @return string|null
     */
    public function getPersonnelMemo(): ?string
    {
        return $this->personnelMemo;
    }

    /**
     * @param string|null $personnelMemo
     */
    public function setPersonnelMemo(?string $personnelMemo): void
    {
        $this->personnelMemo = $personnelMemo;
    }


}
