<?php

namespace Eccube\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * CustomerMst
 *
 * @ORM\Table(name="mtb_customer_mst", indexes={@ORM\Index(name="FK_bank_id_customer", columns={"bank_id"}), @ORM\Index(name="FK_member_id_customer", columns={"member_id"}), @ORM\Index(name="FK_pref_id_customer", columns={"pref_id"})})
 * @ORM\InheritanceType("SINGLE_TABLE")
 * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
 * @ORM\HasLifecycleCallbacks()
 * @ORM\Entity(repositoryClass="Eccube\Repository\CustomerMstRepository")
 */
class CustomerMst extends \Eccube\Entity\AbstractEntity
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="smallint", nullable=false, options={"unsigned"=true,"comment"="ID"})
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_code", type="string", length=255, nullable=true, options={"comment"="得意先コード"})
     */
    private $customerCode;

    /**
     * @var string
     *
     * @ORM\Column(name="customer_name", type="string", length=255, nullable=false, options={"comment"="得意先名"})
     */
    private $customerName;

    /**
     * @var string|null
     *
     * @ORM\Column(name="kana", type="string", length=255, nullable=true, options={"comment"="フリガナ"})
     */
    private $kana;

    /**
     * @var string|null
     *
     * @ORM\Column(name="postal_code", type="string", length=8, nullable=true, options={"comment"="郵便番号"})
     */
    private $postalCode;

    /**
     * @var string|null
     *
     * @ORM\Column(name="nation", type="string", length=255, nullable=true, options={"comment"="国家"})
     */
    private $nation;

    /**
     * @var string|null
     *
     * @ORM\Column(name="addr01", type="string", length=255, nullable=true, options={"comment"="市区町村"})
     */
    private $addr01;

    /**
     * @var string|null
     *
     * @ORM\Column(name="addr02", type="string", length=255, nullable=true, options={"comment"="住所"})
     */
    private $addr02;

    /**
     * @var string|null
     *
     * @ORM\Column(name="phone_number", type="string", length=14, nullable=true, options={"comment"="電話番号"})
     */
    private $phoneNumber;

    /**
     * @var string|null
     *
     * @ORM\Column(name="fax", type="string", length=14, nullable=true, options={"comment"="FAX"})
     */
    private $fax;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_as_name", type="string", length=255, nullable=true, options={"comment"="得意先別名"})
     */
    private $customerAsName;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_name_01", type="string", length=255, nullable=true, options={"comment"="得意先担当者情報１_担当名"})
     */
    private $customerName01;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_belonging_01", type="string", length=255, nullable=true, options={"comment"="得意先担当者情報１_所属"})
     */
    private $customerBelonging01;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_cell_phone_01", type="string", length=14, nullable=true, options={"comment"="得意先担当者情報１_携帯電話"})
     */
    private $customerCellPhone01;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_url_01", type="string", length=255, nullable=true, options={"comment"="得意先担当者情報１_URL"})
     */
    private $customerUrl01;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_email_01", type="string", length=255, nullable=true, options={"comment"="得意先担当者情報１_Email"})
     */
    private $customerEmail01;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_name_02", type="string", length=255, nullable=true, options={"comment"="得意先担当者情報２_担当名"})
     */
    private $customerName02;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_belonging_02", type="string", length=255, nullable=true, options={"comment"="得意先担当者情報２_所属"})
     */
    private $customerBelonging02;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_cell_phone_02", type="string", length=14, nullable=true, options={"comment"="得意先担当者情報２_携帯電話"})
     */
    private $customerCellPhone02;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_url_02", type="string", length=255, nullable=true, options={"comment"="得意先担当者情報２_URL"})
     */
    private $customerUrl02;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_email_02", type="string", length=255, nullable=true, options={"comment"="得意先担当者情報２_Email"})
     */
    private $customerEmail02;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_name_03", type="string", length=255, nullable=true, options={"comment"="得意先担当者情報３_担当名"})
     */
    private $customerName03;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_belonging_03", type="string", length=255, nullable=true, options={"comment"="得意先担当者情報３_所属"})
     */
    private $customerBelonging03;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_cell_phone_03", type="string", length=14, nullable=true, options={"comment"="得意先担当者情報３_携帯電話"})
     */
    private $customerCellPhone03;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_url_03", type="string", length=255, nullable=true, options={"comment"="得意先担当者情報３_URL"})
     */
    private $customerUrl03;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_email_03", type="string", length=255, nullable=true, options={"comment"="得意先担当者情報３_Email"})
     */
    private $customerEmail03;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_customer_name_04", type="string", length=255, nullable=true, options={"comment"="得意先担当者情報４_担当名"})
     */
    private $customerName04;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_belonging_04", type="string", length=255, nullable=true, options={"comment"="得意先担当者情報４_所属"})
     */
    private $customerBelonging04;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_cell_phone_04", type="string", length=14, nullable=true, options={"comment"="得意先担当者情報４_携帯電話"})
     */
    private $customerCellPhone04;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_url_04", type="string", length=255, nullable=true, options={"comment"="得意先担当者情報４_URL"})
     */
    private $customerUrl04;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_email_04", type="string", length=255, nullable=true, options={"comment"="得意先担当者情報４_Email"})
     */
    private $customerEmail04;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_name_05", type="string", length=255, nullable=true, options={"comment"="得意先担当者情報５_担当名"})
     */
    private $customerName05;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_belonging_05", type="string", length=255, nullable=true, options={"comment"="得意先担当者情報５_所属"})
     */
    private $customerBelonging05;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_cell_phone_05", type="string", length=14, nullable=true, options={"comment"="得意先担当者情報５_携帯電話"})
     */
    private $customerCellPhone05;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_url_05", type="string", length=255, nullable=true, options={"comment"="得意先担当者情報５_URL"})
     */
    private $customerUrl05;

    /**
     * @var string|null
     *
     * @ORM\Column(name="customer_email_05", type="string", length=255, nullable=true, options={"comment"="得意先担当者情報５_Email"})
     */
    private $customerEmail05;

    /**
     * @var int
     *
     * @ORM\Column(name="sort_no", type="smallint", nullable=false, options={"unsigned"=true,"comment"="ソート順"})
     */
    private $sortNo;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="create_date", type="datetime", nullable=false, options={"comment"="作成日時"})
     */
    private $createDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="update_date", type="datetime", nullable=false, options={"comment"="更新日時"})
     */
    private $updateDate;

    /**
     * @var \Eccube\Entity\Bank
     *
     * @ORM\ManyToOne(targetEntity="Eccube\Entity\Bank")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="bank_id", referencedColumnName="id")
     * })
     */
    private $bankId;

    /**
     * @var \Eccube\Entity\Member
     *
     * @ORM\ManyToOne(targetEntity="Eccube\Entity\Member")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="member_id", referencedColumnName="id")
     * })
     */
    private $member;

    /**
     * @var  \Eccube\Entity\Master\Pref
     *
     * @ORM\ManyToOne(targetEntity="Eccube\Entity\Master\Pref")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="pref_id", referencedColumnName="id")
     * })
     */
    private $pref;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId(int $id)
    {
        $this->id = $id;
    }


    /**
     * @return string|null
     */
    public function getCustomerCode()
    {
        return $this->customerCode;
    }

    /**
     * @param string|null $customerCode
     */
    public function setCustomerCode(?string $customerCode)
    {
        $this->customerCode = $customerCode;
    }

    /**
     * @return string
     */
    public function getCustomerName()
    {
        return $this->customerName;
    }

    /**
     * @param string $customerName
     */
    public function setCustomerName(?string $customerName)
    {
        $this->customerName = $customerName;
    }

    /**
     * @return string|null
     */
    public function getKana()
    {
        return $this->kana;
    }

    /**
     * @param string|null $kana
     */
    public function setKana(?string $kana)
    {
        $this->kana = $kana;
    }

    /**
     * @return string|null
     */
    public function getPostalCode()
    {
        return $this->postalCode;
    }

    /**
     * @param string|null $postalCode
     */
    public function setPostalCode(?string $postalCode)
    {
        $this->postalCode = $postalCode;
    }

    /**
     * @return string|null
     */
    public function getNation()
    {
        return $this->nation;
    }

    /**
     * @param string|null $nation
     */
    public function setNation(?string $nation)
    {
        $this->nation = $nation;
    }

    /**
     * @return string|null
     */
    public function getAddr01()
    {
        return $this->addr01;
    }

    /**
     * @param string|null $addr01
     */
    public function setAddr01(?string $addr01)
    {
        $this->addr01 = $addr01;
    }

    /**
     * @return string|null
     */
    public function getAddr02()
    {
        return $this->addr02;
    }

    /**
     * @param string|null $addr02
     */
    public function setAddr02(?string $addr02)
    {
        $this->addr02 = $addr02;
    }

    /**
     * @return string|null
     */
    public function getPhoneNumber()
    {
        return $this->phoneNumber;
    }

    /**
     * @param string|null $phoneNumber
     */
    public function setPhoneNumber(?string $phoneNumber)
    {
        $this->phoneNumber = $phoneNumber;
    }

    /**
     * @return string|null
     */
    public function getFax()
    {
        return $this->fax;
    }

    /**
     * @param string|null $fax
     */
    public function setFax(?string $fax): void
    {
        $this->fax = $fax;
    }

    /**
     * @return string|null
     */
    public function getCustomerAsName()
    {
        return $this->customerAsName;
    }

    /**
     * @param string|null $customerAsName
     */
    public function setCustomerAsName(?string $customerAsName)
    {
        $this->customerAsName = $customerAsName;
    }

    /**
     * @return string|null
     */
    public function getCustomerName01()
    {
        return $this->customerName01;
    }

    /**
     * @param string|null $customerName01
     */
    public function setCustomerName01(?string $customerName01)
    {
        $this->customerName01 = $customerName01;
    }

    /**
     * @return string|null
     */
    public function getCustomerBelonging01()
    {
        return $this->customerBelonging01;
    }

    /**
     * @param string|null $customerBelonging01
     */
    public function setCustomerBelonging01(?string $customerBelonging01)
    {
        $this->customerBelonging01 = $customerBelonging01;
    }

    /**
     * @return string|null
     */
    public function getCustomerCellPhone01()
    {
        return $this->customerCellPhone01;
    }

    /**
     * @param string|null $customerCellPhone01
     */
    public function setCustomerCellPhone01(?string $customerCellPhone01)
    {
        $this->customerCellPhone01 = $customerCellPhone01;
    }

    /**
     * @return string|null
     */
    public function getCustomerUrl01()
    {
        return $this->customerUrl01;
    }

    /**
     * @param string|null $customerUrl01
     */
    public function setCustomerUrl01(?string $customerUrl01)
    {
        $this->customerUrl01 = $customerUrl01;
    }

    /**
     * @return string|null
     */
    public function getCustomerEmail01()
    {
        return $this->customerEmail01;
    }

    /**
     * @param string|null $customerEmail01
     */
    public function setCustomerEmail01(?string $customerEmail01)
    {
        $this->customerEmail01 = $customerEmail01;
    }

    /**
     * @return string|null
     */
    public function getCustomerName02()
    {
        return $this->customerName02;
    }

    /**
     * @param string|null $customerName02
     */
    public function setCustomerName02(?string $customerName02)
    {
        $this->customerName02 = $customerName02;
    }

    /**
     * @return string|null
     */
    public function getCustomerBelonging02()
    {
        return $this->customerBelonging02;
    }

    /**
     * @param string|null $customerBelonging02
     */
    public function setCustomerBelonging02(?string $customerBelonging02)
    {
        $this->customerBelonging02 = $customerBelonging02;
    }

    /**
     * @return string|null
     */
    public function getCustomerCellPhone02()
    {
        return $this->customerCellPhone02;
    }

    /**
     * @param string|null $customerCellPhone02
     */
    public function setCustomerCellPhone02(?string $customerCellPhone02)
    {
        $this->customerCellPhone02 = $customerCellPhone02;
    }

    /**
     * @return string|null
     */
    public function getCustomerUrl02()
    {
        return $this->customerUrl02;
    }

    /**
     * @param string|null $customerUrl02
     */
    public function setCustomerUrl02(?string $customerUrl02)
    {
        $this->customerUrl02 = $customerUrl02;
    }

    /**
     * @return string|null
     */
    public function getCustomerEmail02()
    {
        return $this->customerEmail02;
    }

    /**
     * @param string|null $customerEmail02
     */
    public function setCustomerEmail02(?string $customerEmail02)
    {
        $this->customerEmail02 = $customerEmail02;
    }

    /**
     * @return string|null
     */
    public function getCustomerName03()
    {
        return $this->customerName03;
    }

    /**
     * @param string|null $customerName03
     */
    public function setCustomerName03(?string $customerName03)
    {
        $this->customerName03 = $customerName03;
    }

    /**
     * @return string|null
     */
    public function getCustomerBelonging03()
    {
        return $this->customerBelonging03;
    }

    /**
     * @param string|null $customerBelonging03
     */
    public function setCustomerBelonging03(?string $customerBelonging03)
    {
        $this->customerBelonging03 = $customerBelonging03;
    }

    /**
     * @return string|null
     */
    public function getCustomerCellPhone03()
    {
        return $this->customerCellPhone03;
    }

    /**
     * @param string|null $customerCellPhone03
     */
    public function setCustomerCellPhone03(?string $customerCellPhone03)
    {
        $this->customerCellPhone03 = $customerCellPhone03;
    }

    /**
     * @return string|null
     */
    public function getCustomerUrl03()
    {
        return $this->customerUrl03;
    }

    /**
     * @param string|null $customerUrl03
     */
    public function setCustomerUrl03(?string $customerUrl03)
    {
        $this->customerUrl03 = $customerUrl03;
    }

    /**
     * @return string|null
     */
    public function getCustomerEmail03()
    {
        return $this->customerEmail03;
    }

    /**
     * @param string|null $customerEmail03
     */
    public function setCustomerEmail03(?string $customerEmail03)
    {
        $this->customerEmail03 = $customerEmail03;
    }

    /**
     * @return string|null
     */
    public function getCustomerName04()
    {
        return $this->customerName04;
    }

    /**
     * @param string|null $customerName04
     */
    public function setCustomerName04(?string $customerName04)
    {
        $this->customerName04 = $customerName04;
    }

    /**
     * @return string|null
     */
    public function getCustomerBelonging04()
    {
        return $this->customerBelonging04;
    }

    /**
     * @param string|null $customerBelonging04
     */
    public function setCustomerBelonging04(?string $customerBelonging04)
    {
        $this->customerBelonging04 = $customerBelonging04;
    }

    /**
     * @return string|null
     */
    public function getCustomerCellPhone04()
    {
        return $this->customerCellPhone04;
    }

    /**
     * @param string|null $customerCellPhone04
     */
    public function setCustomerCellPhone04(?string $customerCellPhone04)
    {
        $this->customerCellPhone04 = $customerCellPhone04;
    }

    /**
     * @return string|null
     */
    public function getCustomerUrl04()
    {
        return $this->customerUrl04;
    }

    /**
     * @param string|null $customerUrl04
     */
    public function setCustomerUrl04(?string $customerUrl04)
    {
        $this->customerUrl04 = $customerUrl04;
    }

    /**
     * @return string|null
     */
    public function getCustomerEmail04()
    {
        return $this->customerEmail04;
    }

    /**
     * @param string|null $customerEmail04
     */
    public function setCustomerEmail04(?string $customerEmail04)
    {
        $this->customerEmail04 = $customerEmail04;
    }

    /**
     * @return string|null
     */
    public function getCustomerName05()
    {
        return $this->customerName05;
    }

    /**
     * @param string|null $customerName05
     */
    public function setCustomerName05(?string $customerName05)
    {
        $this->customerName05 = $customerName05;
    }

    /**
     * @return string|null
     */
    public function getCustomerBelonging05()
    {
        return $this->customerBelonging05;
    }

    /**
     * @param string|null $customerBelonging05
     */
    public function setCustomerBelonging05(?string $customerBelonging05)
    {
        $this->customerBelonging05 = $customerBelonging05;
    }

    /**
     * @return string|null
     */
    public function getCustomerCellPhone05()
    {
        return $this->customerCellPhone05;
    }

    /**
     * @param string|null $customerCellPhone05
     */
    public function setCustomerCellPhone05(?string $customerCellPhone05)
    {
        $this->customerCellPhone05 = $customerCellPhone05;
    }

    /**
     * @return string|null
     */
    public function getCustomerUrl05()
    {
        return $this->customerUrl05;
    }

    /**
     * @param string|null $customerUrl05
     */
    public function setCustomerUrl05(?string $customerUrl05)
    {
        $this->customerUrl05 = $customerUrl05;
    }

    /**
     * @return string|null
     */
    public function getCustomerEmail05()
    {
        return $this->customerEmail05;
    }

    /**
     * @param string|null $customerEmail05
     */
    public function setCustomerEmail05(?string $customerEmail05)
    {
        $this->customerEmail05 = $customerEmail05;
    }

    /**
     * @return int
     */
    public function getSortNo()
    {
        return $this->sortNo;
    }

    /**
     * @param int $sortNo
     */
    public function setSortNo(int $sortNo)
    {
        $this->sortNo = $sortNo;
    }

    /**
     * @return \DateTime
     */
    public function getCreateDate()
    {
        return $this->createDate;
    }

    /**
     * @param \DateTime $createDate
     */
    public function setCreateDate(\DateTime $createDate)
    {
        $this->createDate = $createDate;
    }

    /**
     * @return \DateTime
     */
    public function getUpdateDate()
    {
        return $this->updateDate;
    }

    /**
     * @param \DateTime $updateDate
     */
    public function setUpdateDate(\DateTime $updateDate)
    {
        $this->updateDate = $updateDate;
    }

    /**
     * @return \Eccube\Entity\Bank
     */
    public function getBankId()
    {
        return $this->bankId;
    }

    /**
     * @param \Bank $bankId
     */
    public function setBankId(\Eccube\Entity\Bank $bankId= null)
    {
        $this->bankId = $bankId;
    }

    /**
     * @return \Eccube\Entity\Member
     */
    public function getMember()
    {
        return $this->member;
    }

    /**
     * @param \Eccube\Entity\Member $member
     */
    public function setMember(\Eccube\Entity\Member $member= null)
    {
        $this->member = $member;
    }


    /**
     * @return \Eccube\Entity\Master\Pref
     */
    public function getPref()
    {
        return $this->pref;
    }

    /**
     * @param \Eccube\Entity\Master\Pref
     */
    public function setPref(\Eccube\Entity\Master\Pref $pref= null)
    {
        $this->pref = $pref;
    }
}
