<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Entity;

use Doctrine\ORM\Mapping as ORM;

if (!class_exists('\Eccube\Entity\AmazonRule')) {
    /**
     * AmazonRule
     *
     * @ORM\Table(name="dtb_amazon_rule")
     * @ORM\InheritanceType("SINGLE_TABLE")
     * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
     * @ORM\HasLifecycleCallbacks()
     * @ORM\Entity(repositoryClass="Eccube\Repository\AmazonRuleRepository")
     */
    class AmazonRule extends \Eccube\Entity\AbstractEntity
    {
        /**
         * @return string
         */
        public function __toString()
        {
            return (string) $this->getName();
        }

        /**
         * @var integer
         *
         * @ORM\Column(name="id", type="integer", options={"unsigned":true})
         * @ORM\Id
         * @ORM\GeneratedValue(strategy="IDENTITY")
         */
        private $id;

        /**
         * @var string
         *
         * @ORM\Column(name="name", type="string", length=255)
         */
        private $name;


        /**
         * @var \DateTime
         *
         * @ORM\Column(name="apply_date", type="datetimetz")
         */
        private $apply_date;

        /**
         * @var \Doctrine\Common\Collections\Collection
         *
         * @ORM\OneToMany(targetEntity="Eccube\Entity\AmazonRate", mappedBy="AmazonRule", cascade={"persist","remove"})
         */
        private $AmazonRates;

        /**
         * @var \DateTime
         *
         * @ORM\Column(name="create_date", type="datetimetz")
         */
        private $create_date;

        /**
         * @var \DateTime
         *
         * @ORM\Column(name="update_date", type="datetimetz")
         */
        private $update_date;

        /**
         * @var \Eccube\Entity\Member
         *
         * @ORM\ManyToOne(targetEntity="Eccube\Entity\Member")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="creator_id", referencedColumnName="id")
         * })
         */
        private $Creator;

        /**
         * Constructor
         */
        public function __construct()
        {
            $this->AmazonRates = new \Doctrine\Common\Collections\ArrayCollection();
        }

        public function __clone()
        {
            $this->id = null;
        }

        public function copy()
        {
            $AmazonRates = $this->getAmazonRates();
            $this->AmazonRates = new \Doctrine\Common\Collections\ArrayCollection();
            foreach ($AmazonRates as $AmazonRate) {
                $CloneAmazonRate = clone $AmazonRate;
                $this->addAmazonRate($CloneAmazonRate);
                $CloneAmazonRate->setAmazonRule($this);
            }

            return $this;
        }

        /**
         * Get id.
         *
         * @return int
         */
        public function getId()
        {
            return $this->id;
        }

        /**
         * Set name.
         *
         * @param string $name
         *
         * @return AmazonRule
         */
        public function setName($name)
        {
            $this->name = $name;

            return $this;
        }

        /**
         * Get name.
         *
         * @return string
         */
        public function getName()
        {
            return $this->name;
        }

        /**
         * Set applyDate.
         *
         * @param \DateTime $applyDate
         *
         * @return AmazonRule
         */
        public function setApplyDate($applyDate)
        {
            $this->apply_date = $applyDate;

            return $this;
        }

        /**
         * Get applyDate.
         *
         * @return \DateTime
         */
        public function getApplyDate()
        {
            return $this->apply_date;
        }

        /**
         * Set createDate.
         *
         * @param \DateTime $createDate
         *
         * @return AmazonRule
         */
        public function setCreateDate($createDate)
        {
            $this->create_date = $createDate;

            return $this;
        }

        /**
         * Get createDate.
         *
         * @return \DateTime
         */
        public function getCreateDate()
        {
            return $this->create_date;
        }

        /**
         * Set updateDate.
         *
         * @param \DateTime $updateDate
         *
         * @return AmazonRule
         */
        public function setUpdateDate($updateDate)
        {
            $this->update_date = $updateDate;

            return $this;
        }

        /**
         * Get updateDate.
         *
         * @return \DateTime
         */
        public function getUpdateDate()
        {
            return $this->update_date;
        }

        /**
         * Set creator.
         *
         * @param \Eccube\Entity\Member|null $creator
         *
         * @return AmazonRule
         */
        public function setCreator(\Eccube\Entity\Member $creator = null)
        {
            $this->Creator = $creator;

            return $this;
        }

        /**
         * Get creator.
         *
         * @return \Eccube\Entity\Member|null
         */
        public function getCreator()
        {
            return $this->Creator;
        }

        /**
         * Add amazonRate.
         *
         * @param \Eccube\Entity\AmazonRate $amazonRate
         *
         * @return AmazonRule
         */
        public function addAmazonRate(\Eccube\Entity\AmazonRate $amazonRate)
        {
            $this->AmazonRates[] = $amazonRate;

            return $this;
        }

        /**
         * Remove amazonRate.
         *
         * @param \Eccube\Entity\AmazonRate $amazonRate
         *
         * @return boolean TRUE if this collection contained the specified element, FALSE otherwise.
         */
        public function removeAmazonRate(\Eccube\Entity\AmazonRate $amazonRate)
        {
            return $this->AmazonRates->removeElement($amazonRate);
        }

        /**
         * Get AmazonRates.
         *
         * @return \Doctrine\Common\Collections\Collection
         */
        public function getAmazonRates()
        {
            return $this->AmazonRates;
        }

        protected function getSortedRates()
        {
            $rates = [];

            foreach ($this->getAmazonRates() as $rate) {
                if (!$rate->isFirstRate()) {
                    $rates[] = $rate;
                }
            }
    
            usort($rates, function (AmazonRate $rate1, AmazonRate $rate2) {
                return $rate1->getPriceMin() > $rate2->getPriceMin();
            });

            return $rates;
        }

        public function getFirstRate()
        {
            foreach ($this->getAmazonRates() as $rate) {
                if ($rate->isFirstRate()) {
                    return $rate;
                }
            }
            return null;
        }
        public function getRate1()
        {
            $rates = $this->getSortedRates();
            return $rates && count($rates) > 0 ? $rates[0] : null;
        }
        public function getRate2()
        {
            $rates = $this->getSortedRates();
            return $rates && count($rates) > 1 ? $rates[1] : null;
        }
        public function getRate3()
        {
            $rates = $this->getSortedRates();
            return $rates && count($rates) > 2 ? $rates[2] : null;
        }
    }
}
