<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Entity\Master;

use Doctrine\ORM\Mapping as ORM;

/**
 * Pref
 *
 * @ORM\Table(name="mtb_pref_group")
 * @ORM\InheritanceType("SINGLE_TABLE")
 * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
 * @ORM\HasLifecycleCallbacks()
 * @ORM\Entity(repositoryClass="Eccube\Repository\Master\PrefGroupRepository")
 * @ORM\Cache(usage="NONSTRICT_READ_WRITE")
 */
class PrefGroup extends \Eccube\Entity\Master\AbstractMasterEntity
{
     /**
     * @var string|null
     *
     * @ORM\Column(name="mon", type="string", length=255, nullable=true)
     */
    private $mon;

    /**
     * @var string|null
     *
     * @ORM\Column(name="tue", type="string", length=255, nullable=true)
     */
    private $tue;

    /**
     * @var string|null
     *
     * @ORM\Column(name="wed", type="string", length=255, nullable=true)
     */
    private $wed;

    /**
     * @var string|null
     *
     * @ORM\Column(name="thu", type="string", length=255, nullable=true)
     */
    private $thu;

    /**
     * @var string|null
     *
     * @ORM\Column(name="fri", type="string", length=255, nullable=true)
     */
    private $fri;

    /**
     * @var string|null
     *
     * @ORM\Column(name="sat", type="string", length=255, nullable=true)
     */
    private $sat;

    /**
     * @var string|null
     *
     * @ORM\Column(name="sun", type="string", length=255, nullable=true)
     */
    private $sun;

    /**
     * Get mon
     *
     * @return string|null
     */
    public function getMon()
    {
        return $this->mon;
    }

    /**
     * Get tue
     *
     * @return string|null
     */
    public function getTue()
    {
        return $this->tue;
    }

    /**
     * Get wed
     *
     * @return string|null
     */
    public function getWed()
    {
        return $this->wed;
    }

    /**
     * Get thu
     *
     * @return string|null
     */
    public function getThu()
    {
        return $this->thu;
    }

    /**
     * Get fri
     *
     * @return string|null
     */
    public function getFri()
    {
        return $this->fri;
    }

    /**
     * Get sat
     *
     * @return string|null
     */
    public function getSat()
    {
        return $this->sat;
    }

    /**
     * Get sun
     *
     * @return string|null
     */
    public function getSun()
    {
        return $this->sun;
    }
}
