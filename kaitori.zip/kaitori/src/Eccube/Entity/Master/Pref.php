<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Entity\Master;

use Doctrine\ORM\Mapping as ORM;

/**
 * Pref
 *
 * @ORM\Table(name="mtb_pref")
 * @ORM\InheritanceType("SINGLE_TABLE")
 * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
 * @ORM\HasLifecycleCallbacks()
 * @ORM\Entity(repositoryClass="Eccube\Repository\Master\PrefRepository")
 * @ORM\Cache(usage="NONSTRICT_READ_WRITE")
 */
class Pref extends \Eccube\Entity\Master\AbstractMasterEntity
{

     /**
     * @var string|null
     *
     * @ORM\Column(name="arrive_day", type="string", length=255, nullable=true)
     */
    private $arrive_day;


    /**
     * @var string|null
     *
     * @ORM\Column(name="arrive_time", type="string",  length=255, nullable=true)
     */
    private $arrive_time;

    /**
     * @var string|null
     *
     * @ORM\Column(name="group", type="string",  length=5, nullable=false)
     */
    private $group;


    /**
     * Set preOrderId.
     *
     * @param string|null $preOrderId
     *
     * @return Pref
     */
    public function setArrayDay($arriveDay)
    {
        $this->arrive_day = $arriveDay;

        return $this;
    }

    /**
     * Get preOrderId.
     *
     * @return string|null
     */
    public function getArrayDay()
    {
        return $this->arrive_day;
    }

    /**
     * Set orderNo
     *
     * @param string|null $orderNo
     *
     * @return Pref
     */
    public function setArriveTime($arriveTime)
    {
        $this->arrive_time = $arriveTime;

        return $this;
    }

    /**
     * Get orderNo
     *
     * @return string|null
     */
    public function getArriveTime()
    {
        return $this->arrive_time;
    }

    /**
     * Set group
     *
     * @param string|null $group
     *
     * @return Pref
     */
    public function setGroup($group)
    {
        $this->group = $group;

        return $this;
    }

    /**
     * Get group
     *
     * @return string|null
     */
    public function getGroup()
    {
        return $this->group;
    }
}
