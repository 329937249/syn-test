<?php

namespace Eccube\Entity\Master;

use Doctrine\ORM\Mapping as ORM;

/**
 * ResultClassify
 *
 * @ORM\Table(name="mtb_result_classify")
 * @ORM\InheritanceType("SINGLE_TABLE")
 * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
 * @ORM\HasLifecycleCallbacks()
 * @ORM\Entity(repositoryClass="Eccube\Repository\Master\ResultClassifyRepository")
 * @ORM\Cache(usage="NONSTRICT_READ_WRITE")
 */
class ResultClassify extends \Eccube\Entity\Master\AbstractMasterEntity
{
    /**
     * 正常
     *
     * @var integer
     */
    const NORMAL = 0;

    /**
     * 異常
     *
     * @var integer
     */
    const ERR = 1;
}
