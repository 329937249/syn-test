<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Entity\Master;

use Doctrine\ORM\Mapping as ORM;

/**
 * ContentTemplate
 *
 * @ORM\Table(name="mtb_content_template")
 * @ORM\InheritanceType("SINGLE_TABLE")
 * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
 * @ORM\HasLifecycleCallbacks()
 * @ORM\Entity(repositoryClass="Eccube\Repository\Master\ContentTemplateRepository")
 * @ORM\Cache(usage="NONSTRICT_READ_WRITE")
 */
class ContentTemplate extends \Eccube\Entity\AbstractEntity
{

    /**
     * @return string
     */
    public function __toString()
    {
        return (string) $this->getName();
    }
    
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", options={"unsigned":true})
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var string|null
     *
     * @ORM\Column(name="name", type="string", length=255, nullable=true)
     */
    private $name;

    /**
     * @var string|null
     *
     * @ORM\Column(name="title", type="string", length=255, nullable=true)
     */
    private $title;

    /**
     * @var string|null
     *
     * @ORM\Column(name="description", type="text", nullable=true)
     */
    private $description;
    
    /**
     * @var boolean
     *
     * @ORM\Column(name="is_contact_mail", type="boolean", options={"default":false})
     */
     private $is_contact_mail = false;
     
    /**
     * @var boolean
     *
     * @ORM\Column(name="audit_result", type="boolean", options={"default":false})
     */
     private $audit_result = false;

     /**
     * @var boolean
     *
     * @ORM\Column(name="use_type", type="boolean", options={"default":false})
     */
     private $use_type = false;

    /**
     * @var int
     *
     * @ORM\Column(name="sort_no", type="smallint", options={"unsigned":true})
     */
    protected $sort_no;

    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set id.
     *
     * @param string|null $id
     *
     * @return ContentTemplate
     */
    public function setId($id = null)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Set title.
     *
     * @param string $title
     *
     * @return ContentTemplate
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name.
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set title.
     *
     * @param string $title
     *
     * @return ContentTemplate
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title.
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set description.
     *
     * @param string $description
     *
     * @return ContentTemplate
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description.
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set isContactMail
     *
     * @param boolean $isContactMail
     *
     * @return ContentTemplate
     */
     public function setContactMail($isContactMail)
     {
          $this->is_contact_mail = $isContactMail;

          return $this;
     }

     /**
      * Get is_contact_mail
      *
      * @return boolean
      */
      public function isContactMail()
     {
        return $this->is_contact_mail;
     }
    
     /**
     * Set auditResult
     *
     * @param boolean $auditResult
     *
     * @return ContentTemplate
     */
     public function setAuditResult($auditResult)
     {
          $this->audit_result = $auditResult;

          return $this;
     }

     /**
      * Get audit_result
      *
      * @return boolean
      */
      public function getAuditResult()
     {
        return $this->audit_result;
     }
     
     /**
     * Set useType
     *
     * @param boolean $useType
     *
     * @return ContentTemplate
     */
     public function setUseType($useType)
     {
          $this->use_type = $useType;

          return $this;
     }

     /**
      * Get use_type
      *
      * @return boolean
      */
      public function getUseType()
     {
        return $this->use_type;
     }
     
    /**
     * Set sortNo.
     *
     * @param int|null $sortNo
     *
     * @return ContentTemplate
     */
    public function setSortNo($sortNo = null)
    {
        $this->sort_no = $sortNo;

        return $this;
    }

    /**
     * Get sortNo.
     *
     * @return int|null
     */
    public function getSortNo()
    {
        return $this->sort_no;
    }

}