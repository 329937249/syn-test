<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Entity\Master;

use Doctrine\ORM\Mapping as ORM;

/**
 * Menu
 *
 * @ORM\Table(name="mtb_menu")
 * @ORM\InheritanceType("SINGLE_TABLE")
 * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
 * @ORM\HasLifecycleCallbacks()
 * @ORM\Entity(repositoryClass="Eccube\Repository\Master\MenuRepository")
 * @ORM\Cache(usage="NONSTRICT_READ_WRITE")
 */
class Menu extends \Eccube\Entity\Master\AbstractMasterEntity
{
    /**
     * 拒否URLリスト
     */
    const COMMON_DENY_URL = [
        '/setting/shop/certs',
        '/setting/shop/payment',
        '/setting/shop/delivery',
        '/setting/shop/tax',
        '/setting/shop/mail',
        '/setting/shop/csv',
        '/setting/system/masterdata',
        '/setting/system/authority',
        '/setting/system/category',
        '/setting/system/system',
        '/content/file_manager',
        ];

    /**
     * @var string|null
     *
     * @ORM\Column(name="url", type="string", length=4000, nullable=true)
     */
    protected $url;

    /**
     * Set url.
     *
     * @param string|null $url
     *
     * @return Menu
     */
    public function setUrl($url = null)
    {
        $this->url = $url;

        return $this;
    }

    /**
     * Get url.
     *
     * @return string|null
     */
    public function getUrl()
    {
        return $this->url;
    }

}
