<?php

namespace Eccube\Entity\Master;

use Doctrine\ORM\Mapping as ORM;

/**
 * CheckClassify
 *
 * @ORM\Table(name="mtb_check_classify")
 * @ORM\InheritanceType("SINGLE_TABLE")
 * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
 * @ORM\HasLifecycleCallbacks()
 * @ORM\Entity(repositoryClass="Eccube\Repository\Master\CheckClassifyRepository")
 * @ORM\Cache(usage="NONSTRICT_READ_WRITE")
 */
class CheckClassify extends \Eccube\Entity\Master\AbstractMasterEntity
{
    /**
     * 数量
     *
     * @var integer
     */
    const QUANTITY = 0;

    /**
     * シリアル
     *
     * @var integer
     */
    const SERIAL = 1;
}
