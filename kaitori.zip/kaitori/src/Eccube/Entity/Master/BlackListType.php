<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Entity\Master;

use Doctrine\ORM\Mapping as ORM;

/**
 * BlackListType
 *
 * @ORM\Table(name="mtb_black_list_type")
 * @ORM\InheritanceType("SINGLE_TABLE")
 * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
 * @ORM\HasLifecycleCallbacks()
 * @ORM\Entity(repositoryClass="Eccube\Repository\Master\BlackListTypeRepository")
 * @ORM\Cache(usage="NONSTRICT_READ_WRITE")
 */
class BlackListType extends \Eccube\Entity\Master\AbstractMasterEntity
{

    /** 未指定. */
    const UNSPECIFIED = 1;

    /** 注意. */
    const WARNING = 2;

    /** 買取拒否可. */
    const REFUSE = 3;

}
