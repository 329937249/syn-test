<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Entity\Master;

use Doctrine\ORM\Mapping as ORM;

if (!class_exists('\Eccube\Entity\Master\Rank')) {
    /**
     * Rank
     *
     * @ORM\Table(name="mtb_rank")
     * @ORM\InheritanceType("SINGLE_TABLE")
     * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
     * @ORM\HasLifecycleCallbacks()
     * @ORM\Entity(repositoryClass="Eccube\Repository\Master\RankRepository")
     * @ORM\Cache(usage="NONSTRICT_READ_WRITE")
     */
    class Rank extends \Eccube\Entity\AbstractEntity
    {
        /**
         * @return string
         */
        public function getRankName()
        {
            if ((int)$this->price_change > 0) {
                return $this->name.'( +'.number_format($this->price_change).'円 )';
            } else {
                return $this->name.'( '.number_format($this->price_change).'円 )';
            }
        }


        /**
         * @return string
         */
        public function getFullName()
        {
            $RankTypeName = '';
            if ($this->RankType && $this->RankType->getName()) {
                $RankTypeName = '('.$this->RankType->getName().')';
            }
            if ((int)$this->price_change > 0) {
                return $RankTypeName.$this->name.'( +'.number_format($this->price_change).'円 )';
            } else {
                return $RankTypeName.$this->name.'( '.number_format($this->price_change).'円 )';
            }
        }

        /**
         * @return string
         */
        public function __toString()
        {
            //return (string) $this->getName();
            return (string) $this->getFullName();
        }

        /**
         * @var int
         *
         * @ORM\Column(name="id", type="integer", options={"unsigned":true})
         * @ORM\Id
         * @ORM\GeneratedValue(strategy="IDENTITY")
         */
        protected $id;

        /**
         * @var string
         *
         * @ORM\Column(name="name", type="string", length=255)
         */
        protected $name;

        /**
         * @var int
         *
         * @ORM\Column(name="sort_no", type="smallint", options={"unsigned":true})
         */
        protected $sort_no;

        /**
         * @var string|null
         *
         * @ORM\Column(name="price_change", type="decimal", precision=12, scale=2, nullable=true)
         */
        private $price_change;

        /**
         * @var \Eccube\Entity\Master\RankType
         *
         * @ORM\OneToOne(targetEntity="Eccube\Entity\Master\RankType")
         * @ORM\JoinColumns({
         *   @ORM\JoinColumn(name="rank_type_id", referencedColumnName="id")
         * })
         */
        private $RankType;

        /**
         * @var \Doctrine\Common\Collections\Collection
         *
         * @ORM\OneToMany(targetEntity="Eccube\Entity\ProductRank", mappedBy="Rank")
         */
        protected $ProductRank;

        /**
         * Constructor
         */
        public function __construct()
        {
            $this->ProductRank = new \Doctrine\Common\Collections\ArrayCollection();
        }

        /**
         * Set id.
         *
         * @param int $id
         *
         * @return $this
         */
        public function setId($id)
        {
            $this->id = $id;

            return $this;
        }

        /**
         * Get id.
         *
         * @return int
         */
        public function getId()
        {
            return $this->id;
        }

        /**
         * Set name.
         *
         * @param string $name
         *
         * @return $this
         */
        public function setName($name)
        {
            $this->name = $name;

            return $this;
        }

        /**
         * Get name.
         *
         * @return string
         */
        public function getName()
        {
            return $this->name;
        }

        /**
         * Set sort_no.
         *
         * @param int $sort_no
         *
         * @return $this
         */
        public function setSortNo($sort_no)
        {
            $this->sort_no = $sort_no;

            return $this;
        }

        /**
         * Get sort_no.
         *
         * @return int
         */
        public function getSortNo()
        {
            return $this->sort_no;
        }

        /**
         * Set price_change.
         *
         * @param string|null $price_change
         *
         * @return Rank
         */
        public function setPriceChange($price_change = null)
        {
            $this->price_change = $price_change;

            return $this;
        }

        /**
         * Get price_change.
         *
         * @return string|null
         */
        public function getPriceChange()
        {
            return $this->price_change;
        }

        /**
         * Set rankType.
         *
         * @param \Eccube\Entity\Master\RankType|null $rankType
         *
         * @return Rank
         */
        public function setRankType(\Eccube\Entity\Master\RankType $rankType = null)
        {
            $this->RankType = $rankType;

            return $this;
        }

        /**
         * Get rankType.
         *
         * @return \Eccube\Entity\Master\RankType|null
         */
        public function getRankType()
        {
            return $this->RankType;
        }


        /**
         * Add productRank.
         *
         * @param \Eccube\Entity\ProductRank $productRank
         *
         * @return Rank
         */
        public function addProductRank(\Eccube\Entity\ProductRank $productRank)
        {
            $this->productRank[] = $productRank;

            return $this;
        }

        /**
         * Remove productRank.
         *
         * @param \Eccube\Entity\ProductRank $productRank
         *
         * @return boolean TRUE if this collection contained the specified element, FALSE otherwise.
         */
        public function removeProductRank(\Eccube\Entity\ProductRank $productRank)
        {
            return $this->productRank->removeElement($productRank);
        }

        /**
         * Get productRank.
         *
         * @return \Doctrine\Common\Collections\Collection
         */
        public function getProductRank()
        {
            return $this->productRank;
        }
    }
}
