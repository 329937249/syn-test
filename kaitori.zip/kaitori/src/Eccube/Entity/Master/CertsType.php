<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Entity\Master;

use Doctrine\ORM\Mapping as ORM;

/**
 * CertsType
 *
 * @ORM\Table(name="mtb_certs_type")
 * @ORM\InheritanceType("SINGLE_TABLE")
 * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
 * @ORM\HasLifecycleCallbacks()
 * @ORM\Entity(repositoryClass="Eccube\Repository\Master\CertsTypeRepository")
 * @ORM\Cache(usage="NONSTRICT_READ_WRITE")
 */
class CertsType extends \Eccube\Entity\AbstractEntity
{
    /**
     * @return string
     */
    public function __toString()
    {
        return (string) $this->name;
    }

    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", options={"unsigned":true})
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var string|null
     *
     * @ORM\Column(name="name", type="string", length=255, nullable=true)
     */
    private $name;


    /**
     * @var int|null
     *
     * @ORM\Column(name="sort_no", type="integer", nullable=true, options={"unsigned":true})
     */
    private $sort_no;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\OneToMany(targetEntity="Eccube\Entity\CertsOption", mappedBy="CertsType", cascade={"persist","remove"})
     */
    private $CertsOptions;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->CertsOptions = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set id.
     *
     * @param string|null $id
     *
     * @return CertsType
     */
    public function setId($id = null)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Set name.
     *
     * @param string|null $name
     *
     * @return CertsType
     */
    public function setName($name = null)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name.
     *
     * @return string|null
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set sortNo.
     *
     * @param int|null $sortNo
     *
     * @return CertsType
     */
    public function setSortNo($sortNo = null)
    {
        $this->sort_no = $sortNo;

        return $this;
    }

    /**
     * Get sortNo.
     *
     * @return int|null
     */
    public function getSortNo()
    {
        return $this->sort_no;
    }

    /**
     * Add certsOption.
     *
     * @param \Eccube\Entity\CertsOption $certsOption
     *
     * @return CertsType
     */
    public function addCertsOption(\Eccube\Entity\CertsOption $certsOption)
    {
        $this->CertsOptions[] = $certsOption;

        return $this;
    }

    /**
     * Remove certsOption.
     *
     * @param \Eccube\Entity\CertsOption $certsOption
     *
     * @return boolean TRUE if this collection contained the specified element, FALSE otherwise.
     */
    public function removeCertsOption(\Eccube\Entity\CertsOption $certsOption)
    {
        return $this->CertsOptions->removeElement($certsOption);
    }

    /**
     * Get certsOptions.
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getCertsOptions()
    {
        return $this->CertsOptions;
    }

}
