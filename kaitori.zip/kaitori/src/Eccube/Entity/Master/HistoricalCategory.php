<?php

namespace Eccube\Entity\Master;

use Doctrine\ORM\Mapping as ORM;

/**
 * HistoricalCategory
 *
 * @ORM\Table(name="mtb_historical_category")
 * @ORM\InheritanceType("SINGLE_TABLE")
 * @ORM\DiscriminatorColumn(name="discriminator_type", type="string", length=255)
 * @ORM\HasLifecycleCallbacks()
 * @ORM\Entity(repositoryClass="Eccube\Repository\Master\HistoricalCategoryRepository")
 * @ORM\Cache(usage="NONSTRICT_READ_WRITE")
 */
class HistoricalCategory extends \Eccube\Entity\Master\AbstractMasterEntity
{
    /**
     * 仕入
     *
     * @var integer
     */
    const INCORPORATION = 0;

    /**
     * 売上
     *
     * @var integer
     */
    const SALES = 1;
}
