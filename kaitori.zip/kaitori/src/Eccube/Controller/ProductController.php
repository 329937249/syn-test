<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller;

use Eccube\Entity\BaseInfo;
use Eccube\Entity\Master\ProductStatus;
use Eccube\Entity\Contact;
use Eccube\Entity\Product;
use Eccube\Entity\Category;
use Eccube\Entity\Tag;
use Eccube\Entity\Alarm;
use Eccube\Entity\Master\Rank;
use Eccube\Entity\Master\RankType;
use Eccube\Entity\Master\SaleType;
use Eccube\Entity\Master\OrderStatus;
use Eccube\Entity\ProductClass;
use Eccube\Entity\ProductRank;
use Eccube\Entity\ProductRankOption;
use Eccube\Entity\CartItem;
use Eccube\Entity\ProductSearchHistory;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\AddCartType;
use Eccube\Form\Type\Front\ContactType;
use Eccube\Form\Type\AddCartSingleType;
use Eccube\Form\Type\Master\ProductListMaxType;
use Eccube\Form\Type\Master\ProductListOrderByType;
use Eccube\Form\Type\SearchProductType;
use Eccube\Repository\BaseInfoRepository;
use Eccube\Repository\CustomerFavoriteProductRepository;
use Eccube\Repository\ProductSearchHistoryRepository;
use Eccube\Repository\Master\ProductListMaxRepository;
use Eccube\Repository\Master\SaleTypeRepository;
use Eccube\Repository\Master\RankTypeRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\TagRepository;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\OrderRepository;
use Eccube\Repository\AlarmRepository;
use Eccube\Repository\ProductRecommendRepository;
use Eccube\Repository\ProductRankRepository;
use Eccube\Service\CartService;
use Eccube\Service\PurchaseFlow\PurchaseContext;
use Eccube\Service\PurchaseFlow\PurchaseFlow;
use Knp\Bundle\PaginatorBundle\Pagination\SlidingPagination;
use Knp\Component\Pager\Paginator;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;
use Symfony\Component\HttpFoundation\RedirectResponse;
use SunCat\MobileDetectBundle\DeviceDetector\MobileDetector;
use Doctrine\ORM\Query\ResultSetMapping;
use Eccube\Util\EncryptUtil;
use Eccube\Repository\ShopInfoRepository;

class ProductController extends AbstractController
{
    /**
     * @var PurchaseFlow
     */
    protected $purchaseFlow;

    /**
     * @var CustomerFavoriteProductRepository
     */
    protected $customerFavoriteProductRepository;
    
    /**
     * @var TagRepository
     */
    protected $tagRepository;
    
    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var OrderRepository
     */
    protected $orderRepository;

    /**
     * @var AlarmRepository
     */
    protected $alarmRepository;

    /**
     * @var CartService
     */
    protected $cartService;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var ProductRecommendRepository
     */
    protected $productRecommendRepository;

    /**
     * @var ProductRankRepository
     */
    protected $productRankRepository;

    /**
     * @var SaleTypeRepository
     */
    protected $saleTypeRepository;

    /**
     * @var RankTypeRepository
     */
    protected $rankTypeRepository;
    
    /**
     * @var BaseInfo
     */
    protected $BaseInfo;

    /**
     * @var AuthenticationUtils
     */
    protected $helper;

    /**
     * @var ProductListMaxRepository
     */
    protected $productListMaxRepository;

    private $title = '';

    /**
     * @var ProductSearchHistoryRepository
     */
    protected $productSearchHistoryRepository;

     /**
     * @var ShopInfoRepository
     */
    protected $shopInfoRepository;

    /**
     * @var MobileDetector
     */
    private $mobileDetector;

    /**
     * ProductController constructor.
     *
     * @param PurchaseFlow $cartPurchaseFlow
     * @param CustomerFavoriteProductRepository $customerFavoriteProductRepository
     * @param CartService $cartService
     * @param ProductRepository $productRepository
     * @param TagRepository $tagRepository
     * @param CategoryRepository $categoryRepository
     * @param OrderRepository $orderRepository
     * @param AlarmRepository $alarmRepository,
     * @param ProductRecommendRepository $productRecommendRepository
     * @param ProductRankRepository $productRankRepository 
     * @param SaleTypeRepository $saleTypeRepository,
     * @param RankTypeRepository $rankTypeRepository,
     * @param BaseInfoRepository $baseInfoRepository
     * @param AuthenticationUtils $helper
     * @param ProductListMaxRepository $productListMaxRepository
     * @param ProductSearchHistoryRepository $productSearchHistoryRepository
     * @param MobileDetector $mobileDetector
     * @param ShopInfoRepository $shopInfoRepository
     */
    public function __construct(
        PurchaseFlow $cartPurchaseFlow,
        CustomerFavoriteProductRepository $customerFavoriteProductRepository,
        CartService $cartService,
        ProductRepository $productRepository,
        TagRepository $tagRepository,
        CategoryRepository $categoryRepository,
        OrderRepository $orderRepository,
        AlarmRepository $alarmRepository,
        ProductRecommendRepository $productRecommendRepository,
        ProductRankRepository $productRankRepository,
        SaleTypeRepository $saleTypeRepository,
        RankTypeRepository $rankTypeRepository,
        BaseInfoRepository $baseInfoRepository,
        AuthenticationUtils $helper,
        ProductListMaxRepository $productListMaxRepository,
        ProductSearchHistoryRepository $productSearchHistoryRepository,
        MobileDetector $mobileDetector,
        ShopInfoRepository $shopInfoRepository
    ) {
        $this->purchaseFlow = $cartPurchaseFlow;
        $this->customerFavoriteProductRepository = $customerFavoriteProductRepository;
        $this->cartService = $cartService;
        $this->productRepository = $productRepository;
        $this->tagRepository = $tagRepository;
        $this->categoryRepository = $categoryRepository;
        $this->orderRepository = $orderRepository;
        $this->alarmRepository = $alarmRepository;
        $this->productRecommendRepository = $productRecommendRepository;
        $this->productRankRepository = $productRankRepository;
        $this->saleTypeRepository = $saleTypeRepository;
        $this->rankTypeRepository = $rankTypeRepository;
        $this->BaseInfo = $baseInfoRepository->get();
        $this->helper = $helper;
        $this->productListMaxRepository = $productListMaxRepository;
        $this->productSearchHistoryRepository = $productSearchHistoryRepository;
        $this->mobileDetector = $mobileDetector;
        $this->shopInfoRepository = $shopInfoRepository;
    }

    /**
     * 価格暗号化
     *
     * @Route("/products/encrypt_price/{price}", name="encrypt_price")
     */
    public function encryptPrice(Request $request, string $price)
    {
        $encrypt_key = $request->getSession()->get('encrypt_key');
        if(!$encrypt_key){
            throw new NotFoundHttpException();
        }
        if($encrypt_key != $price){
            throw new NotFoundHttpException();
        }
        $real_price = EncryptUtil::decrypt($price);
        $image = "/tmp/{$real_price}.png";
        $request->getSession()->remove('encrypt_key');
        if (file_exists($image)) {
            $file = readfile($image);
            $headers = array('Content-Type' => 'image/png', 'Content-Disposition' => 'inline; filename="'.$file.'"');
            return new Response($image, 200, $headers);
        }
        $im = @imagecreate(110, 16)
            or die("Cannot Initialize new GD image stream");
        $background_color = imagecolorallocate($im, 255, 255, 255);
        $text_color = imagecolorallocate($im, 255, 0, 0);
        $str = $real_price . ' ,';
        $font_fname = "/var/www/html/ipaexg.ttf";
        imagettftext($im, 12, 0, 0, 14, $text_color, $font_fname, $str);
        imagepng($im, $image);
        imagedestroy($im);
        $file = readfile($image);
        $headers = array('Content-Type' => 'image/png', 'Content-Disposition' => 'inline; filename="'.$file.'"');
        return new Response($image, 200, $headers);
    }

    /**
     * 商品一覧画面（画像なし）.
     *
     * @Route("/products/list_small", name="product_list_small")
     * @Template("Product/list_small.twig")
     */
    public function index_small(Request $request, Paginator $paginator)
    {
        // Doctrine SQLFilter
        if ($this->BaseInfo->isOptionNostockHidden()) {
            $this->entityManager->getFilters()->enable('option_nostock_hidden');
        }

        // handleRequestは空のqueryの場合は無視するため
        if ($request->getMethod() === 'GET') {
            $request->query->set('pageno', $request->query->get('pageno', ''));
        }

        // searchForm
        /* @var $builder \Symfony\Component\Form\FormBuilderInterface */
        $builder = $this->formFactory->createNamedBuilder('', SearchProductType::class);

        if ($request->getMethod() === 'GET') {
            $builder->setMethod('GET');
        }

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_PRODUCT_INDEX_INITIALIZE, $event);

        /* @var $searchForm \Symfony\Component\Form\FormInterface */
        $searchForm = $builder->getForm();

        $searchForm->handleRequest($request);

        // paginator
        $searchData = $searchForm->getData();
        $qb = $this->productRepository->getQueryBuilderBySearchData($searchData);

        $event = new EventArgs(
            [
                'searchData' => $searchData,
                'qb' => $qb,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_PRODUCT_INDEX_SEARCH, $event);
        $searchData = $event->getArgument('searchData');

        $query = $qb->getQuery()
            ->useResultCache(true, $this->eccubeConfig['eccube_result_cache_lifetime_short']);

        /** @var SlidingPagination $pagination */
        $pagination = $paginator->paginate(
            $query,
            !empty($searchData['pageno']) ? $searchData['pageno'] : 1,
            !empty($searchData['disp_number']) ? $searchData['disp_number']->getId() : $this->productListMaxRepository->findOneBy([], ['sort_no' => 'ASC'])->getId()
        );

        $ids = [];
        foreach ($pagination as $Product) {
            $ids[] = $Product->getId();
        }
        $ProductsAndClassCategories = $this->productRepository->findProductsWithSortedClassCategories($ids, 'p.id');

        // addCart form
        $forms = [];
        foreach ($pagination as $Product) {
            /* @var $builder \Symfony\Component\Form\FormBuilderInterface */
            $builder = $this->formFactory->createNamedBuilder(
                '',
                AddCartType::class,
                null,
                [
                    'product' => $ProductsAndClassCategories[$Product->getId()],
                    'allow_extra_fields' => true,
                ]
            );
            $addCartForm = $builder->getForm();

	    $ProductClasses = $Product->getProductClasses();
	    foreach ($ProductClasses as $ProductClass) {
                $forms[$ProductClass->getId()] = $addCartForm->createView();
	    }
            //$forms[$Product->getId()] = $addCartForm->createView();
        }

        // 表示件数
        $builder = $this->formFactory->createNamedBuilder(
            'disp_number',
            ProductListMaxType::class,
            null,
            [
                'required' => false,
                'allow_extra_fields' => true,
            ]
        );
        if ($request->getMethod() === 'GET') {
            $builder->setMethod('GET');
        }

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_PRODUCT_INDEX_DISP, $event);

        $dispNumberForm = $builder->getForm();

        $dispNumberForm->handleRequest($request);

        // ソート順
        $builder = $this->formFactory->createNamedBuilder(
            'orderby',
            ProductListOrderByType::class,
            null,
            [
                'required' => false,
                'allow_extra_fields' => true,
            ]
        );
        if ($request->getMethod() === 'GET') {
            $builder->setMethod('GET');
        }

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_PRODUCT_INDEX_ORDER, $event);

        $orderByForm = $builder->getForm();

        $orderByForm->handleRequest($request);

        $Category = $searchForm->get('category_id')->getData();

        return [
            'subtitle' => $this->getPageTitle($searchData),
            'pagination' => $pagination,
            'search_form' => $searchForm->createView(),
            'disp_number_form' => $dispNumberForm->createView(),
            'order_by_form' => $orderByForm->createView(),
            'forms' => $forms,
            'Category' => $Category,
        ];
    }

    /**
     * （キーワード検索）商品一覧画面
     *
     * @Route("/products/list/keyword", name="product_list_by_keyword")
     */
    public function product_lis_by_keyword(Request $request, Paginator $paginator)
    {
        $template = $this->session->get('list_type') == "big" ? 'Main/product_list_3.twig' : 'Main/product_list_1.twig';
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            $template = 'Mobile/product_list.twig';
        }
        $result = $this->index_for_all($request, $paginator);
        if(is_array($result)){
            return $this->render($template, $result);
        }
        return $this->renderHelp($request, $result);
    }

    /**
     * （キーワード検索）全て商品一覧画面
     *
     * @Route("/products/all_list/keyword", name="product_all_list_by_keyword")
     */
    public function product_all_lis_by_keyword(Request $request, Paginator $paginator)
    {
        $template = $this->session->get('list_type') == "big" ? 'Main/product_list_3.twig' : 'Main/product_list_1.twig';
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            $template = 'Mobile/product_list.twig';
        }
        $result = $this->index_for_all($request, $paginator);
        if(is_array($result)){
            return $this->render($template, $result);
        }
        return $this->renderHelp($request, $result);
    }

    /**
     * （カテゴリ検索）商品一覧画面
     *
     * @Route("/products/{page_type}/small/list_category/{id}", name="product_list_by_category_small", requirements={"id" = "\d+", "page_type" = "\d+"})
     */
    public function product_list_by_category_small(Request $request, $page_type, Category $category, Paginator $paginator)
    {
        $this->session->set('list_type', 'small');
        return $this->product_list_by_category($request, $page_type, $category, $paginator);
    }
    
    /**
     * （タグ検索）商品一覧画面
     *
     * @Route("/products/{page_type}/small/list_category/{id}/list_tag/{tag_id}", name="product_list_by_tag_small", requirements={"id" = "\d+","tag_id" = "\d+", "page_type" = "\d+"})
     */
    public function product_list_by_tag_small(Request $request, $page_type, Category $category, $tag_id, Paginator $paginator)
    {
        $this->session->set('list_type', 'small');
        return $this->product_list_by_tag($request, $page_type, $category, $tag_id, $paginator);
    }
    

    /**
     * （カテゴリ検索）商品一覧画面
     *
     * @Route("/products/{page_type}/big/list_category/{id}", name="product_list_by_category_big", requirements={"id" = "\d+", "page_type" = "\d+"})
     */
    public function product_list_by_category_big(Request $request, $page_type, Category $category, Paginator $paginator)
    {
        $this->session->set('list_type', 'big');
        return $this->product_list_by_category($request, $page_type, $category, $paginator);
    }
    
    /**
     * （タグ検索）商品一覧画面
     *
     * @Route("/products/{page_type}/big/list_category/{id}/list_tag/{tag_id}", name="product_list_by_tag_big", requirements={"id" = "\d+","tag_id" = "\d+", "page_type" = "\d+"})
     */
    public function product_list_by_tag_big(Request $request, $page_type, Category $category, $tag_id, Paginator $paginator)
    {
        $this->session->set('list_type', 'big');
        return $this->product_list_by_tag($request, $page_type, $category, $tag_id, $paginator);
    }
    
    /**
     * （カテゴリ検索）商品一覧画面
     *
     * @Route("/products/{page_type}/list_category/{id}", name="product_list_by_category", requirements={"id" = "\d+", "page_type" = "\d+"})
     */
    public function product_list_by_category(Request $request, $page_type, Category $category, Paginator $paginator)
    {
        $template = $this->session->get('list_type') == "big" ? 'Main/product_list_3.twig' : 'Main/product_list_1.twig';
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            $template = 'Mobile/product_list.twig';
        }
        $result = $this->index_by_category($request, $category, $paginator, $page_type);
        if(is_array($result)){
            return $this->render($template, $result);
        }
        return $this->renderHelp($request, $result);
    }
    
    /**
     * （タグ検索）商品一覧画面
     *
     * @Route("/products/{page_type}/list_category/{id}/list_tag/{tag_id}", name="product_list_by_tag", requirements={"id" = "\d+","tag_id" = "\d+", "page_type" = "\d+"})
     */
    public function product_list_by_tag(Request $request, $page_type, Category $category, $tag_id, Paginator $paginator)
    {
        $template = $this->session->get('list_type') == "big" ? 'Main/product_list_3.twig' : 'Main/product_list_1.twig';
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            $template = 'Mobile/product_list.twig';
        }
        $result = $this->index_by_category_tag($request, $category, $tag_id, $paginator, $page_type);
        if(is_array($result)){
            return $this->render($template, $result);
        }
        return $this->renderHelp($request, $result);
    }
    
    /**
     * （タグ検索）全て商品一覧画面
     *
     * @Route("/products/all_list_tag/{tag_id}", name="product_all_list_by_tag", requirements={"tag_id" = "\d+"})
     */
    public function product_all_list_by_tag(Request $request, $tag_id, Paginator $paginator)
    {
        $template = $this->session->get('list_type') == "big" ? 'Main/product_list_3.twig' : 'Main/product_list_1.twig';
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            $template = 'Mobile/product_list.twig';
        }
        $result = $this->index_by_tag($request, $tag_id, $paginator);
        if(is_array($result)){
            return $this->render($template, $result);
        }
        return $this->renderHelp($request, $result);
    }
    
    /**
     * （買取強化機種）商品一覧画面（携帯:keitai、大画像:3）.
     *
     * @Route("/products/list_keitai_new/{id}", name="product_list_keitai_new_by_category", methods={"GET"}, requirements={"id" = "\d+"})
     * @Template("Block2/new_product.twig")
     */
    public function product_list_keitai_new_by_category(Request $request, Category $category, Paginator $paginator)
    {
        $saleType = $this->saleTypeRepository->find(SaleType::SALE_TYPE_KEITAI);
        $category = $saleType->getCategory();
        // log_info("category", [$category->getId(),$category->getName()]);
        // return $this->index_by_category($request, $category, $paginator, '1');
        return $this->index_for_new($request, $category, $saleType, '1', $paginator);
    }

    /**
     * （買取強化機種）商品一覧画面（家電:kaden、大画像:3）.
     *
     * @Route("/products/list_kaden_new/{id}", name="product_list_kaden_new_by_category", methods={"GET"}, requirements={"id" = "\d+"})
     * @Template("Block2/new_product.twig")
     */
    public function product_list_kaden_new_by_category(Request $request, Category $category, Paginator $paginator)
    {
        $saleType = $this->saleTypeRepository->find(SaleType::SALE_TYPE_KADEN);
        $category = $saleType->getCategory();
        // log_info("category", [$category->getId(),$category->getName()]);
        // return $this->index_by_category($request, $category, $paginator, '2');
        return $this->index_for_new($request, $category, $saleType, '2', $paginator);
    }

    /**
     * （買取強化機種）商品一覧画面（日用品:nitiyouhin、大画像:3）.
     *
     * @Route("/products/list_nitiyouhin_new/{id}", name="product_list_nitiyouhin_new_by_category", methods={"GET"}, requirements={"id" = "\d+"})
     * @Template("Block2/new_product.twig")
     */
    public function product_list_nitiyouhin_new_by_category(Request $request, Category $category, Paginator $paginator)
    {
        $saleType = $this->saleTypeRepository->find(SaleType::SALE_TYPE_NITIYOUHIN);
        $category = $saleType->getCategory();
        return $this->index_for_new($request, $category, $saleType, '3', $paginator);
    }
    

    public function index_by_category(Request $request, Category $category, Paginator $paginator, $page_type)
    {
        //$request->query->set('last_category_id', null);
        
        log_info("category", [$category]);
        log_info("page_type", [$page_type]);
        

        if ($category) {
             $request->query->set('category_id', $category->getId());
        }
        
        if ($page_type) {
            $request->query->set('page_type', $page_type);
        }

        if($request->get('name')){
            return $this->index_for_all($request, $paginator);
        }
        return $this->index($request, $paginator);
    }
    
     public function index_by_category_tag(Request $request, Category $category,  $tag_id,Paginator $paginator, $page_type)
    {

        if ($category) {
            $request->query->set('category_id', $category->getId());
        }
        
        if ($tag_id) {
            $request->query->set('tag_id', $tag_id);
        }
        if ($page_type) {
            $request->query->set('page_type', $page_type);
        }
        return $this->index($request, $paginator);
    }
    
    public function index_by_tag(Request $request, $tag_id,Paginator $paginator)
    {
        if ($tag_id) {
            $request->query->set('tag_id', $tag_id);
        }
        return $this->index_for_all($request, $paginator);
    }

    /**
     * 商品一覧画面.
     *
     * @Route("/products/list", name="product_list")
     * @Template("Product/list.twig")
     */
    public function index(Request $request, Paginator $paginator)
    {
        //$request->query->set('last_category_id', null);

        // Doctrine SQLFilter
        if ($this->BaseInfo->isOptionNostockHidden()) {
            $this->entityManager->getFilters()->enable('option_nostock_hidden');
        }

        // category_id
        $category_id = $request->get('category_id');

        $tag_id = $request->get('tag_id');
        $tag = null;
        if($tag_id){
           $tag = $this->tagRepository->find($tag_id);
        }

        $last_category_id = $request->get('last_category_id');
        $last_category = null;
        if($last_category_id){
         $last_category = $this->categoryRepository
                ->find($last_category_id);
        }
        $page_type = $request->get('page_type');
        log_info("page_type", [$page_type]);

        // ProductClass
        $productclass_id = $request->get('productclass_id');
        log_info("productclass_id", [$productclass_id]);

        // searchForm
        /* @var $builder \Symfony\Component\Form\FormBuilderInterface */
        $builder = $this->formFactory->createNamedBuilder('', SearchProductType::class);

        if ($request->getMethod() === 'GET') {
            $builder->setMethod('GET');
        }

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_PRODUCT_INDEX_INITIALIZE, $event);

        /* @var $searchForm \Symfony\Component\Form\FormInterface */
        $searchForm = $builder->getForm();

        $searchForm->handleRequest($request);

        // paginator
        $allTagSearchData = $searchForm->getData();

        $searchData = $searchForm->getData();
        

        $searchData['tag_id'] = $tag;
        $searchData['last_category_id'] = $last_category;
        $allTagSearchData['last_category_id'] = $last_category;
        $allTags = $this->getAllTags($allTagSearchData,$request,$paginator);

        if($searchData["name"]){
            $this->banDenySearch($searchData["name"]);
        }

        // $qb = $this->productRepository->getQueryBuilderBySearchData($searchData);
        $result = $this->productRepository->getQueryBuilderBySearchDataNew($searchData);

        if($searchData["name"]){
            $this->saveProductSearchHistory($searchData, $result);
        }

        //$event = new EventArgs(
        //    [
        //        'searchData' => $searchData,
        //        'qb' => $qb,
        //    ],
        //    $request
        //);

        //$this->eventDispatcher->dispatch(EccubeEvents::FRONT_PRODUCT_INDEX_SEARCH, $event);

        //$searchData = $event->getArgument('searchData');

        //$query = $qb->getQuery()
        //    ->useResultCache(true, $this->eccubeConfig['eccube_result_cache_lifetime_short']);

        /** @var SlidingPagination $pagination */
        $pagination = $paginator->paginate(
            //$query,
            $result,
            !empty($request->query->get('pageno')) ? $request->query->get('pageno') : 1,
            !empty($searchData['disp_number']) ? $searchData['disp_number']->getId() : $this->productListMaxRepository->findOneBy([], ['sort_no' => 'DESC'])->getId()
        );

        $Category = null;
        if($last_category){
            $Category = $last_category;
        }else{
            $Category = $searchForm->get('category_id')->getData();
        }
        if($pagination->getTotalItemCount() == 0){
             return $Category;
        }

        $ids = [];
        foreach ($pagination as $Product) {
            $ids[] = $Product->getId();
        }
        $ProductsAndClassCategories = $this->productRepository->findProductsWithSortedClassCategories($ids, 'p.id');
        log_info("pagination", ['OK']);

        // addCart form
        $forms = [];
        $hasClassCategory1 = false;
        $hasClassCategory2 = false;
        $hasOldPrice = false;
        $update_dates = [];
        //$ProductTags = [];
        $FavoriteProducts = [];
        $NewProducts = [];
        
        foreach ($pagination as $Product) {
            $thisProduct = $ProductsAndClassCategories[$Product->getId()];
            if (!is_null($Product->getClassName1())) {
                $hasClassCategory1 = true;
            }
            if (!is_null($Product->getClassName2())) {
                $hasClassCategory2 = true;
            }

            // customerFavorite
            $is_favorite = false;
            if ($this->isGranted('ROLE_USER')) {
                $Customer = $this->getUser();
                $is_favorite = $this->customerFavoriteProductRepository->isFavorite($Customer, $Product);
                $FavoriteProducts[$Product->getId()] = $is_favorite;
            } else {
                $FavoriteProducts[$Product->getId()] = false;
            }

            // タグ
            //if($tag){
            //   $ProductTags[$tag->getId()] = $tag;
            //}else{
            //  foreach($Product->getProductTag() as $ProductTag) {
            //    $Tag = $ProductTag->getTag();
            //    if ($Tag) {
            //        $ProductTags[$Tag->getId()] = $Tag;
            //    }
            //  }
            //}

            $ProductClasses = $thisProduct->getProductClasses();
            foreach ($ProductClasses as $ProductClass) {
                // データ更新日
                //foreach($ProductClass->getProductPrices() as $ProductPrice) {
                //    $update_dates[] = $ProductPrice->getUpdateDate();
                //}

                // 中古買取あり
                if ((int)$ProductClass->getPriceOld() > 0 ) {
                    $hasOldPrice = true;
                }

                // 強化買取商品
                $is_newProduct = $this->productRecommendRepository->isNewProduct($ProductClass);
                $NewProducts[$ProductClass->getId()] = $is_newProduct;

                $cartItem = new CartItem();

                /* @var $builder \Symfony\Component\Form\FormBuilderInterface */
                $builder = $this->formFactory->createNamedBuilder(
                    '',
                    AddCartSingleType::class,
                    //null,
                    $cartItem,
                    [
                        //'product' => $ProductsAndClassCategories[$Product->getId()],
                        'product' => $thisProduct,
                        'productclass' => $ProductClass,
                        //'ProductRanks' => $ProductRanks,
                        'allow_extra_fields' => true,
                    ]
                );
                $addCartForm = $builder->getForm();

                //$forms[$Product->getId()] = $addCartForm->createView();
                $forms[$ProductClass->getId()] = $addCartForm->createView();
            }
        }
        // 最新のデータ更新日
        $update_date = new \DateTime();;
        //if (count($update_dates) > 0) {
        //    $update_date = max($update_dates);
        //}
        log_info("addCart form", ['OK']);

        // タグリスト
        //$AllTags = [];
        
        //foreach ($ProductTags as $key => $value){
        //    $AllTags[] = $value;
        //}

        // 表示件数
        $builder = $this->formFactory->createNamedBuilder(
            'disp_number',
            ProductListMaxType::class,
            null,
            [
                'required' => false,
                'allow_extra_fields' => true,
            ]
        );
        if ($request->getMethod() === 'GET') {
            $builder->setMethod('GET');
        }

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_PRODUCT_INDEX_DISP, $event);

        $dispNumberForm = $builder->getForm();

        $dispNumberForm->handleRequest($request);

        // ソート順
        $builder = $this->formFactory->createNamedBuilder(
            'orderby',
            ProductListOrderByType::class,
            null,
            [
                'required' => false,
                'allow_extra_fields' => true,
            ]
        );
        if ($request->getMethod() === 'GET') {
            $builder->setMethod('GET');
        }

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_PRODUCT_INDEX_ORDER, $event);

        $orderByForm = $builder->getForm();

        $orderByForm->handleRequest($request);

        

        log_info(
            '商品一覧',
            [
                'subtitle' => $this->getPageTitle($searchData),
                'pagination' => $pagination,
                'search_form' => $searchForm->createView(),
                'disp_number_form' => $dispNumberForm->createView(),
                'order_by_form' => $orderByForm->createView(),
                'forms' => $forms,
                'SearchTag' => $tag,
                'Category' => $Category,
                'hasClassCategory1' => $hasClassCategory1,
                'hasClassCategory2' => $hasClassCategory2,
                'hasOldPrice' => $hasOldPrice,
                'update_date' => $update_date,
                'page_type' => $page_type,
            ]
        );

        $discountRate = $this->BaseInfo->isOptionDiscount() ? $this->BaseInfo->getOptionDiscountRate() : 100;
        
        // お気に入りアイコンが出るチェック
        $has_finish_order = false;
        if ($this->isGranted('ROLE_USER')) {
           $Customer = $this->getUser();
           if($Customer){
               $has_finish_order = $this->orderRepository->checkFavoriteIconStatus($Customer);
           }
        }
        $seo = $Category ? $Category->getCategorySeo() : null;
        return [
            'kaitori_page_title' => $seo ? $seo->getTitle() : null,
            'kaitori_page_keywords' => $seo ? $seo->getKeyword() : null,
            'kaitori_page_description' => $seo ? $seo->getDescription() : null,
            'subtitle' => $this->getPageTitle($searchData),
            'pagination' => $pagination,
            'search_form' => $searchForm->createView(),
            'disp_number_form' => $dispNumberForm->createView(),
            'order_by_form' => $orderByForm->createView(),
            'forms' => $forms,
            'Category' => $Category,
            'SearchTag' => $tag,
            'hasClassCategory1' => $hasClassCategory1,
            'hasClassCategory2' => $hasClassCategory2,
            'hasOldPrice' => $hasOldPrice,
            'update_date' => $update_date,
            'SelectedTag' => $tag,
            'allTags' => $allTags,
            'FavoriteProducts' => $FavoriteProducts,
            'DiscountRate' => $discountRate,
            'NewProducts' => $NewProducts,
            'productclass_id' => $productclass_id,
            'page_type' => $page_type,
            'option_addcart_time' => $this->BaseInfo->getOptionAddcartTime(),
            'option_request_time' => $this->BaseInfo->getOptionRequestTime(),
            'has_finish_order' => $has_finish_order
        ];
    }

    /**
     * 商品一覧画面.
     *
     * @Route("/products/all/list", name="product_all_list")
     * @Template("Product/list.twig")
     */
    public function index_for_all(Request $request, Paginator $paginator)
    {

        // Doctrine SQLFilter
        if ($this->BaseInfo->isOptionNostockHidden()) {
            $this->entityManager->getFilters()->enable('option_nostock_hidden');
        }

        // searchForm
        /* @var $builder \Symfony\Component\Form\FormBuilderInterface */
        $builder = $this->formFactory->createNamedBuilder('', SearchProductType::class);

        if ($request->getMethod() === 'GET') {
            $builder->setMethod('GET');
        }

        $tag_id = $request->get('tag_id');
        $tag = null;
        if($tag_id){
           $tag = $this->tagRepository->find($tag_id);
        }

         // ProductClass
        $productclass_id = $request->get('productclass_id');

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_ALL_PRODUCT_INDEX_INITIALIZE, $event);

        /* @var $searchForm \Symfony\Component\Form\FormInterface */
        $searchForm = $builder->getForm();

        $searchForm->handleRequest($request);

        // paginator
        $allTagSearchData = $searchForm->getData();

        $searchData = $searchForm->getData();

        $searchData['tag_id'] = $tag;
        $allTags = $this->getAllTags($allTagSearchData,$request,$paginator);

        if($searchData["name"]){
            $this->banDenySearch($searchData["name"]);
        }

        $result = $this->productRepository->getQueryBuilderBySearchDataAll($searchData);
        if($searchData["name"]){
            $this->saveProductSearchHistory($searchData, $result);
        }
        /** @var SlidingPagination $pagination */
        $pagination = $paginator->paginate(
            $result,
            !empty($request->query->get('pageno')) ? $request->query->get('pageno') : 1,
            !empty($searchData['disp_number']) ? $searchData['disp_number']->getId() : $this->productListMaxRepository->findOneBy([], ['sort_no' => 'DESC'])->getId()
        );
        
        $Category = $searchForm->get('category_id')->getData();
        if($pagination->getTotalItemCount() == 0){
             return $Category;
        }

        $ids = [];
        foreach ($pagination as $Product) {
            $ids[] = $Product->getId();
        }
        $ProductsAndClassCategories = $this->productRepository->findProductsWithSortedClassCategories($ids, 'p.id');

        // addCart form
        $forms = [];
        $hasClassCategory1 = false;
        $hasClassCategory2 = false;
        $hasOldPrice = false;
        $update_dates = [];
        $FavoriteProducts = [];
        $NewProducts = [];

        foreach ($pagination as $Product) {
            $thisProduct = $ProductsAndClassCategories[$Product->getId()];
            if (!is_null($Product->getClassName1())) {
                $hasClassCategory1 = true;
            }
            if (!is_null($Product->getClassName2())) {
                $hasClassCategory2 = true;
            }

            // customerFavorite
            $is_favorite = false;
            if ($this->isGranted('ROLE_USER')) {
                $Customer = $this->getUser();
                $is_favorite = $this->customerFavoriteProductRepository->isFavorite($Customer, $Product);
                $FavoriteProducts[$Product->getId()] = $is_favorite;
            } else {
                $FavoriteProducts[$Product->getId()] = false;
            }

            $ProductClasses = $thisProduct->getProductClasses();
            foreach ($ProductClasses as $ProductClass) {
                // データ更新日
                //foreach($ProductClass->getProductPrices() as $ProductPrice) {
                //    $update_dates[] = $ProductPrice->getUpdateDate();
                //}

                // 中古買取あり
                if ((int)$ProductClass->getPriceOld() > 0 ) {
                    $hasOldPrice = true;
                }

                // 強化買取商品
                $is_newProduct = $this->productRecommendRepository->isNewProduct($ProductClass);
                $NewProducts[$ProductClass->getId()] = $is_newProduct;

                $cartItem = new CartItem();

                /* @var $builder \Symfony\Component\Form\FormBuilderInterface */
                $builder = $this->formFactory->createNamedBuilder(
                    '',
                    AddCartSingleType::class,
                    $cartItem,
                    [
                        'product' => $thisProduct,
                        'productclass' => $ProductClass,
                        'allow_extra_fields' => true,
                    ]
                );
                $addCartForm = $builder->getForm();

                $forms[$ProductClass->getId()] = $addCartForm->createView();
            }
        }

        // 最新のデータ更新日
        $update_date = new \DateTime();;
        //if (count($update_dates) > 0) {
        //    $update_date = max($update_dates);
        //}

        // 表示件数
        $builder = $this->formFactory->createNamedBuilder(
            'disp_number',
            ProductListMaxType::class,
            null,
            [
                'required' => false,
                'allow_extra_fields' => true,
            ]
        );
        if ($request->getMethod() === 'GET') {
            $builder->setMethod('GET');
        }

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_PRODUCT_INDEX_DISP, $event);

        $dispNumberForm = $builder->getForm();

        $dispNumberForm->handleRequest($request);

        // ソート順
        $builder = $this->formFactory->createNamedBuilder(
            'orderby',
            ProductListOrderByType::class,
            null,
            [
                'required' => false,
                'allow_extra_fields' => true,
            ]
        );
        if ($request->getMethod() === 'GET') {
            $builder->setMethod('GET');
        }

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_PRODUCT_INDEX_ORDER, $event);

        $orderByForm = $builder->getForm();

        $orderByForm->handleRequest($request);

        $discountRate = $this->BaseInfo->isOptionDiscount() ? $this->BaseInfo->getOptionDiscountRate() : 100;

        // お気に入りアイコンが出るチェック
        $has_finish_order = false;
        if ($this->isGranted('ROLE_USER')) {
           $Customer = $this->getUser();
           if($Customer){
               $has_finish_order = $this->orderRepository->checkFavoriteIconStatus($Customer);
           }
        }
 
        return [
            'subtitle' => $this->getPageTitle($searchData),
            'pagination' => $pagination,
            'search_form' => $searchForm->createView(),
            'disp_number_form' => $dispNumberForm->createView(),
            'order_by_form' => $orderByForm->createView(),
            'forms' => $forms,
            'SearchTag' => $tag,
            'SelectedTag' => $tag,
            'Category' => $Category,
            'hasClassCategory1' => $hasClassCategory1,
            'hasClassCategory2' => $hasClassCategory2,
            'hasOldPrice' => $hasOldPrice,
            'update_date' => $update_date,
            'allTags' => $allTags,
            'FavoriteProducts' => $FavoriteProducts,
            'DiscountRate' => $discountRate,
            'NewProducts' => $NewProducts,
            'productclass_id' => $productclass_id,
            'page_type' => $request->get('page_type'),
            'option_addcart_time' => $this->BaseInfo->getOptionAddcartTime(),
            'option_request_time' => $this->BaseInfo->getOptionRequestTime(),
            'has_finish_order' => $has_finish_order
        ];
    }

    /**
     * 商品強化商品一覧画面.
     */
    public function index_for_new(Request $request, Category $category, $saleType, $page_type, $paginator)
    {
        //$request->query->set('last_category_id', null);
        // Doctrine SQLFilter
        if ($this->BaseInfo->isOptionNostockHidden()) {
            $this->entityManager->getFilters()->enable('option_nostock_hidden');
        }

        // search
        $recommendQeury = $this->productRecommendRepository->getRecommendQuery($saleType);
        $recommendQeury->getQuery()
            ->useResultCache(true, $this->eccubeConfig['eccube_result_cache_lifetime']);
        /** @var SlidingPagination $pagination */
        $pagination = $paginator->paginate(
            $recommendQeury,
            !empty($request->query->get('pageno')) ? $request->query->get('pageno') : 1,
            48
        );
        // addCart form
        $resultProductRecommends = [];
        $forms = [];
        $hasClassCategory1 = false;
        $hasClassCategory2 = false;
        $hasOldPrice = false;
        $update_dates = [];
        $ProductTags = [];
        $FavoriteProducts = [];
        foreach ($pagination as $productRecommend) {
            $ProductClass = $productRecommend->getProductClass();
            $Product = $ProductClass->getProduct();
            if ($Product->isEnable() == false) {
                continue;
            }
            $resultProductRecommends[] = $productRecommend;

            if (!is_null($Product->getClassName1())) {
                $hasClassCategory1 = true;
            }
            if (!is_null($Product->getClassName2())) {
                $hasClassCategory2 = true;
            }

            // customerFavorite
            $is_favorite = false;
            if ($this->isGranted('ROLE_USER')) {
                $Customer = $this->getUser();
                $is_favorite = $this->customerFavoriteProductRepository->isFavorite($Customer, $Product);
                $FavoriteProducts[$Product->getId()] = $is_favorite;
            } else {
                $FavoriteProducts[$Product->getId()] = false;
            }
            
            // タグ
            foreach($Product->getProductTag() as $ProductTag) {
                $Tag = $ProductTag->getTag();
                if ($Tag) {
                    $ProductTags[$Tag->getId()] = $Tag;
                }
            }

            // データ更新日
            //foreach($ProductClass->getProductPrices() as $ProductPrice) {
            //    $update_dates[] = $ProductPrice->getUpdateDate();
            //}

            // 中古買取あり
            if ((int)$ProductClass->getPriceOld() > 0 ) {
                $hasOldPrice = true;
            }

            $cartItem = new CartItem();

            /* @var $builder \Symfony\Component\Form\FormBuilderInterface */
            $builder = $this->formFactory->createNamedBuilder(
                '',
                AddCartSingleType::class,
                $cartItem,
                [
                    'product' => $Product,
                    'productclass' => $ProductClass,
                    'allow_extra_fields' => true,
                ]
            );
            $addCartForm = $builder->getForm();

            $forms[$ProductClass->getId()] = $addCartForm->createView();

        }
        // 最新のデータ更新日
        $update_date = new \DateTime();;
        //if (count($update_dates) > 0) {
        //    $update_date = max($update_dates);
        //}

        // タグリスト
        $AllTags = [];
        foreach ($ProductTags as $key => $value){
            $AllTags[] = $value;
        }

        log_info(
            '商品一覧',
            [
                'forms' => $forms,
                'Category' => $category,
                'hasClassCategory1' => $hasClassCategory1,
                'hasClassCategory2' => $hasClassCategory2,
                'hasOldPrice' => $hasOldPrice,
                'update_date' => $update_date,
                'page_type' => $page_type,
            ]
        );

        $discountRate = $this->BaseInfo->isOptionDiscount() ? $this->BaseInfo->getOptionDiscountRate() : 100;

        // お気に入りアイコンが出るチェック
        $has_finish_order = false;
        if ($this->isGranted('ROLE_USER')) {
           $Customer = $this->getUser();
           if($Customer){
             $has_finish_order = $this->orderRepository->checkFavoriteIconStatus($Customer);
           }
        }

        return [
            'forms' => $forms,
            'Recommends' => $pagination,
            'Category' => $category,
            'hasClassCategory1' => $hasClassCategory1,
            'hasClassCategory2' => $hasClassCategory2,
            'hasOldPrice' => $hasOldPrice,
            'update_date' => $update_date,
            'AllTags' => $AllTags,
            'FavoriteProducts' => $FavoriteProducts,
            'DiscountRate' => $discountRate,
            'page_type' => $page_type,
            'option_addcart_time' => $this->BaseInfo->getOptionAddcartTime(),
            'option_request_time' => $this->BaseInfo->getOptionRequestTime(),
            'has_finish_order' => $has_finish_order
        ];
    }

    /**
     * 商品詳細画面.
     *
     * @Route("/products/class_detail/{id}", name="product_class_detail", methods={"GET"}, requirements={"id" = "\d+"})
     * @Template("Product2/detail_class.twig")
     *
     * @param Request $request
     * @param ProductClass $ProductClass
     *
     * @return array
     */
    public function detail_class(Request $request, ProductClass $ProductClass)
    {
        $Product = $ProductClass->getProduct();
        if (!$this->checkVisibility($Product)) {
            throw new NotFoundHttpException();
        }

        $cartItem = new CartItem();
        $cartItem->setProductClass($ProductClass);

        //新品
        $ProductRanks = [];
        if ((!is_null($ProductClass) && $ProductClass->hasProductRank())) {
            $ProductRanks = $ProductClass->getProductRankNew();
        } else {
            $ProductRanks = $Product->getProductRankNew();
        }

        foreach($ProductRanks as $ProductRank) {
            $cartItem->addProductRank($ProductRank);
        }

        //中古
        $ProductRank2 = [];
        if ((!is_null($ProductClass) && $ProductClass->hasProductRank())) {
            $ProductRank2 = $ProductClass->getProductRankOld();
        } else {
            $ProductRank2 = $Product->getProductRankOld();
        }

        foreach($ProductRank2 as $ProductRank) {
            $cartItem->addProductRank2($ProductRank);
        }

        $builder = $this->formFactory->createNamedBuilder(
            '',
            AddCartSingleType::class,
            $cartItem,
            [
                'product' => $Product,
                'productclass' => $ProductClass,
                'id_add_product_id' => false,
            ]
        );

        $event = new EventArgs(
            [
                'builder' => $builder,
                'Product' => $Product,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_PRODUCT_DETAIL_INITIALIZE, $event);

        $is_favorite = false;
        if ($this->isGranted('ROLE_USER')) {
            $Customer = $this->getUser();
            $is_favorite = $this->customerFavoriteProductRepository->isFavorite($Customer, $Product);
        }

        return [
            'title' => $this->title,
            'subtitle' => $Product->getName(),
            'form' => $builder->getForm()->createView(),
            'Product' => $Product,
            'ProductClass' => $ProductClass,
            'is_favorite' => $is_favorite,
        ];
    }

    /**
     * 商品詳細画面.
     *
     * @Route("/products/detail/{id}", name="product_detail", methods={"GET"}, requirements={"id" = "\d+"})
     * @Template("Product2/detail.twig")
     * @ParamConverter("Product", options={"repository_method" = "findWithSortedClassCategories"})
     *
     * @param Request $request
     * @param Product $Product
     *
     * @return array
     */
    public function detail(Request $request, Product $Product)
    {
        if (!$this->checkVisibility($Product)) {
            throw new NotFoundHttpException();
        }

        $builder = $this->formFactory->createNamedBuilder(
            '',
            AddCartType::class,
            null,
            [
                'product' => $Product,
                'id_add_product_id' => false,
            ]
        );

        $event = new EventArgs(
            [
                'builder' => $builder,
                'Product' => $Product,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_PRODUCT_DETAIL_INITIALIZE, $event);

        $is_favorite = false;
        if ($this->isGranted('ROLE_USER')) {
            $Customer = $this->getUser();
            $is_favorite = $this->customerFavoriteProductRepository->isFavorite($Customer, $Product);
        }

        return [
            'title' => $this->title,
            'subtitle' => $Product->getName(),
            'form' => $builder->getForm()->createView(),
            'Product' => $Product,
            'is_favorite' => $is_favorite,
        ];
    }

    /**
     * お気に入り追加.
     *
     * @Route("/favorite/add/{id}", name="product_add_favorite", requirements={"id" = "\d+"})
     */
    public function addFavorite(Request $request, Product $Product)
    {
        $errorMessages = [];
        $this->checkVisibility($Product);

        $event = new EventArgs(
            [
                'Product' => $Product,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_PRODUCT_FAVORITE_ADD_INITIALIZE, $event);

        if ($this->isGranted('ROLE_USER')) {
            $Customer = $this->getUser();

            // お気に入りチェック
            $is_count_little_twiv = true;
            if($Customer){
               $count = $this->customerFavoriteProductRepository->isAddCustomerFavorite($Customer);
               if($count >= 12){
                  $is_count_little_twiv = false;
               }
            }

            if($is_count_little_twiv == true){
               $is_favorite = $this->customerFavoriteProductRepository->existsFavorite($Customer, $Product);
               if(!$is_favorite) {
                   $this->customerFavoriteProductRepository->addFavorite($Customer, $Product);
               }
               $this->session->getFlashBag()->set('product_detail.just_added_favorite', $Product->getId());

               $event = new EventArgs(
                   [
                       'Product' => $Product,
                   ],
                   $request
               );
               $this->eventDispatcher->dispatch(EccubeEvents::FRONT_PRODUCT_FAVORITE_ADD_COMPLETE, $event);

               if ($event->getResponse() !== null) {
                   return $event->getResponse();
               }

               //if ($request->isXmlHttpRequest()) {
                   // ajaxでのリクエストの場合は結果をjson形式で返す。

                   // 初期化
                   $done = null;
                   $messages = [];

                   if (empty($errorMessages)) {
                       // エラーが発生していない場合
                       $done = true;
                       array_push($messages, trans('front.product.add_favorite_complete'));
                   } else {
                       // エラーが発生している場合
                       $done = false;
                       array_push($messages, trans('front.product.add_favorite_error'));
                   }

                   return $this->json(['done' => $done, 'messages' => $messages]);
               //}
            
            }else{
              $errorMessages[] = 'お気に入りに商品が12件まで登録出来ます。';
              $event = new EventArgs(
                [
                    'Product' => $Product,
                ],
                $request
              );
              $this->eventDispatcher->dispatch(EccubeEvents::FRONT_PRODUCT_FAVORITE_ADD_COMPLETE, $event);

              // 初期化
              $done = null;
              $messages = [];

              if (empty($errorMessages)) {
                  // エラーが発生していない場合
                  $done = true;
                  array_push($messages, trans('front.product.add_favorite_complete'));
              } else {
                  // エラーが発生している場合
                  $done = false;
                  $messages = $errorMessages;
              }

              return $this->json(['done' => $done, 'messages' => $messages]);

            }
        } else {
            // 非会員の場合
            $errorMessages[] = '会員の方がお気に入り商品を追加可能です。先にログインしていただきますようお願いいたします。';
            $event = new EventArgs(
                [
                    'Product' => $Product,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::FRONT_PRODUCT_FAVORITE_ADD_COMPLETE, $event);

            // 初期化
            $done = null;
            $messages = [];

            if (empty($errorMessages)) {
                // エラーが発生していない場合
                $done = true;
                array_push($messages, trans('front.product.add_favorite_complete'));
            } else {
                // エラーが発生している場合
                $done = false;
                $messages = $errorMessages;
            }

            return $this->json(['done' => $done, 'messages' => $messages]);

        }
    }

    /**
     * お気に入り商品を削除する.
     *
     * @Route("/favorite/delete/{id}", name="product_remove_favorite", methods={"DELETE"}, requirements={"id" = "\d+"})
     */
    public function delete(Request $request, Product $Product)
    {
        $errorMessages = [];

        $this->isTokenValid();

        $Customer = $this->getUser();

        log_info('お気に入り商品削除開始', [$Customer->getId(), $Product->getId()]);

        $CustomerFavoriteProduct = $this->customerFavoriteProductRepository->findOneBy(['Customer' => $Customer, 'Product' => $Product]);

        if ($CustomerFavoriteProduct) {
            $this->customerFavoriteProductRepository->delete($CustomerFavoriteProduct);
        } else {
            $errorMessages[] = 'お気に入り商品の削除に失敗しました。';
        }

        // $event = new EventArgs(
        //     [
        //         'Customer' => $Customer,
        //         'CustomerFavoriteProduct' => $CustomerFavoriteProduct,
        //     ], $request
        // );
        // $this->eventDispatcher->dispatch(EccubeEvents::FRONT_MYPAGE_MYPAGE_DELETE_COMPLETE, $event);

        log_info('お気に入り商品削除完了', [$Customer->getId(), $CustomerFavoriteProduct->getId()]);

        // 初期化
        $done = null;
        $messages = [];

        if (empty($errorMessages)) {
            // エラーが発生していない場合
            $done = true;
            array_push($messages, trans('front.product.add_favorite_complete'));
        } else {
            // エラーが発生している場合
            $done = false;
            $messages = $errorMessages;
        }

        return $this->json(['done' => $done, 'messages' => $messages]);
    }

    /**
     * カートに追加.
     *
     * @Route("/cart/add/{id}", name="product_add_cart", methods={"POST"}, requirements={"id" = "\d+"})
     */
    public function addCart(Request $request, Product $Product)
    {
        // エラーメッセージの配列
        $errorMessages = [];
        if (!$this->checkVisibility($Product)) {
            throw new NotFoundHttpException();
        }

        $this->cartService->reset();

        $product_class_id = $request->get('ProductClass');
        $ProductClass = null;
        if ($product_class_id) {
            foreach($Product->getProductClasses() as $class) {
                if ($class->getId() == $product_class_id) {
                    $ProductClass = $class;
                    break;
                }
            }
        }
        log_info("product_class_id, ProductClass",[$product_class_id, $ProductClass]);

        $CartItem = new CartItem();
        $builder = $this->formFactory->createNamedBuilder(
            '',
            AddCartSingleType::class,
            $CartItem,
            [
                'product' => $Product,
                'productclass' => $ProductClass,
                'id_add_product_id' => false,
            ]
        );

        $event = new EventArgs(
            [
                'builder' => $builder,
                'Product' => $Product,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_PRODUCT_CART_ADD_INITIALIZE, $event);

        /* @var $form \Symfony\Component\Form\FormInterface */
        $form = $builder->getForm();
        $form->handleRequest($request);

        if (!$form->isValid()) {
            throw new NotFoundHttpException();
        }

        $addCartData = $form->getData();

        log_info(
            'カート追加処理開始',
            [
                'product_id' => $Product->getId(),
                'product_class_id' => $addCartData['product_class_id'],
                'quantity' => $addCartData['quantity'],
                'ranktype' => $addCartData['ranktype'],
                'ProductRanks' => $addCartData['ProductRanks'],
                'ProductRank2s' => $addCartData['ProductRank2s'],
            ]
        );

        // 査定チェック
        $PriceCheck = true;

        $RankType = $addCartData['ranktype'];
        log_info("査定チェック:RankType", [$RankType]);
        if (is_null($RankType)) {
            $ProductClass = $addCartData['product_class_id'];
            if (!$ProductClass instanceof ProductClass) {
                $ProductClassId = $ProductClass;
                $ProductClass = $this->entityManager
                    ->getRepository(ProductClass::class)
                    ->find($ProductClassId);
                //if (!is_null($ProductClass)) {
                //    if ( (int)$ProductClass->getPriceOld() <= 0 && (int)$ProductClass->getPriceNew() > 0 ) {
                        // 新品買取のみ
                //        $RankType = $this->rankTypeRepository->find(RankType::RANK_TYPE_NEW);
                //        $addCartData['ranktype'] = $RankType;
                //    }
                //    if ( (int)$ProductClass->getPriceNew() <= 0 && (int)$ProductClass->getPriceOld() > 0 ) {
                        // 中古買取のみ
                //        $RankType = $this->rankTypeRepository->find(RankType::RANK_TYPE_OLD);
                //        $addCartData['ranktype'] = $RankType;
                //    }
                //}
            }
        }

        $ProductRanks =$addCartData['ProductRanks'];
        $ProductRank2s =$addCartData['ProductRank2s'];
        log_info("査定チェック:ProductRanks", [$RankType, $ProductRanks]);
        if ($RankType) {
            log_info("査定チェック(RankType->id)", [$RankType->getId()]);
            if (is_null($RankType->getId())) {
                $PriceCheck = false;
                //$errorMessages[] = 'カートに追加されません。先に価格査定を行ってください。';
                $errorMessages[] = 'カートに追加されません。先に商品状態を選択してください。';
                $this->saveAlarm('カートに追加されません。先に商品状態を選択してください。');
            } else {
                $select_options = [];
                if($RankType->getId() == RankType::RANK_TYPE_NEW){
                    $select_options = $ProductRanks;
                }else if($RankType->getId() == RankType::RANK_TYPE_OLD){
                    $select_options = $ProductRank2s;
                }
                $show_options = $ProductClass->getProductPriceOptionHierarchies($RankType->getId());
                if($show_options > 1 && count($select_options) == 0){
                    $PriceCheck = false;
                    $errorMessages[] = "商品のオプショウも一緒に選択してください";
                    $this->saveAlarm('カートに追加されません。先に商品状態を選択してください。');
                }
            }
        } else {
                $PriceCheck = false;
                // $errorMessages[] = 'カートに追加されません。先に価格査定を行ってください。';
                $errorMessages[] = 'カートに追加されません。先に商品状態を選択してください。';
                $this->saveAlarm('カートに追加されません。先に商品状態を選択してください。');
        }

        if($PriceCheck){
           // 買取価格チェック
           $price = $this->calcPrice($addCartData['product_class_id'], 
                   $addCartData['ranktype'], $addCartData['ProductRanks'], $addCartData['ProductRank2s']);
           if (is_null($price) || $price <= 0) {
               $PriceCheck = false;
               // $errorMessages[] = 'カートに追加されません。先に価格査定を行ってください。';
               $errorMessages[] = 'カートに追加されません。先に商品状態を選択してください。';
               $this->saveAlarm('カートに追加されません。先に商品状態を選択してください。');
           }
        }
        
        // 数量
        $quantity = $addCartData['quantity'];
        if($PriceCheck){
           if (is_null($quantity) || $quantity < 1) {
               $PriceCheck = false;
               $errorMessages[] = '数量は１以上に入力してください。';
               $this->saveAlarm('数量は１以上に入力してください。');
           }else{
               //残件チェック
               if($ProductClass && !$ProductClass->isStockUnlimited()){
                     $leftStock = $ProductClass->getStock() - $ProductClass->getProductStock()->getStock();
                     if($leftStock - $quantity < 0){
                           $PriceCheck = false;
                           // $errorMessages[] = "商品". $ProductClass->formattedProductName() . "は残り" . $leftStock."個です";
                           $errorMessages[] = "商品". $ProductClass->formattedProductName() . "は買取数が超えてます。";
                           $this->saveAlarm("商品". $ProductClass->formattedProductName() . "は買取数が超えてます。");
                     }
                }
           }
        }

        if($PriceCheck){
             //会員限定商品チェック
              if($ProductClass->getSaleLimit() > 0){
                 if(!$this->getUser()){
                        $PriceCheck = false;
                        $errorMessages[] = "商品". $ProductClass->formattedProductName() . "は会員限定商品です";
                        $this->saveAlarm("商品". $ProductClass->formattedProductName() . "は会員限定商品です");
                 }else{
                       //一人買取制限チェック
                       $history = $this->sumQuantityForProduct($this->getUser()->getId(),$ProductClass->getId());
                       $saleTotal = $quantity + $history["quantity"];
                       if($saleTotal > $ProductClass->getSaleLimit()){
                          $PriceCheck = false;
                          //$errorMessages[] = "商品". $ProductClass->formattedProductName() . "は一人" . $ProductClass->getSaleLimit() . "台までです";
                          $errorMessages[] = "商品". $ProductClass->formattedProductName() . "は買取数が超えてます。";
                          $this->saveAlarm("商品". $ProductClass->formattedProductName() . "は買取数が超えてます。");
                       }
                }
             }
        }

        if ($PriceCheck) {
            // カートへ追加
            $this->cartService->addProduct($addCartData['product_class_id'], $addCartData['quantity'], 
                $addCartData['ranktype'], $addCartData['ProductRanks'], $addCartData['ProductRank2s']);

            // 明細の正規化
            $Carts = $this->cartService->getCarts();

            foreach ($Carts as $Cart) {
                $result = $this->purchaseFlow->validate($Cart, new PurchaseContext($Cart, $this->getUser()));
                // 復旧不可のエラーが発生した場合は追加した明細を削除.
                if ($result->hasError()) {
                    $this->cartService->removeProduct($addCartData['product_class_id']);
                    foreach ($result->getErrors() as $error) {
                        $errorMessages[] = $error->getMessage();
                    }
                }
                foreach ($result->getWarning() as $warning) {
                    $errorMessages[] = $warning->getMessage();
                }
            }

            $this->cartService->save();

            log_info(
                'カート追加処理完了',
                [
                    'product_id' => $Product->getId(),
                    'product_class_id' => $addCartData['product_class_id'],
                    'quantity' => $addCartData['quantity'],
                    'ranktype' => $addCartData['ranktype'],
                    'ProductRanks' => $addCartData['ProductRanks'],
                    'ProductRank2s' => $addCartData['ProductRank2s'],
                ]
            );
        }

        $event = new EventArgs(
            [
                'form' => $form,
                'Product' => $Product,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_PRODUCT_CART_ADD_COMPLETE, $event);

        if ($event->getResponse() !== null) {
            return $event->getResponse();
        }

        if ($request->isXmlHttpRequest()) {
            // ajaxでのリクエストの場合は結果をjson形式で返す。

            // 初期化
            $done = null;
            $messages = [];

            if (empty($errorMessages)) {
                // エラーが発生していない場合
                $done = true;
                array_push($messages, trans('front.product.add_cart_complete'));
            } else {
                // エラーが発生している場合
                $done = false;
                $messages = $errorMessages;
            }

            return $this->json(['done' => $done, 'messages' => $messages]);
        } else {
            // ajax以外でのリクエストの場合はカート画面へリダイレクト
            foreach ($errorMessages as $errorMessage) {
                $this->addRequestError($errorMessage);
            }

            return $this->redirectToRoute('cart');
        }
    }

    /**
     * 価格査定.(not used)
     *
     * @Route("/cart/calc_cartitem/{id}", name="product_calc_cartitem", methods={"POST"}, requirements={"id" = "\d+"})
     */
    public function calcCartitem(Request $request, Product $Product)
    {
        //$this->isTokenValid();
        // エラーメッセージの配列
        $errorMessages = [];
        if (!$this->checkVisibility($Product)) {
            throw new NotFoundHttpException();
        }

        $builder = $this->formFactory->createNamedBuilder(
            '',
            AddCartSingleType::class,
            null,
            [
                'product' => $Product,
                'productclass' => null,
                'id_add_product_id' => false,
                //'csrf_protection' => false,
            ]
        );

        /* @var $form \Symfony\Component\Form\FormInterface */
        $form = $builder->getForm();
        $form->handleRequest($request);

        if (!$form->isValid()) {
            //throw new NotFoundHttpException();
        }

        $addCartData = $form->getData();

        log_info(
            'カート計算処理開始',
            [
                'product_id' => $Product->getId(),
                'product_class_id' => $addCartData['product_class_id'],
                'quantity' => $addCartData['quantity'],
                'ranktype' => $addCartData['ranktype'],
                'ProductRanks' => $addCartData['ProductRanks'],
                'ProductRank2s' => $addCartData['ProductRank2s'],
            ]
        );

        // 買取価格計算
        log_info("ProductRanks",[count($addCartData['ProductRanks'])]);
        log_info("ProductRank2s",[count($addCartData['ProductRank2s'])]);
        $price = $this->calcPrice($addCartData['product_class_id'], $addCartData['ranktype'], $addCartData['ProductRanks'], $addCartData['ProductRank2s']);
    
        log_info(
            'カート計算処理完了',
            [
                'product_id' => $Product->getId(),
                'product_class_id' => $addCartData['product_class_id'],
                'quantity' => $addCartData['quantity'],
                'ranktype' => $addCartData['ranktype'],
                'ProductRanks' => $addCartData['ProductRanks'],
                'ProductRank2s' => $addCartData['ProductRank2s'],
                'price' => $price,
            ]
        );

        if ($request->isXmlHttpRequest()) {
            // ajaxでのリクエストの場合は結果をjson形式で返す。

            // 初期化
            $done = null;
            $messages = [];

            if (empty($errorMessages)) {
                // エラーが発生していない場合
                $done = true;
                array_push($messages, trans('front.product.add_cart_complete'));
            } else {
                // エラーが発生している場合
                $done = false;
                $messages = $errorMessages;
            }

            return $this->json(['done' => $done, 'price' => $price, 'messages' => $messages]);
        } else {
            // ajax以外でのリクエストの場合はカート画面へリダイレクト
            foreach ($errorMessages as $errorMessage) {
                $this->addRequestError($errorMessage);
            }

            return $this->redirectToRoute('cart');
        }
    }

    /**
     * 買取価格計算.
     *
     * @param $ProductClass ProductClass 商品規格
     * @param $RankType RankType 新品/中古
     * @param $ProductRanks array 商品ランク
     *
     * @return int 買取価格
     */
    protected function calcPrice($ProductClass, $RankType, $ProductRanks, $ProductRank2s)
    {
        if (!$ProductClass instanceof ProductClass) {
            $ProductClassId = $ProductClass;
            $ProductClass = $this->entityManager
                ->getRepository(ProductClass::class)
                ->find($ProductClassId);
            if (is_null($ProductClass)) {
                return null;
            }
        }

        $ClassCategory1 = $ProductClass->getClassCategory1();
        if ($ClassCategory1 && !$ClassCategory1->isVisible()) {
            return null;
        }
        $ClassCategory2 = $ProductClass->getClassCategory2();
        if ($ClassCategory2 && !$ClassCategory2->isVisible()) {
            return null;
        }

        log_info("Price",[$ProductClass->getPriceOld(), $ProductClass->getPriceNew()]);
        if ($RankType && RankType::RANK_TYPE_NEW === $RankType->getId()) {
            $price = (int)$ProductClass->getPriceNew();
            $rank_type_id = $RankType->getId();
        } else if ($RankType && RankType::RANK_TYPE_OLD === $RankType->getId()) {
            $price = (int)$ProductClass->getPriceOld();
            $rank_type_id = $RankType->getId();
        } else {
            if ((int)$ProductClass->getPriceOld() <=0 && (int)$ProductClass->getPriceNew() > 0 ) {
                // 新品買取
                $price = (int)$ProductClass->getPriceNew();
                $rank_type_id = RankType::RANK_TYPE_NEW;
            } else if ((int)$ProductClass->getPriceNew() <=0 && (int)$ProductClass->getPriceOld() > 0 ) {
                // 中古買取
                $price = (int)$ProductClass->getPriceOld();
                $rank_type_id = RankType::RANK_TYPE_OLD;
            } else {
                return null;
            }
            
        }
        log_info("Price",[$price, $rank_type_id]);

        log_info("ProductRanks",[count($ProductRanks)]);
        foreach($ProductRanks as $ProductRank) {
            //log_info("ProductRank1", [$ProductRank, $ProductRank->getId(), $ProductRank->getRankTypeId(), $ProductRank->isVisible() ]);
            if ( $ProductRank->getRankTypeId() === $rank_type_id ) {
                $price = $price + (int)$ProductRank->getPriceChange();
            }
        }
        log_info("ProductRank2s",[count($ProductRank2s)]);
        foreach($ProductRank2s as $ProductRank) {
            //log_info("ProductRank2", [$ProductRank, $ProductRank->getId(), $ProductRank->getRankTypeId(), $ProductRank->isVisible() ]);
            if ( $ProductRank->getRankTypeId() === $rank_type_id ) {
                $price = $price + (int)$ProductRank->getPriceChange();
            }
        }

        return $price;
    }

    /**
     * ページタイトルの設定
     *
     * @param  null|array $searchData
     *
     * @return str
     */
    protected function getPageTitle($searchData)
    {
        if (isset($searchData['name']) && !empty($searchData['name'])) {
            return trans('front.product.search_result');
        } elseif (isset($searchData['category_id']) && $searchData['category_id']) {
            return $searchData['category_id']->getName();
        } else {
            return trans('front.product.all_products');
        }
    }

    /**
     * 閲覧可能な商品かどうかを判定
     *
     * @param Product $Product
     *
     * @return boolean 閲覧可能な場合はtrue
     */
    protected function checkVisibility(Product $Product)
    {
        $is_admin = $this->session->has('_security_admin');

        // 管理ユーザの場合はステータスやオプションにかかわらず閲覧可能.
        if (!$is_admin) {
            // 在庫なし商品の非表示オプションが有効な場合.
            // if ($this->BaseInfo->isOptionNostockHidden()) {
            //     if (!$Product->getStockFind()) {
            //         return false;
            //     }
            // }
            // 公開ステータスでない商品は表示しない.
            if ($Product->getStatus()->getId() !== ProductStatus::DISPLAY_SHOW) {
                return false;
            }
        }
        return true;
    }
    
    private function getAllTags($searchData,$request,$paginator)
    {
        //$qb = $this->productRepository->getQueryBuilderBySearchData($searchData);

        //$event = new EventArgs(
        //    [
        //        'searchData' => $searchData,
        //        'qb' => $qb,
        //    ],
        //    $request
        //);

        //$this->eventDispatcher->dispatch(EccubeEvents::FRONT_PRODUCT_INDEX_SEARCH, $event);

        //$searchData = $event->getArgument('searchData');
        
        //$query = $qb->getQuery()
        //    ->useResultCache(true, $this->eccubeConfig['eccube_result_cache_lifetime_short']);

        /** @var SlidingPagination $pagination */
        //$paginator->paginate(
        //    $query
        //    !empty($request->query->get('pageno')) ? $request->query->get('pageno') : 1,
        //    !empty($searchData['disp_number']) ? $searchData['disp_number']->getId() : $this->productListMaxRepository->findOneBy([], ['sort_no' => 'DESC'])->getId()
        //);

        $ProductTags = [];
        $pagination = $this->productRepository->getAllTagsByCategory($searchData);

        foreach ($pagination as $Product) {
           // タグ
           foreach($Product->getProductTag() as $ProductTag) {
              $Tag = $ProductTag->getTag();
              if ($Tag) {
                   $ProductTags[$Tag->getId()] = $Tag;
              }
           }
        }

        // タグリスト
        $AllTags = [];

        foreach ($ProductTags as $key => $value){
            $AllTags[] = $value;
        }

        return $AllTags;
    }
    
    /**
     * @param \Doctrine\ORM\EntityManagerInterface $em
     * @param array $excludes
     *
     * @return null|arr
     */
    protected function sumQuantityForProduct($customerId,$productClassId)
    {
         $sql = "
         SELECT 
            SUM(d0_.quantity) AS quantity 
         FROM 
            dtb_order_item d0_ 
         INNER JOIN 
            dtb_order d1_ 
         ON
            d0_.order_id = d1_.id 
         AND 
            d1_.discriminator_type IN ('order') 
         AND 
           (d0_.order_id = d1_.id) 
         INNER JOIN 
            mtb_order_status m2_ 
         ON 
            d1_.order_status_id = m2_.id 
         AND 
            m2_.discriminator_type 
         IN
            ('orderstatus') 
         AND 
            (d1_.order_status_id = m2_.id) 
         WHERE 
             (d1_.customer_id = :customerId
         AND
            d0_.product_class_id = :productClassId 
         AND 
            m2_.id NOT IN (:statues))
         AND 
            d0_.discriminator_type IN ('orderitem')
         AND
            TO_DAYS(d1_.create_date) = TO_DAYS(NOW())";

        $rsm = new ResultSetMapping();
        $rsm->addScalarResult('quantity', 'quantity');
        $query = $this->entityManager->createNativeQuery($sql, $rsm)
               ->setParameter('customerId', $customerId)
               ->setParameter('productClassId', $productClassId)
               ->setParameter('statues', $statues = [OrderStatus::PROCESSING, OrderStatus::CANCEL]);

        $result = $query->getOneOrNullResult();
        
        return $result;
    }

    /**
     * （SEO）商品一覧画面
     *
     * @Route("/category/{page_type}/{id}", name="seo_by_category", requirements={"page_type" = "\d+", "id" = "\d+"})
     */
    public function seo_by_category(Request $request, $page_type, Category $category, Paginator $paginator)
    {
        $template = $this->session->get('list_type') == "big" ? 'SEO/main_big.twig' : 'SEO/main_small.twig';
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            $template = 'SEO/mobile_product_list.twig';
        }
        $result = $this->index_by_category($request, $category, $paginator, $page_type);
        if(is_array($result)){
            return $this->render($template, $result);
        }
        return $this->renderHelp($request, $result, true);
    }

    private function renderHelp($request, $category, $is_seo = false)
    {
        $template = $is_seo ? 'SEO/main_help.twig' : 'Help/contact.twig';
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            $template = $is_seo ? 'SEO/mobile_help.twig' : 'Help/contact.twig';
        }
        $builder1 = $this->formFactory->createBuilder(ContactType::class);
        $is_customer = false;
        if ($this->isGranted('ROLE_USER')) {
           /** @var Customer $user */
           $user = $this->getUser();
           $Contact = new Contact();
           $Contact->setName01($user->getName01());
           $Contact->setName02($user->getName02());
           $Contact->setKana01($user->getKana01());
           $Contact->setKana02($user->getKana02());
           $Contact->setPostalCode($user->getPostalCode());
           $Contact->setPref($user->getPref());
           $Contact->setAddr01($user->getAddr01());
           $Contact->setAddr02($user->getAddr02());
           $Contact->setPhoneNumber($user->getPhoneNumber());
           $Contact->setEmail($user->getEmail());
           $Contact->setCustomer($user);
           $builder1->setData($Contact);
           $is_customer = true;
       }
       $form1 = $builder1->getForm();
       $seo = $category ? $category->getCategorySeo() : null;
       return $this->render($template, [
           'kaitori_page_title' => $seo ? $seo->getTitle() : null,
           'kaitori_page_keywords' => $seo ? $seo->getKeyword() : null,
           'kaitori_page_description' => $seo ? $seo->getDescription() : null,
           'form' => $form1->createView(),
           'page_type' => $request->get('page_type'),
           'Category' => $category,
           'is_customer' => $is_customer,
       ]);
    }

    private function saveAlarm($warning)
    {
       //アラーム情報              
       $alarm = new Alarm();
       if ($this->isGranted('ROLE_USER')) {
            $alarm->setCustomer($this->getUser());
       }
       $alarm->setMessage($warning);
       $this->alarmRepository->save($alarm);
    }

    private function banDenySearch($keyword){
        $ips = explode(",", $_SERVER['HTTP_X_FORWARDED_FOR']);            
        $sourceIp = trim($ips[0]);
        //host ip
        $shops = $this->shopInfoRepository->findAll();
        $shopIps = array_map(function($shop){
            return $shop->getNameEng();
        }, $shops);
        if(in_array($sourceIp, $shopIps)){
            return;
        }
        if(strpos($_SERVER['HTTP_USER_AGENT'], 'python') !== false){
            throw new NotFoundHttpException();
        }
        if(strpos($_SERVER['HTTP_USER_AGENT'], 'GoogleDocs') !== false){
            throw new NotFoundHttpException();
        }
        if(strpos($_SERVER['HTTP_USER_AGENT'], 'Google-Apps-Script') !== false){
            throw new NotFoundHttpException();
        }
        if(strpos($_SERVER['HTTP_USER_AGENT'], 'curl') !== false){
            throw new NotFoundHttpException();
        }
        if(is_numeric($keyword)){
            $searchCnt = $this->productSearchHistoryRepository->findByIp($sourceIp, '-1 day');
            if($searchCnt > 20){
                throw new NotFoundHttpException();
            }
        }else{
            $searchCnt = $this->productSearchHistoryRepository->findByIp($sourceIp, '-1 day');
            if($searchCnt > 50){
                throw new NotFoundHttpException();
            }
        }
        
    }
    private function saveProductSearchHistory($searchData, $result){
        //検索履歴に追加
        $history = new ProductSearchHistory();
        if($searchData["category_id"]){
            $history->setCategoryId($searchData["category_id"]->getId());
        }
        if ($this->getUser()) {
            $history->setCustomerId($this->getUser()->getId());
        }
        $history->setKeyword($searchData["name"]);
        $history->setProductCount(count($result));
        $ips = explode(",", $_SERVER['HTTP_X_FORWARDED_FOR']);            
        $sourceIp = trim($ips[0]);
        $history->setIp($sourceIp);
        $history->setAgent($_SERVER['HTTP_USER_AGENT']);
        $this->productSearchHistoryRepository->save($history);
    }
}
