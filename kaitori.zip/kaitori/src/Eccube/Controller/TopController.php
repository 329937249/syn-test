<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller;

use Symfony\Component\Routing\Annotation\Route;
use Eccube\Repository\CategoryRepository;
use SunCat\MobileDetectBundle\DeviceDetector\MobileDetector;
use Symfony\Component\HttpFoundation\Response;

class TopController extends AbstractController
{
    /**
     * @var MobileDetector
     */
    private $mobileDetector;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * TopController constructor.
     *
     * @param MobileDetector $mobileDetector
     */
    public function __construct(
        MobileDetector $mobileDetector, 
        CategoryRepository $categoryRepository) {
            $this->mobileDetector = $mobileDetector;
            $this->categoryRepository = $categoryRepository;
    }

    /**
     * @Route("/", name="homepage")
     */
    public function index()
    {
        $this->session->set('lcsdata.history.site_type', 'homepage');
        $template = 'index_top.twig';
        $kaitori_page_title = 'スマホ・携帯・家電・電化製品・日用品・Amazonギフト券買取・換金の買取なら買取専門の商店';
        $kaitori_page_keywords = 'スマホ買取,iPhone買取,高額買取,高価買取,新品買取,中古買取,携帯商店,家電買取,家電商店,日用品買取,日用商店,Amazonギフト券,買取,換金,現金化,売る,買取商店';
        $kaitori_page_description = 'スマートフォン（スマホ）、白ロム携帯電話の買取なら携帯商店にお任せ下さい！店頭買取は東京の新宿区でアクセス抜群！遠方の方は全国どこからでも家電の郵送買取OK！日用品の買取なら日用商店にお任せ下さい！店頭買取は東京の新宿区でアクセス抜群！遠方の方は全国どこからでも日用品の郵送買取OK！家電・電化製品の買取なら家電商店にお任せ下さい！店頭買取は東京の新宿区でアクセス抜群！遠方の方は全国どこからでも家電の郵送買取OK！Amazonギフト券の買取サイト。高額でアマゾンギフト券を売りたいなら高倍率で全国対応の買取商店へ';
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            $template = 'Mobile/frame/top.twig';
            return $this->render($template, [
                'page_name'=>'Mobile/kaitori_top',
                'body_class'=>'front_page',
                'page_type'=>'0',
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_keywords' => $kaitori_page_keywords,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render($template, [
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_keywords' => $kaitori_page_keywords,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     * @Route("/keitai", name="keitai")
     */
    public function index_keitai()
    {
        $category = $this->categoryRepository->find(7);
        $seo = $category ? $category->getCategorySeo() : null;
        $this->session->set('lcsdata.history.site_type', 'keitai');
        $template = 'index_keitai.twig';
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            $template = 'Mobile/frame/top.twig';
            return $this->render($template, [
                'page_name'=>'Main/keitai_top',
                'body_class'=>'front_page',
                'page_type'=>'1',
                'kaitori_page_title' => $seo ? $seo->getTitle() : null,
                'kaitori_page_keywords' => $seo ? $seo->getKeyword() : null,
                'kaitori_page_description' => $seo ? $seo->getDescription() : null,
            ]);
        }
        return $this->render($template, [
            'kaitori_page_title' => $seo ? $seo->getTitle() : null,
            'kaitori_page_keywords' => $seo ? $seo->getKeyword() : null,
            'kaitori_page_description' => $seo ? $seo->getDescription() : null,
        ]);
    }

    /**
     * @Route("/kaden", name="kaden")
     */
    public function index_kaden()
    {
        $category = $this->categoryRepository->find(8);
        $seo = $category ? $category->getCategorySeo() : null;
        $this->session->set('lcsdata.history.site_type', 'kaden');
        $template = 'index_kaden.twig';
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            $template = 'Mobile/frame/top.twig';
            return $this->render($template, [
                'page_name'=>'Main/kaden_top',
                'body_class'=>'front_page',
                'page_type'=>'2',
                'kaitori_page_title' => $seo ? $seo->getTitle() : null,
                'kaitori_page_keywords' => $seo ? $seo->getKeyword() : null,
                'kaitori_page_description' => $seo ? $seo->getDescription() : null,
            ]);
        }
        return $this->render($template, [
            'kaitori_page_title' => $seo ? $seo->getTitle() : null,
            'kaitori_page_keywords' => $seo ? $seo->getKeyword() : null,
            'kaitori_page_description' => $seo ? $seo->getDescription() : null,
        ]);
    }

    /**
     * @Route("/nitiyouhin", name="nitiyouhin")
     */
    public function index_nitiyouhin()
    {
        $category = $this->categoryRepository->find(9);
        $seo = $category ? $category->getCategorySeo() : null;
        $this->session->set('lcsdata.history.site_type', 'nitiyouhin');
        $template = 'index_nitiyouhin.twig';
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            $template = 'Mobile/frame/top.twig';
            return $this->render($template, [
                'page_name'=>'Main/nitiyouhin_top',
                'body_class'=>'front_page',
                'page_type'=>'3',
                'kaitori_page_title' => $seo ? $seo->getTitle() : null,
                'kaitori_page_keywords' => $seo ? $seo->getKeyword() : null,
                'kaitori_page_description' => $seo ? $seo->getDescription() : null,
            ]);
        }
        return $this->render($template, [
            'kaitori_page_title' => $seo ? $seo->getTitle() : null,
            'kaitori_page_keywords' => $seo ? $seo->getKeyword() : null,
            'kaitori_page_description' => $seo ? $seo->getDescription() : null,
        ]);
    }

    /**
     * @Route("/amazongift", name="amazongift")
     */
    public function index_amazongift()
    {
        $category = $this->categoryRepository->find(10);
        $seo = $category ? $category->getCategorySeo() : null;
        $this->session->set('lcsdata.history.site_type', 'amazongift');
        $template = 'index_amazongift.twig';
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            $template = 'Mobile/frame/top.twig';
            return $this->render($template, [
                'page_name'=>'Main/amazongift_top',
                'body_class'=>'front_page',
                'page_type'=>'4',
                'kaitori_page_title' => $seo ? $seo->getTitle() : null,
                'kaitori_page_keywords' => $seo ? $seo->getKeyword() : null,
                'kaitori_page_description' => $seo ? $seo->getDescription() : null,
            ]);
        }
        return $this->render($template, [
            'kaitori_page_title' => $seo ? $seo->getTitle() : null,
            'kaitori_page_keywords' => $seo ? $seo->getKeyword() : null,
            'kaitori_page_description' => $seo ? $seo->getDescription() : null,
        ]);
    }

    /**
     * （SEO）sitemap
     *
     * @Route("/sitemap.xml", name="seo_sitemap")
     */
    public function seo_sitemap()
    {
        // ツリー表示のため、ルートからのカテゴリを取得
        $TopCategories = $this->categoryRepository->getList(null);
        // dump($TopCategories);
        // die;
        $xml = $this->render('SEO/sitemap.twig', ['topCategories' => $TopCategories]);
        $response = new Response($xml->getContent(), 200, ['content-type' => 'text/xml']);
        return $response;
    }
}
