<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller;

use Symfony\Component\Routing\Annotation\Route;
use SunCat\MobileDetectBundle\DeviceDetector\MobileDetector;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Doctrine\ORM\Query\ResultSetMapping;

class HelpController extends AbstractController
{
    /**
     * @var MobileDetector
     */
    private $mobileDetector;

    /**
     * HelpController constructor.
     *
     * @param MobileDetector $mobileDetector
     */
    public function __construct(MobileDetector $mobileDetector) {
        $this->mobileDetector = $mobileDetector;
    }

    /**
     * ご利用ガイド(注意事項).
     *
     * @Route("/guide", name="help_guide")
     */
    public function guide()
    {
        $templatePrefix = 'Main/';
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => "0",
                'page_name' => "Mobile/help/guide",
                'body_class' => 'guide_page',
            ]);
        }
        return $this->render($templatePrefix . 'index_guide.twig', [
            'page_type' => "0",
        ]);
    }

    /**
     * 当サイトについて(会社概要).
     *
     * @Route("/aboutus", name="help_about")
     */
    public function about()
    {
        $templatePrefix = 'Main/';
        return $this->render($templatePrefix . 'index_about_top.twig', [
            'page_type' => "0",
        ]);

    }

    /**
     * プライバシーポリシー.
     *
     * @Route("/privacypolicy", name="help_privacy")
     */
    public function privacy()
    {
        $templatePrefix = 'Main/';
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => "0",
                'page_name' => 'Help/privacy',
                'body_class' => 'privacy_page',
            ]);
        }
        return $this->render($templatePrefix . 'index_privacy_top.twig', [
            'page_type' => "0",
        ]);
    }

    /**
     * 利用規約.
     *
     * @Route("/terms", name="help_agreement")
     */
    public function agreement()
    {
        $templatePrefix = 'Main/';
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => "0",
                'page_name' => "Help/agreement",
                'body_class' => 'agreement_page',
            ]);
        }
        return $this->render($templatePrefix . 'index_agreement.twig', [
            'page_type' => "0",
        ]);
    }

    /**
     * よくあるご質問.
     *
     * @Route("/faq", name="help_faq")
     */
    public function faq()
    {
        $templatePrefix = 'Main/';
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => "0",
                'page_name' => "Help/faq",
            ]);
        }
        return $this->render($templatePrefix . 'index_faq_top.twig', [
            'page_type' => "0",
        ]);
    }

    /**
     * 店舗案内.
     *
     * @Route("/shop", name="help_shop")
     */
    public function shop()
    {
        $templatePrefix = 'Main/';
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => "0",
                'page_name' => "Mobile/help/tenpo",
                'body_class' => "tenpo_page",
            ]);
        }
        return $this->render($templatePrefix . 'index_tenpo_top.twig', [
            'page_type' => "0",
        ]);
    }

    /**
     * 店頭買取の流れ.
     *
     * @Route("/shopflow", name="help_flow1")
     */
    public function flow1()
    {
        $templatePrefix = 'Main/';
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => "0",
                'page_name' => "Mobile/help/flow1",
                'body_class' => "flow_page",
            ]);
        }
        return $this->render($templatePrefix . 'index_flow1_top.twig', [
            'page_type' => "0",
        ]);
    }

    /**
     * 郵送買取の流れ.
     *
     * @Route("/mailingflow", name="help_flow2")
     */
    public function flow2()
    {
        $templatePrefix = 'Main/';
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => "0",
                'page_name' => "Mobile/help/flow2",
                'body_class' => "flow_page",
            ]);
        }
        return $this->render($templatePrefix . 'index_flow2_top.twig', [
            'page_type' => "0",
        ]);
    }

    /**
     * 法人買取の流れ.
     *
     * @Route("/corporateflow", name="help_flow3")
     */
    public function flow3()
    {
        $templatePrefix = 'Main/';
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => "0",
                'page_name' => "Mobile/help/flow3",
                'body_class' => "flow_page",
            ]);
        }
        return $this->render($templatePrefix . 'index_flow3_top.twig', [
            'page_type' => "0",
        ]);
    }

    /**
     *
     * @Route("/{page_type}/news/{id}", name="news_detail", requirements={"id" = "\d+","page_type" = "\d+"})
     *
     */
    public function news_detail($id,$page_type)
    {
        if (is_null($id)) {
            throw new NotFoundHttpException();
        }
        $templatePrefix = 'Main/';
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Help/news",
                'news_id' => $id,
                'body_class' => "news_page",
            ]);
        }
        if ($page_type == '0') {
            return $this->render($templatePrefix . 'index_news_top.twig', [
                 'news_id' => $id,
                 'page_type' => $page_type,
            ]);
        }

        return $this->render($templatePrefix . 'index_news.twig', [
                 'news_id' => $id,
                 'page_type' => $page_type,
        ]);
        
    }

    /**
     *
     * @Route("/help/doc", name="help_doc")
     *
     */
    public function doc_desc()
    {
        $templatePrefix = 'Main/';
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/doc",
                'body_class' => "flow_page",
            ]);
        }
        return $this->render($templatePrefix . 'index_doc.twig', [
            'page_type' => '0',
        ]);
    }

    /**
     *
     * @Route("/help/other/{id}", name="other")
     *
    */
    public function other($id){
       $sql = "select * from dtb_seo_page where seo_id =:seo_id";
       $rsm = new ResultSetMapping();
       $rsm->addScalarResult('title', 'seo_title');
       $rsm->addScalarResult('description', 'seo_description');
       $rsm->addScalarResult('content', 'seo_content');
       $rsm->addScalarResult('image1', 'seo_image');
       $query = $this->entityManager->createNativeQuery($sql, $rsm)
              ->setParameter('seo_id', $id);
       $result = $query->getResult();
       if(count($result) == 0){
          throw new NotFoundHttpException();
       }
       if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other",
                'body_class' => "flow_page",
                'kaitori_page_title' => $result[0]['seo_title'],
                'kaitori_page_description' => $result[0]['seo_description'],
                'seo_content' => $result[0]['seo_content'],
                'seo_image' => $result[0]['seo_image']
            ]);
        }
        return $this->render('Help/other.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $result[0]['seo_title'],
            'kaitori_page_description' => $result[0]['seo_description'],
            'seo_content' => $result[0]['seo_content'],
            'seo_image' => $result[0]['seo_image']
        ]);
    }

    /**
     *
     * @Route("/help/other1", name="other1")
     *
     */
    public function other1()
    {
        $kaitori_page_title = '中古スマホ市場の動向と、スマホ買取の現在 | スマホ・携帯・家電・電化製品・日用品・Amazonギフト券買取・換金の買取なら買取専門の商店';
        $kaitori_page_description = '携帯電話・家電・日用品の買取専門店「買取商店」のコラムです。スマホが不要になった際、「専門業者に買い取ってもらう」というのは、当たり前の選択肢になりました。今回はこれまでの中古スマホ市場の動向を振り返りつつ、スマホ買取の現在を考えていきましょう。';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other1",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other1.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     *
     * @Route("/help/other2", name="other2")
     *
     */
    public function other2()
    {
        $kaitori_page_title = '【スマホの基礎】知っておきたいスマホの種類と、購入時の選び方・買取に出すポイント | スマホ・携帯・家電・電化製品・日用品・Amazonギフト券買取・換金の買取なら買取専門の商店';
        $kaitori_page_description = '携帯電話・家電・日用品の買取専門店「買取商店」のコラムです。スマホ購入時は「何を基準にすれば？」と悩む方もいらっしゃるでしょう。購入時にユーザーが知っておきたいスマホの基礎知識とスマホ選びのポイント、スマホを買い取ってもらう際のポイントを解説します。';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other2",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other2.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     *
     * @Route("/help/other3", name="other3")
     *
     */
    public function other3()
    {
        $kaitori_page_title = 'Nintendo Switchを売りたい！買取方法とポイントをチェック | スマホ・携帯・家電・電化製品・日用品・Amazonギフト券買取・換金の買取なら買取専門の商店';
        $kaitori_page_description = '携帯電話・家電・日用品の買取専門店「買取商店」のコラムです。ゲーム機の中でも抜群の人気を誇る『Nintendo Switch（ニンテンドースイッチ）』を買取に出したいと考えてる皆様へ向け、主な買取方法や、高値で買取ってもらうポイントをまとめました。';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other3",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other3.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     *
     * @Route("/help/other4", name="other4")
     *
     */
    public function other4()
    {
        $kaitori_page_title = '使わなくなったスマホ、買取と下取りの違いは？ | スマホ・携帯・家電・電化製品・日用品・Amazonギフト券買取・換金の買取なら買取専門の商店';
        $kaitori_page_description = '携帯電話・家電・日用品の買取専門店「買取商店」のコラムです。買い替え時に気になるのが「それまで使っていたスマホをどうするか」ということ。スマホの買取と下取りの違いをはじめ、スマホを買取に出す際に知っておきたい情報をピックアップしてご紹介します。';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other4",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other4.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     *
     * @Route("/help/other5", name="other5")
     *
     */
    public function other5()
    {
        $kaitori_page_title = 'iPhoneとAndroidの違いは？　特徴を解説 | スマホ・携帯・家電・電化製品・日用品・Amazonギフト券買取・換金の買取なら買取専門の商店';
        $kaitori_page_description = '携帯電話・家電・日用品の買取専門店「買取商店」のコラムです。日本のスマホユーザーから圧倒的に支持を受けているiPhoneとAndroidの違いは何でしょうか。ここではiPhoneとAndroidそれぞれの特徴や違いと、両者のメリット・デメリットを解説します。';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other5",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other5.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     *
     * @Route("/help/other6", name="other6")
     *
     */
    public function other6()
    {
        $kaitori_page_title = 'Nintendo Switchは子供から大人まで楽しめるデジタルゲーム機 | スマホ・携帯・家電・電化製品・日用品・Amazonギフト券買取・換金の買取なら買取専門の商店';
        $kaitori_page_description = '携帯電話・家電・日用品の買取専門店「買取商店」のコラムです。デジタルゲームはもはや娯楽の中でも身近なものになりました。人気のゲーム機「Nintendo Switch(ニンテンドースイッチ)」の特徴や、遊ぶ上で知っておきたい知識を見ていきます。';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other6",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other6.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     *
     * @Route("/help/other7", name="other7")
     *
     */
    public function other7()
    {
        $kaitori_page_title = 'スマホ初期化方法は？使用済みスマートフォンを安全に処分するために | スマホ・携帯・家電・電化製品・日用品・Amazonギフト券買取・換金の買取なら買取専門の商店';
        $kaitori_page_description = '携帯電話・家電・日用品の買取専門店「買取商店」のコラムです。スマートフォン機種変時に注意したいのが、使用済みスマホの処分ではないでしょうか。今回はスマホ処分時に必ず行いたい初期化方法の一般的な手順や、スマートフォン処分における注意点をご紹介します。';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other7",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other7.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     *
     * @Route("/help/other8", name="other8")
     *
     */
    public function other8()
    {
        $kaitori_page_title = '白ロムとは？キャリアのスマホを安く買って使うコツ | スマホ・携帯・家電・電化製品・日用品・Amazonギフト券買取・換金の買取なら買取専門の商店';
        $kaitori_page_description = '携帯電話・家電・日用品の買取専門店「買取商店」のコラムです。近年、人気が高まっているのが「白ロム」と呼ばれる中古スマホではないでしょうか。この記事では、白ロムの上手な使い方や、白ロムのメリット、白ロムを購入する際の注意点などを解説しましょう。';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other8",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other8.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     *
     * @Route("/help/other9", name="other9")
     *
     */
    public function other9()
    {
        $kaitori_page_title = '白ロムとSIMフリースマホの違いとは？ | スマホ・携帯・家電・電化製品・日用品・Amazonギフト券買取・換金の買取なら買取専門の商店';
        $kaitori_page_description = '携帯電話・家電・日用品の買取専門店「買取商店」のコラムです。白ロム人気の上昇と共にSIMフリースマホの人気も高まっています。ここでは白ロムとSIMフリースマホの違いや、白ロムとSIMフリースマホそれぞれのメリット・デメリットなどを解説します。';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other9",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other9.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     *
     * @Route("/help/other10", name="other10")
     *
     */
    public function other10()
    {
        $kaitori_page_title = 'iPhone買取のポイントをご紹介！ | スマホ・携帯・家電・電化製品・日用品・Amazonギフト券買取・換金の買取なら買取専門の商店';
        $kaitori_page_description = '携帯電話・家電・日用品の買取専門店「買取商店」のコラムです。iPhoneを新しいものに買い替える際、使用済機種の買取依頼を検討する方も多いでしょう。iPhoneを売却する際のポイントと、2021年時点の主な人気iPhoneモデルをピックアップし紹介します。';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other10",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other10.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     *
     * @Route("/help/other11", name="other11")
     *
     */
    public function other11()
    {
        $kaitori_page_title = 'iPhone 8シリーズの特徴・性能は？根強い人気を誇るその理由';
        $kaitori_page_description = '携帯電話・家電・日用品の買取専門店「買取商店」のコラムです。iPhoneを新しいものに買い替える際、使用済機種の買取依頼を検討する方も多いでしょう。iPhoneを売却する際のポイントと、2021年時点の主な人気iPhoneモデルをピックアップし紹介します。';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other11",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other11.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     *
     * @Route("/help/other12", name="other12")
     *
     */
    public function other12()
    {
        $kaitori_page_title = 'iPhone 11 Proをはじめ、iPhone11シリーズの機能や特徴を解説！';
        $kaitori_page_description = '携帯電話・家電・日用品の買取専門店「買取商店」のコラムです。iPhoneを新しいものに買い替える際、使用済機種の買取依頼を検討する方も多いでしょう。iPhoneを売却する際のポイントと、2021年時点の主な人気iPhoneモデルをピックアップし紹介します。';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other12",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other12.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     *
     * @Route("/help/other13", name="other13")
     *
     */
    public function other13()
    {
        $kaitori_page_title = 'iPhone12機種別の特徴は？高価買取してもらう方法は？';
        $kaitori_page_description = '携帯電話・家電・日用品の買取専門店「買取商店」のコラムです。iPhoneを新しいものに買い替える際、使用済機種の買取依頼を検討する方も多いでしょう。iPhoneを売却する際のポイントと、2021年時点の主な人気iPhoneモデルをピックアップし紹介します。';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other13",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other13.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     *
     * @Route("/help/other14", name="other14")
     *
     */
    public function other14()
    {
        $kaitori_page_title = '機種変更するアイフォン 11は買い取りと下取りどちらがオトク？';
        $kaitori_page_description = '携帯電話・家電・日用品の買取専門店「買取商店」のコラムです。iPhoneを新しいものに買い替える際、使用済機種の買取依頼を検討する方も多いでしょう。iPhoneを売却する際のポイントと、2021年時点の主な人気iPhoneモデルをピックアップし紹介します。';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other14",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other14.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     *
     * @Route("/help/other15", name="other15")
     *
     */
    public function other15()
    {
        $kaitori_page_title = 'アイフォン買取の準備やデータの引き継ぎ方法を解説！買取価格アップのコツも紹介';
        $kaitori_page_description = '携帯電話・家電・日用品の買取専門店「買取商店」のコラムです。iPhoneを新しいものに買い替える際、使用済機種の買取依頼を検討する方も多いでしょう。iPhoneを売却する際のポイントと、2021年時点の主な人気iPhoneモデルをピックアップし紹介します。';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other15",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other15.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     *
     * @Route("/help/other16", name="other16")
     *
     */
    public function other16()
    {
        $kaitori_page_title = 'iPhone SE（第2世代）の機能と特徴、買取に出すポイントを紹介';
        $kaitori_page_description = '携帯電話・家電・日用品の買取専門店「買取商店」のコラムです。iPhoneを新しいものに買い替える際、使用済機種の買取依頼を検討する方も多いでしょう。iPhoneを売却する際のポイントと、2021年時点の主な人気iPhoneモデルをピックアップし紹介します。';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other16",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other16.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     *
     * @Route("/help/other17", name="other17")
     *
     */
    public function other17()
    {
        $kaitori_page_title = 'iPhoneの買い取り価格の相場は？買い取り価格が減額になる７つの要素とは？';
        $kaitori_page_description = '携帯電話・家電・日用品の買取専門店「買取商店」のコラムです。iPhoneを新しいものに買い替える際、使用済機種の買取依頼を検討する方も多いでしょう。iPhoneを売却する際のポイントと、2021年時点の主な人気iPhoneモデルをピックアップし紹介します。';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other17",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other17.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     *
     * @Route("/help/other18", name="other18")
     *
     */
    public function other18()
    {
        $kaitori_page_title = 'iPhone13は高値で売れる！知っておきたい買取価格を上げる５つのポイント';
        $kaitori_page_description = '携帯電話・家電・日用品の買取専門店「買取商店」のコラムです。iPhoneを新しいものに買い替える際、使用済機種の買取依頼を検討する方も多いでしょう。iPhoneを売却する際のポイントと、2021年時点の主な人気iPhoneモデルをピックアップし紹介します。';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other18",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other18.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     *
     * @Route("/help/other19", name="other19")
     *
     */
    public function other19()
    {
        $kaitori_page_title = 'iPhone Xシリーズの機能・特徴は？全面ディスプレイで顔認証へ進化';
        $kaitori_page_description = '携帯電話・家電・日用品の買取専門店「買取商店」のコラムです。iPhoneを新しいものに買い替える際、使用済機種の買取依頼を検討する方も多いでしょう。iPhoneを売却する際のポイントと、2021年時点の主な人気iPhoneモデルをピックアップし紹介します。';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other19",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other19.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     *
     * @Route("/help/other20", name="other20")
     *
     */
    public function other20()
    {
        $kaitori_page_title = 'iPhone 7/7 Plusの機能や、おすすめポイントについて解説';
        $kaitori_page_description = '携帯電話・家電・日用品の買取専門店「買取商店」のコラムです。iPhoneを新しいものに買い替える際、使用済機種の買取依頼を検討する方も多いでしょう。iPhoneを売却する際のポイントと、2021年時点の主な人気iPhoneモデルをピックアップし紹介します。';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other20",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other20.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     *
     * @Route("/help/other21", name="other21")
     *
     */
    public function other21()
    {
        $kaitori_page_title = 'iPhoneを買取に出す前に必ずやっておくべき９つのこと';
        $kaitori_page_description = '携帯電話・家電・日用品の買取専門店「買取商店」のコラムです。iPhoneを新しいものに買い替える際、使用済機種の買取依頼を検討する方も多いでしょう。iPhoneを売却する際のポイントと、2021年時点の主な人気iPhoneモデルをピックアップし紹介します。';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other21",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other21.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     *
     * @Route("/help/other22", name="other22")
     *
     */
    public function other22()
    {
        $kaitori_page_title = 'SIMロック解除・SIMフリーとは？概要や方法、メリットを解説';
        $kaitori_page_description = '携帯電話・家電・日用品の買取専門店「買取商店」のコラムです。iPhoneを新しいものに買い替える際、使用済機種の買取依頼を検討する方も多いでしょう。iPhoneを売却する際のポイントと、2021年時点の主な人気iPhoneモデルをピックアップし紹介します。';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other22",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other22.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     *
     * @Route("/help/other23", name="other23")
     *
     */
    public function other23()
    {
        $kaitori_page_title = 'シニアがiPhoneを使うべき理由と賢い使い方';
        $kaitori_page_description = 'シニアがiPhoneを使うべき理由と賢い使い方';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other23",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other23.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     *
     * @Route("/help/other24", name="other24")
     *
     */
    public function other24()
    {
        $kaitori_page_title = 'iPhoneの裏技を活用して仕事や日常のクオリティを向上させる';
        $kaitori_page_description = 'iPhoneの裏技を活用して仕事や日常のクオリティを向上させる';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other24",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other24.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }

    /**
     *
     * @Route("/help/other25", name="other25")
     *
     */
    public function other25()
    {
        $kaitori_page_title = '｢Pixel 6a｣と｢iPhone SE（第3世代）｣を徹底比較！';
        $kaitori_page_description = '｢Pixel 6a｣と｢iPhone SE（第3世代）｣を徹底比較！';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => "Mobile/help/other25",
                'body_class' => "flow_page",
                'kaitori_page_title' => $kaitori_page_title,
                'kaitori_page_description' => $kaitori_page_description,
            ]);
        }
        return $this->render('Help/other25.twig', [
            'page_type' => '0',
            'kaitori_page_title' => $kaitori_page_title,
            'kaitori_page_description' => $kaitori_page_description,
        ]);
    }
}
