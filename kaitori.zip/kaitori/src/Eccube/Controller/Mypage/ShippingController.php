<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Mypage;

use Doctrine\Common\Collections\ArrayCollection;
use Eccube\Controller\AbstractController;
use Eccube\Entity\Order;
use Eccube\Entity\OrderItem;
use Eccube\Entity\Shipping;
use Eccube\Form\Type\Admin\SearchProductType;
use Eccube\Form\Type\Admin\ShippingType;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\DeliveryRepository;
use Eccube\Repository\OrderItemRepository;
use Eccube\Repository\ShippingRepository;
use Eccube\Repository\OrderRepository;
use Eccube\Service\MailService;
use Eccube\Service\OrderStateMachine;
use Eccube\Service\PurchaseFlow\PurchaseContext;
use Eccube\Service\PurchaseFlow\PurchaseFlow;
use Eccube\Service\TaxRuleService;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\SerializerInterface;

class ShippingController extends AbstractController
{
    /**
     * @var OrderItemRepository
     */
    protected $orderItemRepository;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var DeliveryRepository
     */
    protected $deliveryRepository;

    /**
     * @var TaxRuleService
     */
    protected $taxRuleService;

    /**
     * @var ShippingRepository
     */
    protected $shippingRepository;
    
    /**
     * @var OrderRepository
     */
    protected $orderRepository;

    /**
     * @var SerializerInterface
     */
    protected $serializer;

    /**
     * @var \Eccube\Service\MailService
     */
    protected $mailService;

    /**
     * @var OrderStateMachine
     */
    protected $orderStateMachine;

    /**
     * @var PurchaseFlow
     */
    protected $purchaseFlow;

    /**
     * EditController constructor.
     *
     * @param MailService $mailService
     * @param OrderItemRepository $orderItemRepository
     * @param CategoryRepository $categoryRepository
     * @param DeliveryRepository $deliveryRepository
     * @param TaxRuleService $taxRuleService
     * @param ShippingRepository $shippingRepository
     * @param OrderRepository $orderRepository
     * @param SerializerInterface $serializer
     * @param OrderStateMachine $orderStateMachine
     * @param PurchaseFlow $orderPurchaseFlow
     */
    public function __construct(
        MailService $mailService,
        OrderItemRepository $orderItemRepository,
        CategoryRepository $categoryRepository,
        DeliveryRepository $deliveryRepository,
        TaxRuleService $taxRuleService,
        ShippingRepository $shippingRepository,
        OrderRepository $orderRepository,
        SerializerInterface $serializer,
        OrderStateMachine $orderStateMachine,
        PurchaseFlow $orderPurchaseFlow
    ) {
        $this->mailService = $mailService;
        $this->orderItemRepository = $orderItemRepository;
        $this->categoryRepository = $categoryRepository;
        $this->deliveryRepository = $deliveryRepository;
        $this->taxRuleService = $taxRuleService;
        $this->shippingRepository = $shippingRepository;
        $this->orderRepository = $orderRepository;
        $this->serializer = $serializer;
        $this->orderStateMachine = $orderStateMachine;
        $this->purchaseFlow = $orderPurchaseFlow;
    }

    // TODO
    /**
     * @Route("/%eccube_admin_route%/mypage/preview_notify_mail/ids", name="admin_mypage_preview_notify_mail", methods={"POST"})
     *
     * @param Request $request
     *
     * @return Response
     *
     * @throws \Twig_Error
     */
    public function previewOrderNotifyMail(Request $request)
    {
        log_info('previewOrderNotifyMail.......');
        $idArr = explode(',', $request->get('ids'));
        $orders = [];
        $Customer = null;
        foreach($idArr as $id){
            $Order = $this->orderRepository
                ->find($id);
            if($Order){
            array_push($orders,$Order);
            $Customer = $Order->getCustomer();
            }
        }
        
        return new Response($this->mailService->getMypageNotifyMailBody($orders,$Customer, null, true));
    }
    
    /**
     * @Route("/%eccube_admin_route%/mypage/cancel/preview_notify_mail/{id}", requirements={"id" = "\d+"}, name="admin_mypage_cancel_preview_notify_mail")
     *
     * @param Shipping $Shipping
     *
     * @return Response
     *
     * @throws \Twig_Error
     */
    public function previewMypageCancelNotifyMail(Shipping $Shipping)
    {
        return new Response($this->mailService->getMypageCancelNotifyMailBody($Shipping, null, true));
    }
    // TODO

    /**
     * @Route("/%eccube_admin_route%/mypage/notify_mail/{id}", requirements={"id" = "\d+"}, name="admin_mypage_notify_mail", methods={"PUT"})
     *
     * @param Shipping $Shipping
     *
     * @return JsonResponse
     *
     * @throws \Twig_Error
     */
    public function notifyMail(Shipping $Shipping)
    {
        $this->isTokenValid();

        $this->mailService->sendOrderNotifyMail($Shipping);

        $Shipping->setMailSendDate(new \DateTime());
        $this->shippingRepository->save($Shipping);
        $this->entityManager->flush();

        return $this->json([
            'mail' => true,
            'shipped' => false,
        ]);
    }
    
     /**
     * @Route("/%eccube_admin_route%/mypage_cancel/notify_mail/{id}", requirements={"id" = "\d+"}, name="admin_mypage_cancel_notify_mail", methods={"PUT"})
     *
     * @param Shipping $Shipping
     *
     * @return JsonResponse
     *
     * @throws \Twig_Error
     */
    public function notifyCancelMail(Shipping $Shipping)
    {
        $this->isTokenValid();

        $this->mailService->sendMypageCancelNotifyMail($Shipping);

        $Shipping->setMailSendDate(new \DateTime());
        $this->shippingRepository->save($Shipping);
        $this->entityManager->flush();

        return $this->json([
            'mail' => true,
            'shipped' => false,
        ]);
    }
    
}
