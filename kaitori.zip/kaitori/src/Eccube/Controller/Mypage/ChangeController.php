<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Mypage;

use Eccube\Controller\AbstractController;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Front\EntryType;
use Eccube\Repository\CustomerRepository;
use Eccube\Repository\OrderRepository;
use Eccube\Repository\CustomerCertsDocRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorage;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;
use Symfony\Component\Security\Core\Encoder\EncoderFactoryInterface;
use Eccube\Entity\Master\ModifiedReason;
use Eccube\Entity\Master\PersionType;
use SunCat\MobileDetectBundle\DeviceDetector\MobileDetector;

class ChangeController extends AbstractController
{

    /**
     * @var MobileDetector
     */
    private $mobileDetector;

    /**
     * @var TokenStorage
     */
    protected $tokenStorage;

    /**
     * @var CustomerRepository
     */
    protected $customerRepository;
    
    /**
     * @var OrderRepository
     */
    protected $orderRepository;
    
    /**
     * @var CustomerCertsDocRepository
     */
    protected $customerCertsDocRepository;

    /**
     * @var EncoderFactoryInterface
     */
    protected $encoderFactory;

    public function __construct(
        CustomerRepository $customerRepository,
        OrderRepository $orderRepository,
        CustomerCertsDocRepository $customerCertsDocRepository,
        EncoderFactoryInterface $encoderFactory,
        TokenStorageInterface $tokenStorage,
        MobileDetector $mobileDetector
    ) {
        $this->customerRepository = $customerRepository;
        $this->orderRepository = $orderRepository;
        $this->customerCertsDocRepository = $customerCertsDocRepository;
        $this->encoderFactory = $encoderFactory;
        $this->tokenStorage = $tokenStorage;
        $this->mobileDetector = $mobileDetector;
    }

    /**
     * 会員情報編集画面.
     *
     * @Route("/mypage/change", name="mypage_change")
     * @Template("Mypage/change.twig")
     */
    public function index(Request $request)
    {
        $Customer = $this->getUser();
        $LoginCustomer = clone $Customer;
        $OriginPersonalDocFile = null;
        $OriginCorporationDocFile = null;
        if($PersonalDocFile = $Customer->getPersonalDocFile()){
            $OriginPersonalDocFile = clone $PersonalDocFile;
        }
        if($CorporationDocFile = $Customer->getCorporationDocFile()){
            $OriginCorporationDocFile = clone $CorporationDocFile;
        }
      
        $this->entityManager->detach($LoginCustomer);

        $previous_password = $Customer->getPassword();
        $Customer->setPassword($this->eccubeConfig['eccube_default_password']);

        /* @var $builder \Symfony\Component\Form\FormBuilderInterface */
        $builder = $this->formFactory->createBuilder(EntryType::class, $Customer);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'Customer' => $Customer,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_MYPAGE_CHANGE_INDEX_INITIALIZE, $event);

        /* @var $form \Symfony\Component\Form\FormInterface */
        $form = $builder->getForm();
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            log_info('会員編集開始');
            
            if ($Customer->getPassword() === $this->eccubeConfig['eccube_default_password']) {
                $Customer->setPassword($previous_password);
            } else {
                $encoder = $this->encoderFactory->getEncoder($Customer);
                if ($Customer->getSalt() === null) {
                    $Customer->setSalt($encoder->createSalt());
                }
                $Customer->setPassword(
                    $encoder->encodePassword($Customer->getPassword(), $Customer->getSalt())
                );
            }
            // 変更フラグ、変更事由、確認済フラグを更新する
            $Customer = $this->changeCustomerModifyFlag($Customer,$LoginCustomer);
            $this->changeCustomerCertDocModifyFlag($Customer,$OriginPersonalDocFile,$OriginCorporationDocFile);
            //$this->changeOrderModifyFlag($Customer,$LoginCustomer);

            $this->entityManager->flush();

            log_info('会員編集完了');

            $event = new EventArgs(
                [
                    'form' => $form,
                    'Customer' => $Customer,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::FRONT_MYPAGE_CHANGE_INDEX_COMPLETE, $event);

            return $this->redirect($this->generateUrl('mypage_change_complete'));
        }

        $this->tokenStorage->getToken()->setUser($LoginCustomer);

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/mypage/change.twig', [
                'form' => $form->createView(),
                'Customer' => $Customer,
            ]);
        }

        return [
            'form' => $form->createView(),
            'Customer' => $Customer,
        ];
    }

    /**
     * 会員情報編集完了画面.
     *
     * @Route("/mypage/change_complete", name="mypage_change_complete")
     * @Template("Mypage/change_complete.twig")
     */
    public function complete(Request $request)
    {
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/mypage/change_complete.twig', []);
        }
        return [];
    }
    
     /**
     * 更新変更フラグ.
     * @param 
     * @param 
     * @return Customer
     */
    private function checkCustomerModifyFlag($Customer,$OriginCustomer)
    {
        // 個人
        if($Customer->getPersionType()->getId() == PersionType :: PERSION ){
            // 電話番号
            if($OriginCustomer->getPhoneNumber() != $Customer->getPhoneNumber()){
                return true;
            }
            // 郵便番号
            if($OriginCustomer->getPostalCode() != $Customer->getPostalCode()){
                return true;
            }
            // 都道府県
            if($OriginCustomer->getPref()->getId() != $Customer->getPref()->getId()){
                return true;
            }
            // 市区町村・番地
            if($OriginCustomer->getAddr01() != $Customer->getAddr01()){
                return true;
            }
            // マンション等
            if($OriginCustomer->getAddr02() != $Customer->getAddr02()){
                return true;
            }
            // メールアドレス
            if($OriginCustomer->getEmail() != $Customer->getEmail()){
                return true;
            }
            // 職業
            if($OriginCustomer->getJob()->getId() != $Customer->getJob()->getId()){
                return true;
            }
            // 振込口座
            if($OriginCustomer->getAccountBank() != $Customer->getAccountBank()){
                return true;
            }
            if($this->checkAccountType($Customer,$OriginCustomer)){
                return true;
            }
            if($OriginCustomer->getAccountBranch() != $Customer->getAccountBranch()){
                return true;
            }
            if($OriginCustomer->getAccountName() != $Customer->getAccountName()){
                return true;
            }
            if($OriginCustomer->getAccountNo() != $Customer->getAccountNo()){
                return true;
            }
        }

        // 法人
        if($Customer->getPersionType()->getId() == PersionType :: CORPORATION ){
          // 電話番号
          if($OriginCustomer->getCompanyPhoneNumber() != $Customer->getCompanyPhoneNumber()){
               return true;
          }
          // 郵便番号
          if($OriginCustomer->getCompanyPostalCode() != $Customer->getCompanyPostalCode()){
               return true;
          }
          // 都道府県
          if($OriginCustomer->getCompanyPref()->getId() != $Customer->getCompanyPref()->getId()){
               return true;
          }
          // 市区町村・番地
          if($OriginCustomer->getCompanyAddr01() != $Customer->getCompanyAddr01()){
               return true;
          }
          // マンション等
          if($OriginCustomer->getCompanyAddr02() != $Customer->getCompanyAddr02()){
               return true;
          }
       }
       return false;
    }

    // 住所変更等
    private function changeCustomerModifyFlag($Customer,$OriginCustomer)
    {
        $is_modify = $this->checkCustomerModifyFlag($Customer,$OriginCustomer);
        
        if($is_modify){
            $ModifiedReason = $this->entityManager->find(ModifiedReason::class,  ModifiedReason::ADDRESS_MODIFY);
            $Customer->setModifiedFlg(1)
                    ->setModifiedVerified(0)
                    ->setModifiedReason($ModifiedReason);
        }
        return $Customer;
    }

    private function checkAccountType($Customer,$OriginCustomer)
    {
        if(is_null($OriginCustomer->getAccountType()) &&  is_null($Customer->getAccountType())){
            return false;
        }else if(is_null($OriginCustomer->getAccountType()) &&  null != $Customer->getAccountType()){
            return true;
        }else if(is_null($Customer->getAccountType()) &&  null != $OriginCustomer->getAccountType()){
            return true;
        }else{
            if($OriginCustomer->getAccountType()->getId() != $Customer->getAccountType()->getId()){
                 return true;
            }
        }
    }

    private function checkPersionalDocModifyFlag($PersonalDocFile,$OriginPersonalDocFile)
    {
        
        // 個人
        if(is_null($PersonalDocFile) || is_null($OriginPersonalDocFile)){
            $this->session->set('mypage_upload_img',false);
            $this->session->set('mypage_delete_img',false);
            return false;
        }
            //個人書類種別
        if($PersonalDocFile->getCertsDocId() != $OriginPersonalDocFile->getCertsDocId()){
            return true;
        }
        if($this->session->get('mypage_upload_img') || $this->session->get('mypage_delete_img')){
            return true;
        }
        return false;
    }

    private function checkCorporationDocModifyFlag($CorporationDocFile,$OriginCorporationDocFile)
    {
        // 法人
        if(is_null($CorporationDocFile) || is_null($OriginCorporationDocFile)){
            return false;
        }

        //個人書類種別
        if($CorporationDocFile->getCertsDocId() != $OriginCorporationDocFile->getCertsDocId()){
            return true;
        }
        return false;
    }
    
     /**
     * 更新書類変更フラグ.
     * @param 
     * @param 
     * 
     */
    private function changeCustomerCertDocModifyFlag($Customer,$OriginPersonalDocFile,$OriginCorporationDocFile)
    {
      // 個人
       //「書類対応」４、個人修正場合、ModifiedFlg＝true ModifiedVerified=false
      if($PersonalDocFile = $Customer->getPersonalDocFile()){
           $doc_modified_flag = $this->checkPersionalDocModifyFlag($PersonalDocFile,$OriginPersonalDocFile);
           if($doc_modified_flag){
                $ModifiedReason = $this->entityManager->find(ModifiedReason::class,  ModifiedReason::DOC_MODIFY);
                $PersonalDocFile->setModifiedFlg(1)
                     ->setModifiedVerified(0)
                     ->setModifiedReason($ModifiedReason);
                $this->entityManager->persist($PersonalDocFile);
                $this->entityManager->flush();
                $this->session->set('mypage_upload_img',false);
                $this->session->set('mypage_delete_img',false);
                //$this->changeOrderModifyFlag($Customer,$LoginCustomer);

                return;
           }    
      }
      // 法人書類変更
      if($CorporationDocFile = $Customer->getCorporationDocFile()){
           $doc_modified_flag = $this->checkCorporationDocModifyFlag($CorporationDocFile,$OriginCorporationDocFile);
           if($doc_modified_flag){
            $ModifiedReason = $this->entityManager->find(ModifiedReason::class,  ModifiedReason::DOC_MODIFY);
            $CorporationDocFile->setModifiedFlg(1)
                     ->setModifiedVerified(0)
                     ->setModifiedReason($ModifiedReason);
            $this->entityManager->persist($CorporationDocFile);
            $this->entityManager->flush();
            $this->session->set('mypage_upload_img',false);
            $this->session->set('mypage_delete_img',false);
            //$this->changeOrderModifyFlag($Customer,$LoginCustomer);
           }
        }
    }
    
    /**
     * 更新申込変更フラグ.
     * @param 
     * @param 
     * 
     */
    private function changeOrderModifyFlag($Customer)
    {
      // 個人
      if($Customer->getPersionType()->getId() == PersionType :: PERSION ){
         if($PersonalDocFile = $Customer->getPersonalDocFile()){
             $this->orderRepository->updatePersonalAllOrders($PersonalDocFile);
         }
      }
      
      // 法人
      if($Customer->getPersionType()->getId() == PersionType :: CORPORATION  ){
         $PersonalDocFile = $Customer->getPersonalDocFile();
         $CorporationDocFile = $Customer->getCorporationDocFile();
         if(null != $PersonalDocFile && null != $CorporationDocFile){
            $this->orderRepository->updateCorporationAllOrders($PersonalDocFile,$CorporationDocFile);
         }
      }
      
    }
    
}
