<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Mypage;

use Eccube\Controller\AbstractController;
use Eccube\Entity\BaseInfo;
use Eccube\Entity\Customer;
use Eccube\Entity\Master\SaleType;
use Eccube\Entity\Master\CustomerOrderStatus;
use Eccube\Entity\Master\KaitoriType;
use Eccube\Entity\Master\OrderStatus;
use Eccube\Repository\Master\CertsDocRepository;
use Eccube\Service\PurchaseFlow\ItemCollection;
use Eccube\Repository\OrderItemCopyRepository;
use Eccube\Entity\Product;
use Eccube\Entity\Order;
use Eccube\Entity\Shipping;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Exception\CartException;
use Eccube\Form\Type\Front\CustomerLoginType;
use Eccube\Repository\BaseInfoRepository;
use Eccube\Repository\CustomerFavoriteProductRepository;
use Eccube\Repository\OrderRepository;
use Eccube\Repository\MailHistoryRepository;
use Eccube\Service\OrderHelper;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\PayingRepository;
use Eccube\Repository\OrderOpehistRepository;
use Eccube\Repository\ProductStockRepository;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Service\CartService;
use Eccube\Service\PurchaseFlow\PurchaseContext;
use Eccube\Service\PurchaseFlow\PurchaseFlow;
use Eccube\Service\MailService;
use Eccube\Service\OrderStateMachine;
use Knp\Component\Pager\Paginator;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;
use Eccube\Service\OrderPdfService;
use Symfony\Component\HttpFoundation\Response;
use SunCat\MobileDetectBundle\DeviceDetector\MobileDetector;

class MypageController extends AbstractController
{
    /**
     * @var MobileDetector
     */
    private $mobileDetector;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var CustomerFavoriteProductRepository
     */
    protected $customerFavoriteProductRepository;

    /**
     * @var BaseInfo
     */
    protected $BaseInfo;

    /**
     * @var CartService
     */
    protected $cartService;
    
    /**
     * @var OrderPdfService
     */
    protected $orderPdfService;

    /**
     * @var OrderRepository
     */
    protected $orderRepository;
    
    /**
     * @var MailHistoryRepository
     */
    protected $mailHistoryRepository;
    
    /**
     * @var CertsDocRepository
     */
    protected $certsDocRepository;

    /**
     * @var OrderHelper
     */
    private $orderHelper;
    
    /**
     * @var OrderItemCopyRepository
     */
    protected $orderItemCopyRepository;
    
    /**
     * @var PayingRepository
     */
    protected $payingRepository;
    
    /**
     * @var OrderOpehistRepository
     */
    protected $orderOpehistRepository;
    
    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;
    
    /**
     * @var ProductStockRepository
     */
    protected $productStockRepository;

    /**
     * @var PurchaseFlow
     */
    protected $purchaseFlow;
    
    /**
     * @var MailService
     */
    protected $mailService;
    
    /**
     * @var OrderStateMachine
     */
    protected $orderStateMachine;

    /**
     * MypageController constructor.
     *
     * @param OrderRepository $orderRepository 
     * @param MailHistoryRepository $mailHistoryRepository 
     * @param OrderHelper $orderHelper
     * @param OrderItemCopyRepository $orderItemCopyRepository 
     * @param PayingRepository $payingRepository 
     * @param CustomerFavoriteProductRepository $customerFavoriteProductRepository
     * @param CertsDocRepository $certsDocRepository
     * @param CartService $cartService
     * @param PageMaxRepository $pageMaxRepository
     * @param BaseInfoRepository $baseInfoRepository
     * @param PurchaseFlow $purchaseFlow
     * @param OrderOpehistRepository $orderOpehistRepository
     * @param ProductStockRepository $productStockRepository
     * @param OrderStateMachine $orderStateMachine ;
     * @param MobileDetector $mobileDetector
     */
    public function __construct(
        OrderRepository $orderRepository,
        MailHistoryRepository $mailHistoryRepository,
        OrderHelper $orderHelper,
        OrderItemCopyRepository $orderItemCopyRepository,
        PayingRepository $payingRepository,
        PageMaxRepository $pageMaxRepository,
        CustomerFavoriteProductRepository $customerFavoriteProductRepository,
        CartService $cartService,
        MailService $mailService,
        BaseInfoRepository $baseInfoRepository,
        OrderOpehistRepository $orderOpehistRepository,
        ProductStockRepository $productStockRepository,
        CertsDocRepository $certsDocRepository,
        OrderStateMachine $orderStateMachine,
        PurchaseFlow $purchaseFlow,
        MobileDetector $mobileDetector
    ) {
        $this->orderRepository = $orderRepository;
        $this->mailHistoryRepository = $mailHistoryRepository;
        $this->orderHelper = $orderHelper;
        $this->orderItemCopyRepository = $orderItemCopyRepository;
        $this->payingRepository = $payingRepository;
        $this->pageMaxRepository = $pageMaxRepository;
        $this->certsDocRepository = $certsDocRepository;
        $this->customerFavoriteProductRepository = $customerFavoriteProductRepository;
        $this->BaseInfo = $baseInfoRepository->get();
        $this->cartService = $cartService;
        $this->mailService = $mailService;
        $this->orderStateMachine = $orderStateMachine;
        $this->orderOpehistRepository = $orderOpehistRepository;
        $this->productStockRepository = $productStockRepository;
        $this->purchaseFlow = $purchaseFlow;
        $this->mobileDetector = $mobileDetector;
    }

    /**
     * ログイン画面.
     *
     * @Route("/mypage/login", name="mypage_login")
     * @Template("Mypage/login.twig")
     */
    public function login(Request $request, AuthenticationUtils $utils)
    {
        if ($this->isGranted('IS_AUTHENTICATED_FULLY')) {
            log_info('認証済のためログイン処理をスキップ');

            return $this->redirectToRoute('mypage');
        }

        /* @var $form \Symfony\Component\Form\FormInterface */
        $builder = $this->formFactory
            ->createNamedBuilder('', CustomerLoginType::class);

        $builder->get('login_memory')->setData((bool) $request->getSession()->get('_security.login_memory'));

        if ($this->isGranted('IS_AUTHENTICATED_REMEMBERED')) {
            $Customer = $this->getUser();
            if ($Customer instanceof Customer) {
                $builder->get('login_email')
                    ->setData($Customer->getEmail());
            }
        }

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_MYPAGE_MYPAGE_LOGIN_INITIALIZE, $event);

        $form = $builder->getForm();

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/mypage/login.twig', [
                'error' => $utils->getLastAuthenticationError(),
                'form' => $form->createView(),
            ]);
        }

        return [
            'error' => $utils->getLastAuthenticationError(),
            'form' => $form->createView(),
        ];
    }

    /**
     * マイページ.
     *
     * @Route("/mypage/", name="mypage")
     * @Route("/mypage/page/{page_no}", requirements={"page_no" = "\d+"}, name="mypage_list_page")
     */
    public function index(Request $request, $page_no = null,Paginator $paginator)
    {
        $page_count = $this->session->get('eccube.mypage.search.page_count',
            $this->eccubeConfig->get('eccube_default_page_count'));
        $page_count_param = 10;
        $pageMaxis = $this->pageMaxRepository->findAll();
        if ($page_count_param) {
         
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.mypage.search.page_count', $page_count);
                    break;
                }
            }
        }
        
        if (null !== $page_no || $request->get('resume')) {
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.mypage.search.page_no', (int) $page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.mypage.search.page_no', 1);
                }
               
        } else {
                /**
                 * 初期表示の場合.
                 */
                $page_no = 1;

                // セッション中の検索条件, ページ番号を初期化.
               
                $this->session->set('eccube.mypage.search.page_no', $page_no);
       }

        $Customer = $this->getUser();

        // 購入処理中/決済処理中ステータスの受注を非表示にする.
        // TODO
        $this->entityManager
            ->getFilters()
            ->enable('order_status_processing_hidden');
        // TODO
        // paginator
        $qb = $this->orderRepository->getQueryBuilderByCustomer($Customer);

        $event = new EventArgs(
            [
                'qb' => $qb,
                'Customer' => $Customer,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_MYPAGE_MYPAGE_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $qb,
            $page_no,
            $page_count
        );

        $template = 'Mypage/index.twig';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            $template = 'Mobile/mypage/index.twig';
        }

        return $this->render($template, [
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'amazon' => SaleType :: SALE_TYPE_AMAZONGIFT,
            'applying_one' => CustomerOrderStatus :: APPLYING_INDEX_ONE,
            'applying_eight' => CustomerOrderStatus :: APPLYING_INDEX_EIGHT,
            'customer_order_status_stock' => CustomerOrderStatus::APPLYING_INDEX_NINE,
            'kaitori_shop' => KaitoriType::KAITORI_TYPE_SHOP,
            'kaitori_post' => KaitoriType::KAITORI_TYPE_NORMAL,
            'kaitori_amazon' => KaitoriType::KAITORI_TYPE_AMAZON,
        ]);
    }
    
    // TODO
    // pdf
    /**
     * @Route("/mypage/history/{order_no}/pdf/download", name="order_pdf_download")
     *
     * @param Request $request
     *
     * @return Response
     */
    public function exportPdfDownload(Request $request, OrderPdfService $orderPdfService)
    {
        $Order = $this->orderRepository->findOneBy(
        [
            'id' => $request->get('order_no'),
            'Customer' => $this->getUser(),
        ]);

        if (!$Order) {
            throw new NotFoundHttpException();
        }

        $arrData = [];
        $arrData['issue_date'] = new \DateTime();
        $ids = [];
        foreach ($Order->getShippings() as $shipping){
            $ids[] = $shipping->getId();
        }
        $arrData['ids'] = implode(",", $ids);

        // 購入情報からPDFを作成する
        $orderPdfService->makePdf($arrData);
        // ダウンロードする
        $response = new Response(
            $orderPdfService->outputPdf(),
            200,
            ['content-type' => 'application/pdf']
        );
        $response->headers->set('Content-Disposition', 'attachment; filename="'.$orderPdfService->getPdfFileName().'"');
        return $response;
     }

    // TODO

    /**
     * 購入履歴詳細を表示する.
     *
     * @Route("/mypage/history/{id}", requirements={"id" = "\d+"},name="mypage_history")
     */
    public function history(Request $request, $id)
    {

        $this->entityManager->getFilters()
            ->enable('order_status_processing_hidden');

        $Order = $this->orderRepository->findOneBy(
            [
                'id' => $id,
                'Customer' => $this->getUser(),
            ]
        );

        $event = new EventArgs(
            [
                'Order' => $Order,
            ],
            $request
        );
        
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_MYPAGE_MYPAGE_HISTORY_INITIALIZE, $event);

        /** @var Order $Order */
        $Order = $event->getArgument('Order');

        if (!$Order) {
            throw new NotFoundHttpException();
        }

        $stockOrder = true;
        foreach ($Order->getOrderItems() as $orderItem) {
            if ($orderItem->isProduct() && $orderItem->getQuantity() < 0) {
                $stockOrder = false;
                break;
            }
        }

        
        // 差分
        $OrderItemCopys = (new ItemCollection($this->orderItemCopyRepository->findBy(['Order' => $id])))->sort();
        $compare_result = $this->orderHelper->compareOrderItem($Order->getOrderItems() ,$OrderItemCopys);
        $this->convertFile($Order);

        $template = 'Mypage/history.twig';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            $template = 'Mobile/mypage/history.twig';
        }

        return $this->render($template, [
            'Order' => $Order,
            'order_new' => OrderStatus::NEW,
            'order_wait' => OrderStatus::WAIT,
            'order_stock' => OrderStatus::RETURNED,
            'order_pending' => OrderStatus::PENDING,
            'order_paid' => OrderStatus::PAID,
            'order_cancel' => OrderStatus::CANCEL,
            'customer_order_status_stock' => CustomerOrderStatus::APPLYING_INDEX_NINE,
            'kaitori_shop' => KaitoriType::KAITORI_TYPE_SHOP,
            'kaitori_post' => KaitoriType::KAITORI_TYPE_NORMAL,
            'kaitori_amazon' => KaitoriType::KAITORI_TYPE_AMAZON,
            'stockOrder' => $stockOrder,
            'wait' => CustomerOrderStatus :: APPLYING_INDEX_TWO,
            'is_over_time' => $this->mailHistoryRepository->checkMailSendDate($Order),
            'OrderItemCopys' => $OrderItemCopys,
            'compare_result' => $compare_result,
        ]);
    }

    private function convertFile($Order){
        if($Order->getPersonalDocFile()){
            $certsDoc = $this->certsDocRepository->find($Order->getPersonalDocFile()->getCertsDocId());
            if($certsDoc){
                $Order->getPersonalDocFile()->setCertsDocName($certsDoc->getName());
                $picture1 = $Order->getPersonalDocFile()->getPicture1();
                if($picture1){
                    $stream1 = stream_get_contents($picture1);
                    $extension1 = $Order->getPersonalDocFile()->getExtension1();
                    $encode1 = $extension1.base64_encode($stream1);
                    $Order->getPersonalDocFile()->setPicture1Encode($encode1);
                }
                $picture2 = $Order->getPersonalDocFile()->getPicture2();
                if($picture2){
                    $stream2 = stream_get_contents($picture2);
                    $extension2 = $Order->getPersonalDocFile()->getExtension2();
                    $encode2 = $extension2. base64_encode($stream2);
                    $Order->getPersonalDocFile()->setPicture2Encode($encode2);
                }

                $picture3 = $Order->getPersonalDocFile()->getPicture3();
                if($picture3){
                    $stream3 = stream_get_contents($picture3);
                    $extension3 = $Order->getPersonalDocFile()->getExtension3();
                    $encode3 = $extension3. base64_encode($stream3);
                    $Order->getPersonalDocFile()->setPicture3Encode($encode3);
                }

                $picture4 = $Order->getPersonalDocFile()->getPicture4();
                if($picture4){
                    $stream4 = stream_get_contents($picture4);
                    $extension4 = $Order->getPersonalDocFile()->getExtension4();
                    $encode4 = $extension4. base64_encode($stream4);
                    $Order->getPersonalDocFile()->setPicture4Encode($encode4);
                }

                $picture5 = $Order->getPersonalDocFile()->getPicture5();
                if($picture5){
                    $stream5 = stream_get_contents($picture5);
                    $extension5 = $Order->getPersonalDocFile()->getExtension5();
                    $encode5 = $extension5. base64_encode($stream5);
                    $Order->getPersonalDocFile()->setPicture5Encode($encode5);
                }

                $picture6 = $Order->getPersonalDocFile()->getPicture6();
                if($picture6){
                    $stream6 = stream_get_contents($picture6);
                    $extension6 = $Order->getPersonalDocFile()->getExtension6();
                    $encode6 = $extension6. base64_encode($stream6);
                    $Order->getPersonalDocFile()->setPicture6Encode($encode6);
                }

                $picture7 = $Order->getPersonalDocFile()->getPicture7();
                if($picture7){
                    $stream7 = stream_get_contents($picture7);
                    $extension7 = $Order->getPersonalDocFile()->getExtension7();
                    $encode7 = $extension7. base64_encode($stream7);
                    $Order->getPersonalDocFile()->setPicture7Encode($encode7);
                }

                $picture8 = $Order->getPersonalDocFile()->getPicture8();
                if($picture8){
                    $stream8 = stream_get_contents($picture8);
                    $extension8 = $Order->getPersonalDocFile()->getExtension8();
                    $encode8 = $extension8. base64_encode($stream8);
                    $Order->getPersonalDocFile()->setPicture8Encode($encode8);
                }

                $picture9 = $Order->getPersonalDocFile()->getPicture9();
                if($picture9){
                    $stream9 = stream_get_contents($picture9);
                    $extension9 = $Order->getPersonalDocFile()->getExtension9();
                    $encode9 = $extension9. base64_encode($stream9);
                    $Order->getPersonalDocFile()->setPicture9Encode($encode9);
                }
            }
        }
        if($Order->getCorporationDocFile()){
            $certsDoc = $this->certsDocRepository->find($Order->getCorporationDocFile()->getCertsDocId());
            if($certsDoc){
                $Order->getCorporationDocFile()->setCertsDocName($certsDoc->getName());
                $picture1 = $Order->getCorporationDocFile()->getPicture1();
                if($picture1){
                    $stream1 = stream_get_contents($picture1);
                    $extension1 = $Order->getCorporationDocFile()->getExtension1();
                    $encode1 = $extension1.base64_encode($stream1);
                    $Order->getCorporationDocFile()->setPicture1Encode($encode1);
                }
                $picture2 = $Order->getCorporationDocFile()->getPicture2();
                if($picture2){
                    $stream2 = stream_get_contents($picture2);
                    $extension2 = $Order->getCorporationDocFile()->getExtension2();
                    $encode2 = $extension2. base64_encode($stream2);
                    $Order->getCorporationDocFile()->setPicture2Encode($encode2);
                }

                $picture3 = $Order->getCorporationDocFile()->getPicture3();
                if($picture3){
                    $stream3 = stream_get_contents($picture3);
                    $extension3 = $Order->getCorporationDocFile()->getExtension3();
                    $encode3 = $extension3. base64_encode($stream3);
                    $Order->getCorporationDocFile()->setPicture3Encode($encode3);
                }

                $picture4 = $Order->getCorporationDocFile()->getPicture4();
                if($picture4){
                    $stream4 = stream_get_contents($picture4);
                    $extension4 = $Order->getCorporationDocFile()->getExtension4();
                    $encode4 = $extension4. base64_encode($stream4);
                    $Order->getCorporationDocFile()->setPicture4Encode($encode4);
                }

                $picture5 = $Order->getCorporationDocFile()->getPicture5();
                if($picture5){
                    $stream5 = stream_get_contents($picture5);
                    $extension5 = $Order->getCorporationDocFile()->getExtension5();
                    $encode5 = $extension5. base64_encode($stream5);
                    $Order->getCorporationDocFile()->setPicture5Encode($encode5);
                }

                $picture6 = $Order->getCorporationDocFile()->getPicture6();
                if($picture6){
                    $stream6 = stream_get_contents($picture6);
                    $extension6 = $Order->getCorporationDocFile()->getExtension6();
                    $encode6 = $extension6. base64_encode($stream6);
                    $Order->getCorporationDocFile()->setPicture6Encode($encode6);
                }

                $picture7 = $Order->getCorporationDocFile()->getPicture7();
                if($picture7){
                    $stream7 = stream_get_contents($picture7);
                    $extension7 = $Order->getCorporationDocFile()->getExtension7();
                    $encode7 = $extension7. base64_encode($stream7);
                    $Order->getCorporationDocFile()->setPicture7Encode($encode7);
                }

                $picture8 = $Order->getCorporationDocFile()->getPicture8();
                if($picture8){
                    $stream8 = stream_get_contents($picture8);
                    $extension8 = $Order->getCorporationDocFile()->getExtension8();
                    $encode8 = $extension8. base64_encode($stream8);
                    $Order->getCorporationDocFile()->setPicture8Encode($encode8);
                }

                $picture9 = $Order->getCorporationDocFile()->getPicture9();
                if($picture9){
                    $stream9 = stream_get_contents($picture9);
                    $extension9 = $Order->getCorporationDocFile()->getExtension9();
                    $encode9 = $extension9. base64_encode($stream9);
                    $Order->getCorporationDocFile()->setPicture9Encode($encode9);
                }
            }
        }
    }

    /**
     * 再購入を行う.
     *
     * @Route("/mypage/order/{order_no}", name="mypage_order", methods={"PUT"})
     */
    public function order(Request $request, $order_no)
    {
        $this->isTokenValid();

        log_info('再注文開始', [$order_no]);

        $Customer = $this->getUser();

        /* @var $Order \Eccube\Entity\Order */
        $Order = $this->orderRepository->findOneBy(
            [
                'order_no' => $order_no,
                'Customer' => $Customer,
            ]
        );

        $event = new EventArgs(
            [
                'Order' => $Order,
                'Customer' => $Customer,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_MYPAGE_MYPAGE_ORDER_INITIALIZE, $event);

        if (!$Order) {
            log_info('対象の注文が見つかりません', [$order_no]);
            throw new NotFoundHttpException();
        }

        // エラーメッセージの配列
        $errorMessages = [];

        foreach ($Order->getOrderItems() as $OrderItem) {
            try {
                if ($OrderItem->getProduct() && $OrderItem->getProductClass()) {
    
                    // 商品規格、数量、新品/中古、商品ランク
                    // 新品/中古
                $productRanks = $OrderItem->getProduct()->getProductRank();
                if($productRanks){
                  foreach($productRanks as $ProductRank){
                    $ProductRank->setVisible(true);
                  }
                }
                
                    $this->cartService->addProduct($OrderItem->getProductClass(),$OrderItem->getQuantity(),$OrderItem->getRankType(),$productRanks);

                    // 明細の正規化
                    $Carts = $this->cartService->getCarts();
                    foreach ($Carts as $Cart) {
                        $result = $this->purchaseFlow->validate($Cart, new PurchaseContext($Cart, $this->getUser()));
                        // 復旧不可のエラーが発生した場合は追加した明細を削除.
                        if ($result->hasError()) {
                            $this->cartService->removeProduct($OrderItem->getProductClass());
                            foreach ($result->getErrors() as $error) {
                                $errorMessages[] = $error->getMessage();
                            }
                        }
                        foreach ($result->getWarning() as $warning) {
                            $errorMessages[] = $warning->getMessage();
                        }
                    }

                    $this->cartService->save();
                }
            } catch (CartException $e) {
                log_info($e->getMessage(), [$order_no]);
                $this->addRequestError($e->getMessage());
            }
        }

        foreach ($errorMessages as $errorMessage) {
            $this->addRequestError($errorMessage);
        }

        $event = new EventArgs(
            [
                'Order' => $Order,
                'Customer' => $Customer,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_MYPAGE_MYPAGE_ORDER_COMPLETE, $event);

        if ($event->getResponse() !== null) {
            return $event->getResponse();
        }

        log_info('再注文完了', [$order_no]);

        return $this->redirect($this->generateUrl('cart'));
    }

    /**
     * お気に入り商品を表示する.
     *
     * @Route("/mypage/favorite", name="mypage_favorite")
     * @Template("Mypage/favorite.twig")
     */
    public function favorite(Request $request, Paginator $paginator)
    {
        if (!$this->BaseInfo->isOptionFavoriteProduct()) {
            throw new NotFoundHttpException();
        }
        $Customer = $this->getUser();

        // paginator
        $qb = $this->customerFavoriteProductRepository->getQueryBuilderByCustomer($Customer);

        $event = new EventArgs(
            [
                'qb' => $qb,
                'Customer' => $Customer,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_MYPAGE_MYPAGE_FAVORITE_SEARCH, $event);

        $pagination = $paginator->paginate(
            $qb,
            $request->get('pageno', 1),
            $this->eccubeConfig['eccube_search_pmax'],
            ['wrap-queries' => true]
        );

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/mypage/favorite.twig', [
                'pagination' => $pagination,
            ]);
        }

        return [
            'pagination' => $pagination,
        ];
    }

    /**
     * お気に入り商品を削除する.
     *
     * @Route("/mypage/favorite/{id}/delete", name="mypage_favorite_delete", methods={"DELETE"}, requirements={"id" = "\d+"})
     */
    public function delete(Request $request, Product $Product)
    {
        $this->isTokenValid();

        $Customer = $this->getUser();

        log_info('お気に入り商品削除開始', [$Customer->getId(), $Product->getId()]);

        $CustomerFavoriteProduct = $this->customerFavoriteProductRepository->findOneBy(['Customer' => $Customer, 'Product' => $Product]);

        if ($CustomerFavoriteProduct) {
            $this->customerFavoriteProductRepository->delete($CustomerFavoriteProduct);
        } else {
            throw new BadRequestHttpException();
        }

        $event = new EventArgs(
            [
                'Customer' => $Customer,
                'CustomerFavoriteProduct' => $CustomerFavoriteProduct,
            ], $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_MYPAGE_MYPAGE_DELETE_COMPLETE, $event);

        log_info('お気に入り商品削除完了', [$Customer->getId(), $CustomerFavoriteProduct->getId()]);

        return $this->redirect($this->generateUrl('mypage_favorite'));
    }
    
    /**
     * まとめて配送の申込み
     *
     * @Route("/mypage/send_mail/ids",  name="admin_mypage_send_mail", methods={"POST"})
     *
     * @param Request $request
     * 
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function sendBulkMail(Request $request)
    {
    
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
         }
       
        $idArr = explode(',', $request->get('ids'));
        $orders = [];
        $Customer = null;
        foreach($idArr as $id){
            $Order = $this->orderRepository
                ->find($id);
            if($Order){
            array_push($orders,$Order);
            $Customer = $Order->getCustomer();
            }
        }

        try {
              // 送信
              if($Customer){
                 $this->mailService->sendMypageNotifyMail($orders,$Customer);
              }

              //$Shipping->setMailSendDate(new \DateTime());
            } catch (\Exception $e) {
               log_error('予期しないエラーです', [$e->getMessage()]);
            
               return $this->json(['status' => 'NG'], 500);
            }
        return $this->json(array_merge(['status' => 'OK']));
     }    
     
    /**
     * change order status
     *
     * @Route("/mypage/{id}/change/{status}/order_status", requirements={"id" = "\d+","status" = "\S+"}, name="admin_mypage_change_order_status")
     *
     * @param Request $request
     * @param Shipping $Shipping
     *
     * @return Response
     */
   public function changeOrderStatus(Request $request, Shipping $Shipping,$status=null)
    {
        $Order = $Shipping->getOrder();
        if($this->getUser()->getId() != $Order->getCustomer()->getId()){
            throw new BadRequestHttpException();
        }
         // 顧客確認待ち --> 入荷待ち
         $OrderStatus = $this->entityManager->find(OrderStatus::class,  OrderStatus::RETURNED);
           
         // 顧客確認待ち --> お取消し
         if($status === 'cancel'){
              // お取消し
              $OrderStatus = $this->entityManager->find(OrderStatus::class,  OrderStatus::CANCEL);
         }
        
        if (!$OrderStatus) {
           return $this->json(['status' => 'NG'], 400);
        }
       
        try {
         if ($Order->getOrderStatus()->getId() == $OrderStatus->getId()) {
            log_info('対応状況一括変更スキップ');
         } else {
             
              if ($this->orderStateMachine->can($Order, $OrderStatus)) {

                    $this->orderStateMachine->apply($Order, $OrderStatus);

                   // 操作履歴に登録
                   /** @var OrderOpehist $OrderOpehist */
                   // $this->orderOpehistRepository->insertOrderOpehist($Order, $Member,'対応状況変更');
                  
                    $this->entityManager->flush($Order);
                 
                     // 在庫戻す
                     if ($Order->getOrderStatus()->getId() == OrderStatus::CANCEL) {
                          foreach ($Order->getOrderItems() as $OrderItem) {
                            $ProductClass = $OrderItem->getProductClass();
                            if ($OrderItem->isProduct() && !$ProductClass->isStockUnlimited()) {
                                $quantity = $OrderItem->getQuantity();
                                $this->entityManager->flush($ProductClass);
                                $ProductStock = $this->productStockRepository->findOneBy(['ProductClass' => $ProductClass]);
                                $nowStock = $ProductStock->getStock() == null ? 0 : $ProductStock->getStock();
                                $ProductStock->setStock($nowStock - $quantity);
                                $this->entityManager->flush($ProductStock);
                             }
                           }
                           
                           // 該当会員のキャンセル回数を更新する
                           //if ($Customer = $Order->getCustomer()) {
                           //  $this->orderRepository->updateCustomerCancelTimes($Customer);
                           //}
                           
                           // メール送信
                           $this->mailService->sendMypageCancelNotifyMail($Shipping);
                           $Shipping->setMailSendDate(new \DateTime());      
                    }
               } 
             log_info('対応状況一括変更処理完了', [$Order->getId()]);
             
             }
              return $this->redirect($this->generateUrl('mypage_history', ['id' => $Order->getId()]));
              
            } catch (\Exception $e) {
             log_error('予期しないエラーです', [$e->getMessage()]);
             return $this->redirect($this->generateUrl('mypage_history', ['id' => $Order->getId()]));
            }
      }   
      
    /**
     * ポイント履歴.
     *
     * @Route("/mypage/point_history", name="mypage_point_history")
     * @Route("/mypage/point_history/{page_no}/page", requirements={"page_no" = "\d+"}, name="mypage_point_history_page")
     */
     public function getPointHistories(Request $request, $page_no = null, Paginator $paginator)
    {
        
        $page_count = $this->session->get('eccube.mypage.point.history.search.page_count',
            $this->eccubeConfig->get('eccube_default_page_count'));

        //$page_count_param = (int) $request->get('page_count');
        $page_count_param = 10;
        $pageMaxis = $this->pageMaxRepository->findAll();
      
        if ($page_count_param) {
         
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.mypage.point.history.search.page_count', $page_count);
                    break;
                }
            }
        }

       if (null !== $page_no || $request->get('resume')) {
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.mypage.point.history.search.page_no', (int) $page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.mypage.point.history.search.page_no', 1);
                }
               
        } else {
                /**
                 * 初期表示の場合.
                 */
                $page_no = 1;

                // セッション中の検索条件, ページ番号を初期化.
               
                $this->session->set('eccube.mypage.point.history.search.page_no', $page_no);
       }

        
        $Customer = $this->getUser();

        $qb = $this->orderRepository->getPointHistoriesByCustomer($Customer);

        $event = new EventArgs(
            [
                'qb' => $qb,
                'Customer' => $Customer,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_MYPAGE_MYPAGE_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $qb,
            $page_no,
            $page_count
        );

        $template = 'Mypage/point_history.twig';

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            $template = 'Mobile/mypage/point_history.twig';
        }

        return $this->render($template, [
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'has_errors' => false,
            'point_remain' => $Customer->getPoint(),
            'amazon' => KaitoriType :: KAITORI_TYPE_AMAZON,
            'new' => OrderStatus :: NEW,
            'paid' => OrderStatus :: PAID,
            'expiration_date' => $Customer->getPointExpirationDate(),
        ]);
    }

}
