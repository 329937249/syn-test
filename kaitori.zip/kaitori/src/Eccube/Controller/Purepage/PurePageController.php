<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Purepage;

use SunCat\MobileDetectBundle\DeviceDetector\MobileDetector;
use Eccube\Controller\AbstractController;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class PurePageController extends AbstractController
{
    /**
     * @var MobileDetector
     */
    private $mobileDetector;

    /**
     * PurePageController constructor.
     *
     * @param MobileDetector $mobileDetector
     */
    public function __construct(MobileDetector $mobileDetector) {
        $this->mobileDetector = $mobileDetector;
    }

    /**
     * 会社概要
     * @Route("/company", name="company")
     * @Template("Company/company.twig")
     */
    public function company()
    {
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/frame/top.twig', [
                'page_type' => '0',
                'page_name' => 'Mobile/company'
            ]);
        }
        return [
            'page_type' => '0'
        ];
    }

}
