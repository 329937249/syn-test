<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller;

use DateTime;
use Eccube\Entity\BaseInfo;
use Eccube\Entity\ProductClass;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Entity\Master\KaitoriType;
use Eccube\Repository\BaseInfoRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\CartItemRepository;
use Eccube\Service\CartService;
use Eccube\Service\PurchaseFlow\PurchaseContext;
use Eccube\Service\PurchaseFlow\PurchaseFlow;
use Eccube\Service\PurchaseFlow\PurchaseFlowResult;
use Eccube\Service\OrderHelper;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use SunCat\MobileDetectBundle\DeviceDetector\MobileDetector;

class CartController extends AbstractController
{
    /**
     * @var MobileDetector
     */
    private $mobileDetector;

    /**
     * @var ProductClassRepository
     */
    protected $productClassRepository;

    /**
     * @var CartItemRepository
     */
    protected $cartItemRepository;

    /**
     * @var CartService
     */
    protected $cartService;

    /**
     * @var PurchaseFlow
     */
    protected $purchaseFlow;

    /**
     * @var BaseInfo
     */
    protected $baseInfo;

    /**
     * CartController constructor.
     *
     * @param ProductClassRepository $productClassRepository
     * @param CartItemRepository $cartItemRepository
     * @param CartService $cartService
     * @param PurchaseFlow $cartPurchaseFlow
     * @param BaseInfoRepository $baseInfoRepository
     * @param MobileDetector $mobileDetector
     */
    public function __construct(
        ProductClassRepository $productClassRepository,
        CartItemRepository $cartItemRepository,
        CartService $cartService,
        PurchaseFlow $cartPurchaseFlow,
        BaseInfoRepository $baseInfoRepository,
        MobileDetector $mobileDetector
    ) {
        $this->productClassRepository = $productClassRepository;
        $this->cartItemRepository = $cartItemRepository;
        $this->cartService = $cartService;
        $this->purchaseFlow = $cartPurchaseFlow;
        $this->baseInfo = $baseInfoRepository->get();
        $this->mobileDetector = $mobileDetector;
    }

    /**
     * カート画面.
     *
     * @Route("/cart", name="cart")
     */
    public function index(Request $request)
    {

        $this->cartService->reset();

        // カートを取得して明細の正規化を実行
        $Carts = $this->cartService->getCarts();
        $this->execPurchaseFlow($Carts);

        // TODO itemHolderから取得できるように
        $least = [];
        $quantity = [];
        $isDeliveryFree = [];
        $totalPrice = 0;
        $totalQuantity = 0;
        

        foreach ($Carts as $Cart) {
            $quantity[$Cart->getCartKey()] = 0;
            $isDeliveryFree[$Cart->getCartKey()] = false;
            if ($this->baseInfo->getDeliveryFreeQuantity()) {
                if ($this->baseInfo->getDeliveryFreeQuantity() > $Cart->getQuantity()) {
                    $quantity[$Cart->getCartKey()] = $this->baseInfo->getDeliveryFreeQuantity() - $Cart->getQuantity();
                } else {
                    $isDeliveryFree[$Cart->getCartKey()] = true;
                }
            }

            if ($this->baseInfo->getDeliveryFreeAmount()) {
                if (!$isDeliveryFree[$Cart->getCartKey()] && $this->baseInfo->getDeliveryFreeAmount() <= $Cart->getTotalPrice()) {
                    $isDeliveryFree[$Cart->getCartKey()] = true;
                } else {
                    $least[$Cart->getCartKey()] = $this->baseInfo->getDeliveryFreeAmount() - $Cart->getTotalPrice();
                }
            }

            $totalPrice += $Cart->getTotalPrice();
            $totalQuantity += $Cart->getQuantity();
        }

        // カートが分割された時のセッション情報を削除
        $request->getSession()->remove(OrderHelper::SESSION_CART_DIVIDE_FLAG);

        // サイトタイプ 
        $site_type = $this->session->get('lcsdata.history.site_type', 'homepage');

        $template = "Cart/index.twig";

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            $template = 'Mobile/cart.twig';
        }

        return $this->render($template, [
            'totalPrice' => $totalPrice,
            'totalQuantity' => $totalQuantity,
            // 空のカートを削除し取得し直す
            'Carts' => $this->cartService->getCarts(true),
            'least' => $least,
            'quantity' => $quantity,
            'is_delivery_free' => $isDeliveryFree,
            'back_to_url' => $site_type,
        ]);
    }

    /**
     * @param $Carts
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     */
    protected function execPurchaseFlow($Carts)
    {
        /** @var PurchaseFlowResult[] $flowResults */
        $flowResults = array_map(function ($Cart) {
            $purchaseContext = new PurchaseContext($Cart, $this->getUser());

            return $this->purchaseFlow->validate($Cart, $purchaseContext);
        }, $Carts);

        // 復旧不可のエラーが発生した場合はカートをクリアして再描画
        $hasError = false;
        foreach ($flowResults as $result) {
            if ($result->hasError()) {
                $hasError = true;
                foreach ($result->getErrors() as $error) {
                    $this->addRequestError($error->getMessage());
                }
            }
        }
        if ($hasError) {
            $this->cartService->clear();

            return $this->redirectToRoute('cart');
        }

        $this->cartService->save();

        foreach ($flowResults as $index => $result) {
            foreach ($result->getWarning() as $warning) {
                if ($Carts[$index]->getItems()->count() > 0) {
                    $cart_key = $Carts[$index]->getCartKey();
                    $this->addRequestError($warning->getMessage(), "front.cart.${cart_key}");
                } else {
                    // キーが存在しない場合はグローバルにエラーを表示する
                    $this->addRequestError($warning->getMessage());
                }
            }
        }
    }

    /**
     * カート明細の加算/減算/削除を行う.
     *
     * - 加算
     *      - 明細の個数を1増やす
     * - 減算
     *      - 明細の個数を1減らす
     *      - 個数が0になる場合は、明細を削除する
     * - 削除
     *      - 明細を削除する
     *
     * @Route(
     *     path="/cart/{operation}/{cartItemId}",
     *     name="cart_handle_item",
     *     methods={"PUT"},
     *     requirements={
     *          "operation": "up|down|remove",
     *          "cartItemId": "\d+"
     *     }
     * )
     */
    //public function handleCartItem($operation, $productClassId)
    public function handleCartItem($operation, $cartItemId)
    {
        //log_info('カート明細操作開始', ['operation' => $operation, 'product_class_id' => $productClassId]);
        log_info('カート明細操作開始', ['operation' => $operation, 'cart_item_id' => $cartItemId]);

        $this->isTokenValid();

        $this->cartService->reset();

        /** @var CartItem $CartItem */
        $CartItem = $this->cartItemRepository->find($cartItemId);
        if (is_null($CartItem)) {
            log_info('商品が存在しないため、カート画面へredirect', ['operation' => $operation, 'cart_item_id' => $cartItemId]);

            return $this->redirectToRoute('cart');
        }

        /** @var ProductClass $ProductClass */
        //$ProductClass = $this->productClassRepository->find($productClassId);
        $ProductClass = $CartItem->getProductClass();
        if (is_null($ProductClass)) {
            log_info('商品が存在しないため、カート画面へredirect', ['operation' => $operation, 'product_class_id' => $cartItemId]);

            return $this->redirectToRoute('cart');
        }

        // 明細の増減・削除
        switch ($operation) {
            case 'up':
                //$this->cartService->addProduct($ProductClass, 1);
                $this->cartService->addProductToCartItem($CartItem, 1);
                break;
            case 'down':
                //$this->cartService->addProduct($ProductClass, -1);
                $this->cartService->addProductToCartItem($CartItem, -1);
                break;
            case 'remove':
                //$this->cartService->removeProduct($ProductClass);
                $this->cartService->removeProductToCartItem($CartItem);
                break;
        }

        // カートを取得して明細の正規化を実行
        $Carts = $this->cartService->getCarts();
        $this->execPurchaseFlow($Carts);

        //log_info('カート演算処理終了', ['operation' => $operation, 'product_class_id' => $productClassId]);
        log_info('カート演算処理終了', ['operation' => $operation, 'cart_item_id' => $cartItemId]);

        return $this->redirectToRoute('cart');
    }

    /**
     * カートをロック状態に設定し、購入確認画面へ遷移する.
     *
     * @Route("/cart/buystep1/{cart_key}", name="cart_buystep_store", requirements={"cart_key" = "[a-zA-Z0-9]+[_][\x20-\x7E]+"})
     */
    
      public function buystep1(Request $request, $cart_key)
    {
      $this->session->set('send_type', '1');
      return $this->buystep($request,$cart_key);
    }
    
    /**
     * カートをロック状態に設定し、購入確認画面へ遷移する.
     *
     * @Route("/cart/buystep2/{cart_key}", name="cart_buystep_send", requirements={"cart_key" = "[a-zA-Z0-9]+[_][\x20-\x7E]+"})
     */
    
    public function buystep2(Request $request, $cart_key)
    {
      $this->session->set('send_type', '2');
      return $this->buystep($request,$cart_key);
    }

    /**
     * カートをロック状態に設定し、購入確認画面へ遷移する.
     *
     * @Route("/cart/buystep/{cart_key}", name="cart_buystep", requirements={"cart_key" = "[a-zA-Z0-9]+[_][\x20-\x7E]+"})
     */
    public function buystep(Request $request, $cart_key)
    {
        $Carts = $this->cartService->getCart();
        if (!is_object($Carts)) {
            return $this->redirectToRoute('cart');
        }
        //価格変動チェック
        foreach ($this->cartService->getCarts() as $cart) {
            if($cart_key == $cart->getCartKey()){
                if(!$this->cartService->checkTotalPriceOrgFromCart($cart)){
                    $warning = "買取価格に変更がありましたので、申込することはできません。大変お手数ですが、再度お申込み手続きをお願いします。";
                    $this->addRequestError($warning, "front.cart.${cart_key}");
                    return $this->redirectToRoute('cart');
                }
                //期限切れ商品チェック
                if(KaitoriType::KAITORI_TYPE_AMAZON == $this->session->get('send_type')){
                    foreach ($cart->getCartItems() as $CartItem) {
                        $now = new \DateTime();
                        if($now->format("Ymd") > $CartItem->getAddDate()->format("Ymd")){
                            $warning = "商品". $CartItem->getProductClass()->formattedProductName() ."買取有効期限が切れました";
                            $this->addRequestError($warning, "front.cart.${cart_key}");
                            return $this->redirectToRoute('cart');
                        }
                    }
                }
            }
        }
        // FRONT_CART_BUYSTEP_INITIALIZE
        $event = new EventArgs(
            [],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_CART_BUYSTEP_INITIALIZE, $event);

        $this->cartService->setPrimary($cart_key);
        $this->cartService->save();

        // FRONT_CART_BUYSTEP_COMPLETE
        $event = new EventArgs(
            [],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_CART_BUYSTEP_COMPLETE, $event);

        if ($event->hasResponse()) {
            return $event->getResponse();
        }

        return $this->redirectToRoute('shopping');
    }

    /**
     * amazonギフト券購入画面へ遷移する.
     *
     * @Route("/cart/buystep3/{cart_key}", name="cart_buystep_amazon", requirements={"cart_key" = "[a-zA-Z0-9]+[_][\x20-\x7E]+"})
     */
    
    public function buystep3(Request $request, $cart_key)
    {
      $this->session->set('send_type', '3');
      return $this->buystep($request,$cart_key);
    }

    /**
     * cart_item有効数を取得する.
     *
     * @Route("/cart/count", name="cart_item_count")
     */
    public function getCartItemCount()
    {
       $this->cartService->reset();
       $count = $this->cartService->getInAddCartTimeItems();
       return $this->json(array_merge(['item_count' => $count])); 
    }
}
