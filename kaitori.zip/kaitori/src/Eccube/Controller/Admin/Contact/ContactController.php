<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Contact;

use Eccube\Controller\AbstractController;
use Eccube\Entity\Contact;
use Eccube\Entity\Master\ContentTemplate;
use Eccube\Form\Type\Front\ContactType;
use Eccube\Service\MailService;
use Eccube\Repository\ContactRepository;
use Eccube\Repository\Master\ContentTemplateRepository;
use Knp\Component\Pager\Paginator;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;


class ContactController extends AbstractController
{
    /**
     * @var ContactRepository
     */
    protected $contactRepository;
    
    /**
     * @var ContentTemplateRepository
     */
    protected $contentTemplateRepository;
    
     /**
     * @var \Eccube\Service\MailService
     */
    protected $mailService;
    
    /**
     * ContactController constructor.
     *
     * @param ContactRepository $contactRepository
     * @param ContentTemplateRepository $contentTemplateRepository
     * @param MailService $mailService
     */
    public function __construct(ContactRepository $contactRepository,ContentTemplateRepository $contentTemplateRepository,MailService $mailService)
    {
        $this->contactRepository = $contactRepository;
        $this->contentTemplateRepository = $contentTemplateRepository;
        $this->mailService = $mailService;
    }

    /**
     * お問い合わせ一覧を表示する。
     *
     * @Route("/%eccube_admin_route%/contact/list", name="admin_contact_list")
     * @Route("/%eccube_admin_route%/contact/list/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_contact_list_page")
     * @Template("@admin/Contact/list.twig")
     *
     * @param Request $request
     * @param int $page_no
     * @param Paginator $paginator
     *
     * @return array
     */
    public function index(Request $request, $page_no = 1, Paginator $paginator)
    {
        $qb = $this->contactRepository->getQueryBuilderList();

        $pagination = $paginator->paginate(
            $qb,
            $page_no,
            $this->eccubeConfig->get('eccube_default_page_count')
        );

        return [
            'pagination' => $pagination,
        ];
    }
    
    /**
     * お問い合わせ履歴一覧を表示する。
     *
     * @Route("/%eccube_admin_route%/contact/history/list", name="admin_contact_history_list")
     * @Route("/%eccube_admin_route%/contact/history/list/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_contact_history_list_page")
     * @Template("@admin/Contact/history_list.twig")
     *
     * @param Request $request
     * @param int $page_no
     * @param Paginator $paginator
     *
     * @return array
     */
    public function historyiIndex(Request $request, $page_no = 1, Paginator $paginator)
    {
        $qb = $this->contactRepository->getQueryBuilderHistory();

        $pagination = $paginator->paginate(
            $qb,
            $page_no,
            $this->eccubeConfig->get('eccube_default_page_count')
        );

        return [
            'pagination' => $pagination,
        ];
    }

    /**
     *お問い合わせ明細を表示する。
     *
     * @Route("/%eccube_admin_route%/contact/list/{id}", requirements={"id" = "\d+"}, name="admin_contact_detail")
     * @Template("@admin/Contact/detail.twig")
     */
    public function detail(Request $request, $id)
    {
        $Contact = $this->contactRepository
            ->find($id);

        if (is_null($Contact)) {
            throw new NotFoundHttpException();
        }
        
        return [
            'data' => $Contact
        ];
    }
    
    /**
     *メール送信画面。
     *
     * @Route("/%eccube_admin_route%/contact/send_mail/{id}", requirements={"id" = "\d+"}, name="admin_contact_send_mail")
     * @Template("@admin/Contact/mail_edit.twig")
     */
    public function sendMail(Request $request, $id)
    {
        $templates = $this->contentTemplateRepository->getContentTemplate();
        $template = null;
        if(count($templates) > 0){
            $template = $templates[0];
            $tid = $request->get("tid");
            if($tid){
                $selected = array_filter($templates, function($v, $k) use ($tid){
                    return $v->getId() == $tid;
                }, ARRAY_FILTER_USE_BOTH);
                if(count($selected) > 0){
                    $template = array_values($selected)[0];
                }
            }
        }

        $Contact = $this->contactRepository->find($id);
        
        if (is_null($Contact)) {
            throw new NotFoundHttpException();
        }
        
        return [
            'data' => $Contact,
            'Templates' => $templates,
            'Template' => $template
        ];
    }
    
    /**
     * @Route("/%eccube_admin_route%/contact/preview_notify_mail/{id}", requirements={"id" = "\d+"}, name="admin_contact_preview_notify_mail")
     *
     * @param Contact $Contact
     *
     * @return Response
     *
     * @throws \Twig_Error
     */
    public function previewContactNotifyMail(Request $request,Contact $Contact)
    {
        $note = $request->get('note');
        $new_items = $request->get('items');
        $Contact->setItemsHtmlAdjust($new_items);
        $Contact->setNote($note);
        $this->entityManager->flush($Contact);
        return new Response($this->mailService->getContactNotifyMailBody($Contact, $note,null, true));
    }
    
     /**
     *  Send contact mail
     *
     * @Route("/%eccube_admin_route%/contact/{id}/send_mail", requirements={"id" = "\d+"}, name="admin_contact_send_contact_mail", methods={"PUT"})
     *
     * @param Request $request
     * @param Contact $Contact
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function sendContactMail(Request $request, Contact $Contact)
    {
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
        }

        $this->session->set('ContactNotifyMailTitle', $request->get("mail_title"));
        $result = [];
        
        try {
              $Member = $this->getUser();
              $Contact->setStatus('1')->setMember($Member);
              $this->contactRepository->save($Contact);
              $this->mailService->sendContactNotifyMail($Contact);
            } catch (\Exception $e) {
              log_error('予期しないエラーです', [$e->getMessage()]);
              return $this->json(['status' => 'NG'], 500);
            }
       return $this->json(array_merge(['status' => 'OK'], $result));
    }
    
    /**
     * updateAcceptMemberName
     *
     * @Route("/%eccube_admin_route%/contact/{id}/update_member_name", requirements={"id" = "\d+"}, name="admin_contact_update_member_accept", methods={"PUT"})
     *
     * @param Request $request
     * @param Contact $contact
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function updateAcceptMemberName(Request $request, Contact $Contact)
    {
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
             return $this->json(['status' => 'NG'], 400);
        }

        $Member = $this->getUser();

        $result = [];

        try {
              if($Contact->getMember() == null){
                 $Contact->setMember($Member);
                 $this->entityManager->flush($Contact);
              }else{
                 $result = ['message' => trans('admin.contact.failed_to_change_member', [
                   '%id%' => $Contact->getId(),
                ])];
              }
            } catch (\Exception $e) {
              log_error('予期しないエラーです', [$e->getMessage()]);
              return $this->json(['status' => 'NG'], 500);
            }

        return $this->json(array_merge(['status' => 'OK'], $result));
     }
     
    /**
     * updateNotAcceptMemberName
     *
     * @Route("/%eccube_admin_route%/contact/{id}/update_not_accept_member_name", requirements={"id" = "\d+"}, name="admin_contact_update_member_not_accept", methods={"PUT"})
     *
     * @param Request $request
     * @param Contact $Contact
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function updateNotAcceptMemberName(Request $request, Contact $Contact)
    {
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
         }

        $result = []; 
        $Member = $this->getUser();
        if($Contact->getMember() == null){
           $result = ['message' => trans('admin.contact.failed_to_change_not_accept_member_miss', [
                      '%id%' => $Contact->getId(),
                    ])];
           return $this->json(array_merge(['status' => 'OK'], $result)); 
        }

        try {
              if($Contact->getMember()->getName() == $Member->getName()){
                   $Contact->setMember(NULL);
                   $this->entityManager->flush($Contact);
              }else{
                 $result = ['message' => trans('admin.contact.failed_to_change_not_accept_member', [
                     '%id%' => $Contact->getId(),
                 ])];
              }
            } catch (\Exception $e) {
              log_error('予期しないエラーです', [$e->getMessage()]);
              return $this->json(['status' => 'NG'], 500);
            }
            
        return $this->json(array_merge(['status' => 'OK'], $result));
     }
     
     /**
     * Update contact status
     *
     * @Route("/%eccube_admin_route%/contact/{id}/update_status", requirements={"id" = "\d+"}, name="admin_contact_update_status")
     *
     * @param Request $request
     * @param Contact $Contact
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
   public function updateContactStatus(Request $request, Contact $Contact = null)
    {
      try {
           if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
               return $this->json(['status' => 'NG'], 400);
           }
           $Member = $this->getUser();
           $Contact->setStatus('1')->setMember($Member);
           $this->contactRepository->save($Contact);
           log_info('お問い合わせステータス一括変更処理完了', [$Contact->getId()]); 

         } catch (\Exception $e) {
               log_error('予期しないエラーです', [$e->getMessage()]);
         }

      return $this->json(array_merge(['status' => 'OK']));
    }

}