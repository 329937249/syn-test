<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\SalesVoucher;

use Doctrine\ORM\EntityManagerInterface;
use Eccube\Controller\AbstractController;
use Eccube\Entity\Master\CsvType;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\TempExStockDetailType;
use Eccube\Form\Type\Admin\SearchMemberType;
use Eccube\Form\Type\Admin\SalesVoucherSearchCustomerType;
use Eccube\Form\Type\Admin\TempExStockListType;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Service\CsvExportService;
use Eccube\Util\FormUtil;
use Eccube\Util\StringUtil;
use Knp\Component\Pager\Paginator;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\QueryBuilder;
use Eccube\Repository\CustomerMstRepository;

/**
 *プログラム名 ： TempExStockDetailController.php
 *概　　要     ： 仮出荷伝票明細
 *作　　成     ： 2021/8/17 CNC
 */
class TempExStockDetailController extends AbstractController
{
    // 一覧画面URL
    const TEMPLIST_PAGE_URL = 'sales_management/temp_ex_stock_list';
    /**
     * @var EntityManagerInterface
     */
    protected $entityManager;

    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var CustomerMstRepository
     */
    protected $customerMstRepository;

    /**
     * @var CsvExportService
     */
    protected $csvExportService;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * TempExStockDetailController constructor.
     *
     * @param CategoryRepository $categoryRepository
     * @param PageMaxRepository $pageMaxRepository
     * @param EntityManagerInterface $entityManager
     * @param CustomerMstRepository; $customerMstRepository
     * @param CsvExportService $csvExportService CsvExportService
     */
    public function __construct(
        CategoryRepository $categoryRepository,
        PageMaxRepository $pageMaxRepository,
        EntityManagerInterface $entityManager,
        CustomerMstRepository $customerMstRepository,
        CsvExportService $csvExportService
        , ProductRepository $productRepository
    ) {
        $this->categoryRepository = $categoryRepository;
        $this->pageMaxRepository = $pageMaxRepository;
        $this->entityManager = $entityManager;
        $this->customerMstRepository = $customerMstRepository;
        $this->csvExportService = $csvExportService;
        $this->productRepository = $productRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/sales_management/sales_temp_ex_stock_detail", name="admin_sales_temp_ex_stock_detail")
     * @Route("/%eccube_admin_route%/sales_management/sales_temp_ex_stock_detail/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_sales_temp_ex_stock_detail_page")
     * @Route("/%eccube_admin_route%/sales_management/sales_temp_ex_stock_detail/{id}", requirements={"id" = "\d+"}, name="admin_sales_temp_ex_stock_detail_no")
     * @Route("/%eccube_admin_route%/sales_management/sales_temp_ex_stock_detail/product_id/{productId}", requirements={"productId" = "\d+"}, name="admin_sales_temp_ex_stock_detail_product_id")
     * @Template("@admin/SalesVoucher/temp_ex_stock_detail.twig")
     */
    public function index(Request $request, $page_no = null, Paginator $paginator, $id = null, $productId = null)
    {
        // 前ページurl
        $link =
            strpos($request->headers->get('referer'), self::TEMPLIST_PAGE_URL)
                ? 1
                : 0;
        $builder = $this->formFactory
            ->createBuilder(TempExStockDetailType ::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALESVOUCHER_TEMPEXSTOCK_DETAIL_INDEX_INITIALIZE, $event);

        $searchForm = $builder->getForm();

        // 得意先検索フォーム
        $builder = $this->formFactory
            ->createBuilder(SalesVoucherSearchCustomerType::class);
        $searchSalesModalForm = $builder->getForm();

        // 担当者検索フォーム
        $builder = $this->formFactory
            ->createBuilder(SearchMemberType::class);
        $searchMemberModalForm = $builder->getForm();

        /**
         * ページの表示件数は, 以下の順に優先される.
         * - リクエストパラメータ
         * - セッション
         * - デフォルト値
         * また, セッションに保存する際は mtb_page_maxと照合し, 一致した場合のみ保存する.
         **/
        $page_count = $this->session->get('eccube.admin.temp_ex_stock_detail.search.page_count',
            $this->eccubeConfig->get('eccube_default_page_count'));

        $page_count_param = (int) $request->get('page_count');
        $pageMaxis = $this->pageMaxRepository->findAll();

        $memo = '';
        $personnelmemo = '';
        $memoflg = '0';

        if ($page_count_param) {
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.admin.temp_ex_stock_detail.search.page_count', $page_count);
                    break;
                }
            }
        }

        if ('POST' === $request->getMethod()) {
            $searchForm->handleRequest($request);

            if ($searchForm->isValid()) {
                /**
                 * 検索が実行された場合は, セッションに検索条件を保存する.
                 * ページ番号は最初のページ番号に初期化する.
                 */
                $page_no = 1;
                $searchData = $searchForm->getData();
                // 検索条件, ページ番号をセッションに保持.
                $this->session->set('eccube.admin.temp_ex_stock_detail.search', FormUtil::getViewData($searchForm));
                $this->session->set('eccube.admin.temp_ex_stock_detail.search.page_no', $page_no);
            } else {
                // 検索エラーの際は, 詳細検索枠を開いてエラー表示する.
                return [
                    'searchForm' => $searchForm->createView(),
                    'searchSalesModalForm' => $searchSalesModalForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $page_count,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.admin.temp_ex_stock_detail.search.page_no', (int)$page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.admin.temp_ex_stock_detail.search.page_no', 1);
                }
                $viewData = $this->session->get('eccube.admin.temp_ex_stock_detail.search', []);
            } else {
                /**
                 * 初期表示の場合.
                 */
                $page_no = 1;
                // main category
                $categories = $this->categoryRepository->getList(null, false);
                $mainCategory = null;
                foreach ($categories as $Category) {
                    if ($Category && ($Category->getHierarchy() == 1)) {
                        $mainCategory = $Category;
                        break;
                    }
                }

//                if ($mainCategory) {
//                    $viewData['main_category_id'] = $mainCategory->getId();
//                }

//                if ($mainCategory) {
//                    $searchData['main_category_id'] = $mainCategory;
//                }

                if ($id == null && $productId == null) {
//                    $viewData["personnel_memo"]=$this->getUser()['name'];
//                    $viewData["personnelMemoId"]=$this->getUser()['id'];
                    $viewData["purchase_date_end"] = date('Y-m-d', strtotime('now'));
                    $viewData["purchase_date_start"] = date('Y-m-d', strtotime('- 6 days'));
                    $viewData["nonRegister"] =  true;

                } else if ($productId != null) {

                    $product = $this->productRepository->find($productId);
                    $productCode = $product->getProductClasses()[0]['code'];
                    $viewData["product_code"] = $productCode;
                    $viewData["nonRegister"] =  true;

                } else if ($id != null) {
                    /**
                     * 仮出荷伝票一覧から遷移の場合.
                     */
                    $qbNo = $this->getSearchSalesStockVoucherNo($id);
                    $viewData["provisional_shipment_no"] =  $qbNo[0]['provisional_shipment_no'];
                    $memo = $qbNo[0]['memo'];
                    $personnelmemo = $qbNo[0]['personnel_memo'];
                    $memoflg = '1';
                    $viewData["nonRegister"] =  true;
                    $viewData["register"] =  true;
                }
            }
            // セッション中の検索条件, ページ番号を初期化.
            $this->session->set('eccube.admin.temp_ex_stock_detail.search', $viewData);
            $this->session->set('eccube.admin.temp_ex_stock_detail.search.page_no', $page_no);
            $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
        }

        /** @var QueryBuilder $qb */
        $qb = $this->getSearchData($searchData);

        //仮出荷金額合計
        $stockDetailMoneyTotalAmount = 0;
        foreach ($qb as &$stockDetail) {
            $stockDetailMoneyTotalAmount = $stockDetailMoneyTotalAmount + $stockDetail['total_sales_amount'];

            // 0: reservation_sales_date
            $stockDetail['reservation_sales_date'] = $this->makeDateStringUtcToAsiaTokyo($stockDetail['reservation_sales_date']);
            $stockDetail['0'] = $stockDetail['reservation_sales_date'];
            // 12: update_date
            $stockDetail['update_date'] = $this->makeDateStringUtcToAsiaTokyo($stockDetail['update_date']);
            $stockDetail['12'] = $stockDetail['update_date'];
        }
        $sort_orders = $this->sortOrder($qb, $searchData);

        $event = new EventArgs(
            [
                'qb' => $qb,
                'searchData' => $searchData,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_MANAGEMENT_PAYEE_VOUCHER_DETAIL_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $page_count
        );

        return [
            'searchForm' => $searchForm->createView(),
            'searchSalesModalForm' => $searchSalesModalForm->createView(),
            'searchMemberModalForm' => $searchMemberModalForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'has_errors' => false,
            'request' => $request,
            'stockDetailMoneyTotalAmount' => $stockDetailMoneyTotalAmount,
            'link'=>$link,
            'memo'=> $memo,
            'personnelmemo'=> $personnelmemo,
            'memoflg' => $memoflg,
        ];
    }
    /**
     * 仮出荷伝票明細
     *
     * @param $searchData
     *
     * @return null|result
     */
    public function getSearchData($searchData)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();
        $sql = '
                SELECT
                    psvh.reservation_sales_date,
                    cm.customer_code,
                    cm.customer_name,
                    psv.provisional_shipment_no,
                    psvh.personnel_id,
                    m.name AS personnel_name,
                    psv.product_code,
                    pp.name AS productName,
                    sa.state AS stateName,
                    psv.quantity AS reservation_stock_quantity,
                    psv.total_sales_amount,
                    psv.update_user_name,
                    psv.update_date,
                    psv.provisional_shipment_details_no,
                    slpu.stock_quantity,
                    psvh.tax_rate_category_id,
                    psv.sales_price,
                    dc4.category_id AS category_id1,
                    dc4.categoryName AS categoryName1,
                    dc5.category_id AS category_id2,
                    dc5.categoryName as categoryName2,
                    dc6.category_id AS category_id3,
                    dc6.categoryName as categoryName3,
                    psv.provisional_shipment_id ,
                    psvh.provisional_shipment_voucher_no,
                    CASE  WHEN  svh.sales_voucher_no IS NOT NULL 
                    THEN \'出荷済\' 
                    ELSE \'未出荷\' 
                    END AS provisional_shipment_state                  

                FROM dtb_provisional_shipment_voucher psv
                INNER JOIN dtb_provisional_shipment_voucher_header psvh
                ON psvh.id = psv.provisional_shipment_id
                
                LEFT JOIN dtb_stock_list_product_unit slpu
                ON slpu.product_code=psv.product_code
                AND slpu.state_id=psv.state_id

                INNER JOIN mtb_customer_mst cm
                ON cm.id=psvh.customer_id
                
                INNER JOIN dtb_member m
                ON m.id=psvh.personnel_id              
                
                INNER JOIN dtb_product pp
                ON pp.id=psv.product_id
                
                INNER JOIN mtb_state sa
                ON sa.id=psv.state_id                
                 
                LEFT JOIN dtb_sales_voucher_header svh 
                ON psvh.provisional_shipment_voucher_no = svh.sales_voucher_no               

                INNER JOIN ( 
                    SELECT
                        psv.id,
                        dpcs.category_id,
                        dcs.category_name AS categoryName,
                        dcs.hierarchy 
                    FROM
                        dtb_provisional_shipment_voucher psv
                        INNER JOIN dtb_product dps
                            ON psv.product_id = dps.id
                        INNER JOIN dtb_product_category dpcs
                            ON psv.product_id = dpcs.product_id
                        INNER JOIN dtb_category dcs
                            ON dcs.id = dpcs.category_id
                         WHERE dpcs.category_sub_flag <>1
                ) AS dc4
                ON dc4.id = psv.id
                AND dc4.hierarchy = 1

                LEFT JOIN ( 
                    SELECT
                        psv.id,
                        dpcs.category_id,
                        dcs.category_name AS categoryName,
                        dcs.hierarchy 
                    FROM
                        dtb_provisional_shipment_voucher psv
                        INNER JOIN dtb_product dps
                            ON psv.product_id = dps.id
                        INNER JOIN dtb_product_category dpcs
                            ON psv.product_id = dpcs.product_id
                        INNER JOIN dtb_category dcs
                            ON dcs.id = dpcs.category_id
                         WHERE dpcs.category_sub_flag <>1
                ) AS dc5 
                ON dc5.id = psv.id 
                AND dc5.hierarchy = 2

                LEFT JOIN ( 
                    SELECT
                        psv.id,
                        dpcs.category_id,
                        dcs.category_name AS categoryName,
                        dcs.hierarchy 
                    FROM
                        dtb_provisional_shipment_voucher psv
                        INNER JOIN dtb_product dps
                            ON psv.product_id = dps.id
                        INNER JOIN dtb_product_category dpcs
                            ON psv.product_id = dpcs.product_id
                        INNER JOIN dtb_category dcs
                            ON dcs.id = dpcs.category_id
                         WHERE dpcs.category_sub_flag <>1
                ) AS dc6 
                ON dc6.id = psv.id 
                AND dc6.hierarchy = 3 
                WHERE TRUE
            ';

        $flg = false;
        //provisional_shipment_no
        if (isset($searchData['provisional_shipment_no']) && StringUtil::isNotBlank($searchData['provisional_shipment_no'])) {
            $sql = $sql.' AND  psv.provisional_shipment_no = \''.addslashes($searchData['provisional_shipment_no']).'\'';
            $flg = true;
        }

        if ($flg != true) {
            // mainCategory
            if (isset($searchData['main_category_id']) && !empty($searchData['main_category_id']) && $searchData['main_category_id']) {
                $Category = $searchData['main_category_id'];
                $category_id = 'category_id_'.$Category->getId();
                if (isset($searchData[$category_id]) && !empty($searchData[$category_id]) && $searchData[$category_id]) {
                    $Categories = $searchData[$category_id]->getSelfAndDescendants();
                } else {
                    $Categories = $Category->getSelfAndDescendants();
                }
                if ($Categories) {
                    $sql = $sql.'AND dc4.category_id='."'".$searchData['main_category_id']['id']."'";
                    if ($searchData[$category_id]) {
                        if ($searchData[$category_id]['hierarchy'] == '2') {
                            $sql = $sql.'AND  dc5.category_id='."'".$searchData[$category_id]['id']."'";
                        } else {
                            $sql = $sql.'AND  dc6.category_id='."'".$searchData[$category_id]['id']."'";
                        }
                    }
                }
            }

            //product_code
            if (isset($searchData['product_code']) && StringUtil::isNotBlank($searchData['product_code'])) {
                $sql = $sql.' AND  psv.product_code LIKE '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['product_code']))."%'";
            }

            //product_name
            if (isset($searchData['product_name']) && StringUtil::isNotBlank($searchData['product_name'])) {
                $sql = $sql.' AND  pp.name LIKE '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['product_name']))."%'";
            }
            //personnel_memo
            if (isset($searchData['personnel_memo']) && StringUtil::isNotBlank($searchData['personnel_memo'])) {
                $sql = $sql.' AND   m.id = '.$searchData['personnelMemoId'];
            }

            //customerName
            if (isset($searchData['customerName']) && StringUtil::isNotBlank($searchData['customerName'])) {
                $sql = $sql.' AND  cm.id = '.$searchData['customerId'];
            }

            //purchase_date_start
            if (isset($searchData['purchase_date_start']) && StringUtil::isNotBlank($searchData['purchase_date_start'])) {
                /** @var \DateTime $purchase_date_start */
                $purchase_date_start = $searchData['purchase_date_start'];
                $purchaseDateStart = $purchase_date_start->setTime('0', '0', '0')
                    ->setTimezone(new \DateTimeZone('UTC'))
                    ->format('Y-m-d H:i:s');
                $sql = $sql.' AND  psvh.reservation_sales_date >= \''.$purchaseDateStart.'\'';
            }

            //purchase_date_end
            if (isset($searchData['purchase_date_end']) && StringUtil::isNotBlank($searchData['purchase_date_end'])) {
                /** @var \DateTime $purchase_date_end */
                $purchase_date_end = $searchData['purchase_date_end'];
                $purchaseDateEnd = $purchase_date_end->setTime('23', '59', '59')
                    ->setTimezone(new \DateTimeZone('UTC'))
                    ->format('Y-m-d H:i:s');
                $sql = $sql.' AND  psvh.reservation_sales_date <= \''.$purchaseDateEnd.'\'';
            }

            if (!($searchData['nonRegister'] && $searchData['register'])) {
                // nonRegister
                if ($searchData['nonRegister']) {
                    $sql = $sql.' AND  svh.sales_voucher_no is  null';
                }

                // register
                if ($searchData['register']) {
                    $sql = $sql.' AND  svh.sales_voucher_no is not null';
                }
            }
        }

        $sql = $sql.' ORDER BY 
        psv.update_date DESC
        ,psv.provisional_shipment_no
        ,psvh.reservation_sales_date
        ,cm.customer_name
        ';

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    /**
     * 仮出荷伝票明細(id)
     *
     * @param $id
     *
     * @return null|result
     */
    public function getSearchSalesStockVoucherNo($id)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();
        $sql = ' SELECT DISTINCT psv.provisional_shipment_no,
                 psv.provisional_shipment_id,
                 psvh.id,
                 psvh.memo,
                 psvh.personnel_memo
                 FROM dtb_provisional_shipment_voucher psv
                 INNER JOIN dtb_provisional_shipment_voucher_header psvh
                 ON psvh.id = psv.provisional_shipment_id
                 WHERE TRUE
                 ';
        $sql= $sql.' AND psv.provisional_shipment_id='."'".$id."'";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }
    /**
     * ソート.
     */
    private function sortOrder($orders, $searchData){
        if($searchData['sort_by']){
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case '伝票番号':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a["provisional_shipment_no"] > $b["provisional_shipment_no"] ? -1 : 1;
                        }
                        return $a["provisional_shipment_no"] < $b["provisional_shipment_no"] ? -1 : 1;
                    });
                    break;
                case '予約売上日':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a["reservation_sales_date"]> $b["reservation_sales_date"] ? -1 : 1;
                        }
                        return $a["reservation_sales_date"] < $b["reservation_sales_date"] ? -1 : 1;
                    });
                    break;
                case '得意先名':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a["customer_name"] > $b["customer_name"] ? -1 : 1;
                        }
                        return $a["customer_name"] < $b["customer_name"] ? -1 : 1;
                    });
                    break;
            }
        }
        return $orders;
    }

    /**
     * UTC時間を東京時間にする
     * @param string|null $date 時間文字列(yyyy-mm-dd HH:ii:ss)
     * @return string
     */
    public function makeDateStringUtcToAsiaTokyo(string $date = null)
    {
        if (!$date || $date !== date('Y-m-d H:i:s', strtotime($date))) {
            return '';
        }

        try {
            $date_utc = new \DateTime($date, new \DateTimeZone('UTC'));
            $date_asia_tokyo = $date_utc
                ->setTimezone(new \DateTimeZone('Asia/Tokyo'))
                ->format('Y-m-d H:i:s');
        } catch (\Exception $exception) {
            return '';
        }

        return $date_asia_tokyo;
    }

    // INS-START CNC 2022/03/07
    /**
     * CSVの出力.
     *
     * @Route("/%eccube_admin_route%/sales_voucher/detail/export", name="admin_tempex_stock_details_export")
     *
     * @param Request $request Request
     *
     * @return StreamedResponse
     */
    public function export(Request $request)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        // sql loggerを無効にする.
        $em = $this->entityManager;
        $em->getConfiguration()->setSQLLogger(null);

        $response = new StreamedResponse();
        $response->setCallback(function () use ($request) {

            // CSV種別を元に初期化.
            $this->csvExportService->initCsvType(CsvType::CSV_TYPE_TEMP_EX_STOCK_DETAIL);

            // ヘッダ行の出力.
            $this->csvExportService->exportHeader();

            $qb = $this->getTempExStockDetailQueryBuilder($request);

            // データ行の出力.
            $this->csvExportService->setExportDetailQueryBuilder($qb);

            $this->csvExportService->exportDataArrayCsv(function ($entity, csvExportService $csvService) use ($request) {
                $Csvs = $csvService->getCsvs();

                $TempExStockDetailCSV = new \Eccube\Entity\TempExStockDetailCSV();
                $TempExStockDetailCSV->setProvisionalShipmentNo($entity['provisional_shipment_no']);
                $TempExStockDetailCSV->setReservationSalesDate(substr($this->makeDateStringUtcToAsiaTokyo($entity['reservation_sales_date']), 0, 10));
                $TempExStockDetailCSV->setCustomerName($entity['customer_name']);
                $TempExStockDetailCSV->setPersonnelName($entity['personnel_name']);
                $TempExStockDetailCSV->setCategoryId1($entity['category_id1']);
                $TempExStockDetailCSV->setCategoryName1($entity['categoryName1']);
                $TempExStockDetailCSV->setCategoryId2($entity['category_id2']);
                $TempExStockDetailCSV->setCategoryName2($entity['categoryName2']);
                $TempExStockDetailCSV->setCategoryId3($entity['category_id3']);
                $TempExStockDetailCSV->setCategoryName3($entity['categoryName3']);
                $TempExStockDetailCSV->setProductCode($entity['product_code']);
                $TempExStockDetailCSV->setProductName($entity['productName']);
                $TempExStockDetailCSV->setStateName($entity['stateName']);
                $TempExStockDetailCSV->setStockQuantity(is_null($entity['stock_quantity'])? 0 : $entity['stock_quantity']);
                $TempExStockDetailCSV->setReservationStockQuantity($entity['reservation_stock_quantity']);
                $TempExStockDetailCSV->setSalesPrice($entity['sales_price'] === null ? 0 :$entity['sales_price']);
                $TempExStockDetailCSV->setTotalSalesAmount($entity['total_sales_amount']);
                $TempExStockDetailCSV->setUpdateUserName($entity['update_user_name']);

                $ExportCsvRow = new \Eccube\Entity\ExportCsvRow();

                // CSV出力項目と合致するデータを取得.
                foreach ($Csvs as $Csv) {
                    $ExportCsvRow->setData($csvService->getData($Csv, $TempExStockDetailCSV));
                    $event = new EventArgs(
                        [
                            'csvService' => $csvService,
                            'Csv' => $Csv,
                            'SalesVoucherHeader' => $entity,
                            'ExportCsvRow' => $ExportCsvRow,
                        ],
                        $request
                    );
                    $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_CUSTOMER_CSV_EXPORT, $event);

                    $ExportCsvRow->pushData();
                }
                // 出力.
                $csvService->fputcsv($ExportCsvRow->getRow());
            });
        });

        $now = new \DateTime();
        $filename = 'tempExStockDetail_'.$now->format('YmdHis').'.csv';
        $response->headers->set('Content-Type', 'application/octet-stream');
        $response->headers->set('Content-Disposition', 'attachment; filename='.$filename);
        $response->send();

        log_info('仮出荷伝票明細CSV出力ファイル名', [$filename]);

        return $response;
    }

    /**
     * 仮出荷伝票明細検索用のクエリビルダを返す.
     *
     * @param Request $request Request
     *
     * @return \Doctrine\ORM\QueryBuilder
     */
    public function getTempExStockDetailQueryBuilder(Request $request)
    {
        $session = $request->getSession();

        $builder = $this->formFactory
            ->createBuilder(TempExStockDetailType ::class);
        $searchForm = $builder->getForm();

        $viewData = $session->get('eccube.admin.temp_ex_stock_detail.search', []);
        $searchData = FormUtil::submitAndGetData($searchForm, $viewData);

        $qb = $this->getSearchData($searchData);
        return $qb;
    }
    // INS-END CNC 2022/03/07
}