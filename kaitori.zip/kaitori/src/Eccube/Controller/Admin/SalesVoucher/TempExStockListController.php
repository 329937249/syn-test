<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\SalesVoucher;

use Eccube\Controller\AbstractController;
use Eccube\Entity\BaseInfo;
use Eccube\Entity\Master\CsvType;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Util\StringUtil;
use Eccube\Form\Type\Admin\CustomerMstType;
use Eccube\Form\Type\Admin\TempExStockListType;
use Eccube\Form\Type\Admin\SalesVoucherSearchCustomerType;
use Eccube\Form\Type\Admin\SearchMemberType;
use Eccube\Repository\CustomerMstRepository;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\MemberRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\BaseInfoRepository;
use Eccube\Repository\ProvisionalShipmentVoucherHeaderRepository;
use Eccube\Repository\ProvisionalShipmentVoucherRepository;
use Eccube\Service\CsvExportService;
use Eccube\Service\TempExStockPdfService;
use Eccube\Util\FormUtil;
use Knp\Component\Pager\Paginator;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： TempExStockListController.php
 *概　　要     ： 仮出荷伝票一覧
 *作　　成     ： 2021/8/23 CNC
 */
class TempExStockListController extends AbstractController
{

    /**
     * @var ProvisionalShipmentVoucherHeaderRepository
     */
    protected $provisionalShipmentVoucherHeaderRepository;

    /**
     * @var ProvisionalShipmentVoucherRepository
     */
    protected $provisionalShipmentVoucherRepository;

    /**
     * @var CustomerMstRepository
     */
    protected $customerMstRepository;

    /**
     * @var MemberRepository
     */
    protected $memberRepository;

    /**
     * @var CsvExportService
     */
    protected $csvExportService;

    /** @var BaseInfo */
    public $baseInfoRepository;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /** 定数 */
    const MAX_SHEET_SIZE = 9;

    public function __construct(
        CsvExportService $csvExportService,
        PageMaxRepository $pageMaxRepository,
        ProvisionalShipmentVoucherHeaderRepository $provisionalShipmentVoucherHeaderRepository,
        ProvisionalShipmentVoucherRepository $provisionalShipmentVoucherRepository,
        CustomerMstRepository $customerMstRepository,
        MemberRepository $memberRepository,
        BaseInfoRepository $baseInfoRepository,
        ProductRepository $productRepository
    ) {
        $this->csvExportService = $csvExportService;
        $this->pageMaxRepository = $pageMaxRepository;
        $this->provisionalShipmentVoucherHeaderRepository = $provisionalShipmentVoucherHeaderRepository;
        $this->provisionalShipmentVoucherRepository = $provisionalShipmentVoucherRepository;
        $this->customerMstRepository = $customerMstRepository;
        $this->memberRepository = $memberRepository;
        $this->baseInfoRepository = $baseInfoRepository->get();
        $this->productRepository = $productRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/sales_management/temp_ex_stock_list", name="admin_temp_ex_stock_list")
     * @Route("/%eccube_admin_route%/sales_management/temp_ex_stock_list/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_temp_ex_stock_list_page")
     * @Template("@admin/SalesVoucher/temp_ex_stock_list.twig")
     *
     * @param Request $request
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function index(Request $request, $page_no = null, Paginator $paginator)
    {
        $session = $this->session;
        $builder = $this->formFactory
            ->createBuilder(TempExStockListType::class, null);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_MANAGEMENT_PAYEE_VOUCHER_LIST_INDEX_INITIALIZE, $event);

        $pageMaxis = $this->pageMaxRepository->findAll();
        $pageCount = $session->get('eccube.admin.temp_ex_stock_list.search.page_count', $this->eccubeConfig['eccube_default_page_count']);
        $pageCountParam = $request->get('page_count');
        if ($pageCountParam && is_numeric($pageCountParam)) {
            foreach ($pageMaxis as $pageMax) {
                if ($pageCountParam == $pageMax->getName()) {
                    $pageCount = $pageMax->getName();
                    $session->set('eccube.admin.temp_ex_stock_list.search.page_count', $pageCount);
                    break;
                }
            }
        }
        $form = $builder->getForm();

        // 得意先検索フォーム
        $builder_search_customer = $this->formFactory->createBuilder(SalesVoucherSearchCustomerType::class);

        $event = new EventArgs(
            [
                'builder' => $builder_search_customer,

            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_VOUCHER_INDEX_SEARCH_CUSTOMER_INITIALIZE, $event);

        $search_sales_modal_form = $builder_search_customer->getForm();

        // 担当者検索フォーム
        $builder = $this->formFactory
            ->createBuilder(SearchMemberType::class);
        $searchMemberModalForm = $builder->getForm();

        if ('POST' === $request->getMethod()) {
            $form->handleRequest($request);
            if ($form->isValid()) {
                $searchData = $form->getData();
                $page_no = 1;

                $session->set('eccube.admin.temp_ex_stock_list.search', FormUtil::getViewData($form));
                $session->set('eccube.admin.temp_ex_stock_list.search.page_no', $page_no);
            } else {
                return [
                    'form' => $form->createView(),
                    'searchCustomerMstModalForm' => $search_sales_modal_form->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $pageCount,
                    'salesMoneyTotalAmount' => 0,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                if ($page_no) {
                    $session->set('eccube.admin.temp_ex_stock_list.search.page_no', (int) $page_no);
                } else {
                    $page_no = $session->get('eccube.admin.temp_ex_stock_list.search.page_no', 1);
                }
                $viewData = $session->get('eccube.admin.temp_ex_stock_list.search', []);
            } else {
                $page_no = 1;
                $viewData = FormUtil::getViewData($form);
                $viewData["sales_date_end"] = date('Y-m-d', strtotime('now'));
                $viewData["sales_date_start"] = date('Y-m-d', strtotime('- 6 days'));
                $viewData["nonRegister"] =  true;
//                $viewData["personnel_memo"]=$this->getUser()['name'];
//                $viewData["personnelMemoId"]=$this->getUser()['id'];
            }
            $session->set('eccube.admin.temp_ex_stock_list.search', $viewData);
            $session->set('eccube.admin.temp_ex_stock_list.search.page_no', $page_no);
            $searchData = FormUtil::submitAndGetData($form, $viewData);
        }

        /** @var QueryBuilder $qb */
        $qb = $this->getSearchData($searchData);

        $salesMoneyTotalAmount = 0;
        foreach ($qb as &$sales) {
            $salesMoneyTotalAmount = $salesMoneyTotalAmount + $sales['total_sales_amount'];

            // 2: reservation_sales_date
            $sales['reservation_sales_date'] = $this->makeDateStringUtcToAsiaTokyo($sales['reservation_sales_date']);
            $sales['2'] = $sales['reservation_sales_date'];
            // 4: update_date
            $sales['update_date'] = $this->makeDateStringUtcToAsiaTokyo($sales['update_date']);
            $sales['4'] = $sales['update_date'];
        }
        $sort_orders = $this->sortOrder($qb, $searchData);

        $event = new EventArgs(
            [
                'form' => $form,
                'qb' => $qb,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_MANAGEMENT_PAYEE_VOUCHER_LIST_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $pageCount
        );

        return [
            'form' => $form->createView(),
            'searchSalesModalForm' => $search_sales_modal_form->createView(),
            'searchMemberModalForm' => $searchMemberModalForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'salesMoneyTotalAmount' => $salesMoneyTotalAmount,
            'page_no' => $page_no,
            'page_count' => $pageCount,
            'has_errors' => false,
        ];
    }

    private function sortOrder($orders, $searchData)
    {
        if ($searchData['sort_by']) {
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case '伝票番号':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == "降順") {
                            return $a["provisional_shipment_voucher_no"] > $b["provisional_shipment_voucher_no"] ? -1 : 1;
                        }
                        return $a["provisional_shipment_voucher_no"] < $b["provisional_shipment_voucher_no"] ? -1 : 1;
                    });
                    break;
                case '得意先名':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == "降順") {
                            return $a["customerName"] > $b["customerName"] ? -1 : 1;
                        }
                        return $a["customerName"] < $b["customerName"] ? -1 : 1;
                    });
                    break;
                case '予約売上日':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == "降順") {
                            return $a["reservation_sales_date"] > $b["reservation_sales_date"] ? -1 : 1;
                        }
                        return $a["reservation_sales_date"] < $b["reservation_sales_date"] ? -1 : 1;
                    });
                    break;
            }
        }

        return $orders;
    }

    // INS-START CNC 2022/03/01
    /**
     *  invoice
     *
     * @Route("/%eccube_admin_route%/temp_ex_stock_list/xlsx_Export/{ids}", requirements={"ids" = "\S+"}, name="admin_temp_ex_stock_list_export_xlsx")
     *
     * @param Request $request
     * @param string|null $ids ids
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse|StreamedResponse
     */
    public function xlsxExport(Request $request, string $ids = null)
    {
        $composerMemory = $this->eccubeConfig['eccube_composer_memory_limit'];
        ini_set('memory_limit', $composerMemory);

        try {
            $array_id = explode(',', $ids);
            $response = new StreamedResponse();
            $response->setCallback(function () use ($array_id) {

                // xlsxファイル設定
                $xlsxPath = $this->eccubeConfig->get('eccube_html_dir') . '/template/admin/assets/xlsx/invo.xlsx';
                $spreadsheet = IOFactory::load($xlsxPath);

                // 余分のsheetを削除
                if ($spreadsheet->getSheetCount() > 0) {
                    for ($i = $spreadsheet->getSheetCount() - 1; $i >= 0; $i--) {
                        if ($i > 0) {
                            $spreadsheet->removeSheetByIndex($i);
                        }
                    }
                }

                // sheetテンプレートのコピー
                $sheet = $spreadsheet->getSheet(0);
                for ($i = 0; $i < count($array_id); $i++) {
                    if ($i === count($array_id) - 1) {
                        break;
                    } else {
                        $sheetClone = $sheet->copy();
                        $sheetClone->setTitle('Sheet' . ($i + 2));
                        $spreadsheet->addSheet($sheetClone);
                    }
                }

                $worksheetID = 0;
                foreach ($array_id as $id) {

                    $xlsxHeader = $this->provisionalShipmentVoucherHeaderRepository->getQueryBuilderBySearchDataEXCEL($id);
                    $xlsxdetails = $this->provisionalShipmentVoucherRepository->getExportPdfBySalesVoucherNo($xlsxHeader[0]['provisional_shipment_voucher_no']);

                    if (!$xlsxHeader or !$xlsxdetails) {
                        // invoiceの取得ができなかった場合
                        throw new \Exception('No Data Found. header_id: '.$id.' provisional_shipment_voucher_no: '.$xlsxHeader[0]['provisional_shipment_voucher_no']);
                    }

                    $spreadsheet->setActiveSheetIndex($worksheetID);
                    $spreadsheet->getActiveSheet()
                        // 税関輸出入者コード
                        ->setCellValue('A1', $spreadsheet->getActiveSheet()->getCell('A1')->getCalculatedValue() . $this->baseInfoRepository->getTaxExporterCode())
                        // SHIPPER/EXPOTER(complete  name & address)
                        ->setCellValue('B6', 'LCS CO.,LTD')
                        ->setCellValue('B7', 'LCS CO.,LTD')
                        ->setCellValue('B8', $xlsxHeader[0]['export_addr04'])
                        ->setCellValue('A9', $xlsxHeader[0]['export_addr03'])
                        ->setCellValue('A10', $xlsxHeader[0]['export_addr02'])
                        ->setCellValue('A11', $xlsxHeader[0]['export_addr01'])
                        ->setCellValue('B12', $xlsxHeader[0]['name'])
                        ->setCellValue('B13', $this->baseInfoRepository->getPhoneNumber())
                        // CONSIGNEE(complete  name & address)
                        ->setCellValue('E6', $xlsxHeader[0]['customerName'])
                        ->setCellValue('E7', $xlsxHeader[0]['customerName'])
                        ->setCellValue('E8', $xlsxHeader[0]['nation'])
                        ->setCellValue('D10', $xlsxHeader[0]['customer_addr01'])
                        ->setCellValue('D11', $xlsxHeader[0]['customer_addr02'])
                        ->setCellValue('E12', $xlsxHeader[0]['customerName01'])
                        ->setCellValue('E13', $xlsxHeader[0]['phoneNumber'])
                        // COUNTRY  OF  ULTIMATE  DESTINATION
                        ->setCellValue('A16', $spreadsheet->getActiveSheet()->getCell('A16')->getCalculatedValue().'  '.$xlsxHeader[0]['export_addr01']);

                    // Package List
                    $count = 20;
                    $country = array();
                    $countryEn = array();
                    $productCountryEn = '';
                    $lenght = count($xlsxdetails);
                    if ($lenght > 1) {
                        $spreadsheet->getActiveSheet()->insertNewRowBefore($count + 1, $lenght - 1);
                    }
                    foreach ($xlsxdetails as $xlsxdetail) {
                        // 商品マスタ
                        $product = $this->productRepository->find($xlsxdetail['product_id']);
                        if (!is_null($product)) {
                            $spreadsheet->getActiveSheet()
                                ->setCellValue('A'.$count, $product->getProductNameEn()."\n".$xlsxdetail['product_code'])
                                ->setCellValue('B'. $count, $product->getProductCountryEn())
                                ->setCellValue('C'. $count, $product->getProductDescriptionEn())
                                ->setCellValue('D'.$count, $xlsxdetail['quantity'])
                                ->setCellValue('F'.$count, $xlsxdetail['sales_price'])
                                ->setCellValue('G'.$count, '=F'.$count.'*D'.$count);

                            if (!is_null($product->getProductCountryEn())) {
                                $country[] = $product->getProductCountryEn();
                            }
                            $count = $count + 1;
                        }
                    }
                    // COUNTRY  OF  ORIGIN  OF  GOODS
                    if (count($country) != 0) {
                        $countryEn = array_unique($country);
                        $countryEn = array_merge($countryEn);
                        for ($i = 0; $i < count($countryEn); $i++) {
                            if ($i === (count($countryEn) - 1)) {
                                $productCountryEn .= $countryEn[$i];
                            } else {
                                $productCountryEn .= $countryEn[$i] . '/';
                            }
                        }
                        $spreadsheet->getActiveSheet()
                            ->setCellValue('A15', $spreadsheet->getActiveSheet()->getCell('A15')->getCalculatedValue() . '  ' . $productCountryEn);
                    }
                    $spreadsheet->getActiveSheet()
                        ->setCellValue('B'.($count), '=SUM(E20:E' . (20 + $lenght - 1) . ')')
                        ->setCellValue('D'.($count), '=SUM(D20:D' . (20 + $lenght - 1) . ')')
                        ->setCellValue('B'.($count + 1), '=SUM(G20:G' . (20 + $lenght - 1) . ')')
                        ->setCellValue('G'.($count + 3), 'JPY')
                        ->setCellValue('A'.($count + 6), $spreadsheet->getActiveSheet()->getCell('A'.($count + 6))->getCalculatedValue() . $xlsxHeader[0]['reservation_sales_date']->format('Y.m.d'));
                    ++$worksheetID;
                }
                $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');
                $writer->save('php://output');
            });

            $sysDate = (new \DateTime())->format('YmdHis');
            $response->headers->set('Content-Type','application/octet-stream');
            $response->headers->set('Content-Disposition', 'attachment;filename="仮出荷伝票一覧_'.$sysDate.'_invoice.xlsx"');
            $response->send();
            return $response;
        } catch (\Exception $e){
            $message = trans('admin.netshopAI.csv.download_error').$e->getMessage();
            $this->addError($message, 'admin');

            log_error(trans('admin.netshopAI.csv.download_error'), [$e]);

            return $this->json(['success' => false, 'message' => $message], 500);
        }
    }

    /**
     * PDFの出力.
     *
     * @Route("/%eccube_admin_route%/sales_management/temp_ex_stock_pdf/{idFlg}/{ids}", requirements={"idFlg" = "\S+"}, requirements={"ids" = "\S+"}, name="admin_temp_ex_stock_pdf", methods={"GET"})
     *
     * @param Request $request Request
     * @param string|null $idFlg idFlg
     * @param string|null $ids ids
     * @param TempExStockPdfService|null $tempExStockPdfService TempExStockPdfService
     *
     * @return Response
     */
    public function salesVoucherPdf(Request $request, string $idFlg = null, string $ids = null, TempExStockPdfService $tempExStockPdfService = null)
    {
        // PDFを作成する
        $array_id = explode(',', $ids);
        $tempExStockPdfService->makePdf($idFlg, $array_id);
        // ダウンロードする
        $response = new Response(
            $tempExStockPdfService->outputPdf(),
            200,
            ['content-type' => 'application/pdf']
        );
        $response->headers->set('Content-Disposition', 'attachment; filename="'.$tempExStockPdfService->getPdfFileName().'"');

        return $response;
    }

    /**
     * PDFの出力前チェック.
     *
     * @Route("/%eccube_admin_route%/sales_management/temp_ex_stock_pdf_check", requirements={"ids" = "\S+"}, name="admin_temp_ex_stock_pdf_check", methods={"PUT"})
     *
     * @param Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function salesVoucherPdfCheck(Request $request)
    {
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
        }

        $ids = $request->get('ids');

        $err_ids = [];
        foreach($ids as $id) {
            $temp_ex_stock_list = $this->provisionalShipmentVoucherHeaderRepository->find($id);
            if ($temp_ex_stock_list) {
                $sales_voucher_details = $this->provisionalShipmentVoucherRepository->findOneBy(['provisionalShipmentVoucherHeader' => $temp_ex_stock_list->getId()]);
                if (is_null($sales_voucher_details)) {
                    $err_ids[] = [
                        'id' => $temp_ex_stock_list->getProvisionalShipmentVoucherNo()
                    ];
                }
            } else {
                $err_ids[] = [
                    'id' => $temp_ex_stock_list->getProvisionalShipmentVoucherNo()
                ];
            }
        }

        return $this->json(['err_ids' => $err_ids]);
    }
    // INS-END CNC 2022/03/01

    /**
     * 仮出荷伝票一覧データを取得.
     *
     * @param $searchData
     *
     * @return null|result
     */
    protected function getSearchData($searchData)
    {
        $this->entityManager->getConfiguration()->setSQLLogger(null);
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();

        $sql = '
                SELECT
                  psvh.id AS id,
                  psvh.provisional_shipment_voucher_no,
                  psvh.reservation_sales_date AS reservation_sales_date ,
                  psvh.update_user_name AS update_user_name ,
                  psvh.update_date AS update_date ,
                  psvh.personnel_memo AS personnel_memo ,
                  cus.id AS customerId, 
                  cus.customer_name AS customerName ,
                  cus.sort_no AS sort_no , 
                  mem.id AS memberId ,
                  mem.name AS personnelName ,
                  ter.id AS exportId,
                  sum(psv.total_sales_amount) AS total_sales_amount,
                  svh.sales_voucher_no AS sales_voucher_no,          
                  CASE  WHEN  svh.sales_voucher_no IS NOT NULL 
                  THEN \'出荷済\' 
                  ELSE \'未出荷\' 
                  END AS provisional_shipment_state 
              FROM
                  dtb_provisional_shipment_voucher_header psvh 
                  INNER JOIN mtb_customer_mst cus 
                  ON psvh.customer_id = cus.id 
                  INNER JOIN dtb_member mem 
                  ON psvh.personnel_id = mem.id 
                  LEFT JOIN dtb_provisional_shipment_voucher psv 
                  ON (psv.provisional_shipment_id = psvh.id)	
                  LEFT JOIN dtb_sales_voucher_header svh 
                  ON psvh.provisional_shipment_voucher_no = svh.sales_voucher_no
                  LEFT JOIN mtb_tax_exporter ter
                  ON psvh.export_Address_id = ter.id
                  WHERE TRUE
                 ';

        //sales_voucher_no
        if (isset($searchData['sales_voucher_no']) && StringUtil::isNotBlank($searchData['sales_voucher_no'])) {
            $sql = $sql.' AND  psvh.provisional_shipment_voucher_no LIKE '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['sales_voucher_no']))."%'";
        }

        //personnel_memo
        if (isset($searchData['personnel_memo']) && StringUtil::isNotBlank($searchData['personnel_memo'])) {
            $sql = $sql.' AND   mem.id = '.$searchData['personnelMemoId'];
        }

        //customerName
        if (isset($searchData['customerName']) && StringUtil::isNotBlank($searchData['customerName'])) {
            $sql = $sql.' AND  cus.id = '.$searchData['customerId'];
        }

        //sales_date_start
        if (isset($searchData['sales_date_start']) && StringUtil::isNotBlank($searchData['sales_date_start'])) {
            /** @var \DateTime $sales_date_start */
            $sales_date_start = $searchData['sales_date_start'];
            $purchaseDateStart = $sales_date_start->setTimezone(new \DateTimeZone('UTC'))
                ->format('Y-m-d H:i:s');
            $sql = $sql.' AND  psvh.reservation_sales_date >= \''.$purchaseDateStart.'\'';
        }

        //sales_date_end
        if (isset($searchData['sales_date_end']) && StringUtil::isNotBlank($searchData['sales_date_end'])) {
            /** @var \DateTime $sales_date_end */
            $date = clone $searchData['sales_date_end'];
            $date->modify('+1 days');
            $purchaseDateEnd = $date->setTimezone(new \DateTimeZone('UTC'))
                ->format('Y-m-d H:i:s');

            $sql = $sql.' AND  psvh.reservation_sales_date <= \''.$purchaseDateEnd.'\'';
        }

        if (!($searchData['nonRegister'] && $searchData['register'])) {
            // nonRegister
            if ($searchData['nonRegister']) {
                $sql = $sql.' AND  svh.sales_voucher_no is  null';
            }

            // register
            if ($searchData['register']) {
                $sql = $sql.' AND  svh.sales_voucher_no is not null';
            }
        }

        $sql = $sql.'
        group by 
        psv.provisional_shipment_no
        ORDER BY
        psvh.update_date DESC,
        psvh.provisional_shipment_voucher_no ASC, 
        psvh.reservation_sales_date ASC,
        cus.customer_name ASC
        ';

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    /**
     * UTC時間を東京時間にする
     * @param string|null $date 時間文字列(yyyy-mm-dd HH:ii:ss)
     * @return string
     */
    public function makeDateStringUtcToAsiaTokyo(string $date = null)
    {
        if (!$date || $date !== date('Y-m-d H:i:s', strtotime($date))) {
            return '';
        }

        try {
            $date_utc = new \DateTime($date, new \DateTimeZone('UTC'));
            $date_asia_tokyo = $date_utc
                ->setTimezone(new \DateTimeZone('Asia/Tokyo'))
                ->format('Y-m-d H:i:s');
        } catch (\Exception $exception) {
            return '';
        }

        return $date_asia_tokyo;
    }
}
