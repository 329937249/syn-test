<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\SalesVoucher;

use Doctrine\ORM\QueryBuilder;
use Eccube\Controller\AbstractController;
use Eccube\Entity\BaseInfo;
use Eccube\Entity\Master\CsvType;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\CustomerMstType;
use Eccube\Form\Type\Admin\SalesVoucherListType;
use Eccube\Form\Type\Admin\SalesVoucherSearchCustomerType;
use Eccube\Form\Type\Admin\SearchMemberType;
use Eccube\Repository\CustomerMstRepository;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\MemberRepository;
use Eccube\Repository\BaseInfoRepository;
use Eccube\Repository\SalesVoucherHeaderRepository;
use Eccube\Repository\SalesVoucherDetailRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\Master\SpecialAuthorityRepository;
use Eccube\Service\CsvExportService;
use Eccube\Service\SalesVoucherPdfService;
use Eccube\Util\FormUtil;
use Knp\Component\Pager\Paginator;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Picqer\Barcode\BarcodeGeneratorJPG;
use PhpOffice\PhpSpreadsheet\Worksheet\SheetView;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： SalesVoucherListController.php
 *概　　要     ： 売上伝票一覧
 *作　　成     ： 2021/8/5 CNC
 */
class SalesVoucherListController extends AbstractController
{
    /**
     * @var SalesVoucherHeaderRepository
     */
    protected $pageMaxRepository;
    /**
     * @var SalesVoucherHeaderRepository
     */
    protected $salesVoucherHeaderRepository;

    /**
     * @var SalesVoucherDetailRepository
     */
    protected $salesVoucherDetailRepository;

    /**
     * @var CustomerMstRepository
     */
    protected $customerMstRepository;

    /**
     * @var MemberRepository
     */
    protected $memberRepository;

    /**
     * @var CsvExportService
     */
    protected $csvExportService;

    /** @var BaseInfo */
    public $baseInfoRepository;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var SpecialAuthorityRepository
     */
    protected $specialAuthorityRepository;

    /** 定数 */
    const MAX_SHEET_SIZE = 9;

    public function __construct(
        CsvExportService $csvExportService,
        PageMaxRepository $pageMaxRepository,
        SalesVoucherHeaderRepository $salesVoucherHeaderRepository,
        SalesVoucherDetailRepository $salesVoucherDetailRepository,
        CustomerMstRepository $customerMstRepository,
        MemberRepository $memberRepository,
        BaseInfoRepository $baseInfoRepository,
        ProductRepository $productRepository,
        SpecialAuthorityRepository $specialAuthorityRepository
    ) {
        $this->csvExportService = $csvExportService;
        $this->pageMaxRepository = $pageMaxRepository;
        $this->salesVoucherHeaderRepository = $salesVoucherHeaderRepository;
        $this->salesVoucherDetailRepository = $salesVoucherDetailRepository;
        $this->customerMstRepository = $customerMstRepository;
        $this->memberRepository = $memberRepository;
        $this->baseInfoRepository = $baseInfoRepository->get();
        $this->productRepository = $productRepository;
        $this->specialAuthorityRepository = $specialAuthorityRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/sales_management/sales_voucher_list", name="admin_sales_voucher_list")
     * @Route("/%eccube_admin_route%/sales_management/sales_voucher_list/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_sales_voucher_list_page")
     * @Template("@admin/SalesVoucher/sales_voucher_list.twig")
     *
     * @param Request $request
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function index(Request $request, $page_no = null, Paginator $paginator)
    {
        $session = $this->session;
        $builder = $this->formFactory
            ->createBuilder(SalesVoucherListType::class, null);
        $member = $this->getUser();

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_MANAGEMENT_SALES_VOUCHER_LIST_INDEX_INITIALIZE, $event);

        $pageMaxis = $this->pageMaxRepository->findAll();
        $pageCount = $session->get('eccube.admin.sales_management.search.page_count', $this->eccubeConfig['eccube_default_page_count']);
        $pageCountParam = $request->get('page_count');
        if ($pageCountParam && is_numeric($pageCountParam)) {
            foreach ($pageMaxis as $pageMax) {
                if ($pageCountParam == $pageMax->getName()) {
                    $pageCount = $pageMax->getName();
                    $session->set('eccube.admin.sales_management.search.page_count', $pageCount);
                    break;
                }
            }
        }
        $form = $builder->getForm();

        // 得意先検索フォーム
        $builder_search_customer = $this->formFactory->createBuilder(SalesVoucherSearchCustomerType::class);

        $event = new EventArgs(
            [
                'builder' => $builder_search_customer,

            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_VOUCHER_INDEX_SEARCH_CUSTOMER_INITIALIZE, $event);

        $search_sales_modal_form = $builder_search_customer->getForm();

        // 担当者検索フォーム
        $builder = $this->formFactory
            ->createBuilder(SearchMemberType::class);
        $searchMemberModalForm = $builder->getForm();

        $page_no_bk = $page_no;
        if ('POST' === $request->getMethod()) {
            $form->handleRequest($request);
            if ($form->isValid()) {
                $searchData = $form->getData();
                $page_no = 1;

                $session->set('eccube.admin.sales_management.search', FormUtil::getViewData($form));
                $session->set('eccube.admin.sales_management.search.page_no', $page_no);
            } else {
                return [
                    'form' => $form->createView(),
                    'searchSalesModalForm' => $search_sales_modal_form->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $pageCount,
                    'salesMoneyTotalAmount' => 0,
                    'depositedAmount' => 0,
                    'depositedNotAmount' => 0,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                if ($page_no) {
                    $session->set('eccube.admin.sales_management.search.page_no', (int) $page_no);
                } else {
                    $page_no = $session->get('eccube.admin.sales_management.search.page_no', 1);
                }
                $viewData = $session->get('eccube.admin.sales_management.search', []);
            } else {
                $page_no = 1;
                $viewData = FormUtil::getViewData($form);
                $viewData["sales_date_end"] = date('Y-m-d', strtotime('now'));
                $viewData["sales_date_start"] = date('Y-m-d', strtotime('now'));
//                $viewData["personnel_memo"]=$this->getUser()['name'];
//                $viewData["personnelMemoId"]=$this->getUser()['id'];

                $session->set('eccube.admin.sales_management.search', $viewData);
                $session->set('eccube.admin.sales_management.search.page_no', $page_no);
            }
            $searchData = FormUtil::submitAndGetData($form, $viewData);
        }

        $qb = '';
        $all_orders = [];
        if ('POST' === $request->getMethod() || null !== $page_no_bk){
            /** @var QueryBuilder $qb */
            $qb = $this->salesVoucherHeaderRepository->getQueryBuilderBySearchData($searchData);
            $all_orders = $qb->getQuery()->getResult();
        }

        // 権限
        $authority = $this->specialAuthorityRepository->isValidAuthority($member);

        $salesMoneyTotalAmount = 0;
        $depositedAmount = 0;
        $depositedNotAmount = 0;
        $salesVoucherItems = [];
        $now = date('Y-m-d');
        foreach ($all_orders as $sales) {
            $salesMoneyTotalAmount = $salesMoneyTotalAmount + $sales['salesMoneyTotalAmount'];
            $depositedAmount = $depositedAmount + $sales['depositedAmount'];
            $depositedNotAmount = $depositedNotAmount + $sales['depositedNotAmount'];
            if (!$authority) {
//                if ($now === $sales['salesDate']->format('Y-m-d')) {
                if ($sales['create_date']->format('Y-m-d') >= date('Y-m-d', strtotime('- 5 days')) &&
                    $sales['create_date']->format('Y-m-d') <= date('Y-m-d', strtotime('5 days'))) {
                    $sales['authority'] = true;
                } else {
                    $sales['authority'] = false;
                }
            } else {
                $sales['authority'] = true;
            }
            $salesVoucherItems[] = $sales;
        }

        // 粗利益合計計算
        $i = 0;

        foreach ($salesVoucherItems as $salesVoucherHeader) {
            $exportAddress = $salesVoucherHeader['exportId'];
            $taxRate = $salesVoucherHeader['taxRate'];

            // MOD-START CNC 2022/10/17 DBの「粗利益合計」 > 0の場合、伝票の「粗利益」を再計算しない、DBの「粗利益合計」を取得利用する。
//            $Details = $this->salesVoucherDetailRepository->findBy(['SalesVoucherHeader' => $salesVoucherHeader['id']]);
//
//            //粗利益
//            $grossProfit = 0;
//            //利益率
//            $rate = 0;
//
//            foreach ($Details as $salesVoucherDetail) {
//                if ($salesVoucherDetail['product_code'] == '111' || $salesVoucherDetail['product_code'] == '222' || $salesVoucherDetail['product_code'] == '333' || $salesVoucherDetail['product_code'] == '777') {
//                    continue;
//                }
//                if ($exportAddress !== null) {
//                    //税金区分
//                    $crude = $salesVoucherDetail['sales_price'] - ($salesVoucherDetail['averagePrice'] / (1 + $taxRate / 100));
//                    $grossProfit = $grossProfit + round($crude * $salesVoucherDetail['quantity']);
//                } else {
//                    $crude = $salesVoucherDetail['sales_price'] - $salesVoucherDetail['averagePrice'];
//                    $grossProfit = $grossProfit + round($crude * $salesVoucherDetail['quantity']);
//                }
//            }
            //粗利益
            $grossProfit = 0;
            //利益率
            $rate = 0;

            if ($salesVoucherHeader['salesBenefitTotalAmount'] != 0) {
                $grossProfit = $salesVoucherHeader['salesBenefitTotalAmount'];
            } else {
                $Details = $this->salesVoucherDetailRepository->findBy(['SalesVoucherHeader' => $salesVoucherHeader['id']]);

                foreach ($Details as $salesVoucherDetail) {
                    if ($salesVoucherDetail['product_code'] == '111' || $salesVoucherDetail['product_code'] == '222' || $salesVoucherDetail['product_code'] == '333' || $salesVoucherDetail['product_code'] == '777') {
                        continue;
                    }
                    if ($exportAddress !== null) {
                        //税金区分
                        $crude = $salesVoucherDetail['sales_price'] - ($salesVoucherDetail['averagePrice'] / (1 + $taxRate / 100));
                        $grossProfit = $grossProfit + round($crude * $salesVoucherDetail['quantity']);
                    } else {
                        $crude = $salesVoucherDetail['sales_price'] - $salesVoucherDetail['averagePrice'];
                        $grossProfit = $grossProfit + round($crude * $salesVoucherDetail['quantity']);
                    }
                }
            }
            // MOD-END CNC 2022/10/17

            if (isset($salesVoucherHeader['salesMoneyTotalAmount']) && $salesVoucherHeader['salesMoneyTotalAmount'] != 0) {
                $rate = ($grossProfit / $salesVoucherHeader['salesMoneyTotalAmount']) * 100;
                $salesVoucherHeader['rate'] = round($rate, 1);
            } else {
                $salesVoucherHeader['rate'] = 0;
            }
            $salesVoucherHeader['grossProfit'] = $grossProfit;
            $salesVoucherItems[$i] = $salesVoucherHeader;
            $i++;

        }

        $all_orders = $salesVoucherItems;
        $sort_orders = $this->sortOrder($all_orders, $searchData);

        $event = new EventArgs(
            [
                'form' => $form,
                'qb' => $qb,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_MANAGEMENT_SALES_VOUCHER_LIST_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $pageCount
        );

        return [
            'form' => $form->createView(),
            'searchSalesModalForm' => $search_sales_modal_form->createView(),
            'searchMemberModalForm' => $searchMemberModalForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $pageCount,
            'salesMoneyTotalAmount' => $salesMoneyTotalAmount,
            'depositedAmount' => $depositedAmount,
            'depositedNotAmount' => $depositedNotAmount,
            'has_errors' => false,
        ];
    }

    private function sortOrder($orders, $searchData)
    {
        if ($searchData['sort_by']) {
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case '伝票番号':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == "降順") {
                            return $a["salesVoucherNo"] > $b["salesVoucherNo"] ? -1 : 1;
                        }
                        return $a["salesVoucherNo"] < $b["salesVoucherNo"] ? -1 : 1;
                    });
                    break;
                case '得意先名':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == "降順") {
                            return $a["customerName"] > $b["customerName"] ? -1 : 1;
                        }
                        return $a["customerName"] < $b["customerName"] ? -1 : 1;
                    });
                    break;
                case '売上日':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == "降順") {
                            return $a["salesDate"] > $b["salesDate"] ? -1 : 1;
                        }
                        return $a["salesDate"] < $b["salesDate"] ? -1 : 1;
                    });
                    break;
            }
        }
        return $orders;
    }

    /**
     * @Route("/%eccube_admin_route%/sales_voucher/search/customer", name="admin_sales_voucher_search_customer")
     * @Route("/%eccube_admin_route%/sales_voucher/search/customer/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_master_search_customermst_html_page")
     * @Template("@admin/SalesVoucher/search_customer_list.twig")
     * @param Request $request Request
     * @param int|null $page_no Page No
     * @param Paginator|null $paginator Paginator
     * @return array
     */
    public function searchCustomer(Request $request, int $page_no = null, Paginator $paginator = null)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('search customer mst start.');
            $page_count = $this->eccubeConfig['eccube_default_page_count'];
            $session = $this->session;

            if ('POST' === $request->getMethod()) {
                $page_no = 1;
                $searchData = [
                    'customerName' => $request->get('name'),
                    'kana' => $request->get('kana'),
                    'customerCode' => $request->get('code'),
                    'phoneNumber' => $request->get('phone'),
                    'customerAsName' => $request->get('asName'),
                ];

                $session->set('eccube.admin.sales_voucher.customer.search', $searchData);
                $session->set('eccube.admin.sales_voucher.customer.search.page_no', $page_no);
            } else {
                $searchData = (array) $session->get('eccube.admin.sales_voucher.customer.search');
                if (is_null($page_no)) {
                    $page_no = intval($session->get('eccube.admin.sales_voucher.customer.search.page_no'));
                } else {
                    $session->set('eccube.admin.sales_voucher.customer.search.page_no', $page_no);
                }
            }

            $qb = $this->customerMstRepository->getQueryBuilderBySearchData($searchData);

            $event = new EventArgs(
                [
                    'qb' => $qb,
                    'data' => $searchData,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_VOUCHER_INDEX_SEARCH_CUSTOMER_SEARCH, $event);

            /** @var \Knp\Component\Pager\Pagination\SlidingPagination $pagination */
            $pagination = $paginator->paginate(
                $qb,
                $page_no,
                $page_count,
                ['wrap-queries' => true]
            );

            /** @var $Customer \Eccube\Entity\CustomerMst[] */
            $Customer = $pagination->getItems();

            if (empty($Customer)) {
                log_debug('search customermst not found.');
            }

            $data = [];
            foreach ($Customer as $CustomerMst) {
                $data[] = [
                    'id' => $CustomerMst->getId(),
                    'customerCode' => $CustomerMst->getCustomerCode(),
                    'customerName' => $CustomerMst->getCustomerName(),
                    'customerAsName' => $CustomerMst->getCustomerAsName(),
                ];
            }

            $event = new EventArgs(
                [
                    'data' => $data,
                    'customer' => $pagination,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_VOUCHER_INDEX_SEARCH_CUSTOMER_COMPLETE, $event);
            $data = $event->getArgument('data');

            return [
                'data' => $data,
                'pagination' => $pagination,
            ];
        }
    }

    /**
     * 担当者情報を検索する.
     *
     * @Route("/%eccube_admin_route%/salesmenber/html", name="admin_sales_search_member_html")
     * @Route("/%eccube_admin_route%/salesmenber/html/page/{page_no}", requirements={"page_No" = "\d+"}, name="admin_sales_search_member_html_page")
     * @Template("@admin/SalesVoucher/search_member_list.twig")
     *
     * @param Request $request Request
     * @param integer $page_no page no
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchMemberHtml(Request $request, $page_no = null, Paginator $paginator)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('search member start.');
            $page_count = $this->eccubeConfig['eccube_default_page_count'];
            $session = $this->session;

            if ('POST' === $request->getMethod()) {
                $page_no = 1;
                $searchData = [
                    'login_id' => $request->get('login_id'),
                    'name' => $request->get('name'),
                    'department' => $request->get('department'),
                    'Authority' => $request->get('Authority'),
                ];

                $session->set('eccube.master.member.search', $searchData);
                $session->set('eccube.master.member.search.page_no', $page_no);
            } else {
                $searchData = (array) $session->get('eccube.admin.master.member.search');
                if (is_null($page_no)) {
                    $page_no = intval($session->get('eccube.admin.master.member.search.page_no'));
                } else {
                    $session->set('eccube.admin.master.member.search.page_no', $page_no);
                }
            }

            $qb = $this->memberRepository->getQueryBuilderBySearchData($searchData);

            $event = new EventArgs(
                [
                    'qb' => $qb,
                    'data' => $searchData,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_MANAGEMENT_SALES_VOUCHER_LIST_SEARCH_MEMBER_SEARCH, $event);

            /** @var \Knp\Component\Pager\Pagination\SlidingPagination $pagination */
            $pagination = $paginator->paginate(
                $qb,
                $page_no,
                $page_count,
                ['wrap-queries' => true]
            );

            /** @var $Members \Eccube\Entity\Member[] */
            $Members = $pagination->getItems();

            if (empty($Members)) {
                log_debug('search member not found.');
            }

            $data = [];
            foreach ($Members as $Member) {
                $data[] = [
                    'id' => $Member->getId(),
                    'login_id' => $Member->getLoginId(),
                    'name' => $Member->getName(),
                    'department' => $Member->getDepartment(),
                    'Authority' => $Member->getAuthority(),
                ];
            }

            $event = new EventArgs(
                [
                    'data' => $data,
                    'Members' => $pagination,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_MANAGEMENT_SALES_VOUCHER_LIST_SEARCH_MEMBER_COMPLETE, $event);
            $data = $event->getArgument('data');

            return [
                'data' => $data,
                'pagination' => $pagination,
            ];
        }
    }

    /**
     *  担当者情報をセットする.
     *
     * @Route("/%eccube_admin_route%/salesmenber/search/master/id", name="admin_sales_search_member_by_id", methods={"POST"})
     *
     * @param Request $request Request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchMemberById(Request $request)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('search member by id start.');

            /** @var $Member \Eccube\Entity\Member */
            $Member = $this->memberRepository
                ->find($request->get('id'));

            $event = new EventArgs(
                [
                    'Member' => $Member,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_MANAGEMENT_SALES_VOUCHER_LIST_SEARCH_MEMBER_BY_ID_INITIALIZE, $event);

            if (is_null($Member)) {
                log_debug('search member by id not found.');

                return $this->json([], 404);
            }

            log_debug('search member by id found.');

            $data = [
                'id' => $Member->getId(),
                'name' => $Member->getName(),
            ];

            $event = new EventArgs(
                [
                    'data' => $data,
                    'Member' => $Member,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_MANAGEMENT_SALES_VOUCHER_LIST_SEARCH_MEMBER_BY_ID_COMPLETE, $event);
            $data = $event->getArgument('data');

            return $this->json($data);
        }
    }

    /**
     * CSVの出力.
     *
     * @Route("/%eccube_admin_route%/sales_management/export", name="admin_salesVoucherList_export")
     *
     * @param Request $request Request
     *
     * @return StreamedResponse
     */
    public function export(Request $request)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        // sql loggerを無効にする.
        $em = $this->entityManager;
        $em->getConfiguration()->setSQLLogger(null);

        $response = new StreamedResponse();
        $response->setCallback(function () use ($request) {
            // CSV種別を元に初期化.
            $this->csvExportService->initCsvType(CsvType::CSV_TYPE_SALESLIST);

            // ヘッダ行の出力.
            $this->csvExportService->exportHeader();

            $qb = $this->csvExportService
                ->getSalesListQueryBuilder($request);

            // データ行の出力.
            $this->csvExportService->setExportQueryBuilder($qb);

            $this->csvExportService->exportDataCSV(function ($entity, CsvExportService $csvService) use ($request) {
                $Csvs = $csvService->getCsvs();

                // 粗利益計算
                $exportAddress = $entity['exportId'];
                $taxRate = $entity['taxRate'];

                $Details = $this->salesVoucherDetailRepository->findBy(['SalesVoucherHeader' => $entity['id']]);

                //粗利益
                $grossProfit = 0;

                if (!is_null($Details)) {
                    foreach ($Details as $salesVoucherDetail) {
                        if ($exportAddress !== null) {
                            //税金区分
                            $crude = $salesVoucherDetail['sales_price'] - ($salesVoucherDetail['averagePrice'] / (1 + $taxRate / 100));
                            $grossProfit = $grossProfit + round($crude * $salesVoucherDetail['quantity']);
                        } else {
                            $crude = $salesVoucherDetail['sales_price'] - $salesVoucherDetail['averagePrice'];
                            $grossProfit = $grossProfit + round($crude * $salesVoucherDetail['quantity']);
                        }
                    }
                }

                $entity['grossProfit'] = $grossProfit;

                $SalesVoucherListCSV = new \Eccube\Entity\SalesVoucherListCSV();
                $SalesVoucherListCSV->setSalesVoucherNo($entity['salesVoucherNo']);
                $SalesVoucherListCSV->setSalesDate($entity['salesDate']->format('Y-m-d'));
                $SalesVoucherListCSV->setCustomerName($entity['customerName']);
                $SalesVoucherListCSV->setGrossProfitTotalAmount($entity['grossProfit']);
                $SalesVoucherListCSV->setSalesMoneyTotalAmount($entity['salesMoneyTotalAmount']);
                $SalesVoucherListCSV->setPersonnelName($entity['personnelName']);
                $SalesVoucherListCSV->setPersonnelMemo($entity['personnelMemo']);
                $SalesVoucherListCSV->setDepositedAmount(is_null($entity['depositedAmount']) ? 0 : $entity['depositedAmount']);
                $SalesVoucherListCSV->setDepositedNotAmount(is_null($entity['depositedNotAmount']) ? 0 : $entity['depositedNotAmount']);
                $SalesVoucherListCSV->setUpdateUserName($entity['updateUserName']);
                $SalesVoucherListCSV->setUpdateDate($entity['updateDate']);

                $ExportCsvRow = new \Eccube\Entity\ExportCsvRow();

                // CSV出力項目と合致するデータを取得.
                foreach ($Csvs as $Csv) {
                    $ExportCsvRow->setData($csvService->getData($Csv, $SalesVoucherListCSV));
                    $event = new EventArgs(
                        [
                            'csvService' => $csvService,
                            'Csv' => $Csv,
                            'SalesVoucherHeader' => $entity,
                            'ExportCsvRow' => $ExportCsvRow,
                        ],
                        $request
                    );
                    $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_CUSTOMER_CSV_EXPORT, $event);

                    $ExportCsvRow->pushData();
                }

                // 出力.
                $csvService->fputcsv($ExportCsvRow->getRow());
            });
        });

        $now = new \DateTime();
        $filename = 'salesList_'.$now->format('YmdHis').'.csv';
        $response->headers->set('Content-Type', 'application/octet-stream');
        $response->headers->set('Content-Disposition', 'attachment; filename='.$filename);
        $response->send();

        log_info('売上伝票一覧CSV出力ファイル名', [$filename]);

        return $response;
    }

    /**
     * invoice
     *
     * @Route("/%eccube_admin_route%/sales_management/xlsx_Export/{ids}", requirements={"ids" = "\S+"}, name="admin_sales_export_xlsx")
     *
     * @param Request $request Request
     * @param string|null $ids ids
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse|StreamedResponse
     */
    public function xlsxExport(Request $request, string $ids = null)
    {
        $composerMemory = $this->eccubeConfig['eccube_composer_memory_limit'];
        ini_set('memory_limit', $composerMemory);

        try {
            $array_id = explode(',', $ids);
            $response = new StreamedResponse();
            $response->setCallback(function () use ($array_id) {
                // xlsxファイル設定
                $xlsxPath = $this->eccubeConfig->get('eccube_html_dir').'/template/admin/assets/xlsx/invo.xlsx';
                $spreadsheet = IOFactory::load($xlsxPath);

                // 余分のsheetを削除
                if ($spreadsheet->getSheetCount() > 0) {
                    for ($i = $spreadsheet->getSheetCount() - 1; $i >= 0; $i--) {
                        if ($i > 0) {
                            $spreadsheet->removeSheetByIndex($i);
                        }
                    }
                }

                // sheetテンプレートのコピー
                $sheet = $spreadsheet->getSheet(0);
                for ($i = 0; $i < count($array_id); $i++) {
                    if ($i === count($array_id) - 1) {
                        break;
                    } else {
                        $sheetClone = $sheet->copy();
                        $sheetClone->setTitle('Sheet'.($i + 2));
                        $spreadsheet->addSheet($sheetClone);
                    }
                }

                $array_temp_file = [];
                $worksheetID = 0;
                foreach ($array_id as $id) {
                    $xlsxHeader = $this->salesVoucherHeaderRepository->getQueryBuilderBySearchDataCSV($id);
                    // 2021/11/23 CNC UPD START
                    // $xlsxdetails = $this->salesVoucherDetailRepository->getExportPdfBySalesVoucherNo($xlsxHeader[0]['salesVoucherNo']);
                    $xlsxdetails = $this->salesVoucherDetailRepository->getGroupedExportDetailBySalesVoucherNo($xlsxHeader[0]['salesVoucherNo']);
                    // 2021/11/23 CNC UPD END

                    if (!$xlsxHeader or !$xlsxdetails) {
                        // invoiceの取得ができなかった場合
                        throw new \Exception('No Data Found. header_id: '.$id.' sales_voucher_no: '.$xlsxHeader[0]['salesVoucherNo']);
                    }

                    $spreadsheet->setActiveSheetIndex($worksheetID);
                    $spreadsheet->getActiveSheet()
                        // 税関輸出入者コード
                        ->setCellValue('A1', $spreadsheet->getActiveSheet()->getCell('A1')->getCalculatedValue().$this->baseInfoRepository->getTaxExporterCode())
                        // SHIPPER/EXPOTER(complete  name & address)
                        ->setCellValue('B6', 'LCS CO.,LTD')
                        ->setCellValue('B7', 'LCS CO.,LTD')
                        ->setCellValue('B8', $xlsxHeader[0]['export_addr04'])
                        ->setCellValue('A9', $xlsxHeader[0]['export_addr03'])
                        ->setCellValue('A10', $xlsxHeader[0]['export_addr02'])
                        ->setCellValue('A11', $xlsxHeader[0]['export_addr01'])
                        ->setCellValue('B12', $xlsxHeader[0]['name'])
                        ->setCellValue('B13', $this->baseInfoRepository->getPhoneNumber())
                        // CONSIGNEE(complete  name & address)
                        ->setCellValue('E6', $xlsxHeader[0]['customerName'])
                        ->setCellValue('E7', $xlsxHeader[0]['customerName'])
                        ->setCellValue('E8', $xlsxHeader[0]['nation'])
                        ->setCellValue('D10', $xlsxHeader[0]['customer_addr01'])
                        ->setCellValue('D11', $xlsxHeader[0]['customer_addr02'])
                        ->setCellValue('E12', $xlsxHeader[0]['customerName01'])
                        ->setCellValue('E13', $xlsxHeader[0]['phoneNumber'])
                        // COUNTRY  OF  ULTIMATE  DESTINATION
                        ->setCellValue('A16', $spreadsheet->getActiveSheet()->getCell('A16')->getCalculatedValue().'  '.$xlsxHeader[0]['export_addr01'])
                    ;

                    // Package List
                    $count = 20;
                    $country = array();
                    $countryEn = array();
                    $productCountryEn = '';
                    $lenght = count($xlsxdetails);
                    if ($lenght > 1) {
                        $spreadsheet->getActiveSheet()->insertNewRowBefore($count + 1, $lenght - 1);
                    }
                    foreach ($xlsxdetails as $xlsxdetail) {
                        // 商品マスタ
                        //$product = $this->productRepository->find($xlsxdetail->getProductClass()->getProduct());
                        $product = $this->productRepository->find($xlsxdetail['product_id']);
                        if (!is_null($product)) {
                            $spreadsheet->getActiveSheet()
//                            	->setCellValue('A'. $count, $product->getProductNameEn() . "\n\n")
                                // 2021/11/23 CNC UPD START
                            	// ->setCellValue('A'.$count, $product->getProductNameEn()."\n".$xlsxdetail->getProductCode())
                                ->setCellValue('A'.$count, $product->getProductNameEn()."\n".$xlsxdetail['product_code'])
                                ->setCellValue('B'.$count, $product->getProductCountryEn())
                                ->setCellValue('C'.$count, $product->getProductDescriptionEn())
                                // ->setCellValue('D'.$count, $xlsxdetail->getQuantity())
                                ->setCellValue('D'.$count, $xlsxdetail['quantity'])
                                // ->setCellValue('F'.$count, $xlsxdetail->getSalesPrice())
                                // 2021/11/23 CNC UPD END
                                ->setCellValue('F'.$count, $xlsxdetail['sales_price'])
                                ->setCellValue('G'.$count, '=F'.$count.'*D'.$count)
                            ;

                            if (!is_null($product->getProductCountryEn())) {
                                $country[] = $product->getProductCountryEn();
                            }

//                        $generator = new BarcodeGeneratorJPG();
//                        $str_barcode_jpg = $generator->getBarcode($xlsxdetail->getProductCode(), $generator::TYPE_CODE_128);
//                        $path_barcode_jpg = $this->makeTmpImageFile($str_barcode_jpg);
//                        if ($path_barcode_jpg) {
//                            $drawing = new Drawing();
//                            $drawing->setName('barcode')
//                                ->setDescription('barcode'.$xlsxdetail->getProductCode())
//                                ->setPath($path_barcode_jpg)
//                                ->setCoordinates('A'. ($count + 1))
//                                ->setWidthAndHeight(140, 200)
//                                ->setOffsetX(3)
//                                ->setOffsetY(-25)
//                                ->setWorksheet($spreadsheet->getActiveSheet());
//                            $array_temp_file[] = $path_barcode_jpg;
//                        }

                            $count = $count + 1;
                        }
                    }
                    // COUNTRY  OF  ORIGIN  OF  GOODS
                    if (count($country) != 0) {
                        $countryEn = array_unique($country);
                        $countryEn = array_merge($countryEn);
                        for ($i = 0; $i < count($countryEn); $i++) {
                            if ($i === (count($countryEn) - 1)) {
                                $productCountryEn .= $countryEn[$i];
                            } else {
                                $productCountryEn .= $countryEn[$i].'/';
                            }
                        }
                        $spreadsheet->getActiveSheet()
                            ->setCellValue('A15', $spreadsheet->getActiveSheet()->getCell('A15')->getCalculatedValue().'  '.$productCountryEn);
                    }
                    $spreadsheet->getActiveSheet()
                        ->setCellValue('B'.($count), '=SUM(E20:E'.(20 + $lenght - 1).')')
                        ->setCellValue('D'.($count), '=SUM(D20:D'.(20 + $lenght - 1).')')
                        ->setCellValue('B'.($count + 1), '=SUM(G20:G'.(20 + $lenght - 1).')')
                        ->setCellValue('G'.($count + 3), 'JPY')
                        ->setCellValue('A'.($count + 6), $spreadsheet->getActiveSheet()->getCell('A'.($count + 6))->getCalculatedValue() . $xlsxHeader[0]['salesDate']->format('Y.m.d'));
                    ++$worksheetID;
                }
                $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');
                $writer->save('php://output');

//            // 臨時ファイル削除
//            if (is_array($array_temp_file)) {
//                foreach ($array_temp_file as $file) {
//                    if (file_exists($file)) {
//                        @unlink($file);
//                    }
//                }
//            }
        });

            $sysDate = (new \DateTime())->format('YmdHis');
            $response->headers->set('Content-Type', 'application/octet-stream');
            $response->headers->set('Content-Disposition', 'attachment;filename="売上伝票一覧_'.$sysDate.'_invoice.xlsx"');
            $response->send();
            return $response;
        } catch (\Exception $e) {
            $message = trans('admin.netshopAI.csv.download_error').$e->getMessage();
            $this->addError($message, 'admin');

            log_error(trans('admin.netshopAI.csv.download_error'), [$e]);

            return $this->json(['success' => false, 'message' => $message], 500);
        }
    }

    /**
     * @param string $string
     * @return bool|string
     */
    public function makeTmpImageFile(string $string) {
        list($msec, $sec) = explode(' ', microtime());
        $temp = tempnam(sys_get_temp_dir(), 'barcode_'.date('YmdHis').substr($msec, 0, 6));
        if ($temp) {
            file_put_contents($temp, $string);
            // xlsxファイルを作成完了前、該当臨時ファイルは必要です
            return $temp;
        } else {
            return false;
        }
    }

    /**
     * PDFの出力.
     *
     * @Route("/%eccube_admin_route%/sales_management/sales_voucher_pdf/{idFlg}/{ids}", requirements={"idFlg" = "\S+"}, requirements={"ids" = "\S+"}, name="admin_sales_voucher_pdf", methods={"GET"})
     *
     * @param Request $request Request
     * @param string|null $idFlg idFlg
     * @param string|null $ids ids
     * @param SalesVoucherPdfService|null $salesVoucherPdfService SalesVoucherPdfService
     *
     * @return Response
     */
    public function salesVoucherPdf(Request $request, string $idFlg = null, string $ids = null, SalesVoucherPdfService $salesVoucherPdfService = null)
    {
        // PDFを作成する
        $array_id = explode(',', $ids);
        $salesVoucherPdfService->makePdf($idFlg, $array_id);
        // ダウンロードする
        $response = new Response(
            $salesVoucherPdfService->outputPdf(),
            200,
            ['content-type' => 'application/pdf']
        );
        $response->headers->set('Content-Disposition', 'attachment; filename="'.$salesVoucherPdfService->getPdfFileName().'"');

        return $response;
    }

    /**
     * PDFの出力前チェック.
     *
     * @Route("/%eccube_admin_route%/sales_management/sales_voucher_pdf_check", requirements={"ids" = "\S+"}, name="admin_sales_voucher_pdf_check", methods={"PUT"})
     *
     * @param Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function salesVoucherPdfCheck(Request $request)
    {
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
        }

        $ids = $request->get('ids');

        $err_ids = [];
        foreach($ids as $id) {
            $sales_voucher_header = $this->salesVoucherHeaderRepository->find($id);
            if ($sales_voucher_header) {
                $sales_voucher_details = $this->salesVoucherDetailRepository->findOneBy(['SalesVoucherHeader' => $sales_voucher_header->getId()]);
                if (is_null($sales_voucher_details)) {
                    $err_ids[] = [
                        'id' => $sales_voucher_header->getSalesVoucherNo()
                    ];
                }
            } else {
                $err_ids[] = [
                    'id' => $sales_voucher_header->getSalesVoucherNo()
                ];
            }
        }

        return $this->json(['err_ids' => $err_ids]);
    }
}
