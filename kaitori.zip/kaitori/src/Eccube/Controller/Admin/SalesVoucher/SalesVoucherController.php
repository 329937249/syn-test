<?php


namespace Eccube\Controller\Admin\SalesVoucher;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\DBAL\Exception\ForeignKeyConstraintViolationException;
use Eccube\Common\Constant;
use Eccube\Controller\AbstractController;
use Eccube\Entity\CustomerMst;
use Eccube\Entity\LogControllable;
use Eccube\Entity\Master\OtherItemCodeChange;
use Eccube\Entity\Member;
use Eccube\Entity\PayeeVoucherHeader;
use Eccube\Entity\Payment;
use Eccube\Entity\Product;
use Eccube\Entity\ProvisionalShipmentVoucherHeader;
use Eccube\Entity\SalesDepositBalance;
use Eccube\Entity\SalesVoucherDetail;
use Eccube\Entity\SalesVoucherDetailLink;
use Eccube\Entity\SalesVoucherHeader;
use Eccube\Entity\SalesVoucherHeaderHistory;
use Eccube\Entity\StockListProductUnit;
use Eccube\Entity\StockListStorehouseUnit;
use Eccube\Entity\TaxCode;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\AddCartType;
use Eccube\Form\Type\Admin\CsvImportType;
use Eccube\Form\Type\Admin\InputMultipleSerialType;
use Eccube\Form\Type\Admin\SalesVoucherDetailType;
use Eccube\Form\Type\Admin\SalesVoucherSearchCustomerType;
use Eccube\Form\Type\Admin\SalesVoucherType;
use Eccube\Form\Type\Admin\SearchProductType;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\CustomerMstRepository;
use Eccube\Repository\Master\OtherItemCodeChangeRepository;
use Eccube\Repository\Master\SpecialAuthorityRepository;
use Eccube\Repository\PayeeVoucherDetailRepository;
use Eccube\Repository\PayeeVoucherHeaderRepository;
use Eccube\Repository\PaymentRepository;
use Eccube\Repository\PlaceRepository;
use Eccube\Repository\ProductCategoryRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\ProvisionalShipmentVoucherHeaderRepository;
use Eccube\Repository\ProvisionalShipmentVoucherRepository;
use Eccube\Repository\SalesDepositBalanceHistoryRepository;
use Eccube\Repository\SalesDepositBalanceRepository;
use Eccube\Repository\SalesVoucherDetailHistoryRepository;
use Eccube\Repository\SalesVoucherDetailLinkRepository;
use Eccube\Repository\SalesVoucherDetailRepository;
use Eccube\Repository\SalesVoucherHeaderHistoryRepository;
use Eccube\Repository\SalesVoucherHeaderRepository;
use Eccube\Repository\StateRepository;
use Eccube\Repository\StockListProductUnitRepository;
use Eccube\Repository\StockListStorehouseUnitRepository;
use Eccube\Repository\TaxCodeRepository;
use Eccube\Repository\TaxExporterRepository;
use Eccube\Service\PurchaseFlow\Processor\VoucherNoProcessor;
use Eccube\Util\CacheUtil;
use Knp\Component\Pager\Paginator;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Routing\RouterInterface;

/**
 * プログラム名 ： SalesVoucherController.php
 * 概　　要     ： 売上伝票登録画面
 * 作　　成     ： 2021/08/01 CNC
 */
class SalesVoucherController extends AbstractController
{
    // 一覧画面URL
    const PREVIOUS_PAGE_URL_SALES = 'sales_management/sales_voucher_list';
    const BACK_TO_LIST_URL_SALES = 'admin_sales_voucher_list';
    const BACK_TO_LIST_NAME_SALES = 'admin.sales.voucher_list';

    const PREVIOUS_PAGE_URL_PAYEE = 'payee_management/payee_voucher_list';
    const BACK_TO_LIST_URL_PAYEE = 'admin_payee_voucher_list';
    const BACK_TO_LIST_NAME_PAYEE = 'admin.payee.voucher_list';

    const PREVIOUS_PAGE_URL_TEMP = 'sales_management/temp_ex_stock_list';
    const BACK_TO_LIST_URL_TEMP = 'admin_temp_ex_stock_list';
    const BACK_TO_LIST_NAME_TEMP = 'admin.sales.temp_ex_stock_list';

    const TEMPORARY_VOUCHER_NO = '0';

    // INS-START CNC 2022/03/21
    const PREVIOUS_PAGE_URL_SALES_DETAIL = 'sales_management/sales_voucher_detail';
    const BACK_TO_LIST_URL_SALES_DETAIL = 'admin_sales_voucher_detail';
    const BACK_TO_LIST_NAME_SALES_DETAIL = 'admin.sales.voucher_detail';
    // INS-END CNC 2022/03/21

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var OtherItemCodeChangeRepository
     */
    protected $otherItemCodeChangeRepository;

    /**
     * @var SalesVoucherHeaderRepository
     */
    protected $salesVoucherHeaderRepository;

    /**
     * @var SalesVoucherDetailRepository
     */
    protected $salesVoucherDetailRepository;

    /**
     * @var CustomerMstRepository
     */
    protected $customerMstRepository;

    /**
     * @var PaymentRepository
     */
    protected $paymentRepository;

    /**
     * @var TaxCodeRepository
     */
    protected $taxCodeRepository;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var ProductClassRepository
     */
    protected $productClassRepository;

    /**
     * @var ProductCategoryRepository
     */
    protected $productCategoryRepository;

    /**
     * @var StateRepository
     */
    protected $stateRepository;

    /**
     * @var PlaceRepository
     */
    protected $placeRepository;

    /**
     * @var SpecialAuthorityRepository
     */
    protected $specialAuthorityRepository;

    /**
     * @var StockListProductUnitRepository
     */
    protected $stockListProductUnitRepository;

    /**
     * @var StockListStorehouseUnitRepository
     */
    protected $stockListStorehouseUnitRepository;

    /**
     * @var SalesVoucherDetailLinkRepository
     */
    protected $salesVoucherDetailLinkRepository;
    /**
     * @var PayeeVoucherDetailRepository
     */
    protected $payeeVoucherDetailRepository;

    /**
     * @var PayeeVoucherHeaderRepository
     */
    protected $payeeVoucherHeaderRepository;

    /**
     * @var SalesVoucherHeaderHistoryRepository
     */
    protected $salesVoucherHeaderHistoryRepository;

    /**
     * @var SalesVoucherDetailHistoryRepository
     */
    protected $salesVoucherDetailHistoryRepository;

    /**
     * @var SalesDepositBalanceRepository
     */
    protected $salesDepositBalanceRepository;

    /**
     * @var SalesDepositBalanceHistoryRepository
     */
    protected $salesDepositBalanceHistoryRepository;

    /**
     * @var ProvisionalShipmentVoucherHeaderRepository
     */
    protected $provisionalShipmentVoucherHeaderRepository;

    /**
     * @var TaxExporterRepository
     */
    protected $taxExporterRepository;

    /**
     * @var VoucherNoProcessor
     */
    protected $voucherNoProcessor;

    /**
     * @var ProvisionalShipmentVoucherRepository
     */
    protected $provisionalShipmentVoucherRepository;

    /**
     * SalesVoucherController constructor.
     * @param CategoryRepository $categoryRepository カテゴリ
     * @param OtherItemCodeChangeRepository $otherItemCodeChangeRepository その他項目変換
     * @param CustomerMstRepository $customerMstRepository 得意先
     * @param SalesVoucherDetailRepository $salesVoucherDetailRepository 仕入伝票明細
     * @param SalesVoucherHeaderRepository $salesVoucherHeaderRepository 売上伝票ヘッダー
     * @param PaymentRepository $paymentRepository 支払方法
     * @param TaxCodeRepository $taxCodeRepository 税金区分
     * @param ProductRepository $productRepository 商品
     * @param ProductClassRepository $productClassRepository プロタクトクラス
     * @param ProductCategoryRepository $productCategoryRepository 商品
     * @param StateRepository $stateRepository 状態
     * @param PlaceRepository $placeRepository 置場
     * @param SpecialAuthorityRepository $specialAuthorityRepository 特殊権限
     * @param StockListProductUnitRepository $stockListProductUnitRepository 在庫一覧（商品単位）
     * @param StockListStorehouseUnitRepository $stockListStorehouseUnitRepository 在庫一覧（置場単位）
     * @param SalesVoucherDetailLinkRepository $salesVoucherDetailLinkRepository 売上伝票明細紐付
     * @param PayeeVoucherDetailRepository $payeeVoucherDetailRepository 仕入伝票明細
     * @param PayeeVoucherHeaderRepository $payeeVoucherHeaderRepository 仕入伝票ヘッダー
     * @param SalesVoucherHeaderHistoryRepository $salesVoucherHeaderHistoryRepository 売上伝票ヘッダー履歴
     * @param SalesVoucherDetailHistoryRepository $salesVoucherDetailHistoryRepository 売上伝票明細履歴
     * @param SalesDepositBalanceRepository $salesDepositBalanceRepository 売上入金残高
     * @param SalesDepositBalanceHistoryRepository $salesDepositBalanceHistoryRepository 売上入金残高履歴
     * @param ProvisionalShipmentVoucherHeaderRepository $provisionalShipmentVoucherHeaderRepository 仮出荷伝票ヘッダ
     * @param TaxExporterRepository $taxExporterRepository 税関輸出者マスタ
     * @param VoucherNoProcessor $voucherNoProcessor 伝票番号作成
     * @param ProvisionalShipmentVoucherRepository $provisionalShipmentVoucherRepository 仮出荷伝票明細
     */
    public function __construct(
        CategoryRepository $categoryRepository,
        OtherItemCodeChangeRepository $otherItemCodeChangeRepository,
        CustomerMstRepository $customerMstRepository,
        SalesVoucherDetailRepository $salesVoucherDetailRepository,
        SalesVoucherHeaderRepository $salesVoucherHeaderRepository,
        PaymentRepository $paymentRepository,
        TaxCodeRepository $taxCodeRepository,
        ProductRepository $productRepository,
        ProductClassRepository $productClassRepository,
        ProductCategoryRepository $productCategoryRepository,
        StateRepository $stateRepository,
        PlaceRepository $placeRepository,
        SpecialAuthorityRepository $specialAuthorityRepository,
        StockListProductUnitRepository $stockListProductUnitRepository,
        StockListStorehouseUnitRepository $stockListStorehouseUnitRepository,
        SalesVoucherDetailLinkRepository $salesVoucherDetailLinkRepository,
        PayeeVoucherDetailRepository $payeeVoucherDetailRepository,
        PayeeVoucherHeaderRepository $payeeVoucherHeaderRepository,
        SalesVoucherHeaderHistoryRepository $salesVoucherHeaderHistoryRepository,
        SalesVoucherDetailHistoryRepository $salesVoucherDetailHistoryRepository,
        SalesDepositBalanceRepository $salesDepositBalanceRepository,
        SalesDepositBalanceHistoryRepository $salesDepositBalanceHistoryRepository,
        ProvisionalShipmentVoucherHeaderRepository $provisionalShipmentVoucherHeaderRepository,
        TaxExporterRepository $taxExporterRepository,
        VoucherNoProcessor $voucherNoProcessor,
        ProvisionalShipmentVoucherRepository $provisionalShipmentVoucherRepository
    ) {
        $this->categoryRepository = $categoryRepository;
        $this->otherItemCodeChangeRepository = $otherItemCodeChangeRepository;
        $this->customerMstRepository = $customerMstRepository;
        $this->salesVoucherDetailRepository = $salesVoucherDetailRepository;
        $this->salesVoucherHeaderRepository = $salesVoucherHeaderRepository;
        $this->paymentRepository = $paymentRepository;
        $this->taxCodeRepository = $taxCodeRepository;
        $this->productRepository = $productRepository;
        $this->productClassRepository = $productClassRepository;
        $this->productCategoryRepository = $productCategoryRepository;
        $this->stateRepository = $stateRepository;
        $this->placeRepository = $placeRepository;
        $this->specialAuthorityRepository = $specialAuthorityRepository;
        $this->stockListProductUnitRepository = $stockListProductUnitRepository;
        $this->stockListStorehouseUnitRepository = $stockListStorehouseUnitRepository;
        $this->salesVoucherDetailLinkRepository = $salesVoucherDetailLinkRepository;
        $this->payeeVoucherDetailRepository = $payeeVoucherDetailRepository;
        $this->payeeVoucherHeaderRepository = $payeeVoucherHeaderRepository;
        $this->salesVoucherHeaderHistoryRepository = $salesVoucherHeaderHistoryRepository;
        $this->salesVoucherDetailHistoryRepository = $salesVoucherDetailHistoryRepository;
        $this->salesDepositBalanceRepository = $salesDepositBalanceRepository;
        $this->salesDepositBalanceHistoryRepository = $salesDepositBalanceHistoryRepository;
        $this->provisionalShipmentVoucherHeaderRepository = $provisionalShipmentVoucherHeaderRepository;
        $this->taxExporterRepository = $taxExporterRepository;
        $this->voucherNoProcessor = $voucherNoProcessor;
        $this->provisionalShipmentVoucherRepository = $provisionalShipmentVoucherRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/sales_voucher", name="admin_sales_voucher")
     * @Route("/%eccube_admin_route%/sales_voucher/{id}/edit", requirements={"id" = "\d+"}, name="admin_sales_voucher_edit")
     * @Template("@admin/SalesVoucher/sales_voucher.twig")
     * @param Request $request Request
     * @param int|null $id ID
     * @param RouterInterface|null $router Router
     * @throws NotFoundHttpException
     * @throws \Exception
     * @return array|RedirectResponse
     */
    public function index(Request $request, int $id = null, RouterInterface $router = null)
    {
        ini_set('memory_limit', '2048M');
        // タイムアウトを無効にする.
        set_time_limit(0);

        $today = new \DateTime();
        $member = $this->getUser();
        $session = $this->session;
        $session->set('eccube.admin.sales_voucher.authority', 'permission_denied');
        $back_url = $request->headers->get('referer');
        // 特殊商品（料）
        $array_special_cost = [];
        $collection_special_cost = $this->otherItemCodeChangeRepository->findAll();
        /** @var OtherItemCodeChange $entity_special_cost */
        foreach ($collection_special_cost as $entity_special_cost) {
            $array_special_cost[$entity_special_cost->getName()] = $entity_special_cost->getId();
        }

        // INS-START CNC 2022/05/09
        $from_list_quantity_disable = 0;
        // INS-END CNC 2022/05/09

        if (null === $id) {
            // 削除ボタン：非表示
            $controls_enable['delete_display'] = 0;
            // 活性制御
            $controls_enable['except_serial_no'] = 1;
            $front_url = null;
            $temp_voucher_no = null;
            if (!empty($request->request->all())) {
                $front_url = $request->request->get('sales_voucher')['front_url'];
                $temp_voucher_no = $request->request->get('sales_voucher')['temp_voucher_no'];
            }

            if ($front_url === self::BACK_TO_LIST_URL_TEMP) {
                // 商品追加活性制御：活性
                $controls_enable['product_add_display'] = 0;
                // 前ページurl
                $controls_enable['back_to_list_display'] = 1;
                $controls_enable['back_to_list_url'] = self::BACK_TO_LIST_URL_TEMP;
                $controls_enable['back_to_list_name'] = self::BACK_TO_LIST_NAME_TEMP;

                // 空のエンティティを作成、さらに初期値を設定する
                $entity_sales_voucher_header = (new SalesVoucherHeader())
                    // 入力モード: 新規登録
                    ->setInputMode(trans('admin.sales.voucher.input_mode.temp'))
                    ->setSalesVoucherNo($temp_voucher_no);

                // 担当者、作成者、更新者：ログインユーザ
                if ($member) {
                    /** @var Member $member */
                    $entity_sales_voucher_header = $entity_sales_voucher_header
                        ->setPersonnel($member)
                        ->setCreateUserName($member->getName())
                        ->setUpdateUserName($member->getName());
                }
            } else if ($front_url === self::BACK_TO_LIST_URL_PAYEE) {
                // 商品追加活性制御：活性
                $controls_enable['product_add_display'] = 1;
                // 前ページurl
                $controls_enable['back_to_list_display'] = 1;
                $controls_enable['back_to_list_url'] = self::BACK_TO_LIST_URL_PAYEE;
                $controls_enable['back_to_list_name'] = self::BACK_TO_LIST_NAME_PAYEE;

                $entity_sales_voucher_header = (new SalesVoucherHeader())
                    // 入力モード: 新規登録
                    ->setInputMode(trans('admin.sales.voucher.input_mode.new'));
                // 担当者、作成者、更新者：ログインユーザ
                if ($member) {
                    /** @var Member $member */
                    $entity_sales_voucher_header = $entity_sales_voucher_header
                        ->setPersonnel($member)
                        ->setCreateUserName($member->getName())
                        ->setUpdateUserName($member->getName());
                }
            } else {
                // 商品追加活性制御：活性
                $controls_enable['product_add_display'] = 1;
                $controls_enable['back_to_list_display'] = 0;
                if ($front_url === self::BACK_TO_LIST_URL_SALES_DETAIL) {
                    $controls_enable['back_to_list_display'] = 1;
                    $controls_enable['back_to_list_url'] = self::BACK_TO_LIST_URL_SALES_DETAIL;
                    $controls_enable['back_to_list_name'] = self::BACK_TO_LIST_NAME_SALES_DETAIL;
                }
                else if ($front_url === self::BACK_TO_LIST_URL_SALES){
                    $controls_enable['back_to_list_display'] = 1;
                    $controls_enable['back_to_list_url'] = self::BACK_TO_LIST_URL_SALES;
                    $controls_enable['back_to_list_name'] = self::BACK_TO_LIST_NAME_SALES;
                }
                // 空のエンティティを作成、さらに初期値を設定する
                $entity_sales_voucher_header = (new SalesVoucherHeader())
                    // 入力モード: 新規登録
                    ->setInputMode(trans('admin.sales.voucher.input_mode.new'))
                    ->setSalesDate($today);

                // 担当者、作成者、更新者：ログインユーザ
                if ($member) {
                    /** @var Member $member */
                    $entity_sales_voucher_header = $entity_sales_voucher_header
                        ->setPersonnel($member)
                        ->setCreateUserName($member->getName())
                        ->setUpdateUserName($member->getName());
                }
                // 支払い方法：税込10%
                $payment = $this->getPaymentBankTransfer();
                // 税金区分：銀行
                $taxCode = $this->getTaxCodeTransfer();

                // 支払方法：銀行振込
                if ($payment) {
                    $entity_sales_voucher_header = $entity_sales_voucher_header->setPayment($payment);
                }
                // 税金区分：税込10%
                if ($taxCode) {
                    $entity_sales_voucher_header = $entity_sales_voucher_header->setTaxCode($taxCode);
                }
            }
            // 履歴登録用、動作：新規
            $behavior = SalesVoucherHeaderHistory::BEHAVIOR_NEW;
            // 権限
            $authority = $this->specialAuthorityRepository->isValidAuthority($member);
            if ($authority) {
                $session->set('eccube.admin.sales_voucher.authority', 'permission_granted');
            }
        } else {
            if (strpos($back_url, self::PREVIOUS_PAGE_URL_PAYEE)) {
                //仕入伝票一覧から
                // 削除ボタン：非表示
                $controls_enable['delete_display'] = 0;
                // 活性制御
                $controls_enable['except_serial_no'] = 1;
                // 商品追加活性制御：活性
                $controls_enable['product_add_display'] = 1;
                // 前ページurl
                $controls_enable['back_to_list_display'] = 1;
                $controls_enable['back_to_list_url'] = self::BACK_TO_LIST_URL_PAYEE;
                $controls_enable['back_to_list_name'] = self::BACK_TO_LIST_NAME_PAYEE;
                // 履歴登録用、動作：新規
                $behavior = SalesVoucherHeaderHistory::BEHAVIOR_NEW;
                /** @var PayeeVoucherHeader $entity_payee_voucher_header */
                $entity_payee_voucher_header = $this->payeeVoucherHeaderRepository->find($id);
                // 空のエンティティを作成、さらに初期値を設定する
                $entity_sales_voucher_header = (new SalesVoucherHeader())
                    // 入力モード: 新規登録
                    ->setInputMode(trans('admin.sales.voucher.input_mode.new'))
                    ->setSalesDate($today)
                    ->setFrontUrl(self::BACK_TO_LIST_URL_PAYEE);
                if (isset($entity_payee_voucher_header)) {
                    $entity_sales_voucher_header->setMemo($entity_payee_voucher_header->getMemo())
                        ->setPersonnelMemo($entity_payee_voucher_header->getPersonnelMemo())
                        ->setSalesMoneyTotalAmount($entity_payee_voucher_header->getPayeeMoneyTotalAmount());

                    // ADD-START CNC 2022/10/29 sort
                    $detailNo = 1;
                    // ADD-END CNC 2022/10/29 sort

                    foreach ($entity_payee_voucher_header->getPayeeVoucherDetails() as $entity_payee_voucher_detail) {
                        $product = $this->productRepository->find($entity_payee_voucher_detail->getProductId());
                        $product_taxCode = null;
                        $entity_sales_voucher_detail = (new SalesVoucherDetail())
                            // ADD-START CNC 2022/10/29 sort
                            ->setSalesDetailsNo($detailNo)
                            // ADD-END CNC 2022/10/29 sort
                            ->setProductCode($entity_payee_voucher_detail->getProductCode())
                            ->setProductId($entity_payee_voucher_detail->getProductId())
                            ->setProductClass($entity_payee_voucher_detail->getProductClass())
                            ->setSerialNo($entity_payee_voucher_detail->getSerialNo())
                            ->setState($entity_payee_voucher_detail->getState())
                            ->setQuantity($entity_payee_voucher_detail->getQuantity())
                            ->setTotalSalesAmount($entity_payee_voucher_detail->getPayeeMoneyAmount())
                            ->setSalesPrice($entity_payee_voucher_detail->getPayeePrice())
                            ->setPlace($entity_payee_voucher_header->getPlace());
                        if (!empty($product->getTaxCode())) {
                            $product_taxCode = $this->taxCodeRepository->find($product->getTaxCode());
                            $entity_sales_voucher_detail->setTaxCode($product_taxCode->getId());
                        } else {
                            $entity_sales_voucher_detail->setTaxCode($product_taxCode);
                        }

                        // 2022/01/14 CNC ADD START
                        $parameter_stock_by_product = [
                            'productId' => $entity_payee_voucher_detail->getProductId(),
                            'ProductClass' => $entity_payee_voucher_detail->getProductClass(),
                            'productCode' => $entity_payee_voucher_detail->getProductCode(),
                            'State' => $entity_payee_voucher_detail->getState(),
                        ];
                        $collection_stock_list_product_unit = $this->stockListProductUnitRepository
                            ->findBy($parameter_stock_by_product);

                        if (isset($collection_stock_list_product_unit[0])) {
                            // 平均単価
                            $entity_sales_voucher_detail->setAveragePrice($collection_stock_list_product_unit[0]->getAverageUnitPrice());
                        } else {
                            //平均単価
                            $entity_sales_voucher_detail->setAveragePrice(0);
                        }
                        // 2022/01/14 CNC ADD END

                        $entity_sales_voucher_header->addSalesVoucherDetail($entity_sales_voucher_detail);

                        // ADD-START CNC 2022/10/29 sort
                        $detailNo++;
                        // ADD-END CNC 2022/10/29 sort
                    }
                    // 支払い方法
                    $payment = $this->paymentRepository->find($entity_payee_voucher_header->getPayment());
                    if ($payment) {
                        $entity_sales_voucher_header = $entity_sales_voucher_header->setPayment($payment);
                    }
                }

                // 担当者、作成者、更新者：ログインユーザ
                if ($member) {
                    /** @var Member $member */
                    $entity_sales_voucher_header = $entity_sales_voucher_header
                        ->setPersonnel($member)
                        ->setCreateUserName($member->getName())
                        ->setUpdateUserName($member->getName());
                }
                // 権限
                $authority = $this->specialAuthorityRepository->isValidAuthority($member);
                if ($authority) {
                    $session->set('eccube.admin.sales_voucher.authority', 'permission_granted');
                }
                // 税金区分：銀行
                $taxCode = $this->getTaxCodeTransfer();
                // 税金区分：税込10%
                if ($taxCode) {
                    $entity_sales_voucher_header = $entity_sales_voucher_header->setTaxCode($taxCode);
                }
            } else if (strpos($back_url, self::PREVIOUS_PAGE_URL_TEMP)) {
                //仮出荷伝票一覧から
                // 削除ボタン：非表示
                $controls_enable['delete_display'] = 0;
                // 活性制御：活性
                $controls_enable['except_serial_no'] = 1;
                // 商品追加活性制御：非活性
                $controls_enable['product_add_display'] = 0;
                // 前ページurl
                $controls_enable['back_to_list_display'] = 1;
                $controls_enable['back_to_list_url'] = self::BACK_TO_LIST_URL_TEMP;
                $controls_enable['back_to_list_name'] = self::BACK_TO_LIST_NAME_TEMP;

                // INS-START CNC 2022/05/09
                $from_list_quantity_disable = 1;
                // INS-END CNC 2022/05/09

                // 履歴登録用、動作：新規
                $behavior = SalesVoucherHeaderHistory::BEHAVIOR_NEW;
                $money_total_amount = 0;
                // 空のエンティティを作成、さらに初期値を設定する
                $entity_sales_voucher_header = (new SalesVoucherHeader())
                    // 入力モード: 新規登録
                    ->setInputMode(trans('admin.sales.voucher.input_mode.temp'))
                    ->setSalesDate($today)
                    ->setFrontUrl(self::BACK_TO_LIST_URL_TEMP);
                /** @var ProvisionalShipmentVoucherHeader $entity_provisional_shipment_voucher_header */
                $entity_provisional_shipment_voucher_header = $this->provisionalShipmentVoucherHeaderRepository->find($id);
                if (isset($entity_provisional_shipment_voucher_header)) {
                    $entity_sales_voucher_header->setMemo($entity_provisional_shipment_voucher_header->getMemo())
                        ->setPersonnelMemo($entity_provisional_shipment_voucher_header->getPersonnelMemo())
                        ->setSalesVoucherNo($entity_provisional_shipment_voucher_header->getProvisionalShipmentVoucherNo())
                        ->setTempVoucherNo($entity_provisional_shipment_voucher_header->getProvisionalShipmentVoucherNo());

                    // ADD-START CNC 2022/10/29 sort
                    $detailNo = 1;
                    // ADD-END CNC 2022/10/29 sort

                    foreach ($entity_provisional_shipment_voucher_header->getDetails() as $entity_provisional_shipment_voucher_detail) {
                        $product = $this->productRepository->find($entity_provisional_shipment_voucher_detail->getProductId());
                        $product_taxCode = null;
                        $entity_sales_voucher_detail = (new SalesVoucherDetail())
                            // ADD-START CNC 2022/10/29 sort
                            ->setSalesDetailsNo($detailNo)
                            // ADD-END CNC 2022/10/29 sort
                            ->setProductCode($entity_provisional_shipment_voucher_detail->getProductCode())
                            ->setProductId($entity_provisional_shipment_voucher_detail->getProductId())
                            ->setProductClass($entity_provisional_shipment_voucher_detail->getProductClass())
                            ->setState($entity_provisional_shipment_voucher_detail->getState())
                            ->setQuantity($entity_provisional_shipment_voucher_detail->getQuantity())
                            ->setTotalSalesAmount($entity_provisional_shipment_voucher_detail->getTotalSalesAmount())
                            ->setSalesPrice($entity_provisional_shipment_voucher_detail->getSalesPrice())
                            ->setSalesPriceExtax($entity_provisional_shipment_voucher_detail->getSalesPriceExtax());
                        if (!empty($product->getTaxCode())) {
                            $product_taxCode = $this->taxCodeRepository->find($product->getTaxCode());
                            $entity_sales_voucher_detail->setTaxCode($product_taxCode->getId());
                        } else {
                            $entity_sales_voucher_detail->setTaxCode($product_taxCode);
                        }

                        // 2022/01/14 CNC ADD START
                        $parameter_stock_by_product = [
                            'productId' => $entity_provisional_shipment_voucher_detail->getProductId(),
                            'ProductClass' => $entity_provisional_shipment_voucher_detail->getProductClass(),
                            'productCode' => $entity_provisional_shipment_voucher_detail->getProductCode(),
                            'State' => $entity_provisional_shipment_voucher_detail->getState(),
                        ];
                        $collection_stock_list_product_unit = $this->stockListProductUnitRepository
                            ->findBy($parameter_stock_by_product);

                        if (isset($collection_stock_list_product_unit[0])) {
                            // 平均単価
                            $entity_sales_voucher_detail->setAveragePrice($collection_stock_list_product_unit[0]->getAverageUnitPrice());
                        } else {
                            //平均単価
                            $entity_sales_voucher_detail->setAveragePrice(0);
                        }
                        // 2022/01/14 CNC ADD END

                        $entity_sales_voucher_header->addSalesVoucherDetail($entity_sales_voucher_detail);
                        $money_total_amount += (int) $entity_provisional_shipment_voucher_detail->getTotalSalesAmount();

                        // ADD-START CNC 2022/10/29 sort
                        $detailNo++;
                        // ADD-END CNC 2022/10/29 sort
                    }
                    $entity_sales_voucher_header = $entity_sales_voucher_header->setSalesMoneyTotalAmount($money_total_amount);
                    // 支払い方法
                    $payment = $this->paymentRepository->find($entity_provisional_shipment_voucher_header->getPayment());
                    // 税金区分
                    $taxCode = $this->taxCodeRepository->find($entity_provisional_shipment_voucher_header->getTaxRateCategory());
                    // 得意先
                    $customer = $this->customerMstRepository->find($entity_provisional_shipment_voucher_header->getCustomer());
                    // 輸出住所
                    $exportAddress = null;
                    if ($entity_provisional_shipment_voucher_header->getExportAddress()) {
                        $exportAddress = $this->taxExporterRepository->find($entity_provisional_shipment_voucher_header->getExportAddress());
                    }
                    if ($payment) {
                        $entity_sales_voucher_header = $entity_sales_voucher_header->setPayment($payment);
                    }
                    if ($taxCode) {
                        $entity_sales_voucher_header = $entity_sales_voucher_header->setTaxCode($taxCode);
                    }
                    if ($customer) {
                        $entity_sales_voucher_header = $entity_sales_voucher_header->setCustomer($customer);
                    }
                    if ($exportAddress) {
                        $entity_sales_voucher_header = $entity_sales_voucher_header->setExportAddress($exportAddress);
                    }
                }
                // 担当者、作成者、更新者：ログインユーザ
                if ($member) {
                    /** @var Member $member */
                    $entity_sales_voucher_header = $entity_sales_voucher_header
                        ->setPersonnel($member)
                        ->setCreateUserName($member->getName())
                        ->setUpdateUserName($member->getName());
                }
                // 権限
                $authority = $this->specialAuthorityRepository->isValidAuthority($member);
                if ($authority) {
                    $session->set('eccube.admin.sales_voucher.authority', 'permission_granted');
                }
            } else {
                //売上一覧から
                // 前ページurl
                $controls_enable['back_to_list_display'] = 1;
                if (strpos($back_url, self::PREVIOUS_PAGE_URL_SALES_DETAIL)){
                    $controls_enable['back_to_list_url'] = self::BACK_TO_LIST_URL_SALES_DETAIL;
                    $controls_enable['back_to_list_name'] = self::BACK_TO_LIST_NAME_SALES_DETAIL;
                } else {
                    $controls_enable['back_to_list_url'] = self::BACK_TO_LIST_URL_SALES;
                    $controls_enable['back_to_list_name'] = self::BACK_TO_LIST_NAME_SALES;
                }

                // 履歴登録用、動作：修正
                $behavior = SalesVoucherHeaderHistory::BEHAVIOR_CHANGE;
                /** @var SalesVoucherHeader $entity_sales_voucher_header */
                $entity_sales_voucher_header = $this->salesVoucherHeaderRepository->find($id);
                if (strpos($back_url, self::PREVIOUS_PAGE_URL_SALES_DETAIL)){
                    $entity_sales_voucher_header->setFrontUrl(self::BACK_TO_LIST_URL_SALES_DETAIL);
                } else {
                    $entity_sales_voucher_header->setFrontUrl(self::BACK_TO_LIST_URL_SALES);
                }

                //売上入金残高
                $collection_sales_deposit_balance = $this->salesDepositBalanceRepository->findBy(['SalesVoucherHeader' => $id]);
                //未入金(入金額0）の場合のみ修正,削除可能
                if (isset($collection_sales_deposit_balance[0]) && $collection_sales_deposit_balance[0]->getDepositedAmount() === '0') {
                    // 削除ボタン：表示
                    $controls_enable['delete_display'] = 1;
                } else {
                    // 削除ボタン：非表示
                    $controls_enable['delete_display'] = 0;
                }
                //売上入金残高履歴
                $collection_sales_deposit_balance_history = $this->salesDepositBalanceHistoryRepository->findBy(
                    ['salesVoucherNo' => $entity_sales_voucher_header->getSalesVoucherNo()], ['revisionNo' => 'DESC']);
                //未入金額が0以外の場合、修正可
                if (isset($collection_sales_deposit_balance_history[0]) && $collection_sales_deposit_balance_history[0]->getUndepositAmount() === '0') {
                    // 活性制御
                    $controls_enable['except_serial_no'] = 0;
                    // 商品追加活性制御：活性
                    $controls_enable['product_add_display'] = 0;
                } else {
                    // 活性制御
                    $controls_enable['except_serial_no'] = 1;
                    // 商品追加活性制御：活性
                    $controls_enable['product_add_display'] = 1;
                }

                foreach ($entity_sales_voucher_header->getSalesVoucherDetails() as $key => $sales_voucher_details) {
                    $sales_voucher_details->getProductCode();
                    if ($sales_voucher_details->getState() !== null && $sales_voucher_details->getPlace() !== null) {
                        $entity_sales_voucher_header->getSalesVoucherDetails()->get($key)->setInnerStockQuantity($sales_voucher_details->getState()->getId()."-".$sales_voucher_details->getPlace()->getId()."-".$sales_voucher_details->getStockQuantity());
                    }
                }
                $entity_sales_voucher_header->setInputMode(trans('admin.sales.voucher.input_mode.edit'));

                // 更新者：ログインユーザ
                if ($member) {
                    /** @var Member $member */
                    $entity_sales_voucher_header = $entity_sales_voucher_header->setUpdateUserName($member->getName());
                }
                // 権限
                $authority = $this->specialAuthorityRepository->isValidAuthority($member);
                if ($authority) {
                    $session->set('eccube.admin.sales_voucher.authority', 'permission_granted');
                }
            }
        }

        // 編集前の仕入伝票情報を保持
        $origin_entity_sales_voucher_header = clone $entity_sales_voucher_header;
        $origin_entity_sales_detail_collection = new ArrayCollection();
        if (!strpos($back_url, self::PREVIOUS_PAGE_URL_TEMP) && !strpos($back_url, self::PREVIOUS_PAGE_URL_PAYEE)) {
            foreach ($origin_entity_sales_voucher_header->getSalesVoucherDetails() as $detail) {
                // 「ヘッダID_明細NO」をキーとする
                $origin_entity_sales_detail_collection[$detail->getSalesVoucherHeader()->getId().'_'.$detail->getSalesDetailsNo()] = $detail;
            }
        }

        // INS-START CNC 2022/03/10
        $customercode = '';
        if ($entity_sales_voucher_header->getCustomer()) {
            $customercode = $entity_sales_voucher_header->getCustomer()->getCustomerCode();
        }
        // INS-END CNC 2022/03/10

        // 削除比較用
        $entity_sales_detail_collection_for_delete = new ArrayCollection();
        foreach ($entity_sales_voucher_header->getSalesVoucherDetails() as $detail) {
            $entity_sales_detail_collection_for_delete->add($detail);
        }
        $builder_sales_voucher_header = $this->formFactory->createBuilder(SalesVoucherType::class, $entity_sales_voucher_header);
        $form_sales_voucher_header = $builder_sales_voucher_header->getForm();

        if ('POST' === $request->getMethod()) {
            if (strpos($back_url, self::PREVIOUS_PAGE_URL_TEMP)) {
                // 明細のソート
                $array_entity_details = $request->get('sales_voucher')['SalesVoucherDetails'];
                array_multisort($array_entity_details);
                $array_entity_header = $request->request->get('sales_voucher');
                $array_entity_header['SalesVoucherDetails'] = $array_entity_details;
                $request->request->set('sales_voucher', $array_entity_header);
            }

            $form_sales_voucher_header->handleRequest($request);

            if ($id != null and strpos($back_url, self::PREVIOUS_PAGE_URL_TEMP) == false) {
                if ($request->get('orderUpdateTime') != $entity_sales_voucher_header->getUpdateDate()->format('Y-m-d H:i:s')) {
                    $form_sales_voucher_header['SalesVoucherDetailsErrors']
                        ->addError(new FormError(trans('admin.payee.voucher.detail_update_date_error')));
                }
            }

            // 権限チェック用日付（新規日付）
            $create_date = $origin_entity_sales_voucher_header->getCreateDate()
                ? clone $origin_entity_sales_voucher_header->getCreateDate()
                : clone $today;
            // 五日前
            $five_days_before = $create_date->sub(new \DateInterval('P4DT23H59M59S'))
                ->setTimezone(new \DateTimeZone('Asia/Tokyo'))
                ->format('Ymd');
            // 五日後
            $five_days_after = $create_date->add(new \DateInterval('P9DT23H59M59S'))
                ->setTimezone(new \DateTimeZone('Asia/Tokyo'))
                ->format('Ymd');

            // 該当売上日
            $sales_date = (new \DateTime($request->get('sales_voucher')['sales_date'], new \DateTimeZone('Asia/Tokyo')))
                ->format('Ymd');

            // 権限と日付
            if (!$authority &&
//                $origin_entity_sales_voucher_header->getSalesDate()->setTimezone(new \DateTimeZone('Asia/Tokyo'))->format('Ymd') !== $today->setTimezone(new \DateTimeZone('Asia/Tokyo'))->format('Ymd')) {
                ($sales_date < $five_days_before || $sales_date > $five_days_after)) {
                $form_sales_voucher_header['sales_date']->addError(
                    new FormError(
                        trans('admin.sales.voucher.detail_date_range').' 作成：'.
                        ($origin_entity_sales_voucher_header->getSalesDate() ?: $today)
                            ->setTimezone(new \DateTimeZone('Asia/Tokyo'))
                            ->format('Ymd')
                    )
                );
//                $form_sales_voucher_header->addError(
//                    new FormError(
//                        trans('admin.sales.voucher.update_date_permission').
//                        ' 売上日：'.
//                        $origin_entity_sales_voucher_header->getSalesDate()->format('Y/m/d')
//                    )
//                );
            }

            // Customer(MST)
            $sales_id = $request->get('sales_voucher')['Customer']['id'];
            $registered_entity_customer = $this->customerMstRepository->find($sales_id);
            if (!$registered_entity_customer) {
                $form_sales_voucher_header['Customer']['customerName']
                    ->addError(new FormError(trans('This value should not be blank.', [], 'validators')));
                $form_sales_voucher_header['Customer']
                    ->addError(new FormError(trans('This value should not be blank.', [], 'validators')));
            } else {
                $entity_sales_voucher_header->setCustomer($registered_entity_customer);
            }

            if ($form_sales_voucher_header->isValid()) {
                /** @var SalesVoucherHeader $sales_voucher */
                $sales_voucher = $form_sales_voucher_header->getData();

                if ($request->get('mode') == 'register') {
                    try {
                        log_info('売上伝票登録開始', [$id]);

                        $sales_voucher->setVoucherNo($sales_voucher->getSalesVoucherNo() ?: self::TEMPORARY_VOUCHER_NO)
                            ->setCustomer($registered_entity_customer);

                        // 明細
                        $money_total_amount = 0;
                        $sales_detail_no = $this->salesVoucherDetailRepository
                            ->getMaxDetailNoInOneVoucher($entity_sales_voucher_header);
                        $collection_sales_voucher_details = $sales_voucher->getSalesVoucherDetails();

                        // 削除
                        /** @var SalesVoucherDetail $origin_detail */
                        foreach ($entity_sales_detail_collection_for_delete as $origin_detail) {
                            if ($collection_sales_voucher_details->contains($origin_detail) === false) {
                                //売上伝票明細関連紐付削除
                                $this->removeSalesVoucherDetailLinkWithDetail($origin_detail, $sales_voucher);
                                if (!isset($array_special_cost[$origin_detail->getProductCode()])) {
                                    $this->removeStockInfoWithDetailRemoved($origin_detail, $member->getName());
                                }
                                $this->entityManager->remove($origin_detail);
                            }
                        }
                        // 変更
                        if ($collection_sales_voucher_details && is_array($collection_sales_voucher_details->getValues())) {
                            $array_sales_voucher_details = $collection_sales_voucher_details->getValues();

                            // ADD-START CNC 2022/10/29 sort
                            $array_sales_voucher_details = array_reverse($array_sales_voucher_details);
                            // ADD-END CNC 2022/10/29 sort

                            // 在庫連動条件
                            $stock_by_product_conditions = [];
                            $stock_by_place_conditions = [];
                            foreach ($array_sales_voucher_details as $line_no => $entity_detail) {
                                $detail_change_flg = true;
                                /** @var SalesVoucherDetail $entity_detail */
                                if (!$entity_detail->getSalesVoucherHeader() ||
                                    !$entity_detail->isEqualFromHeaderPage(
                                        $origin_entity_sales_detail_collection[$entity_detail->getSalesVoucherHeader()->getId().'_'.$entity_detail->getSalesDetailsNo()]
                                    )
                                ) {
                                    //売上伝票明細関連紐付削除
                                    $this->removeSalesVoucherDetailLinkWithDetail($entity_detail, $sales_voucher);
                                    if ($entity_detail->getSalesDetailsNo()) {
                                        $entity_detail->setSalesDetailsNo($entity_detail->getSalesDetailsNo());
                                        $sales_detail_no = $entity_detail->getSalesDetailsNo();
                                    } else {
                                        $entity_detail->setSalesDetailsNo(++$sales_detail_no);
                                    }
                                    $entity_detail
                                        ->setVoucherNo(self::TEMPORARY_VOUCHER_NO)
                                        ->setSalesVoucherHeader($sales_voucher)
                                        ->setTotalSalesAmount()
                                        ->setCreateUserName($entity_detail->getCreateUserName() ?: $member->getName())
                                        ->setUpdateUserName($member->getName());
                                } else {
                                    $detail_change_flg = false;
                                }

                                if (isset($array_special_cost[$entity_detail->getProductCode()])) {
                                    // 特殊商品（料）の場合、置場が必要項目だから、とにかく設定する
                                    $places = $this->placeRepository->findAll();
                                    $entity_detail->setPlace($places[0]);
                                }

                                if ($entity_detail->getSerialNo()) {
                                    // シリアル商品の場合
                                    //  置場は画面値じゃなく、在庫テーブルにて該当商品に対する最新置場を設定する
                                    //  商品情報は画面入力時に誤りが発生する状況が存在するので、在庫テーブルの商品情報も利用する
                                    //    シリアルで検索の効率が低下ですから、入力誤りの場合はとにかく無視する
                                    $collection_stock_by_place = $this->stockListStorehouseUnitRepository
                                        ->findBy(
                                            [
                                                'productId' => $entity_detail->getProductId(),
                                                'ProductClass' => $entity_detail->getProductClass(),
                                                'serialNo' => $entity_detail->getSerialNo(),
                                            ],
                                            /* ['createDate' => 'DESC'] */
                                            ['stockQuantity' => 'DESC', 'updateDate' => 'DESC']
                                        );
                                    if (isset($collection_stock_by_place[0])) {
                                        /** @var StockListStorehouseUnit $entity_stock_by_place */
                                        $entity_stock_by_place = $collection_stock_by_place[0];
                                        // 商品情報
//                                        $entity_detail->setProductId($entity_stock_by_place->getProductId());
//                                        $entity_detail->setProductClass($entity_stock_by_place->getProductClass());
//                                        $entity_detail->setProductCode($entity_stock_by_place->getProductCode());
                                        // 置場
                                        $entity_detail->setPlace($entity_stock_by_place->getStorehouse());
                                    }
                                }
                                // 合計金額
                                $money_total_amount += $entity_detail->getTotalSalesAmount();

                                // 特殊商品（料）の場合、下記処理を除く
                                if (!isset($array_special_cost[$entity_detail->getProductCode()])) {
                                    if ($detail_change_flg) {
                                        //売上伝票明細紐付
                                        /**
                                         * @var SalesVoucherDetailLink $entity_detail_link
                                         * @var PayeeVoucherHeader $payee_voucher_header_entity
                                         */
                                        //シリアル番号あり、関連仕入データ取得
                                        if (!empty($entity_detail->getSerialNo())) {
                                            $entity_detail_link = new SalesVoucherDetailLink();
                                            $collection_payee_voucher_detail = $this->payeeVoucherDetailRepository->findBy(
                                                [
                                                    'product_code' => $entity_detail->getProductCode(),
                                                    'serial_no' => $entity_detail->getSerialNo(),
                                                ],
                                                ['update_date' => 'DESC']
                                            );
                                            if (isset($collection_payee_voucher_detail[0])) {
                                                $entity_payee_voucher_detail = $collection_payee_voucher_detail[0];
                                                $payee_voucher_header_entity = $this->payeeVoucherHeaderRepository->find($entity_payee_voucher_detail['payee_voucher_header_id']);
                                                $entity_detail_link->setSalesVoucherHeader($sales_voucher)
                                                    ->setSalesVoucherNo($sales_voucher->getSalesVoucherNo())
                                                    ->setSalesDetailsNo(($entity_detail->getSalesDetailsNo()) ?: ++$sales_detail_no)
                                                    ->setPayeeVoucherHeader($payee_voucher_header_entity)
                                                    ->setPayeeVoucherNo($entity_payee_voucher_detail['payee_voucher_no'])
                                                    ->setPayeeDetailsNo($entity_payee_voucher_detail['payee_detail_no'])
                                                    ->setProductCode($entity_detail->getProductCode())
                                                    ->setState($entity_detail->getState())
                                                    ->setPlace($entity_detail->getPlace())
                                                    ->setQuantity($entity_detail->getQuantity())
                                                    ->setCreateUserName($member->getName())
                                                    ->setUpdateUserName($member->getName());
                                                $sales_voucher->addSalesVoucherDetailLink($entity_detail_link);
                                            }
                                        } else {
                                            //シリアル番号なし
                                            $first_detail = true;
                                            $sales_quantity_total = $entity_detail->getQuantity();
                                            $collection_sales_voucher_detail_link = $this->getSalesVoucherDetailLinkData($entity_detail);
                                            //売上伝票明細紐付あり
                                            if (isset($collection_sales_voucher_detail_link[0])) {
                                                //売上数量
                                                $link_sales_quantity_total = $collection_sales_voucher_detail_link[0]['quantityTotal'];
                                                //関連仕入データ取得
                                                $collection_payee_voucher_detail = $this->getPayeeVoucherDetailByDetailLink($collection_sales_voucher_detail_link[0]);
                                                foreach ($collection_payee_voucher_detail as $entity_payee_voucher_detail) {
                                                    $entity_detail_link = new SalesVoucherDetailLink();
                                                    $payee_voucher_header_entity = $this->payeeVoucherHeaderRepository->find($entity_payee_voucher_detail['payee_voucher_header_id']);
                                                    if ($entity_payee_voucher_detail['payee_voucher_no'] === $collection_sales_voucher_detail_link[0]['payee_Voucher_No'] &&
                                                        $entity_payee_voucher_detail['payee_detail_no'] === $collection_sales_voucher_detail_link[0]['payee_Details_No']) {
                                                        //関連仕入データ数量=売上数量の場合、次へ
                                                        if ($collection_payee_voucher_detail[0]['quantity'] === $link_sales_quantity_total && $first_detail) {
                                                            $first_detail = false;
                                                            continue;
                                                        }
                                                        if ($entity_payee_voucher_detail['quantity'] - $link_sales_quantity_total - $sales_quantity_total >= 0) {
                                                            $entity_detail_link->setSalesVoucherHeader($sales_voucher)
                                                                ->setSalesVoucherNo($sales_voucher->getSalesVoucherNo())
                                                                ->setSalesDetailsNo(($entity_detail->getSalesDetailsNo()) ?: ++$sales_detail_no)
                                                                ->setPayeeVoucherHeader($payee_voucher_header_entity)
                                                                ->setPayeeVoucherNo($entity_payee_voucher_detail['payee_voucher_no'])
                                                                ->setPayeeDetailsNo($entity_payee_voucher_detail['payee_detail_no'])
                                                                ->setProductCode($entity_detail->getProductCode())
                                                                ->setState($entity_detail->getState())
                                                                ->setPlace($entity_detail->getPlace())
                                                                ->setQuantity($sales_quantity_total)
                                                                ->setCreateUserName($member->getName())
                                                                ->setUpdateUserName($member->getName());
                                                            $sales_voucher->addSalesVoucherDetailLink($entity_detail_link);
                                                            break;
                                                        } else {
                                                            $entity_detail_link->setSalesVoucherHeader($sales_voucher)
                                                                ->setSalesVoucherNo($sales_voucher->getSalesVoucherNo())
                                                                ->setSalesDetailsNo(($entity_detail->getSalesDetailsNo()) ?: ++$sales_detail_no)
                                                                ->setPayeeVoucherHeader($payee_voucher_header_entity)
                                                                ->setPayeeVoucherNo($entity_payee_voucher_detail['payee_voucher_no'])
                                                                ->setPayeeDetailsNo($entity_payee_voucher_detail['payee_detail_no'])
                                                                ->setProductCode($entity_detail->getProductCode())
                                                                ->setState($entity_detail->getState())
                                                                ->setPlace($entity_detail->getPlace())
                                                                ->setQuantity($entity_payee_voucher_detail['quantity'] - $link_sales_quantity_total)
                                                                ->setCreateUserName($member->getName())
                                                                ->setUpdateUserName($member->getName());
                                                            $sales_voucher->addSalesVoucherDetailLink($entity_detail_link);
                                                            $sales_quantity_total = $sales_quantity_total - ($entity_payee_voucher_detail['quantity'] - $link_sales_quantity_total);
                                                        }
                                                    } else {
                                                        if ($entity_payee_voucher_detail['quantity'] >= $sales_quantity_total) {
                                                            $entity_detail_link->setSalesVoucherHeader($sales_voucher)
                                                                ->setSalesVoucherNo($sales_voucher->getSalesVoucherNo())
                                                                ->setSalesDetailsNo(($entity_detail->getSalesDetailsNo()) ?: ++$sales_detail_no)
                                                                ->setPayeeVoucherHeader($payee_voucher_header_entity)
                                                                ->setPayeeVoucherNo($entity_payee_voucher_detail['payee_voucher_no'])
                                                                ->setPayeeDetailsNo($entity_payee_voucher_detail['payee_detail_no'])
                                                                ->setProductCode($entity_detail->getProductCode())
                                                                ->setState($entity_detail->getState())
                                                                ->setPlace($entity_detail->getPlace())
                                                                ->setQuantity($sales_quantity_total)
                                                                ->setCreateUserName($member->getName())
                                                                ->setUpdateUserName($member->getName());
                                                            $sales_voucher->addSalesVoucherDetailLink($entity_detail_link);
                                                            break;
                                                        } else {
                                                            $entity_detail_link->setSalesVoucherHeader($sales_voucher)
                                                                ->setSalesVoucherNo($sales_voucher->getSalesVoucherNo())
                                                                ->setSalesDetailsNo(($entity_detail->getSalesDetailsNo()) ?: ++$sales_detail_no)
                                                                ->setPayeeVoucherHeader($payee_voucher_header_entity)
                                                                ->setPayeeVoucherNo($entity_payee_voucher_detail['payee_voucher_no'])
                                                                ->setPayeeDetailsNo($entity_payee_voucher_detail['payee_detail_no'])
                                                                ->setProductCode($entity_detail->getProductCode())
                                                                ->setState($entity_detail->getState())
                                                                ->setPlace($entity_detail->getPlace())
                                                                ->setQuantity($entity_payee_voucher_detail['quantity'])
                                                                ->setCreateUserName($member->getName())
                                                                ->setUpdateUserName($member->getName());
                                                            $sales_voucher->addSalesVoucherDetailLink($entity_detail_link);
                                                            $sales_quantity_total = $sales_quantity_total - $entity_payee_voucher_detail['quantity'];
                                                        }
                                                    }
                                                }
                                                //売上伝票明細紐付なし
                                            } else {
                                                $collection_payee_voucher_detail = $this->getPayeeVoucherDetailData($entity_detail);
                                                foreach ($collection_payee_voucher_detail as $entity_payee_voucher_detail) {
                                                    $entity_detail_link = new SalesVoucherDetailLink();
                                                    $payee_voucher_header_entity = $this->payeeVoucherHeaderRepository->find($entity_payee_voucher_detail['payee_voucher_header_id']);
                                                    if ($entity_payee_voucher_detail['quantity'] >= $sales_quantity_total) {
                                                        $entity_detail_link->setSalesVoucherHeader($sales_voucher)
                                                            ->setSalesVoucherNo($sales_voucher->getSalesVoucherNo())
                                                            ->setSalesDetailsNo(($entity_detail->getSalesDetailsNo()) ?: ++$sales_detail_no)
                                                            ->setPayeeVoucherHeader($payee_voucher_header_entity)
                                                            ->setPayeeVoucherNo($entity_payee_voucher_detail['payee_voucher_no'])
                                                            ->setPayeeDetailsNo($entity_payee_voucher_detail['payee_detail_no'])
                                                            ->setProductCode($entity_detail->getProductCode())
                                                            ->setState($entity_detail->getState())
                                                            ->setPlace($entity_detail->getPlace())
                                                            ->setQuantity($sales_quantity_total)
                                                            ->setCreateUserName($member->getName())
                                                            ->setUpdateUserName($member->getName());
                                                        $sales_voucher->addSalesVoucherDetailLink($entity_detail_link);
                                                        break;
                                                    } else {
                                                        $entity_detail_link->setSalesVoucherHeader($sales_voucher)
                                                            ->setSalesVoucherNo($sales_voucher->getSalesVoucherNo())
                                                            ->setSalesDetailsNo(($entity_detail->getSalesDetailsNo()) ?: ++$sales_detail_no)
                                                            ->setPayeeVoucherHeader($payee_voucher_header_entity)
                                                            ->setPayeeVoucherNo($entity_payee_voucher_detail['payee_voucher_no'])
                                                            ->setPayeeDetailsNo($entity_payee_voucher_detail['payee_detail_no'])
                                                            ->setProductCode($entity_detail->getProductCode())
                                                            ->setState($entity_detail->getState())
                                                            ->setPlace($entity_detail->getPlace())
                                                            ->setQuantity($entity_payee_voucher_detail['quantity'])
                                                            ->setCreateUserName($member->getName())
                                                            ->setUpdateUserName($member->getName());
                                                        $sales_voucher->addSalesVoucherDetailLink($entity_detail_link);
                                                        $sales_quantity_total = $sales_quantity_total - $entity_payee_voucher_detail['quantity'];
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    $place_changed = 0;
                                    $state_changed = 0;
                                    if (isset($origin_entity_sales_detail_collection[$entity_detail->getSalesVoucherHeader()->getId().'_'.$entity_detail->getSalesDetailsNo()])) {
                                        /** @var SalesVoucherDetail $origin_entity_detail */
                                        $origin_entity_detail = $origin_entity_sales_detail_collection[$entity_detail->getSalesVoucherHeader()->getId().'_'.$entity_detail->getSalesDetailsNo()];
                                        // 置場変更の場合、置場元に対応する件数を除く（シリアル有商品、置場の変更が）
                                        // if ($entity_detail->getSerialNo() && $origin_entity_detail->getPlace() !== $entity_detail->getPlace()) {
                                        if ($origin_entity_detail->getPlace() && $origin_entity_detail->getPlace() !== $entity_detail->getPlace()) {
                                            $place_changed = 1;
                                        }
                                        // 状態変更の場合、置場元に対応する件数を除く
                                        // if ($entity_detail->getSerialNo() && $origin_entity_detail->getState() !== $entity_detail->getState()) {
                                        if ($origin_entity_detail->getState() && $origin_entity_detail->getState() !== $entity_detail->getState()) {
                                            $this->removeStockInfoWithDetailRemoved($origin_entity_detail, $member->getName());
                                            $state_changed = 1;
                                        }
                                        $origin_quantity = $origin_entity_detail->getQuantity();
                                    } else {
                                        $origin_quantity = 0;
                                    }
                                    // 在庫一覧（商品単位）
                                    $key_stock_by_product =
                                        $entity_detail->getProductId()
                                        .'_'.$entity_detail->getProductClass()->getId()
                                        .'_'.$entity_detail->getProductCode()
                                        .'_'.$entity_detail->getState()->getId()
                                    ;
                                    // 変更数量
                                    $quantity_stock_by_product = (
                                        isset($stock_by_product_conditions[$key_stock_by_product])
                                            ? $stock_by_product_conditions[$key_stock_by_product]['quantity']
                                            : 0
                                        ) + ($state_changed ? 0 : $origin_quantity) - $entity_detail->getQuantity();

                                    $stock_by_product_conditions[$key_stock_by_product] = [
                                        'productId' => $entity_detail->getProductId(),
                                        'ProductClass' => $entity_detail->getProductClass(),
                                        'productCode' => $entity_detail->getProductCode(),
                                        'State' => $entity_detail->getState(),
                                        'quantity' => $quantity_stock_by_product,
                                    ];
                                    // ヘッダー置場変更あり
                                    if ($place_changed == 1) {
                                        if ($state_changed == 0) {
                                            // 変更前置場データの削除
                                            // ※状態が変更されたら、変更前データはもう削除されたため
                                            $key_stock_by_place_old =
                                                $entity_detail->getProductId()
                                                .'_'.$entity_detail->getProductClass()->getId()
                                                .'_'.$entity_detail->getProductCode()
                                                .'_'.$entity_detail->getSerialNo()
                                                .'_'.$entity_detail->getState()->getId()
                                                .'_'.$origin_entity_detail->getPlace()->getId()
                                            ;
                                            $quantity_stock_by_place = (
                                                isset($stock_by_place_conditions[$key_stock_by_place_old])
                                                    ? $stock_by_place_conditions[$key_stock_by_place_old]['quantity']
                                                    : 0
                                                ) + $origin_quantity;

                                            $stock_by_place_conditions[$key_stock_by_place_old] = [
                                                'productId' => $entity_detail->getProductId(),
                                                'ProductClass' => $entity_detail->getProductClass(),
                                                'productCode' => $entity_detail->getProductCode(),
                                                'serialNo' => $entity_detail->getSerialNo(),
                                                'State' => $entity_detail->getState(),
                                                'Storehouse' => $origin_entity_detail->getPlace(),
                                                'quantity' => $quantity_stock_by_place,
                                            ];
                                        }

                                        // 変更後置場データの設定
                                        $key_stock_by_place_new =
                                            $entity_detail->getProductId()
                                            .'_'.$entity_detail->getProductClass()->getId()
                                            .'_'.$entity_detail->getProductCode()
                                            .'_'.$entity_detail->getSerialNo()
                                            .'_'.$entity_detail->getState()->getId()
                                            .'_'.$entity_detail->getPlace()->getId()
                                        ;
                                        $quantity_stock_by_place = (
                                            isset($stock_by_place_conditions[$key_stock_by_place_new])
                                                ? $stock_by_place_conditions[$key_stock_by_place_new]['quantity']
                                                : 0
                                            ) - $entity_detail->getQuantity();

                                        $stock_by_place_conditions[$key_stock_by_place_new] = [
                                            'productId' => $entity_detail->getProductId(),
                                            'ProductClass' => $entity_detail->getProductClass(),
                                            'productCode' => $entity_detail->getProductCode(),
                                            'serialNo' => $entity_detail->getSerialNo(),
                                            'State' => $entity_detail->getState(),
                                            'Storehouse' => $entity_detail->getPlace(),
                                            'quantity' => $quantity_stock_by_place,
                                        ];
                                    } else {
                                        // 在庫一覧（置場単位）
                                        $key_stock_by_place =
                                            $entity_detail->getProductId()
                                            .'_'.$entity_detail->getProductClass()->getId()
                                            .'_'.$entity_detail->getProductCode()
                                            .'_'.$entity_detail->getSerialNo()
                                            .'_'.$entity_detail->getState()->getId()
                                            .'_'.$entity_detail->getPlace()->getId()
                                        ;
                                        $quantity_stock_by_place = (
                                            isset($stock_by_place_conditions[$key_stock_by_place])
                                                ? $stock_by_place_conditions[$key_stock_by_place]['quantity']
                                                : 0
                                            ) - $entity_detail->getQuantity() + ($state_changed ? 0 : $origin_quantity);

                                        $stock_by_place_conditions[$key_stock_by_place] = [
                                            'productId' => $entity_detail->getProductId(),
                                            'ProductClass' => $entity_detail->getProductClass(),
                                            'productCode' => $entity_detail->getProductCode(),
                                            'serialNo' => $entity_detail->getSerialNo(),
                                            'State' => $entity_detail->getState(),
                                            'Storehouse' => $entity_detail->getPlace(),
                                            'quantity' => $quantity_stock_by_place,
                                        ];
                                    }
                                }
                            }
                            //   在庫一覧（商品単位）
                            foreach ($stock_by_product_conditions as $place_condition) {
                                $parameter_stock_by_product = [
                                    'productId' => $place_condition['productId'],
                                    'ProductClass' => $place_condition['ProductClass'],
                                    'productCode' => $place_condition['productCode'],
                                    'State' => $place_condition['State'],
                                ];
                                $collection_stock_list_product_unit = $this->stockListProductUnitRepository
                                    ->findBy($parameter_stock_by_product);

                                if (isset($collection_stock_list_product_unit[0])) {
                                    /** @var StockListProductUnit $entity_stock_list_product_unit */
                                    $entity_stock_list_product_unit = $collection_stock_list_product_unit[0];
                                } else {
                                    $entity_stock_list_product_unit = (new StockListProductUnit())
                                        ->setProductId($place_condition['productId'])
                                        ->setProductClass($place_condition['ProductClass'])
                                        ->setProductCode($place_condition['productCode'])
                                        ->setState($place_condition['State'])
                                        ->setStockQuantity(0)
                                        ->setOrderQuantity(0)
                                        ->setProvisionalShipmentQuantity(0)
                                        ->setRemainingStockQuantity(0)
                                        ->setAverageUnitPrice(0)
                                        ->setCreateUserName($member->getName())
                                    ;
                                }
                                $origin_entity_stock_list_product_unit = clone $entity_stock_list_product_unit;

                                if ($sales_voucher->getFrontUrl() == self::BACK_TO_LIST_URL_TEMP) {
                                    $stock_quantity_product_unit =
                                        $entity_stock_list_product_unit->getStockQuantity() + $place_condition['quantity'];
//                                    //仮出荷の場合、仮出荷数量変更
//                                    $provisionalShipmentQuantity =
//                                        $entity_stock_list_product_unit->getProvisionalShipmentQuantity() + $place_condition['quantity'];
                                    $entity_stock_list_product_unit->setStockQuantity(
                                        $stock_quantity_product_unit
                                    )->setRemainingStockQuantity(
                                        $stock_quantity_product_unit
                                        - $origin_entity_stock_list_product_unit->getOrderQuantity()
                                        - $origin_entity_stock_list_product_unit->getProvisionalShipmentQuantity()
                                    );

//                                    if ($provisionalShipmentQuantity >= 0) {
//                                        $entity_stock_list_product_unit->setProvisionalShipmentQuantity(
//                                            $provisionalShipmentQuantity
//                                        )->setRemainingStockQuantity(
//                                            $stock_quantity_product_unit
//                                            - $origin_entity_stock_list_product_unit->getOrderQuantity()
//                                            - $provisionalShipmentQuantity
//                                        );
//                                    } else {
//                                        $entity_stock_list_product_unit->setProvisionalShipmentQuantity(
//                                            0
//                                        )->setRemainingStockQuantity(
//                                            $stock_quantity_product_unit
//                                            - $origin_entity_stock_list_product_unit->getOrderQuantity()
//                                            - 0
//                                        );
//                                    }

                                } else {
                                    //仮出荷以外の場合、在庫数量変更
                                    $stock_quantity_product_unit =
                                        $entity_stock_list_product_unit->getStockQuantity() + $place_condition['quantity'];

                                    $entity_stock_list_product_unit->setStockQuantity(
                                        $stock_quantity_product_unit
                                    )->setRemainingStockQuantity(
                                        $stock_quantity_product_unit
                                        - $origin_entity_stock_list_product_unit->getOrderQuantity()
                                        - $origin_entity_stock_list_product_unit->getProvisionalShipmentQuantity()
                                    );
                                }
                                $entity_stock_list_product_unit->setUpdateUserName($member->getName());
                                $this->entityManager->persist($entity_stock_list_product_unit);
                                $this->entityManager->flush($entity_stock_list_product_unit);
                                LogControllable::print_log(__FILE__, '########## Insert/update: stock list by product', [$entity_stock_list_product_unit->toArray()]);
                                LogControllable::print_log(__FILE__, '########## Insert/update: stock list by product - quantity change: ', [$place_condition['quantity']]);
                            }
                            // 仮出荷伝票一覧の場合、仮出荷数量を変更
                            if ($sales_voucher->getFrontUrl() == self::BACK_TO_LIST_URL_TEMP) {
                                $temp_voucher_no = $request->get('sales_voucher')['temp_voucher_no'];
                                if (isset($temp_voucher_no) && $temp_voucher_no !== null) {
                                    $entity_provisional_shipment_voucher_header = $this->provisionalShipmentVoucherHeaderRepository->findBy(['provisional_shipment_voucher_no' => $temp_voucher_no ]);
                                    if (isset($entity_provisional_shipment_voucher_header) && (!empty($entity_provisional_shipment_voucher_header[0]))) {
                                        foreach ($entity_provisional_shipment_voucher_header[0]->getDetails() as $entity_provisional_shipment_voucher_detail) {
                                            $parameter_stock_by_product = [
                                                'productId' => $entity_provisional_shipment_voucher_detail->getProductId(),
                                                'ProductClass' => $entity_provisional_shipment_voucher_detail->getProductClass(),
                                                'productCode' => $entity_provisional_shipment_voucher_detail->getProductCode(),
                                                'State' => $entity_provisional_shipment_voucher_detail->getState(),
                                            ];
                                            $collection_stock_list_product_unit = $this->stockListProductUnitRepository
                                                ->findBy($parameter_stock_by_product);
                                            if (isset($collection_stock_list_product_unit[0])) {
                                                /** @var StockListProductUnit $entity_stock_list_product_unit */
                                                $entity_stock_list_product_unit_temp = $collection_stock_list_product_unit[0];
                                                $origin_entity_stock_list_product_unit = clone $entity_stock_list_product_unit_temp;
                                                $provisionalShipmentQuantity =
                                                    $origin_entity_stock_list_product_unit->getProvisionalShipmentQuantity() - $entity_provisional_shipment_voucher_detail->getQuantity();

                                                if ($provisionalShipmentQuantity >= 0) {
                                                    $entity_stock_list_product_unit_temp->setProvisionalShipmentQuantity(
                                                        $provisionalShipmentQuantity
                                                    )->setRemainingStockQuantity(
                                                        $origin_entity_stock_list_product_unit->getStockQuantity()
                                                        - $origin_entity_stock_list_product_unit->getOrderQuantity()
                                                        - $provisionalShipmentQuantity
                                                    );
                                                } else {
                                                    $entity_stock_list_product_unit_temp->setProvisionalShipmentQuantity(
                                                        0
                                                    )->setRemainingStockQuantity(
                                                        $origin_entity_stock_list_product_unit->getStockQuantity()
                                                        - $origin_entity_stock_list_product_unit->getOrderQuantity()
                                                        - 0
                                                    );
                                                }
                                                $entity_stock_list_product_unit_temp->setUpdateUserName($member->getName());
                                                $this->entityManager->persist($entity_stock_list_product_unit_temp);
                                                $this->entityManager->flush($entity_stock_list_product_unit_temp);
                                            }
                                        }
                                    }
                                }
                            }

                            //   在庫一覧（置場単位）
                            foreach ($stock_by_place_conditions as $place_condition) {
                                $parameter_stock_by_place = [
                                    'productId' => $place_condition['productId'],
                                    'ProductClass' => $place_condition['ProductClass'],
                                    'productCode' => $place_condition['productCode'],
                                    'serialNo' => $place_condition['serialNo'],
                                    'State' => $place_condition['State'],
                                    'Storehouse' => $place_condition['Storehouse'],
                                ];
                                $collection_stock_list_place_unit = $this->stockListStorehouseUnitRepository
                                    ->findBy(
                                        $parameter_stock_by_place,
                                        /* ['createDate' => 'DESC'] */
                                        ['stockQuantity' => 'DESC', 'updateDate' => 'DESC']
                                    );

                                if (isset($collection_stock_list_place_unit[0])) {
                                    $entity_stock_list_place_unit = $collection_stock_list_place_unit[0];
                                } else {
                                    $entity_stock_list_place_unit = (new StockListStorehouseUnit())
                                        ->setProductId($place_condition['productId'])
                                        ->setProductClass($place_condition['ProductClass'])
                                        ->setProductCode($place_condition['productCode'])
                                        ->setSerialNo($place_condition['serialNo'])
                                        ->setState($place_condition['State'])
                                        ->setStorehouse($place_condition['Storehouse'])
                                        ->setCreateUserName($member->getName())
                                    ;
                                }
                                $entity_stock_list_place_unit->setStockQuantity(
                                    $entity_stock_list_place_unit->getStockQuantity()
                                    + $place_condition['quantity']
                                )->setUpdateUserName($member->getName());
                                $this->entityManager->persist($entity_stock_list_place_unit);
                                $this->entityManager->flush($entity_stock_list_place_unit);
                                LogControllable::print_log(__FILE__, '########## Insert/update: stock list by storehouse', [$entity_stock_list_place_unit->toArray()]);
                                LogControllable::print_log(__FILE__, '########## Insert/update: stock list by storehouse - quantity change: ', [$place_condition['quantity']]);
                            }
                        }
                        // ヘッダー：合計
                        $sales_voucher->setSalesMoneyTotalAmount($money_total_amount);
                        // ADD-START CNC 2022/10/17 DBの「粗利益合計」 > 0の場合、伝票の「粗利益」を再計算しない、DBの「粗利益合計」を取得利用する。
                        $Details = $collection_sales_voucher_details;
                        if ($sales_voucher->getExportAddress()) {
                            $exportAddress = $sales_voucher->getExportAddress()->getId();
                        } else {
                            $exportAddress = null;
                        }
                        $taxRate = $sales_voucher->getTaxCode()->getTaxRate();
                        $benefit_total_amount = 0;

                        foreach ($Details as $salesVoucherDetail) {
                            if ($salesVoucherDetail['product_code'] == '111' || $salesVoucherDetail['product_code'] == '222' || $salesVoucherDetail['product_code'] == '333' || $salesVoucherDetail['product_code'] == '777') {
                                continue;
                            }
                            if ($exportAddress !== null) {
                                //税金区分
                                $crude = $salesVoucherDetail['sales_price'] - ($salesVoucherDetail['averagePrice'] / (1 + $taxRate / 100));
                                $benefit_total_amount = $benefit_total_amount + round($crude * $salesVoucherDetail['quantity']);
                            } else {
                                $crude = $salesVoucherDetail['sales_price'] - $salesVoucherDetail['averagePrice'];
                                $benefit_total_amount = $benefit_total_amount + round($crude * $salesVoucherDetail['quantity']);
                            }
                        }

//                        $benefit_total_amount = $form_sales_voucher_header['salesBenefitTotalAmount']->getData();
//                        $benefit_total_amount_str = str_replace(',', '', $benefit_total_amount);
                        $sales_voucher->setSalesBenefitTotalAmount($benefit_total_amount);
                        // ADD-END CNC 2022/10/17

                        // 売上出金残高
                        if ($id === null) {
                            $collection_sales_deposit_balance = $sales_voucher->getSalesDepositBalances();
                            if ($collection_sales_deposit_balance->count() > 0) {
                                $entity_sales_deposit_balance = $collection_sales_deposit_balance[0]
                                    ->setUpdateUserName($member->getName());
                            } else {
                                $entity_sales_deposit_balance = (new SalesDepositBalance())->setSalesVoucherHeader()
                                    ->setSalesVoucherNo(self::TEMPORARY_VOUCHER_NO)
                                    ->setCreateUserName($member->getName())
                                    ->setUpdateUserName($member->getName());
                                $sales_voucher->addSalesDepositBalances($entity_sales_deposit_balance);
                            }
                            $entity_sales_deposit_balance->setSalesVoucherHeader($sales_voucher)
                                ->setDepositedAmount(0);
                        }

                        foreach ($sales_voucher->getSalesVoucherDetails() as $key=>$detail) {

                            if ($sales_voucher->getSalesVoucherDetails()[$key]->getAveragePrice() != 0) {
                                continue;
                            }

                            $parameter_stock_by_product = [
                                'productId' => $detail->getProductId(),
                                'ProductClass' => $detail->getProductClass(),
                                'productCode' => $detail->getProductCode(),
                                'State' => $detail->getState(),
                            ];
                            $productInfo = $this->stockListProductUnitRepository
                                ->findBy($parameter_stock_by_product);

                            if (isset($productInfo[0])) {
                                // 平均単価
                                $sales_voucher->getSalesVoucherDetails()[$key]->setAveragePrice($productInfo[0]->getAverageUnitPrice());
                            } else {
                                //平均単価
                                $sales_voucher->getSalesVoucherDetails()[$key]->setAveragePrice(0);
                            }
                        }

                        // ADD-START CNC 2022/10/29 sort
                        $arraySalesVoucherDetails = $sales_voucher['SalesVoucherDetails']->toArray();

                        $arraySalesVoucherDetails = array_reverse($arraySalesVoucherDetails);

                        $sales_voucher['SalesVoucherDetails']->clear();

                        foreach ($arraySalesVoucherDetails as $arraySalesVoucherDetail) {
                            $sales_voucher['SalesVoucherDetails']->add($arraySalesVoucherDetail);
                        }
                        // ADD-END CNC 2022/10/29 sort

                        $this->entityManager->persist($sales_voucher);
                        $this->entityManager->flush();
                        if ($sales_voucher->getFrontUrl() !== self::BACK_TO_LIST_URL_TEMP) {
                            // 新規登録時はMySQL対応のためflushしてから採番
                            $this->voucherNoProcessor->process($sales_voucher);
                        } else {
                            $sales_voucher->setSalesVoucherNo($sales_voucher->getTempVoucherNo());
                            if (method_exists($sales_voucher, 'getDetails')) {
                                $details = $sales_voucher->getDetails();
                                if ($details && is_array($details->getValues())) {
                                    foreach ($details as $entity_detail) {
                                        /** @var SalesVoucherDetail $entity_detail */
                                        if ($entity_detail->getVoucherNo()) {
                                            continue;
                                        }
                                        $entity_detail->setVoucherNo($sales_voucher->getVoucherNo());
                                    }
                                }
                            }
                        }
                        $updated_entity_sales_paid_balance = $sales_voucher->getSalesDepositBalances()[0];
                        if (!$updated_entity_sales_paid_balance->getSalesVoucherNo()) {
                            $updated_entity_sales_paid_balance
                                ->setSalesVoucherNo($sales_voucher->getSalesVoucherNo());
                        }
                        $updated_entity_sales_voucher_detail_links = $sales_voucher->getSalesVoucherDetailLink();
                        foreach ($updated_entity_sales_voucher_detail_links as $updated_entity_sales_voucher_detail_link) {
                            if (!$updated_entity_sales_voucher_detail_link->getSalesVoucherNo()) {
                                $updated_entity_sales_voucher_detail_link
                                    ->setSalesVoucherNo($sales_voucher->getSalesVoucherNo());
                            }
                        }

                        $this->entityManager->flush();
                        // 履歴（ヘッダ―）
                        $sales_voucher_history = $this->salesVoucherHeaderHistoryRepository
                            ->createSalesVoucherHeaderHistoryByHeader($sales_voucher, $behavior);
                        $this->entityManager->persist($sales_voucher_history);
                        $this->entityManager->flush();

                        log_info('売上伝票登録完了', [$sales_voucher->getId()]);
                        $this->addSuccess('admin.common.save_complete', 'admin');

                        return $this->redirectToRoute('admin_sales_voucher_edit', ['id' => $sales_voucher->getId()]);
                    } catch (\Exception $e) {
                        $this->entityManager->rollback();
                        log_error('売上伝票登録エラー', [$id, $e]);
                        $this->addError($e->getMessage(), 'admin');
                    }
                } elseif ($request->get('mode') == 'register' && $form_sales_voucher_header) {
                    $this->entityManager->rollback();
                    $this->addError('admin.common.save_error', 'admin');
                }
            }
        } else {
            $total_quantity = 0;
            $total_benefit = 0;
            $taxCode = $this->taxCodeRepository->find($form_sales_voucher_header['TaxCode']->getViewData());

            // 表示時明細の商品名称設定
            foreach ($form_sales_voucher_header['SalesVoucherDetails'] as $form_detail) {
                /** @var FormInterface $form_detail */
                /** @var Product $product */
                // 在庫一覧（商品単位）
                $parameter_stock_by_product = [
                    'productId' => $form_detail['product_id']->getViewData(),
                    'ProductClass' => $form_detail['ProductClass']->getViewData(),
                    'productCode' => $form_detail['product_code']->getViewData(),
                    'State' => $form_detail['State']->getViewData(),
                ];
                $collection_stock_list_product_unit = $this->stockListProductUnitRepository
                    ->findBy($parameter_stock_by_product);

                if (isset($collection_stock_list_product_unit[0])) {

                    // 2022/02/14 CNC UPDATE START
                    if ((!isset($form_detail['averagePrice'])) || $form_detail['averagePrice'] == '' || $form_detail['averagePrice'] == null) {
                        // 平均単価
                        $form_detail['averagePrice']->setData($collection_stock_list_product_unit[0]->getAverageUnitPrice());
                    }
                    // 2022/02/14 CNC UPDATE END

                    //仮出荷数
                    $form_detail['provisionalCount']->setData($collection_stock_list_product_unit[0]->getProvisionalShipmentQuantity());
                } else {
                    // 2022/01/14 CNC DEL START
//                    //平均単価
//                    $form_detail['averagePrice']->setData(0);
                    // 2022/01/14 CNC DEL END
                    //仮出荷数
                    $form_detail['provisionalCount']->setData(0);
                }

                $product = $this->productRepository->find($form_detail['product_id']
                    ->getData());
                $form_detail['product_name']->setData($product->getName());
                $form_detail['product_serial_flg']->setData($product->getSerialFlg());
                if ($form_sales_voucher_header['ExportAddress']->getViewData() !== '') {
                    //粗利益
                    $form_detail['benefit']->setData($form_detail['sales_price']->getData() - $form_detail['averagePrice']->getData() / (1 + $taxCode['taxRate'] / 100));
                } else {
                    //粗利益
                    $form_detail['benefit']->setData($form_detail['sales_price']->getData() - $form_detail['averagePrice']->getData());
                }
                if (!empty($form_detail['sales_price']->getData())) {
                    //利益率
                    $form_detail['benefitRate']->setData(round($form_detail['benefit']->getData() / $form_detail['sales_price']->getData() * 100, 1).'%');
                } else {
                    //利益率
                    $form_detail['benefitRate']->setData('0.0%');
                }
                $form_detail['benefit']->setData($form_detail['benefit']->getData() * $form_detail['quantity']->getData());
                //商品税区分
                $array_product_tax_code = $this->productClassRepository->findProductsTaxCodeWithProductCode($form_detail['product_code']->getViewData());
                if (!empty($array_product_tax_code) && !empty($array_product_tax_code[1])) {
                    $form_detail['tax_code']->setData($array_product_tax_code[1]->getId());
                } else {
                    $form_detail['tax_code']->setData(null);
                }
                //税込
                if ($taxCode->getCalculateTax()->getId() === 2) {
                    $form_detail['tax_flg']->setData('1');
                } else {
                    //税抜
                    $form_detail['tax_flg']->setData('0');
                }

                if (!isset($array_special_cost[$form_detail['product_code']->getData()])) {
                    $total_quantity += $form_detail['quantity']->getData();
                    $total_benefit += $form_detail['benefit']->getData();
                }
            }

            if (!empty($taxCode)) {
                $form_sales_voucher_header['taxRate']->setData($taxCode['taxRate']);
            } else {
                $form_sales_voucher_header['taxRate']->setData(null);
            }

            // 数量,粗利益合計
            $form_sales_voucher_header['total_quantity']->setData($total_quantity);
            $form_sales_voucher_header['salesBenefitTotalAmount']->setData($total_benefit);
        }

        // 明細行数
        if ($form_sales_voucher_header['SalesVoucherDetails'] && $form_sales_voucher_header['SalesVoucherDetails']->count() > 0) {
            $now_row_no = max(
                    array_keys($form_sales_voucher_header['SalesVoucherDetails']->getData()->toArray())
                ) + 1;
        } else {
            $now_row_no = 0;
        }

        // 伝票明細登録用コントロール
        $builder_sales_voucher_detail = $this->formFactory->createBuilder(SalesVoucherDetailType::class);
        $form_sales_voucher_detail = $builder_sales_voucher_detail->getForm();

        // マスタデータチェック
        if ($this->paymentRepository->count([]) <= 0) {
            $this->addError(trans('admin.common.master_table_no_data_message', ['%table%' => 'dtb_payment']), 'admin');
        }
        if ($this->customerMstRepository->count([]) <= 0) {
            $this->addError(trans('admin.common.master_table_no_data_message', ['%table%' => 'mtb_customer_mst']), 'admin');
        }
        if ($this->productRepository->count([]) <= 0) {
            $this->addError(trans('admin.common.master_table_no_data_message', ['%table%' => 'dtb_product']), 'admin');
        }
        if ($this->taxExporterRepository->count([]) <= 0) {
            $this->addError(trans('admin.common.master_table_no_data_message', ['%table%' => 'mtb_tax_exporter']), 'admin');
        }
        if ($this->taxCodeRepository->count([]) <= 0) {
            $this->addError(trans('admin.common.master_table_no_data_message', ['%table%' => 'mtb_tax_code']), 'admin');
        }

        // 商品検索フォーム
        $builder_search_customer = $this->formFactory->createBuilder(SalesVoucherSearchCustomerType::class);

        $event = new EventArgs(
            [
                'builder' => $builder_search_customer,
                'SalesVoucherHeader' => $entity_sales_voucher_header,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_VOUCHER_INDEX_SEARCH_CUSTOMER_INITIALIZE, $event);

        $search_sales_modal_form = $builder_search_customer->getForm();

        // 複数シリアル番号入力フォーム
        $builder_input_multiple_serial = $this->formFactory->createBuilder(InputMultipleSerialType::class);

        $event = new EventArgs(
            [
                'builder' => $builder_input_multiple_serial,
                'SalesVoucherHeader' => $entity_sales_voucher_header,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_VOUCHER_INDEX_INPUT_MULTIPLE_SERIAL_INITIALIZE, $event);

        $input_multiple_serial_form = $builder_input_multiple_serial->getForm();

        // 商品検索フォーム
        $builder_search_product_modal = $this->formFactory
            ->createBuilder(SearchProductType::class);

        $event = new EventArgs(
            [
                'builder' => $builder_search_product_modal,
                'SalesVoucherHeader' => $entity_sales_voucher_header,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_VOUCHER_INDEX_SEARCH_PRODUCT_SUB_INITIALIZE, $event);

        $searchProductModalForm = $builder_search_product_modal->getForm();

        $builder_csv_import = $this->formFactory
            ->createBuilder(CsvImportType::class);

        $event = new EventArgs(
            [
                'builder' => $builder_csv_import,
                'SalesVoucherHeader' => $entity_sales_voucher_header,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_VOUCHER_INDEX_CSV_IMPORT_INITIALIZE, $event);

        $csv_import_form = $builder_csv_import->getForm();

        // 数量合計表示
        $total['total_quantity'] = trans('admin.sales.voucher.total_quantity')
            .number_format((float) str_replace(',', '', $form_sales_voucher_header['total_quantity']->getData()));
        $total['sales_money_total_amount'] = trans('admin.sales.voucher.sales_money_total_amount')
            .number_format((float) str_replace(',', '', $form_sales_voucher_header['sales_money_total_amount']->getData())).trans('admin.sales.voucher.sales_money_yen');
        $total['salesBenefitTotalAmount'] = trans('admin.sales.voucher.sales_benefit_total_amount')
            .number_format((float) str_replace(',', '', $form_sales_voucher_header['salesBenefitTotalAmount']->getData())).trans('admin.sales.voucher.sales_money_yen');

        $orderUpdateTime = null;
        if ($id != null and strpos($back_url, self::PREVIOUS_PAGE_URL_TEMP) == false and strpos($back_url, self::PREVIOUS_PAGE_URL_PAYEE) == false) {
            $orderUpdateTime = $entity_sales_voucher_header->getUpdateDate()->format('Y-m-d H:i:s');
        }

        // ADD-START CNC 2022/10/29 sort
        $firstDetailsNo = 0;
        $secondDetailsNo = 0;

        if (count($form_sales_voucher_header->getData()->getSalesVoucherDetails()) > 1) {
            $i = 0;
            foreach ($form_sales_voucher_header->getData()->getSalesVoucherDetails() as $formDetails) {
                if ($i == 0) {
                    $firstDetailsNo = $formDetails['sales_details_no'];
                } elseif ($i == 1) {
                    $secondDetailsNo = $formDetails['sales_details_no'];
                } else {
                    break;
                }

                $i++;
            }
        }

        $key_list = [];
        foreach ($form_sales_voucher_header->getData()->getSalesVoucherDetails() as $key => $formDetails) {
            array_push($key_list, $key);
        }

        $key_list = array_reverse($key_list);
        // ADD-END CNC 2022/10/29 sort

        return [
            'form' => $form_sales_voucher_header->createView(),
            'searchSalesModalForm' => $search_sales_modal_form->createView(),
            'inputMultipleSerialForm' => $input_multiple_serial_form->createView(),
            'SalesVoucherHeader' => $entity_sales_voucher_header,
            'salesVoucherRegisterForm' => $form_sales_voucher_detail->createView(),
            'searchProductModalForm' => $searchProductModalForm->createView(),
            'csvImportForm' => $csv_import_form->createView(),
            'ControlsEnable' => $controls_enable,
            'totalAmountInfo' => $total,
            'detailDatumLength' => $now_row_no,
            'SpecialCost' => $array_special_cost,
            'customercode' => $customercode,
            // INS-START CNC 2022/05/09
            'fromListQuantityDisable' => $from_list_quantity_disable,
            // INS-END CNC 2022/05/09
            'orderUpdateTime' => $orderUpdateTime,
            // ADD-START CNC 2022/10/29 sort
            'firstDetailsNo' => $firstDetailsNo,
            'secondDetailsNo' => $secondDetailsNo,
            'keyList' => $key_list,
            // ADD-END CNC 2022/10/29 sort
        ];
    }

    /**
     *  伝票更新時間取得
     *
     * @Route("/%eccube_admin_route%/sales_voucher/search/date", name="admin_sales_voucher_search_date")
     * @param Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchOrderUpdateDate(Request $request, Paginator $paginator)
    {
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
        }

        $result = [];
        $id = $request->get('headerId');

        if (!is_null($id)) {
            $entity_sales_voucher_header = $this->salesVoucherHeaderRepository->find($id);
            if ($entity_sales_voucher_header) {
                $orderUpdateTimeNew = $entity_sales_voucher_header->getUpdateDate()->format('Y-m-d H:i:s');
                $result['orderUpdateTimeNew'] = $orderUpdateTimeNew;
            } else {
                $result['orderUpdateTimeNew'] = "";
            }
        }

        return $this->json(array_merge(['status' => 'OK'], $result));
    }

    /**
     * ヘッダー削除
     * @Route("/%eccube_admin_route%/sales_voucher/{id}/delete", requirements={"id" = "\d+"}, name="admin_sales_voucher_delete", methods={"DELETE"})
     * @param Request $request Request
     * @param int|null $id ID
     * @param CacheUtil|null $cacheUtil CacheUtil
     * @return \Symfony\Component\HttpFoundation\JsonResponse|RedirectResponse
     * @throws \Exception
     */
    public function delete(Request $request, int $id = null, CacheUtil $cacheUtil = null)
    {
        $this->isTokenValid();
        $session = $request->getSession();
        $page_no = intval($session->get('eccube.admin.sales_management.search.page_count'));
        $page_no = $page_no ? $page_no : Constant::ENABLED;
        $message = null;
        $success = false;
        $member = $this->getUser();

        if (!is_null($id)) {
            /** @var SalesVoucherHeader $entity_sales_voucher_header */
            $entity_sales_voucher_header = $this->salesVoucherHeaderRepository->find($id);
            if (!$entity_sales_voucher_header) {
                if ($request->isXmlHttpRequest()) {
                    $message = trans('admin.common.delete_error_already_deleted');

                    return $this->json(['success' => $success, 'message' => $message]);
                } else {
                    $this->deleteMessage();
                    $rUrl = $this->generateUrl('admin_sales_voucher_list', ['page_no' => $page_no]).'?resume='.Constant::ENABLED;

                    return $this->redirect($rUrl);
                }
            }

            // INS-START CNC 2022/05/09
            $voucher_no = $entity_sales_voucher_header->getSalesVoucherNo();
            $entity_temp_ex_stock_edit_header = $this->provisionalShipmentVoucherHeaderRepository->findoneBy(['provisional_shipment_voucher_no' => $voucher_no ]);
            if($entity_temp_ex_stock_edit_header){
                $collection_temp_ex_stock_edit_detail = $entity_temp_ex_stock_edit_header->getProvisionalShipmentVoucher();
            }
            // INS-END CNC 2022/05/09

            if ($entity_sales_voucher_header instanceof SalesVoucherHeader) {
                log_info('売上伝票ヘッダー削除開始', [$id]);

                $collection_sales_paid_balance = $entity_sales_voucher_header->getSalesDepositBalances();
                $collection_sales_voucher_detail = $entity_sales_voucher_header->getSalesVoucherDetails();
                $collection_sales_voucher_detail_link = $entity_sales_voucher_header->getSalesVoucherDetailLink();

                try {
                    // 関連売上残高削除
                    if (isset($collection_payee_paid_balance[0])) {
                        $this->salesDepositBalanceRepository->delete($collection_sales_paid_balance[0]);
                    }
                    // 関連売上伝票明細削除
                    if ($collection_sales_voucher_detail_link->count() > 0) {
                        foreach ($collection_sales_voucher_detail_link as $detail_link) {
                            $this->salesVoucherDetailLinkRepository->delete($detail_link);
                        }
                    }
                    if ($collection_sales_voucher_detail->count() > 0) {
                        foreach ($collection_sales_voucher_detail as $detail) {
                            $this->removeStockInfoWithDetailRemoved($detail, $member->getName());
                            $parameter_detail_history = [
                                'salesVoucherNo' => $detail->getSalesVoucherNo(),
                                'salesDetailsNo' => $detail->getSalesDetailsNo(),
                            ];
                            $collection_detail_history = $this->salesVoucherDetailHistoryRepository
                                ->findBy($parameter_detail_history, ['revisionNo' => 'DESC']);
                            if (isset($collection_detail_history[0])) {
                                $detail->setAveragePrice($collection_detail_history[0]->getAveragePrice());
                            }
                            $this->salesVoucherDetailRepository->delete($detail);
                        }
                    }

                    // INS-START CNC 2022/05/09
                    if($entity_temp_ex_stock_edit_header){
                        if ($collection_temp_ex_stock_edit_detail->count() > 0) {
                            foreach ($collection_temp_ex_stock_edit_detail as $detail) {
                                $this->provisionalShipmentVoucherRepository->delete($detail);
                            }
                        }
                        $this->provisionalShipmentVoucherHeaderRepository->delete($entity_temp_ex_stock_edit_header);
                    }
                    // INS-END CNC 2022/05/09

                    // 履歴（ヘッダ―）
                    $sales_voucher_history = $this->salesVoucherHeaderHistoryRepository
                        ->createSalesVoucherHeaderHistoryByHeader($entity_sales_voucher_header, SalesVoucherHeaderHistory::BEHAVIOR_DELETE);
                    $this->entityManager->persist($sales_voucher_history);

                    $this->salesVoucherHeaderRepository->delete($entity_sales_voucher_header);
                    $this->entityManager->flush();

                    $event = new EventArgs(
                        [
                            'SalesVoucherHeader' => $entity_sales_voucher_header,
                            'SalesVoucherDetail' => $collection_sales_voucher_detail,
                            'SalesPaidBalance' => $collection_sales_paid_balance,
                        ],
                        $request
                    );
                    $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_VOUCHER_DELETE_COMPLETE, $event);

                    log_info('売上伝票ヘッダー削除完了', [$id]);

                    $success = true;
                    $message = trans('admin.common.delete_complete');

                    $cacheUtil->clearDoctrineCache();
                } catch (ForeignKeyConstraintViolationException $e) {
                    log_info('売上伝票ヘッダー削除エラー', [$id]);
                    $message = trans('admin.common.delete_error_foreign_key', ['%name%' => $entity_sales_voucher_header->getSalesVoucherNo()]);
                } catch (\Exception $e) {
                    log_info('売上伝票ヘッダー削除エラー', [$id]);
                    $message = trans('admin.common.delete_error');
                }
            } else {
                log_info('売上伝票ヘッダー削除エラー', [$id]);
                $message = trans('admin.common.delete_error');
            }
        } else {
            log_info('売上伝票ヘッダー削除エラー', [$id]);
            $message = trans('admin.common.delete_error');
        }

        if ($request->isXmlHttpRequest()) {
            return $this->json(['success' => $success, 'message' => $message]);
        } else {
            if ($success) {
                $this->addSuccess($message, 'admin');
                $rUrl = $this->generateUrl('admin_sales_voucher_list', ['page_no' => $page_no]).'?resume='.Constant::ENABLED;
            } else {
                $this->addError($message, 'admin');
                $rUrl = $this->generateUrl('admin_sales_voucher_edit', ['id' => $id]);
            }

            return $this->redirect($rUrl);
        }
    }
    /**
     * @param SalesVoucherDetail $sales_voucher_detail 明細
     * @param SalesVoucherHeader $sales_voucher_header 明細対応するヘッダー
     */
    public function removeSalesVoucherDetailLinkWithDetail(SalesVoucherDetail $sales_voucher_detail, SalesVoucherHeader $sales_voucher_header)
    {
        // 明細紐付
        $parameter_detail_link_by_sales = [
            'SalesVoucherHeader' => $sales_voucher_header->getId(),
            'salesVoucherNo' => $sales_voucher_detail->getSalesVoucherNo(),
            'salesDetailsNo' => $sales_voucher_detail->getSalesDetailsNo(),
        ];
        $collection_sales_detail_link = $this->salesVoucherDetailLinkRepository
            ->findBy($parameter_detail_link_by_sales);

        // 関連売上伝票明細紐付削除
        foreach ($collection_sales_detail_link as $detail_link) {
            $this->entityManager->remove($detail_link);
        }
    }

    /**
     * @param SalesVoucherDetail $sales_voucher_detail 明細
     * @param string $user_name ユーザ名
     */
    public function removeStockInfoWithDetailRemoved(SalesVoucherDetail $sales_voucher_detail, string $user_name)
    {
        // 在庫一覧（商品単位）
        $parameter_stock_by_product = [
            'productId' => $sales_voucher_detail->getProductId(),
            'ProductClass' => $sales_voucher_detail->getProductClass(),
            'productCode' => $sales_voucher_detail->getProductCode(),
            'State' => $sales_voucher_detail->getState(),
        ];

        $collection_stock_list_product_unit = $this->stockListProductUnitRepository
            ->findBy($parameter_stock_by_product);

        if (isset($collection_stock_list_product_unit[0])) {
            /** @var StockListProductUnit $entity_stock_list_product_unit */
            $entity_stock_list_product_unit = $collection_stock_list_product_unit[0];
        } else {
            $entity_stock_list_product_unit = (new StockListProductUnit())
                ->setProductId($sales_voucher_detail->getProductId())
                ->setProductClass($sales_voucher_detail->getProductClass())
                ->setProductCode($sales_voucher_detail->getProductCode())
                ->setState($sales_voucher_detail->getState())
                ->setCreateUserName($user_name)
                ->setUpdateUserName($user_name)
            ;
        }
        $origin_entity_stock_list_product_unit = clone $entity_stock_list_product_unit;
        $stock_quantity_product_unit =
            $origin_entity_stock_list_product_unit->getStockQuantity() + $sales_voucher_detail->getQuantity();
        $entity_stock_list_product_unit->setStockQuantity(
            $stock_quantity_product_unit
        )->setRemainingStockQuantity(
            $origin_entity_stock_list_product_unit->getRemainingStockQuantity() + $sales_voucher_detail->getQuantity()
        )->setUpdateUserName($user_name);
        $this->entityManager->persist($entity_stock_list_product_unit);
        $this->entityManager->flush($entity_stock_list_product_unit);
        LogControllable::print_log(__FILE__, '########## Insert/update: stock list by product', [$entity_stock_list_product_unit->toArray()]);
        LogControllable::print_log(__FILE__, '########## Insert/update: stock list by product - quantity change: ', [$sales_voucher_detail->getQuantity()]);

        // 在庫一覧（置場単位）
        $parameter_stock_by_place = [
            'productId' => $sales_voucher_detail->getProductId(),
            'ProductClass' => $sales_voucher_detail->getProductClass(),
            'productCode' => $sales_voucher_detail->getProductCode(),
            'State' => $sales_voucher_detail->getState(),
            'Storehouse' => $sales_voucher_detail->getPlace(),
        ];
        if ($sales_voucher_detail->getSerialNo() !== null && $sales_voucher_detail->getSerialNo() !== '') {
            $parameter_stock_by_place = [
                'serialNo' => $sales_voucher_detail->getSerialNo(),
            ];
        }
        $collection_stock_list_place_unit = $this->stockListStorehouseUnitRepository
            ->findBy(
                $parameter_stock_by_place,
                /* ['createDate' => 'DESC'] */
                ['stockQuantity' => 'DESC', 'updateDate' => 'DESC']
            );

        if (isset($collection_stock_list_place_unit[0])) {
            /** @var StockListStorehouseUnit $entity_stock_list_place_unit */
            $entity_stock_list_place_unit = $collection_stock_list_place_unit[0];
        } else {
            $entity_stock_list_place_unit = (new StockListStorehouseUnit())
                ->setProductId($sales_voucher_detail->getProductId())
                ->setProductClass($sales_voucher_detail->getProductClass())
                ->setProductCode($sales_voucher_detail->getProductCode())
                ->setState($sales_voucher_detail->getState())
                ->setStorehouse($sales_voucher_detail->getPlace())
                ->setSerialNo($sales_voucher_detail->getSerialNo())
                ->setCreateUserName($user_name)
                ->setUpdateUserName($user_name)
            ;
        }

        $entity_stock_list_place_unit->setStockQuantity(
            $entity_stock_list_place_unit->getStockQuantity()
            + $sales_voucher_detail->getQuantity()
        )->setUpdateUserName($user_name);
        $this->entityManager->persist($entity_stock_list_place_unit);
        $this->entityManager->flush($entity_stock_list_place_unit);
        LogControllable::print_log(__FILE__, '########## Insert/update: stock list by storehouse', [$entity_stock_list_place_unit->toArray()]);
        LogControllable::print_log(__FILE__, '########## Insert/update: stock list by storehouse - quantity change: ', [$sales_voucher_detail->getQuantity()]);
    }

    /**
     * @Route("/%eccube_admin_route%/sales_voucher/search/product", name="admin_sales_voucher_search_product")
     * @param Request $request リクエスト
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchProduct(Request $request)
    {
        $product_code = $request->get('code');

        log_info('Admin SalesVoucher searchProduct', [$product_code]);

        // 商品取得
        $array_entity_product = $product_code
            ? $this->productRepository->findProductsWithProductCode($product_code)
            : [];

        $event = new EventArgs(
            [
                'ProductCode' => $product_code,
                'Product' => $array_entity_product,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_VOUCHER_INDEX_SEARCH_PRODUCT_INITIALIZE, $event);

        if (!empty($array_entity_product) && !empty($array_entity_product[0])) {
            /** @var Product $entity_product */
            $entity_product = $array_entity_product[0][0];
            $data = [
                'target_product_id' => $entity_product->getId(),
                'target_product_name' => $entity_product->getName(),
                'target_product_serial_flg' => ($entity_product->getSerialFlg() ? '1' : '0'),
                'target_product_category_id' => $array_entity_product[0]['category_id'],
                'target_product_class_id' => $entity_product->getProductClasses()[0]->getId(),
            ];
        } else {
            log_debug('search product by code not found.');
            return $this->json([], 404);
        }

        $event = new EventArgs(
            [
                'ProductCode' => $product_code,
                'Product' => $entity_product,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_VOUCHER_INDEX_SEARCH_PRODUCT_COMPLETE, $event);

        return $this->json($data);
    }

    /**
     * @Route("/%eccube_admin_route%/sales_voucher/commit/product", name="admin_sales_voucher_commit_product")
     * @param Request $request リクエスト
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function commitProduct(Request $request)
    {
        $product_code = $request->get('code');
        $serial_flag = $request->get('serialFlag');
        $tax_code = $request->get('taxCode');
        $serialNo = $request->get('serialNo');

        log_info('Admin SalesVoucher searchProduct', [$product_code]);

        $entity_taxCode = $this->taxCodeRepository->getTaxCodeById($tax_code);
        $tax_flg = '';
        $tax_rate = '';
        $product_stateId = '';
        $quantity = 0;
        $product_tax_code = null;
        if (!empty($entity_taxCode) && !empty($entity_taxCode[0])) {
            if ($entity_taxCode[0]->getCalculateTax()->getId() === 2) {
                // 税込
                $tax_flg = '1';
            } else {
                // 税抜
                $tax_flg = '0';
            }
            $tax_rate = $entity_taxCode[0]->getTaxRate();
        }
        //商品税区分
        $array_product_tax_code = $this->productClassRepository->findProductsTaxCodeWithProductCode($product_code);
        if (!empty($array_product_tax_code) && !empty($array_product_tax_code[1])) {
            $product_tax_code = $array_product_tax_code[1]->getId();
        }
        $member_place = null;
        /** @var Member $member */
        $member = $this->getUser();
        if ($member->isSalesVisableFlg() && !empty($member->getSalesPlace())) {
            $member_place = $member->getSalesPlace()->getId();
        }

        // 商品情報取得
        if ($serial_flag === '1') {
            // シリアル番号ありの場合、商品取得
            // 2021/11/02 CNC UPDATE START
            // $array_entity_product = $this->productClassRepository->findProductsSerialWithProductCode($product_code, $serialNo);
            $array_entity_product = $this->stockListStorehouseUnitRepository->findProductsSerialInStock($serialNo);
            // 2021/11/02 CNC UPDATE END

            if (!empty($array_entity_product) && !empty($array_entity_product[0]) && $array_entity_product[0]['stockQuantity'] > 0) {
                /** @var Product $entity_product */
                $entity_product = $array_entity_product[0][0];
                $data = [
                    'target_product_stateId' => $array_entity_product[0]['stateId'],
                    'target_product_state' => $array_entity_product[0]['state'],
                    'target_product_place' => $array_entity_product[0]['place'],
                    'target_product_quantity' => $array_entity_product[0]['quantity'],
                    'target_product_average_unit_price' => $array_entity_product[0]['averageUnitPrice'],
                    'tax_flg' => $tax_flg,
                    'tax_rate' => $tax_rate,
                    'tax_code' => $product_tax_code,
                    'duplicate_serial_no' => '1',
                    'member_place' => $member_place,
                ];
            } else {
                $entity_product = null;
                $data = [
                    'duplicate_serial_no' => '0',
                ];
            }
        } else {
            // シリアル番号なしの場合、商品取得
            $array_entity_product = $this->productCategoryRepository->findProductsDetailsWithProductCode($product_code);

            if (!empty($array_entity_product) && !empty($array_entity_product[0])) {
                /** @var Product $entity_product */
                $entity_product = $array_entity_product[0][0];
                $data = [
                    'target_product_place' => '',
                    'target_product_stateId' => $array_entity_product[0]['stateId'],
                    'target_product_state' => $array_entity_product[0]['state'],
                    'target_product_quantity' => $array_entity_product[0]['quantity'],
                    'target_product_average_unit_price' => $array_entity_product[0]['averageUnitPrice'],
                    'tax_flg' => $tax_flg,
                    'tax_rate' => $tax_rate,
                    'tax_code' => $product_tax_code,
                    'duplicate_serial_no' => '1',
                    'member_place' => $member_place,
                ];
            } else {
                $entity_product = null;
                $data = [
                    'target_product_stateId' => $product_stateId,
                    'target_product_quantity' => $quantity,
                    'target_product_average_unit_price' => $quantity,
                    'tax_flg' => $tax_flg,
                    'tax_rate' => $tax_rate,
                    'tax_code' => $product_tax_code,
                    'duplicate_serial_no' => '1',
                    'member_place' => $member_place,
                ];
            }
        }
        $event = new EventArgs(
            [
                'ProductCode' => $product_code,
                'Product' => $array_entity_product,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_VOUCHER_INDEX_SEARCH_PRODUCT_INITIALIZE, $event);
        $event = new EventArgs(
            [
                'ProductCode' => $product_code,
                'Product' => $entity_product,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_VOUCHER_INDEX_SEARCH_PRODUCT_COMPLETE, $event);

        return $this->json($data);
    }
    /**
     * @Route("/%eccube_admin_route%/sales_voucher/commit/product/serial", name="admin_sales_voucher_commit_product_by_serial")
     * @param Request $request リクエスト
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function commitProductBySerial(Request $request)
    {
        $tax_code = $request->get('taxCode');
        $serialNo = $request->get('serialNo');

        log_info('Admin SalesVoucher searchProductBySerial', [$serialNo]);

        $entity_taxCode = $this->taxCodeRepository->getTaxCodeById($tax_code);
        $tax_flg = '';
        $tax_rate = '';
        $product_tax_code = null;
        if (!empty($entity_taxCode) && !empty($entity_taxCode[0])) {
            if ($entity_taxCode[0]->getCalculateTax()->getId() === 2) {
                // 税込
                $tax_flg = '1';
            } else {
                // 税抜
                $tax_flg = '0';
            }
            $tax_rate = $entity_taxCode[0]->getTaxRate();
        }

        $member_place = null;
        /** @var Member $member */
        $member = $this->getUser();
        if ($member->isSalesVisableFlg() && !empty($member->getSalesPlace())) {
            $member_place = $member->getSalesPlace()->getId();
        }
        // シリアル番号ありの場合、商品取得
        $array_entity_product = $this->stockListStorehouseUnitRepository->findProductsSerialWithProductCode('', $serialNo);

        if (!empty($array_entity_product) && !empty($array_entity_product[0]) && $array_entity_product[0]['stockQuantity'] > 0) {
            //商品税区分
            $array_product_tax_code = $this->productClassRepository->findProductsTaxCodeWithProductCode($array_entity_product[0][0]['productCode']);
            if (!empty($array_product_tax_code) && !empty($array_product_tax_code[1])) {
                $product_tax_code = $array_product_tax_code[1]->getId();
            }
            // カテゴリ取得のため、商品コードで再検索する
            $array_entity_product_category = $this->productRepository->findProductsWithProductCode($array_entity_product[0][0]['productCode']);

            if (!empty($array_entity_product_category) && !empty($array_entity_product_category[0])) {
                /** @var Product $entity_product */
                $entity_product = $array_entity_product[0][0];
                $data = [
                    'target_product_code' => $array_entity_product[0][0]['productCode'],
                    'target_product_id' => $array_entity_product[0][0]['productId'],
                    'target_product_name' => $array_entity_product[0]['name'],
                    'target_product_serial_flg' => '1',
                    'target_product_category_id' => $array_entity_product_category[0]['category_id'],
                    'target_product_product_class' => $array_entity_product[0][0]['ProductClass']['id'],
                    'target_product_stateId' => $array_entity_product[0]['stateId'],
                    'target_product_state' => $array_entity_product[0]['state'],
                    'target_product_place' => $array_entity_product[0]['place'],
                    'target_product_quantity' => $array_entity_product[0]['quantity'],
                    'target_product_average_unit_price' => $array_entity_product[0]['averageUnitPrice'],
                    'tax_flg' => $tax_flg,
                    'tax_rate' => $tax_rate,
                    'tax_code' => $product_tax_code,
                    'duplicate_serial_no' => '1',
                    'member_place' => $member_place,
                ];
            } else {
                $entity_product = null;
                $data = [
                    'duplicate_serial_no' => '0',
                    'tax_flg' => $tax_flg,
                    'tax_rate' => $tax_rate,
                    'tax_code' => $product_tax_code,
                ];
            }
        } else {
            $entity_product = null;
            $data = [
                'duplicate_serial_no' => '0',
                'tax_flg' => $tax_flg,
                'tax_rate' => $tax_rate,
                'tax_code' => $product_tax_code,
            ];
        }
        $event = new EventArgs(
            [
                'Product' => $array_entity_product,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_VOUCHER_INDEX_SEARCH_PRODUCT_INITIALIZE, $event);
        $event = new EventArgs(
            [
                'Product' => $entity_product,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_VOUCHER_INDEX_SEARCH_PRODUCT_COMPLETE, $event);

        return $this->json($data);
    }
    /**
     * @Route("/%eccube_admin_route%/sales_voucher/check/serial", name="admin_sales_voucher_check_serial")
     * @param Request $request リクエスト
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function checkSerialNo(Request $request)
    {
        $product_code = $request->get('code');
        $serialNo = $request->get('serialNo');
        $serialFlg = true;

        log_info('Admin SalesVoucher checkSerialNo', [$product_code]);
        $strSerial = '';

        $serialArray = explode("\n", $serialNo);
        foreach ($serialArray  as $serial) {
            if (empty($serial)) {
                continue;
            }
            // 2021/11/02 CNC UPDATE START
            // $array_entity_product = $this->productClassRepository->findProductsSerialWithProductCode($product_code, $serial);
            $array_entity_product = $this->stockListStorehouseUnitRepository->findProductsSerialInStock($serial);
            // 2021/11/02 CNC UPDATE END
            if (empty($array_entity_product) || empty($array_entity_product[0]) || $array_entity_product[0]['stockQuantity'] <= 0) {
                $serialFlg = false;
                $strSerial = $strSerial.$serial.'  ';
            }
        }
        if ($serialFlg) {
            $data = [
                'strSerial' => $strSerial,
                'duplicate_serial_no' => '1',
            ];
        } else {
            $data = [
                'strSerial' => $strSerial,
                'duplicate_serial_no' => '0',
            ];
        }
        $event = new EventArgs(
            [
                'ProductCode' => $product_code,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_VOUCHER_INDEX_CHECK_SERIAL, $event);

        return $this->json($data);
    }

    /**
     * @Route("/%eccube_admin_route%/sales_voucher/search/serial", name="admin_sales_voucher_search_serial")
     * @param Request $request リクエスト
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchSerialNo(Request $request)
    {
        $product_code = $request->get('code');
        $serialNo = $request->get('serialNo');

        log_info('Admin SalesVoucher checkSerialNo', [$product_code]);
        $array_entity_product = $this->stockListStorehouseUnitRepository->findProductsSerialWithProductCode($product_code, $serialNo);
        if (!empty($array_entity_product) && !empty($array_entity_product[0]) && $array_entity_product[0]['stockQuantity'] > 0) {
            $data = [
                'target_product_place' => $array_entity_product[0]['place'],
                'stateId' => $array_entity_product[0]['stateId'],
            ];
        } else {
            $data = [
                'target_product_place' => '',
                'stateId' => '',
            ];
        }
        $event = new EventArgs(
            [
                'ProductCode' => $product_code,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_VOUCHER_INDEX_CHECK_SERIAL, $event);

        return $this->json($data);
    }

    // MOD-START CNC 2022/10/10 「在庫数不足」チェックを変更
//    /**
//     * @Route("/%eccube_admin_route%/sales_voucher/check/place", name="admin_sales_voucher_check_place_count")
//     * @param Request $request リクエスト
//     * @return \Symfony\Component\HttpFoundation\JsonResponse
//     */
//    public function checkPlaceCount(Request $request)
//    {
//        $product_code = $request->get('productCode');
//
//        // 特殊商品（料）場合、チェックなし
//        $collection_special_cost = $this->otherItemCodeChangeRepository->findBy(['name' => $product_code]);
//        if (isset($collection_special_cost[0])) {
//            $data = [
//                'state_name' => '',
//                'product_code' => $product_code,
//                'duplicate_count' => '0',
//            ];
//            return $this->json($data);
//        }
//
//        $place = $request->get('place');
//        $state = $request->get('state');
//        $serialNo = $request->get('serial_no');
//        $quantity = $request->get('quantity');
//
//        $existFlg = true;
//
//        log_info('Admin SalesVoucher checkPlaceCount', [$product_code]);
//
//        if (empty($serialNo)) {
//            $parameter_stock_list_storehouse_unit = [
//                'productCode' => $product_code,
//                'Storehouse' => $place,
//                'State' => $state,
//            ];
//        } else {
//            $parameter_stock_list_storehouse_unit = [
//                'productCode' => $product_code,
//                'Storehouse' => $place,
//                'State' => $state,
//                'serialNo' => $serialNo,
//            ];
//        }
//        $state = $this->stateRepository->find($state);
//        $collection_stock_list_storehouse_unit = $this->stockListStorehouseUnitRepository
//            ->findBy(
//                $parameter_stock_list_storehouse_unit,
//                /* ['createDate' => 'DESC'] */
//                ['stockQuantity' => 'DESC', 'updateDate' => 'DESC']
//            );
//        $stock_quantity = 0;
//        if (is_array($collection_stock_list_storehouse_unit)) {
//            foreach ($collection_stock_list_storehouse_unit as $item_stock_list_storehouse_unit) {
//                $stock_quantity += $item_stock_list_storehouse_unit['stockQuantity'];
//            }
//        }
//        //置場在庫数＜出荷数の場合
//        if (empty($collection_stock_list_storehouse_unit) || empty($collection_stock_list_storehouse_unit[0]) || $stock_quantity < $quantity) {
//            $existFlg = false;
//        }
//        if ($existFlg) {
//            $data = [
//                'state_name' => $state->getState(),
//                'product_code' => $product_code,
//                'duplicate_count' => '0',
//            ];
//        } else {
//            $data = [
//                'state_name' => $state->getState(),
//                'product_code' => $product_code,
//                'duplicate_count' => '1',
//            ];
//        }
//        $event = new EventArgs(
//            [
//                'ProductCode' => $product_code,
//            ],
//            $request
//        );
//        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_VOUCHER_INDEX_CHECK_PLACE, $event);
//
//        return $this->json($data);
//    }
    /**
     * @Route("/%eccube_admin_route%/sales_voucher/check/place", name="admin_sales_voucher_check_place_count")
     * @param Request $request リクエスト
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function checkPlaceCount(Request $request)
    {
        $product_code = $request->get('productCode');

        // 特殊商品（料）場合、チェックなし
        $collection_special_cost = $this->otherItemCodeChangeRepository->findBy(['name' => $product_code]);
        if (isset($collection_special_cost[0])) {
            $data = [
                'state_name' => '',
                'product_code' => $product_code,
                'duplicate_count' => '0',
            ];
            return $this->json($data);
        }

        $place = $request->get('place');
        $state = $request->get('state');
        $serialNo = $request->get('serial_no');
        $quantity = $request->get('quantity');

        $existFlg = true;

        log_info('Admin SalesVoucher checkPlaceCount', [$product_code]);

        // 平均単価
        $average_price = 0;
        $collection_stock_list_product_unit = $this->stockListProductUnitRepository->findStockListProductUnitByKey($product_code, $state);
        if (!empty($collection_stock_list_product_unit) && !empty($collection_stock_list_product_unit[0])) {
            $average_price = $collection_stock_list_product_unit[0]['averageUnitPrice'];
        }

        if (empty($serialNo)) {
            $parameter_stock_list_storehouse_unit = [
                'productCode' => $product_code,
                'Storehouse' => $place,
                'State' => $state,
            ];
        } else {
            $data = [
                'stock_quantity' => '',
                'average_price' => $average_price,
                'duplicate_count' => '0',
            ];
            return $this->json($data);
        }
        $collection_stock_list_storehouse_unit = $this->stockListStorehouseUnitRepository
            ->findBy(
                $parameter_stock_list_storehouse_unit,
                /* ['createDate' => 'DESC'] */
                ['stockQuantity' => 'DESC', 'updateDate' => 'DESC']
            );
        $stock_quantity = 0;
        if (is_array($collection_stock_list_storehouse_unit)) {
            foreach ($collection_stock_list_storehouse_unit as $item_stock_list_storehouse_unit) {
                $stock_quantity += $item_stock_list_storehouse_unit['stockQuantity'];
            }
        }
        //置場在庫数＜出荷数の場合
        if (empty($collection_stock_list_storehouse_unit) || empty($collection_stock_list_storehouse_unit[0]) || $stock_quantity < $quantity) {
            $existFlg = false;
        }
        if ($existFlg) {
            $data = [
                'stock_quantity' => $stock_quantity,
                'average_price' => $average_price,
                'duplicate_count' => '0',
            ];
        } else {
            $data = [
                'stock_quantity' => $stock_quantity,
                'average_price' => $average_price,
                'duplicate_count' => '1',
            ];
        }
        $event = new EventArgs(
            [
                'ProductCode' => $product_code,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_VOUCHER_INDEX_CHECK_PLACE, $event);

        return $this->json($data);
    }
    // MOD-END CNC 2022/10/10


    /**
     * @Route("/%eccube_admin_route%/sales_voucher/search/product_sub", name="admin_sales_voucher_search_product_sub")
     * @Route("/%eccube_admin_route%/sales_voucher/search/product_sub/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_sales_voucher_search_product_sub_page")
     * @Template("@admin/SalesVoucher/search_sales_product.twig")
     * @param Request $request Request
     * @param int|null $page_no page_no
     * @param Paginator|null $paginator Paginator
     * @return array
     */
    public function searchProductSubPage(Request $request, int $page_no = null, Paginator $paginator = null)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('search product start.');
            $page_count = $this->eccubeConfig['eccube_default_page_count'];
            $session = $this->session;

            if ('POST' === $request->getMethod()) {
                $page_no = 1;

                $searchData = [
                    'id' => $request->get('id'),
                ];

                if ($categoryId = $request->get('category_id')) {
                    $Category = $this->categoryRepository->find($categoryId);
                    $searchData['category_id'] = $Category;
                }

                $session->set('eccube.admin.sales_voucher.product.search', $searchData);
                $session->set('eccube.admin.sales_voucher.product.search.page_no', $page_no);
            } else {
                $searchData = (array) $session->get('eccube.admin.sales_voucher.product.search');
                if (is_null($page_no)) {
                    $page_no = intval($session->get('eccube.admin.sales_voucher.product.search.page_no'));
                } else {
                    $session->set('eccube.admin.sales_voucher.product.search.page_no', $page_no);
                }
            }

            $qb = $this->productRepository
                ->getQueryBuilderBySearchDataForAdminSubPage($searchData);

            $event = new EventArgs(
                [
                    'qb' => $qb,
                    'searchData' => $searchData,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_VOUCHER_INDEX_SEARCH_PRODUCT_SUB, $event);

            /** @var \Knp\Component\Pager\Pagination\SlidingPagination $pagination */
            $pagination = $paginator->paginate(
                $qb,
                $page_no,
                $page_count,
                ['wrap-queries' => true]
            );

            /** @var $Products \Eccube\Entity\Product[] */
            $Products = $pagination->getItems();

            if (empty($Products)) {
                log_debug('search product not found.');
            }

            $forms = [];
            foreach ($Products as $Product) {
                /* @var $builder \Symfony\Component\Form\FormBuilderInterface */
                $builder = $this->formFactory->createNamedBuilder('', AddCartType::class, null, [
                    'product' => $this->productRepository->findWithSortedClassCategories($Product->getId()),
                ]);
                $addCartForm = $builder->getForm();
                $forms[$Product->getId()] = $addCartForm->createView();
            }

            $event = new EventArgs(
                [
                    'forms' => $forms,
                    'Products' => $Products,
                    'pagination' => $pagination,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_VOUCHER_INDEX_SEARCH_PRODUCT_SUB_COMPLETE, $event);

            return [
                'forms' => $forms,
                'pagination' => $pagination,
            ];
        }
    }

    /**
     * @Route("/%eccube_admin_route%/sales_voucher/search/taxCode", name="admin_sales_voucher_getTaxCode")
     * @param Request $request リクエスト
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getTaxCode(Request $request)
    {
        $taxCodeSelect = $request->get('taxCodeSelect');

        log_info('Admin SalesVoucher searchTaxCode', [$taxCodeSelect]);

        // 商品取得
        $entity_taxCode = $this->taxCodeRepository->getTaxCodeById($taxCodeSelect);

        if (!empty($entity_taxCode) && !empty($entity_taxCode[0])) {
            if ($entity_taxCode[0]->getCalculateTax()->getId() === 2) {
                //税込
                $tax_flg = '1';
            } else {
                //税抜
                $tax_flg = '0';
            }
            $tax_rate = $entity_taxCode[0]->getTaxRate();

            $data = [
                'header_tax_code' => $tax_flg,
                'header_tax_rate' => $tax_rate,
            ];
        } else {
            log_debug('search tax by code not found.');
            return $this->json([], 404);
        }

        $event = new EventArgs(
            [
                'header_tax_code' => $tax_flg,
                'header_tax_rate' => $tax_rate,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_VOUCHER_INDEX_SEARCH_TAX_CODE, $event);

        return $this->json($data);
    }

    /**
     * 支払方法：銀行振込 情報取得
     * @return Payment
     */
    public function getPaymentBankTransfer()
    {
        $array_payment_bank_transfer = $this->paymentRepository->findBy(['method' => '銀行振込']);
        return isset($array_payment_bank_transfer[0])
            ? $array_payment_bank_transfer[0]
            : null;
    }

    /**
     * 税金区分：税込10% 情報取得
     * @return TaxCode
     */
    public function getTaxCodeTransfer()
    {
        $array_return = $this->taxCodeRepository->findBy(['taxName' => '税込10%']);
        return isset($array_return[0])
            ? $array_return[0]
            : null;
    }

    /**
     * 売上伝票明細紐付
     *
     * @param $searchData
     *
     * @return ArrayCollection|array
     */
    public function getSalesVoucherDetailLinkData($searchData)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();
        $sql = '
                select s.payee_Voucher_Header_id
                ,s.payee_Voucher_No
                ,s.payee_Details_No
                ,s.product_code
                ,s.state_id
                ,s.storehouse_id
                ,s.create_Date
                ,sum(s.quantity) AS quantityTotal
            FROM
                 dtb_sales_voucher_detail_link s
            INNER JOIN dtb_payee_voucher_detail p
				 ON s.payee_voucher_header_id = p.payee_voucher_header_id
				 AND s.payee_voucher_no = p.payee_voucher_no
				 AND s.payee_details_no = p.payee_detail_no
            WHERE
                 ';
        $sql = $sql.' s.product_code = \''.$searchData['product_code'].'\'  AND s.state_id = \''.$searchData['state']['id'].'\' AND s.storehouse_id = \''.$searchData['place']['id'].'\'
            GROUP BY
                s.payee_Voucher_No,s.payee_Details_No,s.product_code,s.state_id,s.storehouse_id
            ORDER BY
                s.create_Date desc,p.create_date';

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    /**
     * 仕入伝票明細
     *
     * @param $searchData
     *
     * @return ArrayCollection|array
     */
    public function getPayeeVoucherDetailData($searchData)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();
        $sql = '
                SELECT
                 d.payee_voucher_header_id,d.quantity,d.payee_voucher_no,d.payee_detail_no,d.payee_price,d.create_Date
                FROM
                  dtb_payee_voucher_detail d
                INNER JOIN dtb_payee_voucher_header  h on d.payee_voucher_header_id = h.id
                WHERE';
        $sql = $sql.' d.product_code = \''.$searchData['product_code'].'\' AND d.state_id = \''.$searchData['state']['id'].'\' AND h.storehouse_id = \''.$searchData['place']['id'].'\'
            ORDER BY
                d.create_Date,payee_voucher_header_id,payee_voucher_no,payee_detail_no';

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    /**
     * 仕入伝票明細
     *
     * @param $searchData
     *
     * @return ArrayCollection|array
     */
    public function getPayeeVoucherDetailByDetailLink($searchData)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();
        $sql = '
                SELECT
                 d.payee_voucher_header_id,d.payee_voucher_no,d.payee_detail_no,d.quantity,d.state_id,d.create_date,d.payee_price
                FROM
                  dtb_payee_voucher_detail d
                INNER JOIN dtb_payee_voucher_header  h on d.payee_voucher_header_id = h.id
                WHERE  d.create_date >=(
                    SELECT d.create_date
	                FROM dtb_payee_voucher_detail d
	                WHERE ';
        $sql = $sql.' payee_voucher_header_id = \''.$searchData['payee_Voucher_Header_id']
            .'\' AND payee_voucher_no = \''.$searchData['payee_Voucher_No'].'\' AND payee_detail_no = \''.$searchData['payee_Details_No'].'\' )';
        $sql = $sql.' AND d.product_code = \''.$searchData['product_code'].'\' AND d.state_id = \''.$searchData['state_id'].'\' AND h.storehouse_id = \''.$searchData['storehouse_id'].'\'';
        //serial
        if (!empty($searchData['serial'])) {
            $sql = $sql.' AND  d.serial_no = \''.$searchData['serial'].'\'';
        }
        $sql = $sql.' ORDER BY
                d.create_Date';

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }


    // INS-START CNC 2022/03/10
    /**
     * @Route("/%eccube_admin_route%/sales_voucher/search/customercode", name="admin_sales_voucher_customercode")
     * @param Request $request リクエスト
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchCustomerCode(Request $request)
    {
        $customer_code = $request->get('code');

        log_info("Admin SalesVoucher searchCustomer", [$customer_code]);

        // 得意先取得
        $array_entity_customer_code = $this->customerMstRepository->findCustomerWithCustomerCode($customer_code);

        $event = new EventArgs(
            [
                'CustomerCode' => $customer_code,
                'Customer' => $array_entity_customer_code,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_MANAGEMENT_INDEX_SEARCH_CUSTOMER_INITIALIZE, $event);

        if (!empty($array_entity_customer_code) && !empty($array_entity_customer_code[0])) {
            /** @var CustomerMst $entity_customer */
            $entity_customer = $array_entity_customer_code[0];
            $data = [
                'target_customer_id' => $entity_customer->getId(),
                'target_customer_code' => $entity_customer->getCustomerCode(),
                'target_customer_name' => $entity_customer->getCustomerName(),
            ];
        } else {
            log_debug('search customer by code not found.');
            return $this->json([], 404);
        }
        $event = new EventArgs(
            [
                'CustomerCode' => $customer_code,
                'Customer' => $entity_customer,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_MANAGEMENT_INDEX_SEARCH_CUSTOMER_COMPLETE, $event);

        return $this->json($data);
    }

    // INS-END CNC 2022/03/10
}
