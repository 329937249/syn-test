<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\SalesVoucher;

use Doctrine\ORM\EntityManagerInterface;
use Eccube\Controller\AbstractController;
use Eccube\Entity\LogControllable;
use Eccube\Entity\Master\CsvType;
use Eccube\Entity\SalesVoucherDetail;
use Eccube\Entity\SalesVoucherHeader;
use Eccube\Entity\SalesVoucherHeaderHistory;
use Eccube\Entity\SalesVoucherReturnsHistory;
use Eccube\Entity\StockListProductUnit;
use Eccube\Entity\StockListStorehouseUnit;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\SalesVoucherDetailReturnQuantityType;
use Eccube\Form\Type\Admin\SalesVoucherItemType;
use Eccube\Form\Type\Admin\SearchMemberType;
use Eccube\Form\Type\Admin\SalesVoucherSearchCustomerType;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\Master\SpecialAuthorityRepository;
use Eccube\Repository\SalesVoucherDetailLinkRepository;
use Eccube\Repository\SalesVoucherHeaderHistoryRepository;
use Eccube\Repository\TaxCodeRepository;
use Eccube\Repository\SalesVoucherDetailRepository;
use Eccube\Repository\SalesVoucherHeaderRepository;
use Eccube\Repository\StockListProductUnitRepository;
use Eccube\Repository\StockListStorehouseUnitRepository;
use Eccube\Repository\SalesVoucherReturnsHistoryRepository;
use Eccube\Service\CsvExportService;
use Eccube\Util\FormUtil;
use Eccube\Util\StringUtil;
use Knp\Component\Pager\Paginator;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\Routing\Annotation\Route;
use Eccube\Repository\MemberRepository;
use Eccube\Repository\customerMstRepository;
use Doctrine\ORM\QueryBuilder;

/**
 *プログラム名 ： SalesVoucherDetailController.php
 *概　　要     ： 売上伝票明細
 *作　　成     ： 2021/8/16 CNC
 */
class SalesVoucherDetailController extends AbstractController
{
    // 一覧画面URL
    const PREVIOUS_PAGE_URL_LIST = 'sales_management/sales_voucher_list';
    const BACK_TO_LIST_URL_LIST = 'admin_sales_voucher_list';
    const BACK_TO_LIST_NAME_LIST = 'admin.sales.voucher_list';

    const PREVIOUS_PAGE_URL_BALANCE = 'payment/cash_receipt_balance';
    const BACK_TO_LIST_URL_BALANCE = 'admin_payment_cash_receipt';
    const BACK_TO_LIST_NAME_BALANCE = 'admin.remittance.cash_receipt_balance';

    /**
     * @var CsvExportService
     */
    protected $csvExportService;
    /**
     * @var EntityManagerInterface
     */
    protected $entityManager;

    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;

    /**
     * @var CustomerMstRepository
     */
    protected $customerMstRepository;

    /**
     * @var MemberRepository
     */
    protected $memberRepository;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;
    /**
     * @var SalesVoucherHeaderHistoryRepository
     */
    protected $salesVoucherHeaderHistoryRepository;
    /**
     * @var TaxCodeRepository
     */
    protected $taxCodeRepository;
    /**
     * @var SalesVoucherDetailRepository
     */
    protected $salesVoucherDetailRepository;
    /**
     * @var SalesVoucherHeaderRepository
     */
    protected $salesVoucherHeaderRepository;
    /**
     * @var StockListProductUnitRepository
     */
    protected $stockListProductUnitRepository;
    /**
     * @var StockListStorehouseUnitRepository
     */
    protected $stockListStorehouseUnitRepository;
    /**
     * @var SalesVoucherReturnsHistoryRepository
     */
    protected $salesVoucherReturnsHistoryRepository;
    /**
     * @var SalesVoucherDetailLinkRepository
     */
    protected $salesVoucherDetailLinkRepository;

    /**
     * @var SpecialAuthorityRepository
     */
    protected $specialAuthorityRepository;

    /**
     * ProductController constructor.
     *
     * @param CsvExportService $csvExportService
     * @param CategoryRepository $categoryRepository
     * @param PageMaxRepository $pageMaxRepository
     * @param EntityManagerInterface $entityManager
     * @param CustomerMstRepository $customerMstRepository,
     * @param MemberRepository $memberRepository
     * @param SalesVoucherHeaderHistoryRepository $salesVoucherHeaderHistoryRepository,
     * @param TaxCodeRepository $taxCodeRepository
     * @param SalesVoucherDetailLinkRepository $salesVoucherDetailLinkRepository 売上伝票明細紐付
     * @param SalesVoucherDetailRepository $salesVoucherDetailRepository
     * @param SalesVoucherHeaderRepository $salesVoucherHeaderRepository
     * @param StockListProductUnitRepository $stockListProductUnitRepository
     * @param StockListStorehouseUnitRepository $stockListStorehouseUnitRepository
     * @param SalesVoucherReturnsHistoryRepository $salesVoucherReturnsHistoryRepository
     * @param SpecialAuthorityRepository $specialAuthorityRepository SpecialAuthorityRepository
     */
    public function __construct(
        CsvExportService $csvExportService,
        CategoryRepository $categoryRepository,
        PageMaxRepository $pageMaxRepository,
        EntityManagerInterface $entityManager,
        CustomerMstRepository $customerMstRepository,
        MemberRepository $memberRepository,
        SalesVoucherHeaderHistoryRepository $salesVoucherHeaderHistoryRepository,
        TaxCodeRepository $taxCodeRepository,
        SalesVoucherDetailRepository $salesVoucherDetailRepository,
        SalesVoucherDetailLinkRepository $salesVoucherDetailLinkRepository,
        SalesVoucherHeaderRepository $salesVoucherHeaderRepository,
        StockListProductUnitRepository $stockListProductUnitRepository,
        StockListStorehouseUnitRepository $stockListStorehouseUnitRepository,
        SalesVoucherReturnsHistoryRepository $salesVoucherReturnsHistoryRepository,
        SpecialAuthorityRepository $specialAuthorityRepository

    ) {
        $this->csvExportService = $csvExportService;
        $this->categoryRepository = $categoryRepository;
        $this->pageMaxRepository = $pageMaxRepository;
        $this->entityManager = $entityManager;
        $this->customerMstRepository = $customerMstRepository;
        $this->memberRepository = $memberRepository;
        $this->salesVoucherHeaderHistoryRepository = $salesVoucherHeaderHistoryRepository;
        $this->salesVoucherDetailLinkRepository = $salesVoucherDetailLinkRepository;
        $this->taxCodeRepository = $taxCodeRepository;
        $this->salesVoucherDetailRepository = $salesVoucherDetailRepository;
        $this->salesVoucherHeaderRepository = $salesVoucherHeaderRepository;
        $this->stockListProductUnitRepository = $stockListProductUnitRepository;
        $this->stockListStorehouseUnitRepository = $stockListStorehouseUnitRepository;
        $this->salesVoucherReturnsHistoryRepository = $salesVoucherReturnsHistoryRepository;
        $this->specialAuthorityRepository = $specialAuthorityRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/sales_management/sales_voucher_detail", name="admin_sales_voucher_detail")
     * @Route("/%eccube_admin_route%/sales_management/sales_voucher_detail/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_sales_voucher_detail_page")
     * @Route("/%eccube_admin_route%/sales_management/sales_voucher_detail/{id}", requirements={"id" = "\d+"}, name="admin_detail_sales_voucher_no")
     * @Template("@admin/SalesVoucher/sales_voucher_detail.twig")
     */
    public function index(Request $request, $page_no = null, Paginator $paginator,$id=null)
    {
        // 前ページurl
        $link = $request->headers->get('referer');

        //売上伝票一覧から
        if(strpos($link ,self::PREVIOUS_PAGE_URL_LIST)){
            // 前ページurl
            $controls_enable['back_to_list_display'] = 1;
            $controls_enable['back_to_list_url'] = self::BACK_TO_LIST_URL_LIST;
            $controls_enable['back_to_list_name'] = self::BACK_TO_LIST_NAME_LIST;
            //売上残高から
        }else if(strpos($link ,self::PREVIOUS_PAGE_URL_BALANCE)){
            // 前ページurl
            $controls_enable['back_to_list_display'] = 1;
            $controls_enable['back_to_list_url'] = self::BACK_TO_LIST_URL_BALANCE;
            $controls_enable['back_to_list_name'] = self::BACK_TO_LIST_NAME_BALANCE;
        }else{
            $controls_enable['back_to_list_display'] = 0;
        }

        $builder = $this->formFactory
            ->createBuilder(SalesVoucherItemType ::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_MANAGEMENT_SALES_VOUCHER_DETAIL_INDEX_INITIALIZE, $event);

        $searchForm = $builder->getForm();

        // 得意先検索フォーム
        $builder = $this->formFactory
            ->createBuilder(SalesVoucherSearchCustomerType::class);
        $searchCustomerMstModalForm = $builder->getForm();

        // 担当者検索フォーム
        $builder = $this->formFactory
            ->createBuilder(SearchMemberType::class);
        $searchSalesMemberModalForm = $builder->getForm();

        // INS-START CNC 2022/03/21
        $member = $this->getUser();
        // INS-END CNC 2022/03/21

        /**
         * ページの表示件数は, 以下の順に優先される.
         * - リクエストパラメータ
         * - セッション
         * - デフォルト値
         * また, セッションに保存する際は mtb_page_maxと照合し, 一致した場合のみ保存する.
         **/
        $page_count = $this->session->get('eccube.admin.sales_detail.search.page_count',
            $this->eccubeConfig->get('eccube_default_page_count'));

        $page_count_param = (int) $request->get('page_count');
        $pageMaxis = $this->pageMaxRepository->findAll();

        $memo = '';
        $personnelmemo = '';
        $memoflg = '0';

        if ($page_count_param) {
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.admin.sales_detail.search.page_count', $page_count);
                    break;
                }
            }
        }

        $page_no_bk = $page_no;
        if ('POST' === $request->getMethod()) {
            $searchForm->handleRequest($request);

            if ($searchForm->isValid()) {
                /**
                 * 検索が実行された場合は, セッションに検索条件を保存する.
                 * ページ番号は最初のページ番号に初期化する.
                 */
                $page_no = 1;
                $searchData = $searchForm->getData();
                // 検索条件, ページ番号をセッションに保持.
                $this->session->set('eccube.admin.sales_detail.search', FormUtil::getViewData($searchForm));
                $this->session->set('eccube.admin.sales_detail.search.page_no', $page_no);
            } else {
                // 検索エラーの際は, 詳細検索枠を開いてエラー表示する.
                return [
                    'searchForm' => $searchForm->createView(),
                    'searchCustomerMstModalForm' => $searchCustomerMstModalForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $page_count,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.admin.sales_detail.search.page_no', (int)$page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.admin.sales_detail.search.page_no', 1);
                }
                $viewData = $this->session->get('eccube.admin.sales_detail.search', []);
            } else {
                /**
                 * 初期表示の場合.
                 */
                $page_no = 1;
                // main category
                $categories = $this->categoryRepository->getList(null, false);
                $mainCategory = null;
                foreach ($categories as $Category) {
                    if ($Category && ($Category->getHierarchy() == 1)) {
                        $mainCategory = $Category;
                        break;
                    }
                }

//                if ($mainCategory) {
//                    $viewData['main_category_id'] = $mainCategory->getId();
//                }

//                if ($mainCategory) {
//                    $searchData['main_category_id'] = $mainCategory;
//                }

                if ($id == null) {
                    $viewData["sales_date_end"] = date('Y-m-d', strtotime('now'));
                    $viewData["sales_date_start"] = date('Y-m-d', strtotime('now'));
//                    $viewData["personnel_memo"] = $this->getUser()['name'];
//                    $viewData["personnelMemoId"] = $this->getUser()['id'];

                } else {

                    $qbNo = $this->getSearchSalesVoucherNo($id);
                    $viewData["sales_voucher_no"] =  $qbNo[0]['sales_voucher_no'];
                    $memo = $qbNo[0]['memo'];
                    $personnelmemo = $qbNo[0]['personnel_memo'];
                    $memoflg = '1';
                }
            }
            // セッション中の検索条件, ページ番号を初期化.
            $this->session->set('eccube.admin.sales_detail.search', $viewData);
            $this->session->set('eccube.admin.sales_detail.search.page_no', $page_no);
            $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
        }

        // 202/01/18 CNC BEF START --仕入明細、商品コード、状態、価格で集計
//        /** @var QueryBuilder $qb */
//        $qb = $this->getSearchData($searchData);
        // 202/01/18 CNC BEF END
        // 202/01/18 CNC AFT START --仕入明細、商品コード、状態、価格で集計
        $qb = [];
        if ('POST' === $request->getMethod() || null !== $page_no_bk){
            if ($searchData['total_mode']) {
                /** @var QueryBuilder $qb */
                $qb = $this->getSearchTotalData($searchData);
            } else {
                /** @var QueryBuilder $qb */
                $qb = $this->getSearchData($searchData);
            }
        }

        // 202/01/18 CNC AFT END

        // INS-START CNC 2022/03/21
        // 権限
        $authority = $this->specialAuthorityRepository->isValidAuthority($member);
        // INS-END CNC 2022/03/21

        $salesMoneyTotalAmount = 0;
        foreach ($qb as &$sales) {
            $salesMoneyTotalAmount = $salesMoneyTotalAmount + $sales['total_sales_amount'];

            $sales['sales_date'] = $this->makeDateStringUtcToAsiaTokyo($sales['sales_date']);
            $sales['update_date'] = $this->makeDateStringUtcToAsiaTokyo($sales['update_date']);
            $sales['1'] = $sales['sales_date'];
            $sales['24'] = $sales['update_date'];

            // INS-START CNC 2022/03/21
            if (!$authority) {
                if ($sales['create_date'] >= date('Y-m-d', strtotime('- 5 days')) &&
                    $sales['create_date'] <= date('Y-m-d', strtotime('5 days'))) {
                    $sales['authority'] = true;
                } else {
                    $sales['authority'] = false;
                }
            } else {
                $sales['authority'] = true;
            }
            // INS-END CNC 2022/03/21
        }

        // 粗利益合計
        $grossProfitTotalAmount = 0;
        // 粗利益
        $grossProfit = 0;

        foreach ($qb as $export) {
            // 202/01/18 CNC BEF START --仕入明細、商品コード、状態、価格で集計
//            if ($export['exportAddressId'] !== null) {
//                //税金区分
//                $taxRateCategory = $export['taxRateCategoryId'];
//                $tax = $this->taxCodeRepository->find($taxRateCategory);
//                $tax_rate = $tax->getTaxRate();
//                $grossProfit = $export['sales_price'] - ($export['averageUnitPrice'] / (1 + $tax_rate / 100));
//            } else {
//                $grossProfit = $export['sales_price'] - $export['averageUnitPrice'];
//            }
//
//            $grossProfitTotalAmount = $grossProfitTotalAmount + round($grossProfit * $export['quantity']);
            // 202/01/18 CNC BEF END
            // 202/01/18 CNC AFT START --仕入明細、商品コード、状態、価格で集計
            if (!isset($export['grossProfit'])){
                if ($export['exportAddressId'] !== null) {
                    //税金区分
                    $taxRateCategory = $export['taxRateCategoryId'];
                    $tax = $this->taxCodeRepository->find($taxRateCategory);
                    $tax_rate = $tax->getTaxRate();
                    $grossProfit = $export['sales_price'] - ($export['averageUnitPrice'] / (1 + $tax_rate / 100));
                } else {
                    $grossProfit = $export['sales_price'] - $export['averageUnitPrice'];
                }

                $grossProfitTotalAmount = $grossProfitTotalAmount + round($grossProfit * $export['quantity']);
            } else {
                $grossProfitTotalAmount = $grossProfitTotalAmount + $export['grossProfit'];
            }
            // 202/01/18 CNC AFT END
        }

        $sort_orders = $this->sortOrder($qb, $searchData);

        $event = new EventArgs(
            [
                'qb' => $qb,
                'searchData' => $searchData,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_MANAGEMENT_SALES_VOUCHER_DETAIL_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $page_count
        );

        $forms = [];
        foreach ($sort_orders as $EditTag) {
            $id = $EditTag['id'];
            $forms[$id] = $this
                ->formFactory
                ->createNamed('returnQuantity_'.$id, SalesVoucherDetailReturnQuantityType::class, $EditTag);
        }

        $formViews = [];
        foreach ($forms as $key => $value) {
            $formViews[$key] = $value->createView();
        }

        $i = 0;
        //粗利益
        $crude = 0;
        //利益率
        $rate = 0;

        foreach ($pagination as $export) {
            // 202/01/18 CNC BEF START --仕入明細、商品コード、状態、価格で集計
//            if ($pagination[$i]['exportAddressId'] !== null) {
//                //税金区分
//                $taxRateCategory = $pagination[$i]['taxRateCategoryId'];
//                $tax = $this->taxCodeRepository->find($taxRateCategory);
//                $tax_rate = $tax->getTaxRate();
//                $crude = $export['sales_price'] - ($export['averageUnitPrice'] / (1 + $tax_rate / 100));
//                if (isset($export['sales_price']) && $export['sales_price'] != 0) {
//                    $rate = ($crude / $export['sales_price']) * 100;
//                }
//                $export['crude'] = round($crude * $export['quantity']);
//                $export['rate'] = round($rate, 1);
//                $pagination[$i] = $export;
//                $i++;
//            } else {
//                $crude = $export['sales_price'] - $export['averageUnitPrice'];
//                if (isset($export['sales_price']) && $export['sales_price'] != 0) {
//                    $rate = ($crude / $export['sales_price']) * 100;
//                }
//                $export['crude'] = round($crude * $export['quantity']);
//                $export['rate'] = round($rate, 1);
//                $pagination[$i] = $export;
//                $i++;
//            }
            // 202/01/18 CNC BEF END
            // 202/01/18 CNC AFT START --仕入明細、商品コード、状態、価格で集計
            if (!isset($export['grossProfit'])) {
                if ($pagination[$i]['exportAddressId'] !== null) {
                    //税金区分
                    $taxRateCategory = $pagination[$i]['taxRateCategoryId'];
                    $tax = $this->taxCodeRepository->find($taxRateCategory);
                    $tax_rate = $tax->getTaxRate();
                    $crude = $export['sales_price'] - ($export['averageUnitPrice'] / (1 + $tax_rate / 100));
                    if (isset($export['sales_price']) && $export['sales_price'] != 0) {
                        $rate = ($crude / $export['sales_price']) * 100;
                    } else {
                        $rate = 0;
                    }
                    $export['crude'] = round($crude * $export['quantity']);
                    $export['rate'] = round($rate, 1);
                    $pagination[$i] = $export;
                    $i++;
                } else {
                    $crude = $export['sales_price'] - $export['averageUnitPrice'];
                    if (isset($export['sales_price']) && $export['sales_price'] != 0) {
                        $rate = ($crude / $export['sales_price']) * 100;
                    } else {
                        $rate = 0;
                    }
                    $export['crude'] = round($crude * $export['quantity']);
                    $export['rate'] = round($rate, 1);
                    $pagination[$i] = $export;
                    $i++;
                }
            } else {
                $crude = $export['grossProfit'];
                if (isset($export['total_sales_amount']) && $export['total_sales_amount'] != 0) {
                    $rate = ($crude / $export['total_sales_amount']) * 100;
                }
                $export['crude'] = round($crude);
                $export['rate'] = round($rate, 1);
                $pagination[$i] = $export;
                $i++;
            }
            // 202/01/18 CNC AFT END
        }

        return [
            'searchForm' => $searchForm->createView(),
            'searchCustomerMstModalForm' => $searchCustomerMstModalForm->createView(),
            'searchSalesMemberModalForm' => $searchSalesMemberModalForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'has_errors' => false,
            'request' => $request,
            'salesMoneyTotalAmount' => $salesMoneyTotalAmount,
            'grossProfitTotalAmount' => $grossProfitTotalAmount,
            'ControlsEnable' => $controls_enable,
            'forms' => $formViews,
            'memo'=> $memo,
            'personnelmemo'=> $personnelmemo,
            'memoflg' => $memoflg,
        ];
    }
    /**
     * 売上伝票明細.
     *
     * @param $searchData
     *
     * @return null|result
     */
    public function getSearchData($searchData)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();
        $sql = '
                SELECT
                    dsvd.id,
                    dsvh.sales_date,
                    mcm.customer_code,
                    mcm.id AS customerId,
                    mcm.customer_name AS customerName,
                    dsvd.sales_voucher_no,
                    dc4.category_id AS category_id1,
                    dc4.categoryName AS categoryName1,
                    dc5.category_id AS category_id2,
                    dc5.categoryName as categoryName2,
                    dc6.category_id AS category_id3,
                    dc6.categoryName as categoryName3,
                    dsvd.product_code,
                    dp.name AS productName,
                    ms.state AS stateName,
                    dsvd.serial_no,
                    dsvd.quantity,
                    dsvd.sales_price_extax,
                    dsvd.sales_price,
                    dsvd.total_sales_amount,
                    dm.id AS personnelMemoId,
                    dm.name AS personnelName,
                    mp.place,
                    dsvd.update_user_name,
                    dsvd.update_date,
                    dsvd.stock_quantity AS stockQuantity,
                    case when dsvd.average_unit_price IS NULL then dslpu.average_unit_price else dsvd.average_unit_price end  AS averageUnitPrice,
                    dsvh.export_Address_id AS exportAddressId,
                    dsvh.tax_rate_category_id AS taxRateCategoryId,
                    dsvd.sales_voucher_header_id,
                    dsvd.create_date
                FROM
                    dtb_sales_voucher_detail dsvd
                INNER JOIN dtb_sales_voucher_header dsvh
                    ON dsvd.sales_voucher_header_id = dsvh.id
                INNER JOIN mtb_customer_mst mcm
                    ON mcm.id=dsvh.customer_id
                INNER JOIN dtb_product dp
                    ON dp.id=dsvd.product_id
                INNER JOIN mtb_state ms
                    ON ms.id=dsvd.state_id
                INNER JOIN mtb_place mp
                    ON mp.id=dsvd.storehouse_id
                INNER JOIN dtb_member dm
                    ON dm.id=dsvh.personnel_id
                LEFT JOIN dtb_stock_list_product_unit dslpu
                    ON dsvd.product_id=dslpu.product_id
                    AND dsvd.state_id = dslpu.state_id
                    AND dsvd.product_code = dslpu.product_code
                INNER JOIN (
                    SELECT
                        dsvds.id,
                        dpcs.category_id,
                        dcs.category_name AS categoryName,
                        dcs.hierarchy
                    FROM
                        dtb_sales_voucher_detail dsvds
                        INNER JOIN dtb_product dps
                            ON dsvds.product_id = dps.id
                        INNER JOIN dtb_product_category dpcs
                            ON dsvds.product_id = dpcs.product_id
                        INNER JOIN dtb_category dcs
                            ON dcs.id = dpcs.category_id
                         WHERE dpcs.category_sub_flag <>1
                ) AS dc4
                    ON dc4.id = dsvd.id
                    AND dc4.hierarchy = 1
                LEFT JOIN (
                    SELECT
                        dsvds.id,
                        dpcs.category_id,
                        dcs.category_name AS categoryName,
                        dcs.hierarchy
                    FROM
                        dtb_sales_voucher_detail dsvds
                        INNER JOIN dtb_product dps
                            ON dsvds.product_id = dps.id
                        INNER JOIN dtb_product_category dpcs
                            ON dsvds.product_id = dpcs.product_id
                        INNER JOIN dtb_category dcs
                            ON dcs.id = dpcs.category_id
                         WHERE dpcs.category_sub_flag <>1
                ) AS dc5
                    ON dc5.id = dsvd.id
                    AND dc5.hierarchy = 2
                LEFT JOIN (
                    SELECT
                        dsvds.id,
                        dpcs.category_id,
                        dcs.category_name AS categoryName,
                        dcs.hierarchy
                    FROM
                        dtb_sales_voucher_detail dsvds
                        INNER JOIN dtb_product dps
                            ON dsvds.product_id = dps.id
                        INNER JOIN dtb_product_category dpcs
                            ON dsvds.product_id = dpcs.product_id
                        INNER JOIN dtb_category dcs
                            ON dcs.id = dpcs.category_id
                         WHERE dpcs.category_sub_flag <>1
                ) AS dc6
                    ON dc6.id = dsvd.id
                    AND dc6.hierarchy = 3
                WHERE TRUE
            ';

        $flg = false;

        //serial
        if (isset($searchData['serial']) && StringUtil::isNotBlank($searchData['serial'])) {
            $sql = $sql.' AND  dsvd.serial_no LIKE '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['serial']))."%'";
            $flg = true;
        }

        //sales_voucher_no
        if (isset($searchData['sales_voucher_no']) && StringUtil::isNotBlank($searchData['sales_voucher_no'])) {
            $sql = $sql.' AND  dsvd.sales_voucher_no LIKE '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['sales_voucher_no']))."%'";
            $flg = true;
        }

        if ($flg != true) {
            //product_code
            if (isset($searchData['product_code']) && StringUtil::isNotBlank($searchData['product_code'])) {
                $sql = $sql.' AND  dsvd.product_code LIKE '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['product_code']))."%'";
                $flg = true;
            }

            //place
            if (isset($searchData['Place']) && StringUtil::isNotBlank($searchData['Place'])) {
                $sql = $sql.' AND mp.id='."'".$searchData['Place']->getId()."'";
            }

            //product_name
            if (isset($searchData['product_name']) && StringUtil::isNotBlank($searchData['product_name'])) {
                $sql = $sql.' AND  dp.name LIKE '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['product_name']))."%'";
            }

            //personnel_memo
            if (isset($searchData['personnel_memo']) && StringUtil::isNotBlank($searchData['personnel_memo'])) {
                $sql = $sql.' AND   dm.id = '.$searchData['personnelMemoId'];
            }

            //customerName
            if (isset($searchData['customerName']) && StringUtil::isNotBlank($searchData['customerName'])) {
                $sql = $sql.' AND  mcm.id = '.$searchData['customerId'];
            }

            //sales_date_start
            if (isset($searchData['sales_date_start']) && StringUtil::isNotBlank($searchData['sales_date_start'])) {
                /** @var \DateTime $sales_date_start */
                $sales_date_start = $searchData['sales_date_start'];
                $salesDateStart = $sales_date_start->setTime('0', '0', '0')
                    ->setTimezone(new \DateTimeZone('UTC'))
                    ->format('Y-m-d H:i:s');
                $sql = $sql.' AND  dsvh.sales_date >= \''.$salesDateStart .'\'';
            }

            //sales_date_end
            if (isset($searchData['sales_date_end']) && StringUtil::isNotBlank($searchData['sales_date_end'])) {
                /** @var \DateTime $sales_date_end */
                $sales_date_end = $searchData['sales_date_end'];
                $salesDateEnd = $sales_date_end->setTime('23', '59', '59')
                    ->setTimezone(new \DateTimeZone('UTC'))
                    ->format('Y-m-d H:i:s');
                $sql = $sql . ' AND  dsvh.sales_date <= \'' .$salesDateEnd  . '\'';
            }

            // mainCategory
            if (isset($searchData['main_category_id']) && !empty($searchData['main_category_id']) && $searchData['main_category_id']) {
                $Category = $searchData['main_category_id'];
                $category_id = 'category_id_'.$Category->getId();
                if (isset($searchData[$category_id]) && !empty($searchData[$category_id]) && $searchData[$category_id]) {
                    $Categories = $searchData[$category_id]->getSelfAndDescendants();
                } else {
                    $Categories = $Category->getSelfAndDescendants();
                }
                if ($Categories) {
                    $sql = $sql.'AND dc4.category_id='."'".$searchData['main_category_id']['id']."'";
                    if ($searchData[$category_id]) {
                        if ($searchData[$category_id]['hierarchy'] == '2') {
                            $sql = $sql.'AND  dc5.category_id='."'".$searchData[$category_id]['id']."'";
                        } else {
                            $sql = $sql.'AND  dc6.category_id='."'".$searchData[$category_id]['id']."'";
                        }
                    }
                }
            }
        }
        $sql = $sql.' ORDER BY
        dsvh.sales_date DESC
        ,dsvd.update_date DESC
        ,mcm.customer_name
        ,dsvd.sales_voucher_no
        ,dsvd.sales_details_no
        ';

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }
    /**
     * 売上伝票明細.
     *
     * @param $id
     *
     * @return null|result
     */
    public function getSearchSalesVoucherNo($id)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();
        $sql = ' SELECT dsvd.sales_voucher_no,
                 dsvd.memo,
                 dsvd.personnel_memo
                 FROM dtb_sales_voucher_header dsvd
                 WHERE TRUE
                 ';
        $sql= $sql.' AND dsvd.id='."'".$id."'";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }
    /**
     * ソート.
     */
    private function sortOrder($orders, $searchData){
        if($searchData['sort_by']){
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case '売上日':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a["sales_date"]> $b["sales_date"] ? -1 : 1;
                        }
                        return $a["sales_date"] < $b["sales_date"] ? -1 : 1;
                    });
                    break;
                case '得意先名':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a["customerName"] > $b["customerName"] ? -1 : 1;
                        }
                        return $a["customerName"] < $b["customerName"] ? -1 : 1;
                    });
                    break;
                case '伝票番号':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a["sales_voucher_no"] > $b["sales_voucher_no"] ? -1 : 1;
                        }
                        return $a["sales_voucher_no"] < $b["sales_voucher_no"] ? -1 : 1;
                    });
                    break;
                case '商品コード':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a["product_code"] > $b["product_code"] ? -1 : 1;
                        }
                        return $a["product_code"] < $b["product_code"] ? -1 : 1;
                    });
                    break;
                case '状態':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a["stateName"] > $b["stateName"] ? -1 : 1;
                        }
                        return $a["stateName"] < $b["stateName"] ? -1 : 1;
                    });
                    break;
            }
        }
        return $orders;
    }

    /**
     * CSVの出力.
     *
     * @Route("/%eccube_admin_route%/sales_management/detail/export", name="admin_salesVoucherDetail_export")
     *
     * @param Request $request Request
     *
     * @return StreamedResponse
     */
    public function export(Request $request)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        // sql loggerを無効にする.
        $em = $this->entityManager;
        $em->getConfiguration()->setSQLLogger(null);

        $response = new StreamedResponse();
        $response->setCallback(function () use ($request) {
            // CSV種別を元に初期化.
            $this->csvExportService->initCsvType(CsvType::CSV_TYPE_SALESDETAIL);

            // ヘッダ行の出力.
            $this->csvExportService->exportHeader();

            $qb = $this->getSalesDetailQueryBuilder($request);

            //粗利益、利益率
            $crude = 0;
            $rate = 0;
            $i = 0;
            foreach ($qb as $export) {
                // 202/01/18 CNC BEF START --仕入明細、商品コード、状態、価格で集計
//                if ($qb[$i]['exportAddressId'] !== null) {
//                    //税金区分
//                    $taxRateCategory = $qb[$i]['taxRateCategoryId'];
//                    $tax = $this->taxCodeRepository->find($taxRateCategory);
//                    $tax_rate = $tax->getTaxRate();
//                    $crude = $export['sales_price'] - ($export['averageUnitPrice'] / (1 + $tax_rate / 100));
//                    if (isset($export['sales_price']) && $export['sales_price'] != 0) {
//                        $rate = ($crude / $export['sales_price']) * 100;
//                    }
//                    $export['crude'] = round($crude * $export['quantity']);
//                    $export['rate'] = round($rate, 1);
//                    $qb[$i] = $export;
//                    $i++;
//                } else {
//                    $crude = $export['sales_price'] - $export['averageUnitPrice'];
//                    if (isset($export['sales_price']) && $export['sales_price'] != 0) {
//                        $rate = ($crude / $export['sales_price']) * 100;
//                    }
//                    $export['crude'] = round($crude * $export['quantity']);
//                    $export['rate'] = round($rate, 1);
//                    $qb[$i] = $export;
//                    $i++;
//                }
                // 202/01/18 CNC BEF END
                // 202/01/18 CNC AFT START --仕入明細、商品コード、状態、価格で集計
                if (!isset($export['grossProfit'])) {
                    if ($qb[$i]['exportAddressId'] !== null) {
                        //税金区分
                        $taxRateCategory = $qb[$i]['taxRateCategoryId'];
                        $tax = $this->taxCodeRepository->find($taxRateCategory);
                        $tax_rate = $tax->getTaxRate();
                        $crude = $export['sales_price'] - ($export['averageUnitPrice'] / (1 + $tax_rate / 100));
                        if (isset($export['sales_price']) && $export['sales_price'] != 0) {
                            $rate = ($crude / $export['sales_price']) * 100;
                        }
                        $export['crude'] = round($crude * $export['quantity']);
                        $export['rate'] = round($rate, 1);
                        $qb[$i] = $export;
                        $i++;
                    } else {
                        $crude = $export['sales_price'] - $export['averageUnitPrice'];
                        if (isset($export['sales_price']) && $export['sales_price'] != 0) {
                            $rate = ($crude / $export['sales_price']) * 100;
                        }
                        $export['crude'] = round($crude * $export['quantity']);
                        $export['rate'] = round($rate, 1);
                        $qb[$i] = $export;
                        $i++;
                    }
                } else {
                    $crude = $export['grossProfit'];
                    if (isset($export['total_sales_amount']) && $export['total_sales_amount'] != 0) {
                        $rate = ($crude / $export['total_sales_amount']) * 100;
                    }
                    $export['crude'] = round($crude);
                    $export['rate'] = round($rate, 1);
                    $qb[$i] = $export;
                    $i++;
                }
                // 202/01/18 CNC AFT END
            }

            // データ行の出力.
            $this->csvExportService->setExportDetailQueryBuilder($qb);

            $this->csvExportService->exportDataArrayCsv(function ($entity, csvExportService $csvService) use ($request) {
                $Csvs = $csvService->getCsvs();

                $SalesVoucherDetailCSV = new \Eccube\Entity\SalesVoucherDetailCSV();
                $SalesVoucherDetailCSV->setSalesDate(substr($this->makeDateStringUtcToAsiaTokyo($entity['sales_date']),0,10));
                $SalesVoucherDetailCSV->setCustomerCode($entity['customer_code']);
                $SalesVoucherDetailCSV->setCustomerId($entity['customerId']);
                $SalesVoucherDetailCSV->setCustomerName($entity['customerName']);
                $SalesVoucherDetailCSV->setSalesVoucherNo($entity['sales_voucher_no']);
                $SalesVoucherDetailCSV->setProductCode($entity['product_code']);
                $SalesVoucherDetailCSV->setProductName($entity['productName']);
                $SalesVoucherDetailCSV->setStateName($entity['stateName']);
                $SalesVoucherDetailCSV->setSerialNo($entity['serial_no']);
                $SalesVoucherDetailCSV->setQuantity($entity['quantity']);
                $SalesVoucherDetailCSV->setSalesPriceExtax($entity['sales_price_extax']);
                $SalesVoucherDetailCSV->setSalesPrice($entity['sales_price']);
                $SalesVoucherDetailCSV->setTotalSalesAmount($entity['total_sales_amount']);
                $SalesVoucherDetailCSV->setPersonnelMemoId($entity['personnelMemoId']);
                $SalesVoucherDetailCSV->setPersonnelName($entity['personnelName']);
                $SalesVoucherDetailCSV->setPlace($entity['place']);
                $SalesVoucherDetailCSV->setUpdateUserName($entity['update_user_name']);
                $SalesVoucherDetailCSV->setCrude($entity['crude']);
                $SalesVoucherDetailCSV->setRate($entity['rate']/100);
                $SalesVoucherDetailCSV->setAverageUnitPrice(is_null($entity['averageUnitPrice']) ? 0 : $entity['averageUnitPrice']);
                $SalesVoucherDetailCSV->setCategoryId1($entity['category_id1']);
                $SalesVoucherDetailCSV->setCategoryName1($entity['categoryName1']);
                $SalesVoucherDetailCSV->setCategoryId2($entity['category_id2']);
                $SalesVoucherDetailCSV->setCategoryName2($entity['categoryName2']);
                $SalesVoucherDetailCSV->setCategoryId3($entity['category_id3']);
                $SalesVoucherDetailCSV->setCategoryName3($entity['categoryName3']);

                $ExportCsvRow = new \Eccube\Entity\ExportCsvRow();

                // CSV出力項目と合致するデータを取得.
                foreach ($Csvs as $Csv) {
                    $ExportCsvRow->setData($csvService->getData($Csv, $SalesVoucherDetailCSV));
                    $event = new EventArgs(
                        [
                            'csvService' => $csvService,
                            'Csv' => $Csv,
                            'SalesVoucherHeader' => $entity,
                            'ExportCsvRow' => $ExportCsvRow,
                        ],
                        $request
                    );
                    $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_CUSTOMER_CSV_EXPORT, $event);

                    $ExportCsvRow->pushData();
                }
                // 出力.
                $csvService->fputcsv($ExportCsvRow->getRow());
            });
        });

        $now = new \DateTime();
        $filename = 'salesDetail_'.$now->format('YmdHis').'.csv';
        $response->headers->set('Content-Type', 'application/octet-stream');
        $response->headers->set('Content-Disposition', 'attachment; filename='.$filename);
        $response->send();

        log_info('売上伝票明細CSV出力ファイル名', [$filename]);

        return $response;
    }
    /**
     * 売上伝票明細検索用のクエリビルダを返す.
     *
     * @param Request $request
     *
     * @return \Doctrine\ORM\QueryBuilder
     */
    public function getSalesDetailQueryBuilder(Request $request)
    {
        $session = $request->getSession();

        $builder = $this->formFactory
            ->createBuilder(SalesVoucherItemType ::class);

        $searchForm = $builder->getForm();

        $viewData = $session->get('eccube.admin.sales_detail.search', []);
        $searchData = FormUtil::submitAndGetData($searchForm, $viewData);

        // 202/01/18 CNC BEF START --仕入明細、商品コード、状態、価格で集計
//        $qb = $this->getSearchData($searchData);
        // 202/01/18 CNC BEF END
        // 202/01/18 CNC AFT START --仕入明細、商品コード、状態、価格で集計
        if ($searchData['total_mode']) {
            $qb = $this->getSearchTotalData($searchData);
        } else {
            $qb = $this->getSearchData($searchData);
        }
        // 202/01/18 CNC AFT END

        return $qb;
    }

    /**
     * 得意先情報を検索する.
     *
     * @Route("/%eccube_admin_route%/sales_management/html", name="admin_master_search_customermst_html")
     * @Route("/%eccube_admin_route%/sales_management/page/{page_no}", requirements={"page_No" = "\d+"}, name="admin_master_search_customermst_html_page")
     * @Template("@admin/SalesVoucher/search_customer_list.twig")
     * @param Request $request
     * @param integer $page_no
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchCustomerMstHtml(Request $request, $page_no = null, Paginator $paginator)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('search customermst start.');
            $page_count = $this->eccubeConfig['eccube_default_page_count'];
            $session = $this->session;

            if ('POST' === $request->getMethod()) {
                $page_no = 1;
                $searchData = [
                    'customerName' => $request->get('customerName'),
                    'kana' => $request->get('kana'),
                    'customerCode' => $request->get('customerCode'),
                    'phoneNumber' => $request->get('phoneNumber'),
                    'customerAsName' => $request->get('customerAsName'),
                ];

                $session->set('eccube.master.customermst.search', $searchData);
                $session->set('eccube.master.customermst.search.page_no', $page_no);
            } else {
                $searchData = (array) $session->get('eccube.admin.master.customermst.search');
                if (is_null($page_no)) {
                    $page_no = intval($session->get('eccube.admin.master.customermst.search.page_no'));
                } else {
                    $session->set('eccube.admin.master.customermst.search.page_no', $page_no);
                }
            }

            $qb = $this->customerMstRepository->getQueryBuilderBySearchData($searchData);

            $event = new EventArgs(
                [
                    'qb' => $qb,
                    'data' => $searchData,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_MANAGEMENT_SALES_VOUCHER_DETAIL_SEARCH_SALES_SEARCH, $event);

            /** @var \Knp\Component\Pager\Pagination\SlidingPagination $pagination */
            $pagination = $paginator->paginate(
                $qb,
                $page_no,
                $page_count,
                ['wrap-queries' => true]
            );

            /** @var $CustomerMsts \Eccube\Entity\CustomerMst[] */
            $CustomerMsts = $pagination->getItems();

            if (empty($CustomerMsts)) {
                log_debug('search customermst not found.');
            }

            $data = [];
            foreach ($CustomerMsts as $CustomerMst) {
                $data[] = [
                    'id' => $CustomerMst->getId(),
                    'customerCode' => $CustomerMst->getCustomerCode(),
                    'customerName' => $CustomerMst->getCustomerName(),
                    'customerAsName' => $CustomerMst->getCustomerAsName()
                ];
            }

            $event = new EventArgs(
                [
                    'data' => $data,
                    'CustomerMsts' => $pagination,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_MANAGEMENT_SALES_VOUCHER_DETAIL_SEARCH_SALES_COMPLETE, $event);
            $data = $event->getArgument('data');

            return [
                'data' => $data,
                'pagination' => $pagination,
            ];
        }
    }

    /**
     *  得意先情報をセットする.
     *
     * @Route("/%eccube_admin_route%/sales_management/search/master/id", name="admin_master_search_customer_mst_by_id", methods={"POST"})
     *
     * @param Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchCustomerMstById(Request $request)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('search customermst by id start.');

            /** @var $CustomerMst \Eccube\Entity\$CustomerMst */
            $CustomerMst = $this->customerMstRepository
                ->find($request->get('id'));

            $event = new EventArgs(
                [
                    'CustomerMst' => $CustomerMst,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_MANAGEMENT_SALES_VOUCHER_DETAIL_SEARCH_SALES_BY_ID_INITIALIZE, $event);

            if (is_null($CustomerMst)) {
                log_debug('search customermst by id not found.');

                return $this->json([], 404);
            }

            log_debug('search customermst by id found.');

            $data = [
                'id' => $CustomerMst->getId(),
                'customerName' => $CustomerMst->getCustomerName(),
            ];

            $event = new EventArgs(
                [
                    'data' => $data,
                    'CustomerMst' => $CustomerMst,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_MANAGEMENT_SALES_VOUCHER_DETAIL_SEARCH_SALES_BY_ID_COMPLETE, $event);
            $data = $event->getArgument('data');
            return $this->json($data);
        }
    }
    /**
     * Update to payAmount number.
     *
     * @Route("/%eccube_admin_route%/sales_management/sales_voucher_detail/{id}/return_quantity", requirements={"id" = "\d+"}, name="admin_sales_return_quantity_save",methods={"PUT"})
     *
     * @param Request $request Request
     * @param $id
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function save(Request $request, $id)
    {
        /** @var SalesVoucherDetail $returnQuantity */
        $returnQuantity = $this->salesVoucherDetailRepository->find($id);
        /** @var SalesVoucherHeader $returnsPrice */
        $returnsPrice = $this->salesVoucherHeaderRepository
            ->findOneBy(['sales_voucher_no' => $returnQuantity->getSalesVoucherNo()]);
        /** @var StockListProductUnit $stockQuantity */
        $stockQuantity = $this->stockListProductUnitRepository
            ->findOneBy(['productId' => $returnQuantity->getProductId(), 'State' => $returnQuantity->getState()]);
        if (empty($returnQuantity->getSerialNo())) {
            $stockQuantityStorehouse = $this->stockListStorehouseUnitRepository
                ->findOneBy(['productId' => $returnQuantity->getProductId(), 'State' => $returnQuantity->getState(), 'Storehouse' => $returnQuantity->getPlace()], ['updateDate' => 'DESC']);
        } else {
            $stockQuantityStorehouse = $this->stockListStorehouseUnitRepository
                ->findOneBy(['serialNo' => $returnQuantity->getSerialNo(), 'productId' => $returnQuantity->getProductId(), 'State' => $returnQuantity->getState(), 'Storehouse' => $returnQuantity->getPlace()], ['updateDate' => 'DESC']);
        }

        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
        }

        try {
            $return_quantity = 0;
            if ($request->get('return_quantity')) {
                $return_quantity = str_replace(',', '', $request->get('return_quantity'));
            }
            $quantity = $returnQuantity->getQuantity() - $return_quantity;
            $total_sales_amount = $quantity * $returnQuantity->getSalesPrice();

            if ($quantity === 0) {
                $this->salesVoucherDetailRepository->delete($returnQuantity);

                // 明細紐付
                $parameter_detail_link_by_sales = [
                    'SalesVoucherHeader' => $returnQuantity->getSalesVoucherHeader(),
                    'salesVoucherNo' => $returnQuantity->getSalesVoucherNo(),
                    'salesDetailsNo' => $returnQuantity->getSalesDetailsNo(),
                ];
                $collection_sales_detail_link = $this->salesVoucherDetailLinkRepository
                    ->findBy($parameter_detail_link_by_sales);

                // 関連売上伝票明細紐付削除
                foreach ($collection_sales_detail_link as $detail_link) {
                    $this->entityManager->remove($detail_link);
                }
            } else {
                //数量
                $returnQuantity->setQuantity($quantity);
                $returnQuantity->setTotalSalesAmount($total_sales_amount);
            }

            //返品金額
            $returns_price = $returnsPrice->getReturnsPrice() + ($return_quantity * $returnQuantity->getSalesPrice());
            $returnsPrice->setReturnsPrice($returns_price);
            $returnsPrice->setSalesMoneyTotalAmount($returnsPrice->getSalesMoneyTotalAmount() - ($return_quantity * $returnQuantity->getSalesPrice()));
            $returnsPrice->setUpdateUserName($this->getUser()['name']);

            //在庫数量、残在庫数量（商品単位）
            $stock_quantity = $stockQuantity->getStockQuantity() + $return_quantity;
            $remaining_stock_quantity = $stockQuantity->getRemainingStockQuantity() + $return_quantity;
            $stockQuantity->setStockQuantity($stock_quantity);
            $stockQuantity->setRemainingStockQuantity($remaining_stock_quantity);
            $stockQuantity->setUpdateUserName($this->getUser()['name']);
            $this->entityManager->persist($stockQuantity);
            $this->entityManager->flush($stockQuantity);
            $returnQuantity->setAveragePrice($stockQuantity->getAverageUnitPrice());
            //在庫数量（置場単位）
            if (!empty($stockQuantityStorehouse)) {
                $stock_quantity_storehouse = $stockQuantityStorehouse->getStockQuantity() + $return_quantity;
                $stockQuantityStorehouse->setStockQuantity($stock_quantity_storehouse);
                $stockQuantityStorehouse->setUpdateUserName($this->getUser()['name']);
            } else {
                $stockQuantityStorehouse = (new StockListStorehouseUnit())
                    ->setProductId($returnQuantity->getProductId())
                    ->setProductClass($returnQuantity->getProductClass())
                    ->setProductCode($returnQuantity->getProductCode())
                    ->setSerialNo($returnQuantity->getSerialNo())
                    ->setState($returnQuantity->getState())
                    ->setStorehouse($returnQuantity->getPlace())
                    ->setStockQuantity($return_quantity)
                    ->setCreateUserName($this->getUser()['name'])
                    ->setUpdateUserName($this->getUser()['name'])
                ;
            }
            $this->entityManager->persist($stockQuantityStorehouse);
            $this->entityManager->flush($stockQuantityStorehouse);
            //売上伝票返品履歴(dtb_sales_voucher_returns_history)
            $salesVoucherReturnsHistoryOld = $this->salesVoucherReturnsHistoryRepository
                ->findOneBy(['salesVoucherNo' => $returnQuantity->getSalesVoucherNo(), 'salesDetailsNo' => $returnQuantity->getSalesDetailsNo()], ['revisionNo' => 'DESC']);
            $salesVoucherReturnsHistory = new SalesVoucherReturnsHistory();
            $salesVoucherReturnsHistory->setSalesVoucherNo($returnQuantity->getSalesVoucherNo());
            $salesVoucherReturnsHistory->setSalesDetailsNo($returnQuantity->getSalesDetailsNo());
            $salesVoucherReturnsHistory->setProductId($returnQuantity->getProductId());
            $salesVoucherReturnsHistory->setProductCode($returnQuantity->getProductCode());
            $salesVoucherReturnsHistory->setSerialNo($returnQuantity->getSerialNo());
            $salesVoucherReturnsHistory->setSalesPriceExtax($returnQuantity->getSalesPriceExtax());
            $salesVoucherReturnsHistory->setSalesPrice($returnQuantity->getSalesPrice());
            $salesVoucherReturnsHistory->setQuantity($returnQuantity->getQuantity());
            $salesVoucherReturnsHistory->setTotalSalesAmount($returnQuantity->getTotalSalesAmount());
            $salesVoucherReturnsHistory->setReturnsPrice($returnQuantity->getSalesPrice());
            $salesVoucherReturnsHistory->setReturnsQuantity($return_quantity);
            $salesVoucherReturnsHistory->setTotalReturnsAmount($returns_price);
            if ($salesVoucherReturnsHistoryOld == null) {
                $salesVoucherReturnsHistory->setRevisionNo(0);
            } else {
                $salesVoucherReturnsHistory->setRevisionNo($salesVoucherReturnsHistoryOld->getRevisionNo() + 1);
            }
            $salesVoucherReturnsHistory->setCreateUserName($this->getUser()['name']);
            $salesVoucherReturnsHistory->setUpdateUserName($this->getUser()['name']);
            $salesVoucherReturnsHistory->setSalesVoucherHeader($returnQuantity->getSalesVoucherHeader());
            $salesVoucherReturnsHistory->setStorehouse($returnQuantity->getPlace());
            $salesVoucherReturnsHistory->setState($returnQuantity->getState());
            $salesVoucherReturnsHistory->setProductClass($returnQuantity->getProductClass());

            if ($quantity !== 0) {
                $this->entityManager->persist($returnQuantity);
                $returnsPrice->addSalesVoucherDetail($returnQuantity);
            }
            $this->entityManager->persist($returnsPrice);
//            $this->entityManager->persist($stockQuantity);
            LogControllable::print_log(__FILE__, '########## Insert/update: stock list by product', [$stockQuantity->toArray()]);
//            $this->entityManager->persist($stockQuantityStorehouse);
            LogControllable::print_log(__FILE__, '########## Insert/update: stock list by storehouse', [$stockQuantityStorehouse->toArray()]);
            $this->entityManager->persist($salesVoucherReturnsHistory);
            $this->entityManager->flush();

            // 履歴（ヘッダ―）
            $sales_voucher_history = $this->salesVoucherHeaderHistoryRepository
                ->createSalesVoucherHeaderHistoryByHeader($returnsPrice, SalesVoucherHeaderHistory::BEHAVIOR_CHANGE);
            $this->entityManager->persist($sales_voucher_history);
            $this->entityManager->flush();

            $message = ['status' => 'OK'];
            return $this->json($message);
        } catch (\Exception $e) {
            log_error('予期しないエラー', [$e->getMessage()]);
            return $this->json(['status' => 'NG', 'error' => $e->getMessage()], 500);
        }
    }

    /**
     * UTC時間を東京時間にする
     * @param string|null $date 時間文字列(yyyy-mm-dd HH:ii:ss)
     * @return string
     */
    public function makeDateStringUtcToAsiaTokyo(string $date = null)
    {
        if (!$date || $date !== date('Y-m-d H:i:s', strtotime($date))) {
            return '';
        }

        try {
            $date_utc = new \DateTime($date, new \DateTimeZone('UTC'));
            $date_asia_tokyo = $date_utc
                ->setTimezone(new \DateTimeZone('Asia/Tokyo'))
                ->format('Y-m-d H:i:s');
        } catch (\Exception $exception) {
            return '';
        }

        return $date_asia_tokyo;
    }

    // 2022/01/18 CNC ADD START --仕入明細、商品コード、状態、価格で集計
    /**
     * 仕入伝票集計表示.
     *
     * @param $searchData
     *
     * @return null|result
     */
    public function getSearchTotalData($searchData)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();
        $sql = '
                SELECT
                    \'\' AS id,
                    \'\' AS sales_date,
                    \'\' AS customer_code,
                    \'\' AS customerId,
                    \'\' AS customerName,
                    \'\' AS sales_voucher_no,
                    dc4.category_id AS category_id1,
                    dc4.categoryName AS categoryName1,
                    dc5.category_id AS category_id2,
                    dc5.categoryName as categoryName2,
                    dc6.category_id AS category_id3,
                    dc6.categoryName as categoryName3,
                    dsvd.product_code,
                    dp.name AS productName,
                    ms.state AS stateName,
                    \'\' AS serial_no,
                    SUM(dsvd.quantity) AS quantity,
                    dsvd.sales_price_extax,
                    dsvd.sales_price,
                    SUM(dsvd.total_sales_amount) AS total_sales_amount,
                    \'\' AS personnelMemoId,
                    \'\' AS personnelName,
                    \'\' AS place,
                    \'\' AS update_user_name,
                    \'\' AS update_date,
                    \'\' AS stockQuantity,
                    round(AVG(dsvd.average_unit_price)) AS averageUnitPrice,
                    dsvh.export_Address_id AS exportAddressId,
                    dsvh.tax_rate_category_id AS taxRateCategoryId,
                    SUM(gp.grossProfit) AS grossProfit,
                    dsvd.sales_voucher_header_id AS sales_voucher_header_id,
                    dsvd.create_date
                FROM
                    dtb_sales_voucher_detail dsvd
                INNER JOIN dtb_sales_voucher_header dsvh
                    ON dsvd.sales_voucher_header_id = dsvh.id
                INNER JOIN mtb_customer_mst mcm
                    ON mcm.id=dsvh.customer_id
                INNER JOIN dtb_product dp
                    ON dp.id=dsvd.product_id
                INNER JOIN mtb_state ms
                    ON ms.id=dsvd.state_id
                INNER JOIN mtb_place mp
                    ON mp.id=dsvd.storehouse_id
                INNER JOIN dtb_member dm
                    ON dm.id=dsvh.personnel_id
                LEFT JOIN (
                    SELECT
                        dsvd2.id,
                        CASE WHEN dsvh2.export_Address_id IS NULL
                            THEN (sales_price - average_unit_price) * quantity
                            ELSE round((sales_price - average_unit_price / (1 + mtc.tax_rate / 100)) * quantity)
                        END AS grossProfit
                    FROM
                        dtb_sales_voucher_detail dsvd2
                        INNER JOIN dtb_sales_voucher_header dsvh2
                            ON dsvd2.sales_voucher_header_id = dsvh2.id
                        LEFT JOIN mtb_tax_code mtc
                            ON mtc.id = dsvh2.tax_rate_category_id
                ) AS gp
                ON gp.id = dsvd.id
                LEFT JOIN dtb_stock_list_product_unit dslpu
                    ON dsvd.product_id=dslpu.product_id
                    AND dsvd.state_id = dslpu.state_id
                    AND dsvd.product_code = dslpu.product_code
                INNER JOIN (
                    SELECT
                        dsvds.id,
                        dpcs.category_id,
                        dcs.category_name AS categoryName,
                        dcs.hierarchy
                    FROM
                        dtb_sales_voucher_detail dsvds
                        INNER JOIN dtb_product dps
                            ON dsvds.product_id = dps.id
                        INNER JOIN dtb_product_category dpcs
                            ON dsvds.product_id = dpcs.product_id
                        INNER JOIN dtb_category dcs
                            ON dcs.id = dpcs.category_id
                         WHERE dpcs.category_sub_flag <>1
                ) AS dc4
                    ON dc4.id = dsvd.id
                    AND dc4.hierarchy = 1
                LEFT JOIN (
                    SELECT
                        dsvds.id,
                        dpcs.category_id,
                        dcs.category_name AS categoryName,
                        dcs.hierarchy
                    FROM
                        dtb_sales_voucher_detail dsvds
                        INNER JOIN dtb_product dps
                            ON dsvds.product_id = dps.id
                        INNER JOIN dtb_product_category dpcs
                            ON dsvds.product_id = dpcs.product_id
                        INNER JOIN dtb_category dcs
                            ON dcs.id = dpcs.category_id
                         WHERE dpcs.category_sub_flag <>1
                ) AS dc5
                    ON dc5.id = dsvd.id
                    AND dc5.hierarchy = 2
                LEFT JOIN (
                    SELECT
                        dsvds.id,
                        dpcs.category_id,
                        dcs.category_name AS categoryName,
                        dcs.hierarchy
                    FROM
                        dtb_sales_voucher_detail dsvds
                        INNER JOIN dtb_product dps
                            ON dsvds.product_id = dps.id
                        INNER JOIN dtb_product_category dpcs
                            ON dsvds.product_id = dpcs.product_id
                        INNER JOIN dtb_category dcs
                            ON dcs.id = dpcs.category_id
                         WHERE dpcs.category_sub_flag <>1
                ) AS dc6
                    ON dc6.id = dsvd.id
                    AND dc6.hierarchy = 3
                WHERE TRUE
            ';

        //product_code
        if (isset($searchData['product_code']) && StringUtil::isNotBlank($searchData['product_code'])) {
            $sql = $sql.' AND  dsvd.product_code LIKE '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['product_code']))."%'";
            $flg = true;
        }

        //place
        if (isset($searchData['Place']) && StringUtil::isNotBlank($searchData['Place'])) {
            $sql = $sql.' AND mp.id='."'".$searchData['Place']->getId()."'";
        }

        //product_name
        if (isset($searchData['product_name']) && StringUtil::isNotBlank($searchData['product_name'])) {
            $sql = $sql.' AND  dp.name LIKE '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['product_name']))."%'";
        }

        //personnel_memo
        if (isset($searchData['personnel_memo']) && StringUtil::isNotBlank($searchData['personnel_memo'])) {
            $sql = $sql.' AND   dm.id = '.$searchData['personnelMemoId'];
        }

        //customerName
        if (isset($searchData['customerName']) && StringUtil::isNotBlank($searchData['customerName'])) {
            $sql = $sql.' AND  mcm.id = '.$searchData['customerId'];
        }

        //sales_date_start
        if (isset($searchData['sales_date_start']) && StringUtil::isNotBlank($searchData['sales_date_start'])) {
            /** @var \DateTime $sales_date_start */
            $sales_date_start = $searchData['sales_date_start'];
            $salesDateStart = $sales_date_start->setTime('0', '0', '0')
                ->setTimezone(new \DateTimeZone('UTC'))
                ->format('Y-m-d H:i:s');
            $sql = $sql.' AND  dsvh.sales_date >= \''.$salesDateStart .'\'';
        }

        //sales_date_end
        if (isset($searchData['sales_date_end']) && StringUtil::isNotBlank($searchData['sales_date_end'])) {
            /** @var \DateTime $sales_date_end */
            $sales_date_end = $searchData['sales_date_end'];
            $salesDateEnd = $sales_date_end->setTime('23', '59', '59')
                ->setTimezone(new \DateTimeZone('UTC'))
                ->format('Y-m-d H:i:s');
            $sql = $sql . ' AND  dsvh.sales_date <= \'' .$salesDateEnd  . '\'';
        }

        // mainCategory
        if (isset($searchData['main_category_id']) && !empty($searchData['main_category_id']) && $searchData['main_category_id']) {
            $Category = $searchData['main_category_id'];
            $category_id = 'category_id_'.$Category->getId();
            if (isset($searchData[$category_id]) && !empty($searchData[$category_id]) && $searchData[$category_id]) {
                $Categories = $searchData[$category_id]->getSelfAndDescendants();
            } else {
                $Categories = $Category->getSelfAndDescendants();
            }
            if ($Categories) {
                $sql = $sql.'AND dc4.category_id='."'".$searchData['main_category_id']['id']."'";
                if ($searchData[$category_id]) {
                    if ($searchData[$category_id]['hierarchy'] == '2') {
                        $sql = $sql.'AND  dc5.category_id='."'".$searchData[$category_id]['id']."'";
                    } else {
                        $sql = $sql.'AND  dc6.category_id='."'".$searchData[$category_id]['id']."'";
                    }
                }
            }
        }

        $sql = $sql.'
        GROUP BY
        dsvd.product_code
        ,dsvd.state_id
        ,dsvd.sales_price_extax
        ,dsvd.sales_price
        ORDER BY
        dsvd.update_date DESC
        ,dsvh.sales_date
        ,mcm.customer_name
        ,dsvd.sales_voucher_no
        ,dsvd.sales_details_no
        ';

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }
    // 2022/01/18 CNC ADD END
}
