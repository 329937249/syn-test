<?php


namespace Eccube\Controller\Admin\SalesVoucher;

use Eccube\Controller\Admin\AbstractCsvImportController;
use Eccube\Entity\Member;
use Eccube\Entity\Product;
use Eccube\Entity\State;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\PlaceRepository;
use Eccube\Repository\ProductCategoryRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\StateRepository;
use Eccube\Repository\StockListStorehouseUnitRepository;
use Eccube\Util\CacheUtil;
use Eccube\Util\StringUtil;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class SalesCsvImportController extends AbstractCsvImportController
{
    /**
     * @var ProductRepository
     */
    private $productRepository;

    /**
     * @var StateRepository
     */
    private $stateRepository;

    /**
     * @var PlaceRepository
     */
    private $placeRepository;

    /**
     * @var ProductClassRepository
     */
    private $productClassRepository;

    /**
     * @var ProductCategoryRepository
     */
    private $productCategoryRepository;

    /**
     * @var StockListStorehouseUnitRepository
     */
    private $stockListStorehouseUnitRepository;

    private $errors = [];

    public function __construct(
        ProductRepository $productRepository,
        StateRepository $stateRepository,
        PlaceRepository $placeRepository,
        ProductClassRepository $productClassRepository,
        ProductCategoryRepository $productCategoryRepository,
        StockListStorehouseUnitRepository $stockListStorehouseUnitRepository
    ) {
        $this->productRepository = $productRepository;
        $this->stateRepository = $stateRepository;
        $this->placeRepository = $placeRepository;
        $this->productClassRepository = $productClassRepository;
        $this->productCategoryRepository = $productCategoryRepository;
        $this->stockListStorehouseUnitRepository = $stockListStorehouseUnitRepository;
    }

    /**
     * 売上伝票CSVインポート
     *
     * @Route("/%eccube_admin_route%/sales_voucher/sales_voucher_csv_upload", name="admin_sales_voucher_csv_import")
     * @param Request $request Request
     * @param CacheUtil $cache_util CacheUtil
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     * @throws \Doctrine\DBAL\ConnectionException
     */
    public function csvSalesVoucher(Request $request, CacheUtil $cache_util)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('csv import start.');
            /** @var UploadedFile $uploaded_file */
            $uploaded_file = $request->files->get('admin_csv_import')['import_file'];
            $error = 0;
            if (!empty($uploaded_file)) {
                log_info('売上伝票CSV登録開始');
                $headers = $this->getSalesVoucherCsvHeader();
                $data = $this->getImportData($uploaded_file);
                if ($data === false) {
                    $this->addErrors(trans('admin.common.csv_invalid_format'));
                    return $this->renderWithError();
                }

                $data->rewind();

                $getProductCode = function ($item) {
                    return $item['id'];
                };
                $requireHeader = array_keys(array_map($getProductCode, array_filter($headers, function ($value) {
                    return $value['required'];
                })));

                $columnHeaders = $data->getColumnHeaders();

                if (count(array_diff($requireHeader, $columnHeaders)) > 0) {
                    $this->addErrors(trans('admin.common.csv_invalid_format'));

                    return $this->renderWithError();
                }

                $size = count($data);

                if ($size < 1) {
                    $this->addErrors(trans('admin.common.csv_invalid_no_data'));

                    return $this->renderWithError();
                }

                $headerByKey = array_flip(array_map($getProductCode, $headers));
                $grid_data = [];

                // CSVファイルの登録処理
                foreach ($data as $line => $row) {
                    if (count($headers) != count($row)) {
                        $message = trans('admin.common.csv_invalid_format_line', ['%line%' => $line + 1]);
                        $this->addErrors($message);
                        $error++;
                        continue;
                    }
                    if (!isset($row[$headerByKey['product_code']]) || StringUtil::isBlank($row[$headerByKey['product_code']])) {
                        $message = trans('admin.common.csv_invalid_required', ['%line%' => $line + 1, '%name%' => '商品コード']);
                        $this->addErrors($message);
                        $error++;
                        continue;
                    }
                    $array_entity_product = $this->productRepository->findProductsWithProductCode($row[$headerByKey['product_code']]);
                    if (count($array_entity_product) <= 0) {
                        $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line + 1, '%name%' => '商品']);
                        $this->addErrors($message);
                        $error++;
                        continue;
                    }
                    /** @var Product $Product */
                    /** @var State $state */
                    $Product = $array_entity_product[0][0];
                    if (!$Product) {
                        $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line + 1, '%name%' => '商品']);
                        $this->addErrors($message);
                        $error++;
                        continue;
                    }
                    $state = $this->stateRepository->find($row[$headerByKey['status']]);
                    if(!$state){
                        $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line + 1, '%name%' => '状態']);
                        $this->addErrors($message);
                        $error++;
                        continue;
                    }else{
                        $sameFalg = false;
                        foreach ($array_entity_product as $entity_product){
                            if($entity_product['category_id']  == $state->getCategoryId()){
                                $sameFalg = true;
                            }
                        }
                        if(!$sameFalg){
                            $message = trans('admin.common.csv_invalid_category_id', ['%line%' => $line + 1]);
                            $this->addErrors($message);
                            $error++;
                            continue;
                        }
                    }
                    $place = $row[$headerByKey['place']];
                    if(!empty($place)){
                        $place = $this->placeRepository->find($row[$headerByKey['place']]);
                        if(!$place){
                            $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line + 1, '%name%' => '置場']);
                            $this->addErrors($message);
                            $error++;
                            continue;
                        }
                        $place = $place ->getId();
                    }else{
                        /** @var Member $member */
                        $member = $this->getUser();
                        if($member->isSalesVisableFlg() && !empty($member->getSalesPlace())){
                            $place = $member->getSalesPlace()->getId();
                        }
                    }
                    if($Product->getSerialFlg() && $row[$headerByKey['serial_no']] == ""){
                        $message = trans('admin.common.csv_invalid_required', ['%line%' => $line + 1, '%name%' => 'シリアル番号']);
                        $this->addErrors($message);
                        $error++;
                        continue;
                    }
                    if(!empty($row[$headerByKey['serial_no']])){
                        $array_sales_product = $this->stockListStorehouseUnitRepository->findProductsSerialWithProductCode($row[$headerByKey['product_code']], $row[$headerByKey['serial_no']]);
                    }else{
                        $array_sales_product = $this->productCategoryRepository->findProductsDetailsWithProductCode($row[$headerByKey['product_code']]);
                    }

                    if(!empty($row[$headerByKey['sales_price']]) && !empty($array_sales_product) && !empty($array_sales_product[0])){
                        $benefit = ($row[$headerByKey['sales_price']] - $array_sales_product[0]['averageUnitPrice']) * $row[$headerByKey['quantity']];
                        //利益率
                        $benefitRate = round(($row[$headerByKey['sales_price']] - $array_sales_product[0]['averageUnitPrice']) / $row[$headerByKey['sales_price']] *100,1).'%';
                        $averageUnitPrice = number_format((float)str_replace(',', '', $array_sales_product[0]['averageUnitPrice']));
                        $provisionalCount = $array_sales_product[0]['quantity'];
                    }else{
                        $benefit = $row[$headerByKey['sales_price']];
                        //利益率
                        $benefitRate = '0.0%';
                        $averageUnitPrice = 0;
                        $provisionalCount = 0;
                    }
                    $taxCode = null;
                    if(!empty($Product->getTaxCode())){
                        $taxCode = $Product->getTaxCode()->getId();
                    }

                    $grid_data[] = [
                        'id' => $Product->getId(),
                        'product_name' => $Product->getName(),
                        'serial_flg' => $Product->getSerialFlg(),
                        'product_code' => $row[$headerByKey['product_code']],
                        'category' => $array_entity_product[0]['category_id'],
                        'product_class' => $Product->getProductClasses()[0]->getId(),
                        'serial_no' => $row[$headerByKey['serial_no']],
                        'quantity' => $row[$headerByKey['quantity']],
                        'status' => $row[$headerByKey['status']],
                        'place' => $place,
                        'sales_price' => $row[$headerByKey['sales_price']],
                        'sales_price_extax' => $row[$headerByKey['sales_price_extax']],
                        'averagePrice' => $averageUnitPrice,
                        'provisionalCount' => $provisionalCount,
                        'benefit' => $benefit,
                        'benefitRate' => $benefitRate,
                        'tax_code' => $taxCode,
                    ];
                }

                $this->removeUploadedFile();
                if ($error > 0) {
                    return $this->json(['error' => $this->errors]);
                } else {
                    return $this->json(['data' => $grid_data]);
                }
            }
        }
    }

    /**
     * 売上伝票CSVヘッダー定義
     * @return array
     */
    protected function getSalesVoucherCsvHeader()
    {
        return [
            trans('admin.sales.voucher.csv_import.product_code_col') => [
                'id' => 'product_code',
                'description' => 'admin.sales.voucher.csv_import.product_code_description',
                'required' => true,
            ],
            trans('admin.sales.voucher.csv_import.serial_no_col') => [
                'id' => 'serial_no',
                'description' => 'admin.sales.voucher.csv_import.serial_no_description',
                'required' => false,
            ],
            trans('admin.sales.voucher.csv_import.quantity_col') => [
                'id' => 'quantity',
                'description' => 'admin.sales.voucher.csv_import.quantity_description',
                'required' => true,
            ],
            trans('admin.sales.voucher.csv_import.status_col') => [
                'id' => 'status',
                'description' => 'admin.sales.voucher.csv_import.status_description',
                'required' => true,
            ],
            trans('admin.sales.voucher.csv_import.place_col') => [
                'id' => 'place',
                'description' => 'admin.sales.voucher.csv_import.place_description',
                'required' => false,
            ],
            trans('admin.sales.voucher.csv_import.sales_price_col') => [
                'id' => 'sales_price',
                'description' => 'admin.sales.voucher.csv_import.sales_price_description',
                'required' => false,
            ],
            trans('admin.sales.voucher.csv_import.sales_price_extax_col') => [
                'id' => 'sales_price_extax',
                'description' => 'admin.sales.voucher.csv_import.sales_price_extax_description',
                'required' => false,
            ],
        ];
    }

    /**
     * 登録、更新時のエラー画面表示
     */
    protected function addErrors($message)
    {
        $this->errors[] = $message;
    }

    /**
     * 登録、更新時のエラー画面表示
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     *
     * @throws \Doctrine\DBAL\ConnectionException
     */
    protected function renderWithError()
    {
        $this->removeUploadedFile();

        return $this->json([
            'errors' => $this->errors,
        ]);
    }
}