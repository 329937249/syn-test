<?php


namespace Eccube\Controller\Admin\SalesVoucher;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\DBAL\Exception\ForeignKeyConstraintViolationException;
use Eccube\Common\Constant;
use Eccube\Controller\AbstractController;
use Eccube\Entity\CustomerMst;
use Eccube\Entity\Product;
use Eccube\Entity\Member;
use Eccube\Entity\ProvisionalShipmentVoucher;
use Eccube\Entity\ProvisionalShipmentVoucherHeader;
use Eccube\Entity\Payment;
use Eccube\Entity\StockListProductUnit;
use Eccube\Form\Type\Admin\CsvImportType;
use Eccube\Repository\StateRepository;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\SearchProductType;
use Eccube\Form\Type\AddCartType;
use Eccube\Form\Type\Admin\TempExStockEditType;
use Eccube\Form\Type\Admin\TempExStockEditSearchCustomerType;
use Eccube\Repository\TaxCodeRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\PaymentRepository;
use Eccube\Repository\TaxExporterRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\CustomerMstRepository;
use Eccube\Repository\ProvisionalShipmentVoucherRepository;
use Eccube\Repository\StockListProductUnitRepository;
use Eccube\Repository\ProvisionalShipmentVoucherHeaderRepository;
use Eccube\Repository\Master\SpecialAuthorityRepository;
use Eccube\Repository\SalesVoucherHeaderRepository;
use Eccube\Service\PurchaseFlow\Processor\VoucherNoProcessor;
use Eccube\Util\CacheUtil;
use Knp\Component\Pager\Paginator;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Routing\RouterInterface;

/**
 * プログラム名 ： TempExStockEditController.php
 * 概　　要     ： 仮出荷伝票登録画面タイプ
 * 作　　成     ： 2021/08/05 CNC
 */
class TempExStockEditController extends AbstractController
{
    const TEMPORARY_VOUCHER_NO = '0';

    // INS-START CNC 2022/03/21
    // 一覧画面URL
    const PREVIOUS_PAGE_URL_LIST = 'sales_management/temp_ex_stock_list';
    const BACK_TO_LIST_URL_STOCK = 'admin_temp_ex_stock_list';
    const BACK_TO_LIST_NAME_STOCK = 'admin.sales.temp_ex_stock_list';

    // 明細画面URL
    const PREVIOUS_PAGE_URL_DETAIL = 'sales_management/sales_temp_ex_stock_detail';
    const BACK_TO_DETAIL_URL_STOCK = 'admin_sales_temp_ex_stock_detail';
    const BACK_TO_DETAIL_NAME_STOCK = 'admin.sales.temp_ex_stock_detail';
    // INS-END CNC 2022/03/21

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var TaxCodeRepository
     */
    protected $taxCodeRepository;

    /**
     * @var PaymentRepository
     */
    protected $paymentRepository;

    /**
     * @var TaxExporterRepository
     */
    protected $taxExporterRepository;

    /**
     * @var ProvisionalShipmentVoucherRepository
     */
    protected $ProvisionalShipmentVoucherRepository;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var ProvisionalShipmentVoucherHeaderRepository
     */
    protected $provisionalShipmentVoucherHeaderRepository;

    /**
     * @var SpecialAuthorityRepository
     */
    protected $specialAuthorityRepository;

    /**
     * @var StockListProductUnitRepository
     */
    protected $stockListProductUnitRepository;

    /**
     * @var CustomerMstRepository
     */
    protected $customerMstRepository;

    /**
     * @var ProductClassRepository
     */
    protected $productClassRepository;

    /**
     * @var StateRepository
     */
    protected $stateRepository;

    /**
     * @var VoucherNoProcessor
     */
    protected $voucherNoProcessor;

    /**
     * @var SalesVoucherHeaderRepository
     */
    protected $salesVoucherHeaderRepository;

    /**
     * PayeeVoucherController constructor.
     * @param CategoryRepository $categoryRepository カテゴリ
     * @param TaxCodeRepository $taxCodeRepository 税区分マスタ
     * @param CustomerMstRepository $customerMstRepository 得意先
     * @param PaymentRepository $paymentRepository 支払方法
     * @param TaxExporterRepository $taxExporterRepository 税関輸出者マスタ
     * @param ProductRepository $productRepository 商品
     * @param VoucherNoProcessor $voucherNoProcessor 伝票番号作成
     * @param ProvisionalShipmentVoucherRepository $ProvisionalShipmentVoucherRepository 仮出荷伝票明細
     * @param ProvisionalShipmentVoucherHeaderRepository $provisionalShipmentVoucherHeaderRepository 仮出荷伝票ヘッダー
     * @param SpecialAuthorityRepository $specialAuthorityRepository 特殊権限
     * @param StateRepository $stateRepository 状態
     * @param ProductClassRepository $productClassRepository プロダクトクラス
     * @param StockListProductUnitRepository $stockListProductUnitRepository 在庫一覧（商品単位）
     * @param SalesVoucherHeaderRepository $salesVoucherHeaderRepository
     */
    public function __construct(
        CategoryRepository $categoryRepository,
        TaxCodeRepository $taxCodeRepository,
        CustomerMstRepository $customerMstRepository,
        PaymentRepository $paymentRepository,
        TaxExporterRepository $taxExporterRepository,
        ProductRepository $productRepository,
        ProvisionalShipmentVoucherRepository $ProvisionalShipmentVoucherRepository,
        ProvisionalShipmentVoucherHeaderRepository $provisionalShipmentVoucherHeaderRepository,
        SpecialAuthorityRepository $specialAuthorityRepository,
        StockListProductUnitRepository $stockListProductUnitRepository,
        ProductClassRepository $productClassRepository,
        StateRepository $stateRepository,
        SalesVoucherHeaderRepository $salesVoucherHeaderRepository,
        VoucherNoProcessor $voucherNoProcessor
    ) {
        $this->categoryRepository = $categoryRepository;
        $this->taxCodeRepository = $taxCodeRepository;
        $this->customerMstRepository = $customerMstRepository;
        $this->paymentRepository = $paymentRepository;
        $this->taxExporterRepository = $taxExporterRepository;
        $this->productRepository = $productRepository;
        $this->ProvisionalShipmentVoucherRepository = $ProvisionalShipmentVoucherRepository;
        $this->provisionalShipmentVoucherHeaderRepository = $provisionalShipmentVoucherHeaderRepository;
        $this->specialAuthorityRepository = $specialAuthorityRepository;
        $this->stockListProductUnitRepository = $stockListProductUnitRepository;
        $this->productClassRepository = $productClassRepository;
        $this->stateRepository = $stateRepository;
        $this->voucherNoProcessor = $voucherNoProcessor;
        $this->salesVoucherHeaderRepository = $salesVoucherHeaderRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/sales_management/temp_ex_stock_edit", name="admin_temp_ex_stock_edit")
     * @Route("/%eccube_admin_route%/sales_management/temp_ex_stock_edit/{id}/edit", requirements={"id" = "\d+"}, name="admin_temp_ex_stock_edit_list")
     * @Template("@admin/SalesVoucher/temp_ex_stock_edit.twig")
     * @param Request $request Request
     * @param int|null $id id
     * @param RouterInterface|null $router RouterInterface
     * @throws NotFoundHttpException
     * @throws \Exception
     * @return array|RedirectResponse
     */
    public function index(Request $request, int $id = null, RouterInterface $router = null)
    {
        $today = new \DateTime();
        $member = $this->getUser();
        $session = $this->session;
        $session->set('eccube.admin.temp_ex_stock_edit.authority', 'permission_denied');
        // INS-START CNC 2022/03/21
        $back_url = $request->headers->get('referer');
        // INS-END CNC 2022/03/21

        if (null === $id) {
            // 削除ボタン：非表示
            $delete_display = 0;
            // 活性制御
            $controls_enable['changeFlg'] = 1;

//            $front_url = null;
//
//            if (!empty($request->request->all())) {
//                $front_url = $request->request->get('payee_voucher')['front_url'];
//            }
//
//            if ($front_url === self::PREVIOUS_PAGE_URL_DETAIL){
//                // 前ページurl
//                $controls_enable['back_to_list_display'] = 1;
//                $controls_enable['back_to_list_url'] = self::BACK_TO_DETAIL_URL_STOCK;
//                $controls_enable['back_to_list_name'] = self::BACK_TO_DETAIL_NAME_STOCK;
//
//            }else if ($front_url === self::PREVIOUS_PAGE_URL_LIST){
//                // 前ページurl
//                $controls_enable['back_to_list_display'] = 1;
//                $controls_enable['back_to_list_url'] = self::BACK_TO_LIST_URL_STOCK;
//                $controls_enable['back_to_list_name'] = self::BACK_TO_LIST_NAME_STOCK;
//            } else {
//                $controls_enable['back_to_list_display'] = 0;
//            }
            $controls_enable['back_to_list_display'] = 0;


            // 支払い方法：銀行
            $payment = $this->getPaymentBankTransfer();

            // 空のエンティティを作成、さらに初期値を設定する
            $entity_temp_ex_stock_edit_header = (new ProvisionalShipmentVoucherHeader())
                // 入力モード: 新規登録
                ->setInputMode(trans('admin.temp.ex.stock.edit.input_mode.new'))
                ->setReservationSalesDate($today);

            // 担当者、作成者、更新者：ログインユーザ
            if ($member) {
                /** @var Member $member */
                $entity_temp_ex_stock_edit_header = $entity_temp_ex_stock_edit_header
                    ->setPersonnel($member)
                    ->setCreateUserName($member->getName())
                    ->setUpdateUserName($member->getName());

                // 権限
                $authority = $this->specialAuthorityRepository->isValidAuthority($member);
                if ($authority) {
                    $session->set('eccube.admin.temp_ex_stock_edit.authority', 'permission_granted');
                }
            }

            // 支払方法：銀行振込
            if ($payment) {
                $entity_temp_ex_stock_edit_header = $entity_temp_ex_stock_edit_header->setPayment($payment);
            }

            // 仮出荷川口のみ
            $entity_temp_ex_stock_edit_header->setProvisionalShipmentKawaguchiOnly(true);
        } else {

            // INS-START CNC 2022/03/21
//            if (strpos($back_url, self::PREVIOUS_PAGE_URL_DETAIL)) {
//                //仮出荷伝票明細から
//                // 前ページurl
//                $controls_enable['back_to_list_url'] = self::BACK_TO_DETAIL_URL_STOCK;
//                $controls_enable['back_to_list_name'] = self::BACK_TO_DETAIL_NAME_STOCK;
//            }else if (strpos($back_url, self::PREVIOUS_PAGE_URL_LIST)){
//                //仮出荷伝票一覧から
//                // 前ページurl
//                $controls_enable['back_to_list_url'] = self::BACK_TO_LIST_URL_STOCK;
//                $controls_enable['back_to_list_name'] = self::BACK_TO_LIST_NAME_STOCK;
//            }
            // INS-END CNC 2022/03/21
            if (strpos($back_url, self::PREVIOUS_PAGE_URL_DETAIL)) {
                //仮出荷伝票明細から
                // 前ページurl
                $controls_enable['back_to_list_display'] = 1;
                $controls_enable['back_to_list_url'] = self::BACK_TO_DETAIL_URL_STOCK;
                $controls_enable['back_to_list_name'] = self::BACK_TO_DETAIL_NAME_STOCK;
            }else {
                //仮出荷伝票一覧から
                // 前ページurl
                $controls_enable['back_to_list_display'] = 1;
                $controls_enable['back_to_list_url'] = self::BACK_TO_LIST_URL_STOCK;
                $controls_enable['back_to_list_name'] = self::BACK_TO_LIST_NAME_STOCK;
            }
            
            // 削除ボタン：表示
            $delete_display = 1;
            // 活性制御
            $controls_enable['changeFlg'] = 1;

            /** @var ProvisionalShipmentVoucherHeader $entity_temp_ex_stock_edit_header */
            $entity_temp_ex_stock_edit_header = $this->provisionalShipmentVoucherHeaderRepository->find($id);

            if ($entity_temp_ex_stock_edit_header !== null) {
                if ($entity_temp_ex_stock_edit_header instanceof ProvisionalShipmentVoucherHeader) {
                    // 出荷判断
                    $sales_voucher_header = $this->salesVoucherHeaderRepository->findOneBy(['sales_voucher_no' => $entity_temp_ex_stock_edit_header->getVoucherNo()]);

                    if ($sales_voucher_header == null) {
                        // 未出荷
                        $controls_enable['changeFlg'] = 1;
                    } else {
                        // 出荷済
                        $controls_enable['changeFlg'] = 0;
                    }
                }
            }

            // 入力モード: 修正
            $entity_temp_ex_stock_edit_header->setInputMode(trans('admin.temp.ex.stock.edit.input_mode.edit'));

            // 更新者：ログインユーザ
            if ($member) {
                /** @var Member $member */
                $entity_temp_ex_stock_edit_header = $entity_temp_ex_stock_edit_header
                    ->setUpdateUserName($member->getName());

                // 権限
                $authority = $this->specialAuthorityRepository->isValidAuthority($member);
                if ($authority) {
                    $session->set('eccube.admin.temp_ex_stock_edit.authority', 'permission_granted');
                }
            }
        }

        // 編集前の仮出荷伝票情報を保持
        $origin_entity_temp_ex_stock_edit_header = clone $entity_temp_ex_stock_edit_header;
        $origin_entity_temp_ex_stock_edit_detail_collection = new ArrayCollection();
        foreach ($origin_entity_temp_ex_stock_edit_header->getProvisionalShipmentVoucher() as $detail) {
            $origin_entity_temp_ex_stock_edit_detail_collection[$detail->getId()] = $detail;
        }

        // INS-START CNC 2022/03/10
        $customercode = '';
        if ($entity_temp_ex_stock_edit_header->getCustomer()) {
            $customercode = $entity_temp_ex_stock_edit_header->getCustomer()->getCustomerCode();
        }
        // INS-END CNC 2022/03/10

        // 削除比較用
        $entity_temp_ex_stock_edit_detail_collection_for_delete = new ArrayCollection();
        foreach ($entity_temp_ex_stock_edit_header->getProvisionalShipmentVoucher() as $detail) {
            $entity_temp_ex_stock_edit_detail_collection_for_delete->add($detail);
        }

        $builder_temp_ex_stock_edit_header = $this->formFactory
            ->createBuilder(TempExStockEditType::class, $entity_temp_ex_stock_edit_header);

        $form = $builder_temp_ex_stock_edit_header->getForm();

        if ('POST' === $request->getMethod()) {
            $form->handleRequest($request);

            if ($id != null ) {
                if ($request->get('orderUpdateTime') != $entity_temp_ex_stock_edit_header->getUpdateDate()->format('Y-m-d H:i:s')) {
                    $form['tempExStockEditDetailErrors']
                        ->addError(new FormError(trans('admin.payee.voucher.detail_update_date_error')));
                }
            }

            // Customer(MST)
            $customer_id = $request->get('temp_ex_stock_edit')['customer']['id'];
            /** @var CustomerMst $registered_entity_customer */
            $registered_entity_customer = $this->customerMstRepository->find($customer_id);
            if (!$registered_entity_customer) {
                $form['customer']['customerName']
                    ->addError(new FormError(trans('This value should not be blank.', [], 'validators')));
                $form['customer']
                    ->addError(new FormError(trans('This value should not be blank.', [], 'validators')));
            } else {
                $entity_temp_ex_stock_edit_header->setCustomer($registered_entity_customer);
            }

            $now_row_no = 0;

            if ($request->get('temp_ex_stock_edit')['total_quantity'] != '0') {
                $array_form_details = $request->get('temp_ex_stock_edit')['provisionalShipmentVoucher'];
                $now_row_no = $array_form_details
                    ? count($array_form_details)
                    : 0;
            }

            if ($form->isValid()) {
                /** @var ProvisionalShipmentVoucherHeader $temp_ex_stock_edit */
                $temp_ex_stock_edit = $form->getData();

                if ($request->get('mode') == 'register') {
                    try {
                        log_info('仮出荷先伝票登録開始', [$id]);

                        // 2021/12/27 CNC UPD START
                        if ($id === null) {
                            // 新規の場合、必須項目のため、先にダミー番号を登録する
                            $temp_ex_stock_edit->setProvisionalShipmentVoucherNo(self::TEMPORARY_VOUCHER_NO);
                        }
                        $temp_ex_stock_edit->setCustomer($registered_entity_customer);
                        // 2021/12/27 CNC UPD END

                        // 明細
                        $money_total_amount = 0;
                        $temp_ex_stock_edit_detail_no = $this->ProvisionalShipmentVoucherRepository
                            ->getMaxDetailNoInOneVoucher($entity_temp_ex_stock_edit_header);
                        $collection_temp_ex_stock_edit_details = $temp_ex_stock_edit->getProvisionalShipmentVoucher();

                        // 削除
                        foreach ($entity_temp_ex_stock_edit_detail_collection_for_delete as $origin_detail) {
                            if ($collection_temp_ex_stock_edit_details->contains($origin_detail) === false) {
                                $this->removeStockInfoWithDetailRemoved($origin_detail, $member->getName());
                                $this->entityManager->remove($origin_detail);
                            }
                        }

                        // 変更
                        if ($collection_temp_ex_stock_edit_details && is_array($collection_temp_ex_stock_edit_details->getValues())) {
                            $array_temp_ex_stock_edit_details = $collection_temp_ex_stock_edit_details->getValues();

                            // 設定
                            /** @var ProvisionalShipmentVoucher $entity_detail */
                            foreach ($array_temp_ex_stock_edit_details as $line_no => $entity_detail) {
                                if (!$entity_detail->getId() ||
                                    !$entity_detail->isEqual($origin_entity_temp_ex_stock_edit_detail_collection[$entity_detail->getId()])
                                ) {
                                    $entity_detail->setProvisionalShipmentDetailsNo(($entity_detail->getProvisionalShipmentDetailsNo()) ?: ++$temp_ex_stock_edit_detail_no)
                                        ->setProvisionalShipmentNo(self::TEMPORARY_VOUCHER_NO)
                                        ->setProvisionalShipmentVoucherHeader($temp_ex_stock_edit)
                                        ->setTotalSalesAmount()
                                        ->setCreateUserName($entity_detail->getCreateUserName() ?: $member->getName())
                                        ->setUpdateUserName($member->getName());
                                }

                                $int_money_total_amount = $entity_detail->getTotalSalesAmount();
                                $int_money_total_amount = str_replace(',', '', $int_money_total_amount);
                                $money_total_amount += $int_money_total_amount;

                                // 在庫一覧（商品単位）
                                $collection_stock_list_product_unit = $this->stockListProductUnitRepository->findStockListProductUnitByKey(
                                    $entity_detail->getProductCode(),
                                    $entity_detail->getState()->getId()
                                );

//                                if (isset($collection_stock_list_product_unit[0])) {

                                    $countQuantity = 0;
                                    $EditFlg = false;
                                    $stateChangeFlg = false;
                                    $stateChangeBeforeInfo = null;
                                    foreach ($origin_entity_temp_ex_stock_edit_detail_collection as $detail) {
                                        if ($entity_detail->getId() == $detail->getId()) {
                                            $countQuantity = $entity_detail->getQuantity() - $detail->getQuantity();
                                            $EditFlg = true;
                                            if ($entity_detail->getProductCode() !== $detail->getProductCode()
                                                || $entity_detail->getState()->getId() !== $detail->getState()->getId()) {
                                                $stateChangeFlg = true;
                                                $stateChangeBeforeInfo = $detail;
                                            }
                                            break;
                                        }
                                    }

                                    if ($countQuantity != 0 && $EditFlg) {

                                        if (isset($collection_stock_list_product_unit[0])) {
                                            $entity_stock_list_product_unit = $collection_stock_list_product_unit[0];
                                        } else {
                                            $entity_stock_list_product_unit = (new StockListProductUnit())
                                                ->setProductId($entity_detail->getProductId())
                                                ->setProductClass($entity_detail->getProductClass())
                                                ->setProductCode($entity_detail->getProductCode())
                                                ->setState($entity_detail->getState())
                                                ->setAverageUnitPrice(0)
                                                ->setStockQuantity(0)
                                                ->setOrderQuantity(0)
                                                ->setCreateUserName($member->getName())
                                                ->setUpdateUserName($member->getName())
                                            ;
                                        }

                                        if (!$stateChangeFlg) {
                                            if ($entity_stock_list_product_unit->getProvisionalShipmentQuantity() + $countQuantity >= 0) {
                                                $entity_stock_list_product_unit->setProvisionalShipmentQuantity(
                                                    $entity_stock_list_product_unit->getProvisionalShipmentQuantity()
                                                    + $countQuantity
                                                )->setRemainingStockQuantity(
                                                    $entity_stock_list_product_unit->getRemainingStockQuantity()
                                                    - $countQuantity
                                                )->setUpdateUserName($member->getName());
                                            } else {
                                                $provisional_shipment_quantity = $entity_stock_list_product_unit->getProvisionalShipmentQuantity();
                                                $entity_stock_list_product_unit->setProvisionalShipmentQuantity(
                                                    0
                                                )->setRemainingStockQuantity(
                                                    $entity_stock_list_product_unit->getRemainingStockQuantity()
                                                    + $provisional_shipment_quantity
                                                )->setUpdateUserName($member->getName());
                                            }
                                        } else {

                                            // 状態変更前の仮出荷数を削除
                                            $collection_stock_list_product_unit_changeBefore = $this->stockListProductUnitRepository->findStockListProductUnitByKey(
                                                $stateChangeBeforeInfo->getProductCode(),
                                                $stateChangeBeforeInfo->getState()->getId()
                                            );

                                            if (isset($collection_stock_list_product_unit_changeBefore[0])) {
                                                $entity_stock_list_product_unit_changeBefore = $collection_stock_list_product_unit_changeBefore[0];
                                            } else {
                                                $entity_stock_list_product_unit_changeBefore = (new StockListProductUnit())
                                                    ->setProductId($stateChangeBeforeInfo->getProductId())
                                                    ->setProductClass($stateChangeBeforeInfo->getProductClass())
                                                    ->setProductCode($stateChangeBeforeInfo->getProductCode())
                                                    ->setState($stateChangeBeforeInfo->getState())
                                                    ->setAverageUnitPrice(0)
                                                    ->setStockQuantity(0)
                                                    ->setOrderQuantity(0)
                                                    ->setCreateUserName($member->getName())
                                                    ->setUpdateUserName($member->getName())
                                                ;
                                            }

                                            if ($entity_stock_list_product_unit_changeBefore->getProvisionalShipmentQuantity() - $stateChangeBeforeInfo->getQuantity() >= 0) {
                                                $entity_stock_list_product_unit_changeBefore->setProvisionalShipmentQuantity(
                                                    $entity_stock_list_product_unit_changeBefore->getProvisionalShipmentQuantity()
                                                    - $stateChangeBeforeInfo->getQuantity()
                                                )->setRemainingStockQuantity(
                                                    $entity_stock_list_product_unit_changeBefore->getRemainingStockQuantity()
                                                    + $stateChangeBeforeInfo->getQuantity()
                                                )->setUpdateUserName($member->getName());
                                            } else {
                                                $provisional_shipment_quantity = $entity_stock_list_product_unit_changeBefore->getProvisionalShipmentQuantity();
                                                $entity_stock_list_product_unit_changeBefore->setProvisionalShipmentQuantity(
                                                    0
                                                )->setRemainingStockQuantity(
                                                    $entity_stock_list_product_unit_changeBefore->getRemainingStockQuantity()
                                                    - $provisional_shipment_quantity
                                                )->setUpdateUserName($member->getName());
                                            }
                                            $this->entityManager->persist($entity_stock_list_product_unit_changeBefore);

                                            // 状態変更後の仮出荷数を追加
                                            if ($entity_stock_list_product_unit->getProvisionalShipmentQuantity() + $entity_detail->getQuantity() >= 0) {
                                                $entity_stock_list_product_unit->setProvisionalShipmentQuantity(
                                                    $entity_stock_list_product_unit->getProvisionalShipmentQuantity()
                                                    + $entity_detail->getQuantity()
                                                )->setRemainingStockQuantity(
                                                    $entity_stock_list_product_unit->getRemainingStockQuantity()
                                                    - $entity_detail->getQuantity()
                                                )->setUpdateUserName($member->getName());
                                            } else {
                                                $entity_stock_list_product_unit->setProvisionalShipmentQuantity(
                                                    0
                                                )->setRemainingStockQuantity(
                                                    $entity_stock_list_product_unit->getStockQuantity()
                                                    - $entity_stock_list_product_unit->getOrderQuantity()
                                                    - 0
                                                )->setUpdateUserName($member->getName());
                                            }
                                        }

                                        $this->entityManager->persist($entity_stock_list_product_unit);
                                        $this->entityManager->flush($entity_stock_list_product_unit);

                                    } elseif ($entity_temp_ex_stock_edit_header->getInputMode() == trans('admin.temp.ex.stock.edit.input_mode.new') || (!$EditFlg && $countQuantity == 0)) {

                                        if (isset($collection_stock_list_product_unit[0])) {
                                            $entity_stock_list_product_unit = $collection_stock_list_product_unit[0];
                                        } else {
                                            $entity_stock_list_product_unit = (new StockListProductUnit())
                                                ->setProductId($entity_detail->getProductId())
                                                ->setProductClass($entity_detail->getProductClass())
                                                ->setProductCode($entity_detail->getProductCode())
                                                ->setState($entity_detail->getState())
                                                ->setAverageUnitPrice(0)
                                                ->setStockQuantity(0)
                                                ->setOrderQuantity(0)
                                                ->setCreateUserName($member->getName())
                                                ->setUpdateUserName($member->getName())
                                            ;
                                        }

                                        if ($entity_stock_list_product_unit->getProvisionalShipmentQuantity() + $entity_detail->getQuantity() >= 0) {
                                            $entity_stock_list_product_unit->setProvisionalShipmentQuantity(
                                                $entity_stock_list_product_unit->getProvisionalShipmentQuantity()
                                                + $entity_detail->getQuantity()
                                            )->setRemainingStockQuantity(
                                                $entity_stock_list_product_unit->getRemainingStockQuantity()
                                                - $entity_detail->getQuantity()
                                            )->setUpdateUserName($member->getName());
                                        } else {
                                            $provisional_shipment_quantity = $entity_stock_list_product_unit->getProvisionalShipmentQuantity();
                                            $entity_stock_list_product_unit->setProvisionalShipmentQuantity(
                                                0
                                            )->setRemainingStockQuantity(
                                                $entity_stock_list_product_unit->getRemainingStockQuantity()
                                                + $provisional_shipment_quantity
                                            )->setUpdateUserName($member->getName());
                                        }

                                        $this->entityManager->persist($entity_stock_list_product_unit);
                                        $this->entityManager->flush($entity_stock_list_product_unit);
                                    // INS-START CNC 2022/12/12 状態を修正時、ロジック修正
                                    } elseif ($stateChangeFlg) {
                                        // 状態変更前の仮出荷数を削除
                                        $collection_stock_list_product_unit_changeBefore = $this->stockListProductUnitRepository->findStockListProductUnitByKey(
                                            $stateChangeBeforeInfo->getProductCode(),
                                            $stateChangeBeforeInfo->getState()->getId()
                                        );

                                        if (isset($collection_stock_list_product_unit_changeBefore[0])) {
                                            $entity_stock_list_product_unit_changeBefore = $collection_stock_list_product_unit_changeBefore[0];
                                        } else {
                                            $entity_stock_list_product_unit_changeBefore = (new StockListProductUnit())
                                                ->setProductId($stateChangeBeforeInfo->getProductId())
                                                ->setProductClass($stateChangeBeforeInfo->getProductClass())
                                                ->setProductCode($stateChangeBeforeInfo->getProductCode())
                                                ->setState($stateChangeBeforeInfo->getState())
                                                ->setAverageUnitPrice(0)
                                                ->setStockQuantity(0)
                                                ->setOrderQuantity(0)
                                                ->setCreateUserName($member->getName())
                                                ->setUpdateUserName($member->getName())
                                            ;
                                        }

                                        if ($entity_stock_list_product_unit_changeBefore->getProvisionalShipmentQuantity() - $stateChangeBeforeInfo->getQuantity() >= 0) {
                                            $entity_stock_list_product_unit_changeBefore->setProvisionalShipmentQuantity(
                                                $entity_stock_list_product_unit_changeBefore->getProvisionalShipmentQuantity()
                                                - $stateChangeBeforeInfo->getQuantity()
                                            )->setRemainingStockQuantity(
                                                $entity_stock_list_product_unit_changeBefore->getRemainingStockQuantity()
                                                + $stateChangeBeforeInfo->getQuantity()
                                            )->setUpdateUserName($member->getName());
                                        } else {
                                            $provisional_shipment_quantity = $entity_stock_list_product_unit_changeBefore->getProvisionalShipmentQuantity();
                                            $entity_stock_list_product_unit_changeBefore->setProvisionalShipmentQuantity(
                                                0
                                            )->setRemainingStockQuantity(
                                                $entity_stock_list_product_unit_changeBefore->getRemainingStockQuantity()
                                                - $provisional_shipment_quantity
                                            )->setUpdateUserName($member->getName());
                                        }
                                        $this->entityManager->persist($entity_stock_list_product_unit_changeBefore);

                                        // 状態変更後の仮出荷数を追加
                                        if (isset($collection_stock_list_product_unit[0])) {
                                            $entity_stock_list_product_unit = $collection_stock_list_product_unit[0];
                                        } else {
                                            $entity_stock_list_product_unit = (new StockListProductUnit())
                                                ->setProductId($entity_detail->getProductId())
                                                ->setProductClass($entity_detail->getProductClass())
                                                ->setProductCode($entity_detail->getProductCode())
                                                ->setState($entity_detail->getState())
                                                ->setAverageUnitPrice(0)
                                                ->setStockQuantity(0)
                                                ->setOrderQuantity(0)
                                                ->setCreateUserName($member->getName())
                                                ->setUpdateUserName($member->getName())
                                            ;
                                        }

                                        if ($entity_stock_list_product_unit->getProvisionalShipmentQuantity() + $entity_detail->getQuantity() >= 0) {
                                            $entity_stock_list_product_unit->setProvisionalShipmentQuantity(
                                                $entity_stock_list_product_unit->getProvisionalShipmentQuantity()
                                                + $entity_detail->getQuantity()
                                            )->setRemainingStockQuantity(
                                                $entity_stock_list_product_unit->getRemainingStockQuantity()
                                                - $entity_detail->getQuantity()
                                            )->setUpdateUserName($member->getName());
                                        } else {
                                            $entity_stock_list_product_unit->setProvisionalShipmentQuantity(
                                                0
                                            )->setRemainingStockQuantity(
                                                $entity_stock_list_product_unit->getStockQuantity()
                                                - $entity_stock_list_product_unit->getOrderQuantity()
                                                - 0
                                            )->setUpdateUserName($member->getName());
                                        }

                                        $this->entityManager->persist($entity_stock_list_product_unit);
                                        $this->entityManager->flush($entity_stock_list_product_unit);
                                // INS-END CNC 2022/12/12 状態を修正時、ロジック修正
                                    }
//                                }
                            }
                        }

                        // ヘッダー：合計
                        $temp_ex_stock_edit->setMoneyTotalAmount($money_total_amount);

                        $this->entityManager->persist($temp_ex_stock_edit);
                        $this->entityManager->flush();

                        // 新規登録時はMySQL対応のためflushしてから採番
                        $this->voucherNoProcessor->process($temp_ex_stock_edit);
                        $this->entityManager->flush();

                        log_info('仮出荷伝票登録完了', [$temp_ex_stock_edit->getId()]);
                        $this->addSuccess('admin.common.save_complete', 'admin');

                        return $this->redirectToRoute('admin_temp_ex_stock_edit_list', ['id' => $temp_ex_stock_edit->getId()]);
                    } catch (\Exception $e) {
                        log_error('仮出荷伝票登録エラー', [$id, $e]);
                        $this->addError($e->getMessage(), 'admin');
                    }
                } elseif ($request->get('mode') == 'register' && $form) {
                    $this->addError('admin.common.save_error', 'admin');
                }
            }
        } else {
            $total_quantity = 0;
            $money_total_amount = 0;
            $total_sales_amount = 0;
            // 表示時明細の商品名称設定
            foreach ($form['provisionalShipmentVoucher'] as $form_detail) {
                /** @var FormInterface $form_detail */
                /** @var Product $product */
                $product = $this->productRepository->find($form_detail['product_id']
                    ->getData());
                $form_detail['product_name']->setData($product->getName());

                $array_entity_product = $this->productRepository->findProductsWithProductCode(
                    $form_detail['product_code']->getData()
                );
                if (!empty($array_entity_product) && !empty($array_entity_product[0])) {
                    $form_detail['category']->setData($array_entity_product[0]['category_id']);
                }

                $total_quantity += $form_detail['quantity']->getData();
                $money_total_amount += $form_detail['total_sales_amount']->getData();
                $form_detail['total_sales_amount']->setData(number_format(
                    (float) str_replace(',', '', $form_detail['total_sales_amount']->getData())
                ));
            }

            // 数量合計
            $form['total_quantity']->setData($total_quantity);
            // 金額合計
            $form['money_total_amount']->setData($money_total_amount);

            // 明細行数
            $now_row_no = $form['provisionalShipmentVoucher']
                ? $form['provisionalShipmentVoucher']->count()
                : 0;
        }

        $header_tax_id_flg = '';
        // 2022/01/13 CNC ADD START
        $tax_rate = '';
        // 2022/01/13 CNC ADD END

        if ($entity_temp_ex_stock_edit_header->getTaxRateCategory() && $entity_temp_ex_stock_edit_header->getTaxRateCategory()->getId() != null) {
            $array_entity_taxCode = $this->taxCodeRepository->findCalculateTaxIdByKey($entity_temp_ex_stock_edit_header->getTaxRateCategory()->getId());

            if (!empty($array_entity_taxCode) && !empty($array_entity_taxCode[0])) {
                if ($array_entity_taxCode[0]->getCalculateTax()->getId() === 2) {
                    $header_tax_id_flg = '1';
                } else {
                    $header_tax_id_flg = '0';
                }
                // 2022/01/13 CNC ADD START
                $tax_rate = $array_entity_taxCode[0]->getTaxRate();
                // 2022/01/13 CNC ADD END
            }
        }

        // マスタデータチェック
        if ($this->paymentRepository->count([]) <= 0) {
            $this->addError(trans('admin.common.master_table_no_data_message', ['%table%' => 'dtb_payment']), 'admin');
        }
        if ($this->customerMstRepository->count([]) <= 0) {
            $this->addError(trans('admin.common.master_table_no_data_message', ['%table%' => 'mtb_customer_mst']), 'admin');
        }
        if ($this->taxCodeRepository->count([]) <= 0) {
            $this->addError(trans('admin.common.master_table_no_data_message', ['%table%' => 'mtb_tax_code']), 'admin');
        }
        if ($this->taxExporterRepository->count([]) <= 0) {
            $this->addError(trans('admin.common.master_table_no_data_message', ['%table%' => 'mtb_tax_exporter']), 'admin');
        }

        // 得意先検索フォーム
        $builder_search_customer = $this->formFactory->createBuilder(TempExStockEditSearchCustomerType::class);

        $event = new EventArgs(
            [
                'builder' => $builder_search_customer,
                'tempExStockEditHeader' => $entity_temp_ex_stock_edit_header,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_TEMP_EX_STOCK_EDIT_INDEX_SEARCH_CUSTOMER_INITIALIZE, $event);

        $search_temp_ex_stock_modal_form = $builder_search_customer->getForm();

        // 状態
        $entity_state = $this->stateRepository->getStateByCategory();

        // 商品検索フォーム
        $builder = $this->formFactory
            ->createBuilder(SearchProductType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'tempExStockEditHeader' => $entity_temp_ex_stock_edit_header,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ORDER_EDIT_SEARCH_PRODUCT_INITIALIZE, $event);

        $searchProductModalForm = $builder->getForm();

        // 数量合計表示
        $total['total_quantity'] = trans('admin.temp.ex.stock.edit.total_quantity')
            .number_format(
                (float) str_replace(',', '', $form['total_quantity']->getData())
            );
        // 金額合計表示
        $total['money_total_amount'] = trans('admin.temp.ex.stock.edit_money_total_amount')
            .number_format(
                (float) str_replace(',', '', $form['money_total_amount']->getData())
            );

        $orderUpdateTime = null;
        if ($id != null) {
            $orderUpdateTime = $entity_temp_ex_stock_edit_header->getUpdateDate()->format('Y-m-d H:i:s');
        }

        $builder_csv_import = $this->formFactory
            ->createBuilder(CsvImportType::class);

        $event = new EventArgs(
            [
                'builder' => $builder_csv_import,
                'tempExStockEditHeader' => $entity_temp_ex_stock_edit_header,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_VOUCHER_INDEX_CSV_IMPORT_INITIALIZE, $event);

        $csv_import_form = $builder_csv_import->getForm();

        return [
            'form' => $form->createView(),
            'searchCustomerModalForm' => $search_temp_ex_stock_modal_form->createView(),
            'searchProductModalForm' => $searchProductModalForm->createView(),
            'tempExStockEditHeader' => $entity_temp_ex_stock_edit_header,
            'deleteDisplayFlg' => $delete_display,
            'stateList' => $entity_state,
            'totalAmountInfo' => $total,
            'detailDatumLength' => $now_row_no,
            'header_tax_id_flg' => $header_tax_id_flg,
            // 2022/01/13 CNC ADD START
            'tax_rate' => $tax_rate,
            // 2022/01/13 CNC ADD END
            'ControlsEnable' => $controls_enable,
            'customercode' => $customercode,
            'orderUpdateTime' => $orderUpdateTime,
            'csvImportForm' => $csv_import_form->createView(),
        ];
    }

    /**
     *  伝票更新時間取得
     *
     * @Route("/%eccube_admin_route%/temp_ex_stock_edit/search/date", name="admin_temp_sales_voucher_search_date")
     * @param Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchOrderUpdateDate(Request $request, Paginator $paginator)
    {
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
        }

        $result = [];
        $id = $request->get('headerId');

        if (!is_null($id)) {
            $entity_temp_ex_stock_edit_header = $this->provisionalShipmentVoucherHeaderRepository->find($id);
            if ($entity_temp_ex_stock_edit_header) {
                $orderUpdateTimeNew = $entity_temp_ex_stock_edit_header->getUpdateDate()->format('Y-m-d H:i:s');
                $result['orderUpdateTimeNew'] = $orderUpdateTimeNew;
            } else {
                $result['orderUpdateTimeNew'] = "";
            }
        }

        return $this->json(array_merge(['status' => 'OK'], $result));
    }

    /**
     * ヘッダー削除
     * @Route("/%eccube_admin_route%/temp_ex_stock_edit/{id}/delete", requirements={"id" = "\d+"}, name="admin_temp_ex_stock_edit_delete", methods={"DELETE"})
     * @param Request $request Request
     * @param int|null $id ID
     * @param CacheUtil|null $cacheUtil CacheUtil
     * @return \Symfony\Component\HttpFoundation\JsonResponse|RedirectResponse
     * @throws \Exception
     */
    public function delete(Request $request, int $id = null, CacheUtil $cacheUtil = null)
    {
        $this->isTokenValid();
        $session = $request->getSession();
        $page_no = intval($session->get('eccube.admin.sales_management.search.page_count'));
        $page_no = $page_no ? $page_no : Constant::ENABLED;
        $message = null;
        $success = false;
        $member = $this->getUser();

        if (!is_null($id)) {
            /** @var ProvisionalShipmentVoucherHeader $entity_temp_ex_stock_edit_header */
            $entity_temp_ex_stock_edit_header = $this->provisionalShipmentVoucherHeaderRepository->find($id);
            if (!$entity_temp_ex_stock_edit_header) {
                if ($request->isXmlHttpRequest()) {
                    $message = trans('admin.common.delete_error_already_deleted');

                    return $this->json(['success' => $success, 'message' => $message]);
                } else {
                    $this->deleteMessage();
                    $rUrl = $this->generateUrl('admin_temp_ex_stock_list', ['page_no' => $page_no]).'?resume='.Constant::ENABLED;

                    return $this->redirect($rUrl);
                }
            }

            if ($entity_temp_ex_stock_edit_header instanceof ProvisionalShipmentVoucherHeader) {
                log_info('仮出荷伝票ヘッダー削除開始', [$id]);

                $collection_temp_ex_stock_edit_detail = $entity_temp_ex_stock_edit_header->getProvisionalShipmentVoucher();

                try {
                    // 関連仮出荷伝票明細削除
                    if ($collection_temp_ex_stock_edit_detail->count() > 0) {

                        // 出荷判断
                        $sales_voucher_header = $this->salesVoucherHeaderRepository->findOneBy(['sales_voucher_no' => $entity_temp_ex_stock_edit_header->getVoucherNo()]);

                        if ($sales_voucher_header == null) {
                            // 未出荷
                            $salesCount = 0;
                        } else {
                            // 出荷済
                            $salesCount = 1;
                        }

                        foreach ($collection_temp_ex_stock_edit_detail as $detail) {

                            // 未出荷のみ場合、仮出荷数量を変更
                            if ($salesCount !== 1) {
                                $this->removeStockInfoWithDetailRemoved($detail, $member->getName());
                            }

                            $this->ProvisionalShipmentVoucherRepository->delete($detail);
                        }
                    }

                    $this->provisionalShipmentVoucherHeaderRepository->delete($entity_temp_ex_stock_edit_header);
                    $this->entityManager->flush();

                    $event = new EventArgs(
                        [
                            'tempExStockEditHeader' => $entity_temp_ex_stock_edit_header,
                            'tempExStockEditDetail' => $collection_temp_ex_stock_edit_detail,
                        ],
                        $request
                    );
                    $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_TEMP_EX_STOCK_EDIT_COMPLETE, $event);

                    log_info('仮出荷伝票ヘッダー削除完了', [$id]);

                    $success = true;
                    $message = trans('admin.common.delete_complete');

                    $cacheUtil->clearDoctrineCache();
                } catch (ForeignKeyConstraintViolationException $e) {
                    log_info('仮出荷伝票ヘッダー削除エラー', [$id]);
                    $message = trans('admin.common.delete_error_foreign_key', ['%name%' => $entity_temp_ex_stock_edit_header->getProvisionalShipmentVoucherNo()]);
                } catch (\Exception $e) {
                    log_info('仮出荷伝票ヘッダー削除エラー', [$id]);
                    $message = trans('admin.common.delete_error');
                }
            } else {
                log_info('仮出荷伝票ヘッダー削除エラー', [$id]);
                $message = trans('admin.common.delete_error');
            }
        } else {
            log_info('仮出荷伝票ヘッダー削除エラー', [$id]);
            $message = trans('admin.common.delete_error');
        }

        if ($request->isXmlHttpRequest()) {
            return $this->json(['success' => $success, 'message' => $message]);
        } else {
            if ($success) {
                $this->addSuccess($message, 'admin');
                $rUrl = $this->generateUrl('admin_temp_ex_stock_list', ['page_no' => $page_no]).'?resume='.Constant::ENABLED;
            } else {
                $this->addError($message, 'admin');
                $rUrl = $this->generateUrl('admin_product_page', ['page_no' => $page_no]).'?resume='.Constant::ENABLED;
            }

            return $this->redirect($rUrl);
        }
    }

    /**
     * @Route("/%eccube_admin_route%/temp_ex_stock_edit/search/customer", name="admin_temp_ex_stock_edit_search_customer")
     * @Route("/%eccube_admin_route%/temp_ex_stock_edit/search/customer/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_temp_ex_stock_edit_search_customer_page")
     * @Template("@admin/SalesVoucher/temp_ex_stock_edit_search_customer.twig")
     * @param Request $request Request
     * @param int|null $page_no page no
     * @param Paginator|null $paginator Paginator
     * @return array
     */
    public function searchCustomer(Request $request, int $page_no = null, Paginator $paginator = null)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            $page_count = $this->eccubeConfig['eccube_default_page_count'];
            $session = $this->session;

            if ('POST' === $request->getMethod()) {
                $page_no = 1;
                $searchData = [
                    'customerName' => $request->get('name'),
                    'kana' => $request->get('kana'),
                    'customerCode' => $request->get('code'),
                    'phoneNumber' => $request->get('phone'),
                    'customerAsName' => $request->get('as_name'),
                ];

                $session->set('eccube.admin.temp_ex_stock_edit.customer.search', $searchData);
                $session->set('eccube.admin.temp_ex_stock_edit.customer.search.page_no', $page_no);
            } else {
                $searchData = (array) $session->get('eccube.admin.temp_ex_stock_edit.customer.search');
                if (is_null($page_no)) {
                    $page_no = intval($session->get('eccube.admin.temp_ex_stock_edit.customer.page_no'));
                } else {
                    $session->set('eccube.admin.temp_ex_stock_edit.customer.page_no', $page_no);
                }
            }

            $qb = $this->customerMstRepository->getQueryBuilderBySearchData($searchData);

            $event = new EventArgs(
                [
                    'qb' => $qb,
                    'data' => $searchData,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_TEMP_EX_STOCK_EDIT_INDEX_SEARCH_CUSTOMER_SEARCH, $event);

            /** @var \Knp\Component\Pager\Pagination\SlidingPagination $pagination */
            $pagination = $paginator->paginate(
                $qb,
                $page_no,
                $page_count,
                ['wrap-queries' => true]
            );

            /** @var $Customers \Eccube\Entity\CustomerMst[] */
            $Customers = $pagination->getItems();

            if (empty($Customers)) {
                log_debug('search customerMst not found.');
            }

            $data = [];
            foreach ($Customers as $customerMst) {
                $data[] = [
                    'id' => $customerMst->getId(),
                    'customerName' => $customerMst->getCustomerName(),
                    'kana' => $customerMst->getKana(),
                    'customerCode' => $customerMst->getCustomerCode(),
                    'phoneNumber' => $customerMst->getPhoneNumber(),
                    'customerAsName' => $customerMst->getCustomerAsName(),
                ];
            }

            $event = new EventArgs(
                [
                    'data' => $data,
                    'customers' => $pagination,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::AADMIN_TEMP_EX_STOCK_EDIT_INDEX_SEARCH_CUSTOMER_COMPLETE, $event);
            $data = $event->getArgument('data');

            return [
                'data' => $data,
                'pagination' => $pagination,
            ];
        }
    }

    /**
     * @Route("/%eccube_admin_route%/temp_ex_stock_edit/calculate_tax_flg", name="admin_temp_ex_stock_edit_calculate_tax_flg")
     * @param Request $request リクエスト
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function calculateTaxFlg(Request $request)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('add taxCode start.');

            $id = $request->get('id');

            $array_entity_taxCode = $this->taxCodeRepository->findCalculateTaxIdByKey($id);

            if (!empty($array_entity_taxCode) && !empty($array_entity_taxCode[0])) {
                if ($array_entity_taxCode[0]->getCalculateTax()->getId() === 2) {
                    $tax_flg = '1';
                } else {
                    $tax_flg = '0';
                }
                $tax_rate = $array_entity_taxCode[0]->getTaxRate();

                $data = [
                    'tax_flg' => $tax_flg,
                    'tax_rate' => $tax_rate,
                ];
            } else {
                $data = [];
            }
            return $this->json($data);
        }
    }

    /**
     * @Route("/%eccube_admin_route%/temp_ex_stock_edit/search/product", name="admin_temp_ex_stock_edit_search_product")
     * @Route("/%eccube_admin_route%/temp_ex_stock_edit/search/product/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_temp_ex_stock_edit_search_product_page")
     * @Template("@admin/SalesVoucher/temp_ex_stock_edit_search_product.twig")
     * @param Request $request Request
     * @param int|null $page_no page_no
     * @param Paginator|null $paginator Paginator
     * @return array
     */
    public function searchProduct(Request $request, $page_no = null, Paginator $paginator)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('search product start.');

            $page_count = $this->eccubeConfig['eccube_default_page_count'];
            $session = $this->session;

            if ('POST' === $request->getMethod()) {
                $page_no = 1;

                $searchData = [
                    'id' => $request->get('id'),
                ];

                if ($categoryId = $request->get('category_id')) {
                    $Category = $this->categoryRepository->find($categoryId);
                    $searchData['category_id'] = $Category;
                }

                $session->set('eccube.admin.sales_voucher.product.search', $searchData);
                $session->set('eccube.admin.sales_voucher.product.search.page_no', $page_no);
            } else {
                $searchData = (array) $session->get('eccube.admin.sales_voucher.product.search');
                if (is_null($page_no)) {
                    $page_no = intval($session->get('eccube.admin.sales_voucher.product.search.page_no'));
                } else {
                    $session->set('eccube.admin.sales_voucher.product.search.page_no', $page_no);
                }
            }

            $qb = $this->productRepository
                ->getQueryBuilderBySearchDataForAdminSubPage($searchData);

            $event = new EventArgs(
                [
                    'qb' => $qb,
                    'searchData' => $searchData,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ORDER_EDIT_SEARCH_PRODUCT_SEARCH, $event);

            /** @var \Knp\Component\Pager\Pagination\SlidingPagination $pagination */
            $pagination = $paginator->paginate(
                $qb,
                $page_no,
                $page_count,
                ['wrap-queries' => true]
            );

            /** @var $Products \Eccube\Entity\Product[] */
            $Products = $pagination->getItems();

            if (empty($Products)) {
                log_debug('search product not found.');
            }

            $forms = [];
            foreach ($Products as $Product) {
                /* @var $builder \Symfony\Component\Form\FormBuilderInterface */
                $builder = $this->formFactory->createNamedBuilder('', AddCartType::class, null, [
                    'product' => $this->productRepository->findWithSortedClassCategories($Product->getId()),
                ]);
                $addCartForm = $builder->getForm();
                $forms[$Product->getId()] = $addCartForm->createView();
            }

            $event = new EventArgs(
                [
                    'forms' => $forms,
                    'Products' => $Products,
                    'pagination' => $pagination,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ORDER_EDIT_SEARCH_PRODUCT_COMPLETE, $event);

            return [
                'forms' => $forms,
                'pagination' => $pagination,
            ];
        }
    }

    /**
     * @param ProvisionalShipmentVoucher $temp_ex_stock_edit_detail 明細
     * @param string $user_name ユーザ名
     */
    public function removeStockInfoWithDetailRemoved(ProvisionalShipmentVoucher $temp_ex_stock_edit_detail, string $user_name)
    {
        // 在庫一覧（商品単位）
        $parameter_stock_by_product = [
            'productId' => $temp_ex_stock_edit_detail->getProductId(),
            'ProductClass' => $temp_ex_stock_edit_detail->getProductClass(),
            'productCode' => $temp_ex_stock_edit_detail->getProductCode(),
            'State' => $temp_ex_stock_edit_detail->getState(),
        ];

        $collection_stock_list_product_unit = $this->stockListProductUnitRepository
            ->findBy($parameter_stock_by_product);

        if (isset($collection_stock_list_product_unit[0])) {
            $entity_stock_list_product_unit = $collection_stock_list_product_unit[0];

            if ($entity_stock_list_product_unit->getProvisionalShipmentQuantity() - $temp_ex_stock_edit_detail->getQuantity() >= 0) {
                $entity_stock_list_product_unit->setProvisionalShipmentQuantity(
                    $entity_stock_list_product_unit->getProvisionalShipmentQuantity()
                    - $temp_ex_stock_edit_detail->getQuantity()
                )->setRemainingStockQuantity(
                    $entity_stock_list_product_unit->getRemainingStockQuantity()
                    + $temp_ex_stock_edit_detail->getQuantity()
                )->setUpdateUserName($user_name);
            } else {
                $provisional_shipment_quantity = $entity_stock_list_product_unit->getProvisionalShipmentQuantity();
                $entity_stock_list_product_unit->setProvisionalShipmentQuantity(
                    0
                )->setRemainingStockQuantity(
                    $entity_stock_list_product_unit->getRemainingStockQuantity()
                    + $provisional_shipment_quantity
                )->setUpdateUserName($user_name);
            }

            $this->entityManager->persist($entity_stock_list_product_unit);
        }
    }

    /**
     * 支払方法：銀行振込 情報取得
     * @return Payment
     */
    public function getPaymentBankTransfer()
    {
        $array_payment_bank_transfer = $this->paymentRepository->findBy(['method' => '銀行振込']);
        return isset($array_payment_bank_transfer[0])
            ? $array_payment_bank_transfer[0]
            : null;
    }

    // INS-START CNC 2022/03/10
    /**
     * @Route("/%eccube_admin_route%/sales_voucher/search/customer_code", name="admin_sales_voucher_customer_code")
     * @param Request $request リクエスト
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchCustomerCode(Request $request)
    {
        $customer_code = $request->get('code');

        log_info("Admin SalesVoucher searchCustomer", [$customer_code]);

        // 得意先取得
        $array_entity_customer_code = $this->customerMstRepository->findCustomerWithCustomerCode($customer_code);

        $event = new EventArgs(
            [
                'CustomerCode' => $customer_code,
                'Customer' => $array_entity_customer_code,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_MANAGEMENT_INDEX_SEARCH_CUSTOMER_INITIALIZE, $event);

        if (!empty($array_entity_customer_code) && !empty($array_entity_customer_code[0])) {
            /** @var CustomerMst $entity_customer */
            $entity_customer = $array_entity_customer_code[0];
            $data = [
                'target_customer_id' => $entity_customer->getId(),
                'target_customer_code' => $entity_customer->getCustomerCode(),
                'target_customer_name' => $entity_customer->getCustomerName(),
            ];
        } else {
            log_debug('search customer by code not found.');
            return $this->json([], 404);
        }
        $event = new EventArgs(
            [
                'CustomerCode' => $customer_code,
                'Customer' => $entity_customer,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_MANAGEMENT_INDEX_SEARCH_CUSTOMER_COMPLETE, $event);

        return $this->json($data);
    }

    // INS-END CNC 2022/03/10
}
