<?php


namespace Eccube\Controller\Admin\SalesVoucher;

use Eccube\Controller\Admin\AbstractCsvImportController;
use Eccube\Entity\Member;
use Eccube\Entity\Product;
use Eccube\Entity\State;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\PlaceRepository;
use Eccube\Repository\ProductCategoryRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\StateRepository;
use Eccube\Repository\StockListProductUnitRepository;
use Eccube\Util\CacheUtil;
use Eccube\Util\StringUtil;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class TempExStockCsvImportController extends AbstractCsvImportController
{
    /**
     * @var ProductRepository
     */
    private $productRepository;

    /**
     * @var StateRepository
     */
    private $stateRepository;

    /**
     * @var PlaceRepository
     */
    private $placeRepository;

    /**
     * @var ProductClassRepository
     */
    private $productClassRepository;

    /**
     * @var ProductCategoryRepository
     */
    private $productCategoryRepository;

    /**
     * @var StockListProductUnitRepository
     */
    protected $stockListProductUnitRepository;

    private $errors = [];

    public function __construct(
        ProductRepository $productRepository,
        StateRepository $stateRepository,
        PlaceRepository $placeRepository,
        ProductClassRepository $productClassRepository,
        ProductCategoryRepository $productCategoryRepository,
        StockListProductUnitRepository $stockListProductUnitRepository
    ) {
        $this->productRepository = $productRepository;
        $this->stateRepository = $stateRepository;
        $this->placeRepository = $placeRepository;
        $this->productClassRepository = $productClassRepository;
        $this->productCategoryRepository = $productCategoryRepository;
        $this->stockListProductUnitRepository = $stockListProductUnitRepository;
    }

    /**
     * 仮出荷伝票CSVインポート
     *
     * @Route("/%eccube_admin_route%/temp_ex_stock_edit/temp_ex_stock_csv_upload", name="admin_temp_ex_stock_csv_import")
     * @param Request $request Request
     * @param CacheUtil $cache_util CacheUtil
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     * @throws \Doctrine\DBAL\ConnectionException
     */
    public function csvTempExStock(Request $request, CacheUtil $cache_util)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('csv import start.');
            /** @var UploadedFile $uploaded_file */
            $uploaded_file = $request->files->get('admin_csv_import')['import_file'];
            $error = 0;
            if (!empty($uploaded_file)) {
                log_info('仮出荷伝票CSV登録開始');
                $headers = $this->getTempExStockCsvHeader();
                $data = $this->getImportData($uploaded_file);
                if ($data === false) {
                    $this->addErrors(trans('admin.common.csv_invalid_format'));
                    return $this->renderWithError();
                }

                $data->rewind();

                $getProductCode = function ($item) {
                    return $item['id'];
                };
                $requireHeader = array_keys(array_map($getProductCode, array_filter($headers, function ($value) {
                    return $value['required'];
                })));

                $columnHeaders = $data->getColumnHeaders();

                if (count(array_diff($requireHeader, $columnHeaders)) > 0) {
                    $this->addErrors(trans('admin.common.csv_invalid_format'));

                    return $this->renderWithError();
                }

                $size = count($data);

                if ($size < 1) {
                    $this->addErrors(trans('admin.common.csv_invalid_no_data'));

                    return $this->renderWithError();
                }

                $headerByKey = array_flip(array_map($getProductCode, $headers));
                $grid_data = [];

                // CSVファイルの登録処理
                foreach ($data as $line => $row) {
                    if (count($headers) != count($row)) {
                        $message = trans('admin.common.csv_invalid_format_line', ['%line%' => $line + 1]);
                        $this->addErrors($message);
                        $error++;
                        continue;
                    }
                    if (!isset($row[$headerByKey['product_code']]) || StringUtil::isBlank($row[$headerByKey['product_code']])) {
                        $message = trans('admin.common.csv_invalid_required', ['%line%' => $line + 1, '%name%' => '商品コード']);
                        $this->addErrors($message);
                        $error++;
                        continue;
                    }
                    $array_entity_product = $this->productRepository->findProductsWithProductCode($row[$headerByKey['product_code']]);
                    if (count($array_entity_product) <= 0) {
                        $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line + 1, '%name%' => '商品']);
                        $this->addErrors($message);
                        $error++;
                        continue;
                    }
                    /** @var Product $Product */
                    /** @var State $state */
                    $Product = $array_entity_product[0][0];
                    if (!$Product) {
                        $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line + 1, '%name%' => '商品']);
                        $this->addErrors($message);
                        $error++;
                        continue;
                    }
                    $state = $this->stateRepository->find($row[$headerByKey['status_id']]);
                    if(!$state){
                        $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line + 1, '%name%' => '状態ID']);
                        $this->addErrors($message);
                        $error++;
                        continue;
                    }else{
                        $sameFalg = false;
                        foreach ($array_entity_product as $entity_product){
                            if($entity_product['category_id']  == $state->getCategoryId()){
                                $sameFalg = true;
                            }
                        }
                        if(!$sameFalg){
                            $message = trans('admin.common.csv_invalid_category_id', ['%line%' => $line + 1]);
                            $this->addErrors($message);
                            $error++;
                            continue;
                        }
                    }

                    // 数量
                    $csv_cnt_bigger_db_cnt_flg = '0';
                    $quantityCompareRemainingCnt = $row[$headerByKey['quantity']];
                    $stockListProductUnit = $this->stockListProductUnitRepository
                        ->findOneBy([
                            'productCode' => $row[$headerByKey['product_code']],
                            'State' => $row[$headerByKey['status_id']]
                        ]);
                    if (!$stockListProductUnit) {
                        $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line + 1, '%name%' => '商品の在庫情報']);
                        $this->addErrors($message);
                        $error++;
                        continue;
                    } else {
                        if ($quantityCompareRemainingCnt > $stockListProductUnit->getRemainingStockQuantity()) {
                            $csv_cnt_bigger_db_cnt_flg = '1';
                            $quantityCompareRemainingCnt = $stockListProductUnit->getRemainingStockQuantity();
                        }
                    }

                    $grid_data[] = [
                        'id' => $Product->getId(),
                        'product_name' => $Product->getName(),
                        'product_code' => $row[$headerByKey['product_code']],
                        'category' => $array_entity_product[0]['category_id'],
                        'product_class' => $Product->getProductClasses()[0]->getId(),
                        'quantity' => $quantityCompareRemainingCnt,
                        'status' => $row[$headerByKey['status_id']],
                        'sales_price' => $row[$headerByKey['sales_price']],
                        'sales_price_extax' => $row[$headerByKey['sales_price_extax']],
                        'csv_cnt_bigger_db_cnt_flg' => $csv_cnt_bigger_db_cnt_flg,
                    ];
                }

                $this->removeUploadedFile();
                if ($error > 0) {
                    return $this->json(['error' => $this->errors]);
                } else {
                    return $this->json(['data' => $grid_data]);
                }
            }
        }
    }

    /**
     * 仮出荷伝票CSVヘッダー定義
     * @return array
     */
    protected function getTempExStockCsvHeader()
    {
        return [
            trans('admin.temp.ex.stock.csv_import.product_code_col') => [
                'id' => 'product_code',
                'description' => 'admin.temp.ex.stock.csv_import.product_code_description',
                'required' => true,
            ],
            trans('admin.temp.ex.stock.csv_import.status_id_col') => [
                'id' => 'status_id',
                'description' => 'admin.temp.ex.stock.csv_import.status_id_description',
                'required' => true,
            ],
            trans('admin.temp.ex.stock.csv_import.quantity_col') => [
                'id' => 'quantity',
                'description' => 'admin.temp.ex.stock.csv_import.quantity_description',
                'required' => true,
            ],
            trans('admin.temp.ex.stock.csv_import.sales_price_extax_col') => [
                'id' => 'sales_price_extax',
                'description' => 'admin.temp.ex.stock.csv_import.sales_price_extax_description',
                'required' => true,
            ],
            trans('admin.temp.ex.stock.csv_import.sales_price_col') => [
                'id' => 'sales_price',
                'description' => 'admin.temp.ex.stock.csv_import.sales_price_description',
                'required' => true,
            ],
        ];
    }

    /**
     * 登録、更新時のエラー画面表示
     */
    protected function addErrors($message)
    {
        $this->errors[] = $message;
    }

    /**
     * 登録、更新時のエラー画面表示
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     *
     * @throws \Doctrine\DBAL\ConnectionException
     */
    protected function renderWithError()
    {
        $this->removeUploadedFile();

        return $this->json([
            'errors' => $this->errors,
        ]);
    }
}
