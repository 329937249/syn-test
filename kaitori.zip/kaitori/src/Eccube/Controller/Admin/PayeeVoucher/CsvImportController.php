<?php


namespace Eccube\Controller\Admin\PayeeVoucher;

use Eccube\Controller\Admin\AbstractCsvImportController;
use Eccube\Entity\Product;
use Eccube\Repository\ProductRepository;
use Eccube\Util\CacheUtil;
use Eccube\Util\StringUtil;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class CsvImportController extends AbstractCsvImportController
{
    /**
     * @var ProductRepository
     */
    private $productRepository;

    private $errors = [];

    public function __construct(
        ProductRepository $productRepository
    ) {
        $this->productRepository = $productRepository;
    }

    /**
     * 仕入伝票CSVインポート
     *
     * @Route("/%eccube_admin_route%/payee_voucher/payee_voucher_csv_upload", name="admin_payee_voucher_csv_import")
     * @param Request $request Request
     * @param CacheUtil $cache_util CacheUtil
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     * @throws \Doctrine\DBAL\ConnectionException
     */
    public function csvPayeeVoucher(Request $request, CacheUtil $cache_util)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('csv import start.');
            /** @var UploadedFile $uploaded_file */
            $uploaded_file = $request->files->get('admin_csv_import')['import_file'];
            $error = 0;
            if (!empty($uploaded_file)) {
                log_info('仕入伝票CSV登録開始');
                $headers = $this->getPayeeVoucherCsvHeader();
                $data = $this->getImportData($uploaded_file);
                if ($data === false) {
                    $this->addErrors(trans('admin.common.csv_invalid_format'));
                    return $this->renderWithError();
                }

                $data->rewind();

                $getProductCode = function ($item) {
                    return $item['id'];
                };
                $requireHeader = array_keys(array_map($getProductCode, array_filter($headers, function ($value) {
                    return $value['required'];
                })));

                $columnHeaders = $data->getColumnHeaders();

                if (count(array_diff($requireHeader, $columnHeaders)) > 0) {
                    $this->addErrors(trans('admin.common.csv_invalid_format'));

                    return $this->renderWithError();
                }

                $size = count($data);

                if ($size < 1) {
                    $this->addErrors(trans('admin.common.csv_invalid_no_data'));

                    return $this->renderWithError();
                }

                $headerByKey = array_flip(array_map($getProductCode, $headers));
                $grid_data = [];

                // CSVファイルの登録処理
                foreach ($data as $line => $row) {
                    if (count($headers) != count($row)) {
                        $message = trans('admin.common.csv_invalid_format_line', ['%line%' => $line + 1]);
                        $this->addErrors($message);
                        $error++;
                        continue;
                    }
                    if (!isset($row[$headerByKey['product_code']]) || StringUtil::isBlank($row[$headerByKey['product_code']])) {
                        $message = trans('admin.common.csv_invalid_required', ['%line%' => $line + 1, '%name%' => '商品コード']);
                        $this->addErrors($message);
                        $error++;
                        continue;
                    }
                    $array_entity_product = $this->productRepository->findProductsWithProductCode($row[$headerByKey['product_code']]);
                    if (count($array_entity_product) <= 0) {
                        $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line + 1, '%name%' => '商品']);
                        $this->addErrors($message);
                        $error++;
                        continue;
                    }
                    /** @var Product $Product */
                    $Product = $array_entity_product[0][0];
                    if (!$Product) {
                        $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line + 1, '%name%' => '商品']);
                        $this->addErrors($message);
                        $error++;
                        continue;
                    }

                    // $payee_price = round($Product->getPrice02IncTaxMin() ?: $Product->getPrice01IncTaxMin());

                    $grid_data[] = [
                        'id' => $Product->getId(),
                        'name' => $Product->getName(),
                        'serial_flg' => (int) $Product->getSerialFlg(),
                        'product_code' => $row[$headerByKey['product_code']],
                        'category' => $array_entity_product[0]['category_id'],
                        'product_class' => $Product->getProductClasses()[0]->getId(),
                        'serial_no' => $row[$headerByKey['serial_no']],
                        'state_name' => $row[$headerByKey['state']],
                        'quantity' => $row[$headerByKey['quantity']],
                        'payee_price' => $row[$headerByKey['payee_price']],
                    ];
                }

                $this->removeUploadedFile();
                if ($error > 0) {
                    return $this->json(['error' => $this->errors]);
                } else {
                    return $this->json(['data' => $grid_data]);
                }
            }
        }
    }

    /**
     * 仕入伝票CSVヘッダー定義
     * @return array
     */
    protected function getPayeeVoucherCsvHeader()
    {
        return [
            trans('admin.payee.voucher.csv_import.jan_code_col') => [
                'id' => 'product_code',
                'description' => 'admin.payee.voucher.csv_import.jan_code_description',
                'required' => true,
            ],
            trans('admin.payee.voucher.csv_import.serial_no_col') => [
                'id' => 'serial_no',
                'description' => 'admin.payee.voucher.csv_import.serial_no_description',
                'required' => false,
            ],
            trans('admin.payee.voucher.csv_import.state_col') => [
                'id' => 'state',
                'description' => 'admin.payee.voucher.csv_import.state_description',
                'required' => false,
            ],
            trans('admin.payee.voucher.csv_import.quantity_col') => [
                'id' => 'quantity',
                'description' => 'admin.payee.voucher.csv_import.quantity_description',
                'required' => true,
            ],
            trans('admin.payee.voucher.csv_import.price_col') => [
                'id' => 'payee_price',
                'description' => 'admin.payee.voucher.csv_import.price_description',
                'required' => true,
            ],
        ];
    }

    /**
     * 登録、更新時のエラー画面表示
     */
    protected function addErrors($message)
    {
        $this->errors[] = $message;
    }

    /**
     * 登録、更新時のエラー画面表示
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     *
     * @throws \Doctrine\DBAL\ConnectionException
     */
    protected function renderWithError()
    {
        $this->removeUploadedFile();

        return $this->json([
            'errors' => $this->errors,
        ]);
    }
}