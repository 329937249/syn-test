<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\PayeeVoucher;

use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\QueryBuilder;
use Eccube\Controller\AbstractController;
use Eccube\Entity\Master\CsvType;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\PayeeVoucherItemType;
use Eccube\Form\Type\Admin\SearchMemberType;
use Eccube\Form\Type\Admin\SearchPayeeMstType;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\Master\SpecialAuthorityRepository;
use Eccube\Repository\MemberRepository;
use Eccube\Repository\PayeeMstRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\StockListStorehouseUnitRepository;
use Eccube\Service\CsvExportService;
use Eccube\Util\FormUtil;
use Eccube\Util\StringUtil;
use Knp\Component\Pager\Paginator;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;

/**
 *プログラム名 ： PayeeVoucherDetailPhoneController.php
 *概　　要     ： 仕入伝票明細(フォン)
 *作　　成     ： 2022/09/16 CNC
 */
class PayeeVoucherDetailPhoneController extends AbstractController
{
    // 一覧画面URL
    const PAYEElIST_PAGE_URL = 'payee_management/payee_voucher_list';
    const BACK_TO_LIST_URL_PAYEE = 'admin_payee_voucher_list';
    const BACK_TO_LIST_NAME_PAYEE = 'admin.payee.voucher_list';

    const PREVIOUS_PAGE_URL_BALANCE = 'payment/disbursement_balance';
    const BACK_TO_LIST_URL_BALANCE = 'admin_payment_disbursement';
    const BACK_TO_LIST_NAME_BALANCE = 'admin.remittance.disbursement_balance';

    /**
     * @var CsvExportService
     */
    protected $csvExportService;
    /**
     * @var EntityManagerInterface
     */
    protected $entityManager;

    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;

    /**
     * @var PayeeMstRepository
     */
    protected $payeeMstRepository;

    /**
     * @var MemberRepository
     */
    protected $memberRepository;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var SpecialAuthorityRepository
     */
    protected $specialAuthorityRepository;

    /**
     * @var StockListStorehouseUnitRepository
     */
    protected $stockListStorehouseUnitRepository;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * ProductController constructor.
     *
     * @param CsvExportService $csvExportService CsvExportService
     * @param CategoryRepository $categoryRepository CategoryRepository
     * @param PageMaxRepository $pageMaxRepository PageMaxRepository
     * @param EntityManagerInterface $entityManager EntityManagerInterface
     * @param PayeeMstRepository $payeeMstRepository PayeeMstRepository
     * @param MemberRepository $memberRepository MemberRepository
     * @param SpecialAuthorityRepository $specialAuthorityRepository SpecialAuthorityRepository
     * @param StockListStorehouseUnitRepository $stockListStorehouseUnitRepository
     */
    public function __construct(
        CsvExportService $csvExportService,
        CategoryRepository $categoryRepository,
        PageMaxRepository $pageMaxRepository,
        EntityManagerInterface $entityManager,
        PayeeMstRepository $payeeMstRepository,
        MemberRepository $memberRepository,
        SpecialAuthorityRepository $specialAuthorityRepository,
        StockListStorehouseUnitRepository $stockListStorehouseUnitRepository
        , ProductRepository $productRepository
    ) {
        $this->csvExportService = $csvExportService;
        $this->categoryRepository = $categoryRepository;
        $this->pageMaxRepository = $pageMaxRepository;
        $this->entityManager = $entityManager;
        $this->payeeMstRepository = $payeeMstRepository;
        $this->memberRepository = $memberRepository;
        $this->specialAuthorityRepository = $specialAuthorityRepository;
        $this->stockListStorehouseUnitRepository = $stockListStorehouseUnitRepository;
        $this->productRepository = $productRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/payee_management/payee_voucher_detail_phone", name="admin_payee_voucher_detail_phone")
     * @Route("/%eccube_admin_route%/payee_management/payee_voucher_detail_phone/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_payee_voucher_detail_phone_page")
     * @Route("/%eccube_admin_route%/payee_management/payee_voucher_detail_phone/{id}", requirements={"id" = "\d+"}, name="admin_detail_payee_voucher_no_phone")
     * @Route("/%eccube_admin_route%/payee_management/payee_voucher_detail_phone/product_id/{productId}", requirements={"productId" = "\d+"}, name="admin_payee_voucher_detail_product_id_phone")
     * @Route("/%eccube_admin_route%/payee_management/payee_voucher_detail_phone/serial_id/{serial_id}", requirements={"serial_id" = "\d+"}, name="admin_payee_voucher_detail_serial_id_phone")
     * @Template("@admin/PayeeVoucher/payee_voucher_detail_phone.twig")
     *
     * @param Request $request Request
     * @param null $page_no page no
     * @param Paginator $paginator Paginator
     * @param null $id id
     * @return array
     */
    public function index(Request $request, $page_no = null, Paginator $paginator, $id = null, $serial_id = null, $productId = null)
    {
        // 前ページurl
        $link = $request->headers->get('referer');

        if (strpos($link, self::PAYEElIST_PAGE_URL)) {
            //仕入伝票一覧から
            // 前ページurl
            $controls_enable['back_to_list_display'] = 1;
            $controls_enable['back_to_list_url'] = self::BACK_TO_LIST_URL_PAYEE;
            $controls_enable['back_to_list_name'] = self::BACK_TO_LIST_NAME_PAYEE;
        } else if (strpos($link, self::PREVIOUS_PAGE_URL_BALANCE)) {
            //仕入出金残高から
            // 前ページurl
            $controls_enable['back_to_list_display'] = 1;
            $controls_enable['back_to_list_url'] = self::BACK_TO_LIST_URL_BALANCE;
            $controls_enable['back_to_list_name'] = self::BACK_TO_LIST_NAME_BALANCE;
        } else {
            $controls_enable['back_to_list_display'] = 0;
        }
        $builder = $this->formFactory
            ->createBuilder(PayeeVoucherItemType ::class);
        $member = $this->getUser();

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_MANAGEMENT_PAYEE_VOUCHER_DETAIL_INDEX_INITIALIZE, $event);

        $searchForm = $builder->getForm();

        // 仕入先検索フォーム
        $builder = $this->formFactory
            ->createBuilder(SearchPayeeMstType::class);
        $searchPayeeMstModalForm = $builder->getForm();

        // 担当者検索フォーム
        $builder = $this->formFactory
            ->createBuilder(SearchMemberType::class);
        $searchMemberModalForm = $builder->getForm();

        /**
         * ページの表示件数は, 以下の順に優先される.
         * - リクエストパラメータ
         * - セッション
         * - デフォルト値
         * また, セッションに保存する際は mtb_page_maxと照合し, 一致した場合のみ保存する.
         **/
        $page_count = $this->session->get('eccube.admin.payee_detail.phone.search.page_count',
            $this->eccubeConfig->get('eccube_default_page_count'));

        $page_count_param = (int) $request->get('page_count');
        $pageMaxis = $this->pageMaxRepository->findAll();

        $memo = '';
        $personnelmemo = '';
        $memoflg = '0';

        if ($page_count_param) {
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.admin.payee_detail.phone.search.page_count', $page_count);
                    break;
                }
            }
        }

        $page_no_bk = $page_no;
        if ('POST' === $request->getMethod()) {
            $searchForm->handleRequest($request);

            if ($searchForm->isValid()) {
                /**
                 * 検索が実行された場合は, セッションに検索条件を保存する.
                 * ページ番号は最初のページ番号に初期化する.
                 */
                $page_no = 1;
                $searchData = $searchForm->getData();
                // 検索条件, ページ番号をセッションに保持.
                $this->session->set('eccube.admin.payee_detail.phone.search', FormUtil::getViewData($searchForm));
                $this->session->set('eccube.admin.payee_detail.phone.search.page_no', $page_no);
            } else {
                // 検索エラーの際は, 詳細検索枠を開いてエラー表示する.
                return [
                    'searchForm' => $searchForm->createView(),
                    'searchPayeeMstModalForm' => $searchPayeeMstModalForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $page_count,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.admin.payee_detail.phone.search.page_no', (int) $page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.admin.payee_detail.phone.search.page_no', 1);
                }
                $viewData = $this->session->get('eccube.admin.payee_detail.phone.search', []);
            } else {
                /**
                 * 初期表示の場合.
                 */
                $page_no = 1;
                // main category
                $categories = $this->categoryRepository->getList(null, false);
                $mainCategory = null;
                foreach ($categories as $Category) {
                    if ($Category && ($Category->getHierarchy() == 1)) {
                        $mainCategory = $Category;
                        break;
                    }
                }

                if ($id == null && $serial_id == null && $productId == null) {
                    $viewData['purchase_date_end'] = date('Y-m-d', strtotime('now'));
                    $viewData['purchase_date_start'] = date('Y-m-d', strtotime('now'));

                } else if ($productId != null) {
                    $product = $this->productRepository->find($productId);
                    $productCode = $product->getProductClasses()[0]['code'];

                    $viewData['product_code'] = $productCode;
                    $viewData['purchase_date_end'] = date('Y-m-d', strtotime('now'));
                    $viewData['purchase_date_start'] = date('Y-m-d', strtotime('- 180 days'));
                } else if ($serial_id != null) {
                    $serialNoInfo = $this->stockListStorehouseUnitRepository->find($serial_id);
                    $serialNo = $serialNoInfo->getSerialNo();

                    $viewData['serial'] = $serialNo;
                } else {
                    /**
                     * 仕入伝票一覧から遷移の場合.
                     */
                    $qbNo = $this->getSearchPayeeVoucherNo($id);
                    $viewData['payee_voucher_no'] = $qbNo[0]['payee_voucher_no'];
                    $memo = $qbNo[0]['memo'];
                    $personnelmemo = $qbNo[0]['personnel_memo'];
                    $memoflg = '1';
                }
            }
            // セッション中の検索条件, ページ番号を初期化.
            $this->session->set('eccube.admin.payee_detail.phone.search', $viewData);
            $this->session->set('eccube.admin.payee_detail.phone.search.page_no', $page_no);
            $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
        }

        $qb = [];
        if ('POST' === $request->getMethod() || null !== $page_no_bk){
            if ($searchData['total_mode']) {
                /** @var QueryBuilder $qb */
                $qb = $this->getSearchTotalData($searchData);
            } else {
                /** @var QueryBuilder $qb */
                $qb = $this->getSearchData($searchData);
            }
        }

        // 権限
        $authority = $this->specialAuthorityRepository->isValidAuthority($member);

        $payeeMoneyTotalAmount = 0;
        foreach ($qb as &$payee) {
            $payeeMoneyTotalAmount = $payeeMoneyTotalAmount + $payee['payee_money_amount'];

            $payee['purchase_date'] = $this->makeDateStringUtcToAsiaTokyo($payee['purchase_date']);
            $payee['update_date'] = $this->makeDateStringUtcToAsiaTokyo($payee['update_date']);
            $payee['sales_date'] = $this->makeDateStringUtcToAsiaTokyo($payee['sales_date']);
            $payee['0'] = $payee['purchase_date'];
            $payee['13'] = $payee['update_date'];
            $payee['19'] = $payee['sales_date'];

            if (!$authority) {
                if ($payee['create_date'] >= date('Y-m-d', strtotime('- 5 days')) &&
                    $payee['create_date'] <= date('Y-m-d', strtotime('5 days'))) {
                    $payee['authority'] = true;
                } else {
                    $payee['authority'] = false;
                }
            } else {
                $payee['authority'] = true;
            }
        }
        $sort_orders = $this->sortOrder($qb, $searchData);

        $event = new EventArgs(
            [
                'qb' => $qb,
                'searchData' => $searchData,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_MANAGEMENT_PAYEE_VOUCHER_DETAIL_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $page_count
        );

        return [
            'searchForm' => $searchForm->createView(),
            'searchPayeeMstModalForm' => $searchPayeeMstModalForm->createView(),
            'searchMemberModalForm' => $searchMemberModalForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'has_errors' => false,
            'request' => $request,
            'payeeMoneyTotalAmount' => $payeeMoneyTotalAmount,
            'ControlsEnable' => $controls_enable,
            'link' => $link,
            'memo'=> $memo,
            'personnelmemo'=> $personnelmemo,
            'memoflg' => $memoflg,
        ];
    }
    /**
     * 仕入伝票明細.
     *
     * @param $searchData
     *
     * @return mixed[]
     */
    public function getSearchData($searchData)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();
        $sql = '
                 SELECT
                    pvh.purchase_date,
                    ps.payee_code,
                    ps.id AS payeeId,
                    ps.payee_name AS payeeName,
                    pvh.payee_voucher_no,
                    pvd.product_code,
                    pp.name AS productName,
                    sa.state AS stateName,
                    pvd.serial_no,
                    pvd.quantity,
                    pvd.payee_price,
                    pvd.payee_money_amount,
                    pa.place,
                    pvd.update_date,
                    mb.id AS personnelMemoId,
                    mb.name AS personnelMemoName,
                    sd.customer_code,
                    sd.customerName,
                    sd.totalSalesAmount,
                    sd.sales_date,
                    pvh.update_user_name,
                    pvd.payee_detail_no,
                    dc4.category_id AS category_id1,
                    CASE WHEN oic.id IS NULL THEN dc4.categoryName ELSE NULL END AS categoryName1,
                    dc5.category_id AS category_id2,
                    CASE WHEN oic.id IS NULL THEN dc5.categoryName ELSE NULL END AS categoryName2,
                    dc6.category_id AS category_id3,
                    CASE WHEN oic.id IS NULL THEN dc6.categoryName ELSE NULL END AS categoryName3,
                    pvd.payee_voucher_header_id,
                    pvd.create_date

                FROM dtb_payee_voucher_detail pvd
                INNER JOIN dtb_payee_voucher_header pvh
                ON pvd.payee_voucher_header_id = pvh.id

                LEFT JOIN (
                SELECT
                t.payee_voucher_header_id,
                t.payee_voucher_no,
                t.payee_detail_no,
                t.serial_no,
                svdl.sales_voucher_header_id,
                svdl.sales_voucher_no,
                svdl.sales_details_no,
                cm.customer_code,
                cm.customer_name AS customerName,
                svd.total_sales_amount AS totalSalesAmount,
                svh.sales_date
                FROM (SELECT * FROM dtb_payee_voucher_detail pvd
                WHERE  pvd.serial_no is not null) t
                
                INNER JOIN dtb_sales_voucher_detail_link svdl
                ON svdl.payee_voucher_header_id = t.payee_voucher_header_id 
                AND svdl.payee_voucher_no = t.payee_voucher_no
                AND svdl.payee_details_no = t.payee_detail_no 
                
                INNER JOIN dtb_sales_voucher_detail svd
                ON svd.sales_voucher_header_id = svdl.sales_voucher_header_id
                AND svd.sales_voucher_no = svdl.sales_voucher_no
                AND svd.sales_details_no = svdl.sales_details_no
                
                INNER JOIN dtb_sales_voucher_header svh
                ON svh.id=svd.sales_voucher_header_id               
                
                INNER JOIN mtb_customer_mst cm
                ON cm.id=svh.customer_id
                 ) AS sd
                 
                ON pvd.payee_voucher_no = sd.payee_voucher_no
                AND pvd.payee_detail_no = sd.payee_detail_no
                AND pvd.payee_voucher_header_id = sd.payee_voucher_header_id
                
                INNER JOIN mtb_payee_mst ps
                ON ps.id = pvh.payee_code

                INNER JOIN dtb_product pp
                ON pp.id = pvd.product_id

                INNER JOIN mtb_place pa
                ON pa.id = pvh.storehouse_id 

                INNER JOIN dtb_member mb
                ON mb.id = pvh.personnel_id

                INNER JOIN dtb_product dp 
                ON pvd.product_id = dp.id

                INNER Join ( 
                    SELECT
                        dpvds.id,
                        dpcs.category_id,
                        dcs.category_name AS categoryName,
                        dcs.hierarchy 
                    FROM
                        dtb_payee_voucher_detail dpvds
                        INNER JOIN dtb_product dps
                            ON dpvds.product_id = dps.id
                        INNER JOIN dtb_product_category dpcs
                            ON dpvds.product_id = dpcs.product_id
                        INNER JOIN dtb_category dcs
                            ON dcs.id = dpcs.category_id
                         WHERE dpcs.category_sub_flag <> 1
                ) AS dc4
                ON dc4.id = pvd.id
                AND dc4.hierarchy = 1

                LEFT JOIN mtb_state sa
                  ON sa.id = pvd.state_id
                
                LEFT JOIN mtb_other_item_code_change oic
                  ON oic.name = pvd.product_code

                LEFT JOIN ( 
                    SELECT
                        dpvds.id,
                        dpcs.category_id,
                        dcs.category_name AS categoryName,
                        dcs.hierarchy 
                    FROM
                        dtb_payee_voucher_detail dpvds
                        INNER JOIN dtb_product dps
                            ON dpvds.product_id = dps.id
                        INNER JOIN dtb_product_category dpcs
                            ON dpvds.product_id = dpcs.product_id
                        INNER JOIN dtb_category dcs
                            ON dcs.id = dpcs.category_id
                         WHERE dpcs.category_sub_flag <>1
                ) AS dc5 
                ON dc5.id = pvd.id 
                AND dc5.hierarchy = 2

                LEFT JOIN ( 
                    SELECT
                        dpvds.id,
                        dpcs.category_id,
                        dcs.category_name AS categoryName,
                        dcs.hierarchy 
                    FROM
                        dtb_payee_voucher_detail dpvds
                        INNER JOIN dtb_product dps
                            ON dpvds.product_id = dps.id
                        INNER JOIN dtb_product_category dpcs
                            ON dpvds.product_id = dpcs.product_id
                        INNER JOIN dtb_category dcs
                            ON dcs.id = dpcs.category_id
                         WHERE dpcs.category_sub_flag <>1
                ) AS dc6 
                ON dc6.id = pvd.id 
                AND dc6.hierarchy = 3 
                WHERE TRUE
            ';

        $flg = false;

        //serial
        if (isset($searchData['serial']) && StringUtil::isNotBlank($searchData['serial'])) {
            $sql = $sql.' AND  pvd.serial_no LIKE '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['serial']))."%'";
            $flg = true;
        }

        //payee_voucher_no
        if (isset($searchData['payee_voucher_no']) && StringUtil::isNotBlank($searchData['payee_voucher_no'])) {
            $sql = $sql.' AND  pvh.payee_voucher_no LIKE '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['payee_voucher_no']))."%'";
            $flg = true;
        }

        if ($flg != true) {
            //product_code
            if (isset($searchData['product_code']) && StringUtil::isNotBlank($searchData['product_code'])) {
                $sql = $sql.' AND  pvd.product_code LIKE '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['product_code']))."%'";
            }
            //place
            if (isset($searchData['Place']) && StringUtil::isNotBlank($searchData['Place'])) {
                $sql = $sql.' AND pa.id='."'".$searchData['Place']->getId()."'";
            }

            //product_name
            if (isset($searchData['product_name']) && StringUtil::isNotBlank($searchData['product_name'])) {
                $sql = $sql.' AND  pp.name LIKE '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['product_name']))."%'";
            }

            //serial
            if (isset($searchData['serial']) && StringUtil::isNotBlank($searchData['serial'])) {
                $sql = $sql.' AND  pvd.serial_no LIKE '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['serial']))."%'";
            }

            //personnel_memo
            if (isset($searchData['personnel_memo']) && StringUtil::isNotBlank($searchData['personnel_memo'])) {
                $sql = $sql.' AND   mb.id = '.$searchData['personnelMemoId'];
            }

            //payeeName
            if (isset($searchData['payeeName']) && StringUtil::isNotBlank($searchData['payeeName'])) {
                $sql = $sql.' AND  ps.id = '.$searchData['payeeId'];
            }

            //purchase_date_start
            if (isset($searchData['purchase_date_start']) && StringUtil::isNotBlank($searchData['purchase_date_start'])) {
                /** @var \DateTime $purchase_date_start */
                $purchase_date_start = $searchData['purchase_date_start'];
                $purchaseDateStart = $purchase_date_start->setTime('0', '0', '0')
                    ->setTimezone(new \DateTimeZone('UTC'))
                    ->format('Y-m-d H:i:s');
                $sql = $sql.' AND  pvh.purchase_date >= \''.$purchaseDateStart.'\'';
            }

            //purchase_date_end
            if (isset($searchData['purchase_date_end']) && StringUtil::isNotBlank($searchData['purchase_date_end'])) {
                /** @var \DateTime $purchase_date_end */
                $purchase_date_end = $searchData['purchase_date_end'];
                $purchaseDateEnd = $purchase_date_end->setTime('23', '59', '59')
                    ->setTimezone(new \DateTimeZone('UTC'))
                    ->format('Y-m-d H:i:s');
                $sql = $sql.' AND  pvh.purchase_date <= \''.$purchaseDateEnd.'\'';
            }

            // mainCategory
            if (isset($searchData['main_category_id']) && !empty($searchData['main_category_id']) && $searchData['main_category_id']) {
                $Category = $searchData['main_category_id'];
                $category_id = 'category_id_'.$Category->getId();
                if (isset($searchData[$category_id]) && !empty($searchData[$category_id]) && $searchData[$category_id]) {
                    $Categories = $searchData[$category_id]->getSelfAndDescendants();
                } else {
                    $Categories = $Category->getSelfAndDescendants();
                }
                if ($Categories) {
                    $sql = $sql.'AND dc4.category_id='."'".$searchData['main_category_id']['id']."'";
                    if ($searchData[$category_id]) {
                        if ($searchData[$category_id]['hierarchy'] == '2') {
                            $sql = $sql.'AND  dc5.category_id='."'".$searchData[$category_id]['id']."'";
                        } else {
                            $sql = $sql.'AND  dc6.category_id='."'".$searchData[$category_id]['id']."'";
                        }
                    }
                }
            }
        }
        $sql = $sql.' ORDER BY 
        pvh.purchase_date DESC
        ,pvd.update_date DESC
        ,ps.payee_name
        ,pvh.payee_voucher_no
        ';

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    /**
     * 仕入伝票明細.
     *
     * @param $id
     *
     * @return mixed[]
     */
    public function getSearchPayeeVoucherNo($id)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();
        $sql = ' SELECT DISTINCT pvd.payee_voucher_no,
                 pvd.payee_voucher_header_id,
                 pvh.id,
                 pvh.memo,
                 pvh.personnel_memo
                 FROM dtb_payee_voucher_detail pvd                
                 INNER JOIN dtb_payee_voucher_header pvh
                 ON pvd.payee_voucher_header_id = pvh.id               
                 WHERE TRUE
                 ';
        $sql = $sql.' AND pvd.payee_voucher_header_id='."'".$id."'";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    /**
     * ソート.
     * @param $orders
     * @param $searchData
     * @return mixed
     */
    private function sortOrder($orders, $searchData)
    {
        if ($searchData['sort_by']) {
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case '仕入日':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == '降順') {
                            return $a["purchase_date"] > $b["purchase_date"] ? -1 : 1;
                        }
                        return $a["purchase_date"] < $b["purchase_date"] ? -1 : 1;
                    });
                    break;
                case '仕入先名':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == '降順') {
                            return $a["payeeName"] > $b["payeeName"] ? -1 : 1;
                        }
                        return $a["payeeName"] < $b["payeeName"] ? -1 : 1;
                    });
                    break;
                case '伝票番号':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == '降順') {
                            return $a["payee_voucher_no"] > $b["payee_voucher_no"] ? -1 : 1;
                        }
                        return $a["payee_voucher_no"] < $b["payee_voucher_no"] ? -1 : 1;
                    });
                    break;
                case '状態':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == '降順') {
                            return $a["stateName"] > $b["stateName"] ? -1 : 1;
                        }
                        return $a["stateName"] < $b["stateName"] ? -1 : 1;
                    });
                    break;
                case '得意先名':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == '降順') {
                            return $a['customerName'] > $b['customerName'] ? -1 : 1;
                        }
                        return $a['customerName'] < $b['customerName'] ? -1 : 1;
                    });
                    break;
                case '商品コード':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == '降順') {
                            return $a["product_code"] > $b["product_code"] ? -1 : 1;
                        }
                        return $a["product_code"] < $b["product_code"] ? -1 : 1;
                    });
                    break;
                case '商品名':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == '降順') {
                            return $a["productName"] > $b["productName"] ? -1 : 1;
                        }
                        return $a["productName"] < $b["productName"] ? -1 : 1;
                    });
                    break;
                case 'シリアル':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == '降順') {
                            return $a["serial_no"] > $b["serial_no"] ? -1 : 1;
                        }
                        return $a["serial_no"] < $b["serial_no"] ? -1 : 1;
                    });
                    break;
            }
        }
        return $orders;
    }

    /**
     * UTC時間を東京時間にする
     * @param string|null $date 時間文字列(yyyy-mm-dd HH:ii:ss)
     * @return string
     */
    public function makeDateStringUtcToAsiaTokyo(string $date = null)
    {
        if (!$date || $date !== date('Y-m-d H:i:s', strtotime($date))) {
            return '';
        }

        try {
            $date_utc = new \DateTime($date, new \DateTimeZone('UTC'));
            $date_asia_tokyo = $date_utc
                ->setTimezone(new \DateTimeZone('Asia/Tokyo'))
                ->format('Y-m-d H:i:s');
        } catch (\Exception $exception) {
            return '';
        }

        return $date_asia_tokyo;
    }

    /**
     * 仕入伝票集計表示.
     *
     * @param $searchData
     *
     * @return mixed[]
     */
    public function getSearchTotalData($searchData)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();
        $sql = '
                 SELECT
                    \'\' AS purchase_date,
                    \'\' AS payee_code,
                    \'\' AS payeeId,
                    \'\' AS payeeName,
                    \'\' AS payee_voucher_no,
                    pvd.product_code,
                    pp.name AS productName,
                    sa.state AS stateName,
                    \'\' AS serial_no,
                    sum(pvd.quantity) AS quantity,
                    pvd.payee_price,
                    sum(pvd.payee_money_amount) AS payee_money_amount,
                    \'\' AS place,
                    \'\' AS update_date,
                    \'\' AS personnelMemoId,
                    \'\' AS personnelMemoName,
                    \'\' AS customer_code,
                    \'\' AS customerName,
                    \'\' AS totalSalesAmount,
                    \'\' AS sales_date,
                    \'\' AS update_user_name,
                    \'\' AS payee_detail_no,
                    dc4.category_id AS category_id1,
                    CASE WHEN oic.id IS NULL THEN dc4.categoryName ELSE NULL END AS categoryName1,
                    dc5.category_id AS category_id2,
                    CASE WHEN oic.id IS NULL THEN dc5.categoryName ELSE NULL END AS categoryName2,
                    dc6.category_id AS category_id3,
                    CASE WHEN oic.id IS NULL THEN dc6.categoryName ELSE NULL END AS categoryName3,
                    pvd.payee_voucher_header_id,
                    pvd.create_date

                FROM dtb_payee_voucher_detail pvd
                INNER JOIN dtb_payee_voucher_header pvh
                ON pvd.payee_voucher_header_id = pvh.id

                LEFT JOIN (
                SELECT
                t.payee_voucher_header_id,
                t.payee_voucher_no,
                t.payee_detail_no,
                t.serial_no,
                svdl.sales_voucher_header_id,
                svdl.sales_voucher_no,
                svdl.sales_details_no,
                cm.customer_code,
                cm.customer_name AS customerName,
                svd.total_sales_amount AS totalSalesAmount,
                svh.sales_date
                FROM (SELECT * FROM dtb_payee_voucher_detail pvd
                WHERE  pvd.serial_no is not null) t
                
                INNER JOIN dtb_sales_voucher_detail_link svdl
                ON svdl.payee_voucher_header_id = t.payee_voucher_header_id 
                AND svdl.payee_voucher_no = t.payee_voucher_no
                AND svdl.payee_details_no = t.payee_detail_no 
                
                INNER JOIN dtb_sales_voucher_detail svd
                ON svd.sales_voucher_header_id = svdl.sales_voucher_header_id
                AND svd.sales_voucher_no = svdl.sales_voucher_no
                AND svd.sales_details_no = svdl.sales_details_no
                
                INNER JOIN dtb_sales_voucher_header svh
                ON svh.id=svd.sales_voucher_header_id               
                
                INNER JOIN mtb_customer_mst cm
                ON cm.id=svh.customer_id
                 ) AS sd
                 
                ON pvd.payee_voucher_no = sd.payee_voucher_no
                AND pvd.payee_detail_no = sd.payee_detail_no
                AND pvd.payee_voucher_header_id = sd.payee_voucher_header_id
                
                INNER JOIN mtb_payee_mst ps
                ON ps.id = pvh.payee_code

                INNER JOIN dtb_product pp
                ON pp.id = pvd.product_id

                INNER JOIN mtb_place pa
                ON pa.id = pvh.storehouse_id 

                INNER JOIN dtb_member mb
                ON mb.id = pvh.personnel_id

                INNER JOIN dtb_product dp 
                ON pvd.product_id = dp.id

                INNER Join ( 
                    SELECT
                        dpvds.id,
                        dpcs.category_id,
                        dcs.category_name AS categoryName,
                        dcs.hierarchy 
                    FROM
                        dtb_payee_voucher_detail dpvds
                        INNER JOIN dtb_product dps
                            ON dpvds.product_id = dps.id
                        INNER JOIN dtb_product_category dpcs
                            ON dpvds.product_id = dpcs.product_id
                        INNER JOIN dtb_category dcs
                            ON dcs.id = dpcs.category_id
                         WHERE dpcs.category_sub_flag <> 1
                ) AS dc4
                ON dc4.id = pvd.id
                AND dc4.hierarchy = 1

                LEFT JOIN mtb_state sa
                  ON sa.id = pvd.state_id
                
                LEFT JOIN mtb_other_item_code_change oic
                  ON oic.name = pvd.product_code

                LEFT JOIN ( 
                    SELECT
                        dpvds.id,
                        dpcs.category_id,
                        dcs.category_name AS categoryName,
                        dcs.hierarchy 
                    FROM
                        dtb_payee_voucher_detail dpvds
                        INNER JOIN dtb_product dps
                            ON dpvds.product_id = dps.id
                        INNER JOIN dtb_product_category dpcs
                            ON dpvds.product_id = dpcs.product_id
                        INNER JOIN dtb_category dcs
                            ON dcs.id = dpcs.category_id
                         WHERE dpcs.category_sub_flag <>1
                ) AS dc5 
                ON dc5.id = pvd.id 
                AND dc5.hierarchy = 2

                LEFT JOIN ( 
                    SELECT
                        dpvds.id,
                        dpcs.category_id,
                        dcs.category_name AS categoryName,
                        dcs.hierarchy 
                    FROM
                        dtb_payee_voucher_detail dpvds
                        INNER JOIN dtb_product dps
                            ON dpvds.product_id = dps.id
                        INNER JOIN dtb_product_category dpcs
                            ON dpvds.product_id = dpcs.product_id
                        INNER JOIN dtb_category dcs
                            ON dcs.id = dpcs.category_id
                         WHERE dpcs.category_sub_flag <>1
                ) AS dc6 
                ON dc6.id = pvd.id 
                AND dc6.hierarchy = 3 
                WHERE TRUE
            ';

        //product_code
        if (isset($searchData['product_code']) && StringUtil::isNotBlank($searchData['product_code'])) {
            $sql = $sql.' AND  pvd.product_code LIKE '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['product_code']))."%'";
        }
        //place
        if (isset($searchData['Place']) && StringUtil::isNotBlank($searchData['Place'])) {
            $sql = $sql.' AND pa.id='."'".$searchData['Place']->getId()."'";
        }

        //product_name
        if (isset($searchData['product_name']) && StringUtil::isNotBlank($searchData['product_name'])) {
            $sql = $sql.' AND  pp.name LIKE '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['product_name']))."%'";
        }

        //personnel_memo
        if (isset($searchData['personnel_memo']) && StringUtil::isNotBlank($searchData['personnel_memo'])) {
            $sql = $sql.' AND   mb.id = '.$searchData['personnelMemoId'];
        }

        //payeeName
        if (isset($searchData['payeeName']) && StringUtil::isNotBlank($searchData['payeeName'])) {
            $sql = $sql.' AND  ps.id = '.$searchData['payeeId'];
        }

        //purchase_date_start
        if (isset($searchData['purchase_date_start']) && StringUtil::isNotBlank($searchData['purchase_date_start'])) {
            /** @var \DateTime $purchase_date_start */
            $purchase_date_start = $searchData['purchase_date_start'];
            $purchaseDateStart = $purchase_date_start->setTime('0', '0', '0')
                ->setTimezone(new \DateTimeZone('UTC'))
                ->format('Y-m-d H:i:s');
            $sql = $sql.' AND  pvh.purchase_date >= \''.$purchaseDateStart.'\'';
        }

        //purchase_date_end
        if (isset($searchData['purchase_date_end']) && StringUtil::isNotBlank($searchData['purchase_date_end'])) {
            /** @var \DateTime $purchase_date_end */
            $purchase_date_end = $searchData['purchase_date_end'];
            $purchaseDateEnd = $purchase_date_end->setTime('23', '59', '59')
                ->setTimezone(new \DateTimeZone('UTC'))
                ->format('Y-m-d H:i:s');
            $sql = $sql.' AND  pvh.purchase_date <= \''.$purchaseDateEnd.'\'';
        }

        // mainCategory
        if (isset($searchData['main_category_id']) && !empty($searchData['main_category_id']) && $searchData['main_category_id']) {
            $Category = $searchData['main_category_id'];
            $category_id = 'category_id_'.$Category->getId();
            if (isset($searchData[$category_id]) && !empty($searchData[$category_id]) && $searchData[$category_id]) {
                $Categories = $searchData[$category_id]->getSelfAndDescendants();
            } else {
                $Categories = $Category->getSelfAndDescendants();
            }
            if ($Categories) {
                $sql = $sql.'AND dc4.category_id='."'".$searchData['main_category_id']['id']."'";
                if ($searchData[$category_id]) {
                    if ($searchData[$category_id]['hierarchy'] == '2') {
                        $sql = $sql.'AND  dc5.category_id='."'".$searchData[$category_id]['id']."'";
                    } else {
                        $sql = $sql.'AND  dc6.category_id='."'".$searchData[$category_id]['id']."'";
                    }
                }
            }
        }

        $sql = $sql.' GROUP BY 
        pvd.product_code
        ,pvd.state_id
        ,pvd.payee_price
        ORDER BY 
        pvd.update_date DESC
        ,pvh.purchase_date
        ,ps.payee_name
        ,pvh.payee_voucher_no
        ';

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }
}
