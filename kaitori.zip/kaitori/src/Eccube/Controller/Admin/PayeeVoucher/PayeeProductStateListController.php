<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\PayeeVoucher;

use Eccube\Controller\AbstractController;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\PayeeProductStateRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\StateRepository;
use Eccube\Util\FormUtil;
use Knp\Component\Pager\Paginator;
use Symfony\Component\HttpFoundation\Request;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\Routing\Annotation\Route;
use Eccube\Form\Type\Admin\PayeeProductStateListType;

/**
 *プログラム名 ： PayeeProductStateListController.php
 *概　　要     ： 仕入商品状態一覧
 *作　　成     ： 2022/9/5 CNC
 */
class PayeeProductStateListController extends AbstractController
{
    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;

    /**
     * @var StateRepository
     */
    protected $stateRepository;

    /**
     * @var PayeeProductStateRepository
     */
    protected $PayeeProductStateRepository;

    /**
     * ProductController constructor.
     *
     * @param CategoryRepository $categoryRepository
     * @param ProductRepository $productRepository
     * @param PageMaxRepository $pageMaxRepository
     * @param StateRepository $stateRepository
     * @param PayeeProductStateRepository $PayeeProductStateRepository
     */
    public function __construct(
        CategoryRepository $categoryRepository,
        ProductRepository $productRepository,
        PageMaxRepository $pageMaxRepository,
        StateRepository $stateRepository,
        PayeeProductStateRepository $PayeeProductStateRepository
    ) {
        $this->categoryRepository = $categoryRepository;
        $this->productRepository = $productRepository;
        $this->pageMaxRepository = $pageMaxRepository;
        $this->stateRepository = $stateRepository;
        $this->PayeeProductStateRepository = $PayeeProductStateRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/payee_management/payee_product_state_list", name="admin_payee_payee_product_state_list")
     * @Route("/%eccube_admin_route%/payee_management/payee_product_state_list/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_payee_payee_product_state_list_page")
     * @Template("@admin/PayeeVoucher/payee_product_state_list.twig")
     */
    public function index(Request $request, $page_no = null, Paginator $paginator)
    {
        $builder = $this->formFactory
            ->createBuilder(PayeeProductStateListType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_PRODUCT_STATE_LIST_INDEX_INITIALIZE, $event);

        $searchForm = $builder->getForm();

        /**
         * ページの表示件数は, 以下の順に優先される.
         * - リクエストパラメータ
         * - セッション
         * - デフォルト値
         * また, セッションに保存する際は mtb_page_maxと照合し, 一致した場合のみ保存する.
         **/
        $page_count = $this->session->get('eccube.admin.payee_management.search.page_count',
            $this->eccubeConfig->get('eccube_mltext_len'));

        $page_count_param = (int) $request->get('page_count');
        $pageMaxis = $this->pageMaxRepository->findAll();

        if ($page_count_param) {
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.admin.payee_management.search.page_count', $page_count);
                    break;
                }
            }
        }

        // 状態
        $stateList = $this->stateRepository->getStateByCategory();

        $page_no_bk = $page_no;
        if ('POST' === $request->getMethod()) {
            $searchForm->handleRequest($request);

            if ($searchForm->isValid()) {
                /**
                 * 検索が実行された場合は, セッションに検索条件を保存する.
                 * ページ番号は最初のページ番号に初期化する.
                 */
                $page_no = 1;
                $searchData = $searchForm->getData();

                // 検索条件, ページ番号をセッションに保持.
                $this->session->set('eccube.admin.payee_management.search', FormUtil::getViewData($searchForm));
                $this->session->set('eccube.admin.payee_management.search.page_no', $page_no);
            } else {
                // 検索エラーの際は, 詳細検索枠を開いてエラー表示する.
                return [
                    'searchForm' => $searchForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $page_count,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.admin.payee_management.search.page_no', (int) $page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.admin.payee_management.search.page_no', 1);
                }
                $viewData = $this->session->get('eccube.admin.payee_management.search', []);
                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
            } else {
                /**
                 * 初期表示の場合.
                 */
                $page_no = 1;

                // main category
                $categories = $this->categoryRepository->getList(null, false);
                $mainCategory = null;
                foreach($categories as $Category) {
                    if ($Category && ($Category->getHierarchy() == 1) ) {
                        $mainCategory = $Category;
                        break;
                    }
                }

                $viewData = FormUtil::getViewData($searchForm);

                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);

                // セッション中の検索条件, ページ番号を初期化.
                $this->session->set('eccube.admin.payee_management.search', $viewData);
                $this->session->set('eccube.admin.payee_management.search.page_no', $page_no);
            }
        }

        $qb = '';
        $all_orders = [];
        if ('POST' === $request->getMethod() || null !== $page_no_bk){
            $qb = $this->PayeeProductStateRepository->getQueryBuilderBySearchDataForAdmin($searchData);
            $all_orders = $qb->getQuery()->getResult();
        }

        $sort_orders = $this->sortOrder($all_orders, $searchData);

        $event = new EventArgs(
            [
                'qb' => $qb,
                'searchData' => $searchData,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_PRODUCT_STATE_LIST_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $page_count
        );

        return [
            'searchForm' => $searchForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'has_errors' => false,
            'request' => $request,
            'StateList' => $stateList,
        ];
    }

    private function sortOrder($orders, $searchData) {
        if ($searchData['sort_by']) {
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case '商品コード':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == "降順") {
                            return $a["productCode"] > $b["productCode"] ? -1 : 1;
                        }
                        return $a["productCode"] < $b["productCode"] ? -1 : 1;
                    });
                    break;
                case '状態':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == "降順") {
                            return $a["state"] > $b["state"] ? -1 : 1;
                        }
                        return $a["state"] < $b["state"] ? -1 : 1;
                    });
                    break;
            }
        }
        return $orders;
    }
}
