<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\PayeeVoucher;

use Eccube\Controller\AbstractController;
use Eccube\Entity\Master\CsvType;
use Eccube\Entity\Master\PayingStatus;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\PayeeVoucherListType;
use Eccube\Form\Type\Admin\SearchMemberType;
use Eccube\Form\Type\Admin\SearchPayeeMstType;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\Master\SpecialAuthorityRepository;
use Eccube\Repository\MemberRepository;
use Eccube\Repository\OrderRepository;
use Eccube\Repository\PayeeMstRepository;
use Eccube\Repository\PayeeVoucherHeaderRepository;
use Eccube\Service\CsvExportService;
use Eccube\Service\PayeeVoucherPdfService;
use Eccube\Util\FormUtil;
use Knp\Component\Pager\Paginator;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： PayeeVoucherListController.php
 *概　　要     ： 仕入伝票一覧
 *作　　成     ： 2021/7/9 CNC
 */
class PayeeVoucherListController extends AbstractController
{
    /**
     * @var PayeeVoucherHeaderRepository
     */
    protected $pageMaxRepository;
    /**
     * @var PayeeVoucherHeaderRepository
     */
    protected $payeeVoucherHeaderRepository;

    /**
     * @var PayeeMstRepository
     */
    protected $payeeMstRepository;

    /**
     * @var MemberRepository
     */
    protected $memberRepository;

    /**
     * @var SpecialAuthorityRepository
     */
    protected $specialAuthorityRepository;

    /**
     * @var CsvExportService
     */
    protected $csvExportService;

    /**
     * @var OrderRepository
     */
    protected $orderRepository;

    public function __construct(
        CsvExportService $csvExportService,
        PageMaxRepository $pageMaxRepository,
        PayeeVoucherHeaderRepository $payeeVoucherHeaderRepository,
        PayeeMstRepository $payeeMstRepository,
        MemberRepository $memberRepository,
        SpecialAuthorityRepository $specialAuthorityRepository,
        OrderRepository $orderRepository
    ) {
        $this->csvExportService = $csvExportService;
        $this->pageMaxRepository = $pageMaxRepository;
        $this->payeeVoucherHeaderRepository = $payeeVoucherHeaderRepository;
        $this->payeeMstRepository = $payeeMstRepository;
        $this->memberRepository = $memberRepository;
        $this->specialAuthorityRepository = $specialAuthorityRepository;
        $this->orderRepository = $orderRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/payee_management/payee_voucher_list", name="admin_payee_voucher_list")
     * @Route("/%eccube_admin_route%/payee_management/payee_voucher_list/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_payee_voucher_list_page")
     * @Template("@admin/PayeeVoucher/payee_voucher_list.twig")
     *
     * @param Request $request
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function index(Request $request, $page_no = null, Paginator $paginator)
    {
        $session = $this->session;
        $builder = $this->formFactory
            ->createBuilder(PayeeVoucherListType::class, null);
        $member = $this->getUser();

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_MANAGEMENT_PAYEE_VOUCHER_LIST_INDEX_INITIALIZE, $event);

        $pageMaxis = $this->pageMaxRepository->findAll();
        $pageCount = $session->get('eccube.admin.payee_management.search.page_count', $this->eccubeConfig['eccube_default_page_count']);
        $pageCountParam = $request->get('page_count');
        if ($pageCountParam && is_numeric($pageCountParam)) {
            foreach ($pageMaxis as $pageMax) {
                if ($pageCountParam == $pageMax->getName()) {
                    $pageCount = $pageMax->getName();
                    $session->set('eccube.admin.payee_management.search.page_count', $pageCount);
                    break;
                }
            }
        }
        $form = $builder->getForm();

        // 仕入先検索フォーム
        $builder = $this->formFactory
            ->createBuilder(SearchPayeeMstType::class);
        $searchPayeeMstModalForm = $builder->getForm();

        // 担当者検索フォーム
        $builder = $this->formFactory
            ->createBuilder(SearchMemberType::class);
        $searchMemberModalForm = $builder->getForm();

        $page_no_bk = $page_no;
        if ('POST' === $request->getMethod()) {
            $form->handleRequest($request);
            if ($form->isValid()) {
                $searchData = $form->getData();
                $page_no = 1;

                $session->set('eccube.admin.payee_management.search', FormUtil::getViewData($form));
                $session->set('eccube.admin.payee_management.search.page_no', $page_no);
            } else {
                return [
                    'form' => $form->createView(),
                    'searchPayeeMstModalForm' => $searchPayeeMstModalForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $pageCount,
                    'payeeMoneyTotalAmount' => 0,
                    'paidAmount' => 0,
                    'paidNotAmount' => 0,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                if ($page_no) {
                    $session->set('eccube.admin.payee_management.search.page_no', (int) $page_no);
                } else {
                    $page_no = $session->get('eccube.admin.payee_management.search.page_no', 1);
                }
                $viewData = $session->get('eccube.admin.payee_management.search', []);
            } else {
                $page_no = 1;
                $viewData = FormUtil::getViewData($form);
                $viewData["purchase_date_end"] =  date('Y-m-d', strtotime('now'));
                $viewData["purchase_date_start"] =  date('Y-m-d', strtotime('now'));
//                $viewData["personnel_memo"] = $this->getUser()['name'];
//                $viewData["personnelMemoId"] = $this->getUser()['id'];
                $viewData["nonRegister"] =  true;
                $viewData["register"] =  true;
                $session->set('eccube.admin.payee_management.search', $viewData);
                $session->set('eccube.admin.payee_management.search.page_no', $page_no);
            }
            $searchData = FormUtil::submitAndGetData($form, $viewData);
        }

        $qb = '';
        $all_orders = [];
        if ('POST' === $request->getMethod() || null !== $page_no_bk){
            /** @var QueryBuilder $qb */
            $qb = $this->payeeVoucherHeaderRepository->getQueryBuilderBySearchData($searchData);
            $all_orders = $qb->getQuery()->getResult();
        }

        // 権限
        $authority = $this->specialAuthorityRepository->isValidAuthority($member);

        $payeeMoneyTotalAmount = 0;
        $paidAmount = 0;
        $paidNotAmount = 0;
        $payeeVoucherItems = [];
        foreach ($all_orders as &$payee) {
            $payeeMoneyTotalAmount = $payeeMoneyTotalAmount + $payee['payeeMoneyTotalAmount'];
            // MOD-START CNC 2022/04/21 S以外の伝票の場合、出金済額と未出金額設定
//            $paidAmount = $paidAmount + $payee['paidAmount'];
//            $paidNotAmount = $paidNotAmount + $payee['paidNotAmount'];

            if (substr($payee['payee_voucher_no'],0,1) == 'S') {
                $paidAmount = $paidAmount + $payee['paidAmount'];
                $paidNotAmount = $paidNotAmount + $payee['paidNotAmount'];
            } else {
                $order = $this->orderRepository->findOneBy(['order_no' => $payee['payee_voucher_no']]);
                if ($order['paying'] == null) {
                    $paidAmount = $paidAmount + $payee['payeeMoneyTotalAmount'];
                    $payee['paidAmount'] = $payee['payeeMoneyTotalAmount'];
                } else {
                    if ($order['paying']['paying_status']['id'] == PayingStatus::FINISH) {
                        $paidAmount = $paidAmount + $payee['payeeMoneyTotalAmount'];
                        $payee['paidAmount'] = $payee['payeeMoneyTotalAmount'];
                    } else {
                        $paidNotAmount = $paidNotAmount + $payee['payeeMoneyTotalAmount'];
                        $payee['paidNotAmount'] = $payee['payeeMoneyTotalAmount'];
                    }
                }
            }
            // MOD-END CNC 2022/04/21

            if (!$authority) {
//                if (date('Y-m-d', strtotime('- 3 days')) <= $payee["purchase_date"]->format('Y-m-d')
//                && $payee["purchase_date"]->format('Y-m-d') <= date('Y-m-d', strtotime('5 days'))) {
                if ($payee['create_date']->format('Y-m-d') >= date('Y-m-d', strtotime('- 5 days')) &&
                    $payee['create_date']->format('Y-m-d') <= date('Y-m-d', strtotime('5 days'))) {
                    $payee['authority'] = true;
                } else {
                    $payee['authority'] = false;
                }
            } else {
                $payee['authority'] = true;
            }
            $payeeVoucherItems[] = $payee;
        }
        $all_orders = $payeeVoucherItems;
        $sort_orders = $this->sortOrder($all_orders, $searchData);

        $event = new EventArgs(
            [
                'form' => $form,
                'qb' => $qb,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_MANAGEMENT_PAYEE_VOUCHER_LIST_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $pageCount
        );
        return [
            'form' => $form->createView(),
            'searchPayeeMstModalForm' => $searchPayeeMstModalForm->createView(),
            'searchMemberModalForm' => $searchMemberModalForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $pageCount,
            'payeeMoneyTotalAmount' => $payeeMoneyTotalAmount,
            'paidAmount' => $paidAmount,
            'paidNotAmount' => $paidNotAmount,
            'has_errors' => false,
        ];
    }

    private function sortOrder($orders, $searchData) {
        if($searchData['sort_by']){
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case '伝票番号':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a["payee_voucher_no"] > $b["payee_voucher_no"] ? -1 : 1;
                        }
                        return $a["payee_voucher_no"] < $b["payee_voucher_no"] ? -1 : 1;
                    });
                    break;
                case '仕入先名':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a["payeeName"] > $b["payeeName"] ? -1 : 1;
                        }
                        return $a["payeeName"] < $b["payeeName"] ? -1 : 1;
                    });
                    break;
                case '仕入日':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a["purchase_date"]> $b["purchase_date"] ? -1 : 1;
                        }
                        return $a["purchase_date"] < $b["purchase_date"] ? -1 : 1;
                    });
                    break;
                case '仕入置場':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a["place"] > $b["place"] ? -1 : 1;
                        }
                        return $a["place"] < $b["place"] ? -1 : 1;
                    });
                    break;
            }
        }
        return $orders;
    }

    /**
     * 仕入先情報を検索する.
     *
     * @Route("/%eccube_admin_route%/payee_management/html", name="admin_master_search_payee_html")
     * @Route("/%eccube_admin_route%/payee_management/page/{page_no}", requirements={"page_No" = "\d+"}, name="admin_master_search_payee_html_page")
     * @Template("@admin/PayeeVoucher/search_payeemst.twig")
     *
     * @param Request $request
     * @param integer $page_no
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchPayeeMstHtml(Request $request, $page_no = null, Paginator $paginator)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('search payeemst start.');
            $page_count = $this->eccubeConfig['eccube_default_page_count'];
            $session = $this->session;

            if ('POST' === $request->getMethod()) {
                $page_no = 1;
                $searchData = [
                    'payeeCode' => $request->get('payeeCode'),
                    'payeeName' => $request->get('payeeName'),
                    'kana' => $request->get('kana'),
                    'phoneNumber' => $request->get('phoneNumber'),
                ];

                $session->set('eccube.master.payeemst.search', $searchData);
                $session->set('eccube.master.payeemst.search.page_no', $page_no);
            } else {
                $searchData = (array) $session->get('eccube.admin.master.payeemst.search');
                if (is_null($page_no)) {
                    $page_no = intval($session->get('eccube.admin.master.payeemst.search.page_no'));
                } else {
                    $session->set('eccube.admin.master.payeemst.search.page_no', $page_no);
                }
            }

            $qb = $this->payeeMstRepository->getQueryBuilderBySearchData($searchData);

            $event = new EventArgs(
                [
                    'qb' => $qb,
                    'data' => $searchData,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_MANAGEMENT_PAYEE_VOUCHER_LIST_SEARCH_PAYEE_SEARCH, $event);

            /** @var \Knp\Component\Pager\Pagination\SlidingPagination $pagination */
            $pagination = $paginator->paginate(
                $qb,
                $page_no,
                $page_count,
                ['wrap-queries' => true]
            );

            /** @var $PayeeMsts \Eccube\Entity\PayeeMst[] */
            $PayeeMsts = $pagination->getItems();

            if (empty($PayeeMsts)) {
                log_debug('search payeemst not found.');
            }

            $data = [];
            foreach ($PayeeMsts as $PayeeMst) {
                $data[] = [
                    'id' => $PayeeMst->getId(),
                    'payeeCode' => $PayeeMst->getPayeeCode(),
                    'payeeName' => $PayeeMst->getPayeeName()
                ];
            }

            $event = new EventArgs(
                [
                    'data' => $data,
                    'PayeeMsts' => $pagination,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_MANAGEMENT_PAYEE_VOUCHER_LIST_SEARCH_PAYEE_COMPLETE, $event);
            $data = $event->getArgument('data');

            return [
                'data' => $data,
                'pagination' => $pagination,
            ];
        }
    }

    /**
     *  仕入先情報をセットする.
     *
     * @Route("/%eccube_admin_route%/payee_management/search/master/id", name="admin_master_search_payee_mst_by_id", methods={"POST"})
     *
     * @param Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchPayeeMstById(Request $request)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('search payeemst by id start.');

            /** @var $PayeeMst \Eccube\Entity\PayeeMst */
            $PayeeMst = $this->payeeMstRepository
                ->find($request->get('id'));

            $event = new EventArgs(
                [
                    'PayeeMst' => $PayeeMst,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_MANAGEMENT_PAYEE_VOUCHER_LIST_SEARCH_PAYEE_BY_ID_INITIALIZE, $event);

            if (is_null($PayeeMst)) {
                log_debug('search payeemst by id not found.');

                return $this->json([], 404);
            }

            log_debug('search payeemst by id found.');

            $data = [
                'id' => $PayeeMst->getId(),
                'payeeName' => $PayeeMst->getPayeeName(),
            ];

            $event = new EventArgs(
                [
                    'data' => $data,
                    'PayeeMst' => $PayeeMst,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_MANAGEMENT_PAYEE_VOUCHER_LIST_SEARCH_PAYEE_BY_ID_COMPLETE, $event);
            $data = $event->getArgument('data');
            return $this->json($data);
        }
    }

    /**
     * 担当者情報を検索する.
     *
     * @Route("/%eccube_admin_route%/authority/html", name="admin_master_search_member_html")
     * @Route("/%eccube_admin_route%/authority/html/page/{page_no}", requirements={"page_No" = "\d+"}, name="admin_master_search_member_html_page")
     * @Template("@admin/PayeeVoucher/search_member.twig")
     *
     * @param Request $request
     * @param integer $page_no
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchMemberHtml(Request $request, $page_no = null, Paginator $paginator)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('search member start.');
            $page_count = $this->eccubeConfig['eccube_default_page_count'];
            $session = $this->session;

            if ('POST' === $request->getMethod()) {
                $page_no = 1;
                $searchData = [
                    'login_id' => $request->get('login_id'),
                    'name' => $request->get('name'),
                ];

                $session->set('eccube.master.member.search', $searchData);
                $session->set('eccube.master.member.search.page_no', $page_no);
            } else {
                $searchData = (array) $session->get('eccube.admin.master.member.search');
                if (is_null($page_no)) {
                    $page_no = intval($session->get('eccube.admin.master.member.search.page_no'));
                } else {
                    $session->set('eccube.admin.master.member.search.page_no', $page_no);
                }
            }

            $qb = $this->memberRepository->getQueryBuilderBySearchData($searchData);

            $event = new EventArgs(
                [
                    'qb' => $qb,
                    'data' => $searchData,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_MANAGEMENT_PAYEE_VOUCHER_LIST_SEARCH_MEMBER_SEARCH, $event);

            /** @var \Knp\Component\Pager\Pagination\SlidingPagination $pagination */
            $pagination = $paginator->paginate(
                $qb,
                $page_no,
                $page_count,
                ['wrap-queries' => true]
            );

            /** @var $Members \Eccube\Entity\Member[] */
            $Members = $pagination->getItems();

            if (empty($Members)) {
                log_debug('search member not found.');
            }

            $data = [];
            foreach ($Members as $Member) {
                $data[] = [
                    'id' => $Member->getId(),
                    'login_id' => $Member->getLoginId(),
                    'name' => $Member->getName()
                ];
            }

            $event = new EventArgs(
                [
                    'data' => $data,
                    'Members' => $pagination,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_MANAGEMENT_PAYEE_VOUCHER_LIST_SEARCH_MEMBER_COMPLETE, $event);
            $data = $event->getArgument('data');

            return [
                'data' => $data,
                'pagination' => $pagination,
            ];
        }
    }

    /**
     *  担当者情報をセットする.
     *
     * @Route("/%eccube_admin_route%/authority/search/master/id", name="admin_master_search_member_by_id", methods={"POST"})
     *
     * @param Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchMemberById(Request $request)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('search member by id start.');

            /** @var $Member \Eccube\Entity\Member */
            $Member = $this->memberRepository
                ->find($request->get('id'));

            $event = new EventArgs(
                [
                    'Member' => $Member,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_MANAGEMENT_PAYEE_VOUCHER_LIST_SEARCH_MEMBER_BY_ID_INITIALIZE, $event);

            if (is_null($Member)) {
                log_debug('search member by id not found.');

                return $this->json([], 404);
            }

            log_debug('search member by id found.');

            $data = [
                'id' => $Member->getId(),
                'name' => $Member->getName(),
            ];

            $event = new EventArgs(
                [
                    'data' => $data,
                    'Member' => $Member,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_MANAGEMENT_PAYEE_VOUCHER_LIST_SEARCH_MEMBER_BY_ID_COMPLETE, $event);
            $data = $event->getArgument('data');
            return $this->json($data);
        }
    }

    /**
     * CSVの出力.
     *
     * @Route("/%eccube_admin_route%/payee_management/export", name="admin_payeeVoucherList_export")
     *
     * @param Request $request
     *
     * @return StreamedResponse
     */
    public function export(Request $request)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        // sql loggerを無効にする.
        $em = $this->entityManager;
        $em->getConfiguration()->setSQLLogger(null);

        $response = new StreamedResponse();
        $response->setCallback(function () use ($request) {
            // CSV種別を元に初期化.
            $this->csvExportService->initCsvType(CsvType::CSV_TYPE_PAYEELIST);

            // ヘッダ行の出力.
            $this->csvExportService->exportHeader();

            $qb = $this->csvExportService
                ->getPayeeListQueryBuilder($request);

            // データ行の出力.
            $this->csvExportService->setExportQueryBuilder($qb);

            $this->csvExportService->exportDataCSV(function ($entity, CsvExportService $csvService) use ($request) {
                $Csvs = $csvService->getCsvs();

                $PayeeVoucherListCSV = new \Eccube\Entity\PayeeVoucherListCSV();
                $PayeeVoucherListCSV->setPayeeVoucherNo($entity['payee_voucher_no']);
                $PayeeVoucherListCSV->setPurchaseDate($entity['purchase_date']->format('Y-m-d'));
                $PayeeVoucherListCSV->setPayee($entity['payeeName']);
                $PayeeVoucherListCSV->setPayeeMoneyTotalAmount($entity['payeeMoneyTotalAmount']);
                $PayeeVoucherListCSV->setPersonnel($entity['personnelName']);
                $PayeeVoucherListCSV->setPersonnelMemo($entity['personnel_memo']);
                $PayeeVoucherListCSV->setPaidAmount(is_null($entity['paidAmount']) ? 0 : $entity['paidAmount']);
                $PayeeVoucherListCSV->setPaidNotAmount(is_null($entity['paidNotAmount']) ? 0 : $entity['paidNotAmount']);
                $PayeeVoucherListCSV->setPlace($entity['place']);
                $PayeeVoucherListCSV->setUpdateUserName($entity['update_user_name']);
                $PayeeVoucherListCSV->setUpdateDate($entity['update_date']);
                $PayeeVoucherListCSV->setRegistrationStatus($entity['registration_status']);

                $ExportCsvRow = new \Eccube\Entity\ExportCsvRow();

                // CSV出力項目と合致するデータを取得.
                foreach ($Csvs as $Csv) {
                    $ExportCsvRow->setData($csvService->getData($Csv, $PayeeVoucherListCSV));
                    $event = new EventArgs(
                        [
                            'csvService' => $csvService,
                            'Csv' => $Csv,
                            'PayeeVoucherHeader' => $entity,
                            'ExportCsvRow' => $ExportCsvRow,
                        ],
                        $request
                    );
                    $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_CUSTOMER_CSV_EXPORT, $event);

                    $ExportCsvRow->pushData();
                }

                //$row[] = number_format(memory_get_usage(true));
                // 出力.
                $csvService->fputcsv($ExportCsvRow->getRow());
            });
        });

        $now = new \DateTime();
        $filename = 'payeeList_'.$now->format('YmdHis').'.csv';
        $response->headers->set('Content-Type', 'application/octet-stream');
        $response->headers->set('Content-Disposition', 'attachment; filename='.$filename);
        $response->send();

        log_info('仕入伝票一覧CSV出力ファイル名', [$filename]);

        return $response;
    }

    /**
     *  PDFの出力.
     *
     * @Route("/%eccube_admin_route%/payee_management/export/{id}/pdf", requirements={"id" = "\d+"}, name="admin_payee_voucher_pdf", methods={"GET"})
     *
     * @param Request $request
     *
     * @return
     */
    public function pdfExport(Request $request, $id, PayeeVoucherPdfService $payeeVoucherPdfService)
    {
        // PDFを作成する
        $payeeVoucherPdfService->makePdf($id);
        // ダウンロードする
        $response = new Response(
            $payeeVoucherPdfService->outputPdf(),
            200,
            ['content-type' => 'application/pdf']
        );
        $response->headers->set('Content-Disposition', 'attachment; filename="'.$payeeVoucherPdfService->getPdfFileName().'"');
        return $response;
    }
}
