<?php

namespace Eccube\Controller\Admin\PayeeVoucher;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\DBAL\Exception\ForeignKeyConstraintViolationException;
use Eccube\Common\Constant;
use Eccube\Controller\AbstractController;
use Eccube\Entity\LogControllable;
use Eccube\Entity\Master\OtherItemCodeChange;
use Eccube\Entity\Member;
use Eccube\Entity\PayeeMst;
use Eccube\Entity\PayeePaidBalance;
use Eccube\Entity\PayeeVoucherDetail;
use Eccube\Entity\PayeeVoucherHeader;
use Eccube\Entity\PayeeVoucherHeaderHistory;
use Eccube\Entity\Payment;
use Eccube\Entity\Product;
use Eccube\Entity\State;
use Eccube\Entity\StockListProductUnit;
use Eccube\Entity\StockListStorehouseUnit;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\AddCartType;
use Eccube\Form\Type\Admin\CsvImportType;
use Eccube\Form\Type\Admin\InputMultipleSerialType;
use Eccube\Form\Type\Admin\PayeeVoucherDetailType;
use Eccube\Form\Type\Admin\PayeeVoucherDocType;
use Eccube\Form\Type\Admin\PayeeVoucherSearchPayeeType;
use Eccube\Form\Type\Admin\PayeeVoucherType;
use Eccube\Form\Type\Admin\SearchProductType;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\Master\OtherItemCodeChangeRepository;
use Eccube\Repository\Master\SpecialAuthorityRepository;
use Eccube\Repository\OrderRepository;
use Eccube\Repository\PayeeMstRepository;
use Eccube\Repository\PayeePaidBalanceRepository;
use Eccube\Repository\PayeeVoucherDetailRepository;
use Eccube\Repository\PayeeVoucherHeaderHistoryRepository;
use Eccube\Repository\PayeeVoucherHeaderRepository;
use Eccube\Repository\PaymentRepository;
use Eccube\Repository\PlaceRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\SalesVoucherDetailLinkRepository;
use Eccube\Repository\SerialPictureRepository;
use Eccube\Repository\StateRepository;
use Eccube\Repository\StockListProductUnitRepository;
use Eccube\Repository\StockListStorehouseUnitRepository;
use Eccube\Service\PurchaseFlow\Processor\VoucherNoProcessor;
use Eccube\Util\CacheUtil;
use Knp\Component\Pager\Paginator;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\UnsupportedMediaTypeHttpException;
use Symfony\Component\Routing\RouterInterface;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;

/**
 * プログラム名 ： PayeeVoucherPhoneController.php
 * 概　　要     ： 仕入伝票登録画面(フォン)
 * 作　　成     ： 2022/09/16 CNC
 */
class PayeeVoucherPhoneController extends AbstractController
{
    const TEMPORARY_VOUCHER_NO = '0';

    // 一覧画面URL
    const PREVIOUS_PAGE_URL = 'payee_management/payee_voucher_list';
    const BACK_TO_LIST_URL_PAYEE = 'admin_payee_voucher_list';
    const BACK_TO_LIST_NAME_PAYEE = 'admin.payee.voucher_list';

    // 明細画面URL
    const PREVIOUS_PAGE_URL_PAYEED_ETAIL = 'payee_management/payee_voucher_detail_phone';
    const BACK_TO_LIST_URL_PAYEED_ETAIL = 'admin_payee_voucher_detail_phone';
    const BACK_TO_LIST_NAME_PAYEED_ETAIL = 'admin.payee.voucher_detail_phone';

    const YEN = '円';

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var OtherItemCodeChangeRepository
     */
    protected $otherItemCodeChangeRepository;

    /**
     * @var PayeeVoucherHeaderHistoryRepository
     */
    protected $payeeVoucherHeaderHistoryRepository;

    /**
     * @var PayeeVoucherHeaderRepository
     */
    protected $payeeVoucherHeaderRepository;

    /**
     * @var PayeeVoucherDetailRepository
     */
    protected $payeeVoucherDetailRepository;

    /**
     * @var PayeeMstRepository
     */
    protected $payeeMstRepository;

    /**
     * @var PayeePaidBalanceRepository
     */
    protected $payeePaidBalanceRepository;

    /**
     * @var PaymentRepository
     */
    protected $paymentRepository;

    /**
     * @var PlaceRepository
     */
    protected $placeRepository;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var SalesVoucherDetailLinkRepository
     */
    protected $salesVoucherDetailLinkRepository;

    /**
     * @var SerialPictureRepository
     */
    protected $serialPictureRepository;

    /**
     * @var SpecialAuthorityRepository
     */
    protected $specialAuthorityRepository;

    /**
     * @var StateRepository
     */
    protected $stateRepository;

    /**
     * @var StockListProductUnitRepository
     */
    protected $stockListProductUnitRepository;

    /**
     * @var StockListStorehouseUnitRepository
     */
    protected $stockListStorehouseUnitRepository;

    /**
     * @var VoucherNoProcessor
     */
    protected $voucherNoProcessor;

    /**
     * @var OrderRepository
     */
    protected $orderRepository;

    /**
     * PayeeVoucherPhoneController constructor.
     * @param CategoryRepository $categoryRepository カテゴリ
     * @param OtherItemCodeChangeRepository $otherItemCodeChangeRepository その他項目変換
     * @param PayeeMstRepository $payeeMstRepository 仕入先
     * @param PayeeVoucherDetailRepository $payeeVoucherDetailRepository 仕入伝票明細
     * @param PayeeVoucherHeaderHistoryRepository $payeeVoucherHeaderHistoryRepository 仕入伝票ヘッダー履歴
     * @param PayeeVoucherHeaderRepository $payeeVoucherHeaderRepository 仕入伝票ヘッダー
     * @param PayeePaidBalanceRepository $payeePaidBalanceRepository 仕入伝票ヘッダー
     * @param PaymentRepository $paymentRepository 支払方法
     * @param PlaceRepository $placeRepository 置場
     * @param ProductRepository $productRepository 商品
     * @param SalesVoucherDetailLinkRepository $salesVoucherDetailLinkRepository 売上伝票明細紐付
     * @param SerialPictureRepository $serialPictureRepository 画像
     * @param SpecialAuthorityRepository $specialAuthorityRepository 特殊権限
     * @param StateRepository $stateRepository 状態
     * @param StockListProductUnitRepository $stockListProductUnitRepository 在庫一覧（商品単位）
     * @param StockListStorehouseUnitRepository $stockListStorehouseUnitRepository 在庫一覧（置場単位）
     * @param VoucherNoProcessor $voucherNoProcessor 伝票番号作成
     */
    public function __construct(
        CategoryRepository $categoryRepository,
        OtherItemCodeChangeRepository $otherItemCodeChangeRepository,
        PayeeMstRepository $payeeMstRepository,
        PayeeVoucherDetailRepository $payeeVoucherDetailRepository,
        PayeeVoucherHeaderHistoryRepository $payeeVoucherHeaderHistoryRepository,
        PayeeVoucherHeaderRepository $payeeVoucherHeaderRepository,
        PayeePaidBalanceRepository $payeePaidBalanceRepository,
        PaymentRepository $paymentRepository,
        PlaceRepository $placeRepository,
        ProductRepository $productRepository,
        SalesVoucherDetailLinkRepository $salesVoucherDetailLinkRepository,
        SerialPictureRepository $serialPictureRepository,
        SpecialAuthorityRepository $specialAuthorityRepository,
        StateRepository $stateRepository,
        StockListProductUnitRepository $stockListProductUnitRepository,
        StockListStorehouseUnitRepository $stockListStorehouseUnitRepository,
        VoucherNoProcessor $voucherNoProcessor,
        OrderRepository $orderRepository
    ) {
        ini_set('memory_limit', '2048M');

        $this->categoryRepository = $categoryRepository;
        $this->otherItemCodeChangeRepository = $otherItemCodeChangeRepository;
        $this->payeeMstRepository = $payeeMstRepository;
        $this->payeeVoucherDetailRepository = $payeeVoucherDetailRepository;
        $this->payeeVoucherHeaderHistoryRepository = $payeeVoucherHeaderHistoryRepository;
        $this->payeeVoucherHeaderRepository = $payeeVoucherHeaderRepository;
        $this->payeePaidBalanceRepository = $payeePaidBalanceRepository;
        $this->paymentRepository = $paymentRepository;
        $this->placeRepository = $placeRepository;
        $this->productRepository = $productRepository;
        $this->salesVoucherDetailLinkRepository = $salesVoucherDetailLinkRepository;
        $this->serialPictureRepository = $serialPictureRepository;
        $this->specialAuthorityRepository = $specialAuthorityRepository;
        $this->stateRepository = $stateRepository;
        $this->stockListProductUnitRepository = $stockListProductUnitRepository;
        $this->stockListStorehouseUnitRepository = $stockListStorehouseUnitRepository;
        $this->voucherNoProcessor = $voucherNoProcessor;
        $this->orderRepository = $orderRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/payee_voucher_phone", name="admin_payee_voucher_phone")
     * @Route("/%eccube_admin_route%/payee_voucher_phone/{id}/edit", requirements={"id" = "\d+"}, name="admin_payee_voucher_edit_phone")
     * @Template("@admin/PayeeVoucher/payee_voucher_phone.twig")
     * @param Request $request Request
     * @param int|null $id ID
     * @param RouterInterface|null $router Router
     * @throws NotFoundHttpException
     * @throws \Exception
     * @return array|RedirectResponse
     */
    public function index(Request $request, int $id = null, RouterInterface $router = null)
    {
        ini_set('memory_limit', '2048M');

        if ($this->container->has('profiler')) {
            $this->container->get('profiler')->disable();
        }
        $today = new \DateTime();
        $member = $this->getUser();
        $session = $this->session;
        $back_url = $request->headers->get('referer');
        $header_flg = true;
        $paying_finished_flg = false;

        // 特殊商品（料）
        $array_special_cost = [];
        $collection_special_cost = $this->otherItemCodeChangeRepository->findAll();
        /** @var OtherItemCodeChange $entity_special_cost */
        foreach ($collection_special_cost as $entity_special_cost) {
            $array_special_cost[$entity_special_cost->getName()] = $entity_special_cost->getId();
        }

        // 前ページurl
        if ($id !== null) {
            $controls_enable['back_to_list_display'] = 1;
        } else {
            $controls_enable['back_to_list_display'] = 0;
        }

        if (null === $id) {
            // 削除ボタン：非表示
            $controls_enable['delete_display'] = 0;

            // 活性制御：送金済と未送金
            $controls_enable['paying_finish_no'] = 1;

            $front_url = null;
            if (!empty($request->request->all())) {
                $front_url = $request->request->get('payee_voucher')['front_url'];
            }

            if ($front_url === self::BACK_TO_LIST_URL_PAYEE){
                // 前ページurl
                $controls_enable['back_to_list_display'] = 1;
                $controls_enable['back_to_list_url'] = self::BACK_TO_LIST_URL_PAYEE;
                $controls_enable['back_to_list_name'] = self::BACK_TO_LIST_NAME_PAYEE;

            }else if ($front_url === self::BACK_TO_LIST_URL_PAYEED_ETAIL){
                // 前ページurl
                $controls_enable['back_to_list_display'] = 1;
                $controls_enable['back_to_list_url'] = self::BACK_TO_LIST_URL_PAYEED_ETAIL;
                $controls_enable['back_to_list_name'] = self::BACK_TO_LIST_NAME_PAYEED_ETAIL;
            } else {
                $controls_enable['back_to_list_display'] = 0;
            }

            // 履歴登録用、動作：新規
            $behavior = PayeeVoucherHeaderHistory::BEHAVIOR_NEW;
            // 支払い方法：銀行
            $payment = $this->getPaymentBankTransfer();

            // 空のエンティティを作成、さらに初期値を設定する
            $entity_payee_voucher_header = (new PayeeVoucherHeader())
                // 入力モード: 新規登録
                ->setInputMode(trans('admin.payee.voucher.input_mode.new'))
                ->setPurchaseDate($today);

            // 担当者、作成者、更新者：ログインユーザ
            if ($member) {
                /** @var Member $member */
                $entity_payee_voucher_header = $entity_payee_voucher_header
                    ->setPersonnel($member)
                    ->setCreateUserName($member->getName())
                    ->setUpdateUserName($member->getName());
            }

            // 支払方法：銀行振込
            if ($payment) {
                $entity_payee_voucher_header = $entity_payee_voucher_header->setPayment($payment);
            }
        } else {
            $header_flg = false;

            if (strpos($back_url, self::PREVIOUS_PAGE_URL_PAYEED_ETAIL)) {
                //仕入明細から
                // 前ページurl
                $controls_enable['back_to_list_display'] = 1;
                $controls_enable['back_to_list_url'] = self::BACK_TO_LIST_URL_PAYEED_ETAIL;
                $controls_enable['back_to_list_name'] = self::BACK_TO_LIST_NAME_PAYEED_ETAIL;

            }else {
                //仕入伝票一覧から
                // 前ページurl
                $controls_enable['back_to_list_display'] = 1;
                $controls_enable['back_to_list_url'] = self::BACK_TO_LIST_URL_PAYEE;
                $controls_enable['back_to_list_name'] = self::BACK_TO_LIST_NAME_PAYEE;
            }

            // 履歴登録用、動作：修正
            $behavior = PayeeVoucherHeaderHistory::BEHAVIOR_CHANGE;

            /** @var PayeeVoucherHeader $entity_payee_voucher_header */
            $entity_payee_voucher_header = $this->payeeVoucherHeaderRepository->find($id);
            if ($entity_payee_voucher_header->getRegistrationStatus() === trans('admin.payee.voucher.input_mode.real_register') &&
                ord($entity_payee_voucher_header->getPayeeVoucherNo()) === ord(VoucherNoProcessor::VOUCHER_TYPE_PAYEE)) {
                // 「本登録」、伝票番号の頭は「S」の場合
                // 入力モード: 修正
                $entity_payee_voucher_header->setInputMode(trans('admin.payee.voucher.input_mode.edit'));

                $payee_paid_balance = $this->payeePaidBalanceRepository->findOneBy(['payee_voucher_no' => $entity_payee_voucher_header['payee_voucher_no']]);
                $payee_money = $entity_payee_voucher_header->getPayeeMoneyTotalAmount() - $payee_paid_balance->getPaidAmount();

                // 送金済の場合
                if($payee_money <= 0){
                    // 削除ボタン：非表示
                    $controls_enable['delete_display'] = 1;
                    // 活性制御：送金済と未送金
                    $controls_enable['paying_finish_no'] = 1;
                    // 送金済FLG
                    $paying_finished_flg = true;
                }else{
                    // 削除ボタン：表示
                    $controls_enable['delete_display'] = 1;
                    // 活性制御：送金済と未送金
                    $controls_enable['paying_finish_no'] = 1;
                }

            } elseif ($entity_payee_voucher_header->getRegistrationStatus() === trans('admin.payee.voucher.input_mode.real_register') &&
                ord($entity_payee_voucher_header->getPayeeVoucherNo()) != ord(VoucherNoProcessor::VOUCHER_TYPE_PAYEE)) {
                // 「本登録」、伝票番号の頭は「S」以外の場合
                // 入力モード: 修正
                $entity_payee_voucher_header->setInputMode(trans('admin.payee.voucher.input_mode.edit'));

                $order = $this->orderRepository->findOneBy(['order_no' => $entity_payee_voucher_header['payee_voucher_no']]);
                $paying_status = '';

                if($order['paying'] !== null){
                    $paying_status = $order['Paying']['paying_status']['id'];
                }

                // 送金済の場合
                if($paying_status == 1  || $paying_status == ''){
                    // 削除ボタン：非表示
                    $controls_enable['delete_display'] = 1;
                    // 活性制御：送金済と未送金
                    $controls_enable['paying_finish_no'] = 1;
                }else{
                    // 削除ボタン：表示
                    $controls_enable['delete_display'] = 1;
                    // 活性制御：送金済と未送金
                    $controls_enable['paying_finish_no'] = 1;
                }

            } else {
                // 「仮登録」
                // 入力モード: 本登録
                $entity_payee_voucher_header->setInputMode(trans('admin.payee.voucher.input_mode.real_register'));
                // 削除ボタン：非表示
                $controls_enable['delete_display'] = 0;
                // 活性制御：送金済と未送金
                $controls_enable['paying_finish_no'] = 0;
            }

            // 更新者：ログインユーザ
            if ($member) {
                /** @var Member $member */
                $entity_payee_voucher_header = $entity_payee_voucher_header
                    ->setUpdateUserName($member->getName());

                // 権限
                $authority = $this->specialAuthorityRepository->isValidAuthority($member);
                if ($authority) {
                    $header_flg = true;
                }
            }
        }

        // 編集前の仕入伝票情報を保持
        $origin_entity_payee_voucher_header = clone $entity_payee_voucher_header;
        $origin_entity_payee_detail_collection = new ArrayCollection();
        foreach ($origin_entity_payee_voucher_header->getPayeeVoucherDetails() as $detail) {
            // 「ヘッダID_明細NO」をキーとする
            $origin_entity_payee_detail_collection[$detail->getPayeeVoucherHeader()->getId().'_'.$detail->getPayeeDetailNo()] = $detail;
        }

        $payee_code = '';
        if ($entity_payee_voucher_header->getPayee()) {
            $payee_code = $entity_payee_voucher_header->getPayee()->getPayeeCode();
        }

        // 削除比較用
        $entity_payee_detail_collection_for_delete = new ArrayCollection();
        foreach ($entity_payee_voucher_header->getPayeeVoucherDetails() as $detail) {
            $entity_payee_detail_collection_for_delete->add($detail);
        }

        $builder_payee_voucher_header = $this->formFactory
            ->createBuilder(PayeeVoucherType::class, $entity_payee_voucher_header);
        $form_payee_voucher_header = $builder_payee_voucher_header->getForm();

        if ('POST' === $request->getMethod()) {

            $form_payee_voucher_header->handleRequest($request);

            if ($id != null ) {
                if ($request->get('orderUpdateTime') != $entity_payee_voucher_header->getUpdateDate()->format('Y-m-d H:i:s')) {
                    $form_payee_voucher_header['PayeeVoucherDetailsErrors']
                        ->addError(new FormError(trans('admin.payee.voucher.detail_update_date_error')));
                }
            }

            // 権限チェック用日付（新規日付）
            $create_date = $origin_entity_payee_voucher_header->getCreateDate()
                ? clone $origin_entity_payee_voucher_header->getCreateDate()
                : clone $today;
            // 五日前
            $five_days_before = $create_date->sub(new \DateInterval('P4DT23H59M59S'))
                ->setTimezone(new \DateTimeZone('Asia/Tokyo'))
                ->format('Ymd');
            // 五日後
            $five_days_after = $create_date->add(new \DateInterval('P9DT23H59M59S'))
                ->setTimezone(new \DateTimeZone('Asia/Tokyo'))
                ->format('Ymd');

            // 該当仕入日
            $purchase_date = (new \DateTime($request->get('payee_voucher')['purchase_date'], new \DateTimeZone('Asia/Tokyo')))
                ->format('Ymd');

            if ($purchase_date < $five_days_before || $purchase_date > $five_days_after) {
                $form_payee_voucher_header['purchase_date']->addError(
                    new FormError(
                        trans('admin.payee.voucher.detail_date_range').' 作成：'.
                        ($origin_entity_payee_voucher_header->getCreateDate() ?: $today)
                            ->setTimezone(new \DateTimeZone('Asia/Tokyo'))
                            ->format('Ymd')
                    )
                );
            }

            // Payee(MST)
            $payee_id = $request->get('payee_voucher')['Payee']['id'];
            $registered_entity_payee = $this->payeeMstRepository->find($payee_id);
            if (!$registered_entity_payee) {
                $form_payee_voucher_header['Payee']['payeeName']
                    ->addError(new FormError(trans('This value should not be blank.', [], 'validators')));
                $form_payee_voucher_header['Payee']
                    ->addError(new FormError(trans('This value should not be blank.', [], 'validators')));
            } else {
                $entity_payee_voucher_header->setPayee($registered_entity_payee);
            }

            if ($form_payee_voucher_header->isValid()) {
                /** @var PayeeVoucherHeader $payee_voucher */
                $payee_voucher = $form_payee_voucher_header->getData();

                if ($request->get('mode') == 'register') {
                    try {
                        log_info('仕入先伝票登録開始', [$id]);

                        $payee_voucher->setVoucherNo($payee_voucher->getPayeeVoucherNo() ?: self::TEMPORARY_VOUCHER_NO)
                            ->setRegistrationStatus(trans('admin.payee.voucher.input_mode.real_register'))
                            ->setPayee($registered_entity_payee);

                        // 現在置場
                        $header_place = $payee_voucher->getPlace();
                        // 変更前置場
                        if ($id !== null) {
                            $origin_header_place = $origin_entity_payee_voucher_header->getPlace();
                        } else {
                            $origin_header_place = null;
                        }

                        // 明細
                        $money_total_amount = 0;
                        $payee_detail_no = $this->payeeVoucherDetailRepository
                            ->getMaxDetailNoInOneVoucher($entity_payee_voucher_header);
                        $collection_payee_voucher_details = $payee_voucher->getPayeeVoucherDetails();

                        // 削除
                        /** @var PayeeVoucherDetail $origin_detail */
                        foreach ($entity_payee_detail_collection_for_delete as $origin_detail) {
                            if ($collection_payee_voucher_details->contains($origin_detail) === false) {
                                if ($this->isSold($origin_detail)) {
                                    $form_payee_voucher_header['PayeeVoucherDetailsErrors']
                                        ->addError(new FormError(trans('admin.payee.voucher.detail_delete_when_sold')));
                                    throw new \Exception(trans('admin.payee.voucher.detail_delete_when_sold'));
                                }
                                if (!isset($array_special_cost[$origin_detail->getProductCode()])) {
                                    $this->removeStockInfoWithDetailRemoved($origin_detail, $payee_voucher, $member->getName());
                                    $this->removePictureByDetail($origin_detail);
                                }
                                $this->entityManager->remove($origin_detail);
                                $this->entityManager->flush($origin_detail);
                            }
                        }

                        // 変更
                        if ($collection_payee_voucher_details && is_array($collection_payee_voucher_details->getValues())) {
                            $array_payee_voucher_details = $collection_payee_voucher_details->getValues();

                            // ADD-START CNC 2022/10/29 sort
                            $array_payee_voucher_details = array_reverse($array_payee_voucher_details);
                            // ADD-END CNC 2022/10/29 sort

                            // 行番号
                            $line = 0;
                            $array_line = [];
//                            foreach ($collection_payee_voucher_details as $No => $row) {
                            foreach ($array_payee_voucher_details as $No => $row) {
                                $array_line[$line++] = $No;
                            }

                            // 在庫連動条件
                            $stock_by_product_conditions = [];
                            $stock_by_place_conditions = [];
                            $stock_by_place_serial_change = [];
                            // チェック
                            $message_exception = '';

                            /** @var PayeeVoucherDetail $entity_detail */
                            foreach ($array_payee_voucher_details as $line_no => $entity_detail) {
                                if (!$entity_detail->getPayeeVoucherHeader() ||
                                    !$entity_detail->isEqualFromHeaderPage(
                                        $origin_entity_payee_detail_collection[$entity_detail->getPayeeVoucherHeader()->getId().'_'.$entity_detail->getPayeeDetailNo()]
                                    )
                                ) {
                                    if ($entity_detail->getPayeeVoucherHeader() && $this->isSold($entity_detail)) {
                                        $form_payee_voucher_header['PayeeVoucherDetails'][$array_line[$line_no]]['product_code']
                                            ->addError(new FormError(trans('admin.payee.voucher.detail_update_when_sold')));
                                        $message_exception .= '明細の'.($line_no + 1).'行目：'.trans('admin.payee.voucher.detail_update_when_sold')."\n";
                                    }
                                    // 在庫にシリアル番号存在するが、在庫数が０の場合、仕入可能になる
                                    $serial_no = $entity_detail->getSerialNo();
                                    $origin_serial_no = '';
                                    if ($entity_detail->getPayeeVoucherHeader() &&
                                        isset($origin_entity_payee_detail_collection[$entity_detail->getPayeeVoucherHeader()->getId().'_'.$entity_detail->getPayeeDetailNo()])) {
                                        /** @var PayeeVoucherDetail $origin_entity_detail */
                                        $origin_entity_detail = $origin_entity_payee_detail_collection[$entity_detail->getPayeeVoucherHeader()->getId().'_'.$entity_detail->getPayeeDetailNo()];
                                        $origin_serial_no = $origin_entity_detail->getSerialNo();
                                    }
                                    if ($serial_no &&
                                        $serial_no !== $origin_serial_no) {
                                        /** @var StockListStorehouseUnit $infoStockListStorehouseUnit */
                                        $infoStockListStorehouseUnit = $this->stockListStorehouseUnitRepository->findOneBy(
                                            [
                                                'serialNo' => $serial_no,
                                            ],
                                            ['stockQuantity' => 'DESC']
                                        );
                                        if ($infoStockListStorehouseUnit && $infoStockListStorehouseUnit->getStockQuantity() > 0) {
                                            $form_payee_voucher_header['PayeeVoucherDetails'][$array_line[$line_no]]['serial_no']
                                                ->addError(new FormError(trans('admin.payee.voucher.duplicate_detail_serial_no')));
                                            $message_exception .= '明細の'.($line_no + 1).'行目：'.trans('admin.payee.voucher.duplicate_detail_serial_no')."\n";
                                        }
                                    }
                                }
                            }
                            if ($message_exception !== '') {
                                throw new \Exception($message_exception);
                            }

                            //　仕入金額合計の一致チェック
//                            if($entity_payee_voucher_header->getId()){
//                                $total_amount_money = $entity_payee_voucher_header->getPayeeMoneyTotalAmount();
//                                $total_amount_money_str = str_replace(',', '', $total_amount_money);
//
//                                if ($origin_entity_payee_voucher_header->getPayeeMoneyTotalAmount() !== $total_amount_money_str) {
//                                    $form_payee_voucher_header['PayeeVoucherDetailsErrors']
//                                        ->addError(new FormError(trans('admin.payee.voucher.detail_update_money_error')));
//                                    throw new \Exception(trans('admin.payee.voucher.detail_update_money_error'));
//                                }
//                            }
                            if ($entity_payee_voucher_header->getId()){
                                // 伝票番号の頭は「S」、かつ、送金済の場合
                                if ($entity_payee_voucher_header->getRegistrationStatus() === trans('admin.payee.voucher.input_mode.real_register') &&
                                    ord($entity_payee_voucher_header->getPayeeVoucherNo()) === ord(VoucherNoProcessor::VOUCHER_TYPE_PAYEE) &&
                                    $paying_finished_flg == true){
                                    $total_amount_money = $entity_payee_voucher_header->getPayeeMoneyTotalAmount();
                                    $total_amount_money_str = str_replace(',', '', $total_amount_money);
                                    if ($origin_entity_payee_voucher_header->getPayeeMoneyTotalAmount() !== $total_amount_money_str) {
                                        $form_payee_voucher_header['PayeeVoucherDetailsErrors']
                                            ->addError(new FormError(trans('admin.payee.voucher.detail_update_money_error')));
                                        throw new \Exception(trans('admin.payee.voucher.detail_update_money_error'));
                                    }
                                // 伝票番号の頭は「S」以外
                                } elseif ($entity_payee_voucher_header->getRegistrationStatus() === trans('admin.payee.voucher.input_mode.real_register') &&
                                    ord($entity_payee_voucher_header->getPayeeVoucherNo()) != ord(VoucherNoProcessor::VOUCHER_TYPE_PAYEE)){
                                    $total_amount_money = $entity_payee_voucher_header->getPayeeMoneyTotalAmount();
                                    $total_amount_money_str = str_replace(',', '', $total_amount_money);
                                    if ($origin_entity_payee_voucher_header->getPayeeMoneyTotalAmount() !== $total_amount_money_str) {
                                        $form_payee_voucher_header['PayeeVoucherDetailsErrors']
                                            ->addError(new FormError(trans('admin.payee.voucher.detail_update_money_error')));
                                        throw new \Exception(trans('admin.payee.voucher.detail_update_money_error'));
                                    }
                                }
                            }

                            // 設定
                            /** @var PayeeVoucherDetail $entity_detail */
                            foreach ($array_payee_voucher_details as $line_no => $entity_detail) {
                                if (!$entity_detail->getPayeeVoucherHeader() ||
                                    !$entity_detail->isEqualFromHeaderPage(
                                        $origin_entity_payee_detail_collection[$entity_detail->getPayeeVoucherHeader()->getId().'_'.$entity_detail->getPayeeDetailNo()]
                                    )
                                ) {
                                    if ($entity_detail->getPayeeVoucherHeader() && $this->isSold($entity_detail)) {
                                        $form_payee_voucher_header['PayeeVoucherDetails'][$array_line[$line_no]]['product_code']
                                            ->addError(new FormError(trans('admin.payee.voucher.detail_update_when_sold')));
                                        throw new \Exception('明細の'.($line_no + 1).'行目：'.trans('admin.payee.voucher.detail_update_when_sold'));
                                    }
                                    $entity_detail->setPayeeDetailNo(($entity_detail->getPayeeDetailNo()) ?: ++$payee_detail_no)
                                        ->setVoucherNo(self::TEMPORARY_VOUCHER_NO)
                                        ->setPayeeVoucherHeader($payee_voucher)
                                        ->setPayeeMoneyAmount()
                                        ->setCreateUserName($entity_detail->getCreateUserName() ?: $member->getName())
                                        ->setUpdateUserName($member->getName());
                                }

                                // 合計
                                $money_total_amount += $entity_detail->getPayeeMoneyAmount();

                                if (!isset($array_special_cost[$entity_detail->getProductCode()])) {
                                    // 特殊商品（料）の場合、下記処理を除く

                                    // 在庫 準備
                                    $state_changed = 0;
                                    $not_payee_serial_change = 0;
                                    if (isset($origin_entity_payee_detail_collection[$entity_detail->getPayeeVoucherHeader()->getId().'_'.$entity_detail->getPayeeDetailNo()]) &&
                                        ord($entity_payee_voucher_header->getPayeeVoucherNo()) === ord(VoucherNoProcessor::VOUCHER_TYPE_PAYEE)) {
                                        // 仕入 & 既存あり

                                        if ($origin_entity_payee_voucher_header->getRegistrationStatus() === trans('admin.payee.voucher.input_mode.real_register') &&
                                            $entity_detail->getPayeeVoucherHeader() &&
                                            ($origin_header_place && $header_place === $origin_header_place) &&
                                            $entity_detail->isEqualFromHeaderPage(
                                                $origin_entity_payee_detail_collection[$entity_detail->getPayeeVoucherHeader()->getId().'_'.$entity_detail->getPayeeDetailNo()]
                                            )
                                        ) {
                                            // 元は本登録 かつ 完全に変更されない 登録済み レコード、在庫処理を行わない
                                            continue;
                                        }

                                        /** @var PayeeVoucherDetail $origin_entity_detail */
                                        $origin_entity_detail = $origin_entity_payee_detail_collection[$entity_detail->getPayeeVoucherHeader()->getId().'_'.$entity_detail->getPayeeDetailNo()];

                                        // 本登録
                                        if ((string) $origin_entity_detail->getSerialNo() !== '' && (string) $entity_detail->getSerialNo() !== '') {
                                            // 更新前後、シリアル番号は空以外の場合
                                            // シリアル番号の更新だけを行う
                                            $not_payee_serial_change = 1;
                                        }

                                        //  状態変更の場合、状態元に対応する件数を除く
                                        if ($origin_entity_detail->getState() !== $entity_detail->getState()) {
                                            $this->removeStockInfoWithDetailRemoved($origin_entity_detail, $origin_entity_payee_voucher_header, $member->getName());
                                            $state_changed = 1;
                                        }
                                        $origin_quantity = $origin_entity_detail->getQuantity();
                                        $origin_money = $origin_entity_detail->getPayeeMoneyAmount();
                                    } elseif (isset($origin_entity_payee_detail_collection[$entity_detail->getPayeeVoucherHeader()->getId().'_'.$entity_detail->getPayeeDetailNo()]) &&
                                        ord($entity_payee_voucher_header->getPayeeVoucherNo()) != ord(VoucherNoProcessor::VOUCHER_TYPE_PAYEE)) {
                                        // 仕入以外 & 既存あり（仕入以外はいつも既存ありけど）

                                        if ($origin_entity_payee_voucher_header->getRegistrationStatus() === trans('admin.payee.voucher.input_mode.real_register') &&
                                            $entity_detail->getPayeeVoucherHeader() &&
                                            ($origin_header_place && $header_place === $origin_header_place) &&
                                            $entity_detail->isEqualFromHeaderPage(
                                                $origin_entity_payee_detail_collection[$entity_detail->getPayeeVoucherHeader()->getId().'_'.$entity_detail->getPayeeDetailNo()]
                                            )
                                        ) {
                                            // 元は本登録 かつ 完全に変更されない 登録済み レコード、在庫処理を行わない
                                            continue;
                                        }

                                        /** @var PayeeVoucherDetail $origin_entity_detail */
                                        $origin_entity_detail = $origin_entity_payee_detail_collection[$entity_detail->getPayeeVoucherHeader()->getId().'_'.$entity_detail->getPayeeDetailNo()];
                                        if ($origin_entity_payee_voucher_header->getRegistrationStatus() === trans('admin.payee.voucher.input_mode.real_register')) {
                                            // 本登録
                                            if ((string) $origin_entity_detail->getSerialNo() !== '' && (string) $entity_detail->getSerialNo() !== '') {
                                                // 更新前後、シリアル番号は空以外の場合
                                                // シリアル番号の更新だけを行う
                                                $not_payee_serial_change = 1;
                                            }
                                            //  状態変更の場合、状態元に対応する件数を除く
                                            if ($origin_entity_detail->getState() !== $entity_detail->getState()) {
                                                $this->removeStockInfoWithDetailRemoved($origin_entity_detail, $origin_entity_payee_voucher_header, $member->getName());
                                                $state_changed = 1;
                                            }
                                            // 数量/金額、計算結果は「0」はずです
                                            $origin_quantity = $origin_entity_detail->getQuantity();
                                            $origin_money = $origin_entity_detail->getPayeeMoneyAmount();
                                        } elseif ($origin_entity_payee_voucher_header->getRegistrationStatus() === trans('admin.payee.voucher.input_mode.provisional_register')) {
                                            // 仮登録
                                            // 数量/金額、画面入力値を登録する
                                            $origin_quantity = 0;
                                            $origin_money = 0;
                                        }
                                    } else {
                                        // 既存なし
                                        // 仕入以外の場合、シリアル番号で配分された明細情報を含む
                                        $origin_quantity = 0;
                                        $origin_money = 0;
                                    }
                                    // 在庫一覧（商品単位）
                                    $key_stock_by_product =
                                        $entity_detail->getProductId()
                                        .'_'.$entity_detail->getProductClass()->getId()
                                        .'_'.$entity_detail->getProductCode()
                                        .'_'.$entity_detail->getState()->getId()
                                    ;
                                    // 変更数量
                                    $quantity_stock_by_product = (
                                        isset($stock_by_product_conditions[$key_stock_by_product])
                                            ? $stock_by_product_conditions[$key_stock_by_product]['quantity']
                                            : 0
                                        ) + $entity_detail->getQuantity() -
                                        ($state_changed ? 0 : $origin_quantity);
                                    // 変更金額
                                    $money_stock_by_product = (
                                        isset($stock_by_product_conditions[$key_stock_by_product])
                                            ? $stock_by_product_conditions[$key_stock_by_product]['money']
                                            : 0
                                        ) + $entity_detail->getPayeeMoneyAmount() -
                                        ($state_changed ? 0 : $origin_money);

                                    $stock_by_product_conditions[$key_stock_by_product] = [
                                        'productId' => $entity_detail->getProductId(),
                                        'ProductClass' => $entity_detail->getProductClass(),
                                        'productCode' => $entity_detail->getProductCode(),
                                        'State' => $entity_detail->getState(),
                                        'quantity' => $quantity_stock_by_product,
                                        'money' => $money_stock_by_product,
                                    ];

                                    // 在庫一覧（置場単位）
                                    if ($origin_header_place && $header_place !== $origin_header_place) {
                                        // ヘッダー置場変更あり
                                        if (!$state_changed) {
                                            // 変更前置場データの削除
                                            // ※状態が変更されたら、変更前データはもう削除されたため
                                            $key_stock_by_place_old =
                                                $entity_detail->getProductId()
                                                .'_'.$entity_detail->getProductClass()->getId()
                                                .'_'.$entity_detail->getProductCode()
                                                .'_'.$entity_detail->getSerialNo()
                                                .'_'.$entity_detail->getState()->getId()
                                                .'_'.$origin_header_place->getId()
                                            ;
                                            $quantity_stock_by_place = (
                                                isset($stock_by_place_conditions[$key_stock_by_place_old])
                                                    ? $stock_by_place_conditions[$key_stock_by_place_old]['quantity']
                                                    : 0
                                                ) - $origin_quantity;

                                            $stock_by_place_conditions[$key_stock_by_place_old] = [
                                                'productId' => $entity_detail->getProductId(),
                                                'ProductClass' => $entity_detail->getProductClass(),
                                                'productCode' => $entity_detail->getProductCode(),
                                                'serialNo' => $entity_detail->getSerialNo(),
                                                'State' => $entity_detail->getState(),
                                                'Storehouse' => $origin_header_place,
                                                'quantity' => $quantity_stock_by_place,
                                            ];
                                        }

                                        // 変更後置場データの設定
                                        $key_stock_by_place_new =
                                            $entity_detail->getProductId()
                                            .'_'.$entity_detail->getProductClass()->getId()
                                            .'_'.$entity_detail->getProductCode()
                                            .'_'.$entity_detail->getSerialNo()
                                            .'_'.$entity_detail->getState()->getId()
                                            .'_'.$header_place->getId()
                                        ;
                                        $quantity_stock_by_place = (
                                            isset($stock_by_place_conditions[$key_stock_by_place_new])
                                                ? $stock_by_place_conditions[$key_stock_by_place_new]['quantity']
                                                : 0
                                            ) + $entity_detail->getQuantity();

                                        $stock_by_place_conditions[$key_stock_by_place_new] = [
                                            'productId' => $entity_detail->getProductId(),
                                            'ProductClass' => $entity_detail->getProductClass(),
                                            'productCode' => $entity_detail->getProductCode(),
                                            'serialNo' => $entity_detail->getSerialNo(),
                                            'State' => $entity_detail->getState(),
                                            'Storehouse' => $header_place,
                                            'quantity' => $quantity_stock_by_place,
                                        ];
                                    } else {
                                        // ヘッダー置場変更なし
                                        $key_stock_by_place =
                                            $entity_detail->getProductId()
                                            .'_'.$entity_detail->getProductClass()->getId()
                                            .'_'.$entity_detail->getProductCode()
                                            .'_'.$entity_detail->getSerialNo()
                                            .'_'.$entity_detail->getState()->getId()
                                            .'_'.$header_place->getId()
                                        ;
                                        if ($not_payee_serial_change === 0) {
                                            // 通常場合
                                            $quantity_stock_by_place = (
                                                isset($stock_by_place_conditions[$key_stock_by_place])
                                                    ? $stock_by_place_conditions[$key_stock_by_place]['quantity']
                                                    : 0
                                                ) + $entity_detail->getQuantity() -
                                                ($state_changed ? 0 : $origin_quantity);

                                            $stock_by_place_conditions[$key_stock_by_place] = [
                                                'productId' => $entity_detail->getProductId(),
                                                'ProductClass' => $entity_detail->getProductClass(),
                                                'productCode' => $entity_detail->getProductCode(),
                                                'serialNo' => $entity_detail->getSerialNo(),
                                                'State' => $entity_detail->getState(),
                                                'Storehouse' => $header_place,
                                                'quantity' => $quantity_stock_by_place,
                                            ];
                                        } else {
                                            // 仕入先以外かつシリアル番号変更できる場合
                                            $quantity_stock_by_place = (
                                                isset($stock_by_place_conditions[$key_stock_by_place])
                                                    ? $stock_by_place_conditions[$key_stock_by_place]['quantity']
                                                    : 0
                                                ) + $entity_detail->getQuantity() -
                                                ($state_changed ? 0 : $origin_quantity);

                                            $stock_by_place_serial_change[$key_stock_by_place] = [
                                                'productId' => $entity_detail->getProductId(),
                                                'ProductClass' => $entity_detail->getProductClass(),
                                                'productCode' => $entity_detail->getProductCode(),
                                                'serialNo' => $entity_detail->getSerialNo(),
                                                'originSerialNo' => $origin_entity_detail->getSerialNo(),
                                                'State' => $entity_detail->getState(),
                                                'Storehouse' => $header_place,
                                                'quantity' => $quantity_stock_by_place,
                                            ];
                                        }
                                    }
                                }
                            }

                            // 在庫
                            //   在庫一覧（商品単位）
                            foreach ($stock_by_product_conditions as $place_condition) {
                                $parameter_stock_by_product = [
                                    'productId' => $place_condition['productId'],
                                    'ProductClass' => $place_condition['ProductClass'],
                                    'productCode' => $place_condition['productCode'],
                                    'State' => $place_condition['State'],
                                ];
                                $collection_stock_list_product_unit = $this->stockListProductUnitRepository
                                    ->findBy($parameter_stock_by_product);

                                if (isset($collection_stock_list_product_unit[0])) {
                                    $entity_stock_list_product_unit = $collection_stock_list_product_unit[0];
                                } else {
                                    $entity_stock_list_product_unit = (new StockListProductUnit())
                                        ->setProductId($place_condition['productId'])
                                        ->setProductClass($place_condition['ProductClass'])
                                        ->setProductCode($place_condition['productCode'])
                                        ->setState($place_condition['State'])
                                        ->setOrderQuantity(0)
                                        ->setProvisionalShipmentQuantity(0)
                                        ->setCreateUserName($member->getName())
                                    ;
                                }
                                $origin_entity_stock_list_product_unit = clone $entity_stock_list_product_unit;
                                $changeBeforeQuantity = $entity_stock_list_product_unit->getStockQuantity();
                                $stock_quantity_product_unit =
                                    $entity_stock_list_product_unit->getStockQuantity() + $place_condition['quantity'];
                                $entity_stock_list_product_unit->setStockQuantity(
                                    $stock_quantity_product_unit
                                )->setRemainingStockQuantity(
                                    $stock_quantity_product_unit
                                    - $origin_entity_stock_list_product_unit->getOrderQuantity()
                                    - $origin_entity_stock_list_product_unit->getProvisionalShipmentQuantity()
                                )->setUpdateUserName($member->getName());

                                if ($changeBeforeQuantity <= 0 || $stock_quantity_product_unit <= 0
                                    || $origin_entity_stock_list_product_unit->getAverageUnitPrice() * $origin_entity_stock_list_product_unit->getStockQuantity() <= 0
                                    || round(($origin_entity_stock_list_product_unit->getAverageUnitPrice() * $origin_entity_stock_list_product_unit->getStockQuantity() + $place_condition['money']) / $stock_quantity_product_unit) <= 0) {
                                    $entity_stock_list_product_unit->setAverageUnitPrice(round($place_condition['money'] / $place_condition['quantity']));
                                }
                                else {
                                    $entity_stock_list_product_unit->setAverageUnitPrice(
                                        $stock_quantity_product_unit === 0
                                            ? 0
                                            : round(
                                            (
                                                $origin_entity_stock_list_product_unit->getAverageUnitPrice()
                                                * $origin_entity_stock_list_product_unit->getStockQuantity()
                                                + $place_condition['money']
                                            ) / $stock_quantity_product_unit
                                        )
                                    );
                                }

                                $this->entityManager->persist($entity_stock_list_product_unit);
                                $this->entityManager->flush($entity_stock_list_product_unit);
                                LogControllable::print_log(__FILE__, '########## Insert/update: stock list by product', [$entity_stock_list_product_unit->toArray()]);
                            }

                            //   在庫一覧（置場単位）
                            foreach ($stock_by_place_conditions as $place_condition) {
                                $parameter_stock_by_place = [
                                    'productId' => $place_condition['productId'],
                                    'ProductClass' => $place_condition['ProductClass'],
                                    'productCode' => $place_condition['productCode'],
                                    'serialNo' => $place_condition['serialNo'],
                                    'State' => $place_condition['State'],
                                    'Storehouse' => $place_condition['Storehouse'],
                                ];
                                $collection_stock_list_place_unit = $this->stockListStorehouseUnitRepository
                                    ->findBy($parameter_stock_by_place);

                                if (isset($collection_stock_list_place_unit[0])) {
                                    $entity_stock_list_place_unit = $collection_stock_list_place_unit[0];
                                } else {
                                    $entity_stock_list_place_unit = (new StockListStorehouseUnit())
                                        ->setProductId($place_condition['productId'])
                                        ->setProductClass($place_condition['ProductClass'])
                                        ->setProductCode($place_condition['productCode'])
                                        ->setSerialNo($place_condition['serialNo'])
                                        ->setState($place_condition['State'])
                                        ->setStorehouse($place_condition['Storehouse'])
                                        ->setCreateUserName($member->getName())
                                    ;
                                }
                                $entity_stock_list_place_unit->setStockQuantity(
                                    $entity_stock_list_place_unit->getStockQuantity()
                                    + $place_condition['quantity']
                                )->setUpdateUserName($member->getName());
                                $this->entityManager->persist($entity_stock_list_place_unit);
                                $this->entityManager->flush($entity_stock_list_place_unit);
                                LogControllable::print_log(__FILE__, '########## Insert/update: stock list by storehouse', [$entity_stock_list_place_unit->toArray()]);
                            }

                            //   在庫一覧（置場単位）：シリアル番号変更
                            foreach ($stock_by_place_serial_change as $serial_change) {
                                $parameter_stock_by_place = [
                                    'productId' => $serial_change['productId'],
                                    'ProductClass' => $serial_change['ProductClass'],
                                    'productCode' => $serial_change['productCode'],
                                    'serialNo' => $serial_change['originSerialNo'],
                                    'State' => $serial_change['State'],
                                    'Storehouse' => $serial_change['Storehouse'],
                                ];
                                $collection_stock_list_place_unit = $this->stockListStorehouseUnitRepository
                                    ->findBy($parameter_stock_by_place);

                                if (isset($collection_stock_list_place_unit[0])) {
                                    $entity_stock_list_place_unit = $collection_stock_list_place_unit[0];
                                } else {
                                    $entity_stock_list_place_unit = (new StockListStorehouseUnit())
                                        ->setProductId($serial_change['productId'])
                                        ->setProductClass($serial_change['ProductClass'])
                                        ->setProductCode($serial_change['productCode'])
                                        ->setState($serial_change['State'])
                                        ->setStorehouse($serial_change['Storehouse'])
                                        ->setCreateUserName($member->getName())
                                    ;
                                }
                                $entity_stock_list_place_unit->setSerialNo($serial_change['serialNo'])
                                    ->setUpdateUserName($member->getName())
                                    ->setStockQuantity(
                                        $entity_stock_list_place_unit->getStockQuantity()
                                        + $serial_change['quantity']
                                    );
                                $this->entityManager->persist($entity_stock_list_place_unit);
                                $this->entityManager->flush($entity_stock_list_place_unit);
                                LogControllable::print_log(__FILE__, '########## Insert/update: stock list by storehouse', [$entity_stock_list_place_unit->toArray()]);
                            }
                        }

                        // ヘッダー：合計
                        $payee_voucher->setPayeeMoneyTotalAmount($money_total_amount);

                        // 仕入出金残高
                        if ($id === null) {
                            $collection_payee_paid_balance = $payee_voucher->getPayeePaidBalances();
                            if ($collection_payee_paid_balance->count() > 0) {
                                $entity_payee_paid_balance = $collection_payee_paid_balance[0]
                                    ->setUpdateUserName($member->getName());
                            } else {
                                $entity_payee_paid_balance = (new PayeePaidBalance())->setPayeeVoucherHeader()
                                    ->setPayeeVoucherNo(self::TEMPORARY_VOUCHER_NO)
                                    ->setCreateUserName($member->getName())
                                    ->setUpdateUserName($member->getName())
                                ;
                                $payee_voucher->addPayeePaidBalance($entity_payee_paid_balance);
                            }

                            $entity_payee_paid_balance->setPayeeVoucherHeader($payee_voucher)
                                ->setPaidAmount(0);
                        }

                        // ADD-START CNC 2022/10/29 sort
                        $arrayPayeeVoucherDetails = $payee_voucher['PayeeVoucherDetails']->toArray();

                        $arrayPayeeVoucherDetails = array_reverse($arrayPayeeVoucherDetails);

                        $payee_voucher['PayeeVoucherDetails']->clear();

                        foreach ($arrayPayeeVoucherDetails as $arrayPayeeVoucherDetail) {
                            $payee_voucher['PayeeVoucherDetails']->add($arrayPayeeVoucherDetail);
                        }
                        // ADD-END CNC 2022/10/29 sort

                        $this->entityManager->persist($payee_voucher);
                        $this->entityManager->flush();

                        // 伝票番号
                        // 新規登録時はMySQL対応のためflushしてから採番
                        $this->voucherNoProcessor->process($payee_voucher);
                        $updated_entity_payee_paid_balance = $payee_voucher->getPayeePaidBalances()[0];
                        if ($updated_entity_payee_paid_balance && !$updated_entity_payee_paid_balance->getPayeeVoucherNo()) {
                            $updated_entity_payee_paid_balance
                                ->setPayeeVoucherNo($payee_voucher->getPayeeVoucherNo());
                        }
                        $this->entityManager->flush();

                        // 履歴（ヘッダ―）
                        $payee_voucher_history = $this->payeeVoucherHeaderHistoryRepository
                            ->createPayeeVoucherHeaderHistoryByHeader($payee_voucher, $behavior);
                        $this->entityManager->persist($payee_voucher_history);
                        $this->entityManager->flush();

                        log_info('仕入先伝票登録完了', [$payee_voucher->getId()]);
                        $this->addSuccess('admin.common.save_complete', 'admin');

                        return $this->redirectToRoute('admin_payee_voucher_edit_phone', ['id' => $payee_voucher->getId()]);
                    } catch (\Exception $e) {
                        $this->entityManager->rollback();
                        log_error('仕入先伝票登録エラー', [$id, $e]);
                        $this->addError($e->getMessage(), 'admin');
                    }
                } elseif ($request->get('mode') == 'register' && $form_payee_voucher_header) {
                    $this->entityManager->rollback();
                    $this->addError('admin.common.save_error', 'admin');
                }
            }
        } else {
            $total_quantity = 0;

            // 表示時明細の商品名称設定
            foreach ($form_payee_voucher_header['PayeeVoucherDetails'] as $form_detail) {
                /** @var FormInterface $form_detail */
                /** @var Product $product */
                $product = $this->productRepository->find($form_detail['product_id']
                    ->getData());
                $form_detail['product_name']->setData($product->getName());
                $form_detail['product_serial_flg']->setData($product->getSerialFlg());

                $parameter_stock_by_product = [
                    'productId' => $form_detail['product_id']->getData(),
                    'ProductClass' => $form_detail['ProductClass']->getData(),
                    'productCode' => $form_detail['product_code']->getData(),
                    'State' => $form_detail['State']->getData(),
                ];

                $collection_stock_list_product_unit = $this->stockListProductUnitRepository
                    ->findBy($parameter_stock_by_product);

                if (isset($collection_stock_list_product_unit[0])) {
                    $entity_stock_list_product_unit = $collection_stock_list_product_unit[0];
                    $form_detail['stock_quantity']->setData($entity_stock_list_product_unit['stockQuantity']);
                }

                if (!isset($array_special_cost[$form_detail['product_code']->getData()])) {
                    $total_quantity += $form_detail['quantity']->getData();
                }
            }

            // 数量合計
            $form_payee_voucher_header['total_quantity']->setData($total_quantity);
        }

        // 明細行数
        if ($form_payee_voucher_header['PayeeVoucherDetails'] && $form_payee_voucher_header['PayeeVoucherDetails']->count() > 0) {
            $now_row_no = max(
                    array_keys($form_payee_voucher_header['PayeeVoucherDetails']->getData()->toArray())
                ) + 1;
        } else {
            $now_row_no = 0;
        }

        $controls_enable['changed_control'] = 0;
        // ヘッダ関連する商品の在庫は変更されたかどうか
        foreach ($form_payee_voucher_header['PayeeVoucherDetails'] as $form_detail) {
            /** @var FormInterface $form_detail */
            if ($form_detail['detailIsSold']->getData() === '1' || $form_detail['detailIsMoved']->getData() === '1') {
                // 移動したまたは売った場合、制御する
                $controls_enable['changed_control'] = 1;
            }
        }

        // 伝票明細登録用コントロール
        $builder_payee_voucher_detail = $this->formFactory->createBuilder(PayeeVoucherDetailType::class);
        $form_payee_voucher_detail = $builder_payee_voucher_detail->getForm();

        // マスタデータチェック
        if ($this->paymentRepository->count([]) <= 0) {
            $this->addError(trans('admin.common.master_table_no_data_message', ['%table%' => 'dtb_payment']), 'admin');
        }
        if ($this->payeeMstRepository->count([]) <= 0) {
            $this->addError(trans('admin.common.master_table_no_data_message', ['%table%' => 'mtb_payee_mst']), 'admin');
        }
        if ($this->placeRepository->count([]) <= 0) {
            $this->addError(trans('admin.common.master_table_no_data_message', ['%table%' => 'mtb_place']), 'admin');
        }
        if ($this->productRepository->count([]) <= 0) {
            $this->addError(trans('admin.common.master_table_no_data_message', ['%table%' => 'dtb_product']), 'admin');
        }
        if ($this->stateRepository->count([]) <= 0) {
            $this->addError(trans('admin.common.master_table_no_data_message', ['%table%' => 'mtb_state']), 'admin');
        }

        // 商品検索フォーム
        $builder_search_payee = $this->formFactory->createBuilder(PayeeVoucherSearchPayeeType::class);

        $event = new EventArgs(
            [
                'builder' => $builder_search_payee,
                'PayeeVoucherHeader' => $entity_payee_voucher_header,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_VOUCHER_INDEX_SEARCH_PAYEE_INITIALIZE, $event);

        $search_payee_modal_form = $builder_search_payee->getForm();

        // 複数シリアル番号入力フォーム
        $builder_input_multiple_serial = $this->formFactory->createBuilder(InputMultipleSerialType::class);

        $event = new EventArgs(
            [
                'builder' => $builder_input_multiple_serial,
                'PayeeVoucherHeader' => $entity_payee_voucher_header,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_VOUCHER_INDEX_INPUT_MULTIPLE_SERIAL_INITIALIZE, $event);

        $input_multiple_serial_form = $builder_input_multiple_serial->getForm();

        // 状態
        $collection_entity_state = $this->stateRepository->getStateByCategory();

        // 「新品」状態
        $array_state_new = [];
        $array_entity_state_new = $this->stateRepository->findBy([
            'state' => '新品',
        ]);
        if ($array_entity_state_new && count($array_entity_state_new) > 0) {
            /** @var State $entity_state_new */
            foreach ($array_entity_state_new as $entity_state_new) {
                $array_state_new[$entity_state_new->getCategoryId()] = $entity_state_new->getId();
            }
        }

        // 商品検索フォーム
        $builder_search_product_modal = $this->formFactory
            ->createBuilder(SearchProductType::class);

        $event = new EventArgs(
            [
                'builder' => $builder_search_product_modal,
                'PayeeVoucherHeader' => $entity_payee_voucher_header,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_VOUCHER_INDEX_SEARCH_PRODUCT_SUB_INITIALIZE, $event);

        $searchProductModalForm = $builder_search_product_modal->getForm();

        $builder_csv_import = $this->formFactory
            ->createBuilder(CsvImportType::class);

        $event = new EventArgs(
            [
                'builder' => $builder_csv_import,
                'PayeeVoucherHeader' => $entity_payee_voucher_header,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_VOUCHER_INDEX_CSV_IMPORT_INITIALIZE, $event);

        $csv_import_form = $builder_csv_import->getForm();

        // 数量合計表示
        $total['total_quantity'] = trans('admin.payee.voucher.total_quantity')
            .number_format(
                (float) str_replace(',', '', $form_payee_voucher_header['total_quantity']->getData())
            );
        $total['payee_money_total_amount'] = trans('admin.payee.voucher.payee_money_total_amount')
            .number_format(
                (float) str_replace(',', '', $form_payee_voucher_header['payee_money_total_amount']->getData())
            ).self::YEN;

        $orderUpdateTime = null;
        if ($id != null) {
            $orderUpdateTime = $entity_payee_voucher_header->getUpdateDate()->format('Y-m-d H:i:s');
        }

        // ADD-START CNC 2022/10/29 sort
        $firstDetailsNo = 0;
        $secondDetailsNo = 0;

        if (count($form_payee_voucher_header->getData()->getPayeeVoucherDetails()) > 1) {
            $i = 0;
            foreach ($form_payee_voucher_header->getData()->getPayeeVoucherDetails() as $formDetails) {
                if ($i == 0) {
                    $firstDetailsNo = $formDetails['payee_detail_no'];
                } elseif ($i == 1) {
                    $secondDetailsNo = $formDetails['payee_detail_no'];
                } else {
                    break;
                }

                $i++;
            }
        }

        $key_list = [];
        foreach ($form_payee_voucher_header->getData()->getPayeeVoucherDetails() as $key => $formDetails) {
            array_push($key_list, $key);
        }

        $key_list = array_reverse($key_list);
        // ADD-END CNC 2022/10/29 sort

        return [
            'form' => $form_payee_voucher_header->createView(),
            'searchPayeeModalForm' => $search_payee_modal_form->createView(),
            'inputMultipleSerialForm' => $input_multiple_serial_form->createView(),
            'PayeeVoucherHeader' => $entity_payee_voucher_header,
            'payeeVoucherRegisterForm' => $form_payee_voucher_detail->createView(),
            'searchProductModalForm' => $searchProductModalForm->createView(),
            'csvImportForm' => $csv_import_form->createView(),
            'StateList' => $collection_entity_state,
            'StateNewList' => $array_state_new,
            'ControlsEnable' => $controls_enable,
            'detailDatumLength' => $now_row_no,
            'totalAmountInfo' => $total,
            'SpecialCost' => $array_special_cost,
            'payee_code'=> $payee_code,
            'header_flg'=> $header_flg,
            'orderUpdateTime' => $orderUpdateTime,
            // ADD-START CNC 2022/10/29 sort
            'firstDetailsNo' => $firstDetailsNo,
            'secondDetailsNo' => $secondDetailsNo,
            'keyList' => $key_list,
            // ADD-END CNC 2022/10/29 sort
        ];
    }

    /**
     * ヘッダー削除
     * @Route("/%eccube_admin_route%/payee_voucher/{id}/phone/delete", requirements={"id" = "\d+"}, name="admin_payee_voucher_phone_delete", methods={"DELETE"})
     * @param Request $request Request
     * @param int|null $id ID
     * @param CacheUtil|null $cacheUtil CacheUtil
     * @return \Symfony\Component\HttpFoundation\JsonResponse|RedirectResponse
     * @throws \Exception
     */
    public function delete(Request $request, int $id = null, CacheUtil $cacheUtil = null)
    {
        $this->isTokenValid();
        $session = $request->getSession();
        $page_no = intval($session->get('eccube.admin.payee_management.search.page_count'));
        $page_no = $page_no ? $page_no : Constant::ENABLED;
        $message = null;
        $success = false;
        $member = $this->getUser();

        if (!is_null($id)) {
            /** @var PayeeVoucherHeader $entity_payee_voucher_header */
            $entity_payee_voucher_header = $this->payeeVoucherHeaderRepository->find($id);
            if (!$entity_payee_voucher_header) {
                if ($request->isXmlHttpRequest()) {
                    $message = trans('admin.common.delete_error_already_deleted');

                    return $this->json(['success' => $success, 'message' => $message]);
                } else {
                    $this->deleteMessage();
                    $rUrl = $this->generateUrl('admin_payee_voucher_list', ['page_no' => $page_no]).'?resume='.Constant::ENABLED;

                    return $this->redirect($rUrl);
                }
            }

            // ヘッダー売上状態チェック
            if ($this->isSoldHeader($entity_payee_voucher_header)) {
                log_info('admin.payee.voucher.detail_delete_when_sold', [$id]);
                $this->addError(trans('admin.payee.voucher.detail_delete_when_sold'), 'admin');
                $rUrl = $this->generateUrl('admin_payee_voucher_edit_phone', ['id' => $id]);
                return $this->redirect($rUrl);
            }
            // 出金済み金額チェック
            $entity_payee_paid_balance = $entity_payee_voucher_header->getPayeePaidBalances()[0];
            if ($entity_payee_paid_balance) {
                if ($entity_payee_paid_balance->getPaidAmount() > 0) {
                    log_info('admin.payee.voucher.detail_delete_when_paid', [$id]);
                    $this->addError(trans('admin.payee.voucher.detail_delete_when_paid'), 'admin');
                    $rUrl = $this->generateUrl('admin_payee_voucher_edit_phone', ['id' => $id]);
                    return $this->redirect($rUrl);
                }
            }

            if ($entity_payee_voucher_header instanceof PayeeVoucherHeader) {
                log_info('仕入伝票ヘッダー削除開始', [$id]);

                $collection_payee_paid_balance = $entity_payee_voucher_header->getPayeePaidBalances();
                $collection_payee_voucher_detail = $entity_payee_voucher_header->getPayeeVoucherDetails();

                try {
                    // 関連仕入出金残高削除
                    if (isset($collection_payee_paid_balance[0])) {
                        $this->payeePaidBalanceRepository->delete($collection_payee_paid_balance[0]);
                    }
                    // 関連仕入伝票明細削除
                    if ($collection_payee_voucher_detail->count() > 0) {
                        foreach ($collection_payee_voucher_detail as $detail) {
                            $this->removeStockInfoWithDetailRemoved($detail, $entity_payee_voucher_header, $member->getName());
                            $this->removePictureByDetail($detail);
                            $this->payeeVoucherDetailRepository->delete($detail);
                        }
                    }

                    // 履歴（ヘッダ―）
                    $payee_voucher_history = $this->payeeVoucherHeaderHistoryRepository
                        ->createPayeeVoucherHeaderHistoryByHeader($entity_payee_voucher_header, PayeeVoucherHeaderHistory::BEHAVIOR_DELETE);
                    $this->entityManager->persist($payee_voucher_history);

                    $this->payeeVoucherHeaderRepository->delete($entity_payee_voucher_header);
                    $this->entityManager->flush();

                    $event = new EventArgs(
                        [
                            'PayeeVoucherHeader' => $entity_payee_voucher_header,
                            'PayeeVoucherDetail' => $collection_payee_voucher_detail,
                            'PayeePaidBalance' => $collection_payee_paid_balance,
                        ],
                        $request
                    );
                    $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_VOUCHER_DELETE_COMPLETE, $event);

                    log_info('仕入伝票ヘッダー削除完了', [$id]);

                    $success = true;
                    $message = trans('admin.common.delete_complete');

                    $cacheUtil->clearDoctrineCache();
                } catch (ForeignKeyConstraintViolationException $e) {
                    log_info('仕入伝票ヘッダー削除エラー', [$id]);
                    $message = trans('admin.common.delete_error_foreign_key', ['%name%' => $entity_payee_voucher_header->getPayeeVoucherNo()]);
                } catch (\Exception $e) {
                    log_info('仕入伝票ヘッダー削除エラー', [$id]);
                    $message = trans('admin.common.delete_error');
                }
            } else {
                log_info('仕入伝票ヘッダー削除エラー', [$id]);
                $message = trans('admin.common.delete_error');
            }
        } else {
            log_info('仕入伝票ヘッダー削除エラー', [$id]);
            $message = trans('admin.common.delete_error');
        }

        if ($request->isXmlHttpRequest()) {
            return $this->json(['success' => $success, 'message' => $message]);
        } else {
            if ($success) {
                $this->addSuccess($message, 'admin');
                $rUrl = $this->generateUrl('admin_payee_voucher_list', ['page_no' => $page_no]).'?resume='.Constant::ENABLED;
            } else {
                $this->addError($message, 'admin');
                $rUrl = $this->generateUrl('admin_payee_voucher_edit_phone', ['id' => $id]);
            }

            return $this->redirect($rUrl);
        }
    }

    /**
     * @param PayeeVoucherDetail $payee_voucher_detail PayeeVoucherDetail
     * @return bool
     */
    public function removePictureByDetail(PayeeVoucherDetail $payee_voucher_detail)
    {
        if (!$payee_voucher_detail->getSerialPicture()) {
            return true;
        }
        $entity_serial_picture = $payee_voucher_detail->getSerialPicture();
        try {
            $this->serialPictureRepository->delete($entity_serial_picture);
        } catch (\Exception $exception) {
            log_info('シリアル画像削除エラー', [$entity_serial_picture->getId()]);
            $message = trans('admin.common.delete_error');
            $this->addError($message, 'admin');
            return false;
        }
        return true;
    }

    /**
     * @param PayeeVoucherDetail $payee_voucher_detail 明細
     * @param PayeeVoucherHeader $payee_voucher_header 明細対応するヘッダー
     * @param string $user_name ユーザ名
     */
    public function removeStockInfoWithDetailRemoved(PayeeVoucherDetail $payee_voucher_detail, PayeeVoucherHeader $payee_voucher_header, string $user_name)
    {
        // 在庫一覧（商品単位）
        $parameter_stock_by_product = [
            'productId' => $payee_voucher_detail->getProductId(),
            'ProductClass' => $payee_voucher_detail->getProductClass(),
            'productCode' => $payee_voucher_detail->getProductCode(),
            'State' => $payee_voucher_detail->getState(),
        ];

        $collection_stock_list_product_unit = $this->stockListProductUnitRepository
            ->findBy($parameter_stock_by_product);

        if (isset($collection_stock_list_product_unit[0])) {
            /** @var StockListProductUnit $entity_stock_list_product_unit */
            $entity_stock_list_product_unit = $collection_stock_list_product_unit[0];
            $origin_entity_stock_list_product_unit = clone $entity_stock_list_product_unit;
            $stock_quantity_product_unit =
                $entity_stock_list_product_unit->getStockQuantity() - $payee_voucher_detail->getQuantity();
            $entity_stock_list_product_unit->setStockQuantity(
                $stock_quantity_product_unit
            )->setRemainingStockQuantity(
                $stock_quantity_product_unit
                - $origin_entity_stock_list_product_unit->getOrderQuantity()
                - $origin_entity_stock_list_product_unit->getProvisionalShipmentQuantity()
            )->setUpdateUserName($user_name);

            if ($stock_quantity_product_unit <= 0
                || $origin_entity_stock_list_product_unit->getAverageUnitPrice() * $origin_entity_stock_list_product_unit->getStockQuantity() <= 0
                || ($origin_entity_stock_list_product_unit->getAverageUnitPrice() * $origin_entity_stock_list_product_unit->getStockQuantity() - $payee_voucher_detail->getPayeeMoneyAmount()) / $stock_quantity_product_unit <= 0) {
                $entity_stock_list_product_unit->setAverageUnitPrice(round($payee_voucher_detail->getPayeeMoneyAmount()/$payee_voucher_detail->getQuantity()));
            }
            else {
                $entity_stock_list_product_unit->setAverageUnitPrice(
                    $stock_quantity_product_unit === 0
                        ? 0
                        : round(
                        (
                            $origin_entity_stock_list_product_unit->getAverageUnitPrice()
                            * $origin_entity_stock_list_product_unit->getStockQuantity()
                            - $payee_voucher_detail->getPayeeMoneyAmount()
                        ) / $stock_quantity_product_unit
                    )
                );
            }

            $this->entityManager->persist($entity_stock_list_product_unit);
            $this->entityManager->flush($entity_stock_list_product_unit);
            LogControllable::print_log(__FILE__, '########## Insert/update: stock list by product', [$entity_stock_list_product_unit->toArray()]);
        }

        // 在庫一覧（置場単位）
        $parameter_stock_by_place = [
            'productId' => $payee_voucher_detail->getProductId(),
            'ProductClass' => $payee_voucher_detail->getProductClass(),
            'productCode' => $payee_voucher_detail->getProductCode(),
            'serialNo' => $payee_voucher_detail->getSerialNo(),
            'State' => $payee_voucher_detail->getState(),
            'Storehouse' => $payee_voucher_header->getPlace(),
        ];
        $collection_stock_list_place_unit = $this->stockListStorehouseUnitRepository
            ->findBy($parameter_stock_by_place);

        if (isset($collection_stock_list_place_unit[0])) {
            /** @var StockListStorehouseUnit $entity_stock_list_place_unit */
            $entity_stock_list_place_unit = $collection_stock_list_place_unit[0];
            $stock_quantity = $entity_stock_list_place_unit->getStockQuantity() - $payee_voucher_detail->getQuantity();
            if ($stock_quantity === 0) {
                $this->entityManager->remove($entity_stock_list_place_unit);
                $this->entityManager->flush($entity_stock_list_place_unit);
                LogControllable::print_log(__FILE__, '########## Delete: stock list by storehouse', [$entity_stock_list_place_unit->toArray()]);
            } else {
                $entity_stock_list_place_unit->setStockQuantity($stock_quantity)
                    ->setUpdateUserName($user_name);
                $this->entityManager->persist($entity_stock_list_place_unit);
                $this->entityManager->flush($entity_stock_list_place_unit);
                LogControllable::print_log(__FILE__, '########## Insert/update: stock list by storehouse', [$entity_stock_list_place_unit->toArray()]);
            }
        }
    }

    /**
     * 支払方法：銀行振込 情報取得
     * @return Payment
     */
    public function getPaymentBankTransfer()
    {
        $array_payment_bank_transfer = $this->paymentRepository->findBy(['method' => '銀行振込']);
        return isset($array_payment_bank_transfer[0])
            ? $array_payment_bank_transfer[0]
            : null;
    }

    /**
     * 売上かどうか
     * @param PayeeVoucherDetail $entity_payee_voucher_detail 明細
     * @return bool
     */
    private function isSold(PayeeVoucherDetail $entity_payee_voucher_detail)
    {
        if ($entity_payee_voucher_detail->getPayeeVoucherHeader()) {
            $parameter = [
                'payeeVoucherHeader' => $entity_payee_voucher_detail->getPayeeVoucherHeader(),
                'payeeVoucherNo' => $entity_payee_voucher_detail->getPayeeVoucherNo(),
                'payeeDetailsNo' => $entity_payee_voucher_detail->getPayeeDetailNo(),
            ];
            $result = $this->salesVoucherDetailLinkRepository->count($parameter);
            return $result > 0;
        }
        return false;
    }

    /**
     * 売上ヘッダかどうか
     * @param PayeeVoucherHeader $entity_payee_voucher_header ヘッダー
     * @return bool
     */
    private function isSoldHeader(PayeeVoucherHeader $entity_payee_voucher_header)
    {
        if ($entity_payee_voucher_header) {
            $parameter = [
                'payeeVoucherHeader' => $entity_payee_voucher_header,
                'payeeVoucherNo' => $entity_payee_voucher_header->getPayeeVoucherNo(),
            ];
            $result = $this->salesVoucherDetailLinkRepository->count($parameter);
            return $result > 0;
        }
        return false;
    }
}
