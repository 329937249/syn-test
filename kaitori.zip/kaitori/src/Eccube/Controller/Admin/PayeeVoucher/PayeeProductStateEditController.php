<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\PayeeVoucher;

use Eccube\Controller\AbstractController;
use Eccube\Entity\Product;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\AddCartType;
use Eccube\Form\Type\Admin\PayeeProductStateEditType;
use Eccube\Form\Type\Admin\SearchProductType;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\PayeeProductStateRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\StateRepository;
use Eccube\Util\CacheUtil;
use Knp\Component\Pager\Paginator;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Twig_Environment;
use Eccube\Entity\PayeeProductState;
use Eccube\Common\Constant;
use Doctrine\DBAL\Exception\ForeignKeyConstraintViolationException;

/**
*プログラム名 ： PayeeProductStateEditController.php
*概　　要     ： 仕入商品状態登録
*作　　成     ： 2022/9/2 CNC
*/
class PayeeProductStateEditController extends AbstractController
{
    // 一覧画面URL
    const PREVIOUS_PAGE_URL_LIST = 'payee_management/payee_product_state_list';

    /**
     * @var Twig_Environment
     */
    protected $twig;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var ProductClassRepository
     */
    protected $productClassRepository;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var StateRepository
     */
    protected $StateRepository;

    /**
     * @var PayeeProductStateRepository
     */
    protected $PayeeProductStateRepository;

    /**
     * PayeeProductStateEditController constructor.
     * @param ProductRepository $productRepository
     * @param ProductClassRepository $productClassRepository
     * @param CategoryRepository $categoryRepository
     * @param StateRepository $StateRepository
     * @param PayeeProductStateRepository $PayeeProductStateRepository
     */
    public function __construct(
        Twig_Environment $twig,
        ProductRepository $productRepository,
        ProductClassRepository $productClassRepository,
        CategoryRepository $categoryRepository,
        StateRepository $StateRepository,
        PayeeProductStateRepository $PayeeProductStateRepository
    )
    {
        $this->twig = $twig;
        $this->productRepository = $productRepository;
        $this->productClassRepository = $productClassRepository;
        $this->categoryRepository = $categoryRepository;
        $this->StateRepository = $StateRepository;
        $this->PayeeProductStateRepository = $PayeeProductStateRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/payee_management/payee_product_state", name="admin_payee_payee_product_state")
     * @Route("/%eccube_admin_route%/payee_management/payee_product_state/edit/{id}", requirements={"id" = "\d+"}, name="admin_payee_payee_product_state_edit")
     * @Template("@admin/PayeeVoucher/payee_product_state_edit.twig")
     *
     * @param Request $request
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function index(Request $request, $id = null)
    {
        // 前ページurl
        if (strpos($request->headers->get('referer'), self::PREVIOUS_PAGE_URL_LIST)) {
            $link = 1;
        } else {
            $link = 0;
        }

        // 状態変更の場合、処理対象再取込
        if ('POST' === $request->getMethod()) {
            $productCode = $request->get('PayeeProductState')['productCode'];
        }
        else
        {
            $productCode = null;
        }

        // 新規登録
        if ($id == null) {
            $payeeProductState = new PayeeProductState();

            // 更新情報未設定
            $update_date = null;
            $update_User_Name = null;
            // 作成者追加
            $payeeProductState->setCreateUserName($this->getUser());
            $payeeProductState->setUpdateUserName($this->getUser());
        }
        else {

            // 連動商品
            $payeeProductState = $this->PayeeProductStateRepository->find($id);

            // 更新情報取得
            $update_date = $payeeProductState->getUpdateDate()->format('Y/m/d H:i:s');
            $update_User_Name = $payeeProductState->getUpdateUserName();
        }

        // 商品選択フォーム
        $builder = $this->formFactory
            ->createBuilder(SearchProductType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_PRODUCT_STATE_SEARCH_PRODUCT_INITIALIZE, $event);

        $searchProductModalForm = $builder->getForm();

        // 連動商品フォーム
        $builder = $this->formFactory->createBuilder(PayeeProductStateEditType::class, $payeeProductState);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'payeeProductState' => $payeeProductState,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_PRODUCT_STATE_INDEX_INITIALIZE, $event);


        $form = $builder->getForm();

        if (!is_null($productCode)) {
            /** @var $Product \Eccube\Entity\Product */
            $product = $this->productRepository->findProductsWithProductCode($productCode);

            if (!empty($product) && !empty($product[0])) {
                /** @var Product $entity_product */
                $category_id = $product[0]['category_id'];
            } else {
                $category_id = null;
            }
        } else {
            $category_id = null;
        }

        // 状態
        $entity_state = $this->StateRepository->getStateByCategory();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            if ($id == null){
                $entity_product = $this->productRepository->find($request->get('PayeeProductState')['productId']);
                $entity_productClass = $this->productClassRepository->find($request->get('PayeeProductState')['productClassId']);

                $payeeProductState->setProductId($entity_product);
                $payeeProductState->setProductClassId($entity_productClass);

                $chkPayeeProductState = $this->PayeeProductStateRepository->findBy(
                    [
                        'product_code' => $payeeProductState->getProductCode(),
                    ]);

                if (isset($chkPayeeProductState) && isset($chkPayeeProductState[0])) {
                    $this->addError('admin.payee.voucher.payee_product_state_code_no', 'admin');
                    return $this->redirectToRoute('admin_payee_payee_product_state_list');
                }
            }

            $state = $this->StateRepository->find($payeeProductState->getState());
            $payeeProductState->setStateName($state->getState());

            $this->entityManager->persist($payeeProductState);
            $this->entityManager->flush();

            $event = new EventArgs(
                [
                    'form' => $form,
                    'payeeProductState' => $payeeProductState,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(
                EccubeEvents::ADMIN_PAYEE_PRODUCT_STATE_INDEX_COMPLETE,
                $event
            );

            $this->addSuccess('admin.common.save_complete', 'admin');

            return $this->redirectToRoute('admin_payee_payee_product_state_edit', ['id' => $payeeProductState->getId()]);
        }

        return [
            'form' => $form->createView(),
            'searchProductModalForm' => $searchProductModalForm->createView(),
            'id' => $id,
            'StateList' => $entity_state,
            'category_id' => $category_id,
            'link' => $link,
            'update_date' => $update_date,
            'update_user_name' => $update_User_Name,
        ];
    }

    /**
     *  伝票更新時間取得
     *
     * @Route("/%eccube_admin_route%/payee_product_state/search/date", name="admin_payee_product_state_search_date")
     * @param Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchOrderUpdateDate(Request $request, Paginator $paginator)
    {
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
        }

        $result = [];
        $id = $request->get('headerId');

        if (!is_null($id)) {
            $entity_payee_product_state_header = $this->PayeeProductStateRepository->find($id);
            if ($entity_payee_product_state_header) {
                $orderUpdateTimeNew = $entity_payee_product_state_header->getUpdateDate()->format('Y-m-d H:i:s');
                $result['orderUpdateTimeNew'] = $orderUpdateTimeNew;
            } else {
                $result['orderUpdateTimeNew'] = "";
            }
        }

        return $this->json(array_merge(['status' => 'OK'], $result));
    }

    /**
     * 仕入商品状態ー削除
     * @Route("/%eccube_admin_route%/payee_product_state/{id}/delete", requirements={"id" = "\d+"}, name="admin_payee_product_state_delete", methods={"DELETE"})
     * @param Request $request Request
     * @param int|null $id ID
     * @param CacheUtil|null $cacheUtil CacheUtil
     * @return \Symfony\Component\HttpFoundation\JsonResponse|RedirectResponse
     * @throws \Exception
     */
    public function delete(Request $request, int $id = null, CacheUtil $cacheUtil = null)
    {
        $this->isTokenValid();
        $session = $request->getSession();
        $page_no = intval($session->get('eccube.admin.payee_management.search.page_count'));
        $page_no = $page_no ? $page_no : Constant::ENABLED;
        $message = null;
        $success = false;

        if (!is_null($id)) {
            /** @var PayeeProductState $entity_payee_product_state_header */
            $entity_payee_product_state_header = $this->PayeeProductStateRepository->find($id);
            if (!$entity_payee_product_state_header) {
                if ($request->isXmlHttpRequest()) {
                    $message = trans('admin.common.delete_error_already_deleted');

                    return $this->json(['success' => $success, 'message' => $message]);
                } else {
                    $this->deleteMessage();
                    $rUrl = $this->generateUrl('admin_payee_payee_product_state_list', ['page_no' => $page_no]).'?resume='.Constant::ENABLED;

                    return $this->redirect($rUrl);
                }
            }

            if ($entity_payee_product_state_header instanceof PayeeProductState) {
                log_info('仕入商品状態ー削除開始', [$id]);

                try {

                    $this->PayeeProductStateRepository->delete($entity_payee_product_state_header);
                    $this->entityManager->flush();


                    log_info('仕入商品状態ー削除完了', [$id]);

                    $success = true;
                    $message = trans('admin.common.delete_complete');

                    $cacheUtil->clearDoctrineCache();
                } catch (ForeignKeyConstraintViolationException $e) {
                    log_info('仕入商品状態ー削除エラー', [$id]);
                    $message = trans('admin.common.delete_error_foreign_key', ['%name%' => $entity_payee_product_state_header->getProductCode()]);
                } catch (\Exception $e) {
                    log_info('仕入商品状態ー削除エラー', [$id]);
                    $message = trans('admin.common.delete_error');
                }
            } else {
                log_info('仕入商品状態ー削除エラー', [$id]);
                $message = trans('admin.common.delete_error');
            }
        } else {
            log_info('仕入商品状態ー削除エラー', [$id]);
            $message = trans('admin.common.delete_error');
        }

        if ($request->isXmlHttpRequest()) {
            return $this->json(['success' => $success, 'message' => $message]);
        } else {
            if ($success) {
                $this->addSuccess($message, 'admin');
                $rUrl = $this->generateUrl('admin_payee_payee_product_state_list', ['page_no' => $page_no]).'?resume='.Constant::ENABLED;
            } else {
                $this->addError($message, 'admin');
                $rUrl = $this->generateUrl('admin_payee_payee_product_state_edit', ['id' => $id]);
            }

            return $this->redirect($rUrl);
        }
    }

    /**
     *  商品選択
     *
     * @Route("/%eccube_admin_route%/payee_management/search/product", name="admin_payee_voucher_search_product_state")
     * @Route("/%eccube_admin_route%/payee_management/search/product/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_payee_voucher_search_product_state_page")
     * @Template("@admin/PayeeVoucher/search_product_state.twig")
     */
    public
    function searchProduct(Request $request, $page_no = null, Paginator $paginator)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('search product start.');
            $page_count = $this->eccubeConfig['eccube_default_page_count'];
            $session = $this->session;

            if ('POST' === $request->getMethod()) {
                $page_no = 1;

                $searchData = [
                    'id' => $request->get('id'),
                ];

                if ($categoryId = $request->get('category_id')) {
                    $Category = $this->categoryRepository->find($categoryId);
                    $searchData['category_id'] = $Category;
                }

                $session->set('eccube.admin.payee_management.product.search', $searchData);
                $session->set('eccube.admin.payee_management.product.search.page_no', $page_no);
            } else {
                $searchData = (array)$session->get('eccube.admin.payee_management.product.search');
                if (is_null($page_no)) {
                    $page_no = intval($session->get('eccube.admin.payee_management.product.search.page_no'));
                } else {
                    $session->set('eccube.admin.payee_management.product.search.page_no', $page_no);
                }
            }

            $qb = $this->productRepository
                ->getQueryBuilderBySearchDataForAdmin($searchData);

            $event = new EventArgs(
                [
                    'qb' => $qb,
                    'searchData' => $searchData,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_SEARCH_PRODUCT_SEARCH, $event);

            /** @var \Knp\Component\Pager\Pagination\SlidingPagination $pagination */
            $pagination = $paginator->paginate(
                $qb,
                $page_no,
                $page_count,
                ['wrap-queries' => true]
            );

            /** @var $Products \Eccube\Entity\Product[] */
            $Products = $pagination->getItems();

            if (empty($Products)) {
                log_debug('search product not found.');
            }

            $forms = [];
            foreach ($Products as $Product) {
                /* @var $builder \Symfony\Component\Form\FormBuilderInterface */
                $builder = $this->formFactory->createNamedBuilder('', AddCartType::class, null, [
                    'product' => $this->productRepository->findWithSortedClassCategories($Product->getId()),
                ]);
                $addCartForm = $builder->getForm();
                $forms[$Product->getId()] = $addCartForm->createView();
            }

            $event = new EventArgs(
                [
                    'forms' => $forms,
                    'Products' => $Products,
                    'pagination' => $pagination,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_SEARCH_PRODUCT_COMPLETE, $event);

            return [
                'forms' => $forms,
                'Products' => $Products,
                'pagination' => $pagination,
            ];
        }
    }
}
