<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Setting\Shop;

use Doctrine\DBAL\Exception\ForeignKeyConstraintViolationException;
use Eccube\Controller\AbstractController;
use Eccube\Entity\CategorySeo;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Util\CacheUtil;
use Eccube\Form\Type\Admin\CategoryInfoRegisterType;
use Eccube\Form\Type\Admin\CategoryType;
use Eccube\Form\Type\Admin\CategorySeoType;
use Eccube\Repository\categoryInfoRepository;
use Eccube\Repository\Master\SaleTypeRepository;
use Eccube\Repository\CategoryRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\UnsupportedMediaTypeHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Class ShopCategorySeoController
 */
class ShopCategorySeoController extends AbstractController
{

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var SaleTypeRepository
     */
    protected $saleTypeRepository;

    /**
     * ShopCategorySeoController constructor.
     * @param CategoryRepository $categoryRepository
     * @param SaleTypeRepository $saleTypeRepository
     */
    public function __construct(
        CategoryRepository $categoryRepository,
        SaleTypeRepository $saleTypeRepository
    ){
        $this->categoryRepository = $categoryRepository;
        $this->saleTypeRepository = $saleTypeRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/content/shop/categoryseo", name="admin_setting_shop_category_seo")
     * @Route("/%eccube_admin_route%/content/shop/categoryseo/{parent_id}", requirements={"parent_id" = "\d+"}, name="admin_setting_shop_category_seo_show")
     * @Template("@admin/Setting/Shop/categoryseo.twig")
     */
    public function index(Request $request, $parent_id = null, $id = null, CacheUtil $cacheUtil)
    {
        if ($parent_id) {
            /** @var Category $Parent */
            $Parent = $this->categoryRepository->find($parent_id);
            if (!$Parent) {
                throw new NotFoundHttpException();
            }
        } else {
            $Parent = null;
        }
        if ($id) {
            $TargetCategory = $this->categoryRepository->find($id);
            if (!$TargetCategory) {
                throw new NotFoundHttpException();
            }
            $Parent = $TargetCategory->getParent();
        } else {
            $TargetCategory = new \Eccube\Entity\Category();
            $TargetCategory->setParent($Parent);
            if ($Parent) {
                $TargetCategory->setHierarchy($Parent->getHierarchy() + 1);
            } else {
                $TargetCategory->setHierarchy(1);
            }
        }

        $Categories = $this->categoryRepository->getList($Parent);

        // ツリー表示のため、ルートからのカテゴリを取得
        $TopCategories = $this->categoryRepository->getList(null);

        $builder = $this->formFactory
            ->createBuilder(CategoryType::class, $TargetCategory);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'Parent' => $Parent,
                'TargetCategory' => $TargetCategory,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_CATEGORY_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();

        $forms = [];
        foreach ($Categories as $Category) {
            $forms[$Category->getId()] = $this->formFactory
                ->createNamed('category_'.$Category->getId(), CategoryType::class, $Category);
        }

        if ($request->getMethod() === 'POST') {
            $form->handleRequest($request);
            if ($form->isValid()) {
                if ($this->eccubeConfig['eccube_category_nest_level'] < $TargetCategory->getHierarchy()) {
                    throw new BadRequestHttpException();
                }

                $this->categoryRepository->save($TargetCategory);

                $event = new EventArgs(
                    [
                        'form' => $form,
                        'Parent' => $Parent,
                        'TargetCategory' => $TargetCategory,
                    ],
                    $request
                );
                $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_CATEGORY_INDEX_COMPLETE, $event);

                $this->addSuccess('admin.common.save_complete', 'admin');

                $cacheUtil->clearDoctrineCache();

                if ($Parent) {
                    return $this->redirectToRoute('admin_product_category_show', ['parent_id' => $Parent->getId()]);
                } else {
                    return $this->redirectToRoute('admin_product_category');
                }
            }

            foreach ($forms as $editForm) {
                $editForm->handleRequest($request);
                if ($editForm->isSubmitted() && $editForm->isValid()) {
                    $this->categoryRepository->save($editForm->getData());

                    $event = new EventArgs(
                        [
                            'form' => $form,
                            'editForm' => $editForm,
                            'Parent' => $Parent,
                            'TargetCategory' => $editForm->getData(),
                        ],
                        $request
                    );

                    $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_CATEGORY_INDEX_COMPLETE, $event);

                    $this->addSuccess('admin.common.save_complete', 'admin');

                    $cacheUtil->clearDoctrineCache();

                    if ($Parent) {
                        return $this->redirectToRoute('admin_product_category_show', ['parent_id' => $Parent->getId()]);
                    } else {
                        return $this->redirectToRoute('admin_product_category');
                    }
                }
            }
        }

        $formViews = [];
        foreach ($forms as $key => $value) {
            $formViews[$key] = $value->createView();
        }

        $Ids = [];
        if ($Parent && $Parent->getParents()) {
            foreach ($Parent->getParents() as $item) {
                $Ids[] = $item['id'];
            }
        }
        $Ids[] = intval($parent_id);

        return [
            'form' => $form->createView(),
            'Parent' => $Parent,
            'Ids' => $Ids,
            'Categories' => $Categories,
            'TopCategories' => $TopCategories,
            'TargetCategory' => $TargetCategory,
            'forms' => $formViews,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/content/shop/categoryseo/{id}/edit", requirements={"id" = "\d+"}, name="admin_setting_shop_category_seo_edit")
     * @Template("@admin/Setting/Shop/category_seo_edit.twig")
     *
     * @param Request $request
     * @param id $id
     * @return string
     */
    public function edit(Request $request, $id)
    {
        $Category = $this->categoryRepository->find($id);
        if (!$Category) {
           throw new NotFoundHttpException();
        }

        $CategorySeo = $Category->getCategorySeo();
        if(is_null($CategorySeo)){
           $CategorySeo = new CategorySeo();
        }
        
        $builder = $this->formFactory->createBuilder(CategorySeoType::class, $CategorySeo);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'CategorySeo' => $CategorySeo,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_CATEGORY_SEO_EDIT_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
                $this->entityManager->persist($CategorySeo);
                $this->entityManager->flush($CategorySeo);
                $Category->setCategorySeo($CategorySeo);
                $this->entityManager->flush($Category);
                $event = new EventArgs(
                [
                    'form' => $form,
                    'CategorySeo' => $CategorySeo,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_CATEGORY_SEO_EDIT_INDEX_INITIALIZE, $event);
            
            return $this->redirectToRoute('admin_setting_shop_category_seo_edit', [
                'id' => $Category->getId(),
            ]);
        }

        $SaleTypeAll = $this->saleTypeRepository->findAll();
        $SaleType = $Category->getSaleType($SaleTypeAll);
        return [
            'SaleType' => $SaleType,
            'CategorySeo' => $CategorySeo,
            'Category' => $Category,
            'form' => $form->createView(),
        ];
    }
    
}
