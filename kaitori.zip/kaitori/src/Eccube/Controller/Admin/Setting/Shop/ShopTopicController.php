<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Setting\Shop;

use Doctrine\DBAL\Exception\ForeignKeyConstraintViolationException;
use Eccube\Controller\AbstractController;
use Eccube\Entity\ShopTopic;
use Eccube\Entity\ShopTopicSite;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\ShopTopicRegisterType;
use Eccube\Repository\ShopTopicRepository;
use Eccube\Repository\ShopTopicSitesRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\UnsupportedMediaTypeHttpException;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Class ShopTopicController
 */
class ShopTopicController extends AbstractController
{
    /**
     * @var ShopTopicRepository
     */
    protected $shopTopicRepository;

    /**
     * @var ShopTopicSitesRepository
     */
    protected $shopTopicSitesRepository;

    /**
     * ShopTopicController constructor.
     *
     * @param ShopTopicRepository $shopTopicRepository
     * @param ShopTopicSitesRepository $shopTopicSitesRepository
     */
    public function __construct(ShopTopicRepository $shopTopicRepository,
    ShopTopicSitesRepository $shopTopicSitesRepository)
    {
        $this->shopTopicRepository = $shopTopicRepository;
        $this->shopTopicSitesRepository = $shopTopicSitesRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/content/shop/topic", name="admin_setting_shop_topic")
     * @Template("@admin/Setting/Shop/shoptopic.twig")
     */
    public function index(Request $request)
    {
        $Topics = $this->shopTopicRepository
            ->findBy(
                [],
                ['sort_no' => 'DESC']
            );

        $event = new EventArgs(
            [
                'Topics' => $Topics,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_TOPIC_INDEX_COMPLETE, $event);

        return [
            'Topics' => $Topics,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/content/shop/topic/new", name="admin_setting_shop_topic_new")
     * @Route("/%eccube_admin_route%/content/shop/topic/{id}/edit", requirements={"id" = "\d+"}, name="admin_setting_shop_topic_edit")
     * @Template("@admin/Setting/Shop/shoptopic_edit.twig")
     */
    public function edit(Request $request, ShopTopic $ShopTopic = null)
    {
        if (is_null($ShopTopic)) {
            $ShopTopic = $this->shopTopicRepository->findOneBy([], ['sort_no' => 'DESC']);
            $sortNo = 1;
            if ($ShopTopic) {
                $sortNo = $ShopTopic->getSortNo() + 1;
            }

            $ShopTopic = new \Eccube\Entity\ShopTopic();
            $ShopTopic
                ->setSortNo($sortNo)
                ->setVisible(true);
        }

        $builder = $this->formFactory
            ->createBuilder(ShopTopicRegisterType::class, $ShopTopic);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'ShopTopic' => $ShopTopic,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_TOPIC_EDIT_INITIALIZE, $event);

        $form = $builder->getForm();

        // siteをセット
        $SiteTypes = [];
        foreach ($ShopTopic->getShopTopicSites() as $ShopTopicSite) {
            $SiteTypes[] = $ShopTopicSite->getSiteType();
        }
        
        $form['site_type']->setData($SiteTypes);

        // 既に画像保存されてる場合は取得する
        $oldTopicImage = $ShopTopic->getTopicImage();

        // 登録ボタン押下
        if ($request->getMethod() === 'POST') {
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()) {
                $ShopTopic = $form->getData();

                // ファイルアップロード
                $file = $form['topic_image']->getData();
                $fs = new Filesystem();
                if ($file && $fs->exists($this->getParameter('eccube_temp_image_dir').'/'.$file)) {
                    $fs->rename(
                        $this->getParameter('eccube_temp_image_dir').'/'.$file,
                        $this->getParameter('eccube_save_image_dir').'/'.$file
                    );
                }

                $this->entityManager->persist($ShopTopic);
                $this->entityManager->flush();

                // site登録
                $shopTopicSites = $this->shopTopicSitesRepository
                ->findBy(['shop_topic_id' => $ShopTopic->getId()]);
                // 消す
                foreach ($shopTopicSites as $shopTopicSite) {
                    $ShopTopic->removeShopTopicSite($shopTopicSite);
                    $this->entityManager->remove($shopTopicSite);
                }
                $this->entityManager->persist($ShopTopic);
                $this->entityManager->flush();

                // いれる
                $SiteTypes = $form->get('site_type')->getData();
                foreach ($SiteTypes as $SiteType) {
                    $shopTopicSite = new shopTopicSite();
                    $shopTopicSite
                        ->setSiteTypeId($SiteType->getId())
                        ->setSiteType($SiteType)
                        ->setShopTopicId($ShopTopic->getId())
                        ->setShopTopic($ShopTopic);
                    $ShopTopic->addShopTopicSite($shopTopicSite);
                    $this->entityManager->persist($shopTopicSite);
                }
                $this->entityManager->persist($ShopTopic);
                $this->entityManager->flush();

                $event = new EventArgs(
                    [
                        'form' => $form,
                        'ShopTopic' => $ShopTopic,
                    ],
                    $request
                );
                $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_TOPIC_EDIT_COMPLETE, $event);

                $this->addSuccess('admin.common.save_complete', 'admin');

                return $this->redirectToRoute('admin_setting_shop_topic_edit', ['id' => $ShopTopic->getId()]);
            }
        }

        return [
            'form' => $form->createView(),
            'topic_id' => $ShopTopic->getId(),
            'ShopTopic' => $ShopTopic,
            'oldTopicImage' => $oldTopicImage,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/content/shop/topic/image/add", name="admin_topic_image_add")
     */
    public function imageAdd(Request $request)
    {
        if (!$request->isXmlHttpRequest()) {
            throw new BadRequestHttpException();
        }

        $images = $request->files->get('topic_register');
        $allowExtensions = ['gif', 'jpg', 'jpeg', 'png'];
        $filename = null;
        if (isset($images['topic_image_file'])) {
            $image = $images['topic_image_file'];

            //ファイルフォーマット検証
            $mimeType = $image->getMimeType();
            if (0 !== strpos($mimeType, 'image')) {
                throw new UnsupportedMediaTypeHttpException();
            }

            // 拡張子
            $extension = $image->getClientOriginalExtension();
            if (!in_array(strtolower($extension), $allowExtensions)) {
                throw new UnsupportedMediaTypeHttpException();
            }

            $filename = date('mdHis').uniqid('_').'.'.$extension;
            $image->move($this->getParameter('eccube_temp_image_dir'), $filename);
        }
        $event = new EventArgs(
            [
                'images' => $images,
                'filename' => $filename,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_TOPIC_IMAGE_ADD_COMPLETE, $event);
        $filename = $event->getArgument('filename');

        return $this->json(['filename' => $filename], 200);
    }

    /**
     * @Route("/%eccube_admin_route%/content/shop/topic/{id}/delete", requirements={"id" = "\d+"}, name="admin_setting_shop_topic_delete", methods={"DELETE"})
     *
     * @param Request $request
     * @param ShopTopic $TargetShopTopic
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function delete(Request $request, ShopTopic $TargetShopTopic)
    {
        $this->isTokenValid();

        $sortNo = 1;
        $ShopTopics = $this->shopTopicRepository->findBy([], ['sort_no' => 'ASC']);
        foreach ($ShopTopics as $ShopTopic) {
            $ShopTopic->setSortNo($sortNo++);
        }

        try {
            $this->shopTopicRepository->delete($TargetShopTopic);
            $this->entityManager->flush();

            $event = new EventArgs(
                [
                    'ShopTopic' => $TargetShopTopic,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_TOPIC_DELETE_COMPLETE, $event);

            $this->addSuccess('admin.common.delete_complete', 'admin');
        } catch (ForeignKeyConstraintViolationException $e) {
            $this->entityManager->rollback();

            $message = trans('admin.common.delete_error_foreign_key', ['%name%' => $TargetShopTopic->getName()]);
            $this->addError($message, 'admin');
        }

        return $this->redirectToRoute('admin_setting_shop_topic');
    }

    /**
     * @Route("/%eccube_admin_route%/content/shop/topic/{id}/visible", requirements={"id" = "\d+"}, name="admin_setting_shop_topic_visible", methods={"PUT"})
     */
    public function visible(ShopTopic $ShopTopic)
    {
        $this->isTokenValid();

        $ShopTopic->setVisible(!$ShopTopic->isVisible());

        $this->entityManager->flush();

        if ($ShopTopic->isVisible()) {
            $this->addSuccess(trans('admin.common.to_show_complete', ['%name%' => $ShopTopic->getName()]), 'admin');
        } else {
            $this->addSuccess(trans('admin.common.to_hide_complete', ['%name%' => $ShopTopic->getName()]), 'admin');
        }

        return $this->redirectToRoute('admin_setting_shop_topic');
    }

    /**
     * @Route("/%eccube_admin_route%/content/shop/topic/sort_no/move", name="admin_setting_shop_topic_sort_no_move", methods={"POST"})
     *
     * @param Request $request
     *
     * @return Response
     */
    public function moveSortNo(Request $request)
    {
        if (!$request->isXmlHttpRequest()) {
            throw new BadRequestHttpException();
        }

        if ($this->isTokenValid()) {
            $sortNos = $request->request->all();
            foreach ($sortNos as $topicId => $sortNo) {
                /** @var ShopTopic $ShopTopic */
                $ShopTopic = $this->shopTopicRepository
                    ->find($topicId);
                $ShopTopic->setSortNo($sortNo);
                $this->entityManager->persist($ShopTopic);
            }
            $this->entityManager->flush();

            return new Response();
        }
    }
}
