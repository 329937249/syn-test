<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Setting\Shop;

use Doctrine\DBAL\Exception\ForeignKeyConstraintViolationException;
use Eccube\Controller\AbstractController;
use Eccube\Entity\Master\SaleType;
use Eccube\Entity\ProductClass;
use Eccube\Entity\ProductRecommend;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\SearchProductType;
use Eccube\Form\Type\Admin\ProductRecommendEditType;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\ProductRecommendRepository;
use Eccube\Repository\Master\SaleTypeRepository;
use Eccube\Util\CacheUtil;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Filesystem\Filesystem;
use Knp\Component\Pager\Paginator;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\UnsupportedMediaTypeHttpException;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Class ShopRecommendController
 */
class ShopRecommendController extends AbstractController
{
    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var ProductClassRepository
     */
    protected $productClassRepository;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var SaleTypeRepository
     */
    protected $saleTypeRepository;

    /**
     * @var ProductRecommendRepository
     */
    protected $productRecommendRepository;

    /**
     * ShopCategoryInfoController constructor.
     *
     * @param ProductRepository $productRepository
     * @param SaleTypeRepository $saleTypeRepository
     * @param ProductClassRepository $productClassRepository
     * @param CategoryRepository $categoryRepository
     * @param ProductRecommendRepository $productRecommendRepository
     */
    public function __construct(
        ProductRepository $productRepository,
        SaleTypeRepository $saleTypeRepository,
        ProductClassRepository $productClassRepository,
        CategoryRepository $categoryRepository,
        ProductRecommendRepository $productRecommendRepository)
    {
        $this->productRepository = $productRepository;
        $this->saleTypeRepository = $saleTypeRepository;
        $this->productClassRepository = $productClassRepository;
        $this->categoryRepository = $categoryRepository;
        $this->productRecommendRepository = $productRecommendRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/setting/shop/recommend", name="admin_setting_shop_recommend")
     * @Route("/%eccube_admin_route%/product/recommend", name="admin_product_recommend")
     * @Template("@admin/Setting/Shop/product_recommend.twig")
     */
    public function index(Request $request)
    {
        return [];
    }

    /**
     * @Route("/%eccube_admin_route%/setting/shop/recommend/{id}/edit", requirements={"id" = "\d+"}, name="admin_setting_shop_recommend_edit")
     * @Route("/%eccube_admin_route%/product/recommend/{id}/edit", requirements={"id" = "\d+"}, name="admin_product_recommend_edit")
     * @Template("@admin/Setting/Shop/product_recommend_edit.twig")
     */
    public function edit(Request $request, SaleType $SaleType)
    {
        if (is_null($SaleType)) {
            $route = $request->attributes->get('_route');
            if ($route == 'admin_product_recommend_edit') {
                return $this->redirectToRoute('admin_product_recommend');
            } else {
                return $this->redirectToRoute('admin_setting_shop_recommend');
            }
        }

        $ProductRecommends = $this->productRecommendRepository->findBy(['SaleType' => $SaleType],["sort_no"=> "DESC"]);

        // 商品検索フォーム
        $builder = $this->formFactory
            ->createBuilder(SearchProductType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ORDER_EDIT_SEARCH_PRODUCT_INITIALIZE, $event);

        $searchProductModalForm = $builder->getForm();

        return [
            'searchProductModalForm' => $searchProductModalForm->createView(),
            'SaleType' => $SaleType,
            'ProductRecommends' => $ProductRecommends,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/setting/shop/recommend/search/product", name="admin_setting_shop_recommend_search_product")
     * @Route("/%eccube_admin_route%/setting/shop/recommend/product/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_setting_shop_recommend_search_product_page")
     * @Route("/%eccube_admin_route%/product/recommend/search/product", name="admin_product_recommend_search_product")
     * @Route("/%eccube_admin_route%/product/recommend/product/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_product_recommend_search_product_page")
     * @Template("@admin/Setting/Shop/product_recommend_search_product.twig")
     */
    public function searchProduct(Request $request, $page_no = null, Paginator $paginator)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            $SaleType = $request->get('saletype_id');

            $page_count = $this->eccubeConfig['eccube_default_page_count'];
            $session = $this->session;

            if ('POST' === $request->getMethod()) {
                $page_no = 1;

                $searchData = [
                    'id' => $request->get('id'),
                ];

                if ($categoryId = $request->get('category_id')) {
                    $Category = $this->categoryRepository->find($categoryId);
                    $searchData['category_id'] = $Category;
                }

                $session->set('eccube.admin.shop.product.search', $searchData);
                $session->set('eccube.admin.shop.product.search.page_no', $page_no);
            } else {
                $searchData = (array) $session->get('eccube.admin.shop.product.search');
                if (is_null($page_no)) {
                    $page_no = intval($session->get('eccube.admin.shop.product.search.page_no'));
                } else {
                    $session->set('eccube.admin.shop.product.search.page_no', $page_no);
                }
            }

            $qb = $this->productRepository
                ->getQueryBuilderBySearchDataForAdmin($searchData);

            $event = new EventArgs(
                [
                    'qb' => $qb,
                    'searchData' => $searchData,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ORDER_EDIT_SEARCH_PRODUCT_SEARCH, $event);

            /** @var \Knp\Component\Pager\Pagination\SlidingPagination $pagination */
            $pagination = $paginator->paginate(
                $qb,
                $page_no,
                $page_count,
                ['wrap-queries' => true]
            );

            /** @var $Products \Eccube\Entity\Product[] */
            $Products = $pagination->getItems();

            if (empty($Products)) {
                log_debug('search product not found.');
            }

            $forms = [];
            foreach ($Products as $Product) {
                /* @var $builder \Symfony\Component\Form\FormBuilderInterface */
                log_debug('createNamedBuilder.',[$Product->getId()]);
                $builder = $this->formFactory->createNamedBuilder('', ProductRecommendEditType::class, null, [
                    'product' => $this->productRepository->findWithSortedClassCategories($Product->getId()),
                ]);
                $productForm = $builder->getForm();
                $forms[$Product->getId()] = $productForm->createView();
            }

            $event = new EventArgs(
                [
                    'forms' => $forms,
                    'Products' => $Products,
                    'pagination' => $pagination,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ORDER_EDIT_SEARCH_PRODUCT_COMPLETE, $event);

            return [
                'forms' => $forms,
                'Products' => $Products,
                'pagination' => $pagination,
                'SaleType' => $SaleType,
            ];
        }
    }

    /**
     * @Route("/%eccube_admin_route%/setting/shop/recommend/add", name="admin_setting_shop_recommend_add")
     * @Route("/%eccube_admin_route%/product/recommend/add", name="admin_product_recommend_add")
     * @Template("@admin/Setting/Shop/product_recommend_items.twig")
     */
    public function productAdd(Request $request)
    {
        if (!$request->isXmlHttpRequest()) {
            throw new BadRequestHttpException();
        }

        if (!$request->get('id')) {
            throw new BadRequestHttpException();
        }

        $ProductClass = $this->productClassRepository->find($request->get('id'));
        //$SaleType = $ProductClass->getSaleType();
        $SaleType_id = $request->get('saletype_id');
        $SaleType = $this->saleTypeRepository->find($SaleType_id);

        $ProductRecommend = $this->productRecommendRepository->findBy(['ProductClass' => $ProductClass, 'SaleType' => $SaleType],["sort_no"=> "DESC"]);
        if (!$ProductRecommend) {
            try {
                $productRecommend = new productRecommend();
                $productRecommend->setProductClass($ProductClass);
                $productRecommend->setSaleType($SaleType);
                $this->productRecommendRepository->save($productRecommend);
                $this->entityManager->flush();

                $event = new EventArgs(
                    [
                        'productRecommend' => $productRecommend,
                    ],
                    $request
                );
                $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_CATEGORYINFO_DELETE_COMPLETE, $event);

                //$this->addSuccess('admin.common.save_complete', 'admin');
            } catch (ForeignKeyConstraintViolationException $e) {
                $this->entityManager->rollback();

                $message = trans('admin.common.delete_error_foreign_key', ['%name%' => $TargetCategoryInfo->getId()]);
                $this->addError($message, 'admin');
            }
        }

        $ProductRecommends = $this->productRecommendRepository->findBy(['SaleType' => $SaleType],["sort_no"=> "DESC"]);

        return [
            'SaleType' => $SaleType,
            'ProductRecommends' => $ProductRecommends,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/setting/shop/recommend/{id}/delete", requirements={"id" = "\d+"}, name="admin_setting_shop_recommend_delete", methods={"DELETE"})
     * @Route("/%eccube_admin_route%/product/recommend/{id}/delete", requirements={"id" = "\d+"}, name="admin_product_recommend_delete", methods={"DELETE"})
     */
    public function delete(Request $request, $id, CacheUtil $cacheUtil)
    {
        $route = $request->attributes->get('_route');
        log_info('route', [$route]);
        $this->isTokenValid();

        $ProductRecommend = $this->productRecommendRepository->find($id);
        if (!$ProductRecommend) {
            $this->deleteMessage();

            if ($route == 'admin_product_recommend_delete') {
                return $this->redirectToRoute('admin_product_recommend');
            } else {
                return $this->redirectToRoute('admin_setting_shop_recommend');
            }
        }

        log_info('削除開始', [$id]);

        try {
            $this->productRecommendRepository->delete($ProductRecommend);

            $event = new EventArgs(
                [
                    'ProductRecommend' => $ProductRecommend,
                ], $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_CATEGORY_DELETE_COMPLETE, $event);

            $this->addSuccess('admin.common.delete_complete', 'admin');

            log_info('削除完了', [$id]);

            $cacheUtil->clearDoctrineCache();
        } catch (\Exception $e) {
            log_info('削除エラー', [$id, $e]);

            $message = trans('admin.common.delete_error_foreign_key', ['%name%' => $ProductRecommend->getName()]);
            $this->addError($message, 'admin');
        }

        if ($route == 'admin_product_recommend_delete') {
            return $this->redirectToRoute('admin_product_recommend_edit', ['id' => $ProductRecommend->getSaleType()->getId()]);
        } else {
            return $this->redirectToRoute('admin_setting_shop_recommend_edit', ['id' => $ProductRecommend->getSaleType()->getId()]);
        }
    }

    /**
     * @Route("/%eccube_admin_route%/setting/shop/recommend/sort_no/move", name="admin_setting_shop_recommend_sort_no_move", methods={"POST"})
     * @Route("/%eccube_admin_route%/product/recommend/sort_no/move", name="admin_product_recommend_sort_no_move", methods={"POST"})
     */
    public function moveSortNo(Request $request, CacheUtil $cacheUtil)
    {
        if (!$request->isXmlHttpRequest()) {
            throw new BadRequestHttpException();
        }

        if ($this->isTokenValid()) {
            $sortNos = $request->request->all();
            foreach ($sortNos as $productRecommendId => $sortNo) {
                /* @var $Category \Eccube\Entity\Category */
                $productRecommend = $this->productRecommendRepository
                    ->find($productRecommendId);
                $productRecommend->setSortNo($sortNo);
                $this->entityManager->persist($productRecommend);
            }
            $this->entityManager->flush();

            $cacheUtil->clearDoctrineCache();

            return new Response('Successful');
        }
    }
}
