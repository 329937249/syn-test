<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Setting\Shop;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\DBAL\Exception\ForeignKeyConstraintViolationException;
use Eccube\Controller\AbstractController;
use Eccube\Entity\CategoryTopMatrix;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Util\FormUtil;
use Eccube\Form\Type\Admin\CategoryTopMatrixType;
use Eccube\Repository\Master\SaleTypeRepository;
use Eccube\Repository\CategoryTopMatrixRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Class ShopCategoryController
 */
class ShopCategoryController extends AbstractController
{
    /**
     * @var SaleTypeRepository
     */
    protected $saleTypeRepository;

    /**
     * @var CategoryTopMatrixRepository
     */
    protected $categoryTopMatrixRepository;

    /**
     * ShopCategoryController constructor.
     *
     * @param SaleTypeRepository $saleTypeRepository
     * @param CategoryTopMatrixRepository $categoryTopMatrixRepository
     */
    public function __construct(SaleTypeRepository $saleTypeRepository,
        CategoryTopMatrixRepository $categoryTopMatrixRepository)
    {
        $this->saleTypeRepository = $saleTypeRepository;
        $this->categoryTopMatrixRepository = $categoryTopMatrixRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/setting/system/category", name="admin_setting_shop_category")
     * @Route("/%eccube_admin_route%/setting/system/category/{id}/edit", requirements={"id" = "\d+"}, name="admin_setting_shop_category_edit")
     * @Template("@admin/Setting/Shop/category_matrix_edit.twig")
     */
    public function index(Request $request, $id = null)
    {
        $Matrixes = [];
        $saleTypes = $this->saleTypeRepository->findAll();
        foreach($saleTypes as $saleType) {
            $categoryTopMatrix = $this->categoryTopMatrixRepository->findBy(['SaleType' => $saleType]);
            if (count($categoryTopMatrix) > 0) {
                $Matrixes[] = $categoryTopMatrix[0];
            } else {
                $CategoryTopMatrix = new CategoryTopMatrix();
                $CategoryTopMatrix->setSaleType($saleType);
                $Matrixes[] = $CategoryTopMatrix;
            }
        }

        // 新規登録用フォーム:不使用
        $builder = $this->formFactory
            ->createBuilder(CategoryTopMatrixType::class, new CategoryTopMatrix());
        $form = $builder->getForm();

        // 編集用フォーム
        $forms = [];
        foreach ($Matrixes as $Matrix) {
            $id = $Matrix->getSaleType()->getId();
            $forms[$id] = $this
                ->formFactory
                ->createNamed('matrix_'.$id, CategoryTopMatrixType::class, $Matrix);
        }

        $event = new EventArgs(
            [
                'forms' => $forms,
                'Matrixes' => $Matrixes,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_CATEGORY_EDIT_INITIALIZE, $event);

        // 登録ボタン押下
        if ($request->getMethod() === 'POST' && !is_null($id)) {
            // 編集処理
            log_info("id", [$id]);
            foreach ($forms as $editForm) {
                $editForm->handleRequest($request);
                log_info("editForm", [$editForm->isSubmitted(), $editForm->isValid()]);
                if ($editForm->isSubmitted() && $editForm->isValid()) {
                    $data = $editForm->getData();
                    log_info("data", [$data->getId(), $data->getSaleType(),$data->getCategory(),$data->getRecommendCategory()]);

                    $this->entityManager->persist($data);
                    $this->entityManager->flush();

                    $event = new EventArgs(
                        [
                            'forms' => $forms,
                            'Matrixes' => $Matrixes,
                        ],
                        $request
                    );
                    $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_CATEGORY_EDIT_COMPLETE, $event);
                            $this->addSuccess('admin.common.save_complete', 'admin');

                    return $this->redirectToRoute('admin_setting_shop_category');
                }
            }
        }

        $formViews = [];
        foreach ($forms as $key => $value) {
            $formViews[$key] = $value->createView();
        }

        return [
            'form' => $form->createView(),
            'forms' => $formViews,
            'Matrixes' => $Matrixes,
        ];
    }

}
