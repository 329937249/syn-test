<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Setting\Shop;

use Doctrine\DBAL\Exception\ForeignKeyConstraintViolationException;
use Eccube\Controller\AbstractController;
use Eccube\Entity\CategoryInfo;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\CategoryInfoRegisterType;
use Eccube\Repository\CategoryInfoRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\UnsupportedMediaTypeHttpException;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Class ShopCategoryInfoController
 */
class ShopCategoryInfoController extends AbstractController
{
    /**
     * @var CategoryInfoRepository
     */
    protected $categoryInfoRepository;

    /**
     * ShopCategoryInfoController constructor.
     *
     * @param CategoryInfoRepository $categoryInfoRepository
     */
    public function __construct(CategoryInfoRepository $categoryInfoRepository)
    {
        $this->categoryInfoRepository = $categoryInfoRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/content/shop/categoryinfo", name="admin_setting_shop_category_info")
     * @Template("@admin/Setting/Shop/categoryinfo.twig")
     */
    public function index(Request $request)
    {
        $Categories = $this->categoryInfoRepository
            ->findBy(
                [],
                ['Category' => 'ASC']
            );

        $event = new EventArgs(
            [
                'Categories' => $Categories,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_CATEGORYINFO_INDEX_COMPLETE, $event);

        return [
            'Categories' => $Categories,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/content/shop/categoryinfo/new", name="admin_setting_shop_categoryinfo_new")
     * @Route("/%eccube_admin_route%/content/shop/categoryinfo/{id}/edit", requirements={"id" = "\d+"}, name="admin_setting_shop_categoryinfo_edit")
     * @Template("@admin/Setting/Shop/categoryinfo_edit.twig")
     */
    public function edit(Request $request, CategoryInfo $CategoryInfo = null)
    {
        if (is_null($CategoryInfo)) {
            $CategoryInfo = new \Eccube\Entity\CategoryInfo();
        }

        $builder = $this->formFactory
            ->createBuilder(CategoryInfoRegisterType::class, $CategoryInfo);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'CategoryInfo' => $CategoryInfo,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_CATEGORYINFO_EDIT_INITIALIZE, $event);

        $form = $builder->getForm();

        // 既に画像保存されてる場合は取得する
        $oldCategoryImage = $CategoryInfo->getCategoryImage();

        $form->setData($CategoryInfo);
        $form->handleRequest($request);

        // 登録ボタン押下
        if ($form->isSubmitted() && $form->isValid()) {
            $CategoryInfo = $form->getData();

            // ファイルアップロード
            $file = $form['category_image']->getData();
            $fs = new Filesystem();
            if ($file && $fs->exists($this->getParameter('eccube_temp_image_dir').'/'.$file)) {
                $fs->rename(
                    $this->getParameter('eccube_temp_image_dir').'/'.$file,
                    $this->getParameter('eccube_save_image_dir').'/'.$file
                );
            }

            $this->entityManager->persist($CategoryInfo);
            $this->entityManager->flush();

            $event = new EventArgs(
                [
                    'form' => $form,
                    'CategoryInfo' => $CategoryInfo,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_CATEGORYINFO_EDIT_COMPLETE, $event);

            $this->addSuccess('admin.common.save_complete', 'admin');

            return $this->redirectToRoute('admin_setting_shop_categoryinfo_edit', ['id' => $CategoryInfo->getId()]);
        }

        return [
            'form' => $form->createView(),
            'category_id' => $CategoryInfo->getId(),
            'CategoryInfo' => $CategoryInfo,
            'oldCategoryImage' => $oldCategoryImage,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/content/shop/categoryinfo/image/add", name="admin_categoryinfo_image_add")
     */
    public function imageAdd(Request $request)
    {
        if (!$request->isXmlHttpRequest()) {
            throw new BadRequestHttpException();
        }

        $images = $request->files->get('category_register');
        $allowExtensions = ['gif', 'jpg', 'jpeg', 'png'];
        $filename = null;
        if (isset($images['category_image_file'])) {
            $image = $images['category_image_file'];

            //ファイルフォーマット検証
            $mimeType = $image->getMimeType();
            if (0 !== strpos($mimeType, 'image')) {
                throw new UnsupportedMediaTypeHttpException();
            }

            // 拡張子
            $extension = $image->getClientOriginalExtension();
            if (!in_array(strtolower($extension), $allowExtensions)) {
                throw new UnsupportedMediaTypeHttpException();
            }

            $filename = date('mdHis').uniqid('_').'.'.$extension;
            $image->move($this->getParameter('eccube_temp_image_dir'), $filename);
        }
        $event = new EventArgs(
            [
                'images' => $images,
                'filename' => $filename,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_CATEGORYINFO_IMAGE_ADD_COMPLETE, $event);
        $filename = $event->getArgument('filename');

        return $this->json(['filename' => $filename], 200);
    }

    /**
     * @Route("/%eccube_admin_route%/content/shop/categoryinfo/{id}/delete", requirements={"id" = "\d+"}, name="admin_setting_shop_categoryinfo_delete", methods={"DELETE"})
     *
     * @param Request $request
     * @param CategoryInfo $TargetCategoryInfo
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function delete(Request $request, CategoryInfo $TargetCategoryInfo)
    {
        $this->isTokenValid();

        try {
            $this->categoryInfoRepository->delete($TargetCategoryInfo);
            $this->entityManager->flush();

            $event = new EventArgs(
                [
                    'CategoryInfo' => $TargetCategoryInfo,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_CATEGORYINFO_DELETE_COMPLETE, $event);

            $this->addSuccess('admin.common.delete_complete', 'admin');
        } catch (ForeignKeyConstraintViolationException $e) {
            $this->entityManager->rollback();

            $message = trans('admin.common.delete_error_foreign_key', ['%name%' => $TargetCategoryInfo->getId()]);
            $this->addError($message, 'admin');
        }

        return $this->redirectToRoute('admin_setting_shop_category_info');
    }


}
