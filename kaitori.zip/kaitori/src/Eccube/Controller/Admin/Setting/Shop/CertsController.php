<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Setting\Shop;

use Eccube\Controller\AbstractController;
use Eccube\Entity\Master\CertsType;
use Eccube\Entity\CertsOption;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\CertsTypeType;
use Eccube\Repository\Master\CertsTypeRepository;
use Eccube\Repository\CertsOptionRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;

class CertsController extends AbstractController
{
    /**
     * @var CertsTypeRepository
     */
    protected $CertsTypeRepository;

    /**
     * @var CertsOptionRepository
     */
    protected $CertsOptionRepository;

    /**
     * CertsController constructor.
     *
     * @param CertsTypeRepository $certsTypeRepository
     * @param CertsOptionRepository $certsOptionRepository
     */
    public function __construct(CertsTypeRepository $certsTypeRepository, CertsOptionRepository $certsOptionRepository)
    {
        $this->CertsTypeRepository = $certsTypeRepository;
        $this->CertsOptionRepository = $certsOptionRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/setting/shop/certs", name="admin_setting_shop_certificate")
     * @Template("@admin/Setting/Shop/certs.twig")
     */
    public function index(Request $request, $id = null)
    {
        $CertsTypes = $this->CertsTypeRepository
            ->findBy([], ['sort_no' => 'ASC']);

        $event = new EventArgs(
            [
                'CertsTypes' => $CertsTypes,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_CERTS_INDEX_COMPLETE, $event);

        return [
            'CertsTypes' => $CertsTypes,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/setting/shop/certs/{id}/edit", requirements={"id" = "\d+"}, name="admin_setting_shop_certs_edit")
     * @Template("@admin/Setting/Shop/certs_edit.twig")
     */
    public function edit(Request $request, $id = null)
    {
        if (is_null($id)) {
            throw new NotFoundHttpException();
        } else {
            $CertsType = $this->CertsTypeRepository->find($id);
        }

        $builder = $this->formFactory
            ->createBuilder(CertsTypeType::class, $CertsType);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'CertsType' => $CertsType,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_CERTS_EDIT_INITIALIZE, $event);

        $form = $builder->getForm();

        // 確認書類をセット
        $CertsDocs = [];
        foreach ($CertsType->getCertsOptions() as $CertsOption) {
            $CertsDocs[] = $CertsOption->getCertsDoc();
        }

        $form['certs_docs']->setData($CertsDocs);

        // 登録ボタン押下
        if ($request->getMethod() === 'POST') {
            $form->handleRequest($request);

            if ($form->isValid()) {
                $CertsTypeData = $form->getData();

                // 確認書類の登録
                $CertsOptions = $this->CertsOptionRepository
                    ->findBy(['certs_type_id' => $CertsType->getId()]);
                // 消す
                foreach ($CertsOptions as $CertsOption) {
                    $CertsTypeData->removeCertsOption($CertsOption);
                    $this->entityManager->remove($CertsOption);
                }
                $this->entityManager->persist($CertsTypeData);
                $this->entityManager->flush();

                // いれる
                $CertsDocsData = $form->get('certs_docs')->getData();
                foreach ($CertsDocsData as $CertsDocData) {
                    $CertsOption = new CertsOption();
                    $CertsOption
                        ->setCertsDocId($CertsDocData->getId())
                        ->setCertsDoc($CertsDocData)
                        ->setCertsTypeId($CertsTypeData->getId())
                        ->setCertsType($CertsTypeData);
                    $CertsTypeData->addCertsOption($CertsOption);
                    $this->entityManager->persist($CertsTypeData);
                }

                $this->entityManager->persist($CertsTypeData);
                $this->entityManager->flush();
                
                $event = new EventArgs(
                    [
                        'form' => $form,
                        'CertsType' => $CertsType,
                    ],
                    $request
                );
                $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_CERTS_EDIT_COMPLETE, $event);

                $this->addSuccess('admin.common.save_complete', 'admin');

                return $this->redirectToRoute('admin_setting_shop_certs_edit', ['id' => $CertsType->getId()]);
            }
        }

        return [
            'form' => $form->createView(),
            'CertsType' => $CertsType,
            'certs_type_id' => $CertsType->getId(),
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/setting/shop/certs/sort_no/move", name="admin_shop_certs_type_sort_no_move", methods={"POST"})
     */
    public function moveSortNo(Request $request)
    {
        if (!$request->isXmlHttpRequest()) {
            throw new BadRequestHttpException();
        }

        if ($this->isTokenValid()) {
            $sortNos = $request->request->all();
            foreach ($sortNos as $id => $sortNo) {
                $CertsType = $this->CertsTypeRepository
                    ->find($id);
                $CertsType->setSortNo($sortNo);
                $this->entityManager->persist($CertsType);
            }
            $this->entityManager->flush();

            return new Response();
        }
    }
}
