<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Setting\Shop;

use Doctrine\DBAL\Exception\ForeignKeyConstraintViolationException;
use Eccube\Controller\AbstractController;
use Eccube\Entity\CategoryRank;
use Eccube\Form\Type\Admin\CategoryRankType;
use Eccube\Repository\CategoryRankRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\UnsupportedMediaTypeHttpException;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Class ShopCategoryRankController
 */
class ShopCategoryRankController extends AbstractController
{
    /**
     * @var CategoryRankRepository
     */
    protected $categoryRankRepository;

    /**
     * ShopCategoryRankController constructor.
     *
     * @param CategoryRankRepository $categoryRankRepository
     */
    public function __construct(CategoryRankRepository $categoryRankRepository)
    {
        $this->categoryRankRepository = $categoryRankRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/content/shop/categoryrank", name="admin_setting_shop_category_rank")
     * @Template("@admin/Setting/Shop/categoryrank.twig")
     */
    public function index(Request $request)
    {
        $Categories = $this->categoryRankRepository
            ->findBy(
                [],
                ['sort_no' => 'ASC']
            );

        return [
            'Categories' => $Categories,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/content/shop/categoryrank/new", name="admin_setting_shop_categoryrank_new")
     * @Route("/%eccube_admin_route%/content/shop/categoryrank/{id}/edit", requirements={"id" = "\d+"}, name="admin_setting_shop_categoryrank_edit")
     * @Template("@admin/Setting/Shop/categoryrank_edit.twig")
     */
    public function edit(Request $request, CategoryRank $CategoryRank = null)
    {
        if (is_null($CategoryRank)) {
            $CategoryRank = new \Eccube\Entity\CategoryRank();
        }

        $builder = $this->formFactory
            ->createBuilder(CategoryRankType::class, $CategoryRank);

        $form = $builder->getForm();

        // 既に画像保存されてる場合は取得する
        $form->setData($CategoryRank);
        $form->handleRequest($request);

        // 登録ボタン押下
        if ($form->isSubmitted() && $form->isValid()) {
            $CategoryRank = $form->getData();

            $this->entityManager->persist($CategoryRank);
            $this->entityManager->flush();

            $this->addSuccess('admin.common.save_complete', 'admin');

            return $this->redirectToRoute('admin_setting_shop_categoryrank_edit', ['id' => $CategoryRank->getId()]);
        }

        return [
            'form' => $form->createView(),
            'category_id' => $CategoryRank->getId(),
            'CategoryRank' => $CategoryRank,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/content/shop/categoryrank/{id}/delete", requirements={"id" = "\d+"}, name="admin_setting_shop_categoryrank_delete", methods={"DELETE"})
     *
     * @param Request $request
     * @param CategoryRank $TargetCategoryRank
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function delete(Request $request, CategoryRank $TargetCategoryRank)
    {
        $this->isTokenValid();

        try {
            $this->categoryRankRepository->delete($TargetCategoryRank);
            $this->entityManager->flush();
            $this->addSuccess('admin.common.delete_complete', 'admin');
        } catch (ForeignKeyConstraintViolationException $e) {
            $this->entityManager->rollback();

            $message = trans('admin.common.delete_error_foreign_key', ['%name%' => $TargetCategoryRank->getId()]);
            $this->addError($message, 'admin');
        }

        return $this->redirectToRoute('admin_setting_shop_category_rank');
    }


}
