<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Setting\System;

use Eccube\Controller\AbstractController;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Entity\AuthorityRole;
use Eccube\Entity\AuthorityRole2;
use Eccube\Entity\Master\Authority;
use Eccube\Entity\Master\Menu;
use Eccube\Form\Type\Admin\AuthorityRole2Type;
use Eccube\Repository\AuthorityRoleRepository;
use Eccube\Repository\AuthorityRole2Repository;
use Eccube\Repository\Master\AuthorityRepository;
use Eccube\Repository\Master\MenuRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Eccube\Util\FormUtil;

class AuthorityRoleController extends AbstractController
{
    /**
     * @var MenuRepository
     */
    protected $menuRepository;

    /**
     * @var AuthorityRepository
     */
    protected $authorityRepository;

    /**
     * @var AuthorityRoleRepository
     */
    protected $authorityRoleRepository;

    /**
     * @var AuthorityRole2Repository
     */
    protected $authorityRole2Repository;

    /**
     * AuthorityRoleController constructor.
     *
     * @param MenuRepository $menuRepository
     * @param AuthorityRepository $authorityRepository
     * @param AuthorityRoleRepository $authorityRoleRepository
     * @param AuthorityRole2Repository $authorityRole2Repository
     */
    public function __construct(MenuRepository $menuRepository,
        AuthorityRepository $authorityRepository,
        AuthorityRoleRepository $authorityRoleRepository,
        AuthorityRole2Repository $authorityRole2Repository)
    {
        $this->menuRepository = $menuRepository;
        $this->authorityRepository = $authorityRepository;
        $this->authorityRoleRepository = $authorityRoleRepository;
        $this->authorityRole2Repository = $authorityRole2Repository;
    }

    /**
     * @Route("/%eccube_admin_route%/setting/authority/authorityrole", name="admin_setting_system_authorityrole")
     * @Template("@admin/Setting/System/authorityrole.twig")
     */
    public function index(Request $request)
    {
        $authorityAll = $this->authorityRepository->findAll();
        $Authorities = [];
        foreach ($authorityAll as $Authority) {
            if (Authority::ADMIN != $Authority->getId()) {
                $Authorities[] = $Authority;
            }
        }
    
        $builder = $this->formFactory->createBuilder();
        $builder
            ->add(
                'Authorities',
                CollectionType::class,
                [
                    'entry_type' => AuthorityRole2Type::class,
                    'allow_add' => true,
                    'allow_delete' => true,
                    'prototype' => true,
                    'data' => $Authorities,
                ]
            );

        $event = new EventArgs(
            [
                'builder' => $builder,
                'Authorities' => $Authorities,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SYSTEM_AUTHORITY_ROLE_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();

        $form->handleRequest($request);

        //log_info("form",[$form->isSubmitted(),$form->isValid()]);
        if ($form->isSubmitted() && $form->isValid()) {
            $data = $form->getData();
            $viewData = FormUtil::getViewData($form);
            $Menus = [];
            foreach ($viewData['Authorities'] as $view) {
                $Menus[$view['id']] = $view['Menus'];
            }

            //　メニュークリア
            $authorityRoles = $this->authorityRole2Repository->findAll();
            foreach ($authorityRoles as $authorityRole2) {
                $this->entityManager->remove($authorityRole2);
            }

            //　メニュー追加
            foreach ($data['Authorities'] as $Authority) {
                foreach ($Menus[$Authority->getId()] as $menuId) {
                    $menu = $this->menuRepository->find($menuId);

                    $authorityRole2 = new AuthorityRole2();
                    $authorityRole2->setAuthority($Authority);
                    $authorityRole2->setMenu($menu);

                    $this->entityManager->persist($authorityRole2);
                }
            }
            $this->entityManager->flush();

            $Menus = $this->menuRepository->findAll();
            foreach ($data['Authorities'] as $Authority) {
                // AuthorityRoleクリア(拒否URL)
                $authorityRoles = $this->authorityRoleRepository->findBy(['Authority' => $Authority]);
                foreach ($authorityRoles as $authorityRole) {
                    $this->entityManager->remove($authorityRole);
                }
    
                // AuthorityRole追加(拒否URL)
                foreach ($Menus as $menu) {
                    $count = $this->authorityRole2Repository->count(['Authority' => $Authority, 'Menu' => $menu]);
                    if ($count <= 0) {
                        $authorityRole = new AuthorityRole();
                        $authorityRole->setAuthority($Authority);
                        $authorityRole->setDenyUrl($menu->getUrl());
    
                        $this->entityManager->persist($authorityRole);
                    }
                }

                if (Authority::ADMIN != $Authority->getId()) {
                    foreach (Menu::COMMON_DENY_URL as $deny_url) {
                        $authorityRole = new AuthorityRole();
                        $authorityRole->setAuthority($Authority);
                        $authorityRole->setDenyUrl($deny_url);
    
                        $this->entityManager->persist($authorityRole);
                    }
                }

            }
            $this->entityManager->flush();

            $event = new EventArgs(
                [
                    'form' => $form,
                    'Authorities' => $Authorities,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SYSTEM_AUTHORITY_ROLE_INDEX_COMPLETE, $event);

            $this->addSuccess('admin.common.save_complete', 'admin');

            return $this->redirectToRoute('admin_setting_system_authorityrole');
        }

        // メニューをセット
        $Menus = [];
        $authorityRoles = $this->authorityRole2Repository->findAll();
        foreach ($authorityRoles as $authorityRole2) {
            $Menus[$authorityRole2->getAuthority()->getId()][] = $authorityRole2->getMenu()->getId();
        }

        $viewData = FormUtil::getViewData($form);
        $forms = $form->all();
        if (!empty($forms)) {
            foreach ($form['Authorities'] as $key => $value) {
                $authority_id = $viewData['Authorities'][$key]['id'];
                if (isset($Menus[$authority_id])) {
                    //log_info("setViewData", [$viewData['Authorities'][$key]['Menus'], $Menus[$authority_id]]);
                    $viewData['Authorities'][$key]['Menus'] = $Menus[$authority_id];
                    log_info("setViewData", [$viewData['Authorities'][$key]['Menus']]);
                }
            }

            $viewData = FormUtil::submitAndGetData($form, $viewData);
            log_info("viewData", [$viewData]);
        }

        return [
            'form' => $form->createView(),
        ];
    }
}
