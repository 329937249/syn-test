<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Customer;

use Eccube\Controller\AbstractController;
use Eccube\Entity\Master\CustomerStatus;
use Eccube\Event\EccubeEvents;
use Eccube\Service\OrderPdfService;
use Eccube\Event\EventArgs;
use Eccube\Repository\OrderPdfRepository;
use Eccube\Form\Type\Admin\OrderPdfType;
use Symfony\Component\HttpFoundation\Response;
use Eccube\Form\Type\Admin\CustomerType;
use Eccube\Form\Type\Admin\CustomerDocType;
use Eccube\Repository\CustomerRepository;
use Eccube\Repository\Master\CustomerStatusRepository;
use Eccube\Util\StringUtil;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Encoder\EncoderFactoryInterface;

class CustomerEditController extends AbstractController
{
    /**
     * @var CustomerRepository
     */
    protected $customerRepository;

    /**
     * @var EncoderFactoryInterface
     */
    protected $encoderFactory;

    /**
     * @var OrderPdfService
     */
    protected $orderPdfService;
    
    /**
     * @var OrderPdfRepository
     */
    protected $orderPdfRepository;

    public function __construct(
        CustomerRepository $customerRepository,
        EncoderFactoryInterface $encoderFactory,
        OrderPdfRepository $orderPdfRepository,
        CustomerStatusRepository $customerStatusRepository
    ) {
        $this->customerRepository = $customerRepository;
        $this->encoderFactory = $encoderFactory;
        $this->orderPdfRepository = $orderPdfRepository;
        $this->customerStatusRepository = $customerStatusRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/customer/new", name="admin_customer_new")
     * @Route("/%eccube_admin_route%/customer/{id}/edit", requirements={"id" = "\d+"}, name="admin_customer_edit")
     * @Template("@admin/Customer/edit.twig")
     */
    public function index(Request $request, $id = null)
    {
        // $this->entityManager->getFilters()->enable('incomplete_order_status_hidden');
        $this->entityManager->getFilters()->enable('order_status_processing_hidden');
        // 編集
        if ($id) {
            $Customer = $this->customerRepository
                ->find($id);

            if (is_null($Customer)) {
                throw new NotFoundHttpException();
            }

            $oldStatusId = $Customer->getStatus()->getId();
            
            // 編集用にデフォルトパスワードをセット
            $previous_password = $Customer->getPassword();
            $Customer->setPassword($this->eccubeConfig['eccube_default_password']);
        // 新規登録
        } else {
            $Customer = $this->customerRepository->newCustomer();

            $oldStatusId = null;
        }
            
        // 会員登録フォーム
        $builder = $this->formFactory->createBuilder(CustomerType::class, $Customer);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'Customer' => $Customer,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_CUSTOMER_EDIT_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();
   
        $form->handleRequest($request);
       
        if ($form->isSubmitted() && $form->isValid()) {
            log_info('会員登録開始', [$Customer->getId()]);

            $encoder = $this->encoderFactory->getEncoder($Customer);

            if ($Customer->getPassword() === $this->eccubeConfig['eccube_default_password']) {
                $Customer->setPassword($previous_password);
            } else {
                if ($Customer->getSalt() === null) {
                    $Customer->setSalt($encoder->createSalt());
                    $Customer->setSecretKey($this->customerRepository->getUniqueSecretKey());
                }
                $Customer->setPassword($encoder->encodePassword($Customer->getPassword(), $Customer->getSalt()));
            }

            // 退会ステータスに更新の場合、ダミーのアドレスに更新
            $newStatusId = $Customer->getStatus()->getId();
            if ($oldStatusId != $newStatusId && $newStatusId == CustomerStatus::WITHDRAWING) {
                $Customer->setEmail(StringUtil::random(60).'@dummy.dummy');
            }
          
            $this->entityManager->persist($Customer);
            $this->entityManager->flush();

            log_info('会員登録完了', [$Customer->getId()]);

            $event = new EventArgs(
                [
                    'form' => $form,
                    'Customer' => $Customer,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_CUSTOMER_EDIT_INDEX_COMPLETE, $event);

            $this->addSuccess('admin.common.save_complete', 'admin');

            return $this->redirectToRoute('admin_customer_edit', [
                'id' => $Customer->getId(),
            ]);
        }

        return [
            'form' => $form->createView(),
            'Customer' => $Customer,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/customer/{id}/pic/", requirements={"id" = "\d+"},name="admin_customer_show_pic")
     * @Template("@admin/Customer/customer_certdoc.twig")
     *
     * @param Request $request
     * @return string
     */
    public function showPic(Request $request, $id)
    {
        $Customer = $this->customerRepository->find($id);
        if (is_null($Customer)) {
            throw new NotFoundHttpException();
        }
        $form = $this->createForm(CustomerDocType::class, $Customer);
        $form->handleRequest($request);
        if ($form->isSubmitted()) {
            if($Customer->getPersonalDocFile()){
                $this->entityManager->persist($Customer->getPersonalDocFile());
                $this->entityManager->flush($Customer->getPersonalDocFile());   
            }
            if($Customer->getCorporationDocFile()){
                $this->entityManager->persist($Customer->getCorporationDocFile());
                $this->entityManager->flush($Customer->getCorporationDocFile());   
            }
        }
        return [
            'Customer' => $Customer,
            'form' => $form->createView(),
        ];
    }

}
