<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Master;

use Eccube\Controller\AbstractController;
use Eccube\Entity\Place;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\PlaceType;
use Eccube\Repository\PlaceRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： PlaceController.php
 *概　　要     ： 置場マスタ
 *作　　成     ： 2021/7/5 CNC
 */
class PlaceController extends AbstractController
{
    /**
     * @var PlaceRepository
     */
    protected $placeRepository;

    public function __construct(PlaceRepository $placeRepository)
    {
        $this->placeRepository = $placeRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/master/place", name="admin_master_placeCode")
     * @Template("@admin/Master/place_master.twig")
     *
     * @param Request $request
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function index(Request $request)
    {
        $Place = new Place();
        $Places  = $this->placeRepository->getList();

        /**
         * 新規登録用フォーム
         **/
        $builder = $this->formFactory
            ->createBuilder(PlaceType::class, $Place);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'Place' => $Place,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_PLACE_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();

        /**
         * 編集用フォーム
         */
        $forms = [];
        foreach ($Places as $EditTag) {
            $id = $EditTag->getId();
            $forms[$id] = $this
                ->formFactory
                ->createNamed('place_'.$id, PlaceType::class, $EditTag);
        }

        if ('POST' === $request->getMethod()) {
            /*
             * 登録処理
             */
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()) {
                $existPlace = $this->placeRepository->findByPlace($form->getData()->getPlace());
                if(count($existPlace) > 0){
                    $this->addError('同様な置場は設定できません', 'admin');
                    return $this->redirectToRoute('admin_master_placeCode');
                }

                $this->placeRepository->save($form->getData());

                $this->dispatchComplete($request, $form, $form->getData());

                $this->addSuccess('admin.common.save_complete', 'admin');

                return $this->redirectToRoute('admin_master_placeCode');
            }
            /*
             * 編集処理
             */
            foreach ($forms as $editForm) {
                $editForm->handleRequest($request);
                if ($editForm->isSubmitted() && $editForm->isValid()) {
                    $existPlace = $this->placeRepository->findByPlace($editForm->getData()->getPlace());
                    if(count($existPlace) > 0){
                        if ($existPlace[0]->getId() != $editForm->getData()->getId()) {
                            $this->addError('同様な置場は設定できません', 'admin');
                            return $this->redirectToRoute('admin_master_placeCode');
                        }
                    }
                    $this->placeRepository->save($editForm->getData());

                    $this->dispatchComplete($request, $editForm, $editForm->getData());

                    $this->addSuccess('admin.common.save_complete', 'admin');

                    return $this->redirectToRoute('admin_master_placeCode');
                }
            }
        }

        $formViews = [];
        foreach ($forms as $key => $value) {
            $formViews[$key] = $value->createView();
        }

        return [
            'form' => $form->createView(),
            'Place' => $Place,
            'Places' => $Places,
            'forms' => $formViews,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/master/place/{id}/delete", requirements={"id" = "\d+"}, name="admin_master_place_delete", methods={"DELETE"})
     */
    public function delete(Request $request, Place $Place)
    {
        $this->isTokenValid();

        log_info('置場マスタ削除開始', [$Place->getId()]);

        try {
            $this->placeRepository->delete($Place);

            $event = new EventArgs(
                [
                    'Place' => $Place,
                ], $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_PLACE_DELETE_COMPLETE, $event);

            $this->addSuccess('admin.common.delete_complete', 'admin');

            log_info('置場マスタ削除完了', [$Place->getId()]);
        } catch (\Exception $e) {
            log_info('置場マスタ削除エラー', [$Place->getId(), $e]);

            $message = trans('admin.common.delete_error.foreign_key', ['%name%' => $Place->getplace()]);
            $this->addError($message, 'admin');
        }

        return $this->redirectToRoute('admin_master_placeCode');
    }

    /**
     * @Route("/%eccube_admin_route%/master/place/sort_no/move", name="admin_master_place_sort_no_move", methods={"POST"})
     */
    public function moveSortNo(Request $request)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            $sortNos = $request->request->all();
            foreach ($sortNos as $PlaceId => $sortNo) {
                $Place = $this->placeRepository
                    ->find($PlaceId);
                $Place->setSortNo($sortNo);
                $this->entityManager->persist($Place);
            }
            $this->entityManager->flush();
        }

        return new Response();
    }

    protected function dispatchComplete(Request $request, FormInterface $form, Place $Place)
    {
        $event = new EventArgs(
            [
                'form' => $form,
                'Place' => $Place,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_PLACE_INDEX_COMPLETE, $event);
    }

}
