<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Master;

use Doctrine\ORM\QueryBuilder;
use Eccube\Controller\AbstractController;
use Eccube\Event\EccubeEvents;
use Eccube\Common\Constant;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\SearchPayeeMstType;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\PayeeMstRepository;
use Eccube\Util\FormUtil;
use Knp\Component\Pager\Paginator;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Translation\TranslatorInterface;

/**
 *プログラム名 ： PayeeMstController.php
 *概　　要     ： 仕入先マスタ
 *作　　成     ： 2021/7/5 CNC
 */
class PayeeMstController extends AbstractController
{
    /**
     * @var PayeeMstRepository
     */
    protected $payeeMstRepository;

    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;

    public function __construct(
        PayeeMstRepository $payeeMstRepository,
        PageMaxRepository $pageMaxRepository
    ) {
        $this->payeeMstRepository = $payeeMstRepository;
        $this->pageMaxRepository = $pageMaxRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/master/payee", name="admin_master_payee")
     * @Route("/%eccube_admin_route%/master/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_master_payee_page")
     * @Template("@admin/Master/payee_master.twig")
     *
     * @param Request $request
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function index(Request $request, Paginator $paginator, $page_no = null)
    {
        $session = $this->session;
        $builder = $this->formFactory
            ->createBuilder(SearchPayeeMstType::class, null);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_MASTER_PAYEEMST_INDEX_INITIALIZE, $event);

        $pageMaxis = $this->pageMaxRepository->findAll();
        $pageCount = $session->get('eccube.admin.payeeMst.search.page_count', $this->eccubeConfig['eccube_default_page_count']);
        $pageCountParam = $request->get('page_count');
        if ($pageCountParam && is_numeric($pageCountParam)) {
            foreach ($pageMaxis as $pageMax) {
                if ($pageCountParam == $pageMax->getName()) {
                    $pageCount = $pageMax->getName();
                    $session->set('eccube.admin.payeeMst.search.page_count', $pageCount);
                    break;
                }
            }
        }

        $searchForm = $builder->getForm();

        if ('POST' === $request->getMethod()) {
            $searchForm->handleRequest($request);
            if ($searchForm->isValid()) {
                $searchData = $searchForm->getData();
                $page_no = 1;

                $session->set('eccube.admin.payeeMst.search', FormUtil::getViewData($searchForm));
                $session->set('eccube.admin.payeeMst.search.page_no', $page_no);
            } else {
                return [
                    'searchForm' => $searchForm->createView(),
//                    'PayeeMsts' => [],
//                    'totalItemCount' => 0,
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $pageCount,
                    'has_errors' => true,
                ];
            }
        } else {

//            if ($request->get('resume')) {
//                $viewData = $session->get('eccube.admin.payeeMst.search', []);
//            } else {
//                $viewData = FormUtil::getViewData($searchForm);
//                $session->set('eccube.admin.payeeMst.search', $viewData);
//            }

            if (null !== $page_no || $request->get('resume')) {
                if ($page_no) {
                    $session->set('eccube.admin.payeeMst.search.page_no', (int) $page_no);
                } else {
                    $page_no = $session->get('eccube.admin.payeeMst.search.page_no', 1);
                }
                $viewData = $session->get('eccube.admin.payeeMst.search', []);
            } else {
                $page_no = 1;
                $viewData = FormUtil::getViewData($searchForm);
                $session->set('eccube.admin.payeeMst.search', $viewData);
                $session->set('eccube.admin.payeeMst.search.page_no', $page_no);
            }
            $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
        }

        /** @var QueryBuilder $qb */
        $qb = $this->payeeMstRepository->getQueryBuilderBySearchData($searchData);
        $PayeeMsts = $qb->getQuery()->getResult();
//        $totalItemCount = count($PayeeMsts);

        $sort_orders = $this->sortOrder($PayeeMsts, $searchData);

        $event = new EventArgs(
            [
                'form' => $searchForm,
//                'PayeeMsts' => $PayeeMsts,
                'qb' => $qb,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_MASTER_PAYEEMST_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $pageCount
        );

        return [
            'searchForm' => $searchForm->createView(),
//            'PayeeMsts' => $PayeeMsts,
//            'totalItemCount' => $totalItemCount,
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $pageCount,
            'has_errors' => false,
        ];
    }

    private function sortOrder($orders, $searchData){
        if($searchData['sort_by']){
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case '仕入先コード':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a["payeeCode"]> $b["payeeCode"] ? -1 : 1;
                        }
                        return $a["payeeCode"] < $b["payeeCode"] ? -1 : 1;
                    });
                    break;
            }
        }
        return $orders;
    }

//    /**
//     * @Route("/%eccube_admin_route%/master/payee/sort_no/move", name="admin_master_payee_sort_no_move", methods={"POST"})
//     */
//    public function moveSortNo(Request $request)
//    {
//        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
//            $sortNos = $request->request->all();
//            foreach ($sortNos as $payeeId => $sortNo) {
//                $payee = $this->payeeMstRepository
//                    ->find($payeeId);
//                $payee->setSortNo($sortNo);
//                $this->entityManager->persist($payee);
//            }
//            $this->entityManager->flush();
//        }
//
//        return new Response();
//    }

    /**
     * @Route("/%eccube_admin_route%/master/payee/{id}/delete", requirements={"id" = "\d+"}, name="admin_payeeMst_delete", methods={"DELETE"})
     */
    public function delete(Request $request, $id, TranslatorInterface $translator)
    {
        $this->isTokenValid();

        log_info('仕入先マスタ削除開始', [$id]);

        $payee = $this->payeeMstRepository
            ->find($id);

        if (!$payee) {
            $this->deleteMessage();

            return $this->redirect($this->generateUrl('admin_master_payee').'?resume='.Constant::ENABLED);
        }
        try {
            $this->payeeMstRepository->delete($payee);

            $event = new EventArgs(
                [
                    'Payee' => $payee,
                ], $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_MASTER_PAYEEMST_DELETE_COMPLETE, $event);

            $this->addSuccess('admin.common.delete_complete', 'admin');

            log_info('仕入先マスタ削除完了', [$payee->getId()]);
        } catch (\Exception $e) {
            log_info('仕入先マスタ削除エラー', [$payee->getId(), $e]);

            $message = trans('admin.common.delete_error.foreign_key', ['%name%' => $payee->getPayeeName()]);
            $this->addError($message, 'admin');
        }

        return $this->redirect($this->generateUrl('admin_master_payee').'?resume='.Constant::ENABLED);
    }
}
