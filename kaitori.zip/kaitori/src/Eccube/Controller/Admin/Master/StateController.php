<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Master;

use Eccube\Controller\AbstractController;
use Eccube\Entity\State;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\StateType;
use Eccube\Repository\StateRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： StateController.php
 *概　　要     ： 状態マスタ
 *作　　成     ： 2021/7/5 CNC
 */
class StateController extends AbstractController
{
    /**
     * @var StateRepository
     */
    protected $stateRepository;

    public function __construct(StateRepository $stateRepository)
    {
        $this->stateRepository = $stateRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/master/state", name="admin_master_state")
     * @Template("@admin/Master/state_master.twig")
     *
     * @param Request $request
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function index(Request $request)
    {
        $State = new State();
        $States = $this->stateRepository->getList();
        $is_state_exist= null;
        /**
         * 新規登録用フォーム
         **/
        $builder = $this->formFactory
            ->createBuilder(StateType::class, $State);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'State' => $State,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_STATE_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();

        /**
         * 編集用フォーム
         */
        $forms = [];
        foreach ($States as $EditTag) {
            $id = $EditTag->getId();
            $forms[$id] = $this
                ->formFactory
                ->createNamed('state_' .$id, StateType::class, $EditTag);
        }

        if ('POST' === $request->getMethod()) {
            /*
             * 登録処理
             */
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()) {
                $searchData = $form->getData();
                $isExistState = $this->stateRepository->isStateExists($searchData);
                if($isExistState!=null)
                {
                    $this->addError('同様なカテゴリ、状態は設定できません', 'admin');
                    return $this->redirectToRoute('admin_master_state');
                }
                $this->stateRepository->save($form->getData());

                $this->dispatchComplete($request, $form, $form->getData());

                $this->addSuccess('admin.common.save_complete', 'admin');

                return $this->redirectToRoute('admin_master_state');
            }
            /*
             * 編集処理
             */
            foreach ($forms as $editForm) {
                $editForm->handleRequest($request);
                if ($editForm->isSubmitted() && $editForm->isValid()) {
                    $searchData = $editForm->getData();
                    $isExistState = $this->stateRepository->isStateExists($searchData);
                    if($isExistState!=null)
                    {
                        if ($isExistState != $editForm->getData()->getId()){
                            $this->addError('同様なカテゴリ、状態は設定できません', 'admin');
                            return $this->redirectToRoute('admin_master_state');
                        }
                    }

                    $this->stateRepository->save($editForm->getData());

                    $this->dispatchComplete($request, $editForm, $editForm->getData());

                    $this->addSuccess('admin.common.save_complete', 'admin');

                    return $this->redirectToRoute('admin_master_state');
                }
            }
        }

        $formViews = [];
        foreach ($forms as $key => $value) {
            $formViews[$key] = $value->createView();
        }

        return [
            'form' => $form->createView(),
            'State' => $State,
            'States' => $States,
            'forms' => $formViews,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/master/state/{id}/delete", requirements={"id" = "\d+"}, name="admin_master_state_delete", methods={"DELETE"})
     */
    public function delete(Request $request, State $State)
    {
        $this->isTokenValid();

        log_info('状態マスタ削除開始', [$State->getId()]);

        try {
            $this->stateRepository->delete($State);

            $event = new EventArgs(
                [
                    'State' => $State,
                ], $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_STATE_DELETE_COMPLETE, $event);

            $this->addSuccess('admin.common.delete_complete', 'admin');

            log_info('状態マスタ削除完了', [$State->getId()]);
        } catch (\Exception $e) {
            log_info('状態マスタ削除エラー', [$State->getId(), $e]);

            $message = trans('admin.common.delete_error.foreign_key', ['%name%' => $State->getCategory()]);
            $this->addError($message, 'admin');
        }

        return $this->redirectToRoute('admin_master_state');
    }

    /**
     * @Route("/%eccube_admin_route%/master/state/sort_no/move", name="admin_master_state_sort_no_move", methods={"POST"})
     */
    public function moveSortNo(Request $request)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            $sortNos = $request->request->all();
            foreach ($sortNos as $stateId => $sortNo) {
                $State = $this->stateRepository
                    ->find($stateId);
                $State->setSortNo($sortNo);
                $this->entityManager->persist($State);
            }
            $this->entityManager->flush();
        }

        return new Response();
    }

    protected function dispatchComplete(Request $request, FormInterface $form, State $State)
    {
        $event = new EventArgs(
            [
                'form' => $form,
                'State' => $State,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_STATE_INDEX_COMPLETE, $event);
    }
}
