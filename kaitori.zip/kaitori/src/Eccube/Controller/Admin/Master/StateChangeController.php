<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Master;

use Eccube\Controller\AbstractController;
use Eccube\Entity\Category;
use Eccube\Entity\StateChange;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\StateChangeType;
use Eccube\Form\Type\Master\CategoryType as MasterCategoryType;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\StateChangeRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： StateChangeController.php
 *概　　要     ： 状態変換マスタ
 *作　　成     ： 2021/7/6 CNC
 */
class StateChangeController extends AbstractController
{
    /**
     * @var StateChangeRepository
     */
    protected $stateChangeRepository;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    public function __construct(
        CategoryRepository $categoryRepository,
        StateChangeRepository $stateChangeRepository)
    {
        $this->categoryRepository = $categoryRepository;
        $this->stateChangeRepository = $stateChangeRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/master/state_change", name="admin_master_stateChange")
     * @Template("@admin/Master/statechange_master.twig")
     *
     * @param Request $request Request
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function index(Request $request)
    {
        $StateChange = new StateChange();
        $StateChanges = $this->stateChangeRepository->getList();
        $is_state_exist = null;
        $array_entity_category = $this->categoryRepository->getList(null, false);

        /**
         * 新規登録用フォーム
         **/
        $builder = $this->formFactory
            ->createBuilder(StateChangeType::class)
            ->add('category', MasterCategoryType::class, [
                'choice_label' => 'NameWithLevel',
                'data' => current($array_entity_category),
                'label' => 'admin.product.category',
                'required' => false,
                'multiple' => false,
                'expanded' => false,
                'choices' => $array_entity_category,
                'choice_value' => function (Category $Category = null) {
                    return $Category && ($Category->getHierarchy() == 1) ? $Category->getId() : null;
                },
            ]);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'StateChange' => $StateChange,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_STATE_CHANGE_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();

        /**
         * 編集用フォーム
         */
        $forms = [];
        foreach ($StateChanges as $EditTag) {
            $id = $EditTag->getId();

            $forms[$id] = $this
                ->formFactory
                ->createNamedBuilder('statechange_'.$id, StateChangeType::class)
                ->add('category', MasterCategoryType::class, [
                    'choice_label' => 'NameWithLevel',
                    'label' => 'admin.product.category',
                    'required' => false,
                    'multiple' => false,
                    'expanded' => false,
                    'choices' => $array_entity_category,
                    'choice_value' => function (Category $Category = null) {
                        return $Category && ($Category->getHierarchy() == 1) ? $Category->getId() : null;
                    },
                ])
                ->getForm();

            $forms[$id]->setData($EditTag);
        }

        if ('POST' === $request->getMethod()) {
            /*
             * 登録処理
             */
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()) {
                $conversionBeforeState = $form->get('conversionBeforeState')->getData();
                $category = $form->get('category')->getData();
                $id = $category->getId();
                $conversionAfterState = $form->get('conversionAfterState_'.$id)->getData();

                //$isExistState = $this->stateChangeRepository->findByConversionBeforeState($conversionBeforeState);
                $isExistState = $this->stateChangeRepository->findBy(
                    [
                        'conversionBeforeState' => $conversionBeforeState,
                        'category' => $category,
                    ]
                );
                if (count($isExistState) > 0) {
                    $this->addError('同様な変換前状態は設定できません', 'admin');
                    return $this->redirectToRoute('admin_master_stateChange');
                }

                $StateChange->setConversionBeforeState($conversionBeforeState);
                $StateChange->setCategory($category);
                $StateChange->setConversionAfterState($conversionAfterState);

                $this->stateChangeRepository->save($StateChange);

                $this->dispatchComplete($request, $form, $StateChange);

                $this->addSuccess('admin.common.save_complete', 'admin');

                return $this->redirectToRoute('admin_master_stateChange');
            }
            /*
             * 編集処理
             */
            foreach ($forms as $editForm) {
                $editForm->handleRequest($request);
                if ($editForm->isSubmitted() && $editForm->isValid()) {
                    $id = $editForm->getData()->getId();
                    $conversionBeforeState = $editForm->get('conversionBeforeState')->getData();
                    $category = $editForm->get('category')->getData();
                    $categoryId = $category->getId();
                    $conversionAfterState = $editForm->get('conversionAfterState_'.$categoryId)->getData();

                    //$isExistState = $this->stateChangeRepository->findByConversionBeforeState($conversionBeforeState);
                    $isExistState = $this->stateChangeRepository->findBy(
                        [
                            'conversionBeforeState' => $conversionBeforeState,
                            'category' => $category,
                        ]
                    );
                    if (count($isExistState) > 0) {
                        if ($isExistState[0]->getId() != $editForm->getData()->getId()) {
                            $this->addError('同様な変換前状態は設定できません', 'admin');
                            return $this->redirectToRoute('admin_master_stateChange');
                        }
                    }
                    $editForm->getData()->setId($id);
                    $editForm->getData()->setConversionBeforeState($conversionBeforeState);
                    $editForm->getData()->setCategory($category);
                    $editForm->getData()->setConversionAfterState($conversionAfterState);

                    $this->stateChangeRepository->save($editForm->getData());

                    $this->dispatchComplete($request, $editForm, $editForm->getData());

                    $this->addSuccess('admin.common.save_complete', 'admin');

                    return $this->redirectToRoute('admin_master_stateChange');

                }
            }
        }

        $formViews = [];
        foreach ($forms as $key => $value) {
            $formViews[$key] = $value->createView();
        }

        return [
            'form' => $form->createView(),
            'StateChange' => $StateChange,
            'StateChanges' => $StateChanges,
            'forms' => $formViews,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/master/stateChange/{id}/delete", requirements={"id" = "\d+"}, name="admin_master_stateChange_delete", methods={"DELETE"})
     */
    public function delete(Request $request, StateChange $StateChange)
    {
        $this->isTokenValid();

        log_info('状態変換マスタ削除開始', [$StateChange->getId()]);

        try {
            $this->stateChangeRepository->delete($StateChange);

            $event = new EventArgs(
                [
                    'StateChange' => $StateChange,
                ], $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_STATE_CHANGE_DELETE_COMPLETE, $event);

            $this->addSuccess('admin.common.delete_complete', 'admin');

            log_info('状態変換マスタ削除完了', [$StateChange->getId()]);
        } catch (\Exception $e) {
            log_info('状態変換マスタ削除エラー', [$StateChange->getId(), $e]);

            $message = trans('admin.common.delete_error.foreign_key', ['%name%' => $StateChange->getconversionBeforeState()]);
            $this->addError($message, 'admin');
        }

        return $this->redirectToRoute('admin_master_stateChange');
    }

    /**
     * @Route("/%eccube_admin_route%/master/stateChange/sort_no/move", name="admin_master_stateChange_sort_no_move", methods={"POST"})
     */
    public function moveSortNo(Request $request)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            $sortNos = $request->request->all();
            foreach ($sortNos as $StateChangeId => $sortNo) {
                $StateChange = $this->stateChangeRepository
                    ->find($StateChangeId);
                $StateChange->setSortNo($sortNo);
                $this->entityManager->persist($StateChange);
            }
            $this->entityManager->flush();
        }

        return new Response();
    }

    protected function dispatchComplete(Request $request, FormInterface $form, StateChange $StateChange)
    {
        $event = new EventArgs(
            [
                'form' => $form,
                'StateChange' => $StateChange,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_STATE_CHANGE_INDEX_COMPLETE, $event);
    }

}