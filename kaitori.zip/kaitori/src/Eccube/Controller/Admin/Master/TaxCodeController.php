<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Master;

use Eccube\Controller\AbstractController;
use Eccube\Entity\TaxCode;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\TaxCodeType;
use Eccube\Repository\TaxCodeRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： TaxCodeController.php
 *概　　要     ： 税区分マスタ
 *作　　成     ： 2021/7/1 CNC
 */
class TaxCodeController extends AbstractController
{
    /**
     * @var TaxCodeRepository
     */
    protected $taxCodeRepository;

    public function __construct(TaxCodeRepository $taxCodeRepository)
    {
        $this->taxCodeRepository = $taxCodeRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/master/taxCode", name="admin_master_taxCode")
     * @Template("@admin/Master/tax_master.twig")
     *
     * @param Request $request
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function index(Request $request)
    {
        $TaxCode = new TaxCode();
        $TaxCodes  = $this->taxCodeRepository->getList();

        /**
         * 新規登録用フォーム
         **/
        $builder = $this->formFactory
            ->createBuilder(TaxCodeType::class, $TaxCode);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'TaxCode' => $TaxCode,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_TAX_CODE_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();

        /**
         * 編集用フォーム
         */
        $forms = [];
        foreach ($TaxCodes as $EditTag) {
            $id = $EditTag->getId();
            $forms[$id] = $this
                ->formFactory
                ->createNamed('taxCode_'.$id, TaxCodeType::class, $EditTag);
        }

        if ('POST' === $request->getMethod()) {
            /*
             * 登録処理
             */
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()) {
                $existTax = $this->taxCodeRepository->findByTaxName($form->getData()->getTaxName());
                if(count($existTax) > 0){
                    $this->addError('同様な税区分は設定できません', 'admin');
                    return $this->redirectToRoute('admin_master_taxCode');
                }

                $this->taxCodeRepository->save($form->getData());

                $this->dispatchComplete($request, $form, $form->getData());

                $this->addSuccess('admin.common.save_complete', 'admin');

                return $this->redirectToRoute('admin_master_taxCode');
            }
            /*
             * 編集処理
             */
            foreach ($forms as $editForm) {
                $editForm->handleRequest($request);
                if ($editForm->isSubmitted() && $editForm->isValid()) {
                    $existTax = $this->taxCodeRepository->findByTaxName($editForm->getData()->getTaxName());
                    if(count($existTax) > 0){
                        if ($existTax[0]->getId() != $editForm->getData()->getId()) {
                            $this->addError('同様な税区分は設定できません', 'admin');
                            return $this->redirectToRoute('admin_master_taxCode');
                        }
                    }
                    $this->taxCodeRepository->save($editForm->getData());

                    $this->dispatchComplete($request, $editForm, $editForm->getData());

                    $this->addSuccess('admin.common.save_complete', 'admin');

                    return $this->redirectToRoute('admin_master_taxCode');
                }
            }
        }

        $formViews = [];
        foreach ($forms as $key => $value) {
            $formViews[$key] = $value->createView();
        }

        return [
            'form' => $form->createView(),
            'TaxCode' => $TaxCode,
            'TaxCodes' => $TaxCodes,
            'forms' => $formViews,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/master/taxCode/{id}/delete", requirements={"id" = "\d+"}, name="admin_master_taxCode_delete", methods={"DELETE"})
     */
    public function delete(Request $request, TaxCode $TaxCode)
    {
        $this->isTokenValid();

        log_info('税区分マスタ削除開始', [$TaxCode->getId()]);

        try {
            $this->taxCodeRepository->delete($TaxCode);

            $event = new EventArgs(
                [
                    'TaxCode' => $TaxCode,
                ], $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_TAX_CODE_DELETE_COMPLETE, $event);

            $this->addSuccess('admin.common.delete_complete', 'admin');

            log_info('税区分マスタ削除完了', [$TaxCode->getId()]);
        } catch (\Exception $e) {
            log_info('税区分マスタ削除エラー', [$TaxCode->getId(), $e]);

            $message = trans('admin.common.delete_error.foreign_key', ['%name%' => $TaxCode->getTaxName()]);
            $this->addError($message, 'admin');
        }

        return $this->redirectToRoute('admin_master_taxCode');
    }

    /**
     * @Route("/%eccube_admin_route%/master/taxCode/sort_no/move", name="admin_master_taxCode_sort_no_move", methods={"POST"})
     */
    public function moveSortNo(Request $request)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            $sortNos = $request->request->all();
            foreach ($sortNos as $taxCodeId => $sortNo) {
                $TaxCode = $this->taxCodeRepository
                    ->find($taxCodeId);
                $TaxCode->setSortNo($sortNo);
                $this->entityManager->persist($TaxCode);
            }
            $this->entityManager->flush();
        }

        return new Response();
    }

    protected function dispatchComplete(Request $request, FormInterface $form, TaxCode $TaxCode)
    {
        $event = new EventArgs(
            [
                'form' => $form,
                'TaxCode' => $TaxCode,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_TAX_CODE_INDEX_COMPLETE, $event);
    }
}
