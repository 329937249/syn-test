<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Master;

use Eccube\Controller\AbstractController;
use Eccube\Entity\TaxExporter;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\TaxExporterType;
use Eccube\Repository\TaxExporterRepository;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： TaxExporterController.php
 *概　　要     ： 税関輸出者マスタ
 *作　　成     ： 2021/7/5 CNC
 */
class TaxExporterController extends AbstractController
{
    /**
     * @var TaxExporterRepository
     */
    protected $taxExporterRepository;

    public function __construct(TaxExporterRepository $taxExporterRepository)
    {
        $this->taxExporterRepository = $taxExporterRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/master/tax_exporter", name="admin_master_taxExporter")
     * @Template("@admin/Master/tax_exporter_master.twig")
     *   *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */

    public function index(Request $request)
    {
        $TaxExporter = new TaxExporter();
        $TaxExporters  = $this->taxExporterRepository->getList();

        /**
         * 新規登録用フォーム
         **/
        $builder = $this->formFactory
            ->createBuilder(TaxExporterType::class, $TaxExporter);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'TaxExporter' => $TaxExporter,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_TAX_EXPORTER_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();

        /**
         * 編集用フォーム
         */
        $forms = [];
        foreach ($TaxExporters as $EditTag) {
            $id = $EditTag->getId();
            $forms[$id] = $this
                ->formFactory
                ->createNamed('taxExporter_'.$id, TaxExporterType::class, $EditTag);
        }

        if ('POST' === $request->getMethod()) {
            /*
             * 登録処理
             */
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()) {
                $existTaxExporter = $this->taxExporterRepository->findByName($form->getData()->getName());
                if(count($existTaxExporter) > 0){
                    $this->addError('同様な税関輸出者は設定できません', 'admin');
                    return $this->redirectToRoute('admin_master_taxExporter');
                }

                $this->taxExporterRepository->save($form->getData());

                $this->dispatchComplete($request, $form, $form->getData());

                $this->addSuccess('admin.common.save_complete', 'admin');

                return $this->redirectToRoute('admin_master_taxExporter');
            }
            /*
             * 編集処理
             */
            foreach ($forms as $editForm) {
                $editForm->handleRequest($request);
                if ($editForm->isSubmitted() && $editForm->isValid()) {
                    $existTaxExporter = $this->taxExporterRepository->findByName($editForm->getData()->getName());
                    if(count($existTaxExporter) > 0){
                        if ($existTaxExporter[0]->getId() != $editForm->getData()->getId()) {
                            $this->addError('同様な税関輸出者は設定できません', 'admin');
                            return $this->redirectToRoute('admin_master_taxExporter');
                        }
                    }

                    $this->taxExporterRepository->save($editForm->getData());

                    $this->dispatchComplete($request, $editForm, $editForm->getData());

                    $this->addSuccess('admin.common.save_complete', 'admin');

                    return $this->redirectToRoute('admin_master_taxExporter');
                }
            }
        }

        $formViews = [];
        foreach ($forms as $key => $value) {
            $formViews[$key] = $value->createView();
        }

        return [
            'form' => $form->createView(),
            'TaxExporter' => $TaxExporter,
            'TaxExporters' => $TaxExporters,
            'forms' => $formViews,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/master/tax_exporter/{id}/delete", requirements={"id" = "\d+"}, name="admin_master_tax_exporter_delete", methods={"DELETE"})
     */
    public function delete(Request $request, TaxExporter $TaxExporter)
    {
        $this->isTokenValid();

        log_info('税関輸出者マスタ削除開始', [$TaxExporter->getId()]);

        try {
            $this->taxExporterRepository->delete($TaxExporter);

            $event = new EventArgs(
                [
                    'TaxExporter' => $TaxExporter,
                ], $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_TAX_EXPORTER_DELETE_COMPLETE, $event);

            $this->addSuccess('admin.common.delete_complete', 'admin');

            log_info('税関輸出者マスタ削除完了', [$TaxExporter->getId()]);
        } catch (\Exception $e) {
            log_info('税関輸出者マスタ削除エラー', [$TaxExporter->getId(), $e]);

            $message = trans('admin.common.delete_error.foreign_key', ['%name%' => $TaxExporter->getName()]);
            $this->addError($message, 'admin');
        }

        return $this->redirectToRoute('admin_master_taxExporter');
    }

    /**
     * @Route("/%eccube_admin_route%/master/tax_exporter/sort_no/move", name="admin_master_tax_exporter_sort_no_move", methods={"POST"})
     */
    public function moveSortNo(Request $request)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            $sortNos = $request->request->all();
            foreach ($sortNos as $taxExporterId => $sortNo) {
                $TaxExporter = $this->taxExporterRepository
                    ->find($taxExporterId);
                $TaxExporter->setSortNo($sortNo);
                $this->entityManager->persist($TaxExporter);
            }
            $this->entityManager->flush();
        }

        return new Response();
    }

    protected function dispatchComplete(Request $request, FormInterface $form, TaxExporter $TaxExporter)
    {
        $event = new EventArgs(
            [
                'form' => $form,
                'TaxExporter' => $TaxExporter,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_TAX_EXPORTER_INDEX_COMPLETE, $event);
    }

}
