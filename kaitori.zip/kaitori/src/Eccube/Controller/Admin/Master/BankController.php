<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Master;

use Eccube\Controller\AbstractController;
use Eccube\Entity\Bank;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\BankType;
use Eccube\Repository\BankRepository;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： BankController.php
 *概　　要     ： 銀行マスタ
 *作　　成     ： 2021/7/2 CNC
 */
class BankController extends AbstractController
{
    /**
     * @var BankRepository
     */
    protected $bankRepository;

    public function __construct(BankRepository $bankRepository)
    {
        $this->bankRepository = $bankRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/master/bank", name="admin_master_bank")
     * @Template("@admin/Master/bank_master.twig")
     *   *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */

    public function index(Request $request)
    {
        $Bank = new Bank();
        $Banks  = $this->bankRepository->getList();

        /**
         * 新規登録用フォーム
         **/
        $builder = $this->formFactory
            ->createBuilder(BankType::class, $Bank);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'Bank' => $Bank,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_BANK_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();

        /**
         * 編集用フォーム
         */
        $forms = [];
        foreach ($Banks as $EditTag) {
            $id = $EditTag->getId();
            $forms[$id] = $this
                ->formFactory
                ->createNamed('bank_'.$id, BankType::class, $EditTag);
        }

        if ('POST' === $request->getMethod()) {
            /*
             * 登録処理
             */
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()) {
                $existBank = $this->bankRepository->findByTransferorAccount($form->getData()->getTransferorAccount());
                if(count($existBank) > 0){
                    $this->addError('同様な振込口座は設定できません', 'admin');
                    return $this->redirectToRoute('admin_master_bank');
                }

                $this->bankRepository->save($form->getData());

                $this->dispatchComplete($request, $form, $form->getData());

                $this->addSuccess('admin.common.save_complete', 'admin');

                return $this->redirectToRoute('admin_master_bank');
            }
            /*
             * 編集処理
             */
            foreach ($forms as $editForm) {
                $editForm->handleRequest($request);
                if ($editForm->isSubmitted() && $editForm->isValid()) {
                    $existBank = $this->bankRepository->findByTransferorAccount($editForm->getData()->getTransferorAccount());
                    if(count($existBank) > 0){
                        if ($existBank[0]->getId() != $editForm->getData()->getId()) {
                            $this->addError('同様な振込口座は設定できません', 'admin');
                            return $this->redirectToRoute('admin_master_bank');
                        }
                    }

                    $this->bankRepository->save($editForm->getData());

                    $this->dispatchComplete($request, $editForm, $editForm->getData());

                    $this->addSuccess('admin.common.save_complete', 'admin');

                    return $this->redirectToRoute('admin_master_bank');
                }
            }
        }

        $formViews = [];
        foreach ($forms as $key => $value) {
            $formViews[$key] = $value->createView();
        }

        return [
            'form' => $form->createView(),
            'Bank' => $Bank,
            'Banks' => $Banks,
            'forms' => $formViews,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/master/bank/{id}/delete", requirements={"id" = "\d+"}, name="admin_master_bank_delete", methods={"DELETE"})
     */
    public function delete(Request $request, Bank $Bank)
    {
        $this->isTokenValid();

        log_info('銀行マスタ削除開始', [$Bank->getId()]);

        try {
            $this->bankRepository->delete($Bank);

            $event = new EventArgs(
                [
                    'Bank' => $Bank,
                ], $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_BANK_DELETE_COMPLETE, $event);

            $this->addSuccess('admin.common.delete_complete', 'admin');

            log_info('銀行マスタ削除完了', [$Bank->getId()]);
        } catch (\Exception $e) {
            log_info('銀行マスタ削除エラー', [$Bank->getId(), $e]);

            $message = trans('admin.common.delete_error.foreign_key', ['%name%' => $Bank->getTransferorAccount()]);
            $this->addError($message, 'admin');
        }

        return $this->redirectToRoute('admin_master_bank');
    }

    /**
     * @Route("/%eccube_admin_route%/master/bank/sort_no/move", name="admin_master_bank_sort_no_move", methods={"POST"})
     */
    public function moveSortNo(Request $request)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            $sortNos = $request->request->all();
            foreach ($sortNos as $bankId => $sortNo) {
                $Bank = $this->bankRepository
                    ->find($bankId);
                $Bank->setSortNo($sortNo);
                $this->entityManager->persist($Bank);
            }
            $this->entityManager->flush();
        }

        return new Response();
    }

    protected function dispatchComplete(Request $request, FormInterface $form, Bank $Bank)
    {
        $event = new EventArgs(
            [
                'form' => $form,
                'Bank' => $Bank,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_BANK_INDEX_COMPLETE, $event);
    }
}
