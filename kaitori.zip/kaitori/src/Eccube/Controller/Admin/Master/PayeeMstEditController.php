<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Master;

use Eccube\Controller\AbstractController;
use Eccube\Entity\PayeeMst;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\PayeeMstType;
use Eccube\Repository\PayeeMstRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： PayeeMstEditController.php
 *概　　要     ： 仕入先マスタ
 *作　　成     ： 2021/7/7 CNC
 */
class PayeeMstEditController extends AbstractController
{
    /**
     * @var PayeeMstRepository
     */
    protected $payeeMstRepository;

    public function __construct(
        PayeeMstRepository $payeeMstRepository
    ) {
        $this->payeeMstRepository = $payeeMstRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/master/payee/new", name="admin_payeeMst_new")
     * @Route("/%eccube_admin_route%/master/payee/{id}/edit", requirements={"id" = "\d+"}, name="admin_payeeMst_edit")
     * @Template("@admin/Master/payee_master_edit.twig")
     *
     * @param Request $request
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function index(Request $request, $id = null)
    {
        // 編集
        if ($id) {
            $Payee = $this->payeeMstRepository
                ->find($id);

            if (is_null($Payee)) {
                throw new NotFoundHttpException();
            }
            // 新規登録
        } else {
            $Payee = $this->payeeMstRepository->newPayeeMst();
        }
        // 仕入先マスタ登録フォーム
        $builder = $this->formFactory->createBuilder(PayeeMstType::class, $Payee);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'Payee' => $Payee,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_MASTER_PAYEEMST_EDIT_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            $this->payeeMstRepository->save($form->getData());

            $this->dispatchComplete($request, $form, $form->getData());

            $this->addSuccess('admin.common.save_complete', 'admin');

            return $this->redirectToRoute('admin_payeeMst_edit', [
                'id' => $Payee->getId(),
            ]);
        }

        return [
            'form' => $form->createView(),
            'Payee' => $Payee,
        ];
    }

    protected function dispatchComplete(Request $request, FormInterface $form, PayeeMst $Payee)
    {
        $event = new EventArgs(
            [
                'form' => $form,
                'Payee' => $Payee,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_MASTER_PAYEEMST_EDIT_INDEX_COMPLETE, $event);
    }
}
