<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Payment;

use Eccube\Controller\AbstractController;
use Eccube\Entity\Master\CustomerStatus;
use Eccube\Entity\Master\PayingStatus;
use Eccube\Entity\Master\OrderStatus;
use Eccube\Entity\Master\KaitoriType;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\CustomerType;
use Eccube\Form\Type\Admin\PayingType;
use Eccube\Repository\CustomerRepository;
use Eccube\Repository\PayingRepository;
use Eccube\Repository\OrderRepository;
use Eccube\Util\StringUtil;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Encoder\EncoderFactoryInterface;

class PaymentDetailController extends AbstractController
{
    /**
     * @var CustomerRepository
     */
    protected $customerRepository;
    
    /**
     * @var PayingRepository
     */
    protected $payingRepository;
    
    /**
     * @var OrderRepository
     */
    protected $orderRepository;
    
    /**
     * @var EncoderFactoryInterface
     */
    protected $encoderFactory;

    public function __construct(
        CustomerRepository $customerRepository,
        PayingRepository $payingRepository,
        OrderRepository $orderRepository,
        EncoderFactoryInterface $encoderFactory
    ) {
        $this->customerRepository = $customerRepository;
        $this->payingRepository = $payingRepository;
        $this->orderRepository = $orderRepository;
        $this->encoderFactory = $encoderFactory;
    }
    
    /**
     * @Route("/%eccube_admin_route%/payment", name="admin_payment_detail")
     * @Route("/%eccube_admin_route%/payment/{id}/detail/{status}/status", requirements={"id" = "\d+","status" = "\d+"}, name="admin_paying_detail")
     * @Template("@admin/Payment/detail.twig")
     */
    public function index(Request $request, $id = null, $status = null)
    {

        $OriginPaying = null;
        $payingStatus = $this->entityManager->find(PayingStatus::class, PayingStatus::NEW);

        // 送金済み
        if($status == PayingStatus :: FINISH){
            $payingStatus = $this->entityManager->find(PayingStatus::class, PayingStatus::FINISH);
         //   $this->entityManager->getFilters()->enable('incomplete_paying_status_hidden'); 
        }

        // 編集
        if ($id) {
            $Paying = $this->payingRepository
                ->find($id);

            if (is_null($Paying)) {
                throw new NotFoundHttpException();
            }

            $Paying->setPayingStatus($payingStatus);

            // 銀行情報を更新する 顧客情報と同じ
            if($Paying->getCustomer()){
                $Customer = $this->customerRepository->find($Paying->getCustomer()->getId());
                // 銀行 支店 預金 振込口座番号 振込口座名義
                $Paying->setAccountBank($Customer->getAccountBank())->setAccountBranch($Customer->getAccountBranch())->setAccountType($Customer->getAccountType())->setAccountNo($Customer->getAccountNo())->setAccountName($Customer->getAccountName());
            }

            $this->entityManager->persist($Paying);
            $this->entityManager->flush();

            $oldStatusId = $Paying->getPayingStatus()->getId();
            $OriginPaying = clone $Paying;

            $Paying->setPayingStatus($OriginPaying->getPayingStatus());

            // 振込未送金総金額、書留未送金総金額に値を設定する
            //$this->orderRepository->getNotPayPrice($Paying);

        } else {
            $Paying = $this->payingRepository->newPaying();

            $oldStatusId = null;
        }
      
        $builder = $this->formFactory
            ->createBuilder(PayingType::class, $Paying);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'Paying' => $Paying,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYING_EDIT_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();
        
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // 担当者を更新する
            $Paying->setMember($this->getUser());
            $this->entityManager->persist($Paying);
            $this->entityManager->flush();

            $event = new EventArgs(
                [
                    'form' => $form,
                    'Paying' => $Paying,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYING_EDIT_INDEX_COMPLETE, $event);

            $this->addSuccess('admin.common.save_complete', 'admin');

            return $this->redirectToRoute('admin_paying_detail', [
                'id' => $Paying->getId(),
                'status' => $payingStatus->getId(),
            ]);
        }

       // 未送金
       $Paying->setPayingStatus($OriginPaying->getPayingStatus());
       
       if($Paying->getPayingStatus()->getId() == PayingStatus :: NEW){
           if($Paying->getOrders()){
               $Orders = $Paying->getOrders()->filter(function ($value, $key) {
                   if($value->getOrderStatus()){
                      return ($value->getOrderStatus()->getId() != OrderStatus :: PROCESSING and $value->getOrderStatus()->getId() != OrderStatus :: CANCEL and $value->getOrderStatus()->getId() != OrderStatus :: PAID and $value->getPaymentMethod() != '現金払い') ;
                   }
               });
            }
            $Paying->setOrders($Orders);
        }

        // 送金済み
        if($Paying->getPayingStatus()->getId() == PayingStatus :: FINISH){
           if($Paying->getOrders()){
               $Orders = $Paying->getOrders()->filter(function ($value, $key) {
                  return ($value->getOrderStatus()->getId() != OrderStatus :: PROCESSING and $value->getOrderStatus()->getId() != OrderStatus :: CANCEL and $value->getPaymentMethod() != '現金払い'
                          and null != $value->getPaymentDate() and $value->getPaymentDate()->format('Y-m-d') == $value->getPaying()->getPayingDate()->format('Y-m-d')) ;
               });
            }
            $Paying->setOrders($Orders);
        }
        
        return [
            'form' => $form->createView(),
            'Paying' => $Paying,
            'amazon' => KaitoriType :: KAITORI_TYPE_AMAZON,
            'shop' => KaitoriType :: KAITORI_TYPE_SHOP,
            'post' => KaitoriType :: KAITORI_TYPE_NORMAL,
            'paying_new' =>PayingStatus :: NEW,
        ];
    }
    
    private function setFirstPaymentDate($Paying)
    {
            //$this->entityManager->getFilters()->disable('incomplete_new_paying_status_hidden'); 
            
            // 初回振込
            $firstFurikomiOrder = $this->orderRepository->getFirstFurikomiOrder($Paying->getCustomer());
            if(null!= $firstFurikomiOrder){
            
            $Paying->setFirstFurikomiDate($firstFurikomiOrder->getPaymentDate());
            }
            // 初回書留
            $firstKakitomeOrder = $this->orderRepository->getFirstKakitomeOrder($Paying->getCustomer());
            if(null!= $firstKakitomeOrder){
           
            $Paying->setFirstKakitomeDate($firstKakitomeOrder->getPaymentDate());
            }  
            
            $this->entityManager->persist($Paying);
            $this->entityManager->flush(); 
    }

    /**
     * @Route("/%eccube_admin_route%/payment/{id}/detail/{status}/update_data", requirements={"id" = "\d+","status" = "\d+"}, name="admin_paying_edit_update")
     *  @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function refreshData(Request $request, $id = null, $status = null)
    {
        $result = [];
        $OriginPaying = null;
        $payingStatus = $this->entityManager->find(PayingStatus::class, PayingStatus::NEW);

        // 送金済み
        if($status == PayingStatus :: FINISH){
            $payingStatus = $this->entityManager->find(PayingStatus::class, PayingStatus::FINISH);
        }
        // 編集
        if ($id) {
            $Paying = $this->payingRepository
                ->find($id);

            if (is_null($Paying)) {
                throw new NotFoundHttpException();
            }

            $Paying->setPayingStatus($payingStatus);

            // 銀行情報を更新する 顧客情報と同じ
            if($Paying->getCustomer()){
                $Customer = $this->customerRepository->find($Paying->getCustomer()->getId());
                // 銀行 支店 預金 振込口座番号 振込口座名義
                $Paying->setAccountBank($Customer->getAccountBank())->setAccountBranch($Customer->getAccountBranch())->setAccountType($Customer->getAccountType())->setAccountNo($Customer->getAccountNo())->setAccountName($Customer->getAccountName());
            }

            $this->entityManager->persist($Paying);
            $this->entityManager->flush();

            $oldStatusId = $Paying->getPayingStatus()->getId();
            $OriginPaying = clone $Paying;

            $Paying->setPayingStatus($OriginPaying->getPayingStatus());

            // 振込未送金総金額、書留未送金総金額に値を設定する
            //$this->orderRepository->getNotPayPrice($Paying);
       
        } else {
            $Paying = $this->payingRepository->newPaying();
            $oldStatusId = null;
        }
      
        $builder = $this->formFactory
            ->createBuilder(PayingType::class, $Paying);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'Paying' => $Paying,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYING_EDIT_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();
        
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // 担当者を更新する
            $Paying->setMember($this->getUser());
            $this->entityManager->persist($Paying);
            $this->entityManager->flush();

            $event = new EventArgs(
                [
                    'form' => $form,
                    'Paying' => $Paying,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYING_EDIT_INDEX_COMPLETE, $event);

            $this->addSuccess('admin.common.save_complete', 'admin');

            return $this->redirectToRoute('admin_paying_edit_update', [
                'id' => $Paying->getId(),
                'status' => $payingStatus->getId(),
            ]);
        }
       // 未送金
       $Paying->setPayingStatus($OriginPaying->getPayingStatus());
       
       if($Paying->getPayingStatus()->getId() == PayingStatus :: NEW){
           if($Paying->getOrders()){
               $Orders = $Paying->getOrders()->filter(function ($value, $key) {
                   if($value->getOrderStatus()){
                      return ($value->getOrderStatus()->getId() != OrderStatus :: PROCESSING and $value->getOrderStatus()->getId() != OrderStatus :: CANCEL and $value->getOrderStatus()->getId() != OrderStatus :: PAID and $value->getPaymentMethod() != '現金払い') ;
                   }
               });
            }
            $Paying->setOrders($Orders);
        }
        // 送金済み
         if($Paying->getPayingStatus()->getId() == PayingStatus :: FINISH){
           if($Paying->getOrders()){
               $Orders = $Paying->getOrders()->filter(function ($value, $key) {
                  return ($value->getOrderStatus()->getId() != OrderStatus :: PROCESSING and $value->getOrderStatus()->getId() != OrderStatus :: CANCEL and $value->getPaymentMethod() != '現金払い') ;
               });
            }
            $Paying->setOrders($Orders);
        }
        return $this->json(array_merge(['status' => 'OK'], $result));
    }

}
