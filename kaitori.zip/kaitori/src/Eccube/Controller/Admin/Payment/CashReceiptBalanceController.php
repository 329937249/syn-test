<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Payment;

use Doctrine\ORM\QueryBuilder;
use Eccube\Controller\AbstractController;
use Eccube\Entity\Master\CsvType;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\SalesDepositBalanceDetailType;
use Eccube\Form\Type\Admin\SalesDepositBalanceType;
use Eccube\Form\Type\Admin\SearchMemberType;
use Eccube\Form\Type\Admin\SalesVoucherSearchCustomerType;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\MemberRepository;
use Eccube\Repository\SalesDepositBalanceHistoryRepository;
use Eccube\Repository\SalesDepositBalanceRepository;
use Eccube\Repository\SalesVoucherDetailRepository;
use Eccube\Service\CsvExportService;
use Eccube\Util\FormUtil;
use Knp\Component\Pager\Paginator;
use Eccube\Util\StringUtil;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： CashReceiptBalanceController.php
 *概　　要     ： 売上入金残高
 *作　　成     ： 2021/8/26 CNC
 */
class CashReceiptBalanceController extends AbstractController
{
    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;
    /**
     * @var SalesDepositBalanceRepository
     */
    protected $salesDepositBalanceRepository;

    /**
     * @var SalesDepositBalanceHistoryRepository
     */
    protected $salesDepositBalanceHistoryRepository;

    /**
     * @var MemberRepository
     */
    protected $memberRepository;

    /**
     * @var CsvExportService
     */
    protected $csvExportService;

    /**
     * @var SalesVoucherDetailRepository
     */
    protected $salesVoucherDetailRepository;

    public function __construct(
        CsvExportService $csvExportService,
        PageMaxRepository $pageMaxRepository,
        SalesDepositBalanceRepository $salesDepositBalanceRepository,
        SalesDepositBalanceHistoryRepository $salesDepositBalanceHistoryRepository,
        MemberRepository $memberRepository,
        SalesVoucherDetailRepository $salesVoucherDetailRepository
    ) {
        $this->csvExportService = $csvExportService;
        $this->pageMaxRepository = $pageMaxRepository;
        $this->salesDepositBalanceRepository = $salesDepositBalanceRepository;
        $this->salesDepositBalanceHistoryRepository = $salesDepositBalanceHistoryRepository;
        $this->memberRepository = $memberRepository;
        $this->salesVoucherDetailRepository = $salesVoucherDetailRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/payment/cash_receipt_balance", name="admin_payment_cash_receipt")
     * @Route("/%eccube_admin_route%/payment/cash_receipt_balance/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_payment_cash_receipt_page")
     * @Template("@admin/Payment/cash_receipt_balance.twig")
     *
     * @param Request $request
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function index(Request $request, $page_no = null, Paginator $paginator)
    {
        $session = $this->session;
        $builder = $this->formFactory
            ->createBuilder(SalesDepositBalanceType::class, null);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYMENT_SALES_DEPOSIT_BALANCE_INDEX_INITIALIZE, $event);

        $pageMaxis = $this->pageMaxRepository->findAll();
        $pageCount = $session->get('eccube.admin.payment.deposit.search.page_count', $this->eccubeConfig['eccube_default_page_count']);
        $pageCountParam = $request->get('page_count');
        if ($pageCountParam && is_numeric($pageCountParam)) {
            foreach ($pageMaxis as $pageMax) {
                if ($pageCountParam == $pageMax->getName()) {
                    $pageCount = $pageMax->getName();
                    $session->set('eccube.admin.payment.deposit.search.page_count', $pageCount);
                    break;
                }
            }
        }
        $form = $builder->getForm();

        // 得意先検索フォーム
        $builder_search_customer = $this->formFactory->createBuilder(SalesVoucherSearchCustomerType::class);

        $event = new EventArgs(
            [
                'builder' => $builder_search_customer,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SALES_VOUCHER_INDEX_SEARCH_CUSTOMER_INITIALIZE, $event);

        $search_sales_modal_form = $builder_search_customer->getForm();

        // 担当者検索フォーム
        $builder = $this->formFactory
            ->createBuilder(SearchMemberType::class);
        $searchMemberModalForm = $builder->getForm();

        $page_no_bk = $page_no;
        if ('POST' === $request->getMethod()) {
            $form->handleRequest($request);
            if ($form->isValid()) {
                $searchData = $form->getData();
                $page_no = 1;

                $session->set('eccube.admin.payment.deposit.search', FormUtil::getViewData($form));
                $session->set('eccube.admin.payment.deposit.search.page_no', $page_no);
            } else {
                return [
                    'form' => $form->createView(),
                    'searchSalesModalForm' => $search_sales_modal_form->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $pageCount,
                    'salesMoneyTotalAmount' => 0,
                    // 2022/01/13 CNC ADD START
                    'grossProfitTotalAmount' => 0,
                    // 2022/01/13 CNC ADD END
                    'depositAmount' => 0,
                    'depositNotAmount' => 0,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                if ($page_no) {
                    $session->set('eccube.admin.payment.deposit.search.page_no', (int) $page_no);
                } else {
                    $page_no = $session->get('eccube.admin.payment.deposit.search.page_no', 1);
                }
                $viewData = $session->get('eccube.admin.payment.deposit.search', []);
            } else {
                $page_no = 1;
                $viewData = FormUtil::getViewData($form);
                $viewData["sales_date_end"] =  date('Y-m-d', strtotime('now'));
                $viewData["sales_date_start"] =  date('Y-m-d', strtotime('now'));
//                $viewData["personnel_memo"]=$this->getUser()['name'];
//                $viewData["personnelMemoId"]=$this->getUser()['id'];
                $viewData["deposit_amount_finished"] =  false;
                $viewData["deposit_amount_remain"] =  true;
                $viewData["deposit_amount_unfinished"] =  true;
                $session->set('eccube.admin.payment.deposit.search', $viewData);
                $session->set('eccube.admin.payment.deposit.search.page_no', $page_no);
            }
            $searchData = FormUtil::submitAndGetData($form, $viewData);
        }

        $qb = '';
        $all_orders = [];
        if ('POST' === $request->getMethod() || null !== $page_no_bk){
            /** @var QueryBuilder $qb */
            $qb = $this->salesDepositBalanceRepository->getQueryBuilderBySearchData($searchData);
            $all_orders = $qb->getQuery()->getResult();
        }

        // 2022/01/13 CNC ADD START
        // 粗利益合計計算
        $i = 0;
        // 粗利益合計
        $grossProfitTotalAmount = 0;

        foreach ($all_orders as $salesDepositBalance) {
            $exportAddress = $salesDepositBalance['exportId'];
            $taxRate = $salesDepositBalance['taxRate'];

            $Details = $this->salesVoucherDetailRepository->findBy(['SalesVoucherHeader' => $salesDepositBalance['salesVoucherHeaderId']]);

            //粗利益
            $grossProfit = 0;
            //利益率
            $rate = 0;

            foreach ($Details as $salesVoucherDetail) {
                if ($exportAddress !== null) {
                    //税金区分
                    $crude = $salesVoucherDetail['sales_price'] - ($salesVoucherDetail['averagePrice'] / (1 + $taxRate / 100));
                    $grossProfit = $grossProfit + round($crude * $salesVoucherDetail['quantity']);
                } else {
                    $crude = $salesVoucherDetail['sales_price'] - $salesVoucherDetail['averagePrice'];
                    $grossProfit = $grossProfit + round($crude * $salesVoucherDetail['quantity']);
                }
            }
            if (isset($salesDepositBalance[0]['SalesVoucherHeader']['salesMoneyTotalAmount']) && $salesDepositBalance[0]['SalesVoucherHeader']['salesMoneyTotalAmount'] != 0) {
                $rate = ($grossProfit / ($salesDepositBalance[0]['SalesVoucherHeader']['salesMoneyTotalAmount'])) * 100;
                $salesDepositBalance['rate'] = round($rate, 1);
            }else{
                $salesDepositBalance['rate'] = 0;
            }
            $salesDepositBalance['grossProfit'] = $grossProfit;
            $all_orders[$i] = $salesDepositBalance;
            $i++;

            $grossProfitTotalAmount = $grossProfitTotalAmount + $grossProfit;
        }
        // 2022/01/13 CNC ADD END

        $sort_orders = $this->sortOrder($all_orders, $searchData);

        $salesMoneyTotalAmount = 0;
        $depositAmount = 0;
        $depositNotAmount = 0;
        foreach ($all_orders as $sales){
            $salesMoneyTotalAmount = $salesMoneyTotalAmount + $sales[0]->getSalesVoucherHeader()->getSalesMoneyTotalAmount();
            $depositAmount = $depositAmount + $sales[0]->getDepositedAmount();
        }
        $depositNotAmount = $salesMoneyTotalAmount - $depositAmount;

        // 総利益率
        $rateSum = 0;
        if ($salesMoneyTotalAmount != 0) {
            $rateSum = round(($grossProfitTotalAmount / $salesMoneyTotalAmount) * 100, 1);
        }

        $event = new EventArgs(
            [
                'form' => $form,
                'qb' => $qb,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYMENT_SALES_DEPOSIT_BALANCE_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $pageCount
        );

        $forms = [];
        foreach ($sort_orders as $EditTag) {
            $id = $EditTag[0]->getId();
            $forms[$id] = $this
                ->formFactory
                ->createNamed('salesDepositBalance_'.$id, SalesDepositBalanceDetailType::class, $EditTag);
        }

        $formViews = [];
        foreach ($forms as $key => $value) {
            $formViews[$key] = $value->createView();
        }
        $totalItemCount = $pagination->getTotalItemCount();
        return [
            'form' => $form->createView(),
            'searchSalesModalForm' => $search_sales_modal_form->createView(),
            'searchMemberModalForm' => $searchMemberModalForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $pageCount,
            'totalItemCount' => $totalItemCount,
            'salesMoneyTotalAmount' => $salesMoneyTotalAmount,
            // 2022/01/13 CNC ADD START
            'grossProfitTotalAmount' => $grossProfitTotalAmount,
            'rateSum' => $rateSum,
            // 2022/01/13 CNC ADD END
            'depositAmount' => $depositAmount,
            'depositNotAmount' => $depositNotAmount,
            'has_errors' => false,
            'forms' => $formViews,
        ];
    }

    private function sortOrder($orders, $searchData){
        if($searchData['sort_by']){
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case '伝票番号':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a[0]->getSalesVoucherNo() > $b[0]->getSalesVoucherNo() ? -1 : 1;
                        }
                        return $a[0]->getSalesVoucherNo() < $b[0]->getSalesVoucherNo() ? -1 : 1;
                    });
                    break;
                case '得意先名':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a[0]->getSalesVoucherHeader()->getCustomer()->getCustomerName() > $b[0]->getSalesVoucherHeader()->getCustomer()->getCustomerName() ? -1 : 1;
                        }
                        return $a[0]->getSalesVoucherHeader()->getCustomer()->getCustomerName() < $b[0]->getSalesVoucherHeader()->getCustomer()->getCustomerName() ? -1 : 1;
                    });
                    break;
                case '売上日':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a[0]->getSalesVoucherHeader()->getSalesDate()> $b[0]->getSalesVoucherHeader()->getSalesDate() ? -1 : 1;
                        }
                        return $a[0]->getSalesVoucherHeader()->getSalesDate() < $b[0]->getSalesVoucherHeader()->getSalesDate() ? -1 : 1;
                    });
                    break;
            }
        }
        return $orders;
    }

    /**
     * Update to payAmount number.
     *
     * @Route("/%eccube_admin_route%/payment/cash_receipt_balance/{id}/update_depositedAmount", requirements={"id" = "\d+"}, name="admin_payment_cash_receipt_save", methods={"PUT"})
     *
     * @param Request $request
     *
     * @return Response
     */
    public function save(Request $request, $id)
    {
        $salesDepositBalance = $this->salesDepositBalanceRepository->find($id);

        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
        }

        try {
            $salesDepositBalanceHistoryOld = $this->salesDepositBalanceHistoryRepository->findOneBy(['salesVoucherNo' => $salesDepositBalance->getSalesVoucherNo()], ['revisionNo' => 'DESC']);

            if (StringUtil::isNotBlank($request->get('depositAmount_number'))) {
                $depositAmount_number = str_replace(",", "", $request->get('depositAmount_number'));
                $depositedAmount_number = $salesDepositBalance->getDepositedAmount();
                $depositedAmount = 0 + $depositedAmount_number + $depositAmount_number;
                $undepositAmount = $request->get('salesMoneyTotalAmount') - $depositedAmount;
            } else {
                $depositAmount_number = $salesDepositBalanceHistoryOld->getUndepositAmount();
                $undepositAmount = 0;
                $depositedAmount = $request->get('salesMoneyTotalAmount');
            }

            $salesDepositBalance->setDepositedAmount($depositedAmount);
            $salesDepositBalance->setDepositDate(new \DateTime());
            $salesDepositBalance->setDepositUserName($this->getUser()['name']);
            $salesDepositBalance->setUpdateUserName($this->getUser()['name']);

            // dtb_sales_deposit_balance_history
            $salesDepositBalanceHistory = new \Eccube\Entity\SalesDepositBalanceHistory;
            $salesDepositBalanceHistory->setSalesVoucherHeaderHistory($salesDepositBalanceHistoryOld->getSalesVoucherHeaderHistory());
            $salesDepositBalanceHistory->setSalesVoucherNo($salesDepositBalance->getSalesVoucherNo());
            $salesDepositBalanceHistory->setTotalAmount($request->get('salesMoneyTotalAmount'));
            $salesDepositBalanceHistory->setUndepositAmount($undepositAmount);
            $salesDepositBalanceHistory->setDepositedAmount($depositedAmount);
            $salesDepositBalanceHistory->setDepositAmount($depositAmount_number);
            $salesDepositBalanceHistory->setDepositDate(new \DateTime());
            $salesDepositBalanceHistory->setDepositUserName($this->getUser()['name']);
            $salesDepositBalanceHistory->setRevisionNo($salesDepositBalanceHistoryOld->getRevisionNo() + 1);
            $salesDepositBalanceHistory->setCreateUserName($this->getUser()['name']);
            $salesDepositBalanceHistory->setUpdateUserName($this->getUser()['name']);
            $this->entityManager->persist($salesDepositBalance);
            $this->entityManager->persist($salesDepositBalanceHistory);
            $this->entityManager->flush();
            $depositAmountSearch = $request->get('depositAmountSearch') + $depositAmount_number;
            $depositNotAmountSearch = $request->get('salesMoneyTotalAmountSearch') - $depositAmountSearch;
            $message = ['status' => 'OK',
                'undepositAmount' => $undepositAmount,
                'depositAmount' => $depositedAmount,
                'depositDate' => date('Y-m-d', strtotime('now')),
                'depositUserName' => $this->getUser()['name'],
                'totalItemCountSearch' => $request->get('totalItemCountSearch'),
                'salesMoneyTotalAmountSearch' => $request->get('salesMoneyTotalAmountSearch'),
                'depositAmountSearch' => $depositAmountSearch,
                'depositNotAmountSearch' => $depositNotAmountSearch];
            return $this->json($message);
        } catch (\Exception $e) {
            log_error('予期しないエラー', [$e->getMessage()]);

            return $this->json(['status' => 'NG'], 500);
        }
    }

    /**
     * CSVの出力.
     * @Route("/%eccube_admin_route%/cash_receipt_balance/export", name="admin_cash_receipt_balance_export")
     *
     * @param Request $request Request
     * @return StreamedResponse
     */
    public function export(Request $request)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        // sql loggerを無効にする.
        $em = $this->entityManager;
        $em->getConfiguration()->setSQLLogger(null);

        $response = new StreamedResponse();
        $response->setCallback(function () use ($request) {
            // CSV種別を元に初期化.
            $this->csvExportService->initCsvType(CsvType::CSV_TYPE_PAYMENT_BALANCE);

            // ヘッダ行の出力.
            $this->csvExportService->exportHeader();

            $qb = $this->csvExportService
                ->getPaymentListQueryBuilder($request);

            // データ行の出力.
            $this->csvExportService->setExportQueryBuilder($qb);

            $this->csvExportService->exportDataCSV(function ($entity, CsvExportService $csvService) use ($request) {
                $Csvs = $csvService->getCsvs();

                // 2022/01/13 CNC ADD START
                // 粗利益計算
                $exportAddress = $entity['exportId'];
                $taxRate = $entity['taxRate'];

                $Details = $this->salesVoucherDetailRepository->findBy(['SalesVoucherHeader' => $entity['salesVoucherHeaderId']]);

                //粗利益
                $grossProfit = 0;

                if (!is_null($Details)) {
                    foreach ($Details as $salesVoucherDetail) {
                        if ($exportAddress !== null) {
                            //税金区分
                            $crude = $salesVoucherDetail['sales_price'] - ($salesVoucherDetail['averagePrice'] / (1 + $taxRate / 100));
                            $grossProfit = $grossProfit + round($crude * $salesVoucherDetail['quantity']);
                        } else {
                            $crude = $salesVoucherDetail['sales_price'] - $salesVoucherDetail['averagePrice'];
                            $grossProfit = $grossProfit + round($crude * $salesVoucherDetail['quantity']);
                        }
                    }
                }

                $entity['grossProfit'] = $grossProfit;
                // 2022/01/13 CNC ADD END

                $CashReceiptBalanceCSV = new \Eccube\Entity\CashReceiptBalanceCSV();
                $amounta = 0;
                $amounta = $amounta + $entity[0]['SalesVoucherHeader']['salesMoneyTotalAmount'] - $entity[0]['depositedAmount'];
                $CashReceiptBalanceCSV->setSalesVoucherNo($entity[0]['salesVoucherNo']);
                $CashReceiptBalanceCSV->setSalesDate($entity[0]['SalesVoucherHeader']['salesDate']);
                $CashReceiptBalanceCSV->setCustomerName($entity[0]['SalesVoucherHeader']['Customer']['customerName']);
                $CashReceiptBalanceCSV->setSalesMoneyTotalAmount($entity[0]['SalesVoucherHeader']['salesMoneyTotalAmount']);
                // 2022/01/13 CNC ADD START
                $CashReceiptBalanceCSV->setGrossProfitTotalAmount($entity['grossProfit']);
                // 2022/01/13 CNC ADD END
                $CashReceiptBalanceCSV->setPersonnelName($entity[0]['SalesVoucherHeader']['Personnel']['name']);
                $CashReceiptBalanceCSV->setDepositAmount(is_null($entity[0]['depositedAmount']) ? 0 : $entity[0]['depositedAmount']);
                $CashReceiptBalanceCSV->setDepositNotAmount($amounta);
                $CashReceiptBalanceCSV->setReturnsPrice($entity[0]['SalesVoucherHeader']['returns_price'] === null ? 0 : $entity[0]['SalesVoucherHeader']['returns_price']);
                $CashReceiptBalanceCSV->setDepositDate($entity[0]['depositDate']);
                $CashReceiptBalanceCSV->setDepositUserName($entity[0]['depositUserName']);
                $CashReceiptBalanceCSV->setPersonnelMemo($entity[0]['SalesVoucherHeader']['personnel_memo']);

                $ExportCsvRow = new \Eccube\Entity\ExportCsvRow();

                // CSV出力項目と合致するデータを取得.
                foreach ($Csvs as $Csv) {
                    $ExportCsvRow->setData($csvService->getData($Csv, $CashReceiptBalanceCSV));
                    $event = new EventArgs(
                        [
                            'csvService' => $csvService,
                            'Csv' => $Csv,
                            'SalesDepositBalance' => $entity,
                            'ExportCsvRow' => $ExportCsvRow,
                        ],
                        $request
                    );
                    $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_CUSTOMER_CSV_EXPORT, $event);

                    $ExportCsvRow->pushData();
                }

                // 出力.
                $csvService->fputcsv($ExportCsvRow->getRow());
            });
        });

        $now = new \DateTime();
        $filename = 'CashReceipt_'.$now->format('YmdHis').'.csv';
        $response->headers->set('Content-Type', 'application/octet-stream');
        $response->headers->set('Content-Disposition', 'attachment; filename='.$filename);
        $response->send();

        log_info('売上入金残高CSV出力ファイル名', [$filename]);

        return $response;
    }
}
