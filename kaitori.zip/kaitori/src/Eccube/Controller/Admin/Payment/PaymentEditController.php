<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Payment;

use Eccube\Controller\AbstractController;
use Eccube\Entity\Master\CustomerStatus;
use Eccube\Entity\Master\PayingStatus;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\CustomerType;
use Eccube\Form\Type\Admin\PayingType;
use Eccube\Repository\CustomerRepository;
use Eccube\Repository\OrderRepository;
use Eccube\Repository\PayingRepository;
use Eccube\Util\StringUtil;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Encoder\EncoderFactoryInterface;

class PaymentEditController extends AbstractController
{
    /**
     * @var CustomerRepository
     */
    protected $customerRepository;
    
    /**
     * @var OrderRepository
     */
    protected $orderRepository;
    
    /**
     * @var PayingRepository
     */
    protected $payingRepository;


    /**
     * @var EncoderFactoryInterface
     */
    protected $encoderFactory;

    public function __construct(
        CustomerRepository $customerRepository,
        OrderRepository $orderRepository,
        PayingRepository $payingRepository,
        EncoderFactoryInterface $encoderFactory
    ) {
        $this->customerRepository = $customerRepository;
        $this->orderRepository = $orderRepository;
        $this->payingRepository = $payingRepository;
        $this->encoderFactory = $encoderFactory;
    }
    
    /**
     * @Route("/%eccube_admin_route%/payment/new", name="admin_payment_new")
     * @Route("/%eccube_admin_route%/payment/{id}/edit/", requirements={"id" = "\d+"}, name="admin_payment_edit")
     * @Template("@admin/Payment/edit.twig")
     */
    public function edit(Request $request, $id = null)
    {
        // 入力パラメータ：送金番号
        
        // 編集
        if ($id) {
            $Paying = $this->payingRepository
                ->find($id);

            if (is_null($Paying)) {
                throw new NotFoundHttpException();
            }

            //$oldStatusId = $Paying->getStatus()->getId();
            // 編集用にデフォルトパスワードをセット
            //$previous_password = $Paying->getPassword();
            //$Paying->setPassword($this->eccubeConfig['eccube_default_password']);
       
        } else {
            $Paying = $this->payingRepository->newPaying();

            $oldStatusId = null;
        }

      
        $builder = $this->formFactory
            ->createBuilder(PayingType::class, $Paying);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'Paying' => $Paying,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYING_EDIT_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();
        
        $form->handleRequest($request);
    
        if ($form->isSubmitted() && $form->isValid()) {
            log_info('送金登録開始', [$Paying->getId()]);

            //$encoder = $this->encoderFactory->getEncoder($Paying);

           // if ($Paying->getPassword() === $this->eccubeConfig['eccube_default_password']) {
           //     $Paying->setPassword($previous_password);
           // } else {
           //     if ($Paying->getSalt() === null) {
           //         $Paying->setSalt($encoder->createSalt());
           //         $Paying->setSecretKey($this->payingRepository->getUniqueSecretKey());
           //     }
           //     $Paying->setPassword($encoder->encodePassword($Paying->getPassword(), $Paying->getSalt()));
           // }

            // 退会ステータスに更新の場合、ダミーのアドレスに更新
           // $newStatusId = $Paying->getStatus()->getId();
           // if ($oldStatusId != $newStatusId && $newStatusId == CustomerStatus::WITHDRAWING) {
           //     $Paying->setEmail(StringUtil::random(60).'@dummy.dummy');
           // }
           
            $this->entityManager->persist($Paying);
            $this->entityManager->flush();

            log_info('送金登録完了', [$Paying->getId()]);
            if($Paying->getPayingStatus() === $this->entityManager->find(PayingStatus ::class,  PayingStatus ::FINISH )){
            // 送金済みの場合
            // 更新orderステータス:入金待ちー＞入金完了
            $this->orderRepository->updateOrderStatus($Paying->getId());
            // 該当会員初回送金の場合初回振込、初回書留を設定する
            $customerId = $Paying->getCustomer()->getId();
            if(is_null($Paying->getFirstKakitomeDate())){
            // 該当会員の初回書留を取得する
            $firstKakitomeOrder = $this->orderRepository->getFirstKakitomeOrder($customerId);
            if($firstKakitomeOrder != null){
               $Paying->setFirstKakitomeDate($firstKakitomeOrder->getPaymentDate());
              }
            }
            
            if(is_null($Paying->getFirstFurikomiDate())){ 
            // 該当会員の初回書留を取得する
            $firstFurikomiOrder = $this->orderRepository->getFirstFurikomiOrder($customerId);
            if($firstFurikomiOrder != null){
              $Paying->setFirstFurikomiDate($firstFurikomiOrder->getPaymentDate());
            }
            $this->entityManager->persist($Paying);
            $this->entityManager->flush();
             }
            
            }

            $event = new EventArgs(
                [
                    'form' => $form,
                    'Paying' => $Paying,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYING_EDIT_INDEX_COMPLETE, $event);

            $this->addSuccess('admin.common.save_complete', 'admin');

            return $this->redirectToRoute('admin_payment_edit', [
                'id' => $Paying->getId(),
            ]);
        }

        return [
            'form' => $form->createView(),
            'Paying' => $Paying,
        ];
    }
}
