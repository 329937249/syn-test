<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Payment;

use Eccube\Common\Constant;
use Eccube\Controller\AbstractController;
use Eccube\Entity\ExportCsvRow;
use Eccube\Entity\LogControllable;
use Eccube\Entity\Master\CsvType;
use Eccube\Entity\Master\OrderStatus;
use Eccube\Entity\Master\PayingStatus;
use Eccube\Entity\OrderPdf;
use Eccube\Entity\Paying;
use Eccube\Entity\PhoneNumberPay;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\OrderPdfType;
use Eccube\Form\Type\Admin\SearchOrderType;
use Eccube\Form\Type\Admin\SearchPayingType;
use Eccube\Repository\CustomerRepository;
use Eccube\Repository\Master\OrderStatusRepository;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\Master\ProductStatusRepository;
use Eccube\Repository\Master\SexRepository;
use Eccube\Repository\OrderPdfRepository;
use Eccube\Repository\OrderRepository;
use Eccube\Repository\PayingRepository;
use Eccube\Repository\ProductStockRepository;
use Eccube\Repository\OrderOpehistRepository;
use Eccube\Repository\PhoneNumberPayRepository;
use Eccube\Service\CsvExportService;
use Eccube\Service\MailService;
use Eccube\Service\OrderPdfService;
use Eccube\Service\OrderStateMachine;
use Eccube\Service\PurchaseFlow\PurchaseFlow;
use Eccube\Util\FormUtil;
use Knp\Component\Pager\PaginatorInterface;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Form\FormBuilder;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Validator\ValidatorInterface;
use Doctrine\DBAL\Exception\ForeignKeyConstraintViolationException;
use Eccube\Entity\PayeeVoucherDetail;
use Eccube\Entity\PayeeVoucherHeader;
use Eccube\Entity\PayeeVoucherHeaderHistory;
use Eccube\Entity\SalesVoucherDetailLink;
use Eccube\Entity\StockListProductUnit;
use Eccube\Entity\StockListStorehouseUnit;
use Eccube\Repository\StockListProductUnitRepository;
use Eccube\Repository\StockListStorehouseUnitRepository;
use Eccube\Repository\PayeeMstRepository;
use Eccube\Util\CacheUtil;
use Eccube\Repository\PayeePaidBalanceRepository;
use Eccube\Repository\PayeeVoucherDetailRepository;
use Eccube\Repository\PayeeVoucherHeaderHistoryRepository;
use Eccube\Repository\PayeeVoucherHeaderRepository;
use Eccube\Repository\SalesVoucherDetailLinkRepository;

class PaymentOrderController extends AbstractController
{
    /**
     * @var PurchaseFlow
     */
    protected $purchaseFlow;

    /**
     * @var CsvExportService
     */
    protected $csvExportService;

    /**
     * @var CustomerRepository
     */
    protected $customerRepository;

    /**
     * @var SexRepository
     */
    protected $sexRepository;

    /**
     * @var OrderStatusRepository
     */
    protected $orderStatusRepository;

    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;

    /**
     * @var ProductStatusRepository
     */
    protected $productStatusRepository;

    /**
     * @var OrderRepository
     */
    protected $orderRepository;
    
    /**
     * @var PayingRepository
     */
    protected $payingRepository;
    
    /**
     * @var OrderOpehistRepository
     */
    protected $orderOpehistRepository;

    /** 
     * @var OrderPdfRepository 
     */
    protected $orderPdfRepository;

    /**
     * @var ProductStockRepository
     */
    protected $productStockRepository;

    /** @var OrderPdfService */
    protected $orderPdfService;

    /**
     * @var ValidatorInterface
     */
    protected $validator;

    /**
     * @var OrderStateMachine
     */
    protected $orderStateMachine;

    /**
     * @var MailService
     */
    protected $mailService;

    // INS-START CNC 2021/08/23
    /**
     * @var PayeeVoucherHeaderHistoryRepository
     */
    protected $payeeVoucherHeaderHistoryRepository;

    /**
     * @var PayeeVoucherHeaderRepository
     */
    protected $payeeVoucherHeaderRepository;

    /**
     * @var PayeeVoucherDetailRepository
     */
    protected $payeeVoucherDetailRepository;

    /**
     * @var StockListProductUnitRepository
     */
    protected $stockListProductUnitRepository;

    /**
     * @var StockListStorehouseUnitRepository
     */
    protected $stockListStorehouseUnitRepository;

    /**
     * @var SalesVoucherDetailLinkRepository
     */
    protected $salesVoucherDetailLinkRepository;
    // INS-END CNC 2021/08/23

    /**
     * @var PhoneNumberPayRepository
     */
    protected $phoneNumberPayRepository;

    /**
     * OrderController constructor.
     *
     * @param PurchaseFlow $orderPurchaseFlow
     * @param CsvExportService $csvExportService
     * @param CustomerRepository $customerRepository
     * @param SexRepository $sexRepository
     * @param OrderStatusRepository $orderStatusRepository
     * @param PageMaxRepository $pageMaxRepository
     * @param ProductStatusRepository $productStatusRepository
     * @param ProductStockRepository $productStockRepository
     * @param OrderRepository $orderRepository
     * @param OrderPdfRepository $orderPdfRepository
     * @param ValidatorInterface $validator
     * @param OrderStateMachine $orderStateMachine
     * @param PayeeVoucherDetailRepository $payeeVoucherDetailRepository 仕入伝票明細
     * @param PayeeVoucherHeaderHistoryRepository $payeeVoucherHeaderHistoryRepository 仕入伝票ヘッダー履歴
     * @param PayeeVoucherHeaderRepository $payeeVoucherHeaderRepository 仕入伝票ヘッダー
     * @param StockListProductUnitRepository $stockListProductUnitRepository 在庫一覧（商品単位）
     * @param StockListStorehouseUnitRepository $stockListStorehouseUnitRepository 在庫一覧（置場単位）
     * @param SalesVoucherDetailLinkRepository $salesVoucherDetailLinkRepository 売上伝票明細紐付;
     * @param PhoneNumberPayRepository $phoneNumberPayRepository 電話番号送金不可情報;

     */
    public function __construct(
        PurchaseFlow $orderPurchaseFlow,
        CsvExportService $csvExportService,
        CustomerRepository $customerRepository,
        PayingRepository $payingRepository,
        OrderOpehistRepository $orderOpehistRepository,
        SexRepository $sexRepository,
        OrderStatusRepository $orderStatusRepository,
        PageMaxRepository $pageMaxRepository,
        ProductStatusRepository $productStatusRepository,
        ProductStockRepository $productStockRepository,
        OrderRepository $orderRepository,
        OrderPdfRepository $orderPdfRepository,
        ValidatorInterface $validator,
        OrderStateMachine $orderStateMachine,
        MailService $mailService,
        // INS-START CNC 2021/08/23
        PayeeVoucherDetailRepository $payeeVoucherDetailRepository,
        PayeeVoucherHeaderHistoryRepository $payeeVoucherHeaderHistoryRepository,
        PayeeVoucherHeaderRepository $payeeVoucherHeaderRepository,
        StockListProductUnitRepository $stockListProductUnitRepository,
        StockListStorehouseUnitRepository $stockListStorehouseUnitRepository,
        SalesVoucherDetailLinkRepository $salesVoucherDetailLinkRepository,
        // INS-END CNC 2021/08/23
        PhoneNumberPayRepository $phoneNumberPayRepository
    ) {
        $this->purchaseFlow = $orderPurchaseFlow;
        $this->csvExportService = $csvExportService;
        $this->customerRepository = $customerRepository;
        $this->payingRepository = $payingRepository;
        $this->orderOpehistRepository = $orderOpehistRepository;
        $this->sexRepository = $sexRepository;
        $this->orderStatusRepository = $orderStatusRepository;
        $this->pageMaxRepository = $pageMaxRepository;
        $this->productStatusRepository = $productStatusRepository;
        $this->productStockRepository = $productStockRepository;
        $this->orderRepository = $orderRepository;
        $this->orderPdfRepository = $orderPdfRepository;
        $this->validator = $validator;
        $this->orderStateMachine = $orderStateMachine;
        $this->mailService = $mailService;
        // INS-START CNC 2021/08/23
        $this->payeeVoucherDetailRepository = $payeeVoucherDetailRepository;
        $this->payeeVoucherHeaderHistoryRepository = $payeeVoucherHeaderHistoryRepository;
        $this->payeeVoucherHeaderRepository = $payeeVoucherHeaderRepository;
        $this->stockListProductUnitRepository = $stockListProductUnitRepository;
        $this->stockListStorehouseUnitRepository = $stockListStorehouseUnitRepository;
        $this->salesVoucherDetailLinkRepository = $salesVoucherDetailLinkRepository;
        // INS-END CNC 2021/08/23
        $this->phoneNumberPayRepository = $phoneNumberPayRepository;
    }

    /**
     * 送金一覧画面.
     *
     * - 検索条件, ページ番号, 表示件数はセッションに保持されます.
     * - クエリパラメータでresume=1が指定された場合、検索条件, ページ番号, 表示件数をセッションから復旧します.
     * - 各データの, セッションに保持するアクションは以下の通りです.
     *   - 検索ボタン押下時
     *      - 検索条件をセッションに保存します
     *      - ページ番号は1で初期化し、セッションに保存します。
     *   - 表示件数変更時
     *      - クエリパラメータpage_countをセッションに保存します。
     *      - ただし, mtb_page_maxと一致しない場合, eccube_default_page_countが保存されます.
     *   - ページング時
     *      - URLパラメータpage_noをセッションに保存します.
     *   - 初期表示
     *      - 検索条件は空配列, ページ番号は1で初期化し, セッションに保存します.
     *
     * @Route("/%eccube_admin_route%/payment/order", name="admin_payment_order")
     * @Route("/%eccube_admin_route%/payment/order/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_payment_order_page")
     * @Template("@admin/Payment/order.twig")
     */
    public function index(Request $request, $page_no = null, PaginatorInterface $paginator)
    {
        $builder = $this->formFactory->createBuilder(SearchPayingType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_PAYMENT_ORDER_INITIALIZE, $event);

        $searchForm = $builder->getForm();

        /**
         * ページの表示件数は, 以下の順に優先される.
         * - リクエストパラメータ
         * - セッション
         * - デフォルト値
         * また, セッションに保存する際は mtb_page_maxと照合し, 一致した場合のみ保存する.
         **/
        $page_count = $this->session->get('eccube.admin.payment.order.search.page_count',
            $this->eccubeConfig->get('eccube_default_page_count'));

        $page_count_param = (int) $request->get('page_count');
        $pageMaxis = $this->pageMaxRepository->findAll();

        if ($page_count_param) {
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.admin.payment.order.search.page_count', $page_count);
                    break;
                }
            }
        }

        if ('POST' === $request->getMethod()) {
            $searchForm->handleRequest($request);

            if ($searchForm->isValid()) {
                /**
                 * 検索が実行された場合は, セッションに検索条件を保存する.
                 * ページ番号は最初のページ番号に初期化する.
                 */
                $page_no = 1;
                $searchData = $searchForm->getData();

                // 検索条件, ページ番号をセッションに保持.
                $this->session->set('eccube.admin.payment.order.search', FormUtil::getViewData($searchForm));
                $this->session->set('eccube.admin.payment.order.search.page_no', $page_no);
            } else {
                // 検索エラーの際は, 詳細検索枠を開いてエラー表示する.
                return [
                    'searchForm' => $searchForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $page_count,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.admin.payment.order.search.page_no', (int) $page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.admin.payment.order.search.page_no', 1);
                }
                $viewData = $this->session->get('eccube.admin.payment.order.search', []);
                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
            } else {
                /**
                 * 初期表示の場合.
                 */
                $page_no = 1;
                $viewData = [];

                if ($statusId = (int) $request->get('order_status_id')) {
                    $viewData = ['status' => $statusId];
                }

                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);

                // セッション中の検索条件, ページ番号を初期化.
                $this->session->set('eccube.admin.payment.order.search', $viewData);
                $this->session->set('eccube.admin.payment.order.search.page_no', $page_no);
            }
        }
        
        $items = $this->payingRepository->getQueryBuilderByOrderData($searchData);

        $itemsBk = $items;

        $items = [];

        // 振込未送金総金額合計
        $furikomi_total_price_sum = 0;
        // 書留未送金総金額合計
        $kakitome_total_price_sum = 0;

        foreach ($itemsBk as $item) {

//            $phoneNumber = $item['phone_number'];
//            $qbno= $this->phoneNumberPayRepository->getPhoneNumberData($phoneNumber);

            $furikomi_total_price_sum = $furikomi_total_price_sum + $item[0]->getFurikomiTotalPrice();
            $kakitome_total_price_sum = $kakitome_total_price_sum + $item[0]->getKakitomeTotalPrice();

            $order_no = $item['order_no'];
            $qbno= $this->phoneNumberPayRepository->getPhoneNumberData($order_no);

            if($qbno){
                if($qbno[0]->getPayKubun() === 0 ){
                    $item[0]->setPayingPossible(0);

                }else {
                    $item[0]->setPayingPossible(1);
                }

            }else{
                $item[0]->setPayingPossible(1);
            }

            array_push($items, $item[0]);

        }

        // $event = new EventArgs(
        //     [
        //         'qb' => $qb,
        //         'searchData' => $searchData,
        //     ],
        //    $request
        // );

        // $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_PAYMENT_ORDER_SEARCH, $event);
     
        // $items = [];
        // $filter_items = [];
        // foreach ($qb as $item) {
        //     $paying_item = $this->payingRepository->find($item['id']);
        //     array_push($items,$paying_item);
        //  }

        // foreach ($items as $Paying) {
        //     if($Paying->getOrders()){
        //        $Orders = $Paying->getOrders()->filter(function ($value, $key) {
        //           if($value->getOrderStatus()){
        //              return ($value->getOrderStatus()->getId() != OrderStatus :: PROCESSING and $value->getOrderStatus()->getId() != OrderStatus :: CANCEL and $value->getPaymentMethod() != '現金払い') ;
        //           }
        //        });
        //     }
        //     $Paying->setOrders($Orders);
        //     array_push($filter_items,$Paying);
        // }
        
        $sort_payings = $this->sortPaying($items, $searchData);

        // foreach ($sort_payings as $paying) {
        //     $lastOrder = $this->orderRepository->getLastOrderId($paying);
        //     $wait_Order_count = $this->payingRepository->getOrderCounts($paying);
        //     $newPaying = $this->orderRepository->getNotPayPrice($paying);
        //     //$paying->setLastOrder($lastOrder);
        //     //$paying->setWaitOrderCount($wait_Order_count);
        //     $paying->setNewPaying($newPaying);
        // }

        $result = $paginator->paginate(
            $sort_payings,
            $page_no,
            $page_count
        );
       
        return [
            'searchForm' => $searchForm->createView(),
            'pagination' => $result,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'has_errors' => false,
            'OrderStatuses' => $this->orderStatusRepository->findBy([], ['sort_no' => 'ASC']),
            'furikomi_total_price_sum' => $furikomi_total_price_sum,
            'kakitome_total_price_sum' => $kakitome_total_price_sum,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/order/bulk_delete", name="admin_order_bulk_delete", methods={"POST"})
     */
    public function bulkDelete(Request $request)
    {
        $this->isTokenValid();
        $ids = $request->get('ids');
        foreach ($ids as $order_id) {
            $Order = $this->orderRepository
                ->find($order_id);
            if ($Order) {
                $this->entityManager->remove($Order);
                log_info('受注削除', [$Order->getId()]);
            }
        }

        $this->entityManager->flush();

        $this->addSuccess('admin.common.delete_complete', 'admin');

        return $this->redirect($this->generateUrl('admin_order', ['resume' => Constant::ENABLED]));
    }

    /**
     * 受注CSVの出力.
     *
     * @Route("/%eccube_admin_route%/order/export/order", name="admin_order_export_order")
     *
     * @param Request $request
     *
     * @return StreamedResponse
     */
    public function exportOrder(Request $request)
    {
        $filename = 'order_'.(new \DateTime())->format('YmdHis').'.csv';
        $response = $this->exportCsv($request, CsvType::CSV_TYPE_ORDER, $filename);
        log_info('受注CSV出力ファイル名', [$filename]);

        return $response;
    }

    /**
     * 配送CSVの出力.
     *
     * @Route("/%eccube_admin_route%/order/export/shipping", name="admin_order_export_shipping")
     *
     * @param Request $request
     *
     * @return StreamedResponse
     */
    public function exportShipping(Request $request)
    {
        $filename = 'shipping_'.(new \DateTime())->format('YmdHis').'.csv';
        $response = $this->exportCsv($request, CsvType::CSV_TYPE_SHIPPING, $filename);
        log_info('配送CSV出力ファイル名', [$filename]);

        return $response;
    }

    /**
     * @param Request $request
     * @param $csvTypeId
     * @param string $fileName
     *
     * @return StreamedResponse
     */
    protected function exportCsv(Request $request, $csvTypeId, $fileName)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        // sql loggerを無効にする.
        $em = $this->entityManager;
        $em->getConfiguration()->setSQLLogger(null);

        $response = new StreamedResponse();
        $response->setCallback(function () use ($request, $csvTypeId) {
            // CSV種別を元に初期化.
            $this->csvExportService->initCsvType($csvTypeId);

            // ヘッダ行の出力.
            $this->csvExportService->exportHeader();

            // 受注データ検索用のクエリビルダを取得.
            $qb = $this->csvExportService
                ->getOrderQueryBuilder($request);

            // データ行の出力.
            $this->csvExportService->setExportQueryBuilder($qb);
            $this->csvExportService->exportData(function ($entity, $csvService) use ($request) {
                $Csvs = $csvService->getCsvs();

                $Order = $entity;
                $OrderItems = $Order->getOrderItems();

                foreach ($OrderItems as $OrderItem) {
                    $ExportCsvRow = new ExportCsvRow();

                    // CSV出力項目と合致するデータを取得.
                    foreach ($Csvs as $Csv) {
                        // 受注データを検索.
                        $ExportCsvRow->setData($csvService->getData($Csv, $Order));
                        if ($ExportCsvRow->isDataNull()) {
                            // 受注データにない場合は, 受注明細を検索.
                            $ExportCsvRow->setData($csvService->getData($Csv, $OrderItem));
                        }
                        if ($ExportCsvRow->isDataNull() && $Shipping = $OrderItem->getShipping()) {
                            // 受注明細データにない場合は, 出荷を検索.
                            $ExportCsvRow->setData($csvService->getData($Csv, $Shipping));
                        }

                        $event = new EventArgs(
                            [
                                'csvService' => $csvService,
                                'Csv' => $Csv,
                                'OrderItem' => $OrderItem,
                                'ExportCsvRow' => $ExportCsvRow,
                            ],
                            $request
                        );
                        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ORDER_CSV_EXPORT_ORDER, $event);

                        $ExportCsvRow->pushData();
                    }

                    //$row[] = number_format(memory_get_usage(true));
                    // 出力.
                    $csvService->fputcsv($ExportCsvRow->getRow());
                }
            });
        });

        $response->headers->set('Content-Type', 'application/octet-stream');
        $response->headers->set('Content-Disposition', 'attachment; filename='.$fileName);
        $response->send();

        return $response;
    }

    /**
     * Update paying status
     *
     * @Route("/%eccube_admin_route%/payment/order/{id}/order_status", requirements={"id" = "\d+"}, name="admin_paying_update_status", methods={"PUT"})
     *
     * @param Request $request
     * @param int $id
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function updateOrderStatus(Request $request, $id)
    {
        $Paying = $this->payingRepository->find($id);

         //$Customer = $this->customerRepository->find($Paying->getCustomer()->getId());
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
        }

       // update orderStatus
    //    $OrderIds = [];
    //   if($Paying->getCustomer()){
    //       $OrderIds = $this->orderRepository->getAllOrderIds($id,$Paying->getCustomer());
    //    }else{
    //       $OrderIds = $this->orderRepository->getNoneMemberNotPayOrder($id);
    //    }

       //if(null != $OrderIds and count($OrderIds) > 0){
          //foreach($OrderIds as $OrderId){
              // $Order = $this->orderRepository->find($OrderId);
              $Order = $Paying->getOrders()->first();
              // 送金待ちの場合 送金待ち --> 送金完了
              if($this->entityManager->find(OrderStatus::class,  OrderStatus::PENDING) === $Order->getOrderStatus()){
                   $OrderStatus = $this->entityManager->find(OrderStatus::class,  OrderStatus::PAID);
                    if ($this->orderStateMachine->can($Order, $OrderStatus)) {
                         $this->orderStateMachine->apply($Order, $OrderStatus);
                         // 操作履歴に登録
                         /** @var OrderOpehist $OrderOpehist */
                         $Member = $this->getUser();
                         $this->orderOpehistRepository->insertOrderOpehist($Order, $Member,'対応状況変更');
                    }
               }
        //    }
        //  }

        if($Paying->getCustomer()){
           $this->setFirstPaymentDate($Paying);
        }else{
           $this->setNoneMemberFirstPaymentDate($Paying);
        }
        $Paying = $this->payingRepository->updatePayingStatus($Paying);
        
        // 該当会員最後の送金idを更新する
        if($Paying->getCustomer()){
           $Customer = $Paying->getCustomer();
           $this->payingRepository->updateMaxPayingIdByCustomer($Customer,$id);
           $this->orderRepository->updateCustomerSummary($Customer);
           $this->orderRepository->updateAmazonCustomerSummary($Customer);
           $this->entityManager->flush($Customer);
        }

        // update other paying date 
        if($Customer = $Paying->getCustomer()){
             // 該当会員の初回振込を取得する
             $firstFurikomiOrder = $this->orderRepository->getFirstFurikomiOrder($Customer->getId());
             // 該当会員の初回書留を取得する
             $firstKakitomeOrder = $this->orderRepository->getFirstKakitomeOrder($Customer->getId());
             
             $firstKakitomeDate = is_null($firstKakitomeOrder) ? null : $firstKakitomeOrder->getPaymentDate();
             $firstFurikomiDate = is_null($firstFurikomiOrder) ? null : $firstFurikomiOrder->getPaymentDate();
             $this->payingRepository->updateOtherPaying($Customer,$firstKakitomeDate,$firstFurikomiDate);
        }

        $result = [];
        try {
               $Paying = $this->payingRepository->findOneBy(['id' => $id]);
               if($Paying->getPayingStatus()->getId() == PayingStatus :: FINISH){
                  if($Paying->getOrders()){
                    $Orders = $Paying->getOrders()->filter(function ($value, $key) {
                       return ($value->getOrderStatus()->getId() != OrderStatus :: PROCESSING and $value->getOrderStatus()->getId() != OrderStatus :: CANCEL and $value->getPaymentMethod() != '現金払い'
                               and null != $value->getPaymentDate() and $value->getPaymentDate()->format('Y-m-d') == $value->getPaying()->getPayingDate()->format('Y-m-d')) ;
                    });
                  }
                  $Paying->setOrders($Orders);
                }
                $this->mailService->sendPayingNotifyMail($Paying);
                $result['mail'] = true;

        } catch (\Exception $e) {
            log_error('予期しないエラーです', [$e->getMessage()]);

            return $this->json(['status' => 'NG'], 500);
        }
        $Paying->setMember($this->getUser());
        $this->entityManager->flush($Paying);
        return $this->json(array_merge(['status' => 'OK'], $result));
    }

    /**
     * Update to Tracking number.
     *
     * @Route("/%eccube_admin_route%/payment/order/{id}/update_tracking_number", requirements={"id" = "\d+"}, name="admin_payment_update_tracking_number", methods={"PUT"})
     *
     * @param Request $request
     * @param Paying $Paying
     *
     * @return Response
     */
    public function updateTrackingNumber(Request $request, Paying $paying)
    {

        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
        }

        $trackingNumber = mb_convert_kana($request->get('tracking_number'), 'a', 'utf-8');
        /** @var \Symfony\Component\Validator\ConstraintViolationListInterface $errors */
        $errors = $this->validator->validate(
            $trackingNumber,
            [
                new Assert\Length(['max' => $this->eccubeConfig['eccube_stext_len']]),
                new Assert\Regex(
                    ['pattern' => '/^[0-9a-zA-Z-]+$/u', 'message' => trans('admin.order.tracking_number_error')]
                ),
            ]
        );

        if ($errors->count() != 0) {
            log_info('追跡番号入力チェックエラー');
            $messages = [];
            /** @var \Symfony\Component\Validator\ConstraintViolationInterface $error */
            foreach ($errors as $error) {
                $messages[] = $error->getMessage();
            }

            return $this->json(['status' => 'NG', 'messages' => $messages], 400);
        }

        try {
            $paying->setTrackingNumber($trackingNumber);
            $paying->setMember($this->getUser());
            $this->entityManager->flush($paying);
            log_info('追跡番号変更処理完了', [$paying->getId()]);
            $message = ['status' => 'OK', 'paying_id' => $paying->getId(), 'tracking_number' => $trackingNumber];

            return $this->json($message);
        } catch (\Exception $e) {
            log_error('予期しないエラー', [$e->getMessage()]);

            return $this->json(['status' => 'NG'], 500);
        }
    }

    /**
     * rollkback paying status
     *
     * @Route("/%eccube_admin_route%/payment/order/{id}/paying_status/{customerId}", requirements={"id" = "\d+","customerId" = "\d+"}, name="admin_rollback_paying_status", methods={"PUT"})
     *
     * @param Request $request Request
     * @param int $id id
     * @param int $customerId customer Id
     * @param CacheUtil|null $cacheUtil Cache Util
     * @return \Symfony\Component\HttpFoundation\JsonResponse|RedirectResponse
     */
    public function rollbackPayingStatus(Request $request, $id, $customerId = null, CacheUtil $cacheUtil = null)
   {
   
     $result = [];
     $payingId = $request->get('id');
     $customerId = $request->get('customerId');
     try {
        $Member = $this->getUser();
        $OrderIds = $this->orderRepository->getNotPayOrderIds($payingId,$customerId );
       if(null != $OrderIds and count($OrderIds) > 0){
          foreach($OrderIds as $OrderId){
              $Order = $this->orderRepository->find($OrderId);
              // 送金待ちー＞入荷待ち
              //$PreOrderStatus = $Order->getPreOrderStatus();
              $PreOrderStatus = $this->entityManager
                 ->find(OrderStatus::class, OrderStatus::RETURNED);
              if ($this->orderStateMachine->can($Order, $PreOrderStatus)) {

                   $this->orderStateMachine->apply($Order, $PreOrderStatus);

                   $this->entityManager->flush($Order);
                   // 操作履歴に登録
                   /** @var OrderOpehist $OrderOpehist */
                   $this->orderOpehistRepository->insertOrderOpehist($Order, $Member,'対応状況変更');
                  
                  // 在庫戻す
                   // if ($Order->getOrderStatus()->getId() == OrderStatus::RETURNED) {
                   //    foreach ($Order->getOrderItems() as $OrderItem) {
                   //         $ProductClass = $OrderItem->getProductClass();
                   //         if ($OrderItem->isProduct() && !$ProductClass->isStockUnlimited()) {
                   //             $quantity = $OrderItem->getQuantity();
                   //             log_info('1167.........................');
                   //             log_info($quantity);
                   //             log_info('1169.........................');
                   //             $this->entityManager->flush($ProductClass);
                   //             $ProductStock = $this->productStockRepository->findOneBy(['ProductClass' => $ProductClass]);
                   //             $nowStock = $ProductStock->getStock() == null ? 0 : $ProductStock->getStock();
                   //             $ProductStock->setStock($nowStock - $quantity);
                   //             $this->entityManager->flush($ProductStock);
                   //          }
                   //        }
                  //    }
              }

                    // INS-START CNC 2021/08/23
                    $Order = $this->orderRepository->find($OrderId);
                    $orderNo = $Order->getOrderNo();
                    $this->isTokenValid();
                    $session = $request->getSession();
                    $page_no = intval($session->get('eccube.admin.payment.search.page_count'));
                    $page_no = $page_no ? $page_no : Constant::ENABLED;
                    $message = null;
                    $success = false;
                    $member = $this->getUser();

                    if (!is_null($orderNo)) {
                        /** @var PayeeVoucherHeader $entity_payee_voucher_header */
                        $entity_payee_voucher_header = $this->payeeVoucherHeaderRepository->findOneBy(['payee_voucher_no' => $orderNo]);
                        $registrationStatus = $entity_payee_voucher_header->getRegistrationStatus();
                        if (!$entity_payee_voucher_header) {
                            if ($request->isXmlHttpRequest()) {
                                $message = trans('admin.common.delete_error_already_deleted');

                                return $this->json(['success' => $success, 'message' => $message]);
                            } else {
                                $this->deleteMessage();
                                $rUrl = $this->generateUrl('admin_payment_order_page', ['page_no' => $page_no]).'?resume='.Constant::ENABLED;

                                return $this->redirect($rUrl);
                            }
                        }

                        // ヘッダー売上状態チェック
                        if ($this->isSoldHeader($entity_payee_voucher_header)) {
                            log_info('admin.payee.voucher.detail_delete_when_sold', [$orderNo]);
                            $message = trans('admin.payee.voucher.detail_delete_when_sold');

                            $this->addError($message, 'admin');
                            $rUrl = $this->generateUrl('admin_payment_order_page', ['page_no' => $page_no]).'?resume='.Constant::ENABLED;

                            return $this->redirect($rUrl);
                        }

                        if ($entity_payee_voucher_header instanceof PayeeVoucherHeader) {
                            log_info('仕入伝票ヘッダー削除開始', [$orderNo]);

                            $collection_payee_voucher_detail = $entity_payee_voucher_header->getPayeeVoucherDetails();

                            try {
                                // 関連仕入伝票明細削除
                                //   2021/12/17変更後
                                //   申込画面で仮登録を実行することになったので、ここに取り消すとき、ヘッダと明細の削除は行わない
                                //   在庫データ削除して、「本登録」から「仮登録」に変更するのは十分です。
                                if ($collection_payee_voucher_detail->count() > 0) {
                                    foreach ($collection_payee_voucher_detail as $detail) {
                                        $this->removeStockInfoWithDetailRemoved($detail, $entity_payee_voucher_header, $member['name']);
                                        $this->payeeVoucherDetailRepository->delete($detail);
                                    }
                                }

                                if ($registrationStatus == trans('admin.payee.voucher.input_mode.real_register')) {
                                    // 履歴（ヘッダ―）
                                    $payee_voucher_history = $this->payeeVoucherHeaderHistoryRepository
                                        ->createPayeeVoucherHeaderHistoryByHeader($entity_payee_voucher_header, PayeeVoucherHeaderHistory::BEHAVIOR_DELETE);
                                    $this->entityManager->persist($payee_voucher_history);
                                } else {
                                    // 履歴（ヘッダ―）
                                    $payee_voucher_history = $this->payeeVoucherHeaderHistoryRepository
                                        ->createPayeeVoucherHeaderHistoryByHeaderFalse($entity_payee_voucher_header, PayeeVoucherHeaderHistory::BEHAVIOR_DELETE);
                                    $this->entityManager->persist($payee_voucher_history);
                                }

                                $this->payeeVoucherHeaderRepository->delete($entity_payee_voucher_header);
//                                $entity_payee_voucher_header->setRegistrationStatus(trans('admin.payee.voucher.input_mode.provisional_register'));
                                $this->entityManager->flush();

                                $event = new EventArgs(
                                    [
                                        'PayeeVoucherHeader' => $entity_payee_voucher_header,
                                        'PayeeVoucherDetail' => $collection_payee_voucher_detail,
                                    ],
                                    $request
                                );
                                $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYEE_VOUCHER_DELETE_COMPLETE, $event);

                                log_info('仕入伝票ヘッダー削除完了', [$orderNo]);

                                $success = true;

                                $cacheUtil->clearDoctrineCache();
                            } catch (ForeignKeyConstraintViolationException $e) {
                                log_info('仕入伝票ヘッダー削除エラー', [$orderNo]);
                                $message = trans('admin.common.delete_error_foreign_key', ['%name%' => $entity_payee_voucher_header->getPayeeVoucherNo()]);
                            } catch (\Exception $e) {
                                log_info('仕入伝票ヘッダー削除エラー', [$orderNo]);
                                $message = trans('admin.common.delete_error');
                            }
                        } else {
                            log_info('仕入伝票ヘッダー削除エラー', [$orderNo]);
                            $message = trans('admin.common.delete_error');
                        }
                    } else {
                        log_info('仕入伝票ヘッダー削除エラー', [$orderNo]);
                        $message = trans('admin.common.delete_error');
                    }

                    if ($request->isXmlHttpRequest()) {
                        return $this->json(['success' => $success, 'message' => $message]);
                    } else {
                        if ($success) {
                            $this->addSuccess($message, 'admin');
                            $rUrl = $this->generateUrl('admin_payment_order_page', ['page_no' => $page_no]).'?resume='.Constant::ENABLED;
                        } else {
                            $this->addError($message, 'admin');
                            $rUrl = $this->generateUrl('admin_payment_order_page', ['page_no' => $page_no]).'?resume='.Constant::ENABLED;
                        }

                        return $this->redirect($rUrl);
                    }
                    // INS-END CNC 2021/08/23
          }
       }

        $result = ['message' => trans('admin.common.update.paying.no', ['%payingNo%' =>  $payingId ])];

        return $this->json(array_merge(['status' => 'OK'], $result));

  } catch (\Exception $e) {
           
            $result = ['message' => trans('admin.common.update.paying.no.fail', ['%payingNo%' =>  $payingId ])];
             return $this->json(array_merge(['status' => 'NG'], $result));
        }
        
      }

    // INS-START CNC 2021/08/23
    /**
     * @param PayeeVoucherDetail $payee_voucher_detail 明細
     * @param PayeeVoucherHeader $payee_voucher_header 明細対応するヘッダー
     * @param string $user_name ユーザ名
     */
    public function removeStockInfoWithDetailRemoved(PayeeVoucherDetail $payee_voucher_detail, PayeeVoucherHeader $payee_voucher_header, string $user_name)
    {
        if ($payee_voucher_header->getRegistrationStatus() === trans('admin.payee.voucher.input_mode.real_register')) {
            // 在庫一覧（商品単位）
            $parameter_stock_by_product = [
                'productId' => $payee_voucher_detail->getProductId(),
                'ProductClass' => $payee_voucher_detail->getProductClass(),
                'productCode' => $payee_voucher_detail->getProductCode(),
                'State' => $payee_voucher_detail->getState(),
            ];

            $collection_stock_list_product_unit = $this->stockListProductUnitRepository
                ->findBy($parameter_stock_by_product);

            if (isset($collection_stock_list_product_unit[0])) {
                /** @var StockListProductUnit $entity_stock_list_product_unit */
                $entity_stock_list_product_unit = $collection_stock_list_product_unit[0];
                $stock_quantity_product_unit =
                    $entity_stock_list_product_unit->getStockQuantity() - $payee_voucher_detail->getQuantity();
                $before_stock_quantity_product_unit = $entity_stock_list_product_unit->getStockQuantity();
                $entity_stock_list_product_unit->setStockQuantity(
                    $stock_quantity_product_unit
                );
                $entity_stock_list_product_unit->setRemainingStockQuantity(
                    $stock_quantity_product_unit
                    - $entity_stock_list_product_unit->getOrderQuantity()
                    - $entity_stock_list_product_unit->getProvisionalShipmentQuantity()
                )->setUpdateUserName($user_name);
                if ($before_stock_quantity_product_unit <= 0 || $stock_quantity_product_unit <= 0
                    || $entity_stock_list_product_unit->getAverageUnitPrice() <= 0
                    || $entity_stock_list_product_unit->getAverageUnitPrice() * $before_stock_quantity_product_unit - $payee_voucher_detail->getPayeeMoneyAmount() <= 0) {

                    $entity_stock_list_product_unit->setAverageUnitPrice(round($payee_voucher_detail->getPayeeMoneyAmount() / $payee_voucher_detail->getQuantity()));
                }
                else {
                    $entity_stock_list_product_unit->setAverageUnitPrice(
                        $stock_quantity_product_unit === 0
                            ? 0
                            : round(
                            (
                                $entity_stock_list_product_unit->getAverageUnitPrice()
                                * $before_stock_quantity_product_unit
                                - $payee_voucher_detail->getPayeeMoneyAmount()
                            ) / $stock_quantity_product_unit
                        )
                    );
                }

                $this->entityManager->persist($entity_stock_list_product_unit);
                $this->entityManager->flush($entity_stock_list_product_unit);
                LogControllable::print_log(__FILE__, '########## Insert/update: stock list by product', [$entity_stock_list_product_unit->toArray()]);
            }

            // 在庫一覧（置場単位）
            $parameter_stock_by_place = [
                'productId' => $payee_voucher_detail->getProductId(),
                'ProductClass' => $payee_voucher_detail->getProductClass(),
                'productCode' => $payee_voucher_detail->getProductCode(),
                'serialNo' => $payee_voucher_detail->getSerialNo(),
                'State' => $payee_voucher_detail->getState(),
                'Storehouse' => $payee_voucher_header->getPlace(),
            ];
            $collection_stock_list_place_unit = $this->stockListStorehouseUnitRepository
                ->findBy($parameter_stock_by_place);

            if (isset($collection_stock_list_place_unit[0])) {
                /** @var StockListStorehouseUnit $entity_stock_list_place_unit */
                $entity_stock_list_place_unit = $collection_stock_list_place_unit[0];
                $entity_stock_list_place_unit->setStockQuantity(
                    $entity_stock_list_place_unit->getStockQuantity()
                    - $payee_voucher_detail->getQuantity()
                )->setUpdateUserName($user_name);
                $this->entityManager->persist($entity_stock_list_place_unit);
                $this->entityManager->flush($entity_stock_list_place_unit);
                LogControllable::print_log(__FILE__, '########## Insert/update: stock list by storehouse', [$entity_stock_list_place_unit->toArray()]);
            }
        } else {
            return;
        }
    }
    // INS-END CNC 2021/08/23

    /**
     * updateAcceptMemberName
     *
     * @Route("/%eccube_admin_route%/shipping/{id}/update_paying_member_name", requirements={"id" = "\d+"}, name="admin_shipping_update_paying_member_accept", methods={"PUT"})
     *
     * @param Request $request
     * @param Paying $Paying
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function updateAcceptMemberName(Request $request, Paying $Paying)
    {
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
          return $this->json(['status' => 'NG'], 400);
         }
         
        $Member = $this->getUser();    
        //$Order = $Shipping->getOrder();

        $result = [];
       
        try {
              
              if($Paying->getMember() == null){
                 $Paying->setMember($Member);
                 $this->entityManager->flush($Paying);
              }else{
                
                 $result = ['message' => trans('admin.paying.failed_to_change_member', [
                   '%name%' => $Paying->getId(),
                  
                ])];

              }

            } catch (\Exception $e) {
             log_error('予期しないエラーです', [$e->getMessage()]);
            
            return $this->json(['status' => 'NG'], 500);
            }
            
        return $this->json(array_merge(['status' => 'OK'], $result));
     
     }
     
    /**
     * updateNotAcceptMemberName
     *
     * @Route("/%eccube_admin_route%/shipping/{id}/update_paying_not_accept_member_name", requirements={"id" = "\d+"}, name="admin_shipping_update_paying_member_not_accept", methods={"PUT"})
     *
     * @param Request $request
     * @param Paying $Paying
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function updateNotAcceptMemberName(Request $request, Paying $Paying)
    {
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
          return $this->json(['status' => 'NG'], 400);
         }
         
        $result = []; 
        $Member = $this->getUser();    
       
        if($Paying->getMember() == null){
          $result = ['message' => trans('admin.paying.failed_to_change_not_accept_member_miss',[
             '%name%' => $Paying->getId(),
          ])];
           return $this->json(array_merge(['status' => 'OK'], $result)); 
        }
        
        try {
              
              if($Paying->getMember()->getName() == $Member->getName()){
                 $Paying->setMember(NULL);
                 $this->entityManager->flush($Paying);
              }else{
                 $from = $Paying->getMember()->getName();
                 $to = $Member->getName();
                 $result = ['message' => trans('admin.paying.failed_to_change_not_accept_member', [
                   '%name%' => $Paying->geId(),
                   '%from%' => $Paying->getMember()->getName(),
                   '%to%' => $Member->getName(),
                ])];
             
              }

            } catch (\Exception $e) {
             log_error('予期しないエラーです', [$e->getMessage()]);

            return $this->json(['status' => 'NG'], 500);
            }
            
        return $this->json(array_merge(['status' => 'OK'], $result));
     
     }
     
    private function setFirstPaymentDate($Paying)
    {
            //$this->entityManager->getFilters()->disable('incomplete_new_paying_status_hidden'); 
            // 初回振込
            $firstFurikomiOrder = $this->orderRepository->getFirstFurikomiOrder($Paying->getCustomer());
            if(null!= $firstFurikomiOrder){
            $Paying->setFirstFurikomiDate($firstFurikomiOrder->getPaymentDate());
            }
            // 初回書留
            $firstKakitomeOrder = $this->orderRepository->getFirstKakitomeOrder($Paying->getCustomer());
            if(null!= $firstKakitomeOrder){
            $Paying->setFirstKakitomeDate($firstKakitomeOrder->getPaymentDate());
            }  
            
            $this->entityManager->persist($Paying);
            $this->entityManager->flush(); 
    }
    
    // 仮会員の場合
    private function setNoneMemberFirstPaymentDate($Paying)
    {
            $Order = $this->orderRepository->getNoneMemberOrder($Paying);
            if($Order){
               if($Order->getPaymentMethod() == '銀行振込'){
                 // 初回振込
                 $Paying->setFirstFurikomiDate(new \DateTime());
                }
                if($Order->getPaymentMethod() == '現金書留'){
                $Paying->setFirstKakitomeDate(new \DateTime());
              }
            }
            $this->entityManager->persist($Paying);
            $this->entityManager->flush(); 
    }
    
    /**
     * getNotPendingOrderCount
     *
     * @Route("/%eccube_admin_route%/paying/get_order_count", requirements={"ids" = "\S+"}, name="admin_paying_get_not_pending_order_count", methods={"PUT"})
     *
     * @param Request $request
     * 
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getNotPendingOrderCount(Request $request)
    {
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
         }
         
        $result = []; 
        $ids = $request->get('ids');
        foreach( $ids as $id){
          $Paying = $this->payingRepository
                ->find($id);
          $isAllPendingFlag = $this->orderRepository
                ->getNotPendingOrderCount($Paying);
          if($isAllPendingFlag){
             ;
          }else{
             array_push($result, $id);
          }
        }
       $this->json($result);     
       return $this->json($result); 
    }

    private function sortPaying($payings, $searchData){
        
        if($searchData['sort_by']){
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case '会員番号':
                    usort($payings, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a['Customer']['Id'] > $b['Customer']['Id'] ? -1 : 1;
                        }
                        return $a['Customer']['Id'] < $b['Customer']['Id'] ? -1 : 1;
                    });
                    break;
                case '送金区分':
                    usort($payings, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getPayingPossible() > $b->getPayingPossible() ? -1 : 1;
                        }
                        return $a->getPayingPossible() < $b->getPayingPossible() ? -1 : 1;
                    });
                    break;
                case '来店場所':
                    usort($payings, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                          return $a->getPayingKaitoriTypeId() > $b->getPayingKaitoriTypeId() ? -1 : 1;
                        }
                        return $a->getPayingKaitoriTypeId() < $b->getPayingKaitoriTypeId() ? -1 : 1;
                    });
                    break;
                case '申込日':
                    usort($payings, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getPayingOrderDate() > $b->getPayingOrderDate() ? -1 : 1;
                        }
                        return $a->getPayingOrderDate() < $b->getPayingOrderDate() ? -1 : 1;
                    });
                    break;
                case '到着日':
                    usort($payings, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getPayingShippingDeliveryDate() > $b->getPayingShippingDeliveryDate() ? -1 : 1;
                        }
                        return $a->getPayingShippingDeliveryDate() < $b->getPayingShippingDeliveryDate() ? -1 : 1;
                    });
                    break;    
                case '書留未送金総金額':
                    usort($payings, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getKakitomeTotalPrice() > $b->getKakitomeTotalPrice() ? -1 : 1;
                        }
                        return $a->getKakitomeTotalPrice() < $b->getKakitomeTotalPrice() ? -1 : 1;
                    });
                    break;
            }
        }
        return $payings;
    }

    // INS-START CNC 2021/08/23
    /**
     * getWarningOrder
     *
     * @Route("/%eccube_admin_route%/order/post/delete", requirements={"id" = "\S+"}, name="admin_order_delete", methods={"PUT"})
     *
     * @param Request $request
     *
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function Delete(Request $request)
    {
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
        }

        $result = [];
        $payingId = $request->get('id');
        $customerId = $request->get('customerId');
        $changeState_warning_result = [];

        $OrderIds = $this->orderRepository->getNotPayOrderIds($payingId,$customerId );
        if(null != $OrderIds and count($OrderIds) > 0){
            foreach($OrderIds as $OrderId) {
                $Order = $this->orderRepository->find($OrderId);
                $orderNo = $Order->getOrderNo();
                /** @var SalesVoucherDetailLink $sales_voucher_detail_link */
                $sales_voucher_detail_link = $this->salesVoucherDetailLinkRepository->getList($orderNo);

                if (count($sales_voucher_detail_link) > 0) {
                    $result = ['message' => trans('admin.payment.failed_to_changeState', [
                        '%payingNo%' => $payingId,
                    ])];
                    array_push($changeState_warning_result, $result);
                }

            }
            return $this->json(array_merge(['changeState_warning' => $changeState_warning_result]));
        }
    }
    // INS-END CNC 2021/08/23

    /**
     * 売上ヘッダかどうか
     * @param PayeeVoucherHeader $entity_payee_voucher_header ヘッダー
     * @return bool
     */
    private function isSoldHeader(PayeeVoucherHeader $entity_payee_voucher_header)
    {
        if ($entity_payee_voucher_header) {
            $parameter = [
                'payeeVoucherHeader' => $entity_payee_voucher_header,
                'payeeVoucherNo' => $entity_payee_voucher_header->getPayeeVoucherNo(),
            ];
            $result = $this->salesVoucherDetailLinkRepository->count($parameter);
            return $result > 0;
        }
        return false;
    }

    /**
     *
     * @Route("/%eccube_admin_route%/payment/change_phone_number_paying", name="admin_change_phone_number_paying_status", methods={"POST"})
     *
     * @param Request $request Request
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function changePhoneNumberPayingStatus(Request $request)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()){
            $payingId = $request->get('id');
            $Member = $this->getUser();
//            $paying_item = $this->payingRepository->find($payingId);
//            $phoneNumber = $paying_item['phone_number'];
//            $entity_phone_number_pay = $this->phoneNumberPayRepository->getPhoneNumberData($phoneNumber);

            $orderList = $this->orderRepository->findOneBy(['Paying' => $payingId]);
            $order_no = $orderList->getOrderNo();
            $entity_phone_number_pay= $this->phoneNumberPayRepository->getPhoneNumberData($order_no);

            $flg = '';
            if ($entity_phone_number_pay) {

                if ($entity_phone_number_pay[0]->getPayKubun() === 0) {
                    $flg = '0';
                } else {
                    $flg = '1';
                }

                if ($flg === '1') {
                    $entity_phone_number_pay[0]->setPayKubun(0)
                        ->setUpdateUserName($Member);
                    $this->entityManager->persist($entity_phone_number_pay[0]);
                    $this->entityManager->flush();
                } elseif ($flg === '0') {
                    $entity_phone_number_pay[0]->setPayKubun(1)
                        ->setUpdateUserName($Member);
                    $this->entityManager->persist($entity_phone_number_pay[0]);
                    $this->entityManager->flush();
                }

            } else {
                $entity_phone_number_pay = (new PhoneNumberPay())
                    ->setPhoneNumber($order_no)
                    ->setPayKubun(0)
                    ->setCreateUserName($Member)
                    ->setUpdateUserName($Member);
                $this->entityManager->persist($entity_phone_number_pay);
                $this->entityManager->flush();
            }

            $data = ['change_success' => '0',];

        }else{
            $data = [
                'change_success' => '0',
            ];
        }
        return $this->json($data);
    }

}
