<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Payment;

use Eccube\Controller\AbstractController;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\PayeePaidBalanceDetailType;
use Eccube\Form\Type\Admin\PayeePaidBalanceType;
use Eccube\Form\Type\Admin\SearchPayeeMstType;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\MemberRepository;
use Eccube\Repository\PayeeMstRepository;
use Eccube\Repository\PayeePaidBalanceHistoryRepository;
use Eccube\Repository\PayeePaidBalanceRepository;
use Eccube\Util\FormUtil;
use Eccube\Util\StringUtil;
use Knp\Component\Pager\Paginator;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： DisbursementBalanceController.php
 *概　　要     ： 仕入出金残高
 *作　　成     ： 2021/8/10 CNC
 */
class DisbursementBalanceController extends AbstractController
{
    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;
    /**
     * @var PayeePaidBalanceRepository
     */
    protected $payeePaidBalanceRepository;

    /**
     * @var PayeePaidBalanceHistoryRepository
     */
    protected $payeePaidBalanceHistoryRepository;

    /**
     * @var PayeeMstRepository
     */
    protected $payeeMstRepository;

    /**
     * @var MemberRepository
     */
    protected $memberRepository;

    public function __construct(
        PageMaxRepository $pageMaxRepository,
        PayeePaidBalanceRepository $payeePaidBalanceRepository,
        PayeePaidBalanceHistoryRepository $payeePaidBalanceHistoryRepository,
        PayeeMstRepository $payeeMstRepository,
        MemberRepository $memberRepository
    ) {
        $this->pageMaxRepository = $pageMaxRepository;
        $this->payeePaidBalanceRepository = $payeePaidBalanceRepository;
        $this->payeePaidBalanceHistoryRepository = $payeePaidBalanceHistoryRepository;
        $this->payeeMstRepository = $payeeMstRepository;
        $this->memberRepository = $memberRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/payment/disbursement_balance", name="admin_payment_disbursement")
     * @Route("/%eccube_admin_route%/payment/disbursement_balance/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_payment_disbursement_page")
     * @Template("@admin/Payment/disbursement_balance.twig")
     *
     * @param Request $request
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function index(Request $request, $page_no = null, Paginator $paginator)
    {
        $session = $this->session;
        $builder = $this->formFactory
            ->createBuilder(PayeePaidBalanceType::class, null);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYMENT_PAYEE_PAID_BALANCE_INDEX_INITIALIZE, $event);

        $pageMaxis = $this->pageMaxRepository->findAll();
        $pageCount = $session->get('eccube.admin.payment.search.page_count', $this->eccubeConfig['eccube_default_page_count']);
        $pageCountParam = $request->get('page_count');
        if ($pageCountParam && is_numeric($pageCountParam)) {
            foreach ($pageMaxis as $pageMax) {
                if ($pageCountParam == $pageMax->getName()) {
                    $pageCount = $pageMax->getName();
                    $session->set('eccube.admin.payment.search.page_count', $pageCount);
                    break;
                }
            }
        }
        $form = $builder->getForm();

        // 仕入先検索フォーム
        $builder = $this->formFactory
            ->createBuilder(SearchPayeeMstType::class);
        $searchPayeeMstModalForm = $builder->getForm();

        $page_no_bk = $page_no;
        if ('POST' === $request->getMethod()) {
            $form->handleRequest($request);
            if ($form->isValid()) {
                $searchData = $form->getData();
                $page_no = 1;

                $session->set('eccube.admin.payment.search', FormUtil::getViewData($form));
                $session->set('eccube.admin.payment.search.page_no', $page_no);
            } else {
                return [
                    'form' => $form->createView(),
                    'searchPayeeMstModalForm' => $searchPayeeMstModalForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $pageCount,
                    'payeeMoneyTotalAmount' => 0,
                    'paidAmount' => 0,
                    'paidNotAmount' => 0,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                if ($page_no) {
                    $session->set('eccube.admin.payment.search.page_no', (int) $page_no);
                } else {
                    $page_no = $session->get('eccube.admin.payment.search.page_no', 1);
                }
                $viewData = $session->get('eccube.admin.payment.search', []);
            } else {
                $page_no = 1;
                $viewData = FormUtil::getViewData($form);
                $viewData["purchase_date_end"] =  date('Y-m-d', strtotime('now'));
                $viewData["purchase_date_start"] =  date('Y-m-d', strtotime('now'));
                $viewData["paid_amount_finished"] =  false;
                $viewData["paid_amount_unfinished"] =  true;
                $viewData["paid_amount_remain"] =  true;
                $session->set('eccube.admin.payment.search', $viewData);
                $session->set('eccube.admin.payment.search.page_no', $page_no);
            }
            $searchData = FormUtil::submitAndGetData($form, $viewData);
        }

        $qb = '';
        $all_orders = [];
        if ('POST' === $request->getMethod() || null !== $page_no_bk){
            /** @var QueryBuilder $qb */
            $qb = $this->payeePaidBalanceRepository->getQueryBuilderBySearchData($searchData);
            $all_orders = $qb->getQuery()->getResult();
        }
        $sort_orders = $this->sortOrder($all_orders, $searchData);

        $payeeMoneyTotalAmount = 0;
        $paidAmount = 0;
        $paidNotAmount = 0;
        foreach ($all_orders as $payee){
            $payeeMoneyTotalAmount = $payeeMoneyTotalAmount + $payee->getPayeeVoucherHeader()->getPayeeMoneyTotalAmount();
            $paidAmount = $paidAmount + $payee->getPaidAmount();
        }
        $paidNotAmount = $payeeMoneyTotalAmount - $paidAmount;

        $event = new EventArgs(
            [
                'form' => $form,
                'qb' => $qb,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PAYMENT_PAYEE_PAID_BALANCE_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $pageCount
        );

        $forms = [];
        foreach ($sort_orders as $EditTag) {
            $id = $EditTag->getId();
            $forms[$id] = $this
                ->formFactory
                ->createNamed('payeePaidBalance_'.$id, PayeePaidBalanceDetailType::class, $EditTag);
        }

        $formViews = [];
        foreach ($forms as $key => $value) {
            $formViews[$key] = $value->createView();
        }
        $totalItemCount = $pagination->getTotalItemCount();
        return [
            'form' => $form->createView(),
            'searchPayeeMstModalForm' => $searchPayeeMstModalForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $pageCount,
            'totalItemCount' => $totalItemCount,
            'payeeMoneyTotalAmount' => $payeeMoneyTotalAmount,
            'paidAmount' => $paidAmount,
            'paidNotAmount' => $paidNotAmount,
            'has_errors' => false,
            'forms' => $formViews,
        ];
    }

    private function sortOrder($orders, $searchData){
        if($searchData['sort_by']){
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case '伝票番号':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getPayeeVoucherNo() > $b->getPayeeVoucherNo() ? -1 : 1;
                        }
                        return $a->getPayeeVoucherNo() < $b->getPayeeVoucherNo() ? -1 : 1;
                    });
                    break;
                case '仕入先名':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getPayeeVoucherHeader()->getPayee()->getPayeeName() > $b->getPayeeVoucherHeader()->getPayee()->getPayeeName() ? -1 : 1;
                        }
                        return $a->getPayeeVoucherHeader()->getPayee()->getPayeeName() < $b->getPayeeVoucherHeader()->getPayee()->getPayeeName() ? -1 : 1;
                    });
                    break;
                case '仕入日':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getPayeeVoucherHeader()->getPurchaseDate()> $b->getPayeeVoucherHeader()->getPurchaseDate() ? -1 : 1;
                        }
                        return $a->getPayeeVoucherHeader()->getPurchaseDate() < $b->getPayeeVoucherHeader()->getPurchaseDate() ? -1 : 1;
                    });
                    break;
                case '合計金額':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getPayeeVoucherHeader()->getPayeeMoneyTotalAmount() > $b->getPayeeVoucherHeader()->getPayeeMoneyTotalAmount() ? -1 : 1;
                        }
                        return $a->getPayeeVoucherHeader()->getPayeeMoneyTotalAmount() < $b->getPayeeVoucherHeader()->getPayeeMoneyTotalAmount() ? -1 : 1;
                    });
                    break;
                case '出金日':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getPaidDate() > $b->getPaidDate() ? -1 : 1;
                        }
                        return $a->getPaidDate() < $b->getPaidDate() ? -1 : 1;
                    });
                    break;
            }
        }
        return $orders;
    }

    /**
     * Update to payAmount number.
     *
     * @Route("/%eccube_admin_route%/payment/disbursement_balance/{id}/update_payAmount", requirements={"id" = "\d+"}, name="admin_payment_disbursement_save", methods={"PUT"})
     *
     * @param Request $request
     *
     * @return Response
     */
    public function save(Request $request, $id)
    {
        $payeePaidBalance = $this->payeePaidBalanceRepository->find($id);

        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
        }

        try {
            $payeePaidBalanceHistoryOld = $this->payeePaidBalanceHistoryRepository->findOneBy(['payeeVoucherNo' => $payeePaidBalance->getPayeeVoucherNo()], ['revisionNo' => 'DESC']);

            if (StringUtil::isNotBlank($request->get('payAmount_number'))) {
                $payAmount_number = str_replace(",", "", $request->get('payAmount_number'));
                $paidAmount_number = $payeePaidBalance->getPaidAmount();
                $paidAmount = 0 + $paidAmount_number + $payAmount_number;
                $unpayAmount = $request->get('payeeMoneyTotalAmount') - $paidAmount;
            } else {
                $payAmount_number = $payeePaidBalanceHistoryOld->getUnpayAmount();
                $unpayAmount = 0;
                $paidAmount = $request->get('payeeMoneyTotalAmount');
            }

            $payeePaidBalance->setPaidAmount($paidAmount);
            $payeePaidBalance->setPaidDate(new \DateTime());
            $payeePaidBalance->setPayUserName($this->getUser()['name']);
            $payeePaidBalance->setUpdateUserName($this->getUser()['name']);

            // dtb_payee_paid_balance_history
            $payeePaidBalanceHistory = new \Eccube\Entity\PayeePaidBalanceHistory;
            $payeePaidBalanceHistory->setPayeeVoucherHeaderHistory($payeePaidBalanceHistoryOld->getPayeeVoucherHeaderHistory());
            $payeePaidBalanceHistory->setPayeeVoucherNo($payeePaidBalance->getPayeeVoucherNo());
            $payeePaidBalanceHistory->setTotalAmount($request->get('payeeMoneyTotalAmount'));
            $payeePaidBalanceHistory->setUnpayAmount($unpayAmount);
            $payeePaidBalanceHistory->setPaidAmount($paidAmount);
            $payeePaidBalanceHistory->setPayAmount($payAmount_number);
            $payeePaidBalanceHistory->setPayDate(new \DateTime());
            $payeePaidBalanceHistory->setPayUserName($this->getUser()['name']);
            $payeePaidBalanceHistory->setRevisionNo($payeePaidBalanceHistoryOld->getRevisionNo() + 1);
            $payeePaidBalanceHistory->setCreateUserName($this->getUser()['name']);
            $payeePaidBalanceHistory->setUpdateUserName($this->getUser()['name']);
            $this->entityManager->persist($payeePaidBalance);
            $this->entityManager->persist($payeePaidBalanceHistory);
            $this->entityManager->flush();
            $paidAmountSearch = $request->get('paidAmountSearch') + $payAmount_number;
            $paidNotAmountSearch = $request->get('payeeMoneyTotalAmountSearch') - $paidAmountSearch;
            $message = ['status' => 'OK',
                'unpayAmount' => $unpayAmount,
                'paidAmount' => $paidAmount,
                'payDate' => date('Y-m-d', strtotime('now')),
                'payUserName' => $this->getUser()['name'],
                'totalItemCountSearch' => $request->get('totalItemCountSearch'),
                'payeeMoneyTotalAmountSearch' => $request->get('payeeMoneyTotalAmountSearch'),
                'paidAmountSearch' => $paidAmountSearch,
                'paidNotAmountSearch' => $paidNotAmountSearch];
            return $this->json($message);
        } catch (\Exception $e) {
            log_error('予期しないエラー', [$e->getMessage()]);

            return $this->json(['status' => 'NG'], 500);
        }
    }
}
