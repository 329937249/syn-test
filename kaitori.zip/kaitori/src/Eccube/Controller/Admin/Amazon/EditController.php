<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Amazon;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Criteria;
use Eccube\Controller\AbstractController;
use Eccube\Entity\Master\CustomerStatus;
use Eccube\Entity\Master\PayingStatus;
use Eccube\Entity\Master\OrderItemType;
use Eccube\Entity\Master\OrderStatus;
use Eccube\Entity\Master\TaxType;
use Eccube\Entity\Master\BlackListType;
use Eccube\Entity\Master\PersionType;
use Eccube\Entity\Order;
use Eccube\Entity\Shipping;
use Eccube\Entity\CustomerCertsDoc;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Exception\ShoppingException;
use Eccube\Form\Type\AddCartType;
use Eccube\Form\Type\Admin\OrderType;
use Eccube\Form\Type\Admin\SearchCustomerType;
use Eccube\Form\Type\Admin\SearchProductType;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\CustomerRepository;
use Eccube\Repository\PayingRepository;
use Eccube\Repository\DeliveryRepository;
use Eccube\Repository\OrderOpehistRepository;
use Eccube\Repository\Master\DeviceTypeRepository;
use Eccube\Repository\Master\OrderItemTypeRepository;
use Eccube\Repository\Master\OrderStatusRepository;
use Eccube\Repository\Master\CertsDocRepository;
use Eccube\Repository\OrderRepository;
use Eccube\Repository\OrderItemCopyRepository;
use Eccube\Service\PurchaseFlow\ItemCollection;
use Eccube\Repository\ProductRepository;
use Eccube\Service\OrderHelper;
use Eccube\Service\OrderPdfService;
use Eccube\Service\OrderStateMachine;
use Eccube\Service\PurchaseFlow\Processor\OrderNoProcessor;
use Eccube\Service\PurchaseFlow\PurchaseContext;
use Eccube\Service\PurchaseFlow\PurchaseException;
use Eccube\Service\PurchaseFlow\PurchaseFlow;
use Eccube\Service\TaxRuleService;
use Knp\Component\Pager\Paginator;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Routing\RouterInterface;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

class EditController extends AbstractController
{
    /**
     * @var TaxRuleService
     */
    protected $taxRuleService;

    /**
     * @var DeviceTypeRepository
     */
    protected $deviceTypeRepository;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var CustomerRepository
     */
    protected $customerRepository;

    /**
     * @var PayingRepository
     */
    protected $payingRepository;

    /**
     * @var CertsDocRepository
     */
    protected $certsDocRepository;

    /**
     * @var Serializer
     */
    protected $serializer;

    /**
     * @var DeliveryRepository
     */
    protected $deliveryRepository;

    /**
     * @var OrderOpehistRepository
     */
    protected $orderOpehistRepository;

    /**
     * @var PurchaseFlow
     */
    protected $purchaseFlow;

    /**
     * @var OrderRepository
     */
    protected $orderRepository;

    /**
     * @var OrderItemCopyRepository
     */
    protected $orderItemCopyRepository;

    /**
     * @var OrderNoProcessor
     */
    protected $orderNoProcessor;

    /**
     * @var OrderItemTypeRepository
     */
    protected $orderItemTypeRepository;

    /**
     * @var OrderStateMachine
     */
    protected $orderStateMachine;

    /**
     * @var OrderStatusRepository
     */
    protected $orderStatusRepository;

    /**
     * @var OrderHelper
     */
    private $orderHelper;

    /**
     * @var OrderPdfService
     */
    private $orderPdfService;
    
    /**
     * EditController constructor.
     *
     * @param TaxRuleService $taxRuleService
     * @param DeviceTypeRepository $deviceTypeRepository
     * @param ProductRepository $productRepository
     * @param CategoryRepository $categoryRepository
     * @param CustomerRepository $customerRepository
     * @param PayingRepository $payingRepository
     * @param SerializerInterface $serializer
     * @param DeliveryRepository $deliveryRepository
     * @param OrderOpehistRepository $orderOpehistRepository
     * @param PurchaseFlow $orderPurchaseFlow
     * @param OrderRepository $orderRepository
     * @param CertsDocRepository $certsDocRepository
     * @param OrderItemCopyRepository $orderItemCopyRepository
     * @param OrderNoProcessor $orderNoProcessor
     * @param OrderItemTypeRepository $orderItemTypeRepository
     * @param OrderStatusRepository $orderStatusRepository
     * @param OrderStateMachine $orderStateMachine
     * @param OrderHelper $orderHelper
     * @param OrderPdfService $orderPdfService
     */
    public function __construct(
        TaxRuleService $taxRuleService,
        DeviceTypeRepository $deviceTypeRepository,
        ProductRepository $productRepository,
        CategoryRepository $categoryRepository,
        CustomerRepository $customerRepository,
        OrderOpehistRepository $orderOpehistRepository,
        PayingRepository $payingRepository,
        CertsDocRepository $certsDocRepository,
        SerializerInterface $serializer,
        DeliveryRepository $deliveryRepository,
        OrderItemCopyRepository $orderItemCopyRepository,
        PurchaseFlow $orderPurchaseFlow,
        OrderRepository $orderRepository,
        OrderNoProcessor $orderNoProcessor,
        OrderItemTypeRepository $orderItemTypeRepository,
        OrderStatusRepository $orderStatusRepository,
        OrderStateMachine $orderStateMachine,
        OrderHelper $orderHelper,
        OrderPdfService $orderPdfService
    ) {
        $this->taxRuleService = $taxRuleService;
        $this->deviceTypeRepository = $deviceTypeRepository;
        $this->productRepository = $productRepository;
        $this->categoryRepository = $categoryRepository;
        $this->customerRepository = $customerRepository;
        $this->payingRepository = $payingRepository;
        $this->serializer = $serializer;
        $this->deliveryRepository = $deliveryRepository;
        $this->orderOpehistRepository = $orderOpehistRepository;
        $this->purchaseFlow = $orderPurchaseFlow;
        $this->orderRepository = $orderRepository;
        $this->orderItemCopyRepository = $orderItemCopyRepository;
        $this->orderNoProcessor = $orderNoProcessor;
        $this->orderItemTypeRepository = $orderItemTypeRepository;
        $this->orderStatusRepository = $orderStatusRepository;
        $this->certsDocRepository = $certsDocRepository;
        $this->orderStateMachine = $orderStateMachine;
        $this->orderHelper = $orderHelper;
        $this->orderPdfService = $orderPdfService;
    }

    /**
     * Amazon 申込登録/編集画面.
     *
     * @Route("/%eccube_admin_route%/amazon/new", name="admin_amazon_new")
     * @Route("/%eccube_admin_route%/amazon/{id}/edit", requirements={"id" = "\d+"}, name="admin_amazon_edit")
     * @Template("@admin/Amazon/edit.twig")
     */
    public function index(Request $request, $id = null, RouterInterface $router)
    {

        $TargetOrder = null;
        $OriginOrder = null;
        $PersionCertDocName = null;
        $CorporationDocName = null;
        $OrderItemCopys = null;
        $is_customer_update = false;
        if (null === $id) {
            // 空のエンティティを作成.
            $TargetOrder = new Order();
            $TargetOrder->addShipping((new Shipping())->setOrder($TargetOrder));

            $preOrderId = $this->orderHelper->createPreOrderId();
            $TargetOrder->setPreOrderId($preOrderId);
        } else {
            $TargetOrder = $this->orderRepository->find($id);
            if (null === $TargetOrder) {
                throw new NotFoundHttpException();
            }

            // order_item_copy
            $OrderItemCopys = (new ItemCollection($this->orderItemCopyRepository->findBy(['Order' => $id])))->sort();

            // 個人の場合
            $PersonalCertsDoc = $TargetOrder->getPersonalDocFile();
            if ($PersonalCertsDoc) {
                $PersonalFile = $this->certsDocRepository
                    ->find($PersonalCertsDoc->getCertsDocId());
                if ($PersonalFile) {
                    $PersionCertDocName = $PersonalFile->getName();
                }
            }
            // 法人の場合
            $CorporationCertsDoc = $TargetOrder->getCorporationDocFile();
            if ($CorporationCertsDoc) {
                $CorporationFile = $this->certsDocRepository
                    ->find($CorporationCertsDoc->getCertsDocId());
                if ($CorporationFile) {
                    $CorporationDocName = $CorporationFile->getName();
                }
            }
        }

        // 編集前の受注情報を保持
        $OriginOrder = clone $TargetOrder;
        $OriginItems = new ArrayCollection();
        foreach ($TargetOrder->getOrderItems() as $Item) {
            $OriginItems->add($Item);
        }

        $builder = $this->formFactory->createBuilder(OrderType::class, $TargetOrder);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'OriginOrder' => $OriginOrder,
                'TargetOrder' => $TargetOrder,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ORDER_EDIT_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();

        $form->handleRequest($request);

        $purchaseContext = new PurchaseContext($OriginOrder, $OriginOrder->getCustomer());

        if ($form->isSubmitted() && $form->isValid()) {

            $event = new EventArgs(
                [
                    'builder' => $builder,
                    'OriginOrder' => $OriginOrder,
                    'TargetOrder' => $TargetOrder,
                    'PurchaseContext' => $purchaseContext,
                ],
                $request
            );

            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ORDER_EDIT_INDEX_PROGRESS, $event);

            $flowResult = $this->purchaseFlow->validate($TargetOrder, $purchaseContext);

            if ($flowResult->hasWarning()) {
                foreach ($flowResult->getWarning() as $warning) {
                    $this->addWarning($warning->getMessage(), 'admin');
                }
            }

            if ($flowResult->hasError()) {
                foreach ($flowResult->getErrors() as $error) {
                    $this->addError($error->getMessage(), 'admin');
                }
            }

            // 登録ボタン押下
            switch ($request->get('mode')) {
                case 'register':
                    log_info('受注登録開始', [$TargetOrder->getId()]);
                    if (!$flowResult->hasError() && $form->isValid()) {
                        try {
                            $this->purchaseFlow->prepare($TargetOrder, $purchaseContext);
                            $this->purchaseFlow->commit($TargetOrder, $purchaseContext);
                        } catch (PurchaseException $e) {
                            $this->addError($e->getMessage(), 'admin');
                            break;
                        }
                        // 登録前のステータスを保持
                        $TargetOrder->setOrderStatus($OriginOrder->getOrderStatus());
                        $Customer = $TargetOrder->getCustomer();
                        if (null != $Customer && $TargetOrder->getPaymentMethod() != '現金払い' && null == $TargetOrder->getPaying()) {
                                $customerId = $Customer->getId();
                                // 送金履歴がない場合-> 新規送金
                                // 該当会員の初回振込を取得する
                                $firstFurikomiOrder = $this->orderRepository->getFirstFurikomiOrder($customerId);
                                // 該当会員の初回書留を取得する
                                $firstKakitomeOrder = $this->orderRepository->getFirstKakitomeOrder($customerId);
                                $Paying = $this->orderHelper->createPayingFromCustomer($TargetOrder, $firstFurikomiOrder, $firstKakitomeOrder);
                                $TargetOrder->setPaying($Paying);
                        }

                        // 非会員 直接登録 現金払い以外の場合 
                        if (null == $Customer && $TargetOrder->getPaymentMethod() != '現金払い' && null == $TargetOrder->getPaying()) {
                            $Paying = $this->orderHelper->createPayingFromOrder($TargetOrder);
                            // 更新Order
                            $this->orderHelper->updateOrder($Paying, $TargetOrder);
                        }

                        // 会員 非会員 現金払い
                        if ($TargetOrder->getPaymentMethod() == '現金払い') {
                            $TargetOrder->setPaying(null);
                        }

                        // 個人の場合 会社情報クリア
                        if ($TargetOrder->getPersionType()->getId() == PersionType::PERSION) {
                            $TargetOrder->setCompanyName(null);
                            $TargetOrder->setCompanyPostalCode(null);
                            $TargetOrder->setCompanyPref(null);
                            $TargetOrder->setCompanyAddr01(null);
                            $TargetOrder->setCompanyAddr02(null);
                            $TargetOrder->setCompanyPhoneNumber(null);
                        }

                        // 生年月日を更新する
                        $birth = $request->get('order')['birth'];
                        $TargetOrder->setBirth(new \DateTime($birth));

                        // note
                        if ($TargetOrder->getNote() && ($TargetOrder->getOrderStatus()->getId() == OrderStatus::NEW || $TargetOrder->getOrderStatus()->getId() == OrderStatus::RETURNED)) {
                            if ($TargetOrder->getCustomer()) {
                                $mypage_url = $this->generateUrl('mypage_history', ['id' => $TargetOrder->getId()], UrlGeneratorInterface::ABSOLUTE_URL);
                                $new_note = str_replace('「URL」', $mypage_url, $TargetOrder->getNote());
                                $TargetOrder->setNote($new_note);
                            }
                        }

                        // 会員メモを更新する
                        if (null != $Customer && !empty($request->get('admin_customer_note'))) {
                            $Customer->setNote($request->get('admin_customer_note'));
                            $this->entityManager->flush($Customer);
                        }
                        // 登録前のステータスを保持
                        $TargetOrder->setOrderStatus($OriginOrder->getOrderStatus());
                        $this->entityManager->persist($TargetOrder);

                        $this->entityManager->flush();

                        foreach ($OriginItems as $Item) {
                            if ($TargetOrder->getOrderItems()->contains($Item) === false) {
                                $this->entityManager->remove($Item);
                            }
                        }
                        $this->entityManager->flush();

                        // 新規登録時はMySQL対応のためflushしてから採番
                        $this->orderNoProcessor->process($TargetOrder, $purchaseContext);
                        $this->entityManager->flush();

                        $event = new EventArgs(
                            [
                                'form' => $form,
                                'OriginOrder' => $OriginOrder,
                                'TargetOrder' => $TargetOrder,
                                'Customer' => $TargetOrder->getCustomer(),
                            ],
                            $request
                        );
                        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ORDER_EDIT_INDEX_COMPLETE, $event);

                        $this->addSuccess('admin.common.save_complete', 'admin');

                        log_info('申込登録完了', [$TargetOrder->getId()]);

                        if ($returnLink = $form->get('return_link')->getData()) {
                            try {
                                // $returnLinkはpathの形式で渡される. pathが存在するかをルータでチェックする.
                                $pattern = '/^' . preg_quote($request->getBasePath(), '/') . '/';
                                $returnLink = preg_replace($pattern, '', $returnLink);
                                $result = $router->match($returnLink);
                                // パラメータのみ抽出
                                $params = array_filter($result, function ($key) {
                                    return 0 !== \strpos($key, '_');
                                }, ARRAY_FILTER_USE_KEY);

                                // pathからurlを再構築してリダイレクト.
                                return $this->redirectToRoute($result['_route'], $params);
                            } catch (\Exception $e) {
                                // マッチしない場合はログ出力してスキップ.
                                log_warning('URLの形式が不正です。');
                            }
                        }
                        $this->orderOpehistRepository->insertOrderOpehist($TargetOrder, $this->getUser(), '申込情報変更');

                        return $this->redirectToRoute('admin_amazon_edit', ['id' => $TargetOrder->getId()]);
                    }

                    break;
                case 'doc_verify_confirm':
                    $TargetOrder->setModifiedVerified(true);
                    if ($TargetOrder->getPersonalDocFile()) {
                        $TargetOrder->getPersonalDocFile()->setModifiedVerified(true);
                    }
                    if ($TargetOrder->getCorporationDocFile()) {
                        $TargetOrder->getCorporationDocFile()->setModifiedVerified(true);
                    }
                    //「書類対応」２.1、承認　ModifiedFlg＝false ModifiedVerified=true
                    if ($TargetOrder->getCustomer()) {
                        if ($TargetOrder->getCustomer()->getPersonalDocFile()) {
                            $TargetOrder->getCustomer()->getPersonalDocFile()->setModifiedVerified(true);
                            $TargetOrder->getCustomer()->getPersonalDocFile()->setModifiedFlg(false);
                            $this->entityManager->persist($TargetOrder->getCustomer()->getPersonalDocFile());
                            $this->entityManager->flush();
                        }
                        if ($TargetOrder->getCustomer()->getCorporationDocFile()) {
                            $TargetOrder->getCustomer()->getCorporationDocFile()->setModifiedVerified(true);
                            $TargetOrder->getCustomer()->getCorporationDocFile()->setModifiedFlg(false);
                            $this->entityManager->persist($TargetOrder->getCustomer()->getCorporationDocFile());
                            $this->entityManager->flush();
                        }
                        $TargetOrder->getCustomer()->setModifiedVerified(true);
                        $this->entityManager->persist($TargetOrder->getCustomer());
                        $this->entityManager->flush();
                    }
                    // 登録前のステータスを保持
                    $TargetOrder->setOrderStatus($OriginOrder->getOrderStatus());
                    $this->entityManager->persist($TargetOrder);
                    $this->entityManager->flush();
                    $this->orderOpehistRepository->insertOrderOpehist($TargetOrder, $this->getUser(), '書類確認済み');
                    break;
                case 'doc_verify_cancel':
                    $TargetOrder->setModifiedVerified(false);
                    if ($TargetOrder->getPersonalDocFile()) {
                        $TargetOrder->getPersonalDocFile()->setModifiedVerified(false);
                    }
                    if ($TargetOrder->getCorporationDocFile()) {
                        $TargetOrder->getCorporationDocFile()->setModifiedVerified(false);
                    }
                    //「書類対応」２.２、非承認　ModifiedVerified=false
                    if ($TargetOrder->getCustomer()) {
                        if ($TargetOrder->getCustomer()->getPersonalDocFile()) {
                            $TargetOrder->getCustomer()->getPersonalDocFile()->setModifiedVerified(false);
                            $this->entityManager->persist($TargetOrder->getCustomer()->getPersonalDocFile());
                            $this->entityManager->flush();
                        }
                        if ($TargetOrder->getCustomer()->getCorporationDocFile()) {
                            $TargetOrder->getCustomer()->getCorporationDocFile()->setModifiedVerified(false);
                            $this->entityManager->persist($TargetOrder->getCustomer()->getCorporationDocFile());
                            $this->entityManager->flush();
                        }
                        $TargetOrder->getCustomer()->setModifiedVerified(false);
                        $this->entityManager->persist($TargetOrder->getCustomer());
                        $this->entityManager->flush();
                    }
                    // 登録前のステータスを保持
                    $TargetOrder->setOrderStatus($OriginOrder->getOrderStatus());
                    $this->entityManager->persist($TargetOrder);
                    $this->entityManager->flush();
                    $this->orderOpehistRepository->insertOrderOpehist($TargetOrder, $this->getUser(), '書類確認取消');
                    break;
                case 'update_personal':
                    $personalDocFile = $this->copyDocFromCustomer($TargetOrder->getCustomer()->getPersonalDocFile(), $TargetOrder->getPersonalDocFile());
                    $TargetOrder->setPersonalDocFile($personalDocFile);
                    $corporationDocFile = $this->copyDocFromCustomer($TargetOrder->getCustomer()->getCorporationDocFile(), $TargetOrder->getCorporationDocFile());
                    $TargetOrder->setCorporationDocFile($corporationDocFile);
                    // 登録前のステータスを保持
                    $TargetOrder->setOrderStatus($OriginOrder->getOrderStatus());
                    $this->entityManager->persist($TargetOrder);
                    $this->entityManager->flush();
                    $this->orderOpehistRepository->insertOrderOpehist($TargetOrder, $this->getUser(), '書類更新');
                    break;
                default:
                    // 登録前のステータスを保持
                    $TargetOrder->setOrderStatus($OriginOrder->getOrderStatus());
                    break;
            }
        }
        if ($form->isSubmitted() && $request->get('mode') == 'customer_info_update') {
            $event = new EventArgs(
                [
                    'builder' => $builder,
                    'OriginOrder' => $OriginOrder,
                    'TargetOrder' => $TargetOrder,
                    'PurchaseContext' => $purchaseContext,
                ],
                $request
            );

            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ORDER_EDIT_INDEX_PROGRESS, $event);

            $flowResult = $this->purchaseFlow->validate($TargetOrder, $purchaseContext);

            if ($flowResult->hasWarning()) {
                foreach ($flowResult->getWarning() as $warning) {
                    $this->addWarning($warning->getMessage(), 'admin');
                }
            }

            if ($flowResult->hasError()) {
                foreach ($flowResult->getErrors() as $error) {
                    $this->addError($error->getMessage(), 'admin');
                }
            }
            $TargetOrder = $this->updateOrderInfoByCustomer($TargetOrder);
            // 登録前のステータスを保持
            $TargetOrder->setOrderStatus($OriginOrder->getOrderStatus());
            $this->entityManager->persist($TargetOrder);
            $this->entityManager->flush();
            $is_customer_update = true;
        }

        // 会員検索フォーム
        $builder = $this->formFactory
            ->createBuilder(SearchCustomerType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'OriginOrder' => $OriginOrder,
                'TargetOrder' => $TargetOrder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ORDER_EDIT_SEARCH_CUSTOMER_INITIALIZE, $event);

        $searchCustomerModalForm = $builder->getForm();

        // 商品検索フォーム
        $builder = $this->formFactory
            ->createBuilder(SearchProductType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'OriginOrder' => $OriginOrder,
                'TargetOrder' => $TargetOrder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ORDER_EDIT_SEARCH_PRODUCT_INITIALIZE, $event);

        $searchProductModalForm = $builder->getForm();

        // 配送業者のお届け時間
        $times = [];
        $deliveries = $this->deliveryRepository->findAll();
        foreach ($deliveries as $Delivery) {
            $deliveryTimes = $Delivery->getDeliveryTimes();
            foreach ($deliveryTimes as $DeliveryTime) {
                $times[$Delivery->getId()][$DeliveryTime->getId()] = $DeliveryTime->getDeliveryTime();
            }
        }

        // 操作履歴
        $orderOpehistHistories = $this->orderOpehistRepository->findBy(['Order' => $TargetOrder]);

        // 差分
        $compare_result = $this->orderHelper->compareOrderItem($form['OrderItems']->getData(), $OrderItemCopys);

        $aduit_result_type = is_null($TargetOrder->getFixedPhrase()) ? '2' : ($TargetOrder->getFixedPhrase()->getAuditResult() == true ? '1' : '0');
        $use_type = is_null($TargetOrder->getFixedPhrase()) ? '2' : ($TargetOrder->getFixedPhrase()->getUseType() == true ? '1' : '0');

        $jpyear = null;
        if($TargetOrder->getBirth() ){
            $jpDate = $this->orderPdfService->chgAdToJpDate($TargetOrder->getBirth()->format('Y/m/d'));
            $jpyear = explode('年', $jpDate)[0];
        }

        return [
            'form' => $form->createView(),
            'searchCustomerModalForm' => $searchCustomerModalForm->createView(),
            'searchProductModalForm' => $searchProductModalForm->createView(),
            'Order' => $TargetOrder,
            'aduit_result_type' => $aduit_result_type,
            'use_type' => $use_type,
            'id' => $id,
            'shippingDeliveryTimes' => $this->serializer->serialize($times, 'json'),
            'PersionCertDocName' => $PersionCertDocName,
            'CorporationDocName' => $CorporationDocName,
            'OrderOpehistHistories' => $orderOpehistHistories,
            'Customer' => is_null($TargetOrder) ? null : $TargetOrder->getCustomer(),
            'refuse' => BlackListType::REFUSE,
            'warning' => BlackListType::WARNING,
            'new' => OrderStatus::NEW,
            'wait' => OrderStatus::WAIT,
            'stock' => OrderStatus::RETURNED,
            'pending' => OrderStatus::PENDING,
            'OrderItemCopys' => $OrderItemCopys,
            'compare_result' => $compare_result,
            'jpyear' => $jpyear,
            'is_customer_update' => $is_customer_update
        ];
    }

    /**
     * 顧客情報を検索する.
     *
     * @Route("/%eccube_admin_route%/order/search/customer/html", name="admin_order_amazon_search_customer_html")
     * @Route("/%eccube_admin_route%/order/search/customer/html/page/{page_no}", requirements={"page_No" = "\d+"}, name="admin_order_amazon_search_customer_html_page")
     * @Template("@admin/Order/search_customer.twig")
     *
     * @param Request $request
     * @param integer $page_no
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchCustomerHtml(Request $request, $page_no = null, Paginator $paginator)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('search customer start.');
            $page_count = $this->eccubeConfig['eccube_default_page_count'];
            $session = $this->session;

            if ('POST' === $request->getMethod()) {
                $page_no = 1;

                $searchData = [
                    'multi' => $request->get('search_word'),
                    'customer_status' => [
                        CustomerStatus::REGULAR,
                    ],
                ];

                $session->set('eccube.admin.order.customer.search', $searchData);
                $session->set('eccube.admin.order.customer.search.page_no', $page_no);
            } else {
                $searchData = (array) $session->get('eccube.admin.order.customer.search');
                if (is_null($page_no)) {
                    $page_no = intval($session->get('eccube.admin.order.customer.search.page_no'));
                } else {
                    $session->set('eccube.admin.order.customer.search.page_no', $page_no);
                }
            }

            $qb = $this->customerRepository->getQueryBuilderBySearchData($searchData);

            $event = new EventArgs(
                [
                    'qb' => $qb,
                    'data' => $searchData,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ORDER_EDIT_SEARCH_CUSTOMER_SEARCH, $event);

            /** @var \Knp\Component\Pager\Pagination\SlidingPagination $pagination */
            $pagination = $paginator->paginate(
                $qb,
                $page_no,
                $page_count,
                ['wrap-queries' => true]
            );

            /** @var $Customers \Eccube\Entity\Customer[] */
            $Customers = $pagination->getItems();

            if (empty($Customers)) {
                log_debug('search customer not found.');
            }

            $data = [];
            $formatName = '%s%s(%s%s)';
            foreach ($Customers as $Customer) {
                $data[] = [
                    'id' => $Customer->getId(),
                    'name' => sprintf(
                        $formatName,
                        $Customer->getName01(),
                        $Customer->getName02(),
                        $Customer->getKana01(),
                        $Customer->getKana02()
                    ),
                    'phone_number' => $Customer->getPhoneNumber(),
                    'email' => $Customer->getEmail(),
                ];
            }

            $event = new EventArgs(
                [
                    'data' => $data,
                    'Customers' => $pagination,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ORDER_EDIT_SEARCH_CUSTOMER_COMPLETE, $event);
            $data = $event->getArgument('data');

            return [
                'data' => $data,
                'pagination' => $pagination,
            ];
        }
    }

    /**
     * 顧客情報を検索する.
     *
     * @Route("/%eccube_admin_route%/order/amazon/search/customer/id", name="admin_amazon_order_search_customer_by_id", methods={"POST"})
     *
     * @param Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchCustomerById(Request $request)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('search customer by id start.');

            /** @var $Customer \Eccube\Entity\Customer */
            $Customer = $this->customerRepository
                ->find($request->get('id'));

            $event = new EventArgs(
                [
                    'Customer' => $Customer,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ORDER_EDIT_SEARCH_CUSTOMER_BY_ID_INITIALIZE, $event);

            if (is_null($Customer)) {
                log_debug('search customer by id not found.');

                return $this->json([], 404);
            }

            log_debug('search customer by id found.');

            $data = [
                'id' => $Customer->getId(),
                'name01' => $Customer->getName01(),
                'name02' => $Customer->getName02(),
                'kana01' => $Customer->getKana01(),
                'kana02' => $Customer->getKana02(),
                'postal_code' => $Customer->getPostalCode(),
                'pref' => is_null($Customer->getPref()) ? null : $Customer->getPref()->getId(),
                'addr01' => $Customer->getAddr01(),
                'addr02' => $Customer->getAddr02(),
                'email' => $Customer->getEmail(),
                'phone_number' => $Customer->getPhoneNumber(),
                'company_name' => $Customer->getCompanyName(),
            ];

            $event = new EventArgs(
                [
                    'data' => $data,
                    'Customer' => $Customer,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ORDER_EDIT_SEARCH_CUSTOMER_BY_ID_COMPLETE, $event);
            $data = $event->getArgument('data');

            return $this->json($data);
        }
    }

    /**
     * @Route("/%eccube_admin_route%/amazon/search/product", name="admin_amazon_search_product")
     * @Route("/%eccube_admin_route%/amazon/search/product/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_amazon_search_product_page")
     * @Template("@admin/Order/search_product.twig")
     */
    public function searchProduct(Request $request, $page_no = null, Paginator $paginator)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('search product start.');
            $page_count = $this->eccubeConfig['eccube_default_page_count'];
            $session = $this->session;

            if ('POST' === $request->getMethod()) {
                $page_no = 1;

                $searchData = [
                    'id' => $request->get('id'),
                ];

                if ($categoryId = $request->get('category_id')) {
                    $Category = $this->categoryRepository->find($categoryId);
                    $searchData['category_id'] = $Category;
                }

                $session->set('eccube.admin.order.product.search', $searchData);
                $session->set('eccube.admin.order.product.search.page_no', $page_no);
            } else {
                $searchData = (array) $session->get('eccube.admin.order.product.search');
                if (is_null($page_no)) {
                    $page_no = intval($session->get('eccube.admin.order.product.search.page_no'));
                } else {
                    $session->set('eccube.admin.order.product.search.page_no', $page_no);
                }
            }

            $qb = $this->productRepository
                ->getQueryBuilderBySearchDataForAdmin($searchData);

            $event = new EventArgs(
                [
                    'qb' => $qb,
                    'searchData' => $searchData,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ORDER_EDIT_SEARCH_PRODUCT_SEARCH, $event);

            /** @var \Knp\Component\Pager\Pagination\SlidingPagination $pagination */
            $pagination = $paginator->paginate(
                $qb,
                $page_no,
                $page_count,
                ['wrap-queries' => true]
            );

            /** @var $Products \Eccube\Entity\Product[] */
            $Products = $pagination->getItems();

            if (empty($Products)) {
                log_debug('search product not found.');
            }

            $forms = [];

            foreach ($Products as $Product) {

                /* @var $builder \Symfony\Component\Form\FormBuilderInterface */
                $builder = $this->formFactory->createNamedBuilder('', AddCartType::class, null, [
                    'product' => $this->productRepository->findWithSortedClassCategories($Product->getId()),
                ]);

                $addCartForm = $builder->getForm();
                $forms[$Product->getId()] = $addCartForm->createView();
            }

            $event = new EventArgs(
                [
                    'forms' => $forms,
                    'Products' => $Products,
                    'pagination' => $pagination,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ORDER_EDIT_SEARCH_PRODUCT_COMPLETE, $event);

            return [
                'forms' => $forms,
                'Products' => $Products,
                'pagination' => $pagination,
            ];
        }
    }

    /**
     * その他明細情報を取得
     *
     * @Route("/%eccube_admin_route%/order/search/order_item_type", name="admin_order_search_order_item_type")
     * @Template("@admin/Order/order_item_type.twig")
     *
     * @param Request $request
     *
     * @return array
     */
    public function searchOrderItemType(Request $request)
    {

        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('search order item type start.');

            $Charge = $this->entityManager->find(OrderItemType::class, OrderItemType::CHARGE);
            $DeliveryFee = $this->entityManager->find(OrderItemType::class, OrderItemType::DELIVERY_FEE);
            $Discount = $this->entityManager->find(OrderItemType::class, OrderItemType::DISCOUNT);

            $NonTaxable = $this->entityManager->find(TaxType::class, TaxType::NON_TAXABLE);
            $Taxation = $this->entityManager->find(TaxType::class, TaxType::TAXATION);

            $OrderItemTypes = [
                ['OrderItemType' => $Charge, 'TaxType' => $Taxation],
                ['OrderItemType' => $DeliveryFee, 'TaxType' => $Taxation],
                ['OrderItemType' => $Discount, 'TaxType' => $Taxation],
                ['OrderItemType' => $Discount, 'TaxType' => $NonTaxable]
            ];

            return [
                'OrderItemTypes' => $OrderItemTypes,
            ];
        }
    }

    private function updateOrderInfoByCustomer(Order $Order)
    {
        $Customer = $Order->getCustomer();
        $Order
            ->setName01($Customer->getName01())
            ->setName02($Customer->getName02())
            ->setBirth($Customer->getBirth())
            ->setKana01($Customer->getKana01())
            ->setKana02($Customer->getKana02())
            ->setCompanyName($Customer->getCompanyName())
            ->setCompanyNameKana($Customer->getCompanyNameKana())
            ->setEmail($Customer->getEmail())
            ->setJob($Customer->getJob())
            ->setPhoneNumber($Customer->getPhoneNumber())
            ->setPostalCode($Customer->getPostalCode())
            ->setPref($Customer->getPref())
            ->setAddr01($Customer->getAddr01())
            ->setAddr02($Customer->getAddr02())
            ->setAccountNo($Customer->getAccountNo())
            ->setAccountName($Customer->getAccountName())
            ->setAccountType($Customer->getAccountType())
            ->setAccountBank($Customer->getAccountBank())
            ->setAccountBranch($Customer->getAccountBranch())
            ->setCompanyAddr02($Customer->getCompanyAddr02())
            ->setCompanyAddr01($Customer->getCompanyAddr01())
            ->setCompanyPref($Customer->getCompanyPref())
            ->setCompanyPostalCode($Customer->getCompanyPostalCode())
            ->setCompanyPhoneNumber($Customer->getCompanyPhoneNumber());

        return $Order;
    }

    /**
     * @param CustomerCertsDoc $docSrc
     * @param CustomerCertsDoc $docDest
     *
     * @return null|CustomerCertsDoc
     */
    private function copyDocFromCustomer(CustomerCertsDoc $docSrc=null, CustomerCertsDoc $docDest=null){
        if($docSrc==null){
            return null;
        }
        if($docDest == null){
            $docDest = new CustomerCertsDoc();
        }
        $docDest->setCustomerId($docSrc->getCustomerId());
        $docDest->setCertsDocId($docSrc->getCertsDocId());
        $docDest->setValidDate($docSrc->getValidDate());
        $docDest->setVisible($docSrc->getVisible());
        if($docSrc->getPicture1()){
            $stream1 = stream_get_contents($docSrc->getPicture1());
            $docDest->setPicture1($stream1);
        }else{
            $docDest->setPicture1(null);
        }
        if($docSrc->getPicture2()){
            $stream2 = stream_get_contents($docSrc->getPicture2());
            $docDest->setPicture2($stream2);
        }else{
            $docDest->setPicture2(null);
        }
        if($docSrc->getPicture3()){
            $stream3 = stream_get_contents($docSrc->getPicture3());
            $docDest->setPicture3($stream3);
        }else{
            $docDest->getPicture3(null);
        }
        if($docSrc->getPicture4()){
            $stream4 = stream_get_contents($docSrc->getPicture4());
            $docDest->setPicture4($stream4);
        }else{
            $docDest->getPicture4(null);
        }
        if($docSrc->getPicture5()){
            $stream5 = stream_get_contents($docSrc->getPicture5());
            $docDest->setPicture5($stream5);
        }else{
            $docDest->getPicture5(null);
        }
        if($docSrc->getPicture6()){
            $stream6 = stream_get_contents($docSrc->getPicture6());
            $docDest->setPicture6($stream6);
        }else{
            $docDest->getPicture6(null);
        }
        if($docSrc->getPicture7()){
            $stream7 = stream_get_contents($docSrc->getPicture7());
            $docDest->setPicture7($stream7);
        }else{
            $docDest->getPicture7(null);
        }
        if($docSrc->getPicture8()){
            $stream8 = stream_get_contents($docSrc->getPicture8());
            $docDest->setPicture8($stream8);
        }else{
            $docDest->getPicture8(null);
        }
        if($docSrc->getPicture9()){
            $stream9 = stream_get_contents($docSrc->getPicture9());
            $docDest->setPicture9($stream9);
        }else{
            $docDest->getPicture9(null);
        }
        $docDest->setExtension1($docSrc->getExtension1());
        $docDest->setExtension2($docSrc->getExtension2());
        $docDest->setExtension3($docSrc->getExtension3());
        $docDest->setExtension4($docSrc->getExtension4());
        $docDest->setExtension5($docSrc->getExtension5());
        $docDest->setExtension6($docSrc->getExtension6());
        $docDest->setExtension7($docSrc->getExtension7());
        $docDest->setExtension8($docSrc->getExtension8());
        $docDest->setExtension9($docSrc->getExtension9());
        return $docDest;
    }
}
