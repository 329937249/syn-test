<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Content;

use Eccube\Controller\AbstractController;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\ContentTemplateType;
use Eccube\Entity\Master\ContentTemplate;
use Eccube\Repository\Master\ContentTemplateRepository;
use Eccube\Util\CacheUtil;
use Knp\Component\Pager\Paginator;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\JsonResponse;

class TemplateController extends AbstractController
{
    /**
     * @var ContentTemplateRepository
     */
    protected $templateRepository;

    /**
     * TemplateController constructor.
     *
     * @param ContentTemplateRepository $templateRepository
     */
    public function __construct(ContentTemplateRepository $templateRepository)
    {
        $this->templateRepository = $templateRepository;
    }

    /**
     * 定型文一覧を表示する。
     *
     * @Route("/%eccube_admin_route%/setting/shop/template", name="admin_content_template")
     * @Route("/%eccube_admin_route%/setting/shop/template/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_content_template_page")
     * @Template("@admin/Content/template.twig")
     *
     * @param Request $request
     * @param int $page_no
     * @param Paginator $paginator
     *
     * @return array
     */
    public function index(Request $request, $page_no = 1, Paginator $paginator)
    {
        $qb = $this->templateRepository->findBy(array(), array('sort_no' => 'ASC'));

        $event = new EventArgs(
            [
                'qb' => $qb,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_CONTENT_TEMPLATE_INDEX_INITIALIZE, $event);

        $pagination = $paginator->paginate(
            $qb,
            $page_no,
            $this->eccubeConfig->get('eccube_default_page_count')
        );

        return [
            'pagination' => $pagination,
        ];
    }

    /**
     * 定型文を登録・編集する。
     *
     * @Route("/%eccube_admin_route%/setting/shop/template/new", name="admin_content_template_new")
     * @Route("/%eccube_admin_route%/setting/shop/template/{id}/edit", requirements={"id" = "\d+"}, name="admin_content_template_edit")
     * @Template("@admin/Content/template_edit.twig")
     *
     * @param Request $request
     * @param null $id
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function edit(Request $request, $id = null, CacheUtil $cacheUtil)
    {
        if ($id) {
            $Template = $this->templateRepository->find($id);
            if (!$Template) {
                throw new NotFoundHttpException();
            }
        } else {
            $Template = new ContentTemplate();
        }

        $builder = $this->formFactory
            ->createBuilder(ContentTemplateType::class, $Template);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'template' => $Template,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_CONTENT_TEMPLATE_EDIT_INITIALIZE, $event);

        $form = $builder->getForm();
        $form->handleRequest($request);
       
        if ($form->isSubmitted() && $form->isValid()) {
            $params = $request->get('admin_contact');
           
            $is_contact_mail = is_null($params) ? null : (array_key_exists('is_contact_mail', $params) ? $params['is_contact_mail'] : false);
            $Template->setContactMail($is_contact_mail);
          
            $audit_result = is_null($params) ? null : (array_key_exists('audit_result', $params) ? $params['audit_result'] : false);
            $Template->setAuditResult($audit_result);
            
            $use_type = is_null($params) ? null : (array_key_exists('use_type', $params) ? $params['use_type'] : false);
            $Template->setUseType($use_type);
            
            $this->templateRepository->save($Template);

            $event = new EventArgs(
                [
                    'form' => $form,
                    'template' => $Template,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_CONTENT_TEMPLATE_EDIT_COMPLETE, $event);

            $this->addSuccess('admin.common.save_complete', 'admin');

            // キャッシュの削除
            $cacheUtil->clearDoctrineCache();

            return $this->redirectToRoute('admin_content_template_edit', ['id' => $Template->getId()]);
        }
        
        $mail_contact_type = is_null($Template->getId()) ? '1' : ($Template->isContactMail() == true ? '1' : '0');
        $aduit_result_type = is_null($Template->getId()) ? '2' : ($Template->getAuditResult() == true ? '1' : '0');
        $use_type = is_null($Template->getId()) ? '2' : ($Template->getUseType() == true ? '1' : '0');
        
        return [
            'form' => $form->createView(),
            'template' => $Template,
            'mail_contact_type' => $mail_contact_type,
            'aduit_result_type' => $aduit_result_type,
            'use_type' => $use_type,
        ];
    }

    /**
     * 指定した定型文を削除する。
     *
     * @Route("/%eccube_admin_route%/setting/shop/template/{id}/delete", requirements={"id" = "\d+"}, name="admin_content_template_delete", methods={"DELETE"})
     *
     * @param Request $request
     * @param ContentTemplate $ContentTemplate
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function delete(Request $request, ContentTemplate $ContentTemplate, CacheUtil $cacheUtil)
    {
        $this->isTokenValid();

        log_info('定型文削除開始', [$ContentTemplate->getId()]);

        try {
            $this->templateRepository->delete($ContentTemplate);

            $event = new EventArgs(['ContentTemplate' => $ContentTemplate], $request);
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_CONTENT_TEMPLATE_DELETE_COMPLETE, $event);

            $this->addSuccess('admin.common.delete_complete', 'admin');

            log_info('定型文削除完了', [$ContentTemplate->getId()]);

            // キャッシュの削除
            $cacheUtil->clearDoctrineCache();
        } catch (\Exception $e) {
            $message = trans('admin.common.delete_error_foreign_key', ['%name%' => $ContentTemplate->getTitle()]);
            $this->addError($message, 'admin');

            log_error('定型文報削除エラー', [$ContentTemplate->getId(), $e]);
        }

        return $this->redirectToRoute('admin_content_template');
    }

    /**
     * 定型文を取得する。
     *
     * @Route("/%eccube_admin_route%/setting/shop/template/{id}", name="admin_content_template_get")
     * @Route("/%eccube_admin_route%/order/template/{id}", name="admin_order_edit_template_get")
     * @param Request $request
     * @param null $id
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getById(Request $request, $id = null, CacheUtil $cacheUtil)
    {
        $data = [];
        if ($id) {
            $Template = $this->templateRepository->find($id);
            if (!$Template) {
                  return $this->json($data);
            }
             $data['description'] = $Template->getDescription();
             $data['audit_result'] = $Template->getAuditResult();
             $data['use_type'] = $Template->getUseType();
             $data['title'] = $Template->getTitle();
             
             return $this->json($data);
        } 

          return $this->json($data);
    }

}
