<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Content;

use Eccube\Common\Constant;
use Eccube\Controller\AbstractController;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\BulkMailTemplateType;
use Eccube\Entity\BulkMailTemplate;
use Eccube\Repository\BulkMailTemplateRepository;
use Eccube\Util\CacheUtil;
use Knp\Component\Pager\Paginator;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;

class BulkMailTemplateController extends AbstractController
{
    /**
     * @var BulkMailTemplateRepository
     */
    protected $templateRepository;
    
    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;

    /**
     * BulkMailTemplateController constructor.
     *
     * @param BulkMailTemplateRepository $templateRepository
     * @param PageMaxRepository $pageMaxRepository
     */
    public function __construct(BulkMailTemplateRepository $templateRepository,PageMaxRepository $pageMaxRepository)
    {
        $this->templateRepository = $templateRepository;
        $this->pageMaxRepository = $pageMaxRepository;
    }

    /**
     * メール一覧を表示する。
     *
     * @Route("/%eccube_admin_route%/customer/bulk_template", name="admin_content_bulk_template")
     * @Route("/%eccube_admin_route%/customer/bulk_template/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_content_bulk_template_page")
     * @Template("@admin/Content/bulk_mail_template.twig")
     *
     * @param Request $request
     * @param int $page_no
     * @param Paginator $paginator
     *
     * @return array
     */
    public function index(Request $request, $page_no = 1, Paginator $paginator)
    {
        $page_count = $this->session->get('eccube.bulk.template.page_count',
        $this->eccubeConfig->get('eccube_default_page_count'));
        $page_count_param = (int) $request->get('page_count');
        $pageMaxis = $this->pageMaxRepository->findAll();
        if ($page_count_param) {
         
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.bulk.template.page_count', $page_count);
                    break;
                }
            }
        }
        
        if (null !== $page_no || $request->get('resume')) {
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.bulk.template.page_no', (int) $page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.bulk.template.page_no', 1);
                }
               
        } else {
                /**
                 * 初期表示の場合.
                 */
                $page_no = 1;

                // セッション中の検索条件, ページ番号を初期化.
               
                $this->session->set('eccube.bulk.template.page_no', $page_no);
       }

        
        $qb = $this->templateRepository->findBy(array(), array('id' => 'ASC'));

        $event = new EventArgs(
            [
                'qb' => $qb,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_CONTENT_BULK_TEMPLATE_INDEX_INITIALIZE, $event);

        $pagination = $paginator->paginate(
            $qb,
            $page_no,
            $page_count
        );

        return [
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
        ];
    }

    /**
     * メールを登録・編集する。
     *
     * @Route("/%eccube_admin_route%/customer/bulk_template/new", name="admin_content_bulk_template_new")
     * @Route("/%eccube_admin_route%/customer/bulk_template/{id}/edit", requirements={"id" = "\d+"}, name="admin_content_bulk_template_edit")
     * @Template("@admin/Content/bulk_mail_template_edit.twig")
     *
     * @param Request $request
     * @param null $id
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function edit(Request $request, $id = null, CacheUtil $cacheUtil)
    {
        if ($id) {
            $Template = $this->templateRepository->find($id);
            if (!$Template) {
                throw new NotFoundHttpException();
            }
        } else {
            $Template = new BulkMailTemplate();
        }

        $builder = $this->formFactory
            ->createBuilder(BulkMailTemplateType::class, $Template);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'template' => $Template,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_CONTENT_BULK_TEMPLATE_EDIT_INITIALIZE, $event);

        $form = $builder->getForm();
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            $this->templateRepository->save($Template);

            $event = new EventArgs(
                [
                    'form' => $form,
                    'template' => $Template,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_CONTENT_BULK_TEMPLATE_EDIT_COMPLETE, $event);

            $this->addSuccess('admin.common.save_complete', 'admin');

            // キャッシュの削除
            $cacheUtil->clearDoctrineCache();

            return $this->redirectToRoute('admin_content_bulk_template_edit', ['id' => $Template->getId()]);
        }

        return [
            'form' => $form->createView(),
            'template' => $Template,
        ];
    }

    /**
     * 指定したメールを削除する。
     *
     * @Route("/%eccube_admin_route%/customer/bulk_template/{id}/delete", requirements={"id" = "\d+"}, name="admin_content_bulk_template_delete")
     *
     * @param Request $request
     * @param BulkMailTemplate $BulkMailTemplate
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function delete(Request $request, BulkMailTemplate $BulkMailTemplate)
    {

        log_info('メール削除開始', [$BulkMailTemplate->getId()]);

        try {
            $this->templateRepository->delete($BulkMailTemplate);

            $event = new EventArgs(['BulkMailTemplate' => $BulkMailTemplate], $request);
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_CONTENT_BULK_TEMPLATE_DELETE_COMPLETE, $event);

            $this->addSuccess('admin.common.delete_complete', 'admin');

            log_info('メール削除完了', [$BulkMailTemplate->getId()]);

           
        } catch (\Exception $e) {
            $message = trans('admin.common.delete_error_foreign_key', ['%name%' => $BulkMailTemplate->getTitle()]);
            $this->addError($message, 'admin');

            log_error('メール削除エラー', [$BulkMailTemplate->getId(), $e]);
        }

        return $this->redirectToRoute('admin_content_bulk_template');
    }

    /**
     *メールを取得する。
     *
     * @Route("/%eccube_admin_route%/customer/bulk_template/{id}", name="admin_content_bulk_template_get")
     *
     * @param Request $request
     * @param null $id
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function getById(Request $request, $id = null, CacheUtil $cacheUtil)
    {
        if ($id) {
            $Template = $this->templateRepository->find($id);
            if (!$Template) {
                return new Response("");
            }
            return new Response($Template->getDescription());
        } 

        return new Response("");
    }

}
