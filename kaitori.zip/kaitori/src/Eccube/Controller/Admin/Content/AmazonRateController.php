<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Content;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\DBAL\Exception\ForeignKeyConstraintViolationException;
use Eccube\Controller\AbstractController;
use Eccube\Entity\AmazonRule;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Util\FormUtil;
use Eccube\Form\Type\Admin\AmazonRuleType;
use Eccube\Repository\AmazonRuleRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Class AmazonRateController
 */
class AmazonRateController extends AbstractController
{
    /**
     * @var AmazonRuleRepository
     */
    protected $amazonRuleRepository;

    /**
     * AmazonRateController constructor.
     *
     * @param AmazonRuleRepository $amazonRuleRepository
     */
    public function __construct(AmazonRuleRepository $amazonRuleRepository)
    {
        $this->amazonRuleRepository = $amazonRuleRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/amazon/rate", name="admin_amazon_rate")
     * @Template("@admin/Content/amazaon_rate.twig")
     */
    public function index(Request $request)
    {
        $AmazonRules = $this->amazonRuleRepository->getList();

        $event = new EventArgs(
            [
                'AmazonRules' => $AmazonRules,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_CONTENT_AMAZONRATE_INDEX_COMPLETE, $event);

        return [
            'AmazonRules' => $AmazonRules,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/amazaon/rate/new", name="admin_amazon_rate_new")
     * @Route("/%eccube_admin_route%/amazaon/rate/{id}/edit", requirements={"id" = "\d+"}, name="admin_amazon_rate_edit")
     * @Template("@admin/Content/amazaon_rate_edit.twig")
     */
    public function edit(Request $request, $id = null)
    {
        if (is_null($id)) {
            $DefaultRule = $this->amazonRuleRepository->getCurrentRule();
            if (!is_null($DefaultRule)) {
                $AmazonRule = clone $DefaultRule;
                $AmazonRule->copy();
                $AmazonRule->setApplyDate(new \DateTime());
            } else {
                $AmazonRule = new AmazonRule();
                $AmazonRule
                    ->setName("買取換金率")
                    ->setApplyDate(new \DateTime());
            }
        } else {
            $AmazonRule = $this->amazonRuleRepository->find($id);
        }

        $builder = $this->formFactory
            ->createBuilder(AmazonRuleType::class, $AmazonRule);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'AmazonRule' => $AmazonRule,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_CONTENT_AMAZONRATE_EDIT_INITIALIZE, $event);

        $form = $builder->getForm();

        // 登録ボタン押下
        if ($request->getMethod() === 'POST') {
            $form->handleRequest($request);

            if ($form->isValid()) {
                $AmazonRuleData = $form->getData();
                foreach($AmazonRuleData->getAmazonRates() as $AmazonRate) {
                    if (is_null($AmazonRate->isFirstRate())) {
                        $AmazonRate->setFirstRate(false);
                    }
                    if (is_null($AmazonRate->isPriceUnlimited())) {
                        $AmazonRate->setPriceUnlimited(false);
                    }
                    //log_info("AmazonRate", [$AmazonRate->getId(),$AmazonRate->isFirstRate(),$AmazonRate->getName(),$AmazonRate->getPriceMin(),$AmazonRate->getPriceMax(),$AmazonRate->isPriceUnlimited(),$AmazonRate->getRate()]);
                }
                $this->entityManager->persist($AmazonRuleData);

                $this->entityManager->flush();
                
                $event = new EventArgs(
                    [
                        'form' => $form,
                        'AmazonRule' => $AmazonRule,
                    ],
                    $request
                );
                $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_CONTENT_AMAZONRATE_EDIT_COMPLETE, $event);

                $this->addSuccess('admin.common.save_complete', 'admin');

                return $this->redirectToRoute('admin_amazon_rate_edit', ['id' => $AmazonRule->getId()]);
            }
        }

        return [
            'form' => $form->createView(),
            //'AmazonRule' => $AmazonRule,
            'amazon_rule_id' => $AmazonRule->getId(),
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/amazaon/rate/{id}/delete", requirements={"id" = "\d+"}, name="admin_amazon_rate_delete", methods={"DELETE"})
     */
    public function delete(Request $request, AmazonRule $AmazonRule)
    {
        $this->isTokenValid();

        try {
            $this->entityManager->remove($AmazonRule);
            $this->entityManager->flush();
        } catch (ForeignKeyConstraintViolationException $e) {
            $this->addError(trans('admin.common.delete_error_foreign_key', ['%name%' => $Delivery->getName()]), 'admin');

            return $this->redirectToRoute('admin_amazon_rate');
        }

        $event = new EventArgs(
            [
                'AmazonRule' => $AmazonRule,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_CONTENT_AMAZONRATE_DELETE_COMPLETE, $event);

        $this->addSuccess('admin.common.delete_complete', 'admin');

        return $this->redirectToRoute('admin_amazon_rate');
    }

}
