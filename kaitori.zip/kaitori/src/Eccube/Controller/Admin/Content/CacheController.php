<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Content;

use Eccube\Controller\AbstractController;
use Eccube\Util\CacheUtil;
use Eccube\Entity\Product;
use Eccube\Entity\ProductClass;
use Eccube\Entity\Order;
use Eccube\Entity\Cart;
use Eccube\Entity\Customer;
use Eccube\Entity\OrderItem;
use Eccube\Entity\OrderItemCopy;
use Eccube\Entity\CartItem;
use Eccube\Entity\Paying;
use Eccube\Entity\CustomerCertsDoc;
use Eccube\Entity\BulkMailHistory;
use Eccube\Entity\ProductPriceOption;
use Eccube\Entity\ProductRecommend;
use Eccube\Entity\CustomerFavoriteProduct;
use Eccube\Entity\ProductRankOption;
use Eccube\Entity\Master\ProductStatus;
use Eccube\Entity\Master\OrderStatus;
use Eccube\Entity\Master\CustomerStatus;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\OrderItemRepository;
use Eccube\Repository\ProductPriceOptionRepository;
use Eccube\Repository\CartItemRepository;
use Eccube\Repository\ProductRecommendRepository;
use Eccube\Repository\CustomerFavoriteProductRepository;
use Eccube\Repository\ProductRankOptionRepository;
use Eccube\Repository\OrderRepository;
use Eccube\Repository\OrderItemCopyRepository;
use Eccube\Repository\CustomerRepository;
use Eccube\Repository\CartRepository;
use Eccube\Repository\CustomerCertsDocRepository;
use Eccube\Repository\BulkMailHistoryRepository;
use Eccube\Repository\PayingRepository;

class CacheController extends AbstractController
{

    /**
     * @var ProductRepository
     */
    protected $productRepository;
    
    /**
     * @var ProductClassRepository
     */
    protected $productClassRepository;
    
    /**
     * @var OrderItemRepository
     */
    protected $orderItemRepository;
    
    /**
     * @var OrderItemCopyRepository
     */
    protected $orderItemCopyRepository;
    
    /**
     * @var CartItemRepository
     */
    protected $cartItemRepository;
    
    /**
     * @var ProductPriceOptionRepository
     */
    protected $productPriceOptionRepository;
    
    /**
     * @var ProductRecommendRepository
     */
    protected $productRecommendRepository;
    
    /**
     * @var CustomerFavoriteProductRepository
     */
    protected $customerFavoriteProductRepository;
    
    /**
     * @var ProductRankOptionRepository
     */
    protected $productRankOptionRepository;
    
    /**
     * @var OrderRepository
     */
    protected $orderRepository;
    
    /**
     * @var CustomerRepository
     */
    protected $customerRepository;
    
    /**
     * @var CartRepository
     */
    protected $cartRepository;
    
    /**
     * @var CustomerCertsDocRepository
     */
    protected $customerCertsDocRepository;
    
    /**
     * @var BulkMailHistoryRepository
     */
    protected $bulkMailHistoryRepository;
    
    /**
     * @var PayingRepository
     */
    protected $payingRepository;
    
    public function __construct(
        ProductRepository $productRepository,
        ProductClassRepository $productClassRepository,
        OrderItemRepository $orderItemRepository,
        OrderItemCopyRepository $orderItemCopyRepository,
        CartItemRepository $cartItemRepository,
        ProductRecommendRepository $productRecommendRepository,
        CustomerFavoriteProductRepository $customerFavoriteProductRepository,
        ProductPriceOptionRepository $productPriceOptionRepository,
        ProductRankOptionRepository $productRankOptionRepository,
        OrderRepository $orderRepository,
        CustomerRepository $customerRepository,
        CartRepository $cartRepository,
        CustomerCertsDocRepository $customerCertsDocRepository,
        BulkMailHistoryRepository $bulkMailHistoryRepository,
        PayingRepository $payingRepository
    ) {
        $this->productRepository = $productRepository;
        $this->productClassRepository = $productClassRepository;
        $this->orderItemRepository = $orderItemRepository;
        $this->orderItemCopyRepository = $orderItemCopyRepository;
        $this->cartItemRepository = $cartItemRepository;
        $this->productRecommendRepository = $productRecommendRepository;
        $this->customerFavoriteProductRepository = $customerFavoriteProductRepository;
        $this->productPriceOptionRepository = $productPriceOptionRepository;
        $this->productRankOptionRepository = $productRankOptionRepository;
        $this->orderRepository = $orderRepository;
        $this->customerRepository = $customerRepository;
        $this->cartRepository = $cartRepository;
        $this->customerCertsDocRepository = $customerCertsDocRepository;
        $this->bulkMailHistoryRepository = $bulkMailHistoryRepository;
        $this->payingRepository = $payingRepository;
    }
    
    /**
     * @Route("/%eccube_admin_route%/maintenance/cache", name="admin_content_cache")
     * @Template("@admin/Content/cache.twig")
     */
    public function index(Request $request, CacheUtil $cacheUtil)
    {
        $builder = $this->formFactory->createBuilder(FormType::class);
        $form = $builder->getForm();
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $cacheUtil->clearCache();

            $this->addSuccess('admin.common.delete_complete', 'admin');
        }
        return [
            'form' => $form->createView(),
        ];
    }
    
    /**
     * @Route("/%eccube_admin_route%/maintenance/cache/product/delete", name="admin_cache_product_delete", methods={"DELETE"})
     */
    public function bulkDeleteProduct(Request $request, CacheUtil $cacheUtil)
    {
        $this->isTokenValid();
        $session = $request->getSession();
        $message = null;
        $success = false;
        $id = $request->get('product_id');
        $type = $request->get('type');
        log_info('ssid',[$id]);
        log_info('type',[$type]);
        if($type == 'product'){
             if (!is_null($id)) {
                  /* @var $Product \Eccube\Entity\Product */
                  $Product = $this->productRepository->find($id);
                  if (!$Product) {
                      if ($request->isXmlHttpRequest()) {
                          $message = trans('admin.common.delete_error_already_deleted');

                          return $this->json(['success' => $success, 'message' => $message]);
                      } else {
                          $this->deleteMessage();
                          $rUrl = $this->generateUrl('admin_content_cache');
                          return $this->redirect($rUrl);
                      }
                  }

                  if ($Product instanceof Product) {
                          log_info('商品削除開始', [$id]);
                        try {
                          $this->deleteProduct($Product);
                          $success = true;
                          $message = trans('admin.common.delete_complete');

                          $cacheUtil->clearDoctrineCache();
                        } catch (ForeignKeyConstraintViolationException $e) {
                                log_info('商品削除エラー', [$id]);
                                $message = trans('admin.common.delete_error_foreign_key', ['%name%' => $Product->getName()]);
                        }
                   }
              } else {
                  log_info('商品削除エラー2', [$id]);
                  $message = trans('admin.common.delete_error');
              }
          }

          if($type == 'bulk_product'){
               try {
                    $Products = $this->productRepository->findBy(['Status' => ProductStatus::DISPLAY_ABOLISHED]);
                    foreach ($Products as $Product) {
                             log_info('$product',[$Product]);
                             $this->deleteProduct($Product);
                             // カテゴリ削除
                             //$this->deleteProductCategory($Product);
                    }
                    $success = true;
                    $message = trans('admin.common.delete_complete');
                    $cacheUtil->clearDoctrineCache();
                } catch (ForeignKeyConstraintViolationException $e) {
                      log_info('商品一括削除エラー');
                      $message = trans('admin.common.bulk.delete_error_foreign_key');
                }
          }

          if ($request->isXmlHttpRequest()) {
              return $this->json(['success' => $success, 'message' => $message]);
          } else {
              if ($success) {
                  $this->addSuccess($message, 'admin');
              }else {
                  $this->addError($message, 'admin');
              }
              $rUrl = $this->generateUrl('admin_content_cache');
              return $this->redirect($rUrl);
          }
    }
    
    /**
     * @Route("/%eccube_admin_route%/maintenance/cache/order/delete", name="admin_cache_order_delete", methods={"DELETE"})
     */
    public function bulkDeleteOrder(Request $request, CacheUtil $cacheUtil)
    {
        $this->isTokenValid();
        $session = $request->getSession();
        $message = null;
        $success = false;
        $id = $request->get('order_id');
        $type = $request->get('type');
        log_info('ssid',[$id]);
        if($type == 'order'){
             if (!is_null($id)) {
                  /* @var $Product \Eccube\Entity\Product */
                  $Order = $this->orderRepository->find($id);
                  if (!$Order) {
                      log_info('$request->isXmlHttpRequest()',[$request->isXmlHttpRequest()]);
                      if ($request->isXmlHttpRequest()) {
                          $message = trans('admin.common.delete_error_already_deleted');
                          return $this->json(['success' => $success, 'message' => $message]);
                      } else {
                          $this->deleteMessage();
                          $rUrl = $this->generateUrl('admin_content_cache');
                          return $this->redirect($rUrl);
                      }
                  }

                  if ($Order instanceof Order) {
                        log_info('注文削除開始', [$id]);
                        try {
                            $this->deleteOrder($Order);
                            $success = true;
                            $message = trans('admin.common.delete_complete');
                            $cacheUtil->clearDoctrineCache();
                         } catch (ForeignKeyConstraintViolationException $e) {
                                 log_info('注文削除エラー', [$id]);
                                 $message = trans('admin.common.delete_error_foreign_key', ['%name%' => $Order->getId()]);
                         }
                  }
              } else {
                  log_info('注文削除エラー', [$id]);
                  $message = trans('admin.common.delete_error');
              }
          }

          if($type == 'dummy_order'){
               try {
                   $Orders = $this->orderRepository->findBy(['OrderStatus' => OrderStatus::PROCESSING]);
                   foreach ($Orders as $Order) {
                            $this->deleteOrder($Order);
                   }
                   $success = true;
                   $message = trans('admin.common.delete_complete');
                   $cacheUtil->clearDoctrineCache();
                } catch (ForeignKeyConstraintViolationException $e) {
                      log_info('注文一括削除エラー');
                      $message = trans('admin.common.delete_error_foreign_key');
                }
          }

          if($type == 'bulk_order'){
               try {
                   $Orders = $this->orderRepository->findAll();
                   foreach ($Orders as $Order) {
                            $this->deleteOrder($Order);
                   }
                   $success = true;
                   $message = trans('admin.common.delete_complete');
                   $cacheUtil->clearDoctrineCache();
                } catch (ForeignKeyConstraintViolationException $e) {
                      log_info('注文一括削除エラー');
                      $message = trans('admin.common.delete_error_foreign_key');
                }
          }

          if ($request->isXmlHttpRequest()) {
              return $this->json(['success' => $success, 'message' => $message]);
          } else {
              if ($success) {
                  $this->addSuccess($message, 'admin');
              }else {
                  $this->addError($message, 'admin');
              }
              $rUrl = $this->generateUrl('admin_content_cache');
              return $this->redirect($rUrl);
          }
    }

    /**
     * @Route("/%eccube_admin_route%/maintenance/cache/customer/delete", name="admin_cache_customer_delete", methods={"DELETE"})
     */
    public function bulkDeleteCustomer(Request $request, CacheUtil $cacheUtil)
    {
        $this->isTokenValid();
        $session = $request->getSession();
        $message = null;
        $success = false;
        $id = $request->get('customer_id');
        $type = $request->get('type');
        log_info('ssid',[$id]);
        log_info('type',[$type]);
        if($type == 'customer'){
             if (!is_null($id)) {
                  /* @var $Product \Eccube\Entity\Product */
                  $Customer = $this->customerRepository->find($id);
                  if (!$Customer) {
                      if ($request->isXmlHttpRequest()) {
                          $message = trans('admin.common.delete_error_already_deleted');
                          return $this->json(['success' => $success, 'message' => $message]);
                      } else {
                          $this->deleteMessage();
                          $rUrl = $this->generateUrl('admin_content_cache');
                          return $this->redirect($rUrl);
                      }
                  }

                  if ($Customer instanceof Customer) {
                        log_info('ユーザー削除開始', [$id]);
                        try {
                          $this->deleteCustomer($Customer);
                          $success = true;
                          $message = trans('admin.common.delete_complete');
                          $cacheUtil->clearDoctrineCache();
                        } catch (ForeignKeyConstraintViolationException $e) {
                                log_info('ユーザー削除エラー', [$id]);
                                $message = trans('admin.common.delete_error_foreign_key', ['%name%' => $Customer->getId()]);
                        }
                   }
              } else {
                  log_info('ユーザー削除エラー', [$id]);
                  $message = trans('admin.common.delete_error');
              }
          }

          if($type == 'bulk_customer'){
               try {
                   $Customers = $this->customerRepository->findBy(['Status' => CustomerStatus::WITHDRAWING]);
                   foreach ($Customers as $Customer) {
                            $this->deleteCustomer($Customer);
                   }
                   $success = true;
                   $message = trans('admin.common.delete_complete');
                   $cacheUtil->clearDoctrineCache();
                } catch (ForeignKeyConstraintViolationException $e) {
                      log_info('ユーザー一括削除エラー');
                      $message = trans('admin.common.bulk.delete_error_foreign_key');
                }
          }

          if ($request->isXmlHttpRequest()) {
              return $this->json(['success' => $success, 'message' => $message]);
          } else {
              if ($success) {
                  $this->addSuccess($message, 'admin');
              }else {
                  $this->addError($message, 'admin');
              }
              $rUrl = $this->generateUrl('admin_content_cache');
              return $this->redirect($rUrl);
          }
    }

    public function deleteCustomer($Customer)
    {
          $Carts = $this->cartRepository->findBy(['Customer' => $Customer]);
          $CustomerCertsDocs = $this->customerCertsDocRepository->findBy(['customer_id' => $Customer->getId()]);
          $BulkMailHistories = $this->bulkMailHistoryRepository->findBy(['Customer' => $Customer]);
          $Orders = $this->orderRepository->findBy(['Customer' => $Customer]);
          $Payings = $this->payingRepository->findBy(['Customer' => $Customer]);
          log_info('$Payings',[$Payings]);
          $Customer->setCorporationDocFile(null)->setPersonalDocFile(null);
          $this->entityManager->persist($Customer);
          $this->entityManager->flush();
          foreach ($Carts as $Cart) {
              $this->cartRepository->delete($Cart);
          }
          foreach ($Orders as $Order) {
              $this->deleteOrder($Order);
          }
          foreach ($CustomerCertsDocs as $CustomerCertsDoc) {
              log_info('$CustomerCertsDoc',[$CustomerCertsDoc->getId()]);
              $this->customerCertsDocRepository->delete($CustomerCertsDoc);
              $this->entityManager->flush();
          }
          foreach ($BulkMailHistories as $BulkMailHistory) {
              $this->bulkMailHistoryRepository->delete($BulkMailHistory);
          }
          foreach ($Payings as $Paying) {
              log_info('$Paying',[$Paying]);
              $this->payingRepository->delete($Paying);
              $this->entityManager->flush();
          }
          $this->customerRepository->delete($Customer);
          $this->entityManager->flush();
    }

    public function deleteOrder($Order)
    {
          $OrderItemCopys = $this->orderItemCopyRepository->findBy(['Order' => $Order]);
          foreach ($OrderItemCopys as $OrderItemCopy) {
              $this->orderItemCopyRepository->delete($OrderItemCopy);
              $this->entityManager->flush();
          }
          $this->orderRepository->delete($Order);
          $this->entityManager->flush();
    }

    public function deleteProduct($Product)
    {
      $ProductClasses = $this->productClassRepository->findBy(['Product' => $Product]);
      $OrderItems = $this->orderItemRepository->findBy(['Product' => $Product]);
      $ProductPriceOptions = $this->productPriceOptionRepository->findBy(['ProductClass' => $ProductClasses]);
      $CartItems = $this->cartItemRepository->findBy(['ProductClass' => $ProductClasses]);
      $ProductRecommends = $this->productRecommendRepository->findBy(['ProductClass' => $ProductClasses]);
      $CustomerFavoriteProducts = $this->customerFavoriteProductRepository->findBy(['Product' => $Product]);
      foreach ($CustomerFavoriteProducts as $CustomerFavoriteProduct) {
          $this->customerFavoriteProductRepository->deleteCustomerFavoriteProduct($CustomerFavoriteProduct);
      }
       
      $ProductPriceOption1 = array_filter($ProductPriceOptions, function($ProductPriceOption) {
                           return $ProductPriceOption->getHierarchy() == 1 ;
      });
      $ProductPriceOption2 = array_filter($ProductPriceOptions, function($ProductPriceOption) {
                           return $ProductPriceOption->getHierarchy() == 2 ;
      });
      $ProductPriceOption3 = array_filter($ProductPriceOptions, function($ProductPriceOption) {
                           return $ProductPriceOption->getHierarchy() == 3 ;
      });

      foreach ($ProductPriceOption3 as $ProductPriceOption) {
            $ProductRankOptions = $this->productRankOptionRepository->findBy(['ProductRank' => $ProductPriceOption]);
            foreach ($ProductRankOptions as $ProductRankOption) {
                $this->productRankOptionRepository->delete($ProductRankOption);
            }
            $this->productPriceOptionRepository->deleteProductPriceOption($ProductPriceOption);
      }
      foreach ($ProductPriceOption2 as $ProductPriceOption) {
            $ProductRankOptions = $this->productRankOptionRepository->findBy(['ProductRank' => $ProductPriceOption]);
            foreach ($ProductRankOptions as $ProductRankOption) {
                $this->productRankOptionRepository->delete($ProductRankOption);
            }
            $this->productPriceOptionRepository->deleteProductPriceOption($ProductPriceOption);
      }
      foreach ($ProductPriceOption1 as $ProductPriceOption) {
            $ProductRankOptions = $this->productRankOptionRepository->findBy(['ProductRank' => $ProductPriceOption]);
            foreach ($ProductRankOptions as $ProductRankOption) {
                $this->productRankOptionRepository->delete($ProductRankOption);
            }
            $this->productPriceOptionRepository->deleteProductPriceOption($ProductPriceOption);
      }
      foreach ($ProductRecommends as $ProductRecommend) {
          $this->productRecommendRepository->deleteProductRecommend($ProductRecommend);
      }
      foreach ($CartItems as $CartItem) {
          $this->cartItemRepository->delete($CartItem);
      }
      foreach ($OrderItems as $OrderItem) {
          $this->orderItemRepository->delete($OrderItem);
      }
      foreach ($OrderItems as $OrderItem) {
          $Order = $this->orderRepository->find($OrderItem->getOrder());
          if($Order){
             $this->orderRepository->delete($Order);
          }
      }
      foreach ($ProductClasses as $ProductClass) {
          $this->productClassRepository->delete($ProductClass);
      }
      if($Product){
          $this->productRepository->delete($Product);
      }
       $this->entityManager->flush();
    }
}
