<?php


namespace Eccube\Controller\Admin\Rack;

use Eccube\Controller\Admin\AbstractCsvImportController;
use Eccube\Entity\RackProduct;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\RackProductRepository;
use Eccube\Repository\RockStockQuantityHistoryRepository;
use Eccube\Repository\StateRepository;
use Eccube\Util\CacheUtil;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class ExcelRackProductController extends AbstractCsvImportController
{
    /**
     * @var StateRepository
     */
    protected $stateRepository;

    /**
     * @var ProductClassRepository
     */
    protected $productClassRepository;

    /**
     * @var RackProductRepository
     */
    protected $RackProductRepository;

    /**
     * @var RockStockQuantityHistoryRepository
     */
    protected $RockStockQuantityHistoryRepository;

    private $errors = [];

    public function __construct(
        StateRepository $stateRepository,
        ProductClassRepository $productClassRepository,
        RackProductRepository $RackProductRepository,
        RockStockQuantityHistoryRepository $RockStockQuantityHistoryRepository
    ) {
        $this->stateRepository = $stateRepository;
        $this->productClassRepository = $productClassRepository;
        $this->RackProductRepository = $RackProductRepository;
        $this->RockStockQuantityHistoryRepository = $RockStockQuantityHistoryRepository;
    }

    /**
     * ラック
     *
     * @Route("/%eccube_admin_route%/rack_check/rack_xlsx_upload", name="admin_rack_check_import_xlsx")
     * @param Request $request Request
     * @param CacheUtil $cache_util CacheUtil
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     * @throws \Doctrine\DBAL\ConnectionException
     */
    public function csvPayeeVoucher(Request $request, CacheUtil $cache_util)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        ini_set('memory_limit', '2048M');

        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('csv import start.');
            /** @var UploadedFile $uploaded_file */
            $uploaded_file = $request->files->get('admin_search_rackProduct')['check_file'];
            $errorCount = 0;
            $normalCount = 0;

            if (!empty($uploaded_file)) {
                log_info('商品ラック検査一括登録開始');
                $spreadsheet = IOFactory::load($uploaded_file->getPathname());

                $uploadData = $spreadsheet->getSheet(0)->rangeToArray('C4:T'.$spreadsheet->getSheet(0)->getHighestDataRow(),'',false,false);

                // データ存在チェック
                if ($uploadData[0][2] == null) {
                    $this->addErrors('データが存在しません');
                    return $this->renderWithError();
                }

                    $errorList = null;
                    foreach ($uploadData as $rowNum => $data) {

                        // 登録対象チェック
                        if ($data[0] != '〇') {
                            continue;
                        }

                        // 商品コード:必須チェック
                        $productCode = str_replace("\t", "", $data[4]);
                        $data[4] = $productCode;
                        if ($productCode == null || $productCode == '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[4] == null ? '' : $data[4],
                                'productName' => $data[5] == null ? '' : $data[5],
                                'state' => $data[7] == null ? '' : $data[7],
                                'errorMessage' => trans('「商品コード」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 状態ID:必須チェック
                        $stateId = $data[6];
                        if ($stateId === null || $stateId === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[4] == null ? '' : $data[4],
                                'productName' => $data[5] == null ? '' : $data[5],
                                'state' => $data[7] == null ? '' : $data[7],
                                'errorMessage' => trans('「状態ID」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 「商品クラスマスタ」チェック
                        $productClass = $this->productClassRepository->findOneBy(['code' => $productCode]);
                        if (empty($productClass)) {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[4] == null ? '' : $data[4],
                                'productName' => $data[5] == null ? '' : $data[5],
                                'state' => $data[7] == null ? '' : $data[7],
                                'errorMessage' => trans('「商品クラスマスタ」に対応商品コードがありません'),
                            ];
                            $errorCount++;
                        }

                        // 「状態マスタ」チェック
                        $stateInfo = $this->stateRepository->find($stateId);
                        if (empty($stateInfo)) {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[4] == null ? '' : $data[4],
                                'productName' => $data[5] == null ? '' : $data[5],
                                'state' => $data[7] == null ? '' : $data[7],
                                'errorMessage' => trans('「状態マスタ」に対応状態がありません'),
                            ];
                            $errorCount++;
                        }

                        // ID:必須チェック
                        $stock_quantity = str_replace("\t", "", $data[11]);
                        $now_rack_quantity = str_replace("\t", "", $data[12]);
                        $data[11] = $stock_quantity;
                        $data[12] = $now_rack_quantity;

                        // エラーなし場合、データを更新する。
                        if ($errorCount == 0) {

                            /** @var $rackProduct rackProduct */
                            $rackProduct = $this->RackProductRepository->findOneBy([
                                'productCode' => $productCode,
                                'state' => $stateId,
                            ]);

                            $rackProduct->setCheckedUserName($this->getUser());
                            $rackProduct->setCheckedDate(new \DateTime());
                            $rackProduct->setCheckedStockQuantity($stock_quantity);
                            $rackProduct->setCheckedRackQuantity($now_rack_quantity);
                            $rackProduct->setCheckedDiffQuantity($stock_quantity - $now_rack_quantity);
                            $rackProduct->setUpdateUserName($this->getUser());

                            $this->entityManager->persist($rackProduct);
                            $this->entityManager->flush();

                            if($stock_quantity - $now_rack_quantity === 0){
                                $result_classify_kubun = '0';
                            } else {
                                $result_classify_kubun = '1';
                            }

                            $this->RockStockQuantityHistoryRepository->insertStockQuantityInfo($productCode, $stateId,'0',$result_classify_kubun, $this->getUser(), $stock_quantity, $now_rack_quantity, $stock_quantity - $now_rack_quantity);

                            $normalCount++;
                        } // エラーがある場合、チェック続行。（ループ後、rollbackが必要です）
                        else {
                            continue;
                        }
                    }

                $this->removeUploadedFile();

                if ($errorCount > 0) {
                    $this->entityManager->rollback();
                    return $this->json(['data' => $errorList]);
                } else {
                    if ($normalCount == 0) {
                        $this->addErrors('登録対象がありません');
                        return $this->renderWithError();
                    } else {
                        $this->entityManager->flush();
                        $this->addErrors('ラック一括登録完了しました。');
                        return $this->renderWithError();
                    }
                }

            }
        }
    }

    /**
     * 登録、更新時のエラー画面表示
     */
    protected function addErrors($message)
    {
        $this->errors[] = $message;
    }

    /**
     * 登録、更新時のエラー画面表示
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     *
     * @throws \Doctrine\DBAL\ConnectionException
     */
    protected function renderWithError()
    {
        $this->removeUploadedFile();

        return $this->json([
            'errors' => $this->errors,
        ]);
    }
}
