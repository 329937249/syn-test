<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Rack;

use Eccube\Controller\AbstractController;
use Eccube\Entity\RackProduct;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\RackProductListType;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\RackProductRepository;
use Eccube\Repository\RockSimpleSerialRepository;
use Eccube\Repository\StockListProductUnitRepository;
use Eccube\Repository\StateRepository;
use Eccube\Repository\StockListStorehouseUnitRepository;
use Eccube\Repository\RockStockQuantityHistoryRepository;
use Eccube\Util\FormUtil;
use Eccube\Util\StringUtil;
use Knp\Component\Pager\Paginator;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： RackProductListController.php
 *概　　要     ： 商品ラック一覧
 *作　　成     ： 2022/09/21 CNC
 */
class RackProductListController extends AbstractController
{
    /**
     * @var ProductClassRepository
     */
    protected $productClassRepository;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var StockListStorehouseUnitRepository
     */
    private $stockListStorehouseUnitRepository;

    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;

    /**
     * @var StateRepository
     */
    protected $stateRepository;

    /**
     * @var RackProductRepository
     */
    protected $RackProductRepository;

    /**
     * @var RockStockQuantityHistoryRepository
     */
    protected $RockStockQuantityHistoryRepository;

    /**
     * @var RockSimpleSerialRepository
     */
    protected $RockSimpleSerialRepository;

    /**
     * ProductController constructor.
     *
     * @param CategoryRepository $categoryRepository
     * @param ProductRepository $productRepository
     * @param StockListStorehouseUnitRepository $stockListStorehouseUnitRepository
     * @param PageMaxRepository $pageMaxRepository
     * @param StateRepository $stateRepository
     * @param RackProductRepository $RackProductRepository
     * @param RockStockQuantityHistoryRepository $RockStockQuantityHistoryRepository
     * @param RockSimpleSerialRepository $RockSimpleSerialRepository
     */
    public function __construct(
        CategoryRepository $categoryRepository,
        ProductRepository $productRepository,
        StockListStorehouseUnitRepository $stockListStorehouseUnitRepository,
        PageMaxRepository $pageMaxRepository,
        StateRepository $stateRepository,
        RackProductRepository $RackProductRepository,
        RockStockQuantityHistoryRepository $RockStockQuantityHistoryRepository,
        RockSimpleSerialRepository $RockSimpleSerialRepository
    ) {
        $this->categoryRepository = $categoryRepository;
        $this->productRepository = $productRepository;
        $this->stockListStorehouseUnitRepository = $stockListStorehouseUnitRepository;
        $this->pageMaxRepository = $pageMaxRepository;
        $this->stateRepository = $stateRepository;
        $this->RackProductRepository = $RackProductRepository;
        $this->RockStockQuantityHistoryRepository = $RockStockQuantityHistoryRepository;
        $this->RockSimpleSerialRepository = $RockSimpleSerialRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/rack_product/rack_product_list", name="admin_rack_product_list")
     * @Route("/%eccube_admin_route%/rack_product/rack_product_list/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_rack_product_list_page")
     * @Template("@admin/Rack/rack_product_list.twig")
     */
    public function index(Request $request, $page_no = null, Paginator $paginator)
    {
        $builder = $this->formFactory
            ->createBuilder(RackProductListType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_RACK_PRODUCT_LIST_INDEX_INITIALIZE, $event);

        $searchForm = $builder->getForm();

        /**
         * ページの表示件数は, 以下の順に優先される.
         * - リクエストパラメータ
         * - セッション
         * - デフォルト値
         * また, セッションに保存する際は mtb_page_maxと照合し, 一致した場合のみ保存する.
         **/
        $page_count = $this->session->get('eccube.admin.rack.product.search.page_count',
            $this->eccubeConfig->get('eccube_mltext_len'));

        $page_count_param = (int) $request->get('page_count');
        $pageMaxis = $this->pageMaxRepository->findAll();

        if ($page_count_param) {
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.admin.rack.product.search.page_count', $page_count);
                    break;
                }
            }
        }

        $page_no_bk = $page_no;
        if ('POST' === $request->getMethod()) {
            $searchForm->handleRequest($request);

            if ($searchForm->isValid()) {
                /**
                 * 検索が実行された場合は, セッションに検索条件を保存する.
                 * ページ番号は最初のページ番号に初期化する.
                 */
                $page_no = 1;
                $searchData = $searchForm->getData();

                // 検索条件, ページ番号をセッションに保持.
                $this->session->set('eccube.admin.rack.product.search', FormUtil::getViewData($searchForm));
                $this->session->set('eccube.admin.rack.product.search.page_no', $page_no);
            } else {
                // 検索エラーの際は, 詳細検索枠を開いてエラー表示する.
                return [
                    'searchForm' => $searchForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $page_count,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.admin.rack.product.search.page_no', (int) $page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.admin.rack.product.search.page_no', 1);
                }
                $viewData = $this->session->get('eccube.admin.rack.product.search', []);
                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
            } else {
                /**
                 * 初期表示の場合.
                 */
                $page_no = 1;
                // main category
                $categories = $this->categoryRepository->getList(null, false);
                $mainCategory = null;
                foreach ($categories as $Category) {
                    if ($Category && ($Category->getHierarchy() == 1)) {
                        $mainCategory = $Category;
                        break;
                    }
                }

                // submit default value
                $viewData = FormUtil::getViewData($searchForm);
                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);

                // セッション中の検索条件, ページ番号を初期化.
                $this->session->set('eccube.admin.rack.product.search', $viewData);
                $this->session->set('eccube.admin.rack.product.search.page_no', $page_no);
            }
        }

        $qb = [];
        if ('POST' === $request->getMethod() || null !== $page_no_bk){
            $qb = $this->getSearchData($searchData);
        }

        foreach ($qb as &$rack) {
            $rack['checked_date'] = $this->makeDateStringUtcToAsiaTokyo($rack['checked_date']);
        }

        $sort_orders = $this->sortOrder($qb, $searchData);

        $event = new EventArgs(
            [
                'qb' => $qb,
                'searchData' => $searchData,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_RACK_PRODUCT_LIST_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $page_count
        );

        return [
            'searchForm' => $searchForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'has_errors' => false,
            'request' => $request,
        ];
    }

    public function getSearchData($searchData)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();

        //在庫あり
        $rackExist = $searchData['inventory_exist'];
        //マイナス在庫
        $rackMinus = $searchData['inventory_minus'];
        //在庫なし
        $rackNonExist = $searchData['inventory_non_exist'];

        $sql = "
                SELECT
                    id
                  , image
                  , category_id1
                  , categoryname1
                  , category_id2
                  , categoryname2
                  , category_id3
                  , categoryname3
                  , product_code
                  , product_id
                  , product_name
                  , serial_flg
                  , state_id
                  , state
                  , rack_code1
                  , rack_code2
                  , rack_code3
                  , checked_user_name
                  , checked_date
                  , checked_stock_quantity
                  , checked_rack_quantity
                  , checked_diff_quantity
                  , now_stock_quantity
                  , product_size_en
                FROM (
                        SELECT
                            rp.id AS id
                            , pi.file_name AS image
                            , dc4.category_id AS category_id1
                            , dc4.categoryname AS categoryname1
                            , dc5.category_id AS category_id2
                            , dc5.categoryname AS categoryname2
                            , dc6.category_id AS category_id3
                            , dc6.categoryname AS categoryname3
                            , rp.product_code AS product_code
                            , rp.product_id AS product_id
                            , p.name AS product_name
                            , p.serial_flg AS serial_flg
                            , s.id AS state_id
                            , s.state AS state
                            , r1.rack_code AS rack_code1
                            , r2.rack_code AS rack_code2
                            , r3.rack_code AS rack_code3
                            , rp.checked_user_name AS checked_user_name
                            , rp.checked_date AS checked_date
                            , rp.checked_stock_quantity AS checked_stock_quantity
                            , rp.checked_rack_quantity AS checked_rack_quantity
                            , rp.checked_diff_quantity AS checked_diff_quantity
                            , CASE WHEN slsu.storehouse_id = '13'
                              THEN slsu.stock_quantity 
                              ELSE 0 
                              END AS now_stock_quantity 
                            , p.product_size_en AS product_size_en 
                        FROM
                            dtb_rack_product rp
                            INNER JOIN dtb_product_class pc 
                                ON rp.product_class_id = pc.id 
                            INNER JOIN dtb_product p 
                                ON pc.product_id = p.id 
                            INNER JOIN mtb_state s 
                                ON rp.state_id = s.id 
                            LEFT JOIN dtb_product_image pi 
                                ON pi.product_id = pc.product_id 
                            LEFT JOIN ( 
                                SELECT
                                    sls. product_code
                                    , sls.state_id
                                    , sls.storehouse_id
                                    , sum(sls.stock_quantity) AS stock_quantity
                                FROM
                                    dtb_stock_list_storehouse_unit sls
                                WHERE 
                                    sls.storehouse_id = '13'
                                AND sls.stock_quantity <> 0
                                GROUP BY
                                    sls.product_code
                                    ,sls.state_id
                                    ,sls.storehouse_id
                            ) AS slsu 
                                ON slsu.product_code = rp.product_code 
                               AND slsu.state_id = rp.state_id 
                            LEFT JOIN mtb_rack r1 
                                ON r1.id = rp.rack_1 
                            LEFT JOIN mtb_rack r2 
                                ON r2.id = rp.rack_2 
                            LEFT JOIN mtb_rack r3 
                                ON r3.id = rp.rack_3 
                            INNER JOIN ( 
                                SELECT
                                    rp.id AS id
                                    , dcs.category_name AS categoryname
                                    , dcs.hierarchy AS hierarchy
                                    , dpcs.category_id AS category_id 
                                FROM
                                    dtb_rack_product rp 
                                    INNER JOIN dtb_product_class pc 
                                        ON rp.product_class_id = pc.id 
                                    INNER JOIN dtb_product dps 
                                        ON pc.product_id = dps.id 
                                    INNER JOIN dtb_product_category dpcs 
                                        ON rp.product_id = dpcs.product_id 
                                        AND dpcs.category_sub_flag <> 1 
                                    INNER JOIN dtb_category dcs 
                                        ON dcs.id = dpcs.category_id
                            ) AS dc4 
                                ON dc4.id = rp.id 
                                AND dc4.hierarchy = 1 
                            LEFT JOIN ( 
                                SELECT
                                    rp.id AS id
                                    , dcs.category_name AS categoryname
                                    , dcs.hierarchy AS hierarchy
                                    , dpcs.category_id AS category_id 
                                FROM
                                    dtb_rack_product rp 
                                    INNER JOIN dtb_product_class pc 
                                        ON rp.product_class_id = pc.id 
                                    INNER JOIN dtb_product dps 
                                        ON pc.product_id = dps.id 
                                    INNER JOIN dtb_product_category dpcs 
                                        ON rp.product_id = dpcs.product_id 
                                        AND dpcs.category_sub_flag <> 1 
                                    INNER JOIN dtb_category dcs 
                                        ON dcs.id = dpcs.category_id
                            ) AS dc5 
                                ON dc5.id = rp.id 
                                AND dc5.hierarchy = 2 
                            LEFT JOIN ( 
                                SELECT
                                    rp.id AS id
                                    , dcs.category_name AS categoryname
                                    , dcs.hierarchy AS hierarchy
                                    , dpcs.category_id AS category_id 
                                FROM
                                    dtb_rack_product rp 
                                    INNER JOIN dtb_product_class pc 
                                        ON rp.product_class_id = pc.id 
                                    INNER JOIN dtb_product dps 
                                        ON pc.product_id = dps.id 
                                    INNER JOIN dtb_product_category dpcs 
                                        ON rp.product_id = dpcs.product_id 
                                        AND dpcs.category_sub_flag <> 1 
                                    INNER JOIN dtb_category dcs 
                                        ON dcs.id = dpcs.category_id
                            ) AS dc6 
                                ON dc6.id = rp.id 
                                AND dc6.hierarchy = 3 
                        WHERE
                            TRUE ";

        // mainCategory
        if (isset($searchData['main_category_id']) && !empty($searchData['main_category_id']) && $searchData['main_category_id']) {
            $Category = $searchData['main_category_id'];
            $category_id = 'category_id_'.$Category->getId();
            if (isset($searchData[$category_id]) && !empty($searchData[$category_id]) && $searchData[$category_id]) {
                $Categories = $searchData[$category_id]->getSelfAndDescendants();
            } else {
                $Categories = $Category->getSelfAndDescendants();
            }
            if ($Categories) {
                $sql = $sql.'AND dc4.category_id='."'".$searchData['main_category_id']['id']."'";
                if ($searchData[$category_id]) {
                    if ($searchData[$category_id]['hierarchy'] == '2') {
                        $sql = $sql.'AND  dc5.category_id='."'".$searchData[$category_id]['id']."'";
                    } else {
                        $sql = $sql.'AND  dc6.category_id='."'".$searchData[$category_id]['id']."'";
                    }
                }
            }
        }

        // product_code
        if (isset($searchData['product_code']) && StringUtil::isNotBlank($searchData['product_code'])) {
            $sql .= 'AND rp.product_code = '."'". $searchData['product_code']."'";
        }

        // rack
        if (isset($searchData['rack']) && StringUtil::isNotBlank($searchData['rack'])) {
            $sql .= 'AND (r1.rack_code like '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['rack']))."%'";
            $sql .= 'OR r2.rack_code like '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['rack']))."%'";
            $sql .= 'OR r3.rack_code like '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['rack']))."%')";
        }

        // state_simple_kubun
        if (isset($searchData['state_simple_kubun']) && StringUtil::isNotBlank($searchData['state_simple_kubun'])) {
            // 新品
            if ($searchData['state_simple_kubun']->getId() == '1') {
                $sql.= 'AND state = \'新品\'';
            }
            // 新品以外
            else if ($searchData['state_simple_kubun']->getId() == '2') {
                $sql.= 'AND state <> \'新品\'';
            }
        }

        // resultClaccify
        if (isset($searchData['resultClaccify']) && StringUtil::isNotBlank($searchData['resultClaccify'])) {
            // 正常
            if ($searchData['resultClaccify']['id'] == '0') {
                $sql .= 'AND rp.checked_diff_quantity = '."'". "0"."'";
            }
            // 異常
            else if ($searchData['resultClaccify']['id'] == '1') {
                $sql .= 'AND (rp.checked_diff_quantity is null OR rp.checked_diff_quantity <> '."'". "0"."')";
            }
        }

        // checkClassify
        if (isset($searchData['checkClassify']) && StringUtil::isNotBlank($searchData['checkClassify'])) {
            // 数量
            if ($searchData['checkClassify']['id'] == '0') {
                $sql .= 'AND p.serial_flg = '."'". "0"."'";
            }
            // シリアル
            else if ($searchData['checkClassify']['id'] == '1') {
                $sql .= 'AND p.serial_flg = '."'". "1"."'";
            }
        }

        // check_date_start
        if (isset($searchData['check_date_start']) && StringUtil::isNotBlank($searchData['check_date_start'])) {
            /** @var \DateTime $check_date_start */
            $update_date_start = $searchData['check_date_start'];
            $updateDateStart = $update_date_start->setTime('0', '0', '0')
                ->setTimezone(new \DateTimeZone('UTC'))
                ->format('Y-m-d H:i:s');
            $sql = $sql.' AND  rp.checked_date < \''.$updateDateStart.'\'';
        }

        // check_date_end
        if (isset($searchData['check_date_end']) && StringUtil::isNotBlank($searchData['check_date_end'])) {
            $check_date_end = $searchData['check_date_end'];
            $checkDateEnd = $check_date_end->setTime('23', '59', '59')
                ->setTimezone(new \DateTimeZone('UTC'))
                ->format('Y-m-d H:i:s');
            $sql = $sql.' OR  rp.checked_date > \''.$checkDateEnd.'\'';
        }

        $sql = $sql.'
                GROUP BY product_code
                        ,state
                        ,slsu.storehouse_id
                ORDER BY product_code
                        ,state ) rp1
                    ';

        $ExistFlg = false;
        $MinusFlg = false;

        $sql = $sql.' WHERE ';

        //在庫ありをチッェクオンの場合
        if ($rackExist == true) {
            $sql = $sql.' now_stock_quantity > 0 ';
            $ExistFlg = true;
        }

        if ($ExistFlg) {
            //マイナス在庫をチッェクオンの場合
            if ($rackMinus == true) {
                $sql = $sql.'OR now_stock_quantity < 0 ';
                $MinusFlg = true;
            }
        } else {
            if ($rackMinus == true) {
                $sql = $sql.' now_stock_quantity < 0 ';
                $MinusFlg = true;
            }
        }

        if ($ExistFlg or $MinusFlg) {
            //在庫なしをチッェクオンの場合
            if ($rackNonExist == true) {
                $sql = $sql.'OR now_stock_quantity = 0 ';
            }
        } else {
            if ($rackNonExist == true) {
                $sql = $sql.' now_stock_quantity = 0 ';
            }
        }

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    public function getSearchDataWithout($searchData)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();

        $sql = "
                SELECT
                    slsu.id AS id
                  , dc4.category_id AS category_id1
                  , dc4.categoryname AS categoryname1
                  , dc5.category_id AS category_id2
                  , dc5.categoryname AS categoryname2
                  , dc6.category_id AS category_id3
                  , dc6.categoryname AS categoryname3
                  , slsu.product_code AS product_code
                  , slsu.product_id AS product_id
                  , p.name AS product_name
                  , s.id AS state_id
                  , s.state AS state
                  , sum(slsu.stock_quantity) AS now_stock_quantity
                FROM
                    dtb_stock_list_storehouse_unit slsu
                    INNER JOIN dtb_product_class pc 
                        ON slsu.product_class_id = pc.id 
                    INNER JOIN dtb_product p 
                        ON pc.product_id = p.id 
                    INNER JOIN mtb_state s 
                        ON slsu.state_id = s.id 
                    LEFT JOIN dtb_rack_product rp 
                        ON slsu.product_code = rp.product_code 
                       AND slsu.state_id = rp.state_id 
                    INNER JOIN ( 
                        SELECT
                            slsu.id AS id
                            , dcs.category_name AS categoryname
                            , dcs.hierarchy AS hierarchy
                            , dpcs.category_id AS category_id 
                        FROM
                            dtb_stock_list_storehouse_unit slsu 
                            INNER JOIN dtb_product_class pc 
                                ON slsu.product_class_id = pc.id 
                            INNER JOIN dtb_product dps 
                                ON pc.product_id = dps.id 
                            INNER JOIN dtb_product_category dpcs 
                                ON slsu.product_id = dpcs.product_id 
                                AND dpcs.category_sub_flag <> 1 
                            INNER JOIN dtb_category dcs 
                                ON dcs.id = dpcs.category_id
                    ) AS dc4 
                        ON dc4.id = slsu.id 
                        AND dc4.hierarchy = 1 
                    LEFT JOIN ( 
                        SELECT
                            slsu.id AS id
                            , dcs.category_name AS categoryname
                            , dcs.hierarchy AS hierarchy
                            , dpcs.category_id AS category_id 
                        FROM
                            dtb_stock_list_storehouse_unit slsu 
                            INNER JOIN dtb_product_class pc 
                                ON slsu.product_class_id = pc.id 
                            INNER JOIN dtb_product dps 
                                ON pc.product_id = dps.id 
                            INNER JOIN dtb_product_category dpcs 
                                ON slsu.product_id = dpcs.product_id 
                                AND dpcs.category_sub_flag <> 1 
                            INNER JOIN dtb_category dcs 
                                ON dcs.id = dpcs.category_id
                    ) AS dc5 
                        ON dc5.id = slsu.id 
                        AND dc5.hierarchy = 2 
                    LEFT JOIN ( 
                        SELECT
                            slsu.id AS id
                            , dcs.category_name AS categoryname
                            , dcs.hierarchy AS hierarchy
                            , dpcs.category_id AS category_id 
                        FROM
                            dtb_stock_list_storehouse_unit slsu 
                            INNER JOIN dtb_product_class pc 
                                ON slsu.product_class_id = pc.id 
                            INNER JOIN dtb_product dps 
                                ON pc.product_id = dps.id 
                            INNER JOIN dtb_product_category dpcs 
                                ON slsu.product_id = dpcs.product_id 
                                AND dpcs.category_sub_flag <> 1 
                            INNER JOIN dtb_category dcs 
                                ON dcs.id = dpcs.category_id
                    ) AS dc6 
                        ON dc6.id = slsu.id 
                        AND dc6.hierarchy = 3 
                WHERE
                    rp.id IS NULL 
                 ";
        // DEL-START CNC 2022/12/07 川口に情報がなしの場合、在庫数0
        // AND slsu.storehouse_id = '13'

        // mainCategory
        if (isset($searchData['main_category_id']) && !empty($searchData['main_category_id']) && $searchData['main_category_id']) {
            $Category = $searchData['main_category_id'];
            $category_id = 'category_id_'.$Category->getId();
            if (isset($searchData[$category_id]) && !empty($searchData[$category_id]) && $searchData[$category_id]) {
                $Categories = $searchData[$category_id]->getSelfAndDescendants();
            } else {
                $Categories = $Category->getSelfAndDescendants();
            }
            if ($Categories) {
                $sql = $sql.'AND dc4.category_id='."'".$searchData['main_category_id']['id']."'";
                if ($searchData[$category_id]) {
                    if ($searchData[$category_id]['hierarchy'] == '2') {
                        $sql = $sql.'AND  dc5.category_id='."'".$searchData[$category_id]['id']."'";
                    } else {
                        $sql = $sql.'AND  dc6.category_id='."'".$searchData[$category_id]['id']."'";
                    }
                }
            }
        }

        // product_code
        if (isset($searchData['product_code']) && StringUtil::isNotBlank($searchData['product_code'])) {
            $sql .= 'AND slsu.product_code = '."'". $searchData['product_code']."'";
        }

        // state_simple_kubun
        if (isset($searchData['state_simple_kubun']) && StringUtil::isNotBlank($searchData['state_simple_kubun'])) {
            // 新品
            if ($searchData['state_simple_kubun']->getId() == '1') {
                $sql.= 'AND state = \'新品\'';
            }
            // 新品以外
            else if ($searchData['state_simple_kubun']->getId() == '2') {
                $sql.= 'AND state <> \'新品\'';
            }
        }

        $sql = $sql.'
                GROUP BY product_code
                        ,state
                        ,slsu.storehouse_id
                ORDER BY product_code
                        ,state
                    ';
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    /**
     * UTC時間を東京時間にする
     * @param string|null $date 時間文字列(yyyy-mm-dd HH:ii:ss)
     * @return string
     */
    public function makeDateStringUtcToAsiaTokyo(string $date = null)
    {
        if (!$date || $date !== date('Y-m-d H:i:s', strtotime($date))) {
            return '';
        }

        try {
            $date_utc = new \DateTime($date, new \DateTimeZone('UTC'));
            $date_asia_tokyo = $date_utc
                ->setTimezone(new \DateTimeZone('Asia/Tokyo'))
                ->format('Y/m/d H:i:s');
        } catch (\Exception $exception) {
            return '';
        }

        return $date_asia_tokyo;
    }

    private function sortOrder($orders, $searchData) {
        if ($searchData['sort_by']) {
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case '商品コード':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == "降順") {
                            return $a["product_code"] > $b["product_code"] ? -1 : 1;
                        }
                        return $a["product_code"] < $b["product_code"] ? -1 : 1;
                    });
                    break;
                case '状態':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == "降順") {
                            return $a["state"] > $b["state"] ? -1 : 1;
                        }
                        return $a["state"] < $b["state"] ? -1 : 1;
                    });
                    break;
            }
        }
        return $orders;
    }

    /**
     *
     * @Route("/%eccube_admin_route%/rack/check_stock_quantity", name="admin_rack_check_stock_quantity", methods={"POST"})
     *
     * @param Request $request Request
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function checkStockQuantity(Request $request)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()){
            $product_code = $request->get('product_code');
            $state_id = $request->get('state_id');
//            $stock_quantity = $request->get('stock_quantity');
            $rack_quantity = $request->get('rack_quantity');

            /** @var $RackProduct RackProduct */
            $RackProduct = $this->RackProductRepository->findBy([
                'productCode' => $product_code,
                'state' => $state_id,
            ]);

            if (!empty($RackProduct[0])) {
                $updateRackProduct = $RackProduct[0];

                $stockListStorehouseUnit = $this->stockListStorehouseUnitRepository->getStockQuantityByProduct($product_code, $state_id,'13');

                if (!empty($stockListStorehouseUnit[0])) {
                    $stock_quantity = $stockListStorehouseUnit[0]['stockQuantity'];
                // INS-START CNC 2022/12/07 川口に情報がなしの場合、在庫数0
                } else {
                    $stock_quantity = 0;
                }
                // INS-START CNC 2022/12/07

                    $updateRackProduct->setCheckedUserName($this->getUser());
                    $updateRackProduct->setCheckedDate(new \DateTime());
                    $updateRackProduct->setCheckedStockQuantity($stock_quantity);
                    $updateRackProduct->setCheckedRackQuantity($rack_quantity);
                    $updateRackProduct->setCheckedDiffQuantity($stock_quantity - $rack_quantity);

                    $updateRackProduct->setUpdateUserName($this->getUser());

                    $this->entityManager->persist($updateRackProduct);
                    $this->entityManager->flush();

                    if($stock_quantity - $rack_quantity === 0){
                        $result_classify_kubun = '0';
                    } else {
                        $result_classify_kubun = '1';
                    }

                    $this->RockStockQuantityHistoryRepository->insertStockQuantityInfo($product_code, $state_id,'0',$result_classify_kubun, $this->getUser(), $stock_quantity, $rack_quantity, $stock_quantity - $rack_quantity);

//                    $data = ['error_flg' => '0',];
                    $data = [
                        'error_flg' => '0',
                        'stock_quantity' => $stock_quantity,
                        'rack_quantity' => $rack_quantity,
                        'diff_quantity' => $stock_quantity - $rack_quantity,
                        'checkedDate' => date('Y-m-d H:i:s', strtotime('now')),
                        'checkedUserName' => $this->getUser()['name'],
                        ];
                // DEL-START CNC 2022/12/07 川口に情報がなしの場合、在庫数0
//                } else {
//                    $data = [
//                        'error_flg' => '1',
//                        'error_message' => 'この商品は在庫一覧（川口）に存在できません。',
//                    ];
//                }
                // DEL-END CNC 2022/12/07
            } else {
                $data = [
                    'error_flg' => '1',
                    'error_message' => 'この商品は商品ラック一覧に存在できません。',
                    ];
            }
        }
        return $this->json($data);
    }

    /**
     * 連動商品情報出力.
     *
     * @Route("/%eccube_admin_route%/rack/rack_product_export/xlsx", name="admin_rack_product_export_xlsx")
     *
     * @param Request $request Request
     *
     * @return StreamedResponse
     *
     * @throws \Exception
     */
    public function xlsxExport(Request $request)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        ini_set('memory_limit', '2048M');

        $response = new StreamedResponse();
        $response->setCallback(function () use ($request) {

            // searchData
            $builder = $this->formFactory
                ->createBuilder(RackProductListType::class);

            $event = new EventArgs(
                [
                    'builder' => $builder,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_LIST_INDEX_INITIALIZE, $event);

            $searchForm = $builder->getForm();

            $searchForm->handleRequest($request);

            $searchData = $searchForm->getData();

            // 画面入力取得
            $registered_product = $searchData['registered_product'];
            $unregistered_product = $searchData['unregistered_product'];

            // 明細開始行
            $count = 4;

            // xlsxファイル設定
            $xlsxPath = $this->eccubeConfig->get('eccube_html_dir') . '/template/admin/assets/xlsx/商品ラック一括登録.xlsx';
            $spreadsheet = IOFactory::load($xlsxPath);
            // 登録済商品
            if ($registered_product) {
                $qb = $this->getSearchData($searchData);

                foreach ($qb as &$rack) {
                    $rack['checked_date'] = $this->makeDateStringUtcToAsiaTokyo($rack['checked_date']);
                }

                $xlsxDatasAll = $qb;

                foreach ($xlsxDatasAll as $xlsxData) {

                    $spreadsheet->setActiveSheetIndex(0)
                        ->setCellValue('D' . $count, $xlsxData["categoryname1"])
                        ->setCellValue('E' . $count, $xlsxData["categoryname2"])
                        ->setCellValue('F' . $count, $xlsxData["categoryname3"])
                        ->setCellValue('G' . $count, "\t" . $xlsxData["product_code"] . "\t")
                        ->setCellValue('H' . $count, $xlsxData["product_name"])
                        ->setCellValue('I' . $count, $xlsxData["state_id"])
                        ->setCellValue('J' . $count, $xlsxData["state"])
                        ->setCellValue('K' . $count, $xlsxData["rack_code1"])
                        ->setCellValue('L' . $count, $xlsxData["rack_code2"])
                        ->setCellValue('M' . $count, $xlsxData["rack_code3"])
                        ->setCellValue('N' . $count, $xlsxData["now_stock_quantity"])
                        ->setCellValue('O' . $count, $xlsxData["checked_stock_quantity"])
                        ->setCellValue('P' . $count, $xlsxData["checked_rack_quantity"])
                        ->setCellValue('Q' . $count, $xlsxData["checked_diff_quantity"])
                        ->setCellValue('R' . $count, $xlsxData["checked_date"])
                        ->setCellValue('S' . $count, $xlsxData["checked_user_name"]);

                    $count = $count + 1;
                }
            }

            // 未登録商品
            if ($unregistered_product) {
                $qb = $this->getSearchDataWithout($searchData);

                $xlsxDatasAllWithout = $qb;

                foreach ($xlsxDatasAllWithout as $xlsxData) {

                    $spreadsheet->setActiveSheetIndex(0)
                        ->setCellValue('A' . $count, '未')
                        ->setCellValue('D' . $count, $xlsxData["categoryname1"])
                        ->setCellValue('E' . $count, $xlsxData["categoryname2"])
                        ->setCellValue('F' . $count, $xlsxData["categoryname3"])
                        ->setCellValue('G' . $count, "\t" . $xlsxData["product_code"] . "\t")
                        ->setCellValue('H' . $count, $xlsxData["product_name"])
                        ->setCellValue('I' . $count, $xlsxData["state_id"])
                        ->setCellValue('J' . $count, $xlsxData["state"])
                        ->setCellValue('N' . $count, $xlsxData["now_stock_quantity"]);

                    $count = $count + 1;
                }
            }

            $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');

            $writer->save('php://output');
        });

        $sysDate = (new \DateTime())->format('YmdHis');

        $filename = 'attachment;filename="商品ラック一括登録_' . $sysDate . '.xlsx"';

        $response->headers->set('Content-Disposition', $filename);
        header("Content-Type:application/force-download");
        header("Content-Type:application/vnd.ms-excel");
        header("Content-Type:application/octet-stream");
        header("Content-Type:application/download");
        header("Pragma: no-cache");

        $response->send();

        return $response;
    }

    /**
     * 連動商品情報出力.
     *
     * @Route("/%eccube_admin_route%/rack_check/export/xlsx", name="admin_rack_check_export_xlsx")
     *
     * @param Request $request Request
     *
     * @return StreamedResponse
     *
     * @throws \Exception
     */
    public function xlsxExportOut(Request $request)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        ini_set('memory_limit', '2048M');

        $response = new StreamedResponse();
        $response->setCallback(function () use ($request) {

            // searchData
            $builder = $this->formFactory
                ->createBuilder(RackProductListType::class);

            $event = new EventArgs(
                [
                    'builder' => $builder,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_LIST_INDEX_INITIALIZE, $event);

            $searchForm = $builder->getForm();

            $searchForm->handleRequest($request);

            $searchData = $searchForm->getData();

            // 画面入力取得
            $registered_product = $searchData['registered_product'];

            // 明細開始行
            $count = 4;

            // xlsxファイル設定
            $xlsxPath = $this->eccubeConfig->get('eccube_html_dir') . '/template/admin/assets/xlsx/商品ラック検査一括登録.xlsx';
            $spreadsheet = IOFactory::load($xlsxPath);

            // 登録商品
            if ($registered_product) {
                $qb = $this->getSearchData($searchData);

                foreach ($qb as &$rack) {
                    $rack['checked_date'] = $this->makeDateStringUtcToAsiaTokyo($rack['checked_date']);
                }

                foreach ($qb as $xlsxData) {

                    $spreadsheet->setActiveSheetIndex(0)
                        ->setCellValue('D' . $count, $xlsxData["categoryname1"])
                        ->setCellValue('E' . $count, $xlsxData["categoryname2"])
                        ->setCellValue('F' . $count, $xlsxData["categoryname3"])
                        ->setCellValue('G' . $count, "\t" . $xlsxData["product_code"] . "\t")
                        ->setCellValue('H' . $count, $xlsxData["product_name"])
                        ->setCellValue('I' . $count, $xlsxData["state_id"])
                        ->setCellValue('J' . $count, $xlsxData["state"])
                        ->setCellValue('K' . $count, $xlsxData["rack_code1"])
                        ->setCellValue('L' . $count, $xlsxData["rack_code2"])
                        ->setCellValue('M' . $count, $xlsxData["rack_code3"])
                        ->setCellValue('N' . $count, $xlsxData["now_stock_quantity"])
                        ->setCellValue('P' . $count, $xlsxData["checked_stock_quantity"])
                        ->setCellValue('Q' . $count, $xlsxData["checked_rack_quantity"])
                        ->setCellValue('R' . $count, $xlsxData["checked_diff_quantity"])
                        ->setCellValue('S' . $count, $xlsxData["checked_date"])
                        ->setCellValue('T' . $count, $xlsxData["checked_user_name"]);

                    $count = $count + 1;
                }
            }

            $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');

            $writer->save('php://output');
        });

        $sysDate = (new \DateTime())->format('YmdHis');

        $filename = 'attachment;filename="商品ラック検査一括登録_' . $sysDate . '.xlsx"';

        $response->headers->set('Content-Disposition', $filename);
        header("Content-Type:application/force-download");
        header("Content-Type:application/vnd.ms-excel");
        header("Content-Type:application/octet-stream");
        header("Content-Type:application/download");
        header("Pragma: no-cache");

        $response->send();

        return $response;
    }

    /**
     * シリアル別検査エラー結果出力.
     *
     * @Route("/%eccube_admin_route%/rack_check_serial/export/xlsx", name="admin_rack_check_serial_export_xlsx")
     *
     * @param Request $request Request
     *
     * @return StreamedResponse
     *
     * @throws \Exception
     */
    public function xlsxSerialExportOut(Request $request)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        ini_set('memory_limit', '2048M');

        $response = new StreamedResponse();
        $response->setCallback(function () use ($request) {
            // 明細開始行
            $count = 3;
            // xlsxファイル設定
            $xlsxPath = $this->eccubeConfig->get('eccube_html_dir') . '/template/admin/assets/xlsx/シリアル別検査エラー結果.xlsx';
            $spreadsheet = IOFactory::load($xlsxPath);

            $qb = $this->getSerialInfo();

            foreach ($qb as &$rack) {
                $rack['checked_date'] = $this->makeDateStringUtcToAsiaTokyo($rack['checked_date']);
            }

            foreach ($qb as $xlsxData) {

                $spreadsheet->setActiveSheetIndex(0)
                    ->setCellValue('C' . $count, $xlsxData["categoryname1"])
                    ->setCellValue('D' . $count, $xlsxData["categoryname2"])
                    ->setCellValue('E' . $count, $xlsxData["categoryname3"])
                    ->setCellValue('F' . $count, "\t" . $xlsxData["product_code"] . "\t")
                    ->setCellValue('G' . $count, $xlsxData["product_name"])
                    ->setCellValue('H' . $count, $xlsxData["state"])
                    ->setCellValue('I' . $count, $xlsxData["serial_no"])
                    ->setCellValue('J' . $count, $xlsxData["checked_user_name"])
                    ->setCellValue('K' . $count, $xlsxData["checked_date"])
                    ->setCellValue('L' . $count, '×');

                $count = $count + 1;
            }

            $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');

            $writer->save('php://output');
        });

        $sysDate = (new \DateTime())->format('YmdHis');
        $filename = 'attachment;filename="シリアル別検査エラー結果_' . $sysDate . '.xlsx"';

        $response->headers->set('Content-Disposition', $filename);
        header("Content-Type:application/force-download");
        header("Content-Type:application/vnd.ms-excel");
        header("Content-Type:application/octet-stream");
        header("Content-Type:application/download");
        header("Pragma: no-cache");

        $response->send();
        return $response;
    }

    public function getSerialInfo()
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();

        $sql = "
                SELECT
                     rss.id
                    ,rss.product_code AS product_code
                    , rss.state_id AS state_id
                    , rss.serial_no AS serial_no
                    , rss.checked_user_name AS checked_user_name
                    , rss.checked_date AS checked_date
                    , slsu.product_class_id AS product_class_id
                    , pc.product_id AS product_id
                    , p.name AS product_name
                    , s.state AS state
                    , dc4.category_id AS category_id1
                    , dc4.categoryname AS categoryname1
                    , dc5.category_id AS category_id2
                    , dc5.categoryname AS categoryname2
                    , dc6.category_id AS category_id3
                    , dc6.categoryname AS categoryname3
                FROM dtb_rack_simple_serial rss
                    INNER JOIN dtb_stock_list_storehouse_unit slsu
                        ON rss.product_code = slsu.product_code
                        AND rss.state_id = slsu.state_id
                    INNER JOIN dtb_product_class pc
                        ON slsu.product_class_id = pc.id
                    INNER JOIN dtb_product p
                        ON pc.product_id = p.id
                    INNER JOIN mtb_state s 
                        ON rss.state_id = s.id
                    INNER JOIN ( 
                        SELECT
                            rss.id AS id
                            , slsu.product_class_id AS product_class_id
                            , slsu.product_id AS product_id
                            , dcs.category_name AS categoryname
                            , dcs.hierarchy AS hierarchy
                            , dpcs.category_id AS category_id
                        FROM
                             dtb_rack_simple_serial rss 
                            INNER JOIN dtb_stock_list_storehouse_unit slsu
                                ON rss.product_code = slsu.product_code
                                AND rss.state_id = slsu.state_id
                                AND rss.serial_no = slsu.serial_no
                            INNER JOIN dtb_product_class pc
                                ON slsu.product_class_id = pc.id
                            INNER JOIN dtb_product dps
                                ON pc.product_id = dps.id
                            INNER JOIN dtb_product_category dpcs
                                ON slsu.product_id = dpcs.product_id
                                AND dpcs.category_sub_flag <> 1
                            INNER JOIN dtb_category dcs 
                                ON dcs.id = dpcs.category_id
                    ) AS dc4 
                        ON dc4.id = rss.id
                        AND dc4.hierarchy = 1
                    LEFT JOIN (
                        SELECT
                            rss.id AS id
                            , slsu.product_class_id AS product_class_id
                            , slsu.product_id AS product_id
                            , dcs.category_name AS categoryname
                            , dcs.hierarchy AS hierarchy
                            , dpcs.category_id AS category_id 
                        FROM
                            dtb_rack_simple_serial rss
                            INNER JOIN dtb_stock_list_storehouse_unit slsu 
                                ON rss.product_code = slsu.product_code
                                AND rss.state_id = slsu.state_id
                                AND rss.serial_no = slsu.serial_no
                            INNER JOIN dtb_product_class pc
                                ON slsu.product_class_id = pc.id
                            INNER JOIN dtb_product dps 
                                ON pc.product_id = dps.id 
                            INNER JOIN dtb_product_category dpcs
                                ON slsu.product_id = dpcs.product_id 
                                AND dpcs.category_sub_flag <> 1
                            INNER JOIN dtb_category dcs 
                                ON dcs.id = dpcs.category_id
                    ) AS dc5 
                        ON dc5.id = rss.id
                        AND dc5.hierarchy = 2  
                    LEFT JOIN (
                        SELECT
                            rss.id AS id
                            , slsu.product_class_id AS product_class_id
                            , slsu.product_id AS product_id
                            , dcs.category_name AS categoryname
                            , dcs.hierarchy AS hierarchy
                            , dpcs.category_id AS category_id
                        FROM
                            dtb_rack_simple_serial rss
                            INNER JOIN dtb_stock_list_storehouse_unit slsu 
                                ON rss.product_code = slsu.product_code
                                AND rss.state_id = slsu.state_id
                                AND rss.serial_no = slsu.serial_no
                            INNER JOIN dtb_product_class pc
                                ON slsu.product_class_id = pc.id
                            INNER JOIN dtb_product dps 
                                ON pc.product_id = dps.id 
                            INNER JOIN dtb_product_category dpcs 
                                ON slsu.product_id = dpcs.product_id
                                AND dpcs.category_sub_flag <> 1
                            INNER JOIN dtb_category dcs
                                ON dcs.id = dpcs.category_id
                    ) AS dc6 
                        ON dc6.id = rss.id 
                        AND dc6.hierarchy = 3
                WHERE
                    rss.checked_flg = '0'
                    AND slsu.storehouse_id = '13'
	            GROUP BY rss.state_id, rss.product_code, rss.serial_no";

        $sql = $sql.' ORDER BY
        rss.checked_date DESC
        ,rss.product_code
        ,rss.state_id
        ,rss.serial_no ASC';

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    /**
     *
     * @Route("/%eccube_admin_route%/rack/show_diff_quantity", name="admin_rack_show_diff_quantity", methods={"POST"})
     *
     * @param Request $request Request
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function showDiffQuantity(Request $request)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()){
            $product_code = $request->get('product_code');
            $state_id = $request->get('state_id');

            /** @var $Rack Rack */
            $Rack = $this->RackProductRepository->findOneBy([
                'productCode' => $product_code,
                'state' => $state_id,
            ]);
            $state_name = $Rack['stateName'];
            $product_name = $Rack['productName'];

            /** @var $RackProducts RackProducts */
            $RackProducts = $this->RockSimpleSerialRepository->findBy([
                'productCode' => $product_code,
                'state_id' => $state_id,
                'checked_flg' => 0,
            ]);

            $errorList = null;
            if ($RackProducts) {
               foreach ($RackProducts as $rowNum => $RackProduct){
                   $errorList[] = [
                       'rowNum' => $rowNum + 1,
                       'serial' => $RackProduct['serial_no'],
                       'errorMessage' => trans(''),
                   ];
               }
            } else {
                $errorList[] = [
                    'rowNum' => '',
                    'serial' => '',
                    'errorMessage' => trans('未検査のデータが存在しません'),
                ];
            }
        }
        return $this->json(['data' => $errorList,'product_code' => $product_code,'state' => $state_name,'product_name' => $product_name]);
    }
}
