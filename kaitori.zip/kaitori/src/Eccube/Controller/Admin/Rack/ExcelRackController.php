<?php


namespace Eccube\Controller\Admin\Rack;

use Eccube\Controller\Admin\AbstractCsvImportController;
use Eccube\Entity\Rack;
use Eccube\Repository\StateRepository;
use Eccube\Util\CacheUtil;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Eccube\Repository\RackLoginRepository;

class ExcelRackController extends AbstractCsvImportController
{
    /**
     * @var RackLoginRepository
     */
    protected $rackLoginRepository;


    private $errors = [];

    public function __construct(
        RackLoginRepository $rackLoginRepository
    ) {
        $this->rackLoginRepository = $rackLoginRepository;
    }

    /**
     * ラック
     *
     * @Route("/%eccube_admin_route%/rack/rack_xlsx_upload", name="admin_rack_import_xlsx")
     * @param Request $request Request
     * @param CacheUtil $cache_util CacheUtil
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     * @throws \Doctrine\DBAL\ConnectionException
     */
    public function csvPayeeVoucher(Request $request, CacheUtil $cache_util)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        ini_set('memory_limit', '2048M');

        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('csv import start.');
            /** @var UploadedFile $uploaded_file */
            $uploaded_file = $request->files->get('admin_csv_import')['import_file'];
            $errorCount = 0;
            $normalCount = 0;

            if (!empty($uploaded_file)) {
                log_info('ラック一括登録開始');
                $spreadsheet = IOFactory::load($uploaded_file->getPathname());

                $uploadData = $spreadsheet->getSheet(0)->rangeToArray('C4:E'.$spreadsheet->getSheet(0)->getHighestDataRow(),'',false,false);

                // データ存在チェック
                if ($uploadData[0][1] == null) {
                    $this->addErrors('データが存在しません');
                    return $this->renderWithError();
                }

                    $errorList = null;
                    foreach ($uploadData as $rowNum => $data) {

                        // 登録対象チェック
                        if ($data[0] != '〇') {
                            continue;
                        }

                        // ID:必須チェック
                        $id = str_replace("\t", "", $data[1]);
                        $rackCode = str_replace("\t", "", $data[2]);
                        $data[1] = $id;
                        $data[2] = $rackCode;

                        if ($id != '' || $id == '') {

                            $chkRackState = $this->rackLoginRepository->findBy(
                                [
                                    'rack_code' => $rackCode,
                                ]);
                            if (isset($chkRackState) && isset($chkRackState[0])) {
                                $errorList[] = [
                                    'rowNum' => $rowNum + 1,
                                    'rackCode' => $data[2] == null ? '' : $data[2],
                                    'errorMessage' => trans('このラックは既に存在します。'),
                                ];
                                $errorCount++;
                            }
                        }

                        // エラーなし場合、データを更新する。
                        if ($errorCount == 0) {


                            $rackLoginInfo = $this->rackLoginRepository->findOneBy([
                                'id' => $id,
                            ]);

                            // 新規の場合
                            if ($rackLoginInfo == null) {

                                $rackLoginInfo = new Rack();

                                $rackLoginInfo->setRackCode($rackCode);
                                $rackLoginInfo->setCreateUserName($this->getUser());
                                $rackLoginInfo->setUpdateUserName($this->getUser());
                                $this->entityManager->persist($rackLoginInfo);
                            } else {
                                $rackLoginInfo->setRackCode($rackCode);
                                $rackLoginInfo->setUpdateUserName($this->getUser());
                                $this->entityManager->persist($rackLoginInfo);
                            }

                            $this->entityManager->flush();

                            $normalCount++;
                        } // エラーがある場合、チェック続行。（ループ後、rollbackが必要です）
                        else {
                            continue;
                        }
                    }

                $this->removeUploadedFile();

                if ($errorCount > 0) {
                    $this->entityManager->rollback();
                    return $this->json(['data' => $errorList]);
                } else {
                    if ($normalCount == 0) {
                        $this->addErrors('登録対象がありません');
                        return $this->renderWithError();
                    } else {
                        $this->entityManager->flush();
                        $this->addErrors('ラック一括登録完了しました。');
                        return $this->renderWithError();
                    }
                }

            }
        }
    }

    /**
     * 登録、更新時のエラー画面表示
     */
    protected function addErrors($message)
    {
        $this->errors[] = $message;
    }

    /**
     * 登録、更新時のエラー画面表示
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     *
     * @throws \Doctrine\DBAL\ConnectionException
     */
    protected function renderWithError()
    {
        $this->removeUploadedFile();

        return $this->json([
            'errors' => $this->errors,
        ]);
    }
}
