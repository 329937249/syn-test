<?php


namespace Eccube\Controller\Admin\Rack;

use Eccube\Controller\Admin\AbstractCsvImportController;
use Eccube\Entity\Master\Netshop;
use Eccube\Entity\NetshopaiProductInfo;
use Eccube\Entity\NetshopaiResult;
use Eccube\Entity\Product;
use Eccube\Entity\ProductClass;
use Eccube\Entity\Rack;
use Eccube\Entity\RackProduct;
use Eccube\Entity\State;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\Master\NetshopRepository;
use Eccube\Repository\Master\PriceInterlockingLevelRepository;
use Eccube\Repository\NetshopaiProductInfoRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\RackLoginRepository;
use Eccube\Repository\RackProductRepository;
use Eccube\Repository\StateRepository;
use Eccube\Util\CacheUtil;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class CsvImportController extends AbstractCsvImportController
{
    /**
     * @var ProductRepository
     */
    private $productRepository;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var StateRepository
     */
    protected $stateRepository;

    /**
     * @var PriceInterlockingLevelRepository
     */
    protected $priceInterlockingLevelRepository;

    /**
     * @var NetshopRepository
     */
    protected $netshopRepository;

    /**
     * @var ProductClassRepository
     */
    protected $productClassRepository;

    /**
     * @var NetshopaiProductInfoRepository
     */
    protected $NetshopaiProductInfoRepository;

    /**
     * @var RackProductRepository
     */
    protected $RackProductRepository;

    /**
     * @var RackLoginRepository
     */
    protected $RackLoginRepository;

    private $errors = [];

    public function __construct(
        CategoryRepository $categoryRepository,
        StateRepository $stateRepository,
        PriceInterlockingLevelRepository $priceInterlockingLevelRepository,
        ProductClassRepository $productClassRepository,
        NetshopRepository $NetshopRepository,
        ProductRepository $productRepository,
        NetshopaiProductInfoRepository $NetshopaiProductInfoRepository,
         RackProductRepository $RackProductRepository,
        RackLoginRepository $RackLoginRepository
    ) {
        $this->categoryRepository = $categoryRepository;
        $this->stateRepository = $stateRepository;
        $this->priceInterlockingLevelRepository = $priceInterlockingLevelRepository;
        $this->productClassRepository = $productClassRepository;
        $this->netshopRepository = $NetshopRepository;
        $this->productRepository = $productRepository;
        $this->NetshopaiProductInfoRepository = $NetshopaiProductInfoRepository;
        $this->RackProductRepository = $RackProductRepository;
        $this->RackLoginRepository = $RackLoginRepository;
    }

    /**
     * 商品ラック一括登録
     *
     * @Route("/%eccube_admin_route%/rack/rack_product_xlsx_upload", name="admin_rack_product_import_xlsx")
     * @param Request $request Request
     * @param CacheUtil $cache_util CacheUtil
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     * @throws \Doctrine\DBAL\ConnectionException
     */
    public function csvRackProduct(Request $request, CacheUtil $cache_util)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        ini_set('memory_limit', '2048M');

        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('csv import start.');
            /** @var UploadedFile $uploaded_file */
            $uploaded_file = $request->files->get('admin_search_rackProduct')['import_file'];
            $errorCount = 0;
            $normalCount = 0;

            if (!empty($uploaded_file)) {
                log_info('商品ラック一括登録開始');
                $spreadsheet = IOFactory::load($uploaded_file->getPathname());

                $uploadData = $spreadsheet->getSheet(0)->rangeToArray('C4:M'.$spreadsheet->getSheet(0)->getHighestDataRow(),'',false,false);

                // データ存在チェック
                if ($uploadData[0][1] == null) {
                    $this->addErrors('データが存在しません');
                    return $this->renderWithError();
                }

                $errorList = null;
                foreach ($uploadData as $rowNum => $data) {

                    // ラック初期化
                    $entityRack1 = null;
                    $entityRack2 = null;
                    $entityRack3 = null;

                    // 完了判断
                    if ($data[1] === null || $data[1] === '') {
                        break;
                    }

                    // 登録対象チェック
//                    if ($data[0] != '〇') {
//                        continue;
//                    }
                    if ($data[0] != '〇' && $data[0] != '☓') {
                        continue;
                    }

                    // 商品コード:必須チェック
                    $productCode = str_replace("\t", "", $data[4]);
                    $data[4] = $productCode;
                    if ($productCode == null || $productCode == '') {
                        $errorList[] = [
                            'rowNum' => $rowNum + 1,
                            'productCode' => $data[4] == null ? '' : $data[4],
                            'productName' => $data[5] == null ? '' : $data[5],
                            'state' => $data[7] == null ? '' : $data[7],
                            'errorMessage' => trans('「商品コード」が必須入力'),
                        ];
                        $errorCount++;
                    }

                    // 状態ID:必須チェック
                    $stateId = $data[6];
                    if ($stateId === null || $stateId === '') {
                        $errorList[] = [
                            'rowNum' => $rowNum + 1,
                            'productCode' => $data[4] == null ? '' : $data[4],
                            'productName' => $data[5] == null ? '' : $data[5],
                            'state' => $data[7] == null ? '' : $data[7],
                            'errorMessage' => trans('「状態ID」が必須入力'),
                        ];
                        $errorCount++;
                    }

                    // ラック_1存在チェック
                    $rack1 = $data[8];
                    if ($rack1 != null && $rack1 != ''){
                        $entityRack1 = $this->RackLoginRepository->findOneBy([ 'rack_code' => $rack1 ]);
                        if (empty($entityRack1)){
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[4] == null ? '' : $data[4],
                                'productName' => $data[5] == null ? '' : $data[5],
                                'state' => $data[7] == null ? '' : $data[7],
                                'errorMessage' => trans('「ラック_1」は存在できません。'),
                            ];
                            $errorCount++;
                        }
                    }

                    // ラック_2存在チェック
                    $rack2 = $data[9];
                    if ($rack2 != null && $rack2 != ''){
                        $entityRack2 = $this->RackLoginRepository->findOneBy([ 'rack_code' => $rack2 ]);
                        if (empty($entityRack2)){
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[4] == null ? '' : $data[4],
                                'productName' => $data[5] == null ? '' : $data[5],
                                'state' => $data[7] == null ? '' : $data[7],
                                'errorMessage' => trans('「ラック_2」は存在できません。'),
                            ];
                            $errorCount++;
                        }
                    }

                    // ラック_3存在チェック
                    $rack3 = $data[10];
                    if ($rack3 != null && $rack3 != ''){
                        $entityRack3 = $this->RackLoginRepository->findOneBy([ 'rack_code' => $rack3 ]);
                        if (empty($entityRack3)){
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[4] == null ? '' : $data[4],
                                'productName' => $data[5] == null ? '' : $data[5],
                                'state' => $data[7] == null ? '' : $data[7],
                                'errorMessage' => trans('「ラック_3」は存在できません。'),
                            ];
                            $errorCount++;
                        }
                    }

                    // ラック_1未入力、かつ、
                    // ラック_2、または、ラック_3入力チェック
                    if (($rack2 != null && $rack2 != '') || ($rack3 != null && $rack3 != '')){
                        if ($rack1 == null || $rack1 == ''){
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[4] == null ? '' : $data[4],
                                'productName' => $data[5] == null ? '' : $data[5],
                                'state' => $data[7] == null ? '' : $data[7],
                                'errorMessage' => trans('「ラック_1」は入力されていません。'),
                            ];
                            $errorCount++;
                        }
                    }

                    // ラック_2未入力、かつ、
                    // ラック_3入力チェック
                    if ($rack3 != null && $rack3 != ''){
                        if ($rack2 == null || $rack2 == ''){
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[4] == null ? '' : $data[4],
                                'productName' => $data[5] == null ? '' : $data[5],
                                'state' => $data[7] == null ? '' : $data[7],
                                'errorMessage' => trans('「ラック_2」は入力されていません。'),
                            ];
                            $errorCount++;
                        }
                    }

                    // ラック_2重複チェック
                    if ($rack2 != null && $rack2 != ''){
                        if ($rack2 == $rack1){
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[4] == null ? '' : $data[4],
                                'productName' => $data[5] == null ? '' : $data[5],
                                'state' => $data[7] == null ? '' : $data[7],
                                'errorMessage' => trans('「ラック_2」が選択されています。'),
                            ];
                            $errorCount++;
                        }
                    }

                    // ラック_3重複チェック
                    if (($rack2 != null && $rack2 != '') && ($rack1 != null || $rack1 != '')){
                        if ($rack3 == $rack1 || $rack3 == $rack2){
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[4] == null ? '' : $data[4],
                                'productName' => $data[5] == null ? '' : $data[5],
                                'state' => $data[7] == null ? '' : $data[7],
                                'errorMessage' => trans('「ラック_3」が選択されています。'),
                            ];
                            $errorCount++;
                        }
                    }

                    // ラック存在チェック
                    if (($rack1 == null || $rack1 == '') && ($rack2 == null || $rack2 == '') && ($rack3 == null || $rack3 == '')){
                        $errorList[] = [
                            'rowNum' => $rowNum + 1,
                            'productCode' => $data[4] == null ? '' : $data[4],
                            'productName' => $data[5] == null ? '' : $data[5],
                            'state' => $data[7] == null ? '' : $data[7],
                            'errorMessage' => trans('ラックが入力されています。'),
                        ];
                        $errorCount++;
                    }

                    // 「商品クラスマスタ」チェック
                    $productClass = $this->productClassRepository->findOneBy(['code' => $productCode]);
                    if (empty($productClass)) {
                        $errorList[] = [
                            'rowNum' => $rowNum + 1,
                            'productCode' => $data[4] == null ? '' : $data[4],
                            'productName' => $data[5] == null ? '' : $data[5],
                            'state' => $data[7] == null ? '' : $data[7],
                            'errorMessage' => trans('「商品クラスマスタ」に対応商品コードがありません'),
                        ];
                        $errorCount++;
                    }

                    // 「状態マスタ」チェック
                    $stateInfo = $this->stateRepository->find($stateId);
                    if (empty($stateInfo)) {
                        $errorList[] = [
                            'rowNum' => $rowNum + 1,
                            'productCode' => $data[4] == null ? '' : $data[4],
                            'productName' => $data[5] == null ? '' : $data[5],
                            'state' => $data[7] == null ? '' : $data[7],
                            'errorMessage' => trans('「状態マスタ」に対応状態がありません'),
                        ];
                        $errorCount++;
                    }

                    // エラーなし場合、データを更新する。
                    if ($errorCount == 0) {
                        $rackProduct = $this->RackProductRepository->findOneBy([
                            'productCode' => $productCode,
                            'state' => $stateId,
                        ]);

                        if($data[0] == '〇'){
                            // 新規の場合
                            if ($rackProduct == null){

                                $rackProduct = new rackProduct();

                                /** @var $Product Product */
                                $product = $this->productRepository->findProductsWithProductCode($productCode);

                                if (!empty($product) && !empty($product[0])) {
                                    $rackProduct->setProduct($product[0][0]);
                                    // 商品名
                                    $rackProduct->setProductName($data[5]);
                                }

                                /** @var $ProductClass ProductClass */
                                $ProductClass = $this->productClassRepository->findOneBy([
                                    'code' => $productCode
                                ]);

                                if (!empty($ProductClass)) {
                                    $rackProduct->setProductClass($ProductClass);
                                    // 商品コード
                                    $rackProduct->setProductCode($productCode);
                                }

                                /** @var $State State */
                                $State = $this->stateRepository->find($stateId);

                                if (!empty($State)) {
                                    $rackProduct->setState($State);
                                    // 状態名称
                                    $rackProduct->setStateName($State->getState());
                                }

                                // 作成者追加
                                $rackProduct->setCreateUserName($this->getUser());
                                $rackProduct->setUpdateUserName($this->getUser());
                            } else {
                                $rackProduct->setUpdateUserName($this->getUser());
                            }

                            if ($rack1 != null && $rack1 != '') {
                                if (!empty($entityRack1)) {
                                    $rackProduct->setRack1($entityRack1->getId());
                                } else {
                                    $rackProduct->setRack1(null);
                                }
                            } else {
                                $rackProduct->setRack1(null);
                            }

                            if ($rack2 != null && $rack2 != '') {
                                if (!empty($entityRack2)) {
                                    $rackProduct->setRack2($entityRack2->getId());
                                } else {
                                    $rackProduct->setRack2(null);
                                }
                            } else {
                                $rackProduct->setRack2(null);
                            }

                            if ($rack3 != null && $rack3 != '') {
                                if (!empty($entityRack3)) {
                                    $rackProduct->setRack3($entityRack3->getId());
                                } else {
                                    $rackProduct->setRack3(null);
                                }
                            } else {
                                $rackProduct->setRack3(null);
                            }

                            $this->entityManager->persist($rackProduct);
                            $this->entityManager->flush();

                            $normalCount++;

                        } elseif ($data[0] == '☓'){
                            $this->entityManager->remove($rackProduct);
                            $this->entityManager->flush();
                            $normalCount++;
                        }
                    }
                    // エラーがある場合、チェック続行。（ループ後、rollbackが必要です）
                    else {
                        continue;
                    }
                }

                $this->removeUploadedFile();

                if ($errorCount > 0) {
                    $this->entityManager->rollback();
                    return $this->json(['data' => $errorList]);
                } else {
                    if ($normalCount == 0) {
                        $this->addErrors('登録対象がありません');
                        return $this->renderWithError();
                    } else {
                        $this->entityManager->flush();
                        $this->addErrors('連動商品一括処理完了しました。');
                        return $this->renderWithError();
                    }
                }
            }
        }
    }

    /**
     * 登録、更新時のエラー画面表示
     */
    protected function addErrors($message)
    {
        $this->errors[] = $message;
    }

    /**
     * 登録、更新時のエラー画面表示
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     *
     * @throws \Doctrine\DBAL\ConnectionException
     */
    protected function renderWithError()
    {
        $this->removeUploadedFile();

        return $this->json([
            'errors' => $this->errors,
        ]);
    }
}
