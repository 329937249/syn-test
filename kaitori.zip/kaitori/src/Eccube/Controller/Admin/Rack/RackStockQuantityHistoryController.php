<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Rack;

use Eccube\Controller\AbstractController;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\CsvImportType;
use Eccube\Form\Type\Admin\SearchMemberType;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Service\CsvExportService;
use Eccube\Util\FormUtil;
use Eccube\Util\StringUtil;
use Knp\Component\Pager\Paginator;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\Routing\Annotation\Route;
use Eccube\Form\Type\Admin\RackStockQuantityHistoryType;
use Eccube\Repository\RockStockQuantityHistoryRepository;

/**
 *プログラム名 ： RackStockQuantityHistoryController.php
 *概　　要     ： 在庫数検査履歴照会
 *作　　成     ： 2022/10/28 CNC
 */
class RackStockQuantityHistoryController extends AbstractController
{
    /**
     * @var CsvExportService
     */
    protected $csvExportService;

    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;

    /**
     * @var RockStockQuantityHistoryRepository
     */
    protected $RockStockQuantityHistoryRepository;

    /**
     * ProductController constructor.
     *
     * @param PageMaxRepository $pageMaxRepository
     * @param RockStockQuantityHistoryRepository $RockStockQuantityHistoryRepository
     */
    public function __construct(
        PageMaxRepository $pageMaxRepository,
        RockStockQuantityHistoryRepository $RockStockQuantityHistoryRepository
    ) {
        $this->pageMaxRepository = $pageMaxRepository;
        $this->RockStockQuantityHistoryRepository = $RockStockQuantityHistoryRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/rack/rack_stock_quantity_history", name="admin_rack_stock_quantity_history")
     * @Route("/%eccube_admin_route%/rack/rack_stock_quantity_history/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_rack_stock_quantity_history_page")
     * @Template("@admin/Rack/rack_stock_quantity_history.twig")
     */
    public function index(Request $request, $page_no = null, Paginator $paginator)
    {
        $session = $this->session;
        $builder = $this->formFactory
            ->createBuilder(RackStockQuantityHistoryType::class, null);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_RACK_STOCK_QUANTITY_HISTORY_INDEX_INITIALIZE, $event);

        $pageMaxis = $this->pageMaxRepository->findAll();
        $pageCount = $session->get('eccube.admin.rack_stock_quantity_history.search.page_count', $this->eccubeConfig['eccube_default_page_count']);
        $pageCountParam = $request->get('page_count');
        if ($pageCountParam && is_numeric($pageCountParam)) {
            foreach ($pageMaxis as $pageMax) {
                if ($pageCountParam == $pageMax->getName()) {
                    $pageCount = $pageMax->getName();
                    $session->set('eccube.admin.rack_stock_quantity_history.search.page_count', $pageCount);
                    break;
                }
            }
        }
        $searchForm = $builder->getForm();

        $page_no_bk = $page_no;
        if ('POST' === $request->getMethod()) {
            $searchForm->handleRequest($request);
            if ($searchForm->isValid()) {
                $searchData = $searchForm->getData();
                $page_no = 1;

                $session->set('eccube.admin.rack_stock_quantity_history.search', FormUtil::getViewData($searchForm));
                $session->set('eccube.admin.rack_stock_quantity_history.search.page_no', $page_no);
            } else {
                return [
                    'form' => $searchForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $pageCount,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                if ($page_no) {
                    $session->set('eccube.admin.rack_stock_quantity_history.search.page_no', (int) $page_no);
                } else {
                    $page_no = $session->get('eccube.admin.rack_stock_quantity_history.search.page_no', 1);
                }
                $viewData = $session->get('eccube.admin.rack_stock_quantity_history.search', []);
            } else {
                $page_no = 1;
                $viewData = FormUtil::getViewData($searchForm);
                $viewData["check_date_end"] =  date('Y-m-d', strtotime('now'));
                $viewData["check_date_start"] =  date('Y-m-d', strtotime('now'));
                $session->set('eccube.admin.rack_stock_quantity_history.search', $viewData);
                $session->set('eccube.admin.rack_stock_quantity_history.search.page_no', $page_no);
            }
            $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
        }

        $qb = [];
        if ('POST' === $request->getMethod() || null !== $page_no_bk){
            /** @var QueryBuilder $qb */
            $qb = $this->getSearchData($searchData);
        }

        foreach ($qb as &$rack) {
            $rack['checked_date'] = $this->makeDateStringUtcToAsiaTokyo($rack['checked_date']);

            if($rack['check_classify_kubun'] === '1'){
                $rack['checked_stock_info'] = str_replace(',', "\r\n", $rack['checked_stock_info']);
                $rack['checked_rack_info'] = str_replace(',', "\r\n", $rack['checked_rack_info']);
            }
        }

        $event = new EventArgs(
            [
                'searchForm' => $searchForm,
                'qb' => $qb,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_RACK_STOCK_QUANTITY_HISTORY_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $qb,
            $page_no,
            $pageCount
        );
        return [
            'searchForm' => $searchForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $pageCount,
            'has_errors' => false,
        ];
    }

    /**
     * UTC時間を東京時間にする
     * @param string|null $date 時間文字列(yyyy-mm-dd HH:ii:ss)
     * @return string
     */
    public function makeDateStringUtcToAsiaTokyo(string $date = null)
    {
        if (!$date || $date !== date('Y-m-d H:i:s', strtotime($date))) {
            return '';
        }

        try {
            $date_utc = new \DateTime($date, new \DateTimeZone('UTC'));
            $date_asia_tokyo = $date_utc
                ->setTimezone(new \DateTimeZone('Asia/Tokyo'))
                ->format('Y/m/d H:i:s');
        } catch (\Exception $exception) {
            return '';
        }

        return $date_asia_tokyo;
    }


    public function getSearchData($searchData)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();

        $sql = "
                SELECT
                     DISTINCT rsqh.id
                    , rsqh.product_code AS product_code
                    , rsqh.state_id AS state_id
                    , rsqh.check_classify_kubun AS check_classify_kubun
                    , rsqh.result_classify_kubun AS result_classify_kubun
                    , rsqh.checked_user_name AS checked_user_name
                    , rsqh.checked_date AS checked_date
                    , rsqh.checked_stock_info AS checked_stock_info
                    , rsqh.checked_rack_info AS checked_rack_info
                    , rsqh.checked_diff_quantity AS checked_diff_quantity                    
                    , rp.product_name AS product_name                  
                    , rp.state_name AS state
                    , r1.rack_code AS rack_code1
                    , r2.rack_code AS rack_code2
                    , r3.rack_code AS rack_code3  
                FROM dtb_rack_stock_quantity_history rsqh
                    INNER JOIN dtb_rack_product rp
                        ON rsqh.product_code = rp.product_code
                        AND rsqh.state_id = rp.state_id
                    LEFT JOIN mtb_rack r1 
                        ON r1.id = rp.rack_1 
                    LEFT JOIN mtb_rack r2 
                        ON r2.id = rp.rack_2 
                    LEFT JOIN mtb_rack r3 
                        ON r3.id = rp.rack_3                      
                    WHERE TRUE";

        //checkClassify
        if (isset($searchData['checkClassify']) && StringUtil::isNotBlank($searchData['checkClassify'])) {
            $sql = $sql.' AND  rsqh.check_classify_kubun = '.$searchData['checkClassify']['id'];
        }

        //resultClaccify
        if (isset($searchData['resultClaccify']) && StringUtil::isNotBlank($searchData['resultClaccify'])) {
            $sql = $sql.' AND  rsqh.result_classify_kubun = '.$searchData['resultClaccify']['id'];
        }

        //product_code
        if (isset($searchData['product_code']) && StringUtil::isNotBlank($searchData['product_code'])) {
            $sql = $sql.' AND  rsqh.product_code LIKE '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['product_code']))."%'";
        }

        //rack
        if (isset($searchData['rack']) && StringUtil::isNotBlank($searchData['rack'])) {
            $sql .= ' AND (r1.rack_code like '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['rack']))."%'";
            $sql .= 'OR r2.rack_code like '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['rack']))."%'";
            $sql .= 'OR r3.rack_code like '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['rack']))."%')";
        }

        //check_date_start
        if (isset($searchData['check_date_start']) && StringUtil::isNotBlank($searchData['check_date_start'])) {
            /** @var \DateTime $check_date_start */
            $check_date_start = $searchData['check_date_start'];
            $checkDateStart = $check_date_start->setTime('0', '0', '0')
                ->setTimezone(new \DateTimeZone('UTC'))
                ->format('Y-m-d H:i:s');
            $sql = $sql.' AND  rsqh.checked_date >= \''.$checkDateStart.'\'';
        }

        //check_date_end
        if (isset($searchData['check_date_end']) && StringUtil::isNotBlank($searchData['check_date_end'])) {
            $check_date_end = $searchData['check_date_end'];
            $checkDateEnd = $check_date_end->setTime('23', '59', '59')
                ->setTimezone(new \DateTimeZone('UTC'))
                ->format('Y-m-d H:i:s');
            $sql = $sql.' AND  rsqh.checked_date <= \''.$checkDateEnd.'\'';
        }

        $sql = $sql.' ORDER BY
        rsqh.checked_date DESC
        ,rsqh.product_code
        ,rsqh.state_id ASC';

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    /**
     * シリアル別検査エラー結果出力.
     *
     * @Route("/%eccube_admin_route%/rack_stock_quantity_history/export/xlsx", name="admin_rack_stock_quantity_history_export_xlsx")
     *
     * @param Request $request Request
     *
     * @return StreamedResponse
     *
     * @throws \Exception
     */
    public function xlsxSerialExportOut(Request $request)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        ini_set('memory_limit', '2048M');

        $response = new StreamedResponse();
        $response->setCallback(function () use ($request) {

            // searchData
            $builder = $this->formFactory
                ->createBuilder(RackStockQuantityHistoryType::class);

            $event = new EventArgs(
                [
                    'builder' => $builder,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_LIST_INDEX_INITIALIZE, $event);

            $searchForm = $builder->getForm();

            $searchForm->handleRequest($request);

            $searchData = $searchForm->getData();
            // 明細開始行
            $count = 3;
            // xlsxファイル設定
            $xlsxPath = $this->eccubeConfig->get('eccube_html_dir') . '/template/admin/assets/xlsx/シリアル別検査エラー結果.xlsx';
            $spreadsheet = IOFactory::load($xlsxPath);

            $qb = $this->getSerialInfo($searchData);

            foreach ($qb as &$rack) {
                $rack['checked_date'] = $this->makeDateStringUtcToAsiaTokyo($rack['checked_date']);
            }

            foreach ($qb as $xlsxData) {

                $spreadsheet->setActiveSheetIndex(0)
                    ->setCellValue('C' . $count, $xlsxData["categoryname1"])
                    ->setCellValue('D' . $count, $xlsxData["categoryname2"])
                    ->setCellValue('E' . $count, $xlsxData["categoryname3"])
                    ->setCellValue('F' . $count, "\t" . $xlsxData["product_code"] . "\t")
                    ->setCellValue('G' . $count, $xlsxData["product_name"])
                    ->setCellValue('H' . $count, $xlsxData["state"])
                    ->setCellValue('I' . $count, $xlsxData["serial_no"])
                    ->setCellValue('J' . $count, $xlsxData["checked_user_name"])
                    ->setCellValue('K' . $count, $xlsxData["checked_date"])
                    ->setCellValue('L' . $count, '×');

                $count = $count + 1;
            }

            $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');

            $writer->save('php://output');
        });

        $sysDate = (new \DateTime())->format('YmdHis');
        $filename = 'attachment;filename="シリアル別検査エラー結果_' . $sysDate . '.xlsx"';

        $response->headers->set('Content-Disposition', $filename);
        header("Content-Type:application/force-download");
        header("Content-Type:application/vnd.ms-excel");
        header("Content-Type:application/octet-stream");
        header("Content-Type:application/download");
        header("Pragma: no-cache");

        $response->send();
        return $response;
    }

    public function getSerialInfo($searchData)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();

        $sql = "
                SELECT
                    rss.id
                    , rss.product_code AS product_code
                    , rss.state_id AS state_id
                    , rss.serial_no AS serial_no
                    , rss.checked_user_name AS checked_user_name
                    , rss.checked_date AS checked_date
                    , rp.product_name AS product_name                  
                    , rp.state_name AS state
                    , rsqh.check_classify_kubun AS check_classify_kubun
                    , rsqh.result_classify_kubun AS result_classify_kubun
                    , dc4.category_id AS category_id1
                    , dc4.categoryname AS categoryname1
                    , dc5.category_id AS category_id2
                    , dc5.categoryname AS categoryname2
                    , dc6.category_id AS category_id3
                    , dc6.categoryname AS categoryname3
                FROM dtb_rack_simple_serial rss
                    INNER JOIN dtb_rack_product rp
                        ON rss.product_code = rp.product_code
                        AND rss.state_id = rp.state_id
                    LEFT JOIN dtb_rack_stock_quantity_history rsqh
                        ON rsqh.product_code = rss.product_code
                        AND rsqh.state_id = rss.state_id 
                    LEFT JOIN mtb_rack r1 
                        ON r1.id = rp.rack_1 
                    LEFT JOIN mtb_rack r2 
                        ON r2.id = rp.rack_2 
                    LEFT JOIN mtb_rack r3 
                        ON r3.id = rp.rack_3
                    INNER JOIN ( 
                        SELECT
                            rss.id AS id
                            , slsu.product_class_id AS product_class_id
                            , slsu.product_id AS product_id
                            , dcs.category_name AS categoryname
                            , dcs.hierarchy AS hierarchy
                            , dpcs.category_id AS category_id
                        FROM
                             dtb_rack_simple_serial rss 
                            INNER JOIN dtb_stock_list_storehouse_unit slsu
                                ON rss.product_code = slsu.product_code
                                AND rss.state_id = slsu.state_id
                                AND rss.serial_no = slsu.serial_no
                            INNER JOIN dtb_product_class pc
                                ON slsu.product_class_id = pc.id
                            INNER JOIN dtb_product dps
                                ON pc.product_id = dps.id
                            INNER JOIN dtb_product_category dpcs
                                ON slsu.product_id = dpcs.product_id
                                AND dpcs.category_sub_flag <> 1
                            INNER JOIN dtb_category dcs 
                                ON dcs.id = dpcs.category_id
                    ) AS dc4 
                        ON dc4.id = rss.id
                        AND dc4.hierarchy = 1
                    LEFT JOIN (
                        SELECT
                            rss.id AS id
                            , slsu.product_class_id AS product_class_id
                            , slsu.product_id AS product_id
                            , dcs.category_name AS categoryname
                            , dcs.hierarchy AS hierarchy
                            , dpcs.category_id AS category_id 
                        FROM
                            dtb_rack_simple_serial rss
                            INNER JOIN dtb_stock_list_storehouse_unit slsu 
                                ON rss.product_code = slsu.product_code
                                AND rss.state_id = slsu.state_id
                                AND rss.serial_no = slsu.serial_no
                            INNER JOIN dtb_product_class pc
                                ON slsu.product_class_id = pc.id
                            INNER JOIN dtb_product dps 
                                ON pc.product_id = dps.id 
                            INNER JOIN dtb_product_category dpcs
                                ON slsu.product_id = dpcs.product_id 
                                AND dpcs.category_sub_flag <> 1
                            INNER JOIN dtb_category dcs 
                                ON dcs.id = dpcs.category_id
                    ) AS dc5 
                        ON dc5.id = rss.id
                        AND dc5.hierarchy = 2  
                    LEFT JOIN (
                        SELECT
                            rss.id AS id
                            , slsu.product_class_id AS product_class_id
                            , slsu.product_id AS product_id
                            , dcs.category_name AS categoryname
                            , dcs.hierarchy AS hierarchy
                            , dpcs.category_id AS category_id
                        FROM
                            dtb_rack_simple_serial rss
                            INNER JOIN dtb_stock_list_storehouse_unit slsu 
                                ON rss.product_code = slsu.product_code
                                AND rss.state_id = slsu.state_id
                                AND rss.serial_no = slsu.serial_no
                            INNER JOIN dtb_product_class pc
                                ON slsu.product_class_id = pc.id
                            INNER JOIN dtb_product dps 
                                ON pc.product_id = dps.id 
                            INNER JOIN dtb_product_category dpcs 
                                ON slsu.product_id = dpcs.product_id
                                AND dpcs.category_sub_flag <> 1
                            INNER JOIN dtb_category dcs
                                ON dcs.id = dpcs.category_id
                    ) AS dc6 
                        ON dc6.id = rss.id 
                        AND dc6.hierarchy = 3
                WHERE
                    rss.checked_flg = '0'";

        //checkClassify
        if (isset($searchData['checkClassify']) && StringUtil::isNotBlank($searchData['checkClassify'])) {
            $sql = $sql.' AND  rsqh.check_classify_kubun = '.$searchData['checkClassify']['id'];
        }

        //resultClaccify
        if (isset($searchData['resultClaccify']) && StringUtil::isNotBlank($searchData['resultClaccify'])) {
            $sql = $sql.' AND  rsqh.result_classify_kubun = '.$searchData['resultClaccify']['id'];
        }

        //product_code
        if (isset($searchData['product_code']) && StringUtil::isNotBlank($searchData['product_code'])) {
            $sql = $sql.' AND  rss.product_code LIKE '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['product_code']))."%'";
        }

        //rack
        if (isset($searchData['rack']) && StringUtil::isNotBlank($searchData['rack'])) {
            $sql .= ' AND (r1.rack_code like '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['rack']))."%'";
            $sql .= 'OR r2.rack_code like '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['rack']))."%'";
            $sql .= 'OR r3.rack_code like '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['rack']))."%')";
        }

        //check_date_start
        if (isset($searchData['check_date_start']) && StringUtil::isNotBlank($searchData['check_date_start'])) {
            /** @var \DateTime $check_date_start */
            $check_date_start = $searchData['check_date_start'];
            $checkDateStart = $check_date_start->setTime('0', '0', '0')
                ->setTimezone(new \DateTimeZone('UTC'))
                ->format('Y-m-d H:i:s');
            $sql = $sql.' AND  rss.checked_date >= \''.$checkDateStart.'\'';
        }

        //check_date_end
        if (isset($searchData['check_date_end']) && StringUtil::isNotBlank($searchData['check_date_end'])) {
            $check_date_end = $searchData['check_date_end'];
            $checkDateEnd = $check_date_end->setTime('23', '59', '59')
                ->setTimezone(new \DateTimeZone('UTC'))
                ->format('Y-m-d H:i:s');
            $sql = $sql.' AND  rss.checked_date <= \''.$checkDateEnd.'\'';
        }

        $sql = $sql.' GROUP BY 
        rss.state_id
        ,rss.product_code
        ,rss.serial_no
        ORDER BY
        rss.checked_date DESC
        ,rss.product_code
        ,rss.state_id 
        ,rss.serial_no ASC
        ';

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }
}
