<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Rack;

use Doctrine\DBAL\Exception\ForeignKeyConstraintViolationException;
use Eccube\Controller\AbstractController;
use Eccube\Entity\Product;
use Eccube\Entity\ProductClass;
use Eccube\Entity\Rack;
use Eccube\Entity\RackProduct;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\AddCartType;
use Eccube\Form\Type\Admin\RackProductNewType;
use Eccube\Form\Type\Admin\SearchProductType;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\RackLoginRepository;
use Eccube\Repository\RackProductRepository;
use Eccube\Repository\StateRepository;
use Eccube\Util\CacheUtil;
use Knp\Component\Pager\Paginator;
use Monolog\Handler\IFTTTHandler;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Twig_Environment;
use Eccube\Common\Constant;

/**
*プログラム名 ： RackProductNewController.php
*概　　要     ： 商品ラック登録
*作　　成     ： 2022/09/21 CNC
*/
class RackProductNewController extends AbstractController
{
    // 一覧画面URL
    const PREVIOUS_PAGE_URL_LIST = 'rack_product/rack_product_list';

    /**
     * @var Twig_Environment
     */
    protected $twig;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var ProductClassRepository
     */
    protected $productClassRepository;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var StateRepository
     */
    protected $StateRepository;

    /**
     * @var RackProductRepository
     */
    protected $RackProductRepository;

    /**
     * @var RackLoginRepository
     */
    protected $RackLoginRepository;


    /**
     * ProductNewController constructor.
     * @param Twig_Environment $twig
     * @param ProductRepository $productRepository
     * @param ProductClassRepository $productClassRepository
     * @param CategoryRepository $categoryRepository
     * @param StateRepository $StateRepository
     * @param RackProductRepository $RackProductRepository
     * @param RackLoginRepository $RackLoginRepository
     */
    public function __construct(
        Twig_Environment $twig,
        ProductRepository $productRepository,
        ProductClassRepository $productClassRepository,
        CategoryRepository $categoryRepository,
        StateRepository $StateRepository,
        RackProductRepository $RackProductRepository,
        RackLoginRepository $RackLoginRepository
    )
    {
        $this->twig = $twig;
        $this->productRepository = $productRepository;
        $this->productClassRepository = $productClassRepository;
        $this->categoryRepository = $categoryRepository;
        $this->StateRepository = $StateRepository;
        $this->RackProductRepository = $RackProductRepository;
        $this->RackLoginRepository = $RackLoginRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/rack/rack_product", name="admin_rack_product")
     * @Route("/%eccube_admin_route%/rack/rack_product/edit/{id}", requirements={"id" = "\d+"}, name="admin_rack_product_edit")
     * @Template("@admin/Rack/rack_product_new.twig")
     *
     * @param Request $request
     * @param CacheUtil $cacheUtil
     * @param null $id
     *
     * @return array|RedirectResponse
     * @throws \Exception
     */
    public function index(Request $request, CacheUtil $cacheUtil, $id = null)
    {
        // 前ページurl
        if (strpos($request->headers->get('referer'), self::PREVIOUS_PAGE_URL_LIST)) {
            $link = 1;
        } else {
            $link = 0;
        }

        // 新規登録
        if($id == null){
            $rackProduct = new RackProduct();

            $update_date = null;
            $update_User_Name = null;
        } else {
            // 連動商品
            $rackProduct = $this->RackProductRepository->find($id);

            // 更新情報取得
            $update_date = $rackProduct->getUpdateDate()->format('Y/m/d H:i:s');
            $update_User_Name = $rackProduct->getUpdateUserName();

            if (!is_null($rackProduct->getRack1())){
                $rackCode1 = $this->RackLoginRepository->find($rackProduct->getRack1());
                if (isset($rackCode1)){
                    $rackProduct->setRack1($rackCode1->getRackCode());
                } else {
                    $rackProduct->setRack1(null);
                }
            }

            if (!is_null($rackProduct->getRack2())){
                $rackCode2 = $this->RackLoginRepository->find($rackProduct->getRack2());
                if (isset($rackCode2)){
                    $rackProduct->setRack2($rackCode2->getRackCode());
                } else {
                    $rackProduct->setRack2(null);
                }
            }

            if (!is_null($rackProduct->getRack3())){
                $rackCode3 = $this->RackLoginRepository->find($rackProduct->getRack3());
                if (isset($rackCode3)){
                    $rackProduct->setRack3($rackCode3->getRackCode());
                } else {
                    $rackProduct->setRack3(null);
                }
            }
        }

        // 商品選択フォーム
        $builder = $this->formFactory
            ->createBuilder(SearchProductType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_RACK_PRODUCT_NEW_SEARCH_PRODUCT_INITIALIZE, $event);

        $searchProductModalForm = $builder->getForm();

        // 連動商品フォーム
        $builder = $this->formFactory->createBuilder(RackProductNewType::class, $rackProduct);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'rackProduct' => $rackProduct,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_RACK_PRODUCT_NEW_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();

        $form->handleRequest($request);

        if (!is_null($productCode = $rackProduct->getProductCode())) {
            /** @var $Product Product */
            $product = $this->productRepository->findProductsWithProductCode($productCode = $rackProduct->getProductCode());

            if (!empty($product) && !empty($product[0])) {
                /** @var Product $entity_product */
                $category_id = $product[0]['category_id'];
            } else {
                $category_id = null;
            }
        } else {
            $category_id = null;
        }

        // 状態
        $entity_state = $this->StateRepository->getStateByCategory();

        // 更新者にログインユーザー設定
        $rackProduct->setUpdateUserName($this->getUser());

        if ($form->isSubmitted() && $form->isValid()) {

            if($id == null) {
                $entity_rackProduct = $this->RackProductRepository->findBy([
                    'productCode' => $rackProduct->getProductCode(),
                    'state' => $rackProduct->getState()
                ]);

                if (isset($entity_rackProduct[0])) {
                    $this->addError('admin.rack.product_already_exist', 'admin');

                    return $this->redirectToRoute('admin_rack_product_list');
                }

                /** @var $Product Product */
                $product = $this->productRepository->findProductsWithProductCode($rackProduct->getProductCode());

                if (!empty($product) && !empty($product[0])) {
                    $rackProduct->setProduct($product[0][0]);
                }

                /** @var $ProductClass ProductClass */
                $ProductClass = $this->productClassRepository->findOneBy([
                    'code' => $rackProduct->getProductCode()
                ]);

                if (!empty($ProductClass)) {
                    $rackProduct->setProductClass($ProductClass);
                }

                // 状態名称
                $rackProduct->setStateName($rackProduct->getState()->getState());

                // 作成者追加
                $rackProduct->setCreateUserName($this->getUser());
            }

            if (!is_null($rackProduct->getRack1()))
            {
                /** @var $Rack1 Rack */
                $Rack1 = $this->RackLoginRepository->findOneBy([
                    'rack_code' => $rackProduct->getRack1()
                ]);

                if (!empty($Rack1)) {
                    $rackProduct->setRack1($Rack1->getId());
                }
            }

            if (!is_null($rackProduct->getRack2()))
            {
                /** @var $Rack2 Rack */
                $Rack2 = $this->RackLoginRepository->findOneBy([
                    'rack_code' => $rackProduct->getRack2()
                ]);

                if (!empty($Rack2)) {
                    $rackProduct->setRack2($Rack2->getId());
                }
            }

            if (!is_null($rackProduct->getRack3())) {
                /** @var $Rack3 Rack */
                $Rack3 = $this->RackLoginRepository->findOneBy([
                    'rack_code' => $rackProduct->getRack3()
                ]);

                if (!empty($Rack3)) {
                    $rackProduct->setRack3($Rack3->getId());
                }
            }

            $this->entityManager->persist($rackProduct);
            $this->entityManager->flush();

            $event = new EventArgs(
                [
                    'form' => $form,
                    'rackProduct' => $rackProduct,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(
                EccubeEvents::ADMIN_RACK_PRODUCT_NEW_INDEX_COMPLETE,
                $event
            );

            // キャッシュの削除
            $cacheUtil->clearDoctrineCache();

            $this->addSuccess('admin.common.save_complete', 'admin');

            return $this->redirectToRoute('admin_rack_product_edit', ['id' => $rackProduct->getId()]);
        }

        return [
            'form' => $form->createView(),
            'searchProductModalForm' => $searchProductModalForm->createView(),
            'StateList' => $entity_state,
            'id' => $id,
            'update_date' => $update_date,
            'update_user_name' => $update_User_Name,
            'link' => $link,
            'category_id' => $category_id,
        ];
    }

    /**
     * @Route("//%eccube_admin_route%/rack/search/productName", name="admin_rack_new_product_search_product")
     * @param Request $request リクエスト
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchProductNew(Request $request)
    {
        $product_code = $request->get('code');

        log_info('Admin Rack searchProduct', [$product_code]);

        // 商品取得
        $array_entity_product = $this->productRepository->findProductsWithProductCode($product_code);

        $event = new EventArgs(
            [
                'ProductCode' => $product_code,
                'Product' => $array_entity_product,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_RACK_SEARCH_PRODUCT_SEARCH, $event);

        if (!empty($array_entity_product) && !empty($array_entity_product[0])) {
            /** @var Product $entity_product */
            $entity_product = $array_entity_product[0][0];
            $data = [
                'target_product_id' => $entity_product->getId(),
                'target_product_name' => $entity_product->getName(),
                'target_product_serial_flg' => ($entity_product->getSerialFlg() ? '1' : '0'),
                'target_product_category_id' => $array_entity_product[0]['category_id'],
                'target_product_class_id' => $entity_product->getProductClasses()[0]->getId(),
            ];
        } else {
            log_debug('search product by code not found.');
            return $this->json([], 404);
        }

        $event = new EventArgs(
            [
                'ProductCode' => $product_code,
                'Product' => $entity_product,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_RACK_SEARCH_PRODUCT_COMPLETE, $event);

        return $this->json($data);
    }

    /**
     *  商品選択
     *
     * @Route("/%eccube_admin_route%/rack/search/product", name="admin_rack_search_product")
     * @Route("/%eccube_admin_route%/rack/search/product/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_rack_search_product_page")
     * @Template("@admin/Rack/search_product.twig")
     * @param Request $request
     * @param null $page_no
     * @param Paginator $paginator
     * @return array
     */
    public function searchProduct(Request $request, $page_no = null, Paginator $paginator)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('search product start.');
            $page_count = $this->eccubeConfig['eccube_default_page_count'];
            $session = $this->session;

            if ('POST' === $request->getMethod()) {
                $page_no = 1;

                $searchData = [
                    'id' => $request->get('id'),
                ];

                if ($categoryId = $request->get('category_id')) {
                    $Category = $this->categoryRepository->find($categoryId);
                    $searchData['category_id'] = $Category;
                }

                $session->set('eccube.admin.rack.product.search', $searchData);
                $session->set('eccube.admin.rack.product.search.page_no', $page_no);
            } else {
                $searchData = (array) $session->get('eccube.admin.rack.product.search');
                if (is_null($page_no)) {
                    $page_no = intval($session->get('eccube.admin.rack.product.search.page_no'));
                } else {
                    $session->set('eccube.admin.rack.product.search.page_no', $page_no);
                }
            }

            $qb = $this->productRepository
                ->getQueryBuilderBySearchDataForAdmin($searchData);

            $event = new EventArgs(
                [
                    'qb' => $qb,
                    'searchData' => $searchData,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_RACK_SEARCH_PRODUCT_SEARCH, $event);

            /** @var \Knp\Component\Pager\Pagination\SlidingPagination $pagination */
            $pagination = $paginator->paginate(
                $qb,
                $page_no,
                $page_count,
                ['wrap-queries' => true]
            );

            /** @var $Products Product[] */
            $Products = $pagination->getItems();

            if (empty($Products)) {
                log_debug('search product not found.');
            }

            $forms = [];
            foreach ($Products as $Product) {
                /* @var $builder \Symfony\Component\Form\FormBuilderInterface */
                $builder = $this->formFactory->createNamedBuilder('', AddCartType::class, null, [
                    'product' => $this->productRepository->findWithSortedClassCategories($Product->getId()),
                ]);
                $addCartForm = $builder->getForm();
                $forms[$Product->getId()] = $addCartForm->createView();
            }

            $event = new EventArgs(
                [
                    'forms' => $forms,
                    'Products' => $Products,
                    'pagination' => $pagination,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_RACK_SEARCH_PRODUCT_COMPLETE, $event);

            return [
                'forms' => $forms,
                'Products' => $Products,
                'pagination' => $pagination,
            ];
        }
    }

    /**
     *  伝票更新時間取得
     *
     * @Route("/%eccube_admin_route%/rack/search/date", name="admin_rack_product_search_date")
     * @param Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchOrderUpdateDate(Request $request, Paginator $paginator)
    {
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
        }

        $result = [];
        $id = $request->get('id');

        if (!is_null($id)) {
            $rackProduct = $this->RackProductRepository->find($id);
            if ($rackProduct) {
                $UpdateTimeNew = $rackProduct->getUpdateDate()->format('Y/m/d H:i:s');
                $result['UpdateTimeNew'] = $UpdateTimeNew;
            } else {
                $result['UpdateTimeNew'] = "";
            }
        }

        return $this->json(array_merge(['status' => 'OK'], $result));
    }

    /**
     * 商品ラック削除
     * @Route("/%eccube_admin_route%/rack/{id}/delete", requirements={"id" = "\d+"}, name="admin_rack_product_delete", methods={"DELETE"})
     * @param Request $request Request
     * @param int|null $id ID
     * @param CacheUtil|null $cacheUtil CacheUtil
     * @return \Symfony\Component\HttpFoundation\JsonResponse|RedirectResponse
     * @throws \Exception
     */
    public function delete(Request $request, int $id = null, CacheUtil $cacheUtil = null)
    {
        $this->isTokenValid();
        $session = $request->getSession();
        $page_no = intval($session->get('eccube.admin.rack.search.page_count'));
        $page_no = $page_no ? $page_no : Constant::ENABLED;
        $message = null;
        $success = false;
        $member = $this->getUser();

        if (!is_null($id)) {
            /** @var RackProduct $rackProduct */
            $rackProduct = $this->RackProductRepository->find($id);
            if (!$rackProduct) {
                if ($request->isXmlHttpRequest()) {
                    $message = trans('admin.common.delete_error_already_deleted');

                    return $this->json(['success' => $success, 'message' => $message]);
                } else {
                    $this->deleteMessage();
                    $rUrl = $this->generateUrl('admin_rack_product_list', ['page_no' => $page_no]).'?resume='.Constant::ENABLED;

                    return $this->redirect($rUrl);
                }
            }

            if ($rackProduct instanceof RackProduct) {
                log_info('商品ラック削除開始', [$id]);

                try {
                    $this->RackProductRepository->delete($rackProduct);
                    $this->entityManager->flush();

                    $event = new EventArgs(
                        [
                            'RackProduct' => $rackProduct,
                        ],
                        $request
                    );
                    $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_DELETE_COMPLETE, $event);

                    log_info('商品ラック削除完了', [$id]);

                    $success = true;
                    $message = trans('admin.common.delete_complete');

                    $cacheUtil->clearDoctrineCache();
                } catch (ForeignKeyConstraintViolationException $e) {
                    log_info('商品ラックー削除エラー', [$id]);
                    $message = trans('admin.common.delete_error_foreign_key', ['%name%' => $rackProduct->getId()]);
                } catch (\Exception $e) {
                    log_info('商品ラックー削除エラー', [$id]);
                    $message = trans('admin.common.delete_error');
                }
            } else {
                log_info('商品ラックー削除エラー', [$id]);
                $message = trans('admin.common.delete_error');
            }
        } else {
            log_info('商品ラックー削除エラー', [$id]);
            $message = trans('admin.common.delete_error');
        }

        if ($request->isXmlHttpRequest()) {
            return $this->json(['success' => $success, 'message' => $message]);
        } else {
            if ($success) {
                $this->addSuccess($message, 'admin');
                $rUrl = $this->generateUrl('admin_rack_product_list', ['page_no' => $page_no]).'?resume='.Constant::ENABLED;
            } else {
                $this->addError($message, 'admin');
                $rUrl = $this->generateUrl('admin_rack_product_edit', ['id' => $id]);
            }

            return $this->redirect($rUrl);
        }
    }
}
