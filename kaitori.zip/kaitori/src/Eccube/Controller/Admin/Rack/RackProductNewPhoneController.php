<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Rack;

use Doctrine\DBAL\Exception\ForeignKeyConstraintViolationException;
use Eccube\Controller\AbstractController;
use Eccube\Entity\Product;
use Eccube\Entity\ProductClass;
use Eccube\Entity\Rack;
use Eccube\Entity\RackProduct;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\AddCartType;
use Eccube\Form\Type\Admin\RackProductNewType;
use Eccube\Form\Type\Admin\SearchProductType;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\RackLoginRepository;
use Eccube\Repository\RackProductRepository;
use Eccube\Repository\StateRepository;
use Eccube\Util\CacheUtil;
use Knp\Component\Pager\Paginator;
use Monolog\Handler\IFTTTHandler;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Twig_Environment;
use Eccube\Common\Constant;

/**
*プログラム名 ： RackProductNewPhoneController.php
*概　　要     ： 商品ラック登録(フォン)
*作　　成     ： 2022/11/16 CNC
*/
class RackProductNewPhoneController extends AbstractController
{
    /**
     * @var Twig_Environment
     */
    protected $twig;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var ProductClassRepository
     */
    protected $productClassRepository;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var StateRepository
     */
    protected $StateRepository;

    /**
     * @var RackProductRepository
     */
    protected $RackProductRepository;

    /**
     * @var RackLoginRepository
     */
    protected $RackLoginRepository;


    /**
     * RackProductNewPhoneController constructor.
     * @param Twig_Environment $twig
     * @param ProductRepository $productRepository
     * @param ProductClassRepository $productClassRepository
     * @param CategoryRepository $categoryRepository
     * @param StateRepository $StateRepository
     * @param RackProductRepository $RackProductRepository
     * @param RackLoginRepository $RackLoginRepository
     */
    public function __construct(
        Twig_Environment $twig,
        ProductRepository $productRepository,
        ProductClassRepository $productClassRepository,
        CategoryRepository $categoryRepository,
        StateRepository $StateRepository,
        RackProductRepository $RackProductRepository,
        RackLoginRepository $RackLoginRepository
    )
    {
        $this->twig = $twig;
        $this->productRepository = $productRepository;
        $this->productClassRepository = $productClassRepository;
        $this->categoryRepository = $categoryRepository;
        $this->StateRepository = $StateRepository;
        $this->RackProductRepository = $RackProductRepository;
        $this->RackLoginRepository = $RackLoginRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/rack/rack_product_phone", name="admin_rack_product_phone")
     * @Route("/%eccube_admin_route%/rack/rack_product_phone/edit/{id}", requirements={"id" = "\d+"}, name="admin_rack_product_edit_phone")
     * @Template("@admin/Rack/rack_product_new_phone.twig")
     *
     * @param Request $request
     * @param CacheUtil $cacheUtil
     * @param null $id
     *
     * @return array|RedirectResponse
     * @throws \Exception
     */
    public function index(Request $request, CacheUtil $cacheUtil, $id = null)
    {
        // 新規登録
        if($id == null){
            $rackProduct = new RackProduct();

            $update_date = null;
            $update_User_Name = null;
        } else {
            // 連動商品
            $rackProduct = $this->RackProductRepository->find($id);

            // 更新情報取得
            $update_date = $rackProduct->getUpdateDate()->format('Y/m/d H:i:s');
            $update_User_Name = $rackProduct->getUpdateUserName();

            if (!is_null($rackProduct->getRack1())){
                $rackCode1 = $this->RackLoginRepository->find($rackProduct->getRack1());
                if (isset($rackCode1)){
                    $rackProduct->setRack1($rackCode1->getRackCode());
                } else {
                    $rackProduct->setRack1(null);
                }
            }

            if (!is_null($rackProduct->getRack2())){
                $rackCode2 = $this->RackLoginRepository->find($rackProduct->getRack2());
                if (isset($rackCode2)){
                    $rackProduct->setRack2($rackCode2->getRackCode());
                } else {
                    $rackProduct->setRack2(null);
                }
            }

            if (!is_null($rackProduct->getRack3())){
                $rackCode3 = $this->RackLoginRepository->find($rackProduct->getRack3());
                if (isset($rackCode3)){
                    $rackProduct->setRack3($rackCode3->getRackCode());
                } else {
                    $rackProduct->setRack3(null);
                }
            }
        }

        // 商品選択フォーム
        $builder = $this->formFactory
            ->createBuilder(SearchProductType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_RACK_PRODUCT_NEW_SEARCH_PRODUCT_INITIALIZE, $event);

        $searchProductModalForm = $builder->getForm();

        // 連動商品フォーム
        $builder = $this->formFactory->createBuilder(RackProductNewType::class, $rackProduct);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'rackProduct' => $rackProduct,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_RACK_PRODUCT_NEW_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();

        $form->handleRequest($request);

        if (!is_null($productCode = $rackProduct->getProductCode())) {
            /** @var $Product Product */
            $product = $this->productRepository->findProductsWithProductCode($productCode = $rackProduct->getProductCode());

            if (!empty($product) && !empty($product[0])) {
                /** @var Product $entity_product */
                $category_id = $product[0]['category_id'];
            } else {
                $category_id = null;
            }
        } else {
            $category_id = null;
        }

        // 状態
        $entity_state = $this->StateRepository->getStateByCategory();

        // 更新者にログインユーザー設定
        $rackProduct->setUpdateUserName($this->getUser());

        if ($form->isSubmitted() && $form->isValid()) {

            if($id == null) {
                $entity_rackProduct = $this->RackProductRepository->findBy([
                    'productCode' => $rackProduct->getProductCode(),
                    'state' => $rackProduct->getState()
                ]);

                if (isset($entity_rackProduct[0])) {
                    $this->addError('admin.rack.product_already_exist', 'admin');

                    return $this->redirectToRoute('admin_rack_product_list');
                }

                /** @var $Product Product */
                $product = $this->productRepository->findProductsWithProductCode($rackProduct->getProductCode());

                if (!empty($product) && !empty($product[0])) {
                    $rackProduct->setProduct($product[0][0]);
                }

                /** @var $ProductClass ProductClass */
                $ProductClass = $this->productClassRepository->findOneBy([
                    'code' => $rackProduct->getProductCode()
                ]);

                if (!empty($ProductClass)) {
                    $rackProduct->setProductClass($ProductClass);
                }

                // 状態名称
                $rackProduct->setStateName($rackProduct->getState()->getState());

                // 作成者追加
                $rackProduct->setCreateUserName($this->getUser());
            }

            if (!is_null($rackProduct->getRack1()))
            {
                /** @var $Rack1 Rack */
                $Rack1 = $this->RackLoginRepository->findOneBy([
                    'rack_code' => $rackProduct->getRack1()
                ]);

                if (!empty($Rack1)) {
                    $rackProduct->setRack1($Rack1->getId());
                }
            }

            if (!is_null($rackProduct->getRack2()))
            {
                /** @var $Rack2 Rack */
                $Rack2 = $this->RackLoginRepository->findOneBy([
                    'rack_code' => $rackProduct->getRack2()
                ]);

                if (!empty($Rack2)) {
                    $rackProduct->setRack2($Rack2->getId());
                }
            }

            if (!is_null($rackProduct->getRack3())) {
                /** @var $Rack3 Rack */
                $Rack3 = $this->RackLoginRepository->findOneBy([
                    'rack_code' => $rackProduct->getRack3()
                ]);

                if (!empty($Rack3)) {
                    $rackProduct->setRack3($Rack3->getId());
                }
            }

            $this->entityManager->persist($rackProduct);
            $this->entityManager->flush();

            $event = new EventArgs(
                [
                    'form' => $form,
                    'rackProduct' => $rackProduct,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(
                EccubeEvents::ADMIN_RACK_PRODUCT_NEW_INDEX_COMPLETE,
                $event
            );

            // キャッシュの削除
            $cacheUtil->clearDoctrineCache();

            $this->addSuccess('admin.common.save_complete', 'admin');

            return $this->redirectToRoute('admin_rack_product_edit_phone', ['id' => $rackProduct->getId()]);
        }

        return [
            'form' => $form->createView(),
            'searchProductModalForm' => $searchProductModalForm->createView(),
            'StateList' => $entity_state,
            'id' => $id,
            'update_date' => $update_date,
            'update_user_name' => $update_User_Name,
            'category_id' => $category_id,
        ];
    }
}
