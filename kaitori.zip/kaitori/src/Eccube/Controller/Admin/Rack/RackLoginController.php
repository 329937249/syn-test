<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Rack;

use Eccube\Controller\AbstractController;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\AddCartType;
use Eccube\Form\Type\Admin\RackLoginType;
use Eccube\Util\CacheUtil;
use Knp\Component\Pager\Paginator;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Twig_Environment;
use Eccube\Common\Constant;
use Doctrine\DBAL\Exception\ForeignKeyConstraintViolationException;
use Eccube\Entity\Rack;
use Eccube\Repository\RackLoginRepository;

/**
*プログラム名 ： RackLoginController.php
*概　　要     ： 商品ラック登録
*作　　成     ： 2022/9/16 CNC
*/
class RackLoginController extends AbstractController
{
    // 一覧画面URL
    const PREVIOUS_PAGE_URL_LIST = 'rack/rack_list';

    /**
     * @var Twig_Environment
     */
    protected $twig;

    /**
     * @var RackLoginRepository
     */
    protected $rackLoginRepository;

    /**
     * ProductNewController constructor.
     * @param RackLoginRepository $rackLoginRepository
     */
    public function __construct(
        Twig_Environment $twig,
        RackLoginRepository $rackLoginRepository
    )
    {
        $this->twig = $twig;
        $this->rackLoginRepository = $rackLoginRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/rack/rack_login", name="admin_rack_edit")
     * @Route("/%eccube_admin_route%/rack/rack_login/edit/{id}", requirements={"id" = "\d+"}, name="admin_rack_edit_edit")
     * @Template("@admin/Rack/rack_login.twig")
     *
     * @param Request $request
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function index(Request $request, $id = null)
    {
        // 前ページurl
        if (strpos($request->headers->get('referer'), self::PREVIOUS_PAGE_URL_LIST)) {
            $link = 1;
        } else {
            $link = 0;
        }

        // 新規登録
        if ($id == null) {
            $rack = new Rack();

            // 更新情報未設定
            $update_date = null;
            $update_User_Name = null;
            // 作成者追加
            $rack->setCreateUserName($this->getUser());
            $rack->setUpdateUserName($this->getUser());
        } else {
            // 連動商品
            $rack = $this->rackLoginRepository->find($id);

            // 更新情報取得
            $update_date = $rack->getUpdateDate()->format('Y/m/d H:i:s');
            $update_User_Name = $rack->getUpdateUserName();
        }

        // 連動商品フォーム
        $builder = $this->formFactory->createBuilder(RackLoginType::class, $rack);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'rack' => $rack,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_RACK_NEW_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            if ($id == null){
                $chkRackState = $this->rackLoginRepository->findBy(
                    [
                        'rack_code' => $rack->getRackCode(),
                    ]);

                if (isset($chkRackState) && isset($chkRackState[0])) {
                    $this->addError('admin.rack.rack_product_code_no', 'admin');
                    return $this->redirectToRoute('admin_rack_list');
                }
            }

            $this->entityManager->persist($rack);
            $this->entityManager->flush();

            $event = new EventArgs(
                [
                    'form' => $form,
                    'rack' => $rack,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(
                EccubeEvents::ADMIN_RACK_NEW_INDEX_INITIALIZE,
                $event
            );

            $this->addSuccess('admin.common.save_complete', 'admin');

            return $this->redirectToRoute('admin_rack_edit_edit', ['id' => $rack->getId()]);
        }

        return [
            'form' => $form->createView(),
            'id' => $id,
            'link' => $link,
            'update_date' => $update_date,
            'update_user_name' => $update_User_Name,
        ];
    }

    /**
     *  伝票更新時間取得
     *
     * @Route("/%eccube_admin_route%/product_management/search/date", name="admin_rack_search_date")
     * @param Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchOrderUpdateDate(Request $request, Paginator $paginator)
    {
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
        }

        $result = [];
        $id = $request->get('headerId');

        if (!is_null($id)) {
            $entity_rack_header = $this->rackLoginRepository->find($id);
            if ($entity_rack_header) {
                $orderUpdateTimeNew = $entity_rack_header->getUpdateDate()->format('Y-m-d H:i:s');
                $result['orderUpdateTimeNew'] = $orderUpdateTimeNew;
            } else {
                $result['orderUpdateTimeNew'] = "";
            }
        }

        return $this->json(array_merge(['status' => 'OK'], $result));
    }

    /**
     * ヘッダー削除
     * @Route("/%eccube_admin_route%/rack/rack_login/{id}/delete", requirements={"id" = "\d+"}, name="admin_rack_delete", methods={"DELETE"})
     * @param Request $request Request
     * @param int|null $id ID
     * @param CacheUtil|null $cacheUtil CacheUtil
     * @return \Symfony\Component\HttpFoundation\JsonResponse|RedirectResponse
     * @throws \Exception
     */
    public function delete(Request $request, int $id = null, CacheUtil $cacheUtil = null)
    {
        $this->isTokenValid();
        $session = $request->getSession();
        $page_no = intval($session->get('eccube.admin.rack.search.page_count'));
        $page_no = $page_no ? $page_no : Constant::ENABLED;
        $message = null;
        $success = false;

        if (!is_null($id)) {
            /** @var Rack $entity_rack_header */
            $entity_rack_header = $this->rackLoginRepository->find($id);
            if (!$entity_rack_header) {
                if ($request->isXmlHttpRequest()) {
                    $message = trans('admin.common.delete_error_already_deleted');

                    return $this->json(['success' => $success, 'message' => $message]);
                } else {
                    $this->deleteMessage();
                    $rUrl = $this->generateUrl('admin_rack_product_list', ['page_no' => $page_no]).'?resume='.Constant::ENABLED;

                    return $this->redirect($rUrl);
                }
            }

            if ($entity_rack_header instanceof Rack) {
                log_info('ラック削除開始', [$id]);

                try {

                    $this->rackLoginRepository->delete($entity_rack_header);
                    $this->entityManager->flush();


                    log_info('ラック削除完了', [$id]);

                    $success = true;
                    $message = trans('admin.common.delete_complete');

                    $cacheUtil->clearDoctrineCache();
                } catch (ForeignKeyConstraintViolationException $e) {
                    log_info('ラック削除エラー', [$id]);
                    $message = trans('admin.common.delete_error_foreign_key', ['%name%' => $entity_rack_header->getRackCode()]);
                } catch (\Exception $e) {
                    log_info('ラック削除エラー', [$id]);
                    $message = trans('admin.common.delete_error');
                }
            } else {
                log_info('ラック削除エラー', [$id]);
                $message = trans('admin.common.delete_error');
            }
        } else {
            log_info('ラック削除エラー', [$id]);
            $message = trans('admin.common.delete_error');
        }

        if ($request->isXmlHttpRequest()) {
            return $this->json(['success' => $success, 'message' => $message]);
        } else {
            if ($success) {
                $this->addSuccess($message, 'admin');
                $rUrl = $this->generateUrl('admin_rack_list', ['page_no' => $page_no]).'?resume='.Constant::ENABLED;
            } else {
                $this->addError($message, 'admin');
                $rUrl = $this->generateUrl('admin_rack_edit_edit', ['id' => $id]);
            }

            return $this->redirect($rUrl);
        }
    }
}
