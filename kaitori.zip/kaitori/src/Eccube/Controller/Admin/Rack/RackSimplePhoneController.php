<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Rack;

use Doctrine\DBAL\Exception\ForeignKeyConstraintViolationException;
use Eccube\Controller\AbstractController;
use Eccube\Entity\RackProduct;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\RackSimplePhoneType;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\RackProductRepository;
use Eccube\Repository\StateRepository;
use Eccube\Repository\StockListStorehouseUnitRepository;
use Eccube\Util\CacheUtil;
use Eccube\Util\StringUtil;
use Knp\Component\Pager\Paginator;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Twig_Environment;
use Eccube\Common\Constant;

/**
*プログラム名 ： RackSimplePhoneController.php
*概　　要     ： 簡易棚卸(フォン)
*作　　成     ： 2022/10/21 CNC
*/
class RackSimplePhoneController extends AbstractController
{
    /**
     * @var Twig_Environment
     */
    protected $twig;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var StateRepository
     */
    protected $StateRepository;

    /**
     * @var RackProductRepository
     */
    protected $RackProductRepository;

    /**
     * @var StockListStorehouseUnitRepository
     */
    private $stockListStorehouseUnitRepository;

    /**
     * RackSimplePhoneController constructor.
     * @param Twig_Environment $twig
     * @param ProductRepository $productRepository
     * @param StateRepository $StateRepository
     * @param RackProductRepository $RackProductRepository
     * @param StockListStorehouseUnitRepository $stockListStorehouseUnitRepository
     */
    public function __construct(
        Twig_Environment $twig,
        ProductRepository $productRepository,
        StateRepository $StateRepository,
        RackProductRepository $RackProductRepository,
        StockListStorehouseUnitRepository $stockListStorehouseUnitRepository
    )
    {
        $this->twig = $twig;
        $this->productRepository = $productRepository;
        $this->StateRepository = $StateRepository;
        $this->RackProductRepository = $RackProductRepository;
        $this->stockListStorehouseUnitRepository = $stockListStorehouseUnitRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/rack/rack_simple_phone", name="admin_rack_simple_phone")
     * @Template("@admin/Rack/rack_simple_phone.twig")
     *
     * @param Request $request
     * @param CacheUtil $cacheUtil
     * @param null $id
     *
     * @return array|RedirectResponse
     * @throws \Exception
     */
    public function index(Request $request, CacheUtil $cacheUtil, $id = null)
    {

        $builder = $this->formFactory->createBuilder(RackSimplePhoneType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_RACK_SIMPLE_PHONE_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();
        // 状態
        $stateList = $this->StateRepository->getStateByCategory();

        $form->handleRequest($request);

        return [
            'form' => $form->createView(),
            'StateList' => $stateList,
            'id' => $id,
        ];
    }


    /**
     * @Route("/%eccube_admin_route%/rack/search/product_phone", name="admin_rack_search_product_phone")
     * @param Request $request リクエスト
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchProduct(Request $request)
    {
        $searchData = [
            'product_code' => $request->get('product_code'),
            'category_id' => $request->get('category_id'),
            'state' => $request->get('state_id'),
        ];

        log_info('Admin Rack searchProduct', [$searchData]);

        // 商品名称取得
        $array_product_name = $this->getProductNameBySearchData($searchData);

        // 今回在庫数取得
        $array_now_stock_quantity = $this->getStockQuantityBySearchData($searchData);

        // ラック番号取得
        $array_rack = $this->getRackBySearchData($searchData);

        $event = new EventArgs(
            [
                'searchData' => $searchData,
                'array_product_name' => $array_product_name,
                'array_now_stock_quantity' => $array_now_stock_quantity,
                'array_rack' => $array_rack,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_RACK_SIMPLE_PHONE_SEARCH_PRODUCT_SEARCH, $event);

        if (!empty($array_product_name)) {
            $data = [
                'product_name' => $array_product_name[0]['product_name'],
                'rack_1' => empty($array_rack) ? null : $array_rack[0]['rack_code1'],
                'rack_2' => empty($array_rack) ? null : $array_rack[0]['rack_code2'],
                'rack_3' => empty($array_rack) ? null : $array_rack[0]['rack_code3'],
                'now_stock_quantity' => empty($array_now_stock_quantity) ? null : $array_now_stock_quantity[0]['now_stock_quantity'],
            ];
        } else {
            log_debug('search product by code not found.');
            return $this->json([], 404);
        }

        $event = new EventArgs(
            [
                'searchData' => $searchData,
                'array_product_name' => $array_product_name,
                'array_now_stock_quantity' => $array_now_stock_quantity,
                'array_rack' => $array_rack,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_RACK_SIMPLE_PHONE_SEARCH_PRODUCT_COMPLETE, $event);

        return $this->json($data);
    }

    public function getProductNameBySearchData($searchData)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();

        $sql = "
                SELECT
                    ps.product_id AS product_id
                    , ps.product_code AS product_code
                    , p.name AS product_name
                FROM
                    dtb_product_class ps   
                LEFT JOIN dtb_product p 
                    ON ps.product_id = p.id
                WHERE
                    TRUE ";

        // product_code
        if (isset($searchData['product_code']) && StringUtil::isNotBlank($searchData['product_code'])) {
            $sql .= 'AND ps.product_code = '."'". $searchData['product_code']."'";
        }

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    public function getStockQuantityBySearchData($searchData)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();

        $sql = "SELECT
                    CASE WHEN COUNT(slsu.stock_quantity) = 0
                    THEN 0
                    ELSE slsu.stock_quantity
                    END AS now_stock_quantity
                    FROM (
                         SELECT
                            CASE WHEN slsh.storehouse_id = '13'
                            THEN SUM(slsh.stock_quantity)
                             ELSE 0
                             END AS stock_quantity
                         FROM
                            dtb_stock_list_storehouse_unit slsh
                         WHERE
                           TRUE ";

        $sql .= 'AND slsh.storehouse_id = '."'". '13'."'";

        // product_code
        if (isset($searchData['product_code']) && StringUtil::isNotBlank($searchData['product_code'])) {
            $sql .= 'AND slsh.product_code = '."'". $searchData['product_code']."'";
        }

        // state
        if (isset($searchData['state']) && StringUtil::isNotBlank($searchData['state'])) {
            $sql .= 'AND slsh.state_id = '."'".$searchData['state']."'";
        }

        $sql = $sql.'
                GROUP BY slsh.product_code
                        ,slsh.state_id
                        ,slsh.storehouse_id ) slsu
                    ';

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    public function getRackBySearchData($searchData)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();

        $sql = "
                SELECT
                    r1.rack_code AS rack_code1
                    , r2.rack_code AS rack_code2
                    , r3.rack_code AS rack_code3
                FROM dtb_rack_product rp
                     LEFT JOIN mtb_rack r1 
                        ON r1.id = rp.rack_1 
                     LEFT JOIN mtb_rack r2 
                        ON r2.id = rp.rack_2 
                     LEFT JOIN mtb_rack r3 
                        ON r3.id = rp.rack_3 
                WHERE
                    TRUE ";

        // product_code
        if (isset($searchData['product_code']) && StringUtil::isNotBlank($searchData['product_code'])) {
            $sql .= 'AND rp.product_code = '."'". $searchData['product_code']."'";
        }
        // state
        if (isset($searchData['state']) && StringUtil::isNotBlank($searchData['state'])) {
            $sql .= 'AND rp.state_id = '."'".$searchData['state']."'";
        }

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }
}
