<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Rack;

use Eccube\Controller\AbstractController;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\CsvImportType;
use Eccube\Form\Type\Admin\ProductListType;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Service\CsvExportService;
use Eccube\Util\FormUtil;
use Knp\Component\Pager\Paginator;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\Routing\Annotation\Route;
use Eccube\Form\Type\Admin\RackListType;
use Eccube\Repository\RackLoginRepository;

/**
 *プログラム名 ： RackListController.php
 *概　　要     ： 仕入商品状態一覧
 *作　　成     ： 2022/9/5 CNC
 */
class RackListController extends AbstractController
{
    /**
     * @var CsvExportService
     */
    protected $csvExportService;

    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;

    /**
     * @var RackLoginRepository
     */
    protected $rackLoginRepository;

    /**
     * ProductController constructor.
     *
     * @param PageMaxRepository $pageMaxRepository
     * @param RackLoginRepository $rackLoginRepository
     */
    public function __construct(
        PageMaxRepository $pageMaxRepository,
        RackLoginRepository $rackLoginRepository
    ) {
        $this->pageMaxRepository = $pageMaxRepository;
        $this->rackLoginRepository = $rackLoginRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/rack/rack_list", name="admin_rack_list")
     * @Route("/%eccube_admin_route%/rack/rack_list/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_rack_list_page")
     * @Template("@admin/Rack/rack_list.twig")
     */
    public function index(Request $request, $page_no = null, Paginator $paginator)
    {
        $builder = $this->formFactory
            ->createBuilder(RackListType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_RACK_LIST_INDEX_INITIALIZE, $event);

        $searchForm = $builder->getForm();

        /**
         * ページの表示件数は, 以下の順に優先される.
         * - リクエストパラメータ
         * - セッション
         * - デフォルト値
         * また, セッションに保存する際は mtb_page_maxと照合し, 一致した場合のみ保存する.
         **/
        $page_count = $this->session->get('eccube.admin.rack.search.page_count',
            $this->eccubeConfig->get('eccube_mltext_len'));

        $page_count_param = (int) $request->get('page_count');
        $pageMaxis = $this->pageMaxRepository->findAll();

        if ($page_count_param) {
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.admin.rack.search.page_count', $page_count);
                    break;
                }
            }
        }

        $page_no_bk = $page_no;
        if ('POST' === $request->getMethod()) {
            $searchForm->handleRequest($request);

            if ($searchForm->isValid()) {
                /**
                 * 検索が実行された場合は, セッションに検索条件を保存する.
                 * ページ番号は最初のページ番号に初期化する.
                 */
                $page_no = 1;
                $searchData = $searchForm->getData();

                // 検索条件, ページ番号をセッションに保持.
                $this->session->set('eccube.admin.rack.search', FormUtil::getViewData($searchForm));
                $this->session->set('eccube.admin.rack.search.page_no', $page_no);
            } else {
                // 検索エラーの際は, 詳細検索枠を開いてエラー表示する.
                return [
                    'searchForm' => $searchForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $page_count,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.admin.rack.search.page_no', (int) $page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.admin.rack.search.page_no', 1);
                }
                $viewData = $this->session->get('eccube.admin.rack.search', []);
                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
            } else {
                /**
                 * 初期表示の場合.
                 */
                $page_no = 1;

                // submit default value
                $viewData = FormUtil::getViewData($searchForm);

                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);

                // セッション中の検索条件, ページ番号を初期化.
                $this->session->set('eccube.admin.rack.search', $viewData);
                $this->session->set('eccube.admin.rack.search.page_no', $page_no);
            }
        }

        $qb = '';
        $all_orders = [];
        if ('POST' === $request->getMethod() || null !== $page_no_bk){
            $qb = $this->rackLoginRepository->getQueryBuilderBySearchDataForAdmin($searchData);
            $all_orders = $qb->getQuery()->getResult();
        }

        $sort_orders = $this->sortOrder($all_orders, $searchData);

        $event = new EventArgs(
            [
                'qb' => $qb,
                'searchData' => $searchData,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_RACK_LIST_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $page_count
        );

        // xlsxImportType
        $builder_xlsx_import = $this->formFactory
            ->createBuilder(CsvImportType::class);

        $event = new EventArgs(
            [
                'builder' => $builder_xlsx_import,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_RACK_LIST_INDEX_CSV_IMPORT_INITIALIZE, $event);

        $xlsx_import_form = $builder_xlsx_import->getForm();

        return [
            'searchForm' => $searchForm->createView(),
            'xlsxImportForm' => $xlsx_import_form->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'has_errors' => false,
            'request' => $request,
        ];
    }

    private function sortOrder($orders, $searchData) {
        if ($searchData['sort_by']) {
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case 'ラック番号':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == "降順") {
                            return $a["rackCode"] > $b["rackCode"] ? -1 : 1;
                        }
                        return $a["rackCode"] < $b["rackCode"] ? -1 : 1;
                    });
                    break;
            }
        }
        return $orders;
    }

    /**
     * 連動商品情報出力.
     *
     * @Route("/%eccube_admin_route%/rack/export/xlsx", name="admin_rack_export_xlsx")
     *
     * @param Request $request Request
     *
     * @return StreamedResponse
     *
     * @throws \Exception
     */
    public function xlsxExport(Request $request)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        ini_set('memory_limit', '2048M');

        $response = new StreamedResponse();
        $response->setCallback(function () use ($request) {

            // searchData
            $builder = $this->formFactory
                ->createBuilder(RackListType::class);

            $event = new EventArgs(
                [
                    'builder' => $builder,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_RACK_LIST_INDEX_INITIALIZE, $event);

            $searchForm = $builder->getForm();

            $searchForm->handleRequest($request);

            $searchData = $searchForm->getData();

            // 画面入力取得
            $rack_code = $searchData['rack_code'];

            // 明細開始行
            $count = 4;

            // xlsxファイル設定
            $xlsxPath = $this->eccubeConfig->get('eccube_html_dir').'/template/admin/assets/xlsx/ラック一括登録.xlsx';
            $spreadsheet = IOFactory::load($xlsxPath);

            $qb = $this->rackLoginRepository->findAll();

            foreach ($qb as $xlsxData) {

                $spreadsheet->setActiveSheetIndex(0)
                    ->setCellValue('D'.$count, $xlsxData["id"])
                    ->setCellValue('E'.$count, $xlsxData["rackCode"]);
                $count = $count + 1;
            }

            $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');

            $writer->save('php://output');
        });

        $sysDate = (new \DateTime())->format('YmdHis');

        $filename = 'attachment;filename="ラック一括登録_'.$sysDate.'.xlsx"';

        $response->headers->set('Content-Disposition', $filename);
        header("Content-Type:application/force-download");
        header("Content-Type:application/vnd.ms-excel");
        header("Content-Type:application/octet-stream");
        header("Content-Type:application/download");
        header("Pragma: no-cache");

        $response->send();

        return $response;
    }
}
