<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Rack;

use Doctrine\DBAL\Exception\ForeignKeyConstraintViolationException;
use Eccube\Controller\AbstractController;
use Eccube\Entity\RackProduct;
use Eccube\Entity\RackSimpleSerial;
use Eccube\Entity\StockListStorehouseUnit;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\InputMultipleSerialPhoneType;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\RackProductRepository;
use Eccube\Repository\RockSimpleSerialRepository;
use Eccube\Repository\StockListStorehouseUnitRepository;
use Eccube\Repository\RockStockQuantityHistoryRepository;
use Eccube\Util\CacheUtil;
use Eccube\Util\StringUtil;
use Knp\Component\Pager\Paginator;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Twig_Environment;
use Eccube\Common\Constant;

/**
*プログラム名 ： RackSimpleSerialPhoneController.php
*概　　要     ： 簡易棚卸IMEI別(フォン)
*作　　成     ： 2022/10/24 CNC
*/
class RackSimpleSerialPhoneController extends AbstractController
{
    /**
     * @var Twig_Environment
     */
    protected $twig;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var RackProductRepository
     */
    protected $RackProductRepository;

    /**
     * @var RockSimpleSerialRepository
     */
    protected $RockSimpleSerialRepository;

    /**
     * @var StockListStorehouseUnitRepository
     */
    private $stockListStorehouseUnitRepository;

    /**
     * @var RockStockQuantityHistoryRepository
     */
    protected $RockStockQuantityHistoryRepository;

    /**
     * RackSimpleSerialPhoneController constructor.
     * @param Twig_Environment $twig
     * @param ProductRepository $productRepository
     * @param RackProductRepository $RackProductRepository
     * @param RockSimpleSerialRepository $RockSimpleSerialRepository
     * @param StockListStorehouseUnitRepository $stockListStorehouseUnitRepository
     * @param RockStockQuantityHistoryRepository $RockStockQuantityHistoryRepository
     */
    public function __construct(
        Twig_Environment $twig,
        ProductRepository $productRepository,
        RackProductRepository $RackProductRepository,
        RockSimpleSerialRepository $RockSimpleSerialRepository,
        StockListStorehouseUnitRepository $stockListStorehouseUnitRepository,
        RockStockQuantityHistoryRepository $RockStockQuantityHistoryRepository
    )
    {
        $this->twig = $twig;
        $this->productRepository = $productRepository;
        $this->RackProductRepository = $RackProductRepository;
        $this->RockSimpleSerialRepository = $RockSimpleSerialRepository;
        $this->stockListStorehouseUnitRepository = $stockListStorehouseUnitRepository;
        $this->RockStockQuantityHistoryRepository = $RockStockQuantityHistoryRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/rack/rack_simple_serial_phone", name="admin_rack_simple_serial_phone")
     * @Template("@admin/Rack/rack_simple_serial_phone.twig")
     *
     * @param Request $request
     * @param CacheUtil $cacheUtil
     * @param null $id
     *
     * @return array|RedirectResponse
     * @throws \Exception
     */
    public function index(Request $request, CacheUtil $cacheUtil, $id = null)
    {
        $builder = $this->formFactory->createBuilder(InputMultipleSerialPhoneType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_RACK_SIMPLE_PHONE_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();
        $form->handleRequest($request);

        return [
            'form' => $form->createView(),
            'id' => $id,
        ];
    }

    /**
     *
     * @Route("/%eccube_admin_route%/rack/rack_simple_serial_phone/check_stock_serial", name="admin_rack_simple_serial_phone_check_serial", methods={"POST"})
     *
     * @param Request $request Request
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function checkStockSerial(Request $request)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()){
            $array_serial_numbers = $request->get('serial');
            $rack_quantity = count($array_serial_numbers);
            $product_code1 = '';
            $state_id1 = '';

            // 在庫テーブルに満足条件のシリアルを抽出
            $array_duplicate_stock_serial_no = [];
            $checked_stock_info = "";
            $checked_rack_info = implode(",", $array_serial_numbers);
            foreach ($array_serial_numbers as $serial_number) {
                if (trim($serial_number)) {
                    /** @var StockListStorehouseUnit $infoStockListStorehouseUnit */
                    $infoStockListStorehouseUnit = $this->stockListStorehouseUnitRepository->findBy(
                        [
                            'serialNo' => trim($serial_number),
                            'stockQuantity' => 1
                        ]
                    );
                    if ($infoStockListStorehouseUnit && $infoStockListStorehouseUnit[0]->getStockQuantity() > 0 ) {
                        $array_duplicate_stock_serial_no[] = $infoStockListStorehouseUnit[0];
                    }
                }
            }

            if($array_duplicate_stock_serial_no){
                $product_code1 = $array_duplicate_stock_serial_no[0]['product_code'];
                $state_id1 = $array_duplicate_stock_serial_no[0]['state']['id'];

                //シリアルの商品+状態チャック
                foreach ($array_duplicate_stock_serial_no as $array_serial_no) {
                    if(!($array_serial_no['product_code'] == $product_code1 && $array_serial_no['state']['id'] == $state_id1) ){
                        $data = [
                            'error_flg' => '1',
                            'serialNo' => $array_serial_no['serialNo'],
                        ];
                        return $this->json($data);
                    }
                }

            }else{
                $data = [
                    'error_flg' => '2',
                    'error_message' => '全部のシリアルは在庫一覧に存在できません。',
                ];
                return $this->json($data);
            }

            /** @var $RackProduct RackProduct */
            $RackProduct = $this->RackProductRepository->findBy([
                'productCode' => $product_code1,
                'state' => $state_id1,
            ]);

            if (!empty($RackProduct[0])) {
                $updateRackProduct = $RackProduct[0];

                $stockListStorehouseUnit = $this->stockListStorehouseUnitRepository->getStockQuantityByProduct($product_code1, $state_id1,'13');

                if (!empty($stockListStorehouseUnit[0])) {
                    $stock_quantity = $stockListStorehouseUnit[0]['stockQuantity'];
                // INS-START CNC 2022/12/07 川口に情報がなしの場合、在庫数0
                } else {
                    $stock_quantity = 0;
                }
                // INS-START CNC 2022/12/07

                    /** @var $RackSimpleSerial RackSimpleSerial */
                    $rockSimpleSerials = $this->RockSimpleSerialRepository->findBy(
                        [
                            'productCode' => $product_code1,
                            'state_id' => $state_id1,
                        ]
                    );
                    if($rockSimpleSerials){
                        foreach ($rockSimpleSerials as $rockSimpleSerial)
                        // テーブル「簡易棚卸IMEI別」の既存データを削除
                        $this->entityManager->remove($rockSimpleSerial);
                    }

                    // 在庫一覧（置場単位）に存在データ
                    $stockSerials = $this->stockListStorehouseUnitRepository->getSerialByProduct($product_code1, $state_id1,'13');
                    $diff_quantity = 0;
                    if (!empty($stockSerials)){
                        foreach ($stockSerials as $stockSerial) {
                            if ($checked_stock_info == "") {
                                $checked_stock_info = $stockSerial['serial_no'];
                            } else {
                                $checked_stock_info = $checked_stock_info. "," .$stockSerial['serial_no'];
                            }

                            if (in_array($stockSerial->getSerialNo(), $array_serial_numbers)) {
                                $this->RockSimpleSerialRepository->insertSerial($product_code1, $state_id1, $stockSerial['serial_no'], 1, $this->getUser());
                            }else{
                                $this->RockSimpleSerialRepository->insertSerial($product_code1, $state_id1, $stockSerial['serial_no'], 0, $this->getUser());
                                $diff_quantity++;
                            }
                        }
                    }
                    $updateRackProduct->setCheckedUserName($this->getUser());
                    $updateRackProduct->setCheckedDate(new \DateTime());
                    $updateRackProduct->setCheckedStockQuantity($stock_quantity);
                    $updateRackProduct->setCheckedRackQuantity($rack_quantity);
                    $updateRackProduct->setCheckedDiffQuantity($diff_quantity);
                    $updateRackProduct->setUpdateUserName($this->getUser());
                    $this->entityManager->persist($updateRackProduct);
                    $this->entityManager->flush();

                    if($diff_quantity === 0){
                        $result_classify_kubun = '0';
                    } else {
                        $result_classify_kubun = '1';
                    }

                    $this->RockStockQuantityHistoryRepository->insertStockQuantityInfo($product_code1, $state_id1,'1',$result_classify_kubun, $this->getUser(), $checked_stock_info, $checked_rack_info, $diff_quantity);

                    $data = ['error_flg' => '0',];
            // DEL-START CNC 2022/12/07 川口に情報がなしの場合、在庫数0
//                } else {
//                    $data = [
//                        'error_flg' => '2',
//                        'error_message' => 'この商品は在庫一覧（川口）に存在できません。',
//                    ];
//                }
            // DEL-END CNC 2022/12/07 川口に情報がなしの場合、在庫数0
            } else {
                $data = [
                    'error_flg' => '2',
                    'error_message' => 'この商品は商品ラック一覧に存在できません。',
                ];
            }

        }

        return $this->json($data);
    }
}
