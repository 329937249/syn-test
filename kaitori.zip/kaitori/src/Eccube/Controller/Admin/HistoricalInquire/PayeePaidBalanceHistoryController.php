<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\HistoricalInquire;

use Eccube\Controller\AbstractController;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\PayeePaidBalanceHistoryType;
use Eccube\Form\Type\Admin\SearchMemberType;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\MemberRepository;
use Eccube\Repository\PayeePaidBalanceHistoryRepository;
use Eccube\Util\FormUtil;
use Knp\Component\Pager\Paginator;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： PayeePaidBalanceHistoryController.php
 *概　　要     ： 履歴詳細(仕入出金残高)
 *作　　成     ： 2021/7/27 CNC
 */
class PayeePaidBalanceHistoryController extends AbstractController
{
    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;

    /**
     * @var PayeePaidBalanceHistoryRepository
     */
    protected $payeePaidBalanceHistoryRepository;

    /**
     * @var MemberRepository
     */
    protected $memberRepository;


    public function __construct(
        PageMaxRepository $pageMaxRepository,
        PayeePaidBalanceHistoryRepository $payeePaidBalanceHistoryRepository,
        MemberRepository $memberRepository
    ) {
        $this->pageMaxRepository = $pageMaxRepository;
        $this->payeePaidBalanceHistoryRepository = $payeePaidBalanceHistoryRepository;
        $this->memberRepository = $memberRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/historical_inquire/disbursement_balance", name="admin_disbursement_balance")
     * @Route("/%eccube_admin_route%/historical_inquire/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_payee_paid_balance_history_page")
     * @Template("@admin/HistoricalInquire/payee_paid_balance_history.twig")
     *
     * @param Request $request
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function index(Request $request, $page_no = null, Paginator $paginator)
    {
        $session = $this->session;
        $builder = $this->formFactory
            ->createBuilder(PayeePaidBalanceHistoryType::class, null);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_HISTORICAL_INQUIRE_PAYEE_PAID_BALANCE_HISTORY_INDEX_INITIALIZE, $event);

        $pageMaxis = $this->pageMaxRepository->findAll();
        $pageCount = $session->get('eccube.admin.historical_inquire.search.page_count', $this->eccubeConfig['eccube_default_page_count']);
        $pageCountParam = $request->get('page_count');
        if ($pageCountParam && is_numeric($pageCountParam)) {
            foreach ($pageMaxis as $pageMax) {
                if ($pageCountParam == $pageMax->getName()) {
                    $pageCount = $pageMax->getName();
                    $session->set('eccube.admin.historical_inquire.search.page_count', $pageCount);
                    break;
                }
            }
        }
        $form = $builder->getForm();

        // 出金者検索フォーム
        $builder = $this->formFactory
            ->createBuilder(SearchMemberType::class);
        $searchUpdateUserNameModalForm = $builder->getForm();

        $page_no_bk = $page_no;
        if ('POST' === $request->getMethod()) {
            $form->handleRequest($request);
            if ($form->isValid()) {
                $searchData = $form->getData();
                $page_no = 1;

                $session->set('eccube.admin.historical_inquire.search', FormUtil::getViewData($form));
                $session->set('eccube.admin.historical_inquire.search.page_no', $page_no);
            } else {
                return [
                    'form' => $form->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $pageCount,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                if ($page_no) {
                    $session->set('eccube.admin.historical_inquire.search.page_no', (int) $page_no);
                } else {
                    $page_no = $session->get('eccube.admin.historical_inquire.search.page_no', 1);
                }
                $viewData = $session->get('eccube.admin.historical_inquire.search', []);
            } else {
                $page_no = 1;
                $viewData = FormUtil::getViewData($form);
                $viewData["pay_date_end"] =  date('Y-m-d', strtotime('now'));
                $viewData["pay_date_start"] =  date('Y-m-d', strtotime('now'));
                $session->set('eccube.admin.historical_inquire.search', $viewData);
                $session->set('eccube.admin.historical_inquire.search.page_no', $page_no);
            }
            $searchData = FormUtil::submitAndGetData($form, $viewData);
        }

        $qb = '';
        $all_orders = [];
        if ('POST' === $request->getMethod() || null !== $page_no_bk){
            /** @var QueryBuilder $qb */
            $qb = $this->payeePaidBalanceHistoryRepository->getQueryBuilderBySearchData($searchData);
            $all_orders = $qb->getQuery()->getResult();
        }

        $sort_orders = $this->sortOrder($all_orders, $searchData);

        $event = new EventArgs(
            [
                'form' => $form,
                'qb' => $qb,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_HISTORICAL_INQUIRE_PAYEE_PAID_BALANCE_HISTORY_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $pageCount
        );
        return [
            'form' => $form->createView(),
            'searchUpdateUserNameModalForm' => $searchUpdateUserNameModalForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $pageCount,
            'has_errors' => false,
        ];
    }

    private function sortOrder($orders, $searchData){
        if($searchData['sort_by']){
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case '出金日':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a["payDate"]> $b["payDate"] ? -1 : 1;
                        }
                        return $a["payDate"] < $b["payDate"] ? -1 : 1;
                    });
                    break;
                case '出金者':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a["payUserName"] > $b["payUserName"] ? -1 : 1;
                        }
                        return $a["payUserName"] < $b["payUserName"] ? -1 : 1;
                    });
                    break;
            }
        }
        return $orders;
    }

    /**
     * 出金者情報を検索する.
     *
     * @Route("/%eccube_admin_route%/historical_inquire/disbursement_balance/html", name="admin_master_search_updateuser_html")
     * @Route("/%eccube_admin_route%/historical_inquire/disbursement_balance/html/page/{page_no}", requirements={"page_No" = "\d+"}, name="admin_master_search_updateuser_html_page")
     * @Template("@admin/HistoricalInquire/search_updateuser.twig")
     *
     * @param Request $request
     * @param integer $page_no
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchPayUserNameHtml(Request $request, $page_no = null, Paginator $paginator)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('search member start.');
            $page_count = $this->eccubeConfig['eccube_default_page_count'];
            $session = $this->session;

            if ('POST' === $request->getMethod()) {
                $page_no = 1;
                $searchData = [
                    'id' => $request->get('id'),
                    'name' => $request->get('name'),
                ];

                $session->set('eccube.master.member.search', $searchData);
                $session->set('eccube.master.member.search.page_no', $page_no);
            } else {
                $searchData = (array) $session->get('eccube.admin.master.member.search');
                if (is_null($page_no)) {
                    $page_no = intval($session->get('eccube.admin.master.member.search.page_no'));
                } else {
                    $session->set('eccube.admin.master.member.search.page_no', $page_no);
                }
            }

            $qb = $this->memberRepository->getQueryBuilderBySearchData($searchData);

            $event = new EventArgs(
                [
                    'qb' => $qb,
                    'data' => $searchData,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_HISTORICAL_INQUIRE_PAYEE_PAID_BALANCE_HISTORY_SEARCH_UPDATE_USER_NAME_SEARCH, $event);

            /** @var \Knp\Component\Pager\Pagination\SlidingPagination $pagination */
            $pagination = $paginator->paginate(
                $qb,
                $page_no,
                $page_count,
                ['wrap-queries' => true]
            );

            /** @var $Members \Eccube\Entity\Member[] */
            $Members = $pagination->getItems();

            if (empty($Members)) {
                log_debug('search member not found.');
            }

            $data = [];
            foreach ($Members as $Member) {
                $data[] = [
                    'id' => $Member->getId(),
                    'name' => $Member->getName()
                ];
            }

            $event = new EventArgs(
                [
                    'data' => $data,
                    '$Members' => $pagination,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_HISTORICAL_INQUIRE_PAYEE_PAID_BALANCE_HISTORY_SEARCH_UPDATE_USER_NAME_COMPLETE, $event);
            $data = $event->getArgument('data');

            return [
                'data' => $data,
                'pagination' => $pagination,
            ];
        }
    }

    /**
     *  出金者情報をセットする.
     *
     * @Route("/%eccube_admin_route%/historical_inquire/search/updateuser/id", name="admin_master_search_updateuser_by_id", methods={"POST"})
     *
     * @param Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchPayUserNameById(Request $request)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('search member by id start.');

            /** @var $Member \Eccube\Entity\Member */
            $Member = $this->memberRepository
                ->find($request->get('id'));

            $event = new EventArgs(
                [
                    'Member' => $Member,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_HISTORICAL_INQUIRE_PAYEE_PAID_BALANCE_HISTORY_SEARCH_UPDATE_USER_NAME_BY_ID_INITIALIZE, $event);

            if (is_null($Member)) {
                log_debug('search member by id not found.');

                return $this->json([], 404);
            }

            log_debug('search member by id found.');

            $data = [
                'id' => $Member->getId(),
                'name' => $Member->getName(),
            ];

            $event = new EventArgs(
                [
                    'data' => $data,
                    'Member' => $Member,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_HISTORICAL_INQUIRE_PAYEE_PAID_BALANCE_HISTORY_SEARCH_UPDATE_USER_NAME_BY_ID_COMPLETE, $event);
            $data = $event->getArgument('data');
            return $this->json($data);
        }
    }

}
