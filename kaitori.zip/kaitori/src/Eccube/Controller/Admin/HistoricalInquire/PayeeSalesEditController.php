<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\HistoricalInquire;

use Eccube\Controller\AbstractController;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\PayeeSalesEditHistoryType;
use Eccube\Form\Type\Admin\PayeeSalesEditHistoryBeforeType;
use Eccube\Repository\PayeeVoucherHeaderHistoryRepository;
use Eccube\Repository\PayeeVoucherDetailHistoryRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： PayeeSalesEditController.php
 *概　　要     ： 履歴詳細(仕入)
 *作　　成     ： 2021/08/11 CNC
 */
class PayeeSalesEditController extends AbstractController
{
    /**
     * @var PayeeVoucherHeaderHistoryRepository
     */
    protected $payeeVoucherHeaderHistoryRepository;

    /**
     * @var PayeeVoucherDetailHistoryRepository
     */
    protected $payeeVoucherDetailHistoryRepository;

    public function __construct(
        PayeeVoucherHeaderHistoryRepository $payeeVoucherHeaderHistoryRepository,
        PayeeVoucherDetailHistoryRepository $payeeVoucherDetailHistoryRepository
    ) {
        $this->payeeVoucherHeaderHistoryRepository = $payeeVoucherHeaderHistoryRepository;
        $this->payeeVoucherDetailHistoryRepository = $payeeVoucherDetailHistoryRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/historical_inquire/payee_sales/{id}/edit", requirements={"id" = "\d+"}, name="admin_payee_sales_edit")
     * @Template("@admin/HistoricalInquire/payee_sales_edit.twig")
     *
     * @param Request $request
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function index(Request $request, $id = null)
    {
        // 編集
        if ($id) {
            $Payeesales = $this->payeeVoucherHeaderHistoryRepository
                ->find($id);
            if (is_null($Payeesales)) {
                throw new NotFoundHttpException();
            }
        }

        $payee_rev = $Payeesales->getrevisionNo();
        $payee_voucher_no =$Payeesales->getpayeeVoucherNo();
        $payee_processingBehavior = $Payeesales->getprocessingBehavior();

        // 修正前
        $payee_rev_bef = $payee_rev -1;
        $Payeesales_bef = $this->payeeVoucherHeaderHistoryRepository
            ->findOneBy(['payeeVoucherNo' => $payee_voucher_no,'revisionNo' => $payee_rev_bef]);
        $PayeeBef = $this->payeeVoucherDetailHistoryRepository->getListBef($payee_voucher_no,$payee_rev_bef);
        // 修正後
        if($payee_processingBehavior=='削除'){
            $Payee = null;
        }else{
            $Payee = $this->payeeVoucherDetailHistoryRepository->getList($payee_voucher_no,$payee_rev);
        }

        if($payee_processingBehavior=='削除'){
            $Payeesales = null;
        }else{
            $Payeesales = $this->payeeVoucherHeaderHistoryRepository
                ->find($id);
        }
        $payee_Behavior='削除';
        // 修正後
        $builder = $this->formFactory->createBuilder(PayeeSalesEditHistoryType::class, $Payeesales);
        // 修正前
        $builder_1 = $this->formFactory->createBuilder(PayeeSalesEditHistoryBeforeType::class, $Payeesales_bef);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'builder_1' => $builder_1,
                'Payeesales' => $Payeesales,
                'Payeesales_bef' => $Payeesales_bef,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_HISTORICAL_INQUIRE_PAYEE_SALES_EDIT_INDEX_INITIALIZE, $event);

        // 修正後
        $form = $builder->getForm();
        $form->handleRequest($request);
        // 修正前
        $form1= $builder_1->getForm();
        $form1->handleRequest($request);

        $form2 = $builder->getForm();
        $form2->handleRequest($request);

        return [
            'form' => $form->createView(),
            'form1' => $form1->createView(),
            'form2' => $form2->createView(),
            'Payeesales' => $Payeesales,
            'Payee' => $Payee,
            'PayeeBef' => $PayeeBef,
            'payee_Behavior' =>$payee_Behavior,
            'payee_processingBehavior' =>$payee_processingBehavior,
        ];
    }
}
