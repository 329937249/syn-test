<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\HistoricalInquire;

use Eccube\Controller\AbstractController;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\PayeeSalesHistoryType;
use Eccube\Form\Type\Admin\SearchMemberType;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\MemberRepository;
use Eccube\Repository\PayeeVoucherHeaderHistoryRepository;
use Eccube\Repository\SalesVoucherHeaderHistoryRepository;
use Eccube\Util\FormUtil;
use Knp\Component\Pager\Paginator;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： PayeeSalesController.php
 *概　　要     ： 履歴照会(仕入、売上)
 *作　　成     ： 2021/08/03 CNC
 */
class PayeeSalesController extends AbstractController
{
    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;
    /**
     * @var PayeeVoucherHeaderHistoryRepository
     */
    protected $payeeVoucherHeaderHistoryRepository;

    /**
     * @var SalesVoucherHeaderHistoryRepository
     */
    protected $salesVoucherHeaderHistoryRepository;

    /**
     * @var MemberRepository
     */
    protected $memberRepository;

    public function __construct(
        PageMaxRepository $pageMaxRepository,
        PayeeVoucherHeaderHistoryRepository $payeeVoucherHeaderHistoryRepository,
        SalesVoucherHeaderHistoryRepository $salesVoucherHeaderHistoryRepository,
        MemberRepository $memberRepository
    ) {
        $this->pageMaxRepository = $pageMaxRepository;
        $this->payeeVoucherHeaderHistoryRepository = $payeeVoucherHeaderHistoryRepository;
        $this->salesVoucherHeaderHistoryRepository = $salesVoucherHeaderHistoryRepository;
        $this->memberRepository = $memberRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/historical_inquire/payee_sales", name="admin_payee_sales")
     * @Route("/%eccube_admin_route%/historical_inquire/payee_sales/{page_no}", requirements={"page_no" = "\d+"}, name="admin_payee_sales_page")
     * @Template("@admin/HistoricalInquire/payee_sales.twig")
     *
     * @param Request $request
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function index(Request $request, $page_no = null, Paginator $paginator)
    {
        $session = $this->session;
        $builder = $this->formFactory
            ->createBuilder(PayeeSalesHistoryType::class, null);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_HISTORICAL_INQUIRE_PAYEE_SALES_INDEX_INITIALIZE, $event);

        $pageMaxis = $this->pageMaxRepository->findAll();
        $pageCount = $session->get('eccube.admin.payee_sales.search.page_count', $this->eccubeConfig['eccube_default_page_count']);
        $pageCountParam = $request->get('page_count');
        if ($pageCountParam && is_numeric($pageCountParam)) {
            foreach ($pageMaxis as $pageMax) {
                if ($pageCountParam == $pageMax->getName()) {
                    $pageCount = $pageMax->getName();
                    $session->set('eccube.admin.payee_sales.search.page_count', $pageCount);
                    break;
                }
            }
        }
        $form = $builder->getForm();

        // 更新者検索フォーム
        $builder = $this->formFactory
            ->createBuilder(SearchMemberType::class);
        $searchUpdateUserModalForm = $builder->getForm();

        $page_no_bk = $page_no;
        if ('POST' === $request->getMethod()) {
            $form->handleRequest($request);
            if ($form->isValid()) {
                $searchData = $form->getData();
                $page_no = 1;

                $session->set('eccube.admin.payee_sales.search', FormUtil::getViewData($form));
                $session->set('eccube.admin.payee_sales.search.page_no', $page_no);
            } else {
                return [
                    'form' => $form->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $pageCount,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                if ($page_no) {
                    $session->set('eccube.admin.payee_sales.search.page_no', (int) $page_no);
                } else {
                    $page_no = $session->get('eccube.admin.payee_sales.search.page_no', 1);
                }
                $viewData = $session->get('eccube.admin.payee_sales.search', []);
            } else {
                $page_no = 1;
                $viewData = FormUtil::getViewData($form);
                $viewData["inquiry_date_end"] =  date('Y-m-d', strtotime('now'));
                $viewData["inquiry_date_start"] =  date('Y-m-d', strtotime('now'));
                $session->set('eccube.admin.payee_sales.search', $viewData);
                $session->set('eccube.admin.payee_sales.search.page_no', $page_no);
            }
            $searchData = FormUtil::submitAndGetData($form, $viewData);
        }

        if($searchData["historicalCategory"]=='仕入'){
            $qb = $this->payeeVoucherHeaderHistoryRepository->getQueryBuilderBySearchData($searchData);
            $historicalCategory = '仕入';
        }elseif($searchData["historicalCategory"]=='売上'){
            $qb = $this->salesVoucherHeaderHistoryRepository->getQueryBuilderBySearchData($searchData);
            $historicalCategory = '売上';
        }else{
            $voucherno = $searchData["voucher_no"];
            $updateuser = $searchData["update_user_name"];
            if($searchData["inquiry_date_start"]!==null){
                $inquiry_date_start = $searchData["inquiry_date_start"];
                $datestart = $inquiry_date_start->setTime('0', '0', '0')
                    ->setTimezone(new \DateTimeZone('UTC'))
                    ->format('Y-m-d H:i:s');
            }else{
                $datestart ='';
            }

            if($searchData["inquiry_date_end"]!==null){
                $inquiry_date_end = $searchData["inquiry_date_end"];
                $dateend = $inquiry_date_end->setTime('23', '59', '59')
                    ->setTimezone(new \DateTimeZone('UTC'))
                    ->format('Y-m-d H:i:s');
            } else{
                $dateend ='';
            }

            $sale = [];
            if ('POST' === $request->getMethod() || null !== $page_no_bk){
                $sale = $this->getSale($datestart,$updateuser,$dateend,$voucherno);
            }

            $historicalCategory = '';
        }

        if($searchData["historicalCategory"]==''){
            $sort_orders = $this->sortOrder($sale, $searchData);
        }else{
            $all_orders = $qb->getQuery()->getResult();
            $sort_orders = $this->sortOrder($all_orders, $searchData);
        }

        $event = new EventArgs(
            [
                'form' => $form,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_HISTORICAL_INQUIRE_PAYEE_SALES_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $pageCount
        );
        return [
            'form' => $form->createView(),
            'searchUpdateUserModalForm' => $searchUpdateUserModalForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $pageCount,
            'has_errors' => false,
            'historicalCategory' =>$historicalCategory,
        ];
    }

    private function sortOrder($orders, $searchData){
        if($searchData['sort_by']){
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case '修正日':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a["updateDate"]> $b["updateDate"] ? -1 : 1;
                        }
                        return $a["updateDate"] < $b["updateDate"] ? -1 : 1;
                    });
                    break;
                case '更新者':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a["updateUserName"] > $b["updateUserName"] ? -1 : 1;
                        }
                        return $a["updateUserName"] < $b["updateUserName"] ? -1 : 1;
                    });
                    break;
                case '伝票番号':
                    if($searchData["historicalCategory"]=='仕入'){
                        usort($orders, function ($a, $b) use ($order_by) {
                            if($order_by == "降順"){
                                return $a["payeeVoucherNo"] > $b["payeeVoucherNo"] ? -1 : 1;
                            }
                            return $a["payeeVoucherNo"] < $b["payeeVoucherNo"] ? -1 : 1;
                        });
                        break;
                    }
                    elseif ($searchData["historicalCategory"]=='売上'){
                        usort($orders, function ($a, $b) use ($order_by) {
                            if($order_by == "降順"){
                                return $a["salesVoucherNo"] > $b["salesVoucherNo"] ? -1 : 1;
                            }
                            return $a["salesVoucherNo"] < $b["salesVoucherNo"] ? -1 : 1;
                        });
                        break;
                    }
                    elseif ($searchData["historicalCategory"]==''){
                        usort($orders, function ($a, $b) use ($order_by) {
                            if($order_by == "降順"){
                                return $a["voucherNo"] > $b["voucherNo"] ? -1 : 1;
                            }
                            return $a["voucherNo"] < $b["voucherNo"] ? -1 : 1;
                        });
                        break;
                    }
            }
        }
        return $orders;
    }

    /**
     * 更新者情報を検索する.
     *
     * @Route("/%eccube_admin_route%/historical_inquire/payee_sales/html", name="admin_master_search_salesuser_html")
     * @Route("/%eccube_admin_route%/historical_inquire/payee_sales/html/page/{page_no}", requirements={"page_No" = "\d+"}, name="admin_master_search_salesuser_html_page")
     * @Template("@admin/HistoricalInquire/payee_sales_updateuser.twig")
     *
     * @param Request $request
     * @param integer $page_no
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchUpdateUserNameHtml(Request $request, $page_no = null, Paginator $paginator)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('search member start.');
            $page_count = $this->eccubeConfig['eccube_default_page_count'];
            $session = $this->session;

            if ('POST' === $request->getMethod()) {
                $page_no = 1;
                $searchData = [
                    'id' => $request->get('id'),
                    'name' => $request->get('name'),
                ];

                $session->set('eccube.master.member.search', $searchData);
                $session->set('eccube.master.member.search.page_no', $page_no);
            } else {
                $searchData = (array) $session->get('eccube.admin.master.member.search');
                if (is_null($page_no)) {
                    $page_no = intval($session->get('eccube.admin.master.member.search.page_no'));
                } else {
                    $session->set('eccube.admin.master.member.search.page_no', $page_no);
                }
            }

            $qb = $this->memberRepository->getQueryBuilderBySearchData($searchData);

            $event = new EventArgs(
                [
                    'qb' => $qb,
                    'data' => $searchData,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_HISTORICAL_INQUIRE_PAYEE_SALESSEARCH_UPDATE_USER_NAME_SEARCH, $event);

            /** @var \Knp\Component\Pager\Pagination\SlidingPagination $pagination */
            $pagination = $paginator->paginate(
                $qb,
                $page_no,
                $page_count,
                ['wrap-queries' => true]
            );

            /** @var $Members \Eccube\Entity\Member[] */
            $Members = $pagination->getItems();

            if (empty($Members)) {
                log_debug('search member not found.');
            }

            $data = [];
            foreach ($Members as $Member) {
                $data[] = [
                    'id' => $Member->getId(),
                    'name' => $Member->getName()
                ];
            }

            $event = new EventArgs(
                [
                    'data' => $data,
                    '$Members' => $pagination,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_HISTORICAL_INQUIRE_PAYEE_SALESSEARCH_UPDATE_USER_NAME_COMPLETE, $event);
            $data = $event->getArgument('data');

            return [
                'data' => $data,
                'pagination' => $pagination,
            ];
        }
    }

    /**
     *  更新者情報をセットする.
     *
     * @Route("/%eccube_admin_route%/historical_inquire/search/salesuser/id", name="admin_master_search_salesuser_by_id", methods={"POST"})
     *
     * @param Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchUpdateUserNameById(Request $request)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('search member by id start.');

            /** @var $Member \Eccube\Entity\Member */
            $Member = $this->memberRepository
                ->find($request->get('id'));

            $event = new EventArgs(
                [
                    'Member' => $Member,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_HISTORICAL_INQUIRE_PAYEE_SALESSEARCH_UPDATE_USER_NAME_BY_ID_INITIALIZE, $event);

            if (is_null($Member)) {
                log_debug('search member by id not found.');

                return $this->json([], 404);
            }

            log_debug('search member by id found.');

            $data = [
                'id' => $Member->getId(),
                'name' => $Member->getName(),
            ];

            $event = new EventArgs(
                [
                    'data' => $data,
                    'Member' => $Member,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_HISTORICAL_INQUIRE_PAYEE_SALESEARCH_UPDATE_USER_NAME_BY_ID_COMPLETE, $event);
            $data = $event->getArgument('data');
            return $this->json($data);
        }
    }

    /**
     * 履歴照会(仕入、売上).
     * @param $datestart
     * @param $updateuser
     * @param $dateend
     * @param $voucherno
     * @return mixed[]
     */
    protected function getSale($datestart, $updateuser, $dateend, $voucherno)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();

        $sql = "
                SELECT
                *
                FROM(
                SELECT
                    PAY.id AS id,
                    PAY.update_date AS updateDate,
                    PAY.update_user_name AS updateUserName,
                    PAY.processing_behavior AS processingBehavior,
                    PAY.revision_no AS revisionNo,
                    PAY.payee_voucher_no AS voucherNo,
                    PAY.personnel_memo AS personnelMemo,
                    '1' AS FLG,
                    '仕入' AS historicalCategory
                FROM 
                    dtb_payee_voucher_header_history PAY
                UNION ALL
                SELECT 
                    SAL.id AS id,
                    SAL.update_date AS updateDate,
                    SAL.update_user_name AS updateUserName,
                    SAL.processing_behavior AS processingBehavior,
                    SAL.revision_no AS revisionNo,
                    SAL.sales_voucher_no AS voucherNo,
                    SAL.personnel_memo AS personnelMemo,
                    '2' AS FLG,
                    '売上' AS historicalCategory            
                FROM 
                    dtb_sales_voucher_header_history SAL)pay 
                where 
                    voucherNo like '%$voucherno%'"
                .($datestart ? "AND (updateDate >= '$datestart' or '$datestart' = '')" : '')
                .($dateend ? "AND (updateDate <= '$dateend' or '$dateend' = '')" : '')
                ."
                AND
                    (updateUserName = '$updateuser' or '$updateuser' = '')
                AND revisionNo != 0
                ORDER BY
                    voucherNo,
                    revisionNo,
                    updateDate
                    ";

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

}
