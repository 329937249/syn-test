<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\HistoricalInquire;

use Doctrine\ORM\QueryBuilder;
use Eccube\Controller\AbstractController;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\SalesDetailAfterHistoryType;
use Eccube\Form\Type\Admin\SalesDetailBeforeHistoryType;
use Eccube\Repository\SalesVoucherHeaderHistoryRepository;
use Eccube\Repository\TaxCodeRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： SalesDetailEditController.php
 *概　　要     ： 履歴詳細(売上)
 *作　　成     ： 2021/08/11 CNC
 */
class SalesDetailEditController extends AbstractController
{
    /**
     * @var SalesVoucherHeaderHistoryRepositorytaxCodeRepository
     */
    protected $salesVoucherHeaderHistoryRepository;

    /**
     * @var TaxCodeRepository
     */
    protected $taxCodeRepository;

    public function __construct(
        SalesVoucherHeaderHistoryRepository $salesVoucherHeaderHistoryRepository,
        TaxCodeRepository $taxCodeRepository
    ) {
        $this->salesVoucherHeaderHistoryRepository = $salesVoucherHeaderHistoryRepository;
        $this->taxCodeRepository = $taxCodeRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/historical_inquire/sales_detail/{id}/edit", requirements={"id" = "\d+"}, name="admin_sales_detail_edit")
     * @Template("@admin/HistoricalInquire/sales_detail_edit.twig")
     *
     * @param Request $request
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function index(Request $request, $id = null)
    {
        // 編集
        if ($id) {
            //履歴詳細(売上)を検索する
            $salesHistory = $this->salesVoucherHeaderHistoryRepository
                ->find($id);
            if (is_null($salesHistory)) {
                throw new NotFoundHttpException();
            }
        }

        //売上伝票番号
        $salesVoucherNo=$salesHistory->getSalesVoucherNo();

        //処理動作
        $processingBehavior=$salesHistory->getProcessingBehavior();

        //修正後リビジョン番号
        $afterRevisionNo=$salesHistory->getRevisionNo();

        //修正前リビジョン番号
        $beforeRevisionNo=$afterRevisionNo-1;

        $sales_Behavior='削除';

        // 修正前データを取得する
        $salesHistory_bef = $this->salesVoucherHeaderHistoryRepository
            ->findOneBy(['salesVoucherNo' => $salesVoucherNo,'revisionNo' => $beforeRevisionNo]);

        /** @var QueryBuilder $qb */
        $SalesBef = $this->getList($salesVoucherNo,$beforeRevisionNo);

        // 修正後入力モード(削除)を场合
        if($processingBehavior=='削除'){
            $SalesAft = null;
        }else{

            //修正後データを取得する
            /** @var QueryBuilder $qb */
            $SalesAft = $this->getList($salesVoucherNo,$afterRevisionNo);

        }

        if($processingBehavior=='削除'){
            $salesHistory_aft = null;
        }else{
            $salesHistory_aft = $this->salesVoucherHeaderHistoryRepository
                ->find($id);
        }

        //粗利益、利益率
        $crudeBefSum=0;
        $rateBefSum=0;
        $crudeAftSum=0;
        $rateAftSum=0;

        //税金区分
        $taxRateCategory_Bef=$salesHistory_bef->getTaxRateCategory();
        $taxBef=$this->taxCodeRepository->find($taxRateCategory_Bef);
        $tax_rate_Bef=$taxBef->getTaxRate();

        if($SalesAft!=null)
        {
            $taxRateCategory_Aft=$salesHistory_aft->getTaxRateCategory();
            $tax_Aft=$this->taxCodeRepository->find($taxRateCategory_Aft);
            $tax_rate_Aft=$tax_Aft->getTaxRate();

        }

        //修正前(輸出住所)存在の場合
        if($salesHistory_bef['exportAddress']!=null)
        {
            $i=0;
            //修正前
            foreach ($SalesBef as $bef) {
                $crudeBefSum = $bef['sales_price'] - ($bef['average_unit_price'] / (1 + $tax_rate_Bef / 100));
                $rateBefSum=($crudeBefSum/$bef['sales_price'])*100;
                $bef['crudeBefSum'] = round($crudeBefSum);
                $bef['rateBefSum'] = round($rateBefSum,1);
                $SalesBef[$i]=$bef;
                $i++;
            }
        }
        else{
            $i=0;
            //修正前
            foreach ($SalesBef as $bef) {
                $crudeBefSum=$bef['sales_price']-$bef['average_unit_price'];
                $rateBefSum=($crudeBefSum/$bef['sales_price'])*100;
                $bef['crudeBefSum'] = round($crudeBefSum);
                $bef['rateBefSum'] = round($rateBefSum,1);
                $SalesBef[$i]=$bef;
                $i++;
            }
        }

        if($SalesAft!=null) {
            //修正後(輸出住所)存在の場合
            if ($salesHistory_aft['exportAddress'] != null) {
                $i = 0;
                if ($SalesAft != null) {
                    //修正後
                    foreach ($SalesAft as $aft) {
                        $crudeAftSum = $aft['sales_price'] - ($aft['average_unit_price'] / (1 + $tax_rate_Aft / 100));
                        if ($aft['sales_price'] != 0) {
                            $rateAftSum = ($crudeAftSum / $aft['sales_price']) * 100;
                        } else {
                            $rateAftSum = 0;
                        }
                        $aft['crudeAftSum'] = round($crudeAftSum);
                        $aft['rateAftSum'] = round($rateAftSum, 1);
                        $SalesAft[$i] = $aft;
                        $i++;
                    }
                }
            }
            else {
                //修正後輸出住所nullを场合
                $i = 0;
                foreach ($SalesAft as $aft) {
                    $crudeAftSum = $aft['sales_price'] - $aft['average_unit_price'];
                    if ($aft['sales_price'] != 0) {
                        $rateAftSum = $crudeAftSum / $aft['sales_price'] * 100;
                    } else {
                        $rateAftSum = 0;
                    }
                    $aft['crudeAftSum'] = round($crudeAftSum);
                    $aft['rateAftSum'] = round($rateAftSum, 1);
                    $SalesAft[$i] = $aft;
                    $i++;
                }
            }
        }
        else{
            $aft['crudeAftSum'] = $crudeAftSum;
            $aft['rateAftSum'] = $rateAftSum;
        }

        // 修正後
        $builder_1= $this->formFactory->createBuilder(SalesDetailAfterHistoryType::class, $salesHistory_aft);

        // 修正前
        $builder_2 = $this->formFactory->createBuilder(SalesDetailBeforeHistoryType::class, $salesHistory_bef);

        $event = new EventArgs(
            [
                'builder_1' => $builder_1,
                'builder_2' => $builder_2,
                'SalesBef' => $SalesBef,
                'SalesAft' => $SalesAft,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_HISTORICAL_INQUIRE_SALES_DETAIL_EDIT_INDEX_INITIALIZE, $event);

        // 修正後
        $form = $builder_1->getForm();
        $form->handleRequest($request);

        // 修正前
        $form1 = $builder_2->getForm();
        $form1->handleRequest($request);

        $form2= $builder_1->getForm();
        $form2->handleRequest($request);

        return [
            'form' => $form->createView(),
            'form1' => $form1->createView(),
            'form2' => $form2->createView(),
            'sales_Behavior' =>$sales_Behavior,
            'salesVoucherNo' =>$salesVoucherNo,
            'processingBehavior' =>$processingBehavior,
            'SalesBef' => $SalesBef,
            'SalesAft' => $SalesAft,
            'sales_Behavior' =>$sales_Behavior,

        ];
    }
    /**
     * データを取得する
     *
     * @param $salesVoucherNo
     * @param $revisionNo
     *
     * @return null|result
     */
    public function getList($salesVoucherNo,$revisionNo)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();
        $sql = '
                SELECT
                    svdh.sales_details_no,
                    svdh.product_code,
                    p.name,
                    svdh.serial_no,
                    s.state,
                    mp.place,
                    svdh.sales_price_extax,
                    svdh.sales_price,
                    svdh.quantity,
                    svdh.total_sales_amount,
                    svdh.average_unit_price

                FROM dtb_sales_voucher_detail_history svdh

                INNER JOIN dtb_product_class pc
                ON pc.id=svdh.product_class_id

                INNER JOIN dtb_product p
                ON p.id=pc.product_id

                INNER JOIN mtb_state s
                ON s.id=svdh.state_id

                INNER JOIN mtb_place mp
                ON mp.id=svdh.storehouse_id
                WHERE TRUE

            ';

        $sql= $sql.' AND svdh.sales_voucher_no='."'".$salesVoucherNo."'";
        $sql= $sql.' AND svdh.revision_no='."'".$revisionNo."'";
        $sql= $sql.' ORDER BY svdh.sales_details_no ASC';

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }
}
