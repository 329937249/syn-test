<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin;

use Carbon\Carbon;
use Doctrine\Common\Collections\Criteria;
use Doctrine\ORM\NoResultException;
use Doctrine\ORM\Query\ResultSetMapping;
use Eccube\Controller\AbstractController;
use Eccube\Entity\Master\CustomerStatus;
use Eccube\Entity\Master\OrderStatus;
use Eccube\Entity\Master\ProductStatus;
use Eccube\Entity\Master\OrderItemType;
use Eccube\Entity\Master\KaitoriType;
use Eccube\Entity\ProductStock;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Exception\PluginApiException;
use Eccube\Form\Type\Admin\ChangePasswordType;
use Eccube\Form\Type\Admin\LoginType;
use Eccube\Repository\CustomerRepository;
use Eccube\Repository\Master\OrderStatusRepository;
use Eccube\Repository\MemberRepository;
use Eccube\Repository\OrderRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Service\PluginApiService;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;
use Symfony\Component\Security\Core\Encoder\EncoderFactoryInterface;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;
use Eccube\Util\EntityUtil;
use Doctrine\ORM\Query\ResultSetMappingBuilder;

class AdminController extends AbstractController
{
    /**
     * @var AuthorizationCheckerInterface
     */
    protected $authorizationChecker;

    /**
     * @var AuthenticationUtils
     */
    protected $helper;

    /**
     * @var MemberRepository
     */
    protected $memberRepository;

    /**
     * @var EncoderFactoryInterface
     */
    protected $encoderFactory;

    /**
     * @var OrderRepository
     */
    protected $orderRepository;

    /**
     * @var OrderStatusRepository
     */
    protected $orderStatusRepository;

    /**
     * @var CustomerRepository
     */
    protected $customerRepository;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /** @var PluginApiService */
    protected $pluginApiService;

    /**
     * @var array 売り上げ状況用受注状況
     */
    private $excludes = [OrderStatus::CANCEL, OrderStatus::PENDING, OrderStatus::PROCESSING, OrderStatus::RETURNED];

    /**
     * AdminController constructor.
     *
     * @param AuthorizationCheckerInterface $authorizationChecker
     * @param AuthenticationUtils $helper
     * @param MemberRepository $memberRepository
     * @param EncoderFactoryInterface $encoderFactory
     * @param OrderRepository $orderRepository
     * @param OrderStatusRepository $orderStatusRepository
     * @param CustomerRepository $custmerRepository
     * @param ProductRepository $productRepository
     * @param PluginApiService $pluginApiService
     */
    public function __construct(
        AuthorizationCheckerInterface $authorizationChecker,
        AuthenticationUtils $helper,
        MemberRepository $memberRepository,
        EncoderFactoryInterface $encoderFactory,
        OrderRepository $orderRepository,
        OrderStatusRepository $orderStatusRepository,
        CustomerRepository $custmerRepository,
        ProductRepository $productRepository,
        PluginApiService $pluginApiService
    ) {
        $this->authorizationChecker = $authorizationChecker;
        $this->helper = $helper;
        $this->memberRepository = $memberRepository;
        $this->encoderFactory = $encoderFactory;
        $this->orderRepository = $orderRepository;
        $this->orderStatusRepository = $orderStatusRepository;
        $this->customerRepository = $custmerRepository;
        $this->productRepository = $productRepository;
        $this->pluginApiService = $pluginApiService;
    }

    /**
     * @Route("/%eccube_admin_route%/login", name="admin_login")
     * @Template("@admin/login.twig")
     */
    public function login(Request $request)
    {
        if ($this->authorizationChecker->isGranted('ROLE_ADMIN')) {
            return $this->redirectToRoute('admin_homepage');
        }

        /* @var $form \Symfony\Component\Form\FormInterface */
        $builder = $this->formFactory->createNamedBuilder('', LoginType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ADMIM_LOGIN_INITIALIZE, $event);

        $form = $builder->getForm();

        return [
            'error' => $this->helper->getLastAuthenticationError(),
            'form' => $form->createView(),
        ];
    }

    /**
     * 管理画面ホーム
     *
     * @param Request $request
     *
     * @return array
     *
     * @throws NoResultException
     * @throws \Doctrine\ORM\NonUniqueResultException
     *
     * @Route("/%eccube_admin_route%/", name="admin_homepage")
     * @Template("@admin/index.twig")
     */
    public function index(Request $request)
    {
        $adminRoute = $this->eccubeConfig['eccube_admin_route'];
        $is_danger_admin_url = false;
        if ($adminRoute === 'admin') {
            $is_danger_admin_url = true;
        }
        /**
         * 申込み状況.
         */
        $excludes = [];
        $excludes[] = OrderStatus::CANCEL;
        $excludes[] = OrderStatus::PAID;
        //$excludes[] = OrderStatus::DELIVERED;
        //$excludes[] = OrderStatus::PENDING;
        $excludes[] = OrderStatus::PROCESSING;
	    //$excludes[] = OrderStatus::IN_PROGRESS;
        //$excludes[] = OrderStatus::RETURNED;

        $day_history = [];
        $week_history = [];
        $month_history = [];
        //$year_history = [];
        
        $event = new EventArgs(
            [
                'excludes' => $excludes,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ADMIM_INDEX_ORDER, $event);
        $excludes = $event->getArgument('excludes');

        // 受注ステータスごとの受注件数.
        $Orders = $this->getOrderEachStatus($excludes);

        // 受注ステータスの一覧.
        $Criteria = new Criteria();
        $Criteria
            ->where($Criteria::expr()->notIn('id', $excludes))
            ->orderBy(['sort_no' => 'ASC']);
        $OrderStatuses = $this->orderStatusRepository->matching($Criteria);

        /**
         * 売り上げ状況
         */
        $event = new EventArgs(
            [
                'excludes' => $this->excludes,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ADMIM_INDEX_SALES, $event);
        $this->excludes = $event->getArgument('excludes');

        // 今日の売上/件数
        $salesToday = $this->getSalesByDay(new \DateTime());
        // 昨日の売上/件数
        $salesYesterday = $this->getSalesByDay(new \DateTime('-1 day'));
        // 今月の売上/件数
        $salesThisMonth = $this->getSalesByMonth(new \DateTime());

        /**
         * ショップ状況
         */
        // 在庫切れ商品数
        $countNonStockProducts = $this->countNonStockProducts();

        // 取り扱い商品数
        $countProducts = $this->countProducts();

        // 本会員数
        $countCustomers = $this->countCustomers();

        $event = new EventArgs(
            [
                'Orders' => $Orders,
                'OrderStatuses' => $OrderStatuses,
                'salesThisMonth' => $salesThisMonth,
                'salesToday' => $salesToday,
                'salesYesterday' => $salesYesterday,
                'countNonStockProducts' => $countNonStockProducts,
                'countProducts' => $countProducts,
                'countCustomers' => $countCustomers,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ADMIM_INDEX_COMPLETE, $event);

        // 推奨プラグイン
        $recommendedPlugins = [];
        try {
            $recommendedPlugins = $this->pluginApiService->getRecommended();
        } catch (PluginApiException $ignore) {
        }

        $day_history = $this->getProductSearchHistories('day');
        $two_day_history = $this->getProductSearchHistories('two_day');
        $three_day_history = $this->getProductSearchHistories('three_day');
        $week_history = $this->getProductSearchHistories('week');
        $month_history = $this->getProductSearchHistories('month');
        //$year_history = $this->getProductSearchHistories('year');
        $productSaleDay = $this->getSaleDay();

        // INS-START CNC 2021/7/29
//        //今日仕入実績一覧
//        $payees = $this->getPayeeDaily();
//        //今日売上実績一覧
//        $sale = $this->getRevenueDaily();
//        // 仕入数量合計、仕入金額合計
//        $payeeMoneyTotalAmount = 0;
//        $Amount = 0;
//        foreach ($payees as $payee){
//            $payeeMoneyTotalAmount = $payeeMoneyTotalAmount + $payee["payee_money_amount"];
//            $Amount = $Amount + $payee["quantity"];
//        }
//
//        // 売上数量合計、売上金額合計
//        $salesMoneyTotalAmount = 0;
//        $salesAmount = 0;
//        foreach ($sale as $sales){
//            $salesMoneyTotalAmount = $salesMoneyTotalAmount + $sales["total_sales_amount"];
//            $salesAmount = $salesAmount + $sales["quantity"];
//        }
        // INS-END CNC 2021/7/29

        return [
            'Orders' => $Orders,
            'OrderStatuses' => $OrderStatuses,
            'salesThisMonth' => $salesThisMonth,
            'salesToday' => $salesToday,
            'salesYesterday' => $salesYesterday,
            'countNonStockProducts' => $countNonStockProducts,
            'countProducts' => $countProducts,
            'countCustomers' => $countCustomers,
            'recommendedPlugins' => $recommendedPlugins,
            'is_danger_admin_url' => $is_danger_admin_url,
            'day_history' => $day_history,
            'two_day_history' => $two_day_history,
            'three_day_history' => $three_day_history,
            'week_history' => $week_history,
            'month_history' => $month_history,
            //'year_history' => $year_history,
            'productSaleDay' => $productSaleDay, 
            'today' => new \DateTime(), 
            // INS-START CNC 2021/7/29
//            'payees' => $payees,
//            'sale' => $sale,
//            'payeeMoneyTotalAmount' => $payeeMoneyTotalAmount,
//            'Amount' => $Amount,
//            'salesMoneyTotalAmount' => $salesMoneyTotalAmount,
//            'salesAmount' =>$salesAmount
            // INS-END CNC 2021/7/29
        ];
    }

    /**
     * 売上状況の取得
     *
     * @param Request $request
     *
     * @Route("/%eccube_admin_route%/sale_chart", name="admin_homepage_sale")
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function sale(Request $request)
    {
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
        }

        // 週間の売上金額
        $toDate = Carbon::now();
        $fromDate = Carbon::today()->subWeek();
        $rawWeekly = $this->getData($fromDate, $toDate, 'Y/m/d');

        // 月間の売上金額
        // $fromDate = Carbon::now()->startOfMonth();
        $fromDate = Carbon::today()->subMonth();
        $rawMonthly = $this->getData($fromDate, $toDate, 'Y/m/d');

        // 年間の売上金額
        $fromDate = Carbon::now()->subYear()->startOfMonth();
        $rawYear = $this->getData($fromDate, $toDate, 'Y/m');

        $datas = [$rawWeekly, $rawMonthly, $rawYear];

        return $this->json($datas);
    }

    /**
     * パスワード変更画面
     *
     * @Route("/%eccube_admin_route%/change_password", name="admin_change_password")
     * @Template("@admin/change_password.twig")
     *
     * @param Request $request
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|array
     */
    public function changePassword(Request $request)
    {
        $builder = $this->formFactory
            ->createBuilder(ChangePasswordType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ADMIM_CHANGE_PASSWORD_INITIALIZE, $event);

        $form = $builder->getForm();
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $Member = $this->getUser();
            $salt = $Member->getSalt();
            $password = $form->get('change_password')->getData();

            $encoder = $this->encoderFactory->getEncoder($Member);

            // 2系からのデータ移行でsaltがセットされていない場合はsaltを生成.
            if (empty($salt)) {
                $salt = $encoder->createSalt();
            }

            $password = $encoder->encodePassword($password, $salt);

            $Member
                ->setPassword($password)
                ->setSalt($salt);

            $this->memberRepository->save($Member);

            $event = new EventArgs(
                [
                    'form' => $form,
                    'Member' => $Member,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ADMIN_CHANGE_PASSWORD_COMPLETE, $event);

            $this->addSuccess('admin.change_password.password_changed', 'admin');

            return $this->redirectToRoute('admin_change_password');
        }

        return [
            'form' => $form->createView(),
        ];
    }

    /**
     * 在庫なし商品の検索結果を表示する.
     *
     * @Route("/%eccube_admin_route%/search_nonstock", name="admin_homepage_nonstock")
     *
     * @param Request $request
     *
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function searchNonStockProducts(Request $request)
    {
        // 在庫なし商品の検索条件をセッションに付与し, 商品マスタへリダイレクトする.
        $searchData = [];
        $searchData['stock'] = [ProductStock::OUT_OF_STOCK];
        $session = $request->getSession();
        $session->set('eccube.admin.product.search', $searchData);

        return $this->redirectToRoute('admin_product_page', [
            'page_no' => 1,
        ]);
    }

    /**
     * 本会員の検索結果を表示する.
     *
     * @Route("/%eccube_admin_route%/search_customer", name="admin_homepage_customer")
     *
     * @param Request $request
     *
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function searchCustomer(Request $request)
    {
        $searchData = [];
        $searchData['customer_status'] = [CustomerStatus::REGULAR];
        $session = $request->getSession();
        $session->set('eccube.admin.customer.search', $searchData);

        return $this->redirectToRoute('admin_customer_page', [
            'page_no' => 1,
        ]);
    }

    /**
     * @param \Doctrine\ORM\EntityManagerInterface $em
     * @param array $excludes
     *
     * @return null|Request
     */
    protected function getOrderEachStatus(array $excludes)
    {
        $sql = 'SELECT
                    t1.order_status_id as status,
                    COUNT(t1.id) as count
                FROM
                    dtb_order t1
                WHERE
                    t1.order_status_id NOT IN (:excludes)
                GROUP BY
                    t1.order_status_id
                ORDER BY
                    t1.order_status_id';
        $rsm = new ResultSetMapping();
        $rsm->addScalarResult('status', 'status');
        $rsm->addScalarResult('count', 'count');
        $query = $this->entityManager->createNativeQuery($sql, $rsm);
        $query->setParameters([':excludes' => $excludes]);
        $result = $query->getResult();
        $orderArray = [];
        foreach ($result as $row) {
            $orderArray[$row['status']] = $row['count'];
        }

        return $orderArray;
    }


    

    /**
     * @param $dateTime
     *
     * @return array|mixed
     *
     * @throws \Doctrine\ORM\NonUniqueResultException
     */
    protected function getSalesByDay($dateTime,$OrderStatus = OrderStatus::PAID)
    {
        // concat... for pgsql
        // http://stackoverflow.com/questions/1091924/substr-does-not-work-with-datatype-timestamp-in-postgres-8-3
        $dql = 'SELECT
                  SUBSTRING(CONCAT(o.payment_date, \'\'), 1, 10) AS payment_date,
                  SUM(o.total) AS order_amount,
                  COUNT(o) AS order_count
                FROM
                  Eccube\Entity\Order o
                WHERE
                    o.OrderStatus = (:OrderStatus)
                    AND SUBSTRING(CONCAT(o.payment_date, \'\'), 1, 10) = SUBSTRING(:targetDate, 1, 10)
                GROUP BY
                  payment_date';

        $q = $this->entityManager
            ->createQuery($dql)
            ->setParameter(':OrderStatus', $OrderStatus)
            ->setParameter(':targetDate', $dateTime);

        $result = [];
        try {
            $result = $q->getSingleResult();
        } catch (NoResultException $e) {
            // 結果がない場合は空の配列を返す.
        }
        return $result;
    }

    /**
     * @param $dateTime
     *
     * @return array|mixed
     *
     * @throws \Doctrine\ORM\NonUniqueResultException
     */
    protected function getSalesByMonth($dateTime,$OrderStatus = OrderStatus::PAID)
    {
        // concat... for pgsql
        // http://stackoverflow.com/questions/1091924/substr-does-not-work-with-datatype-timestamp-in-postgres-8-3
        $dql = 'SELECT
                  SUBSTRING(CONCAT(o.payment_date, \'\'), 1, 7) AS order_month,
                  SUM(o.total) AS order_amount,
                  COUNT(o) AS order_count
                FROM
                  Eccube\Entity\Order o
                WHERE
                    o.OrderStatus = (:OrderStatus)
                    AND SUBSTRING(CONCAT(o.payment_date, \'\'), 1, 7) = SUBSTRING(:targetDate, 1, 7)
                GROUP BY
                  order_month';

        $q = $this->entityManager
            ->createQuery($dql)
            ->setParameter(':OrderStatus', $OrderStatus)
            ->setParameter(':targetDate', $dateTime);

        $result = [];
        try {
            $result = $q->getSingleResult();
        } catch (NoResultException $e) {
            // 結果がない場合は空の配列を返す.
        }

        return $result;
    }

    /**
     * 在庫切れ商品数を取得
     *
     * @return mixed
     *
     * @throws \Doctrine\ORM\NonUniqueResultException
     */
    protected function countNonStockProducts()
    {
        $qb = $this->productRepository->createQueryBuilder('p')
            ->select('count(DISTINCT p.id)')
            ->innerJoin('p.ProductClasses', 'pc')
            ->where('pc.stock_unlimited = :StockUnlimited AND pc.stock = 0')
            ->andWhere('pc.visible = :visible')
            ->setParameter('StockUnlimited', false)
            ->setParameter('visible', true);

        return $qb->getQuery()->getSingleScalarResult();
    }

    /**
     * 商品数を取得
     *
     * @return mixed
     *
     * @throws \Doctrine\ORM\NonUniqueResultException
     */
    protected function countProducts()
    {
        $qb = $this->productRepository->createQueryBuilder('p')
            ->select('count(p.id)')
            ->where('p.Status in (:Status)')
            ->setParameter('Status', [ProductStatus::DISPLAY_SHOW, ProductStatus::DISPLAY_HIDE]);

        return $qb->getQuery()->getSingleScalarResult();
    }

    /**
     * 本会員数を取得
     *
     * @return mixed
     *
     * @throws \Doctrine\ORM\NonUniqueResultException
     */
    protected function countCustomers()
    {
        $qb = $this->customerRepository->createQueryBuilder('c')
            ->select('count(c.id)')
            ->where('c.Status = :Status')
            ->setParameter('Status', CustomerStatus::REGULAR);

        return $qb->getQuery()->getSingleScalarResult();
    }

    /**
     * 期間指定のデータを取得
     *
     * @param Carbon $fromDate
     * @param Carbon $toDate
     * @param $format
     *
     * @return array
     */
    protected function getData(Carbon $fromDate, Carbon $toDate, $format,$OrderStatus = OrderStatus::PAID)
    {
        $qb = $this->orderRepository->createQueryBuilder('o')
            //->andWhere('o.order_date >= :fromDate')
            //->andWhere('o.order_date <= :toDate')
            //->andWhere('o.OrderStatus NOT IN (:excludes)')
            ->andWhere('o.payment_date >= :fromDate')
            ->andWhere('o.payment_date <= :toDate')
            ->andWhere('o.OrderStatus = :OrderStatus')
            //->setParameter(':excludes', $this->excludes)
            ->setParameter(':OrderStatus', $OrderStatus)
            ->setParameter(':fromDate', $fromDate->copy())
            ->setParameter(':toDate', $toDate->copy())
            //->orderBy('o.order_date');
            ->orderBy('o.payment_date');

        $result = $qb->getQuery()->getResult();

        return $this->convert($result, $fromDate, $toDate, $format);
    }

    /**
     * 期間毎にデータをまとめる
     *
     * @param $result
     * @param Carbon $fromDate
     * @param Carbon $toDate
     * @param $format
     *
     * @return array
     */
    protected function convert($result, Carbon $fromDate, Carbon $toDate, $format)
    {
        $raw = [];
        for ($date = $fromDate; $date <= $toDate; $date = $date->addDay()) {
            $raw[$date->format($format)]['price'] = 0;
            $raw[$date->format($format)]['count'] = 0;
        }

        foreach ($result as $Order) {
            //$raw[$Order->getOrderDate()->format($format)]['price'] += $Order->getPaymentTotal();
            $raw[$Order->getPaymentDate()->format($format)]['price'] += $Order->getTotal();
            //++$raw[$Order->getOrderDate()->format($format)]['count'];
            ++$raw[$Order->getPaymentDate()->format($format)]['count'];
        }
        
        return $raw;
    }

     /**
     * @param \Doctrine\ORM\EntityManagerInterface $em
     * @param array $excludes
     *
     * @return null|arr
     */
    protected function getProductSearchHistories($search_condition)
    {
        $sql = '';
        switch ($search_condition) {
           case 'day': // 一日
              $sql = '
                SELECT
                   cc.con as count, group_concat(cc.keyword,"<PN>",cc.pn order by cc.keyword SEPARATOR "<SP>") as word
                FROM
                   (
                   SELECT
                     COALESCE(COUNT(p.id), 0) as con,
                     sum(p.product_count) as pn,
                     p.keyword
                   FROM
                     dtb_product_search_history p
                   WHERE
                     TO_DAYS(p.create_date) = TO_DAYS(NOW())
                   GROUP BY
                     p.keyword
                   )cc 
                GROUP BY
                    cc.con
                ORDER BY 
                    cc.con desc 
                LIMIT
                    30';
                break;
                case 'two_day': // 二日
                    $sql = '
                      SELECT
                         cc.con as count , group_concat(cc.keyword,"<PN>",cc.pn order by cc.keyword SEPARATOR "<SP>") as word
                      FROM
                         (
                         SELECT
                           COALESCE(COUNT(p.id), 0) as con,
                           sum(p.product_count) as pn,
                           p.keyword
                         FROM
                           dtb_product_search_history p
                         WHERE
                           DATE_SUB(CURDATE(), INTERVAL 1 DAY) <= date(p.create_date)
                         GROUP BY
                           p.keyword
                         )cc 
                      GROUP BY
                          cc.con
                      ORDER BY 
                          cc.con desc 
                      LIMIT
                          30';
                      break;
                      case 'three_day': // 三日
                        $sql = '
                          SELECT
                             cc.con as count, group_concat(cc.keyword,"<PN>",cc.pn order by cc.keyword SEPARATOR "<SP>") as word
                          FROM
                             (
                             SELECT
                               COALESCE(COUNT(p.id), 0) as con,
                               sum(p.product_count) as pn,
                               p.keyword
                             FROM
                               dtb_product_search_history p
                             WHERE
                               DATE_SUB(CURDATE(), INTERVAL 2 DAY) <= date(p.create_date)
                             GROUP BY
                               p.keyword
                             )cc 
                          GROUP BY
                              cc.con
                          ORDER BY 
                              cc.con desc 
                          LIMIT
                              30';
                          break;
            case 'week': // 週間
             $sql = '
                SELECT 
                   cc.con as count ,group_concat(cc.keyword,"<PN>",cc.pn order by cc.keyword SEPARATOR "<SP>") as word
                FROM
                   (
                   SELECT
                     COALESCE(COUNT(p.id), 0) as con,
                     sum(p.product_count) as pn,
                     p.keyword
                   FROM
                     dtb_product_search_history p
                   WHERE
                     DATE_SUB(CURDATE(), INTERVAL 1 WEEK) <= date(p.create_date)
                   GROUP BY
                    p.keyword
                   )cc 
                GROUP BY
                    cc.con
                ORDER BY 
                    cc.con desc 
                LIMIT
                    30'; 
                 break;
           case 'month': // 月間
              $sql = '
                SELECT 
                   cc.con as count , group_concat(cc.keyword,"<PN>",cc.pn order by cc.keyword SEPARATOR "<SP>") as word
                FROM
                   (
                   SELECT
                     COALESCE(COUNT(p.id), 0) as con,
                     sum(p.product_count) as pn,
                     p.keyword
                   FROM
                     dtb_product_search_history p
                   WHERE
                     DATE_SUB(CURDATE(), INTERVAL 1 MONTH) <= date(p.create_date)
                   GROUP BY
                    p.keyword
                   )cc 
                GROUP BY
                    cc.con
                ORDER BY 
                    cc.con desc 
                LIMIT
                    30'; 
                 break;
           case 'year': // 年間
              $sql = '
                SELECT 
                   cc.con as count, group_concat(cc.keyword,"<PN>",cc.pn order by cc.keyword SEPARATOR "<SP>") as word
                FROM
                   (
                   SELECT
                     COALESCE(COUNT(p.id), 0) as con,
                     sum(p.product_count) as pn,
                     p.keyword
                   FROM
                     dtb_product_search_history p
                   WHERE
                     DATE_SUB(CURDATE(), INTERVAL 1 YEAR) <= date(p.create_date)
                   GROUP BY
                     p.keyword
                   )cc 
                GROUP BY
                    cc.con
                ORDER BY 
                    cc.con desc 
                LIMIT
                    30'; 
                 break;
        }

        $rsm = new ResultSetMapping();
        $rsm->addScalarResult('count', 'count');
        $rsm->addScalarResult('word', 'word');
        $rsm->addScalarResult('pn', 'pn');
        $query = $this->entityManager->createNativeQuery($sql, $rsm);

        $result = $query->getResult();
        $arr = [];
        foreach ($result as $history) {
            array_push($arr, $history['word'].'<&&>'.$history['count']);
        }
        return $arr;
    }

     /**
     * @param \Doctrine\ORM\EntityManagerInterface $em
     * @param array $excludes
     *
     * @return null|arr
     */
    protected function getTodayOrderIds()
    {
        $sql = "
        SELECT  o.id FROM  dtb_order o
        WHERE  TO_DAYS(o.operate_finish_post_date) = TO_DAYS(NOW()) OR TO_DAYS(o.operate_finish_shop_date) = TO_DAYS(NOW())";
        $rsm = new ResultSetMapping();
        $rsm->addScalarResult('id', 'id');
        $query = $this->entityManager->createNativeQuery($sql, $rsm);

        $result = $query->getResult();

        $arr = [];
        foreach ($result as $array) {
            array_push($arr, $array['id']);
        }
        return $arr;
    }

    /**
     * @param \Doctrine\ORM\EntityManagerInterface $em
     * @param array $excludes
     *
     * @return null|arr
     */
    protected function getTodayNewOrderIds()
    {
        $sql = "
        SELECT  o.id FROM  dtb_order o 
        INNER JOIN  mtb_order_status m ON o.order_status_id = m.id AND m.discriminator_type IN ('orderstatus')
        WHERE  m.id IN (:statues_new_wait)";
        $rsm = new ResultSetMapping();
        $rsm->addScalarResult('id', 'id');
        $query = $this->entityManager->createNativeQuery($sql, $rsm)
                 ->setParameter('statues_new_wait', $statues = [OrderStatus::NEW, OrderStatus::WAIT]);

        $result = $query->getResult();

        $arr = [];
        foreach ($result as $array) {
            array_push($arr, $array['id']);
        }
        return $arr;
    }
    
    /**
     * 一日買取実績一覧.
     *
     * @param 
     *
     * @return null|arr
     */
    protected function getProductSaleDay()
    {  
        $all_arr = [];
        $all_new_arr = [];
        //ids for 店頭＆郵送
        $orderIds = $this->getTodayOrderIds();
        $orders = $this->orderRepository->findBy(['id' => $orderIds ]);
        foreach($orders as $Order){
          $OrderItems = $Order->getOrderItems();
          foreach($OrderItems as $OrderItem){
             if($OrderItem->isProduct()){
                $key = $OrderItem->getProduct()->getId();
                $product_arr = $this->getProductArr($key,$all_arr);
                $new_product_arr = $this->getNewProductArray($product_arr,$OrderItem,$Order);
                $all_arr[$key] = $new_product_arr;
             }
          }
        }
        // ids for 新規
        $orderNewIds = $this->getTodayNewOrderIds();
        $newOrders = $this->orderRepository->findBy(['id' => $orderNewIds ]);
        foreach($newOrders as $Order){
          $OrderItems = $Order->getOrderItems();
          foreach($OrderItems as $OrderItem){
             if($OrderItem->isProduct()){
                $key = $OrderItem->getProduct()->getId();
                $product_arr = $this->getProductArr($key,$all_new_arr);
                $new_product_arr = $this->getNewProductArrayForNewIds($product_arr,$OrderItem,$Order);
                $all_new_arr[$key] = $new_product_arr;
             }
          }
        }
        $mergeArr = [];
        $keys = array_merge(array_keys($all_arr), array_keys($all_new_arr));
        foreach($keys as $key){
            if(array_key_exists($key, $all_arr)){
                $mergeArr[$key] = array_merge(array_key_exists($key, $mergeArr)? $mergeArr[$key] : [], $all_arr[$key]);
            }
            if(array_key_exists($key, $all_new_arr)){
                $mergeArr[$key] = array_merge(array_key_exists($key, $mergeArr)? $mergeArr[$key] : [], $all_new_arr[$key]);
            }
        }
        return $mergeArr;
    }

    protected function getLastRecordType($all_arr)
    {
       $last_record_type = null;
       if(!empty($all_arr)){
            $last_record_type = 'all_arr';
       }
        return $last_record_type;
    }
   
    protected function getNewProductArray($product_arr,$OrderItem,$Order)
    {
         if(!empty($product_arr)){
               $count = $OrderItem->getQuantity();               
               if($Order->getOperateFinishPostDate()){
                     if(array_key_exists('return_count', $product_arr)){
                          $count = $product_arr['return_count'] + $OrderItem->getQuantity();
                     }
                     $product_arr['return_count'] = $count;
               }
               if($Order->getOperateFinishShopDate()){
                     if(array_key_exists('paid_count', $product_arr)){
                          $count = $product_arr['paid_count'] + $OrderItem->getQuantity();
                     }
                     $product_arr['paid_count'] = $count;
               }
           }else{
                 $category = $this->getStringCategory($OrderItem->getProduct());
                 $product_arr['category'] = $category;
                 $product_arr['name'] = $OrderItem->getProduct()->getName();
                 if($Order->getOperateFinishPostDate()){
                       $product_arr['return_count'] = $OrderItem->getQuantity();
                 }
                 if($Order->getOperateFinishShopDate()){
                       $product_arr['paid_count'] = $OrderItem->getQuantity();
                 }
           }
           return $product_arr;
    }
    protected function getNewProductArrayForNewIds($product_arr,$OrderItem,$Order)
    {
         if(!empty($product_arr)){
               $count = $OrderItem->getQuantity();
               if($Order->getOrderStatus()->getId() == OrderStatus :: NEW || $Order->getOrderStatus()->getId() == OrderStatus :: WAIT){
                    if(array_key_exists('new_count', $product_arr)){
                        $count = $product_arr['new_count'] + $OrderItem->getQuantity();
                    }
                    $product_arr['new_count'] = $count;
               }
           }else{
                 $category = $this->getStringCategory($OrderItem->getProduct());
                 $product_arr['category'] = $category;
                 $product_arr['name'] = $OrderItem->getProduct()->getName();
                 if($Order->getOrderStatus()->getId() == OrderStatus :: NEW || $Order->getOrderStatus()->getId() == OrderStatus :: WAIT){
                    $product_arr['new_count'] = $OrderItem->getQuantity();
                 }
           }
           return $product_arr;
    }

    // 既に存在するレコードを取得する
    protected function getProductArr($key,$all_arr)
    {
       $product_arr = [];
       $product_arr = $this->getArray($key, $all_arr);
       return $product_arr;
    }
    
    protected function getArray($key,$arr)
    {
       $product_arr = [];
       if(array_key_exists($key, $arr)){
            $product_arr = $arr[$key];
       }
        return $product_arr;
    }
    
    protected function getStringCategory($Product)
    {
        $array = [];
        $ProductCategories = $Product->getProductCategories();
        foreach ($ProductCategories as $ProductCategory) {
                if (EntityUtil::isNotEmpty($ProductCategory)) {
                   array_push($array,$ProductCategory->getCategory()->getName());
                }
        }
        return implode($this->eccubeConfig['eccube_csv_export_multidata_separator'], $array);
    }

    protected function sortCategory($all_arr)
    {
        uksort($all_arr, function ($a, $b){
            $a_product = $this->productRepository->find($a);
            $b_product = $this->productRepository->find($b);
            $a_catogory = $a_product->getProductCategories()->first()->getCategory()->getId();
            $b_catogory = $b_product->getProductCategories()->first()->getCategory()->getId();
           
            $a_child_catogory = is_null($a_product->getProductCategories()[1]) ? 0 : $a_product->getProductCategories()[1]->getCategory()->getId();
            $b_child_catogory = is_null($b_product->getProductCategories()[1]) ? 0 : $b_product->getProductCategories()[1]->getCategory()->getId();
            if($a_catogory != $b_catogory){
                return $a_catogory < $b_catogory ? -1 : 1;
            }else{
                return $a_child_catogory < $b_child_catogory ? -1 : 1;
            } 
        });
        return $all_arr;
    }

    // INS-START CNC 2021/7/29
//    /**
//     * 今日仕入実績一覧.
//     *
//     * @return mixed[]
//     */
//    protected function getPayee()
//    {
//        $today_start = (new \DateTime())->setTime(0, 0, 0)
//            ->setTimezone(new \DateTimeZone('UTC'))
//            ->format('Y-m-d H:i:s');
//        $today_end = (new \DateTime())->setTime(23, 59, 59)
//            ->setTimezone(new \DateTimeZone('UTC'))
//            ->format('Y-m-d H:i:s');
//        $pdo = $this->entityManager->getConnection()->getWrappedConnection();
//        $sql = '
//                SELECT
//                    dpvd.id,
//                    dpvd.product_id,
//                    dpvd.product_code,
//                    dpvd.quantity,
//                    dpvd.payee_price,
//                    dpvd.payee_money_amount,
//                    dpvd.create_date,
//                    ms.state,
//                    dp.name,
//                    dc4.category_id AS category_id1,
//                    dc4.categoryName AS categoryName1,
//                    dc5.category_id AS category_id2,
//                    dc5.categoryName as categoryName2,
//                    dc6.category_id AS category_id3,
//                    dc6.categoryName as categoryName3
//                FROM
//                    dtb_payee_voucher_detail dpvd
//                    INNER JOIN dtb_payee_voucher_header dpvh
//                        ON dpvd.payee_voucher_header_id = dpvh.id
//                    INNER JOIN mtb_state ms
//                        ON dpvd.state_id = ms.id
//                    INNER JOIN dtb_product dp
//                        ON dpvd.product_id = dp.id
//                    INNER JOIN (
//                        SELECT
//                            dpvds.id,
//                            dpcs.category_id,
//                            dcs.category_name AS categoryName,
//                            dcs.hierarchy
//                        FROM
//                            dtb_payee_voucher_detail dpvds
//                            INNER JOIN dtb_payee_voucher_header dpvhs
//                                ON dpvds.payee_voucher_header_id = dpvhs.id
//                            INNER JOIN dtb_product dps
//                                ON dpvds.product_id = dps.id
//                            INNER JOIN dtb_product_category dpcs
//                                ON dpvds.product_id = dpcs.product_id
//                            INNER JOIN dtb_category dcs
//                                ON dcs.id = dpcs.category_id
//                        WHERE
//                            dpvhs.purchase_date BETWEEN \''.$today_start.'\' AND \''.$today_end.'\'
//                        AND
//                            dpcs.category_sub_flag = 0
//                    ) AS dc4
//                        ON dc4.id = dpvd.id
//                        AND dc4.hierarchy = 1
//                    LEFT JOIN (
//                        SELECT
//                            dpvds.id,
//                            dpcs.category_id,
//                            dcs.category_name AS categoryName,
//                            dcs.hierarchy
//                        FROM
//                            dtb_payee_voucher_detail dpvds
//                            INNER JOIN dtb_payee_voucher_header dpvhs
//                                ON dpvds.payee_voucher_header_id = dpvhs.id
//                            INNER JOIN dtb_product dps
//                                ON dpvds.product_id = dps.id
//                            INNER JOIN dtb_product_category dpcs
//                                ON dpvds.product_id = dpcs.product_id
//                            INNER JOIN dtb_category dcs
//                                ON dcs.id = dpcs.category_id
//                        WHERE
//                            dpvhs.purchase_date BETWEEN \''.$today_start.'\' AND \''.$today_end.'\'
//                        AND
//                            dpcs.category_sub_flag = 0
//                    ) AS dc5
//                        ON dc5.id = dpvd.id
//                        AND dc5.hierarchy = 2
//                    LEFT JOIN (
//                        SELECT
//                            dpvds.id,
//                            dpcs.category_id,
//                            dcs.category_name AS categoryName,
//                            dcs.hierarchy
//                        FROM
//                            dtb_payee_voucher_detail dpvds
//                            INNER JOIN dtb_payee_voucher_header dpvhs
//                                ON dpvds.payee_voucher_header_id = dpvhs.id
//                            INNER JOIN dtb_product dps
//                                ON dpvds.product_id = dps.id
//                            INNER JOIN dtb_product_category dpcs
//                                ON dpvds.product_id = dpcs.product_id
//                            INNER JOIN dtb_category dcs
//                                ON dcs.id = dpcs.category_id
//                        WHERE
//                            dpvhs.purchase_date BETWEEN \''.$today_start.'\' AND \''.$today_end.'\'
//                        AND
//                            dpcs.category_sub_flag = 0
//                    ) AS dc6
//                        ON dc6.id = dpvd.id
//                        AND dc6.hierarchy = 3
//                WHERE
//                    dpvh.purchase_date BETWEEN \''.$today_start.'\' AND \''.$today_end.'\'
//                ORDER BY
//                    category_id1,
//                    category_id2,
//                    category_id3,
//                    product_code,
//                    name ';
//
//        $stmt = $pdo->prepare($sql);
//        $stmt->execute();
//        $result = $stmt->fetchAll();
//        return $result;
//    }
//
//    /**
//     * 今日売上実績一覧.
//     *
//     * @return mixed[]
//     */
//    protected function getRevenue()
//    {
//        $today_start = (new \DateTime())->setTime(0, 0, 0)
//            ->setTimezone(new \DateTimeZone('UTC'))
//            ->format('Y-m-d H:i:s');
//        $today_end = (new \DateTime())->setTime(23, 59, 59)
//            ->setTimezone(new \DateTimeZone('UTC'))
//            ->format('Y-m-d H:i:s');
//        $pdo = $this->entityManager->getConnection()->getWrappedConnection();
//        $sql = '
//                SELECT
//                    dsvd.id,
//                    dsvd.product_id,
//                    dsvd.product_code,
//                    dsvd.quantity,
//                    dsvd.sales_price,
//                    dsvd.total_sales_amount,
//                    dsvd.create_date,
//                    ms.state,
//                    dp.name,
//                    dc4.category_id AS category_id1,
//                    dc4.categoryName AS categoryName1,
//                    dc5.category_id AS category_id2,
//                    dc5.categoryName as categoryName2,
//                    dc6.category_id AS category_id3,
//                    dc6.categoryName as categoryName3
//                FROM
//                    dtb_sales_voucher_detail dsvd
//                    INNER JOIN dtb_sales_voucher_header dsvh
//                        ON dsvd.sales_voucher_header_id = dsvh.id
//                    INNER JOIN mtb_state ms
//                        ON dsvd.state_id = ms.id
//                    INNER JOIN dtb_product dp
//                        ON dsvd.product_id = dp.id
//                    INNER JOIN (
//                        SELECT
//                            dsvds.id,
//                            dpcs.category_id,
//                            dcs.category_name AS categoryName,
//                            dcs.hierarchy
//                        FROM
//                            dtb_sales_voucher_detail dsvds
//                            INNER JOIN dtb_sales_voucher_header dsvhs
//                                ON dsvds.sales_voucher_header_id = dsvhs.id
//                            INNER JOIN dtb_product dps
//                                ON dsvds.product_id = dps.id
//                            INNER JOIN dtb_product_category dpcs
//                                ON dsvds.product_id = dpcs.product_id
//                            INNER JOIN dtb_category dcs
//                                ON dcs.id = dpcs.category_id
//                        WHERE
//                            dsvhs.sales_date BETWEEN \''.$today_start.'\' AND \''.$today_end.'\'
//                    ) AS dc4
//                        ON dc4.id = dsvd.id
//                        AND dc4.hierarchy = 1
//                    LEFT JOIN (
//                        SELECT
//                            dsvds.id,
//                            dpcs.category_id,
//                            dcs.category_name AS categoryName,
//                            dcs.hierarchy
//                        FROM
//                            dtb_sales_voucher_detail dsvds
//                            INNER JOIN dtb_sales_voucher_header dsvhs
//                                ON dsvds.sales_voucher_header_id = dsvhs.id
//                            INNER JOIN dtb_product dps
//                                ON dsvds.product_id = dps.id
//                            INNER JOIN dtb_product_category dpcs
//                                ON dsvds.product_id = dpcs.product_id
//                            INNER JOIN dtb_category dcs
//                                ON dcs.id = dpcs.category_id
//                        WHERE
//                            dsvhs.sales_date BETWEEN \''.$today_start.'\' AND \''.$today_end.'\'
//                    )  AS dc5
//                        ON dc5.id = dsvd.id
//                        AND dc5.hierarchy = 2
//                    LEFT JOIN (
//                        SELECT
//                            dsvds.id,
//                            dpcs.category_id,
//                            dcs.category_name AS categoryName,
//                            dcs.hierarchy
//                        FROM
//                            dtb_sales_voucher_detail dsvds
//                            INNER JOIN dtb_sales_voucher_header dsvhs
//                                ON dsvds.sales_voucher_header_id = dsvhs.id
//                            INNER JOIN dtb_product dps
//                                ON dsvds.product_id = dps.id
//                            INNER JOIN dtb_product_category dpcs
//                                ON dsvds.product_id = dpcs.product_id
//                            INNER JOIN dtb_category dcs
//                                ON dcs.id = dpcs.category_id
//                        WHERE
//                            dsvhs.sales_date BETWEEN \''.$today_start.'\' AND \''.$today_end.'\'
//                    )  AS dc6
//                        ON dc6.id = dsvd.id
//                        AND dc6.hierarchy = 3
//                WHERE
//                    dsvh.sales_date BETWEEN \''.$today_start.'\' AND \''.$today_end.'\'
//                ORDER BY
//                    category_id1,
//                    category_id2,
//                    category_id3,
//                    product_code,
//                    name';
//
//        $stmt = $pdo->prepare($sql);
//        $stmt->execute();
//        $result = $stmt->fetchAll();
//        return $result;
//    }
    // INS-END CNC 2021/7/29

    protected function sortCategoryChild($all_arr)
    {
        uksort($all_arr, function ($a, $b){
            $a_product = $this->productRepository->find($a);
            $b_product = $this->productRepository->find($b);
            $a_catogory = $a_product->getProductCategories()->first()->getCategory()->getId();
            $b_catogory = $b_product->getProductCategories()->first()->getCategory()->getId();

            $a_parent_catogory = is_null($a_product->getProductCategories()[1]) ? 0 : $a_product->getProductCategories()[1]->getCategory()->getId();
            $b_parent_catogory = is_null($b_product->getProductCategories()[1]) ? 0 : $b_product->getProductCategories()[1]->getCategory()->getId();

            $a_child_catogory = is_null($a_product->getProductCategories()[2]) ? 0 : $a_product->getProductCategories()[2]->getCategory()->getId();
            $b_child_catogory = is_null($b_product->getProductCategories()[2]) ? 0 : $b_product->getProductCategories()[2]->getCategory()->getId();

            if($a_catogory == $b_catogory && $a_parent_catogory == $b_parent_catogory){
                return $a_child_catogory < $b_child_catogory ? -1 : 1;
            }else if($a_catogory == $b_catogory && $a_parent_catogory != $b_parent_catogory){
                return $a_parent_catogory < $b_parent_catogory ? -1 : 1;
            }else if($a_catogory != $b_catogory){
                return $a_catogory < $b_catogory ? -1 : 1;
            }
        });
        return $all_arr;
    }

    protected function sortProductName($all_arr)
    {
        uksort($all_arr, function ($a, $b){
            $a_product = $this->productRepository->find($a);
            $b_product = $this->productRepository->find($b);
            $a_catogory = $a_product->getProductCategories()->first()->getCategory()->getId();
            $b_catogory = $b_product->getProductCategories()->first()->getCategory()->getId();
            $a_parent_catogory = is_null($a_product->getProductCategories()[1]) ? 0 : $a_product->getProductCategories()[1]->getCategory()->getId();
            $b_parent_catogory = is_null($b_product->getProductCategories()[1]) ? 0 : $b_product->getProductCategories()[1]->getCategory()->getId();
            $a_child_catogory = is_null($a_product->getProductCategories()[2]) ? 0 : $a_product->getProductCategories()[2]->getCategory()->getId();
            $b_child_catogory = is_null($b_product->getProductCategories()[2]) ? 0 : $b_product->getProductCategories()[2]->getCategory()->getId();
            $a_product_name = $a_product->getName();
            $b_product_name = $b_product->getName();
            if($a_catogory == $b_catogory && $a_parent_catogory == $b_parent_catogory && $a_child_catogory == $b_child_catogory){
                return strnatcmp($a_product_name, $b_product_name) < 0 ? -1 : 1;
            }else if($a_catogory == $b_catogory && $a_parent_catogory == $b_parent_catogory && $a_child_catogory != $b_child_catogory){
                return $a_child_catogory < $b_child_catogory ? -1 : 1;
            }else if($a_catogory == $b_catogory && $a_parent_catogory != $b_parent_catogory){
                return $a_parent_catogory < $b_parent_catogory ? -1 : 1;
            }else if($a_catogory != $b_catogory){
                return $a_catogory < $b_catogory ? -1 : 1;
            }
        });
        return $all_arr;
    }

    /**
     * insert db
     *
     * @Route("/%eccube_admin_route%/insert_purchase_record", name="admin_insert_purchase_record", methods={"POST"})
     *
     * @param Request $request
     *
     */
    public function savePurchaseRecord(Request $request)
    {

        // $bulk_token = $request->get('_bulk_token');
        // if (!($bulk_token && $bulk_token === "e56f431577eb42f5b67fd624bfa47d4d")) {
        //     return $this->json(['status' => 'NG'], 400); 
        // }

        $productSaleDay = $this->getProductSaleDay();

        foreach ($productSaleDay as $product_id => $value){
            $this->insertPurchaseRecord($product_id,$value);
        }

        return $this->json( ['result' => 'OK'], 200);
    }

    public function getSaleDay()
    {
        $result = [];
        $has_sale_today = false;
        $sql = "
        SELECT 
          dpr.product_id,
          dpr.category,
          dpr.name,
          dpr.new_count,
          dpr.return_count,
          dpr.paid_count
        FROM 
          dtb_purchase_record dpr
        WHERE
          TO_DAYS(dpr.create_date) = TO_DAYS(NOW())";
       $rsm = new ResultSetMapping();
       $rsm->addScalarResult('product_id', 'product_id');
       $rsm->addScalarResult('category', 'category');
       $rsm->addScalarResult('name', 'name');
       $rsm->addScalarResult('new_count', 'new_count');
       $rsm->addScalarResult('return_count', 'return_count');
       $rsm->addScalarResult('paid_count', 'paid_count');
       $query = $this->entityManager->createNativeQuery($sql, $rsm);
       
       $query_result = $query->getResult();
        if(count($query_result) > 0){
            $has_sale_today = true;
        }
        $result_map = [];
        foreach($query_result as $item){
            $key = $item['product_id'];
            $result_map[$key] = $item;
        }
        // $sort_category_array = $this->sortCategory($result_map);
        // $sort_category_child_array = $this->sortCategoryChild($sort_category_array);
        // $sort_result = $this->sortProductName($sort_category_child_array);
        
        // sort for performance
        usort($result_map, function($a, $b) {
            if( $a['category'] != $b['category']){
                return $a['category'] < $b['category'] ? -1 : 1;
            }else{
                return $a['product_id'] > $b['product_id'] ? -1 : 1;
            }
        });
        $result['all_arr'] = $result_map;
        $result['has_sale_today'] = $has_sale_today;
        $result['last_record_type'] = $this->getLastRecordType($query_result);
        return $result;
    }

     /**
     * @param \Doctrine\ORM\EntityManagerInterface $em
     * @param array $value
     *
     */
    protected function insertPurchaseRecord($product_id,$value)
    {
     
        $sql = "
        INSERT INTO 
           dtb_purchase_record
            (product_id, 
            category, 
            name, 
            new_count, 
            return_count, 
            paid_count, 
            update_date, 
            create_date,
            discriminator_type) 
           VALUES 
           (:product_id, 
           :category, 
           :name,
           :new_count, 
           :return_count,
           :paid_count,
           current_timestamp, 
           current_timestamp,
           'purchaserecord')
           ON DUPLICATE KEY UPDATE 
           category = VALUES(category),
           name= VALUES(name),
           new_count= VALUES(new_count),
           return_count= VALUES(return_count),
           paid_count= VALUES(paid_count),
           create_date= current_timestamp";
        $sqlParams = [
            'product_id'     => $product_id,
            'category'     =>  $value['category'],
            'name'     => $value['name'],
            'new_count'     => array_key_exists('new_count',$value) ? $value['new_count'] : 0,
            'return_count'     => array_key_exists('return_count',$value) ? $value['return_count'] : 0,
            'paid_count'     => array_key_exists('paid_count',$value) ? $value['paid_count'] : 0,
          ];
          $result = $this->entityManager->getConnection()
            ->executeQuery(
              $sql,
              $sqlParams
            );
          $this->entityManager->clear();
    }

    // INS-START CNC 2021/7/29
//    /**
//     * @return mixed|mixed[]|null
//     */
//    protected function getPayeeDaily()
//    {
//        try {
//            $now = new \DateTime();
//            $update_time = $this->session->get('update_payee_time');
//
//            if ($update_time) {
//                $diff = $now->getTimestamp() - $update_time;
//
//                if ($diff >= 30 * 60) {
//                    $result = $this->getPayee();
//                    $this->session->set('update_payee_time', $now->getTimestamp());
//                    $this->session->set('admin_payee_day', $result);
//                    return $result;
//                } else {
//                    return $this->session->get('admin_payee_day');
//                }
//            } else {
//                $this->session->set('update_payee_time', $now->getTimestamp());
//                $result = $this->getPayee();
//                $this->session->set('admin_payee_day', $result);
//                return $result;
//            }
//        } catch (\Exception $e) {
//            return [];
//        }
//    }
//
//    /**
//     * @return mixed|mixed[]|null
//     */
//    protected function getRevenueDaily()
//    {
//        try {
//            $now = new \DateTime();
//            $update_time = $this->session->get('update_revenue_time');
//
//            if ($update_time) {
//                $diff = $now->getTimestamp() - $update_time;
//
//                if ($diff >= 30 * 60) {
//                    $result = $this->getRevenue();
//                    $this->session->set('update_revenue_time', $now->getTimestamp());
//                    $this->session->set('admin_revenue_day', $result);
//                    return $result;
//                } else {
//                    return $this->session->get('admin_revenue_day');
//                }
//            } else {
//                $this->session->set('update_revenue_time', $now->getTimestamp());
//                $result = $this->getRevenue();
//                $this->session->set('admin_revenue_day', $result);
//                return $result;
//            }
//        } catch (\Exception $e) {
//            return [];
//        }
//    }
    // INS-END CNC 2021/7/29
}
