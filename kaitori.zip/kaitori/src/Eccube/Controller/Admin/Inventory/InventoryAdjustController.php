<?php


namespace Eccube\Controller\Admin\Inventory;

use Doctrine\Common\Collections\ArrayCollection;
use Eccube\Controller\AbstractController;
use Eccube\Entity\LogControllable;
use Eccube\Entity\Member;
use Eccube\Entity\Product;
use Eccube\Entity\StockAdjustDetail;
use Eccube\Entity\StockAdjustList;
use Eccube\Entity\StockListProductUnit;
use Eccube\Entity\StockListStorehouseUnit;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\InputMultipleSerialType;
use Eccube\Form\Type\Admin\InventoryAdjustListType;
use Eccube\Form\Type\Admin\InventoryProductSelectType;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\Master\SpecialAuthorityRepository;
use Eccube\Repository\PlaceRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\StateRepository;
use Eccube\Repository\StockAdjustDetailRepository;
use Eccube\Repository\StockAdjustListRepository;
use Eccube\Repository\StockListProductUnitRepository;
use Eccube\Repository\StockListStorehouseUnitRepository;
use Eccube\Service\PurchaseFlow\Processor\VoucherNoProcessor;
use Eccube\Util\StringUtil;
use Knp\Component\Pager\Paginator;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Routing\RouterInterface;

/**
 * プログラム名 ： InventoryAdjustController.php
 * 概　　要     ： 在庫調整画面タイプ
 * 作　　成     ： 2021/08/24 CNC
 */
class InventoryAdjustController extends AbstractController
{
    const TEMPORARY_VOUCHER_NO = '0';

    /**
     * @var StockAdjustListRepository
     */
    protected $stockAdjustListRepository;

    /**
     * @var StockAdjustDetailRepository
     */
    protected $stockAdjustDetailRepository;

    /**
     * @var SpecialAuthorityRepository
     */
    protected $specialAuthorityRepository;

    /**
     * @var StockListStorehouseUnitRepository
     */
    protected $stockListStorehouseUnitRepository;

    /**
     * @var StockListProductUnitRepository
     */
    protected $stockListProductUnitRepository;

    /**
     * @var ProductClassRepository
     */
    protected $productClassRepository;

    /**
     * @var StateRepository
     */
    protected $stateRepository;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var PlaceRepository
     */
    protected $placeRepository;

    /**
     * @var VoucherNoProcessor
     */
    protected $voucherNoProcessor;

    /**
     * @param VoucherNoProcessor $voucherNoProcessor 伝票番号作成
     * @param StockAdjustListRepository $stockAdjustListRepository 在庫調整
     * @param StockAdjustDetailRepository $stockAdjustDetailRepository 在庫調整明細
     * @param SpecialAuthorityRepository $specialAuthorityRepository 特殊権限
     * @param StateRepository $stateRepository 状態
     * @param ProductClassRepository $productClassRepository 商品クラス
     * @param ProductRepository $productRepository 商品
     * @param CategoryRepository $categoryRepository カテゴリ
     * @param PlaceRepository $placeRepository 置場
     * @param StockListStorehouseUnitRepository $stockListStorehouseUnitRepository 在庫一覧（置場単位）
     * @param StockListProductUnitRepository $stockListProductUnitRepository 在庫一覧（商品単位）
     */
    public function __construct(
        StockAdjustListRepository $stockAdjustListRepository,
        StockAdjustDetailRepository $stockAdjustDetailRepository,
        SpecialAuthorityRepository $specialAuthorityRepository,
        StockListStorehouseUnitRepository $stockListStorehouseUnitRepository,
        StockListProductUnitRepository $stockListProductUnitRepository,
        ProductClassRepository $productClassRepository,
        StateRepository $stateRepository,
        ProductRepository $productRepository,
        CategoryRepository $categoryRepository,
        PlaceRepository $placeRepository,
        VoucherNoProcessor $voucherNoProcessor
    ) {
        $this->stockAdjustListRepository = $stockAdjustListRepository;
        $this->stockAdjustDetailRepository = $stockAdjustDetailRepository;
        $this->specialAuthorityRepository = $specialAuthorityRepository;
        $this->stockListStorehouseUnitRepository = $stockListStorehouseUnitRepository;
        $this->stockListProductUnitRepository = $stockListProductUnitRepository;
        $this->productClassRepository = $productClassRepository;
        $this->stateRepository = $stateRepository;
        $this->productRepository = $productRepository;
        $this->categoryRepository = $categoryRepository;
        $this->placeRepository = $placeRepository;
        $this->voucherNoProcessor = $voucherNoProcessor;
    }

    /**
     * @Route("/%eccube_admin_route%/inventory_adjust", name="admin_inventory_adjust")
     * @Route("/%eccube_admin_route%/inventory_adjust/edit/{id}", requirements={"id" = "\d+"}, name="admin_inventory_inventory_adjust")
     * @Route("/%eccube_admin_route%/inventory_adjust/edit_kubun/{kubun}", requirements={"kubun" = "\d+"}, name="admin_inventory_inventory_adjust_kubun")
     * @Template("@admin/Inventory/inventory_adjust.twig")
     * @param Request $request Request
     * @param int|null $id id
     * @param int|null $kubun 処理区分
     * @param RouterInterface|null $router RouterInterface
     * @throws NotFoundHttpException
     * @throws \Exception
     * @return array|RedirectResponse
     */
    public function index(Request $request, int $id = null, int $kubun = null, RouterInterface $router = null)
    {
        $today = new \DateTime();
        $member = $this->getUser();

        // 状態変更の場合、処理対象再取込
        if ('POST' === $request->getMethod()) {
            // 状態変更の場合
            // 1:在庫移動　2:在庫調整　3:在庫移動登録　4:在庫調整登録
            if ($request->get('inventory_adjust_list')['submitFlg'] == 1 || $request->get('inventory_adjust_list')['submitFlg'] == 2) {
                return $this->redirectToRoute('admin_inventory_inventory_adjust_kubun', ['kubun' => $request->get('inventory_adjust_list')['submitFlg']]);
            }
        }

        // 明細行数
        $now_row_no = 0;

        // 1:在庫移動　2:在庫調整　3:在庫移動登録　4:在庫調整登録
        $submitFlg = 0;
        if ($kubun == 2) {
            $submitFlg = 2;
        } elseif ($kubun == 1) {
            $submitFlg = 1;
        }

        // 1:在庫移動　2:在庫調整　3:在庫移動登録　4:在庫調整登録
        if ($id == null) {
            // 空のエンティティを作成、さらに初期値を設定する
            $entity_inventory_adjust_list = (new StockAdjustList());

            // 担当者ID、作成者、更新者、作成日時、更新日時：ログインユーザ
            if ($member) {
                /** @var Member $member */
                $entity_inventory_adjust_list = $entity_inventory_adjust_list
                    ->setrepresentative($member)
                    ->setCreateUserName($member->getName())
                    ->setUpdateUserName($member->getName())
                    ->setCreateDate($today)
                    ->setUpdateDate($today);
            }
        } else {
            /** @var StockAdjustList $entity_inventory_adjust_list */
            $entity_inventory_adjust_list = $this->stockAdjustListRepository->find($id);
        }

        // 削除比較用
        $entity_inventory_adjust_detail_collection_for_delete = new ArrayCollection();
        foreach ($entity_inventory_adjust_list->getInventoryAdjustDetail() as $detail) {
            $entity_inventory_adjust_detail_collection_for_delete->add($detail);
        }

        $builder_inventory_adjust_list = $this->formFactory
            ->createBuilder(InventoryAdjustListType::class, $entity_inventory_adjust_list);

        $form = $builder_inventory_adjust_list->getForm();

        if ('POST' === $request->getMethod()) {
            $form->handleRequest($request);

            // 成功後の遷移先URL
            $url_after_success = [];

            // 1:在庫移動　2:在庫調整　3:在庫移動登録　4:在庫調整登録
            if ($request->get('inventory_adjust_list')['submitFlg'] == 4) {
                $submitFlg = 2;
            } elseif ($request->get('inventory_adjust_list')['submitFlg'] == 3) {
                $submitFlg = 1;
            }

            if ($form->isValid()) {
                /** @var StockAdjustList $inventory_adjust_list */
                $inventory_adjust_list = $form->getData();

                if ($request->get('mode') == 'register') {
                    try {
                        log_info('在庫調整登録開始', [$id]);

                        $inventory_adjust_list->setStockAdjustVoucherNo(self::TEMPORARY_VOUCHER_NO);

                        if ($inventory_adjust_list->getProcessingType() == null || $inventory_adjust_list->getProcessingType() == '0') {
                            $inventory_message = trans('admin.inventory.adjust.inventory_move');
                        } else {
                            $inventory_message = trans('admin.inventory.adjust.inventory_adjust');
                        }
                        $inventory_adjust_list->setProcessingType($inventory_message)
                            ->setStockAdjustmentsDate($today);

                        // 明細
                        $inventory_adjust_detail_no = $this->stockAdjustDetailRepository
                            ->getMaxDetailNoInStockAdjustDetail($inventory_adjust_list);
                        $collection_inventory_adjust_list_details = $inventory_adjust_list->getInventoryAdjustDetail();

                        $array_form_details = $collection_inventory_adjust_list_details;
                        $now_row_no = $array_form_details
                            ? count($array_form_details)
                            : 0;

                        // 削除
                        foreach ($entity_inventory_adjust_detail_collection_for_delete as $origin_detail) {
                            if ($collection_inventory_adjust_list_details->contains($origin_detail) === false) {
                                $this->entityManager->remove($origin_detail);
                            }
                        }

                        $loginFlg = false;

                        // 変更
                        if ($collection_inventory_adjust_list_details && is_array($collection_inventory_adjust_list_details->getValues())) {
                            $array_inventory_adjust_list_details = $collection_inventory_adjust_list_details->getValues();

                            $index = 0;
                            $serialArray = [];
                            $changeProductCode = 0;
                            $changeProductId = 0;
                            $changeProductClass = new \Eccube\Entity\ProductClass();
                            $changeState = 0;
                            $changeStorehouse = 0;
                            $tempProductCode = 0;
                            $tempState = 0;
                            $tempStorehouse = 0;
                            $stock_by_product_conditions = [];
                            $array_detail_serial_flg = [];
                            // 設定
                            /** @var StockAdjustDetail $entity_detail */
                            foreach ($array_inventory_adjust_list_details as $line_no => $entity_detail) {
                                if ($entity_detail->getCheckFlg() == 0 &&
                                    ($inventory_adjust_list->getProcessingType() == trans('admin.inventory.adjust.inventory_move'))) {
                                    $inventory_adjust_list->removeStockAdjustDetail($entity_detail);
                                    continue;
                                } else {
                                    $loginFlg = true;
                                }

                                if (!$entity_detail->getId()) {
                                    $entity_detail->setStockAdjustDetailNo(($entity_detail->getStockAdjustDetailNo()) ?: ++$inventory_adjust_detail_no)
                                        ->setInventoryAdjustList($inventory_adjust_list)
                                        ->setStockAdjustVoucherNo(self::TEMPORARY_VOUCHER_NO)
                                        ->setCreateUserName($entity_detail->getCreateUserName() ?: $member->getName())
                                        ->setUpdateDate($today)
                                        ->setCreateDate($today)
                                        ->setUpdateUserName($member->getName());
                                }

                                // 在庫移動
                                if ($inventory_adjust_list->getProcessingType() == trans('admin.inventory.adjust.inventory_move')) {
                                    $url_after_success = [
                                        'url' => 'admin_inventory_adjust',
                                        'conditions' => [],
                                    ];
                                    // シリアルがnullの場合
                                    if ($entity_detail->getSerialNo() == '' || $entity_detail->getSerialNo() == null) {
                                        // 移動元置場
                                        $collection_stock_list_storehouse_unit_from = $this->stockListStorehouseUnitRepository->findStockListStorehouseUnitByKey(
                                            $entity_detail->getProductCode(), $entity_detail->getStateId(), $inventory_adjust_list->getFromStorehouse()->getId(), true
                                        );
                                        $allFlg = false;
                                        if (isset($collection_stock_list_storehouse_unit_from[0])) {
                                            $entity_stock_list_storehouse_unit = $collection_stock_list_storehouse_unit_from[0];
                                            $sum_stock_quantity = 0;
                                            /** @var StockListStorehouseUnit $item_storehouse_unit */
                                            foreach ($collection_stock_list_storehouse_unit_from as $item_storehouse_unit) {
                                                $sum_stock_quantity += $item_storehouse_unit->getStockQuantity();
                                            }
                                            if ($sum_stock_quantity <= 0) {
                                                continue;
                                            }
                                            $entity_stock_list_storehouse_unit->setStockQuantity($entity_stock_list_storehouse_unit->getStockQuantity()
                                                + $entity_detail->getTransferQuantity());
                                            $entity_stock_list_storehouse_unit->setUpdateUserName($member->getName());
                                            // CNC DEL-START 2021/10/27 在庫移動するとき、全部移動の場合、複数のレコードが作成されしまった。
                                            //                          そして部分移動をすれば、複数のレコードは一緒に移動数量を加算しまった。
//                                            // 全部移動---- 移動元置場
//                                            if ($entity_stock_list_storehouse_unit->getStockQuantity() + $entity_detail->getTransferQuantity() == 0) {
//                                                    $entity_stock_list_storehouse_unit->setStorehouse($inventory_adjust_list->getToStorehouse())
//                                                        ->setUpdateUserName($member->getName());
//                                                    $allFlg = true;
//                                                }
//                                                // 部分移動---- 移動元置場
//                                                else {
//                                            }
                                            // CNC DEL-END 2021/10/27
                                            $this->entityManager->persist($entity_stock_list_storehouse_unit);
                                            $this->entityManager->flush($entity_stock_list_storehouse_unit);
                                            LogControllable::print_log(__FILE__, '########## Inventory Move: stock list by storehouse', [$entity_stock_list_storehouse_unit->toArray()]);
                                        }

                                        if (!$allFlg) {
                                            // 移動先置場
                                            $collection_stock_list_storehouse_unit_to = $this->stockListStorehouseUnitRepository->findStockListStorehouseUnitByKey(
                                                $entity_detail->getProductCode(), $entity_detail->getStateId(), $inventory_adjust_list->getToStorehouse()->getId(), true
                                            );
                                            // 移動先置場が存在の場合
                                            if (count($collection_stock_list_storehouse_unit_to) > 0) {
                                                $entity_stock_list_storehouse_unit_to = $collection_stock_list_storehouse_unit_to[0];
                                                $entity_stock_list_storehouse_unit_to->setStockQuantity($entity_stock_list_storehouse_unit_to->getStockQuantity()
                                                    - $entity_detail->getTransferQuantity());
                                                $entity_stock_list_storehouse_unit_to->setUpdateUserName($member->getName());
                                                $this->entityManager->persist($entity_stock_list_storehouse_unit_to);
                                                $this->entityManager->flush($entity_stock_list_storehouse_unit_to);
                                                LogControllable::print_log(__FILE__, '########## Inventory Move: stock list by storehouse', [$entity_stock_list_storehouse_unit_to->toArray()]);
                                            } else {
                                                // 追加データ
                                                $entity_stock_list_storehouse_unit_add = new StockListStorehouseUnit();
                                                $entity_stock_list_storehouse_unit_add
                                                    ->setProductId($entity_detail->getProductId())
                                                    ->setProductClass($entity_detail->getProductClass())
                                                    ->setProductCode($entity_detail->getProductCode())
                                                    ->setSerialNo($entity_detail->getSerialNo())
                                                    ->setState($entity_detail->getState())
                                                    ->setStorehouse($inventory_adjust_list->getToStorehouse())
                                                    ->setStockQuantity(0 - $entity_detail->getTransferQuantity())
                                                    ->setCreateUserName($member->getUsername())
                                                    ->setCreateDate($today)
                                                    ->setUpdateUserName($member->getUsername())
                                                    ->setUpdateDate($today);
                                                $this->entityManager->persist($entity_stock_list_storehouse_unit_add);
                                                $this->entityManager->flush($entity_stock_list_storehouse_unit_add);
                                                LogControllable::print_log(__FILE__, '########## Inventory Move: stock list by storehouse', [$entity_stock_list_storehouse_unit_add->toArray()]);
                                            }
                                        }
                                    } else {
                                        // シリアルがnull以外の場合
                                        if ($entity_detail->getSerialNo() !== '' && $entity_detail->getSerialNo() !== null) {
                                            if (strpos($entity_detail->getSerialNo(), "\r\n") !== false) {
                                                $serialArray = explode("\r\n", $entity_detail->getSerialNo());
                                            } elseif (strpos($entity_detail->getSerialNo(), ',') !== false) {
                                                $serialArray = explode(',', $entity_detail->getSerialNo());
                                            } else {
                                                $serialArray = [$entity_detail->getSerialNo()];
                                            }
                                            foreach ($serialArray as $serialNo) {
                                                // 移動元置場
//                                                $allFlg = false;
                                                $collection_stock_list_storehouse_unit_from = $this->stockListStorehouseUnitRepository->getStockListStorehouseUnitByKey(
                                                    $entity_detail->getProductCode(),
                                                    $entity_detail->getStateId(),
                                                    $inventory_adjust_list->getFromStorehouse()->getId(),
                                                    $serialNo
                                                );
                                                $collection_stock_list_storehouse_unit_to = $this->stockListStorehouseUnitRepository->getStockListStorehouseUnitByKey(
                                                    $entity_detail->getProductCode(),
                                                    $entity_detail->getStateId(),
                                                    $inventory_adjust_list->getToStorehouse()->getId(),
                                                    $serialNo
                                                );
                                                if ((!isset($collection_stock_list_storehouse_unit_to)) || (count($collection_stock_list_storehouse_unit_to) == 0)) {
                                                    if (isset($collection_stock_list_storehouse_unit_from)) {
                                                        foreach ($collection_stock_list_storehouse_unit_from as $item) {
                                                            $entity_stock_list_storehouse_unit = $item;
                                                            if ($entity_stock_list_storehouse_unit->getStockQuantity() <= 0) {
                                                                continue;
                                                            }
                                                            $entity_stock_list_storehouse_unit->setStorehouse($inventory_adjust_list->getToStorehouse())
                                                                ->setUpdateUserName($member->getName());
                                                            // CNC DEL-START 2021/10/27
//                                                        if ($entity_stock_list_storehouse_unit->getStockQuantity() + $entity_detail->getTransferQuantity() / count($serialArray) == 0) {
//                                                            // 全部移動---- 移動元置場
//                                                            $allFlg = true;
//                                                        } else {
//                                                            // 部分移動---- 移動元置場
//                                                            $entity_stock_list_storehouse_unit->setStockQuantity($entity_stock_list_storehouse_unit->getStockQuantity()
//                                                                + $entity_detail->getTransferQuantity());
//                                                            $entity_stock_list_storehouse_unit->setUpdateUserName($member->getName());
//                                                        }
                                                            // CNC DEL-END 2021/10/27
                                                            $this->entityManager->persist($entity_stock_list_storehouse_unit);
                                                            LogControllable::print_log(__FILE__, '########## Inventory Move: stock list by storehouse', [$entity_stock_list_storehouse_unit->toArray()]);
                                                        }
                                                    }
                                                } else {
                                                    if (isset($collection_stock_list_storehouse_unit_from)) {
                                                        foreach ($collection_stock_list_storehouse_unit_from as $item_from) {
                                                            foreach ($collection_stock_list_storehouse_unit_to as $item_to) {
                                                                $entity_stock_list_storehouse_unit_from = $item_from;
                                                                $entity_stock_list_storehouse_unit_to = $item_to;
                                                                if ($entity_stock_list_storehouse_unit_from->getStockQuantity() <= 0) {
                                                                    continue;
                                                                }
                                                                $entity_stock_list_storehouse_unit_from->setStockQuantity(0)
                                                                    ->setUpdateUserName($member->getName());
                                                                $entity_stock_list_storehouse_unit_to->setStockQuantity(1)
                                                                    ->setUpdateUserName($member->getName());

                                                                $this->entityManager->persist($entity_stock_list_storehouse_unit_from);
                                                                $this->entityManager->flush($entity_stock_list_storehouse_unit_from);
                                                                $this->entityManager->persist($entity_stock_list_storehouse_unit_to);
                                                                $this->entityManager->flush($entity_stock_list_storehouse_unit_to);
                                                                LogControllable::print_log(__FILE__, '########## Inventory Move: stock list by storehouse', [$entity_stock_list_storehouse_unit_from->toArray()]);
                                                                LogControllable::print_log(__FILE__, '########## Inventory Move: stock list by storehouse', [$entity_stock_list_storehouse_unit_to->toArray()]);
                                                            }

                                                        }
                                                    }
                                                }

                                                // CNC DEL-START 2021/10/27
//                                                if (!$allFlg) {
//                                                    // 移動先置場
//                                                    $collection_stock_list_storehouse_unit_to = $this->stockListStorehouseUnitRepository->getStockListStorehouseUnitByKey(
//                                                        $entity_detail->getProductCode(),
//                                                        $entity_detail->getStateId(),
//                                                        $inventory_adjust_list->getToStorehouse()->getId(),
//                                                        $serialNo
//                                                    );
//                                                    // 移動先置場が存在の場合
//                                                    if (count($collection_stock_list_storehouse_unit_to) > 0) {
//                                                        foreach ($collection_stock_list_storehouse_unit_to as $item) {
//                                                            $entity_stock_list_storehouse_unit = $item;
//                                                            $entity_stock_list_storehouse_unit
//                                                                ->setStockQuantity(
//                                                                    $entity_stock_list_storehouse_unit->getStockQuantity()
//                                                                    - $entity_detail->getTransferQuantity() / count($serialArray)
//                                                                );
//                                                            $entity_stock_list_storehouse_unit->setUpdateUserName($member->getName());
//                                                            $this->entityManager->persist($entity_stock_list_storehouse_unit);
//                                                        }
//                                                    } else {
//                                                        // 追加データ
//                                                        $entity_stock_list_storehouse_unit_add = new StockListStorehouseUnit();
//                                                        $entity_stock_list_storehouse_unit_add
//                                                            ->setProductId($entity_detail->getProductId())
//                                                            ->setProductClass($entity_detail->getProductClass())
//                                                            ->setProductCode($entity_detail->getProductCode())
//                                                            ->setSerialNo($serialNo)
//                                                            ->setState($entity_detail->getState())
//                                                            ->setStorehouse($inventory_adjust_list->getToStorehouse())
//                                                            ->setStockQuantity(0 - $entity_detail->getTransferQuantity()/count($serialArray))
//                                                            ->setCreateUserName($member->getUsername())
//                                                            ->setCreateDate($today)
//                                                            ->setUpdateUserName($member->getUsername())
//                                                            ->setUpdateDate($today);
//                                                        $this->entityManager->persist($entity_stock_list_storehouse_unit_add);
//                                                    }
//                                                }
                                                // CNC DEL-END 2021/10/27
                                            }
                                        }
                                    }
                                } else {
                                    // 在庫調整
                                    $url_after_success = [
                                        'url' => 'admin_inventory_inventory_adjust_kubun',
                                        'conditions' => ['kubun' => 2],
                                    ];
                                    $index = $index + 1;
                                    /** @var Product $now_product */
                                    $now_product = $this->productRepository->find($entity_detail->getProductId());
                                    // シリアルがnullの場合
                                    //if ($entity_detail->getSerialNo() == null || $entity_detail->getSerialNo() == '') {
                                    if (!$now_product->getSerialFlg()) {
                                        // 在庫一覧（置場単位）
                                        $collection_stock_list_storehouse_unit = $this->stockListStorehouseUnitRepository->getStockListStorehouseUnitByKey($entity_detail->getProductCode(),
                                                                                                                                                            $entity_detail->getStateId(),
                                                                                                                                                            $entity_detail->getStorehouse()->getId(),
                                                                                                                                                            '');
                                        if (isset($collection_stock_list_storehouse_unit)) {
                                            foreach ($collection_stock_list_storehouse_unit as $item) {
                                                $entity_stock_list_storehouse_unit = $item;
                                                $entity_stock_list_storehouse_unit->setStockQuantity(
                                                    $entity_stock_list_storehouse_unit->getStockQuantity()
                                                    + $entity_detail->getTransferQuantity()
                                                )
                                                    ->setUpdateUserName($member->getName());
                                                $this->entityManager->persist($entity_stock_list_storehouse_unit);
                                                $this->entityManager->flush($entity_stock_list_storehouse_unit);
                                                LogControllable::print_log(__FILE__, '########## Inventory Adjust: stock list by storehouse', [$entity_stock_list_storehouse_unit->toArray()]);
                                            }

                                            // 在庫一覧（商品単位）
                                            $collection_stock_list_product_unit = $this->stockListProductUnitRepository->findStockListProductUnitByKey(
                                                $entity_detail->getProductCode(), $entity_detail->getStateId()
                                            );
                                            if (isset($collection_stock_list_product_unit)) {
                                                foreach ($collection_stock_list_product_unit as $item) {
                                                    $entity_stock_list_product_unit = $item;
                                                    $entity_stock_list_product_unit->setStockQuantity(
                                                        $entity_stock_list_product_unit->getStockQuantity()
                                                        + $entity_detail->getTransferQuantity()
                                                    )
                                                        ->setRemainingStockQuantity($entity_stock_list_product_unit->getStockQuantity()
                                                            - $entity_stock_list_product_unit->getOrderQuantity()
                                                            - $entity_stock_list_product_unit->getProvisionalShipmentQuantity())
                                                        ->setUpdateUserName($member->getName());
                                                    $this->entityManager->persist($entity_stock_list_product_unit);
                                                    $this->entityManager->flush($entity_stock_list_product_unit);
                                                    LogControllable::print_log(__FILE__, '########## Inventory Adjust: stock list by product', [$entity_stock_list_product_unit->toArray()]);
                                                }
                                            }
                                        }
                                    } else {
                                        // シリアルがnull以外の場合
                                        if ($entity_detail->getTransferQuantity() > 0) {
                                            // プラスの方
                                            $changeProductCode = $entity_detail->getProductCode();
                                            $changeProductId = $entity_detail->getProductId();
                                            $changeProductClass = $entity_detail->getProductClass();
                                            $changeState = $entity_detail->getState();
                                            $changeStorehouse = $entity_detail->getStorehouse();

                                            // 在庫（商品単位）プラス
                                            $stock_by_product_conditions['plus']['productId'] = $entity_detail->getProductId();
                                            $stock_by_product_conditions['plus']['ProductClass'] = $entity_detail->getProductClass();
                                            $stock_by_product_conditions['plus']['productCode'] = $entity_detail->getProductCode();
                                            $stock_by_product_conditions['plus']['State'] = $entity_detail->getState();
                                        } elseif ($entity_detail->getTransferQuantity() < 0) {
                                            // マイナスの方
                                            if (strpos($entity_detail->getSerialNo(), "\r\n") !== false && ($entity_detail->getSerialNo() !== '' && $entity_detail->getSerialNo() !== null)) {
                                                $serialArray = explode("\r\n", $entity_detail->getSerialNo());
                                            } elseif (strpos($entity_detail->getSerialNo(), ',') !== false && ($entity_detail->getSerialNo() !== '' && $entity_detail->getSerialNo() !== null)) {
                                                $serialArray = explode(',', $entity_detail->getSerialNo());
                                            } else {
                                                $serialArray = [$entity_detail->getSerialNo()];
                                            }
                                            $tempProductCode = $entity_detail->getProductCode();
                                            $tempState = $entity_detail->getState();
                                            $tempStorehouse = $entity_detail->getStorehouse();

                                            // 在庫（商品単位）マイナス
                                            $stock_by_product_conditions['minus'] = [
                                                'productId' => $entity_detail->getProductId(),
                                                'ProductClass' => $entity_detail->getProductClass(),
                                                'productCode' => $entity_detail->getProductCode(),
                                                'State' => $entity_detail->getState(),
                                                'quantity' => 0 - count($serialArray),
                                            ];
                                            // 在庫（商品単位）プラスの加算数量をここに確定する。
                                            $stock_by_product_conditions['plus']['quantity'] = count($serialArray);
                                        }

                                        // シリアルの更新
                                        if ($index == 2) {
                                            foreach ($serialArray as $serialNo) {
                                                // 在庫一覧（置場単位）
                                                $collection_stock_list_storehouse_unit = $this->stockListStorehouseUnitRepository->getStockListStorehouseUnitByKey($tempProductCode,$tempState->getId(),
                                                                                                                                                                    $tempStorehouse->getId(),
                                                                                                                                                                    $serialNo);
                                                if (isset($collection_stock_list_storehouse_unit)) {
                                                    foreach ($collection_stock_list_storehouse_unit as $item) {
                                                        $entity_stock_list_storehouse_unit = $item;
                                                        $entity_stock_list_storehouse_unit
                                                            ->setProductId($changeProductId)
                                                            ->setProductClass($changeProductClass)
                                                            ->setProductCode($changeProductCode)
                                                            ->setState($changeState)
                                                            ->setStorehouse($changeStorehouse)
                                                            ->setUpdateUserName($member->getName());
                                                        $this->entityManager->persist($entity_stock_list_storehouse_unit);
                                                        LogControllable::print_log(__FILE__, '########## Inventory Adjust: stock list by storehouse', [$entity_stock_list_storehouse_unit->toArray()]);
                                                    }
                                                }
                                            }

                                            // /** @var StockAdjustDetail $entity_detail_adjust */
                                            // foreach ($array_inventory_adjust_list_details as $line_no_inner => $entity_detail_adjust) {
                                            // 在庫（商品単位）
                                            foreach ($stock_by_product_conditions as $conditions) {
                                                // $collection_stock_list_product_unit = $this->stockListProductUnitRepository->findStockListProductUnitByKey(
                                                //     $entity_detail_adjust->getProductCode(), $entity_detail->getStateId()
                                                // );
                                                $collection_stock_list_product_unit = $this->stockListProductUnitRepository->findBy(
                                                    [
                                                        'productId' => $conditions['productId'],
                                                        'productCode' => $conditions['productCode'],
                                                        'State' => $conditions['State'],
                                                    ],
                                                    ['createDate' => 'DESC']
                                                );
                                                if (isset($collection_stock_list_product_unit) && isset($collection_stock_list_product_unit[0])) {
                                                    // foreach ($collection_stock_list_product_unit as $item) {
                                                    /** @var StockListProductUnit $entity_stock_list_product_unit */
                                                    $entity_stock_list_product_unit = $collection_stock_list_product_unit[0];
                                                } else {
                                                    $entity_stock_list_product_unit = (new StockListProductUnit())
                                                        ->setProductId($conditions['productId'])
                                                        ->setProductClass($conditions['ProductClass'])
                                                        ->setProductCode($conditions['productCode'])
                                                        ->setState($conditions['State'])
                                                        ->setCreateUserName($member->getName())
                                                        ->setUpdateUserName($member->getName())
                                                    ;
                                                }
                                                $entity_stock_list_product_unit
                                                    ->setStockQuantity(
                                                        $entity_stock_list_product_unit->getStockQuantity()
                                                        + $conditions['quantity']
                                                    )->setRemainingStockQuantity(
                                                        $entity_stock_list_product_unit->getStockQuantity()
                                                        - $entity_stock_list_product_unit->getOrderQuantity()
                                                        - $entity_stock_list_product_unit->getProvisionalShipmentQuantity()
                                                    )->setUpdateUserName($member->getName());

                                                $this->entityManager->persist($entity_stock_list_product_unit);
                                                $this->entityManager->flush($entity_stock_list_product_unit);
                                                LogControllable::print_log(__FILE__, '########## Inventory Adjust: stock list by product', [$entity_stock_list_product_unit->toArray()]);
                                                LogControllable::print_log(__FILE__, '########## Inventory Adjust: stock list by product - quantity change: ', [$conditions['quantity']]);
                                                // }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if ($loginFlg) {
                            $this->entityManager->persist($inventory_adjust_list);
                            $this->entityManager->flush();

                            // 新規登録時はMySQL対応のためflushしてから採番
                            $this->voucherNoProcessor->process($inventory_adjust_list);
                            $this->entityManager->flush();

                            log_info('在庫調整登録完了', [$inventory_adjust_list->getId()]);
                            $this->addSuccess('admin.common.save_complete', 'admin');

                            // return $this->redirectToRoute('admin_inventory_inventory_adjust', ['id' => $inventory_adjust_list->getId()]);
                            return $this->redirectToRoute($url_after_success['url'], $url_after_success['conditions']);
                        } else {
                            log_info('何れかの明細をチェックオンしてください', [$inventory_adjust_list->getId()]);
                            $this->addWarning('admin.inventory.adjust.detail_check_not_found', 'admin');
                        }
                    } catch (\Exception $e) {
                        log_error('在庫調整登録エラー', [$id, $e]);
                        $this->addError($e->getMessage(), 'admin');
                    }
                } elseif ($request->get('mode') == 'register' && $form) {
                    $this->addError('admin.common.save_error', 'admin');
                }
            }
        } else {
            // 表示時明細の商品名称設定
            foreach ($form['inventoryAdjustDetail'] as $form_detail) {
                /** @var FormInterface $form_detail */
                /** @var Product $product */
                $product = $this->productRepository->find($form_detail['productId']
                    ->getData());
                $form_detail['productName']->setData($product->getName());
                $category = $this->categoryRepository->find($product->getProductCategories()->getValues()[0]->getCategory()->getId());
                $form_detail['category']->setData($category->getId());
                $form_detail['categoryName']->setData($category->getName());
                $place = $this->placeRepository->find($form_detail['storehouse']->getData()->getId());
                $form_detail['storehouse']->setData($place);
                $form_detail['storehouseId']->setData($place->getId());
                $form_detail['storehouseName']->setData($place->getPlace());
                $state = $this->stateRepository->find($form_detail['state']->getData());
                $form_detail['state']->setData($state);
                $form_detail['stateId']->setData($state->getId());
                $form_detail['stateName']->setData($state->getState());
                if (strpos($form_detail['serialNo']->getData(), ',') !== false) {
                    $changeSerialNo = str_replace(',', "\r\n", $form_detail['serialNo']->getData());
                    $form_detail['serialNo']->setData($changeSerialNo);
                    $form_detail['serialFlg']->setData('1');
                } elseif (strpos($form_detail['serialNo']->getData(), "\r\n") !== false) {
                    $form_detail['serialFlg']->setData('1');
                } elseif (!empty($form_detail['serialNo']->getData())) {
                    $form_detail['serialFlg']->setData('0');
                }
                $form_detail['checkFlg']->setData('1');
                // 在庫移動
                if ($form['processingType']->getData() == trans('admin.inventory.adjust.inventory_move') && empty($form_detail['serialNo']->getData())) {
                    $form_detail['stockQuantity']->setData($form_detail['stockQuantity']->getData() + $form_detail['transferQuantity']->getData());
                }
            }

            if ($form['processingType']->getData() == trans('admin.inventory.adjust.inventory_move')) {
                $submitFlg = 1;
            } elseif ($form['processingType']->getData() == trans('admin.inventory.adjust.inventory_adjust')) {
                $submitFlg = 2;
            }
            // 明細行数
            $now_row_no = $form['inventoryAdjustDetail']
                ? $form['inventoryAdjustDetail']->count()
                : 0;
        }

        // 複数シリアル番号入力フォーム
        $builder_input_multiple_serial = $this->formFactory->createBuilder(InputMultipleSerialType::class);

        $event = new EventArgs(
            [
                'builder' => $builder_input_multiple_serial,
                'inventoryAdjustList' => $entity_inventory_adjust_list,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_INVENTORY_ADJUST_INDEX_INPUT_MULTIPLE_SERIAL_INITIALIZE, $event);

        $input_multiple_serial_form = $builder_input_multiple_serial->getForm();

        // 在庫商品選択
        $builder = $this->formFactory
            ->createBuilder(InventoryProductSelectType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'inventoryAdjustList' => $entity_inventory_adjust_list,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_INVENTORY_ADJUST_INDEX_INVENTORY_PRODUCT_SELECT_INITIALIZE, $event);

        $inventoryProductSelectModalForm = $builder->getForm();

        return [
            'form' => $form->createView(),
            'inputMultipleSerialForm' => $input_multiple_serial_form->createView(),
            'inventoryProductSelectModalForm' => $inventoryProductSelectModalForm->createView(),
            'inventoryAdjustList' => $entity_inventory_adjust_list,
            'detailDatumLength' => $now_row_no,
            'submitFlg' => $submitFlg,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/inventory_adjust_list/serial_no", name="admin_stock_adjust_detail_serial_no")
     * @param Request $request リクエスト
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function inventoryAdjustDetailSerialNo(Request $request)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('add taxCode start.');

            $serialNo = $request->get('serial_no');

            $array_stock_list_storehouse_unit = $this->stockListStorehouseUnitRepository->findStockAdjustDetailBySerialNo($serialNo);

            if (!empty($array_stock_list_storehouse_unit) && !empty($array_stock_list_storehouse_unit[0]) && !empty($array_stock_list_storehouse_unit[1])) {
                // 置場
                $storehouse = $array_stock_list_storehouse_unit[0]->getStorehouse()->getId();
                $storehouseId = $array_stock_list_storehouse_unit[0]->getStorehouse()->getId();
                $storehouseName = $array_stock_list_storehouse_unit[0]->getStorehouse()->getPlace();

                $productClass = $array_stock_list_storehouse_unit[0]->getProductClass()->getId();
                // カテゴリ(大)
                $categoryId = $array_stock_list_storehouse_unit[1]->getId();
                $categoryName = $array_stock_list_storehouse_unit[1]->getName();
                // 商品ID
                $productId = $array_stock_list_storehouse_unit[0]->getProductId();
                // 商品コード
                $productCode = $array_stock_list_storehouse_unit[0]->getProductCode();
                // 商品名
                $productName = $array_stock_list_storehouse_unit[0]->getProductClass()->getProduct()->getName();
                // 状態
                $stateId = $array_stock_list_storehouse_unit[0]->getState()->getId();
                $stateName = $array_stock_list_storehouse_unit[0]->getState()->getState();
                $state = $array_stock_list_storehouse_unit[0]->getState()->getId();
                // シリアル
                $serialNo = $array_stock_list_storehouse_unit[0]->getSerialNo();
                // 在庫数
                $stockQuantity = $array_stock_list_storehouse_unit[0]->getStockQuantity();

                $data = [
                    'storehouse' => $storehouse,
                    'storehouseId' => $storehouseId,
                    'storehouseName' => $storehouseName,
                    'productClass' => $productClass,
                    'categoryId' => $categoryId,
                    'categoryName' => $categoryName,
                    'productId' => $productId,
                    'productCode' => $productCode,
                    'productName' => $productName,
                    'stateId' => $stateId,
                    'stateName' => $stateName,
                    'state' => $state,
                    'serialNo' => $serialNo,
                    'stockQuantity' => $stockQuantity,
                ];
            } else {
                $data = [];
            }
            return $this->json($data);
        }
    }

    /**
     * @Route("/%eccube_admin_route%/inventory_product_select/search/product", name="admin_inventory_product_select_search_product")
     * @Route("/%eccube_admin_route%/inventory_product_select/search/product/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_inventory_product_select_search_product_page")
     * @Template("@admin/Inventory/search_inventory_product_select.twig")
     * @param Request $request Request
     * @param int|null $page_no page no
     * @param Paginator|null $paginator Paginator
     * @return array
     */
    public function searchProduct(Request $request, int $page_no = null, Paginator $paginator = null)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            $page_count = $this->eccubeConfig['eccube_default_page_count'];
            $session = $this->session;

            if ('POST' === $request->getMethod()) {
                $page_no = 1;
                $searchData = [
                    'productCode' => $request->get('productCode'),
                    'productName' => $request->get('productName'),
                    'storehouse' => $request->get('storehouse'),
                    'inventoryExist' => $request->get('inventoryExist'),
                    'inventoryNotExist' => $request->get('inventoryNotExist'),
                    'inventoryMinus' => $request->get('inventoryMinus'),
                    'moveFlg' => $request->get('moveFlg'),
                ];

                $session->set('eccube.admin.inventory_product_select.product.search', $searchData);
                $session->set('eccube.admin.inventory_product_select.product.search.page_no', $page_no);
            } else {
                $searchData = (array) $session->get('eccube.admin.inventory_product_select.product.search');
                if (is_null($page_no)) {
                    $page_no = intval($session->get('eccube.admin.inventory_product_select.product.page_no'));
                } else {
                    $session->set('eccube.admin.inventory_product_select.product.page_no', $page_no);
                }
            }

//            $qb = $this->stockListStorehouseUnitRepository->getQueryBuilderBySearchData($searchData);
            $qb = $this->getProductBySearchData($searchData);

            $event = new EventArgs(
                [
                    'qb' => $qb,
                    'data' => $searchData,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_INVENTORY_ADJUST_INDEX_INVENTORY_PRODUCT_SELECT_SEARCH, $event);

            /** @var \Knp\Component\Pager\Pagination\SlidingPagination $pagination */
            $pagination = $paginator->paginate(
                $qb,
                $page_no,
                $page_count,
                ['wrap-queries' => true]
            );

            /** @var $StockListStorehouseUnits \Eccube\Entity\StockListStorehouseUnit[] */
            $StockListStorehouseUnits = $pagination->getItems();

            if (empty($StockListStorehouseUnits)) {
                log_debug('search StockListStorehouseUnit not found.');
            }

            $data = [];
            foreach ($StockListStorehouseUnits as $stockListStorehouseUnits) {
                $searchDataSerial = [
                    'productCode' => $stockListStorehouseUnits['productCode'],
                    'productName' => $stockListStorehouseUnits['productName'],
                    'storehouse' => $stockListStorehouseUnits['storehouseId'],
                    'state' => $stockListStorehouseUnits['stateId'],
                    'inventoryExist' => $searchData['inventoryExist'],
                    'inventoryNotExist' => $searchData['inventoryNotExist'],
                    'inventoryMinus' => $searchData['inventoryMinus'],
                    'moveFlg' => $searchData['moveFlg'],
                ];

//                $array_stock_list_storehouse_unit = $this->stockListStorehouseUnitRepository->findSerialNoBySearchData($searchDataSerial);
                $array_stock_list_storehouse_unit = $this->getSerialNoBySearchData($searchDataSerial);
                $serialNo = "";
                foreach ($array_stock_list_storehouse_unit as $serialNoDetails) {
                    if ($serialNo == "" ) {
                        $serialNo = $serialNoDetails['serialNo'];
                    } else if ($serialNoDetails['serialNo'] != "") {
                        $serialNo = $serialNo."\n".$serialNoDetails['serialNo'];
                    }
                }

                $data[] = [
                    'productId' => $stockListStorehouseUnits['productId'],
                    'categoryId' => $stockListStorehouseUnits['categoryId'],
                    'categoryName' => $stockListStorehouseUnits['categoryName'],
                    'productCode' => $stockListStorehouseUnits['productCode'],
                    'productName' => $stockListStorehouseUnits['productName'],
                    'serialNo' => $serialNo,
                    'productClass' => $stockListStorehouseUnits['productClass'],
                    'state' => $stockListStorehouseUnits['stateId'],
                    'stateId' => $stockListStorehouseUnits['stateId'],
                    'stateName' => $stockListStorehouseUnits['stateName'],
                    'storehouse' => $stockListStorehouseUnits['storehouseId'],
                    'storehouseId' => $stockListStorehouseUnits['storehouseId'],
                    'storehouseName' => $stockListStorehouseUnits['storehouseName'],
                    'stockQuantity' => $stockListStorehouseUnits['stockQuantity'],
                ];
            }

            $event = new EventArgs(
                [
                    'data' => $data,
                    'customers' => $pagination,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_INVENTORY_ADJUST_INDEX_INVENTORY_PRODUCT_SELECT_COMPLETE, $event);
            $data = $event->getArgument('data');

            return [
                'data' => $data,
                'pagination' => $pagination,
            ];
        }
    }

    // 在庫商品選択-商品取得
    public function getProductBySearchData($searchData)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();
        $sql = 'SELECT
                    *
                FROM
                    (
                    SELECT
                        dslsu.product_id AS productId
                      , dslsu.product_code AS productCode
                      , SUM(dslsu.stock_quantity) AS stockQuantity
                      , dpc.id AS productClass
                      , dp.name AS productName
                      , ms.id AS stateId
                      , ms.state AS stateName
                      , mp.id AS storehouseId
                      , mp.place AS storehouseName
                      , dcy.id AS categoryId
                      , dcy.category_name AS categoryName
                    FROM
                        dtb_stock_list_storehouse_unit dslsu
                    INNER JOIN dtb_product_class dpc
                      ON dpc.id = dslsu.product_class_id
                    INNER JOIN dtb_product dp
                      ON dp.id = dpc.product_id
                    INNER JOIN mtb_state ms
                      ON ms.id = dslsu.state_id
                    INNER JOIN mtb_place mp
                      ON mp.id = dslsu.storehouse_id
                    INNER JOIN dtb_product_category dpcy
                      ON dpcy.product_id = dp.id
                      AND dpcy.category_sub_flag = 0
                    INNER JOIN dtb_category dcy
                      ON dcy.id = dpcy.category_id
                      AND dcy.hierarchy = 1
                    WHERE
                        dpc.visible = TRUE';

        // moveFlg
        if (!empty($searchData['moveFlg']) && $searchData['moveFlg'] == '1') {
            $sql = $sql." AND  dslsu.stock_quantity > 0";
        }

        $sql = $sql."
                    GROUP BY
                       productCode
                     , stateId
                     , storehouseId
                    ) m1
                WHERE TRUE ";

        // product_code
        if (isset($searchData['productCode']) && StringUtil::isNotBlank($searchData['productCode'])) {
            $sql = $sql." AND  m1.productCode LIKE "."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['productCode']))."%'";
        }

        // payeeName
        if (isset($searchData['productName']) && StringUtil::isNotBlank($searchData['productName'])) {
            $sql = $sql." AND  m1.productName LIKE "."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['productName']))."%'";
        }

        // Storehouse
        if (!empty($searchData['storehouse']) && $searchData['storehouse']) {
            $sql = $sql." AND  m1.storehouseId = ".$searchData['storehouse'];
        }

        // inventoryExist inventoryNotExist inventoryMinus
        $sql = $sql." AND ( FALSE ";
        if ($searchData['inventoryExist'] == 1) {
            $sql = $sql." or m1.stockQuantity > 0";
        }

        if ($searchData['inventoryNotExist'] == 1) {
            $sql = $sql." or m1.stockQuantity = 0";
        }

        if ($searchData['inventoryMinus'] == 1) {
            $sql = $sql." or m1.stockQuantity < 0";
        }

        $sql = $sql." )
                    GROUP BY
                       m1.productCode
                     , m1.stateId
                     , m1.storehouseId";

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    // 在庫商品選択-シリアル取得
    public function getSerialNoBySearchData($searchData)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();
        $sql = 'SELECT
                    *
                FROM
                    (
                    SELECT
                        dslsu.serial_no AS serialNo
                      , dslsu.product_code AS productCode
                      , dslsu.stock_quantity AS stockQuantity
                      , dp.name AS productName
                      , ms.id AS stateId
                      , mp.id AS storehouseId
                    FROM
                        dtb_stock_list_storehouse_unit dslsu
                    INNER JOIN dtb_product_class dpc
                      ON dpc.id = dslsu.product_class_id
                    INNER JOIN dtb_product dp
                      ON dp.id = dpc.product_id
                    INNER JOIN mtb_state ms
                      ON ms.id = dslsu.state_id
                    INNER JOIN mtb_place mp
                      ON mp.id = dslsu.storehouse_id
                    INNER JOIN dtb_product_category dpcy
                      ON dpcy.product_id = dp.id
                      AND dpcy.category_sub_flag = 0
                    INNER JOIN dtb_category dcy
                      ON dcy.id = dpcy.category_id
                      AND dcy.hierarchy = 1
                    WHERE
                        dpc.visible = TRUE';

        // moveFlg
        if (!empty($searchData['moveFlg']) && $searchData['moveFlg'] == '1') {
            $sql = $sql." AND  dslsu.stock_quantity > 0";
        }

        $sql = $sql."
                    ) m1
                WHERE TRUE ";

        // product_code
        if (isset($searchData['productCode']) && StringUtil::isNotBlank($searchData['productCode'])) {
            $sql = $sql." AND  m1.productCode LIKE "."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['productCode']))."%'";
        }

        // payeeName
        if (isset($searchData['productName']) && StringUtil::isNotBlank($searchData['productName'])) {
            $sql = $sql." AND  m1.productName LIKE "."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['productName']))."%'";
        }

        // Storehouse
        if (!empty($searchData['storehouse']) && $searchData['storehouse']) {
            $sql = $sql." AND  m1.storehouseId = ".$searchData['storehouse'];
        }

        // state
        if (!empty($searchData['state']) && $searchData['state']) {
            $sql = $sql." AND  m1.stateId = ".$searchData['state'];
        }

        // inventoryExist inventoryNotExist inventoryMinus
        $sql = $sql." AND ( FALSE ";
        if ($searchData['inventoryExist'] == 1) {
            $sql = $sql." or m1.stockQuantity > 0";
        }

        if ($searchData['inventoryNotExist'] == 1) {
            $sql = $sql." or m1.stockQuantity = 0";
        }

        if ($searchData['inventoryMinus'] == 1) {
            $sql = $sql." or m1.stockQuantity < 0";
        }
        $sql = $sql." )";

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }
}