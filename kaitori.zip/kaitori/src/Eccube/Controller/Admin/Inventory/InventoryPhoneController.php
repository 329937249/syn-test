<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Inventory;
use Eccube\Controller\AbstractController;
use Eccube\Entity\BaseInfo;
use Eccube\Entity\Master\CsvType;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\InventoryType;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\Master\ProductPriceRuleRepository;
use Eccube\Repository\Master\ProductStatusRepository;
use Eccube\Repository\Master\RankRepository;
use Eccube\Repository\Master\RankTypeRepository;
use Eccube\Repository\StateRepository;
use Eccube\Repository\StockListProductUnitRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\ProductPriceOptionRepository;
use Eccube\Repository\ProductImageRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\TagRepository;
use Eccube\Repository\TaxRuleRepository;
use Eccube\Service\CsvExportService;
use Eccube\Util\FormUtil;
use Knp\Component\Pager\Paginator;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Eccube\Util\StringUtil;
use QueryBuilder;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： InventoryPhoneController.php
 *概　　要     ： 在庫照会(フォン)
 *作　　成     ： 2022/11/28 CNC
 */
class InventoryPhoneController extends AbstractController
{
    /**
     * @var CsvExportService
     */
    protected $csvExportService;

    /**
     * @var ProductClassRepository
     */
    protected $productClassRepository;

    /**
     * @var ProductImageRepository
     */
    protected $productImageRepository;

    /**
     * @var TaxRuleRepository
     */
    protected $taxRuleRepository;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var BaseInfo
     */
    protected $BaseInfo;

    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;

    /**
     * @var ProductStatusRepository
     */
    protected $productStatusRepository;

    /**
     * @var TagRepository
     */
    protected $tagRepository;

    /**
     * @var RankRepository
     */
    protected $rankRepository;

    /**
     * @var RankTypeRepository
     */
    protected $rankTypeRepository;

    /**
     * @var ProductPriceRuleRepository
     */
    protected $productPriceRuleRepository;

    /**
     * @var ProductPriceOptionRepository
     */
    protected $productPriceOptionRepository;

    /**
     * @var StateRepository
     */
    protected $stateRepository;

    /**
     * @var StockListProductUnitRepository
     */
    protected $stockListProductUnitRepository;

    /**
     * InventoryPhoneController constructor.
     *
     * @param CsvExportService $csvExportService
     * @param CategoryRepository $categoryRepository
     * @param StateRepository $stateRepository
     * @param PageMaxRepository $pageMaxRepository
     */
    public function __construct(
        CsvExportService $csvExportService,
        CategoryRepository $categoryRepository,
        StateRepository $stateRepository,
        PageMaxRepository $pageMaxRepository,
        ProductRepository $productRepository
    ) {
        $this->csvExportService = $csvExportService;
        $this->categoryRepository = $categoryRepository;
        $this->stateRepository = $stateRepository;
        $this->pageMaxRepository = $pageMaxRepository;
        $this->productRepository = $productRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/inventory_management/inventory_inquire_phone", name="admin_inventory_inquire_phone")
     * @Route("/%eccube_admin_route%/inventory_management/inventory_inquire_phone/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_inventory_inquire_phone_page")
     * @Template("@admin/Inventory/inventory_phone.twig")
     * @param Request $request Request
     * @param null $page_no page no
     * @param Paginator $paginator Paginator
     * @return array
     */
    public function index(Request $request, $page_no = null, Paginator $paginator, $productId = null)
    {
        $builder = $this->formFactory
            ->createBuilder(InventoryType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_INVENTORY_INQUIRE_INDEX_INITIALIZE, $event);

        $searchForm = $builder->getForm();

        /**
         * ページの表示件数は, 以下の順に優先される.
         * - リクエストパラメータ
         * - セッション
         * - デフォルト値
         * また, セッションに保存する際は mtb_page_maxと照合し, 一致した場合のみ保存する.
         **/
        $page_count = $this->session->get('eccube.admin.inventory.phone.search.page_count',
            $this->eccubeConfig->get('eccube_default_page_count'));

        $page_count_param = (int) $request->get('page_count');
        $pageMaxis = $this->pageMaxRepository->findAll();

        if ($page_count_param) {
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.admin.inventory.phone.search.page_count', $page_count);
                    break;
                }
            }
        }

        // 状態
        $stateList = $this->stateRepository->getStateByCategory();

        $page_no_bk = $page_no;
        if ('POST' === $request->getMethod()) {
            $searchForm->handleRequest($request);

            if ($searchForm->isValid()) {
                /**
                 * 検索が実行された場合は, セッションに検索条件を保存する.
                 * ページ番号は最初のページ番号に初期化する.
                 */
                $page_no = 1;
                $searchData = $searchForm->getData();

                // main category
                $categories = $this->categoryRepository->getList(null, false);
                $mainCategory = null;
                foreach ($categories as $Category) {
                    if ($Category && ($Category->getHierarchy() == 1)) {
                        $mainCategory = $Category;
                        break;
                    }
                }

                // 検索条件, ページ番号をセッションに保持.
                $this->session->set('eccube.admin.inventory.phone.search', FormUtil::getViewData($searchForm));
                $this->session->set('eccube.admin.inventory.phone.search.page_no', $page_no);
            } else {
                // 検索エラーの際は, 詳細検索枠を開いてエラー表示する.
                return [
                    'searchForm' => $searchForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $page_count,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.admin.inventory.phone.search.page_no', (int) $page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.admin.inventory.phone.search.page_no', 1);
                }
                $viewData = $this->session->get('eccube.admin.inventory.phone.search', []);
                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
            } else {
                /**
                 * 初期表示の場合.
                 */
                $page_no = 1;

                // main category
                $categories = $this->categoryRepository->getList(null, false);
                $mainCategory = null;
                foreach ($categories as $Category) {
                    if ($Category && ($Category->getHierarchy() == 1)) {
                        $mainCategory = $Category;
                        break;
                    }
                }

                // submit default value
                $viewData = FormUtil::getViewData($searchForm);

                if ( $productId != null) {
                    $product = $this->productRepository->find($productId);
                    $productCode = $product->getProductClasses()[0]['code'];
                    $viewData["product_id"] = $productCode;
                }

                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);

                // セッション中の検索条件, ページ番号を初期化.
                $this->session->set('eccube.admin.inventory.phone.search', $viewData);
                $this->session->set('eccube.admin.inventory.phone.search.page_no', $page_no);
            }
        }

        $qb = [];
        if ('POST' === $request->getMethod() || null !== $page_no_bk){
            $qb = $this->getSearchData($searchData);
        }

        if ($searchData['inventory_serial']){
            foreach ($qb as &$serial) {
                $serial['payee_date'] = $this->makeDateStringUtcToAsiaTokyo($serial['payee_date']);
            }
        }

        $sort_orders = $this->sortOrder($qb, $searchData);
        $stockQuantityTotal = 0;
        $stockAmountTotal = 0;

        foreach ($qb as $stock) {
            $stockQuantityTotal = $stockQuantityTotal + $stock["stock_quantity"];
            $stockAmountTotal = $stockAmountTotal + $stock["stock_amount"];
        }

        $event = new EventArgs(
            [
                'qb' => $qb,
                'searchData' => $searchData,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_INVENTORY_INQUIRE_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $page_count
        );

        return [
            'searchForm' => $searchForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'has_errors' => false,
            'request' => $request,
            'stockQuantityTotal' => $stockQuantityTotal,
            'StateList' => $stateList,
            'stockAmountTotal' => $stockAmountTotal,
        ];
    }

    private function sortOrder($orders, $searchData)
    {
        if ($searchData['sort_by']) {
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case '商品コード':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == '降順') {
                            return $a['product_code'] > $b['product_code'] ? -1 : 1;
                        }
                        return $a['product_code'] < $b['product_code'] ? -1 : 1;
                    });
                    break;
                case '商品名':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == '降順') {
                            return $a['product_name'] > $b['product_name'] ? -1 : 1;
                        }
                        return $a['product_name'] < $b['product_name'] ? -1 : 1;
                    });
                    break;
                case 'シリアル':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == '降順') {
                            return $a["serial"] > $b["serial"] ? -1 : 1;
                        }
                        return $a["serial"] < $b["serial"] ? -1 : 1;
                    });
                    break;
                case '状態':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == '降順') {
                            return $a["state"] > $b["state"] ? -1 : 1;
                        }
                        return $a["state"] < $b["state"] ? -1 : 1;
                    });
                    break;
                case '置場':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == '降順') {
                            return $a["place"] > $b["place"] ? -1 : 1;
                        }
                        return $a["place"] < $b["place"] ? -1 : 1;
                    });
                    break;
                case '在庫数':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == '降順') {
                            return $a["stock_quantity"] > $b["stock_quantity"] ? -1 : 1;
                        }
                        return $a["stock_quantity"] < $b["stock_quantity"] ? -1 : 1;
                    });
                    break;
                case '受注数':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == '降順') {
                            return $a["order_quantity"] > $b["order_quantity"] ? -1 : 1;
                        }
                        return $a["order_quantity"] < $b["order_quantity"] ? -1 : 1;
                    });
                    break;
                case '仮出荷数':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == '降順') {
                            return $a["provisional_shipment_quantity"] > $b["provisional_shipment_quantity"] ? -1 : 1;
                        }
                        return $a["provisional_shipment_quantity"] < $b["provisional_shipment_quantity"] ? -1 : 1;
                    });
                    break;
                case '残在庫数':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == '降順') {
                            return $a["remaining_stock_quantity"] > $b["remaining_stock_quantity"] ? -1 : 1;
                        }
                        return $a["remaining_stock_quantity"] < $b["remaining_stock_quantity"] ? -1 : 1;
                    });
                    break;
            }
        }
        return $orders;
    }

    public function getSearchData($searchData)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();

        //在庫あり
        $inventoryExist = $searchData['inventory_exist'];
        //マイナス在庫
        $inventoryMinus = $searchData['inventory_minus'];
        //在庫なし
        $inventoryNonExist = $searchData['inventory_non_exist'];
        //シリアル単位
        $inventorySerial = $searchData['inventory_serial'];
        //置場単位
        $inventoryStorehouse = $searchData['inventory_storehouse'];

        if (!$inventoryStorehouse && !$inventorySerial) {
            $sql = "
                SELECT
                    pi.file_name AS image
                    , dc4.category_id AS category_id1
                    , dc4.categoryname AS categoryname1
                    , dc5.category_id AS category_id2
                    , dc5.categoryname AS categoryname2
                    , dc6.category_id AS category_id3
                    , dc6.categoryname AS categoryname3
                    , '' AS place
                    , m.product_code AS product_code
                    , m.product_id AS product_id
                    , p.name AS product_name
                    , '' AS serial
                    , '' AS serial_id
                    , s.state AS state
                    , s.id AS stateId
                    , m.stock_quantity AS stock_quantity
                    , m.order_quantity AS order_quantity
                    , m.provisional_shipment_quantity AS provisional_shipment_quantity
                    , m.remaining_stock_quantity AS remaining_stock_quantity
                    , m.average_unit_price AS average_unit_price
                    , '' AS payee_price
                    , m.stock_quantity * m.average_unit_price AS stock_amount
                    , p.product_size_en AS product_size_en
                    , CASE WHEN s.state = '新品' THEN
                        CASE WHEN son2.sumqua IS NULL THEN
                            0
                        ELSE
                            son2.sumqua
                        END
                            +
                        CASE WHEN son4.sumqua IS NULL THEN
                            0
                        ELSE
                            son4.sumqua
                        END
                    ELSE
                        CASE WHEN son2.sumqua IS NULL THEN
                            0
                        ELSE
                            son2.sumqua
                        END
                    END AS reservation_quantity
                FROM
                    dtb_stock_list_product_unit m
                    INNER JOIN dtb_product_class pc
                        ON m.product_class_id = pc.id
                    INNER JOIN dtb_product p
                        ON pc.product_id = p.id
                    INNER JOIN mtb_state s
                        ON m.state_id = s.id
                    LEFT JOIN dtb_product_image pi
                        ON pi.product_id = pc.product_id
                    INNER JOIN (
                        SELECT
                            dslpu.id AS id
                            , dcs.category_name AS categoryname
                            , dcs.hierarchy AS hierarchy
                            , dpcs.category_id AS category_id
                        FROM
                            dtb_stock_list_product_unit dslpu
                            INNER JOIN dtb_product_class pc
                                ON dslpu.product_class_id = pc.id
                            INNER JOIN dtb_product dps
                                ON pc.product_id = dps.id
                            INNER JOIN dtb_product_category dpcs
                                ON dslpu.product_id = dpcs.product_id
                                AND dpcs.category_sub_flag <> 1
                            INNER JOIN dtb_category dcs
                                ON dcs.id = dpcs.category_id
                    ) AS dc4
                        ON dc4.id = m.id
                        AND dc4.hierarchy = 1
                    LEFT JOIN (
                        SELECT
                            dslpu.id AS id
                            , dcs.category_name AS categoryname
                            , dcs.hierarchy AS hierarchy
                            , dpcs.category_id AS category_id
                        FROM
                            dtb_stock_list_product_unit dslpu
                            INNER JOIN dtb_product_class pc
                                ON dslpu.product_class_id = pc.id
                            INNER JOIN dtb_product dps
                                ON pc.product_id = dps.id
                            INNER JOIN dtb_product_category dpcs
                                ON dslpu.product_id = dpcs.product_id
                                AND dpcs.category_sub_flag <> 1
                            INNER JOIN dtb_category dcs
                                ON dcs.id = dpcs.category_id
                    ) AS dc5
                        ON dc5.id = m.id
                        AND dc5.hierarchy = 2
                    LEFT JOIN (
                        SELECT
                            dslpu.id AS id
                            , dcs.category_name AS categoryname
                            , dcs.hierarchy AS hierarchy
                            , dpcs.category_id AS category_id
                        FROM
                            dtb_stock_list_product_unit dslpu
                            INNER JOIN dtb_product_class pc
                                ON dslpu.product_class_id = pc.id
                            INNER JOIN dtb_product dps
                                ON pc.product_id = dps.id
                            INNER JOIN dtb_product_category dpcs
                                ON dslpu.product_id = dpcs.product_id
                                AND dpcs.category_sub_flag <> 1
                            INNER JOIN dtb_category dcs
                                ON dcs.id = dpcs.category_id
                    ) AS dc6
                        ON dc6.id = m.id
                        AND dc6.hierarchy = 3
                    LEFT JOIN (
                        SELECT
                            son1.product_id,
                            son1.product_code,
                            son1.conversion_after_state_id,
                            son1.sumqua
                        FROM
                            (
                                SELECT
                                    dori.product_id,
                                    dori.product_code,
                                    dori.conversion_after_state_id,
                                    SUM(dori.quantity) AS sumqua
                                FROM
                                    dtb_order_item dori
                                INNER JOIN dtb_order dor ON dor.id = dori.order_id
                                AND dor.order_status_id = '9'
                                INNER JOIN dtb_shipping dsp ON dor.id = dsp.order_id
                                AND (
                                    dsp.delivery_id = '3'
                                    OR dsp.delivery_id = '4'
                                )
                                GROUP BY
                                    dori.product_id,
                                    dori.product_code,
                                    dori.conversion_after_state_id
                            ) son1
                    ) son2 ON m.product_id = son2.product_id
                    AND m.product_code = son2.product_code
                    AND s.id = son2.conversion_after_state_id
                    LEFT JOIN (
                        SELECT
                            son3.product_id,
                            son3.product_code,
                            son3.conversion_after_state_id,
                            son3.sumqua
                        FROM
                            (
                                SELECT
                                    dori2.product_id,
                                    dori2.product_code,
                                    dori2.conversion_after_state_id,
                                    SUM(dori2.quantity) AS sumqua
                                FROM
                                    dtb_order_item dori2
                                INNER JOIN dtb_order dor2 ON dor2.id = dori2.order_id
                                AND dor2.order_status_id = '9'
                                INNER JOIN dtb_shipping dsp2 ON dor2.id = dsp2.order_id
                                AND (
                                    dsp2.delivery_id = '3'
                                    OR dsp2.delivery_id = '4'
                                )
                                GROUP BY
                                    dori2.product_id,
                                    dori2.product_code,
                                    dori2.conversion_after_state_id
                            ) son3
                        WHERE
                            son3.conversion_after_state_id IS NULL
                    ) son4 ON m.product_id = son4.product_id
                    AND m.product_code = son4.product_code
                WHERE
                    TRUE ";
        } elseif ($inventoryStorehouse) {
            $sql = "
                 SELECT
                    pi.file_name AS image
                    , dc4.category_id AS category_id1
                    , dc4.categoryname AS categoryname1
                    , dc5.category_id AS category_id2
                    , dc5.categoryname AS categoryname2
                    , dc6.category_id AS category_id3
                    , dc6.categoryname AS categoryname3
                    , pl.place AS place
                    , pl.sort_no AS sort_no
                    , p.name AS product_name
                    , m.product_code AS product_code
                    , m.product_id AS product_id
--                    , m.serial_no AS serial
                    , '' AS serial
                    , '' AS serial_id
                    , s.state AS state
                    , s.id AS stateId
                    , SUM(m.stock_quantity) AS stock_quantity
                    , CASE
                        WHEN pl.place = '川口'
                          THEN slpu.order_quantity
                        ELSE 0
                        END AS order_quantity
                    , CASE
                        WHEN pl.place = '川口'
                          THEN slpu.provisional_shipment_quantity
                        ELSE 0
                        END AS provisional_shipment_quantity
                    , CASE
                        WHEN pl.place = '川口'
                          THEN SUM(m.stock_quantity) - slpu.order_quantity - slpu.provisional_shipment_quantity
                        ELSE SUM(m.stock_quantity)
                        END AS remaining_stock_quantity
                    , CASE
                        WHEN slpu.average_unit_price IS NULL
                            THEN 0
                        ELSE slpu.average_unit_price
                        END  AS average_unit_price
                    , '' AS payee_price
                    , CASE
                        WHEN slpu.average_unit_price IS NULL
                            THEN 0
                        ELSE SUM(m.stock_quantity) * slpu.average_unit_price
                        END AS stock_amount
                    , p.product_size_en AS product_size_en
                    , CASE WHEN pl.place = '川口' THEN
                        CASE WHEN s.state = '新品' THEN
                            CASE WHEN son2.sumqua IS NULL THEN
                                0
                            ELSE
                                son2.sumqua
                            END
                                +
                            CASE WHEN son4.sumqua IS NULL THEN
                                0
                            ELSE
                                son4.sumqua
                            END
                        ELSE
                            CASE WHEN son2.sumqua IS NULL THEN
                                0
                            ELSE
                                son2.sumqua
                            END
                        END
                    ELSE
                        0
                    END AS reservation_quantity
                FROM
                    dtb_stock_list_storehouse_unit m
                    LEFT JOIN dtb_stock_list_product_unit slpu
                        ON slpu.product_code = m.product_code
                        AND slpu.state_id = m.state_id
                    INNER JOIN dtb_product_class pc
                        ON m.product_class_id = pc.id
                    INNER JOIN dtb_product p
                        ON pc.product_id = p.id
                    INNER JOIN mtb_state s
                        ON m.state_id = s.id
                    LEFT JOIN dtb_product_image pi
                        ON pi.product_id = pc.product_id
                    INNER JOIN (
                        SELECT
                            dslsu.id AS id
                            , dcs.category_name AS categoryname
                            , dcs.hierarchy AS hierarchy
                            , dpcs.category_id AS category_id
                        FROM
                            dtb_stock_list_storehouse_unit dslsu
                            INNER JOIN dtb_product_class pc
                                ON dslsu.product_clASs_id = pc.id
                            INNER JOIN dtb_product dps
                                ON pc.product_id = dps.id
                            INNER JOIN dtb_product_category dpcs
                                ON dslsu.product_id = dpcs.product_id
                                AND dpcs.category_sub_flag <> 1
                            INNER JOIN dtb_category dcs
                                ON dcs.id = dpcs.category_id
                    ) AS dc4
                        ON dc4.id = m.id
                        AND dc4.hierarchy = 1
                    LEFT JOIN (
                        SELECT
                            dslsu.id AS id
                            , dcs.category_name AS categoryname
                            , dcs.hierarchy AS hierarchy
                            , dpcs.category_id AS category_id
                        FROM
                            dtb_stock_list_storehouse_unit dslsu
                            INNER JOIN dtb_product_class pc
                                ON dslsu.product_clASs_id = pc.id
                            INNER JOIN dtb_product dps
                                ON pc.product_id = dps.id
                            INNER JOIN dtb_product_category dpcs
                                ON dslsu.product_id = dpcs.product_id
                                AND dpcs.category_sub_flag <> 1
                            INNER JOIN dtb_category dcs
                                ON dcs.id = dpcs.category_id
                    ) AS dc5
                        ON dc5.id = m.id
                        AND dc5.hierarchy = 2
                    LEFT JOIN (
                        SELECT
                            dslsu.id AS id
                            , dcs.category_name AS categoryname
                            , dcs.hierarchy AS hierarchy
                            , dpcs.category_id AS category_id
                        FROM
                            dtb_stock_list_storehouse_unit dslsu
                            INNER JOIN dtb_product_class pc
                                ON dslsu.product_clASs_id = pc.id
                            INNER JOIN dtb_product dps
                                ON pc.product_id = dps.id
                            INNER JOIN dtb_product_category dpcs
                                ON dslsu.product_id = dpcs.product_id
                                AND dpcs.category_sub_flag <> 1
                            INNER JOIN dtb_category dcs
                                ON dcs.id = dpcs.category_id
                    ) AS dc6
                        ON dc6.id = m.id
                        AND dc6.hierarchy = 3
                    LEFT JOIN mtb_place pl
                        ON m.storehouse_id = pl.id
                    LEFT JOIN (
                        SELECT
                            son1.product_id,
                            son1.product_code,
                            son1.conversion_after_state_id,
                            son1.sumqua
                        FROM
                            (
                                SELECT
                                    dori.product_id,
                                    dori.product_code,
                                    dori.conversion_after_state_id,
                                    SUM(dori.quantity) AS sumqua
                                FROM
                                    dtb_order_item dori
                                INNER JOIN dtb_order dor ON dor.id = dori.order_id
                                AND dor.order_status_id = '9'
                                INNER JOIN dtb_shipping dsp ON dor.id = dsp.order_id
                                AND (
                                    dsp.delivery_id = '3'
                                    OR dsp.delivery_id = '4'
                                )
                                GROUP BY
                                    dori.product_id,
                                    dori.product_code,
                                    dori.conversion_after_state_id
                            ) son1
                    ) son2 ON m.product_id = son2.product_id
                    AND m.product_code = son2.product_code
                    AND s.id = son2.conversion_after_state_id
                    LEFT JOIN (
                        SELECT
                            son3.product_id,
                            son3.product_code,
                            son3.conversion_after_state_id,
                            son3.sumqua
                        FROM
                            (
                                SELECT
                                    dori2.product_id,
                                    dori2.product_code,
                                    dori2.conversion_after_state_id,
                                    SUM(dori2.quantity) AS sumqua
                                FROM
                                    dtb_order_item dori2
                                INNER JOIN dtb_order dor2 ON dor2.id = dori2.order_id
                                AND dor2.order_status_id = '9'
                                INNER JOIN dtb_shipping dsp2 ON dor2.id = dsp2.order_id
                                AND (
                                    dsp2.delivery_id = '3'
                                    OR dsp2.delivery_id = '4'
                                )
                                GROUP BY
                                    dori2.product_id,
                                    dori2.product_code,
                                    dori2.conversion_after_state_id
                            ) son3
                        WHERE
                            son3.conversion_after_state_id IS NULL
                    ) son4 ON m.product_id = son4.product_id
                    AND m.product_code = son4.product_code
                WHERE
                    TRUE ";
        } elseif ($inventorySerial) {
            $sql = "
                 SELECT
                    pi.file_name AS image
                    , dc4.category_id AS category_id1
                    , dc4.categoryname AS categoryname1
                    , dc5.category_id AS category_id2
                    , dc5.categoryname AS categoryname2
                    , dc6.category_id AS category_id3
                    , dc6.categoryname AS categoryname3
                    , pl.place AS place
                    , pl.sort_no AS sort_no
                    , p.name AS product_name
                    , m.product_code AS product_code
                    , m.product_id AS product_id
                    , m.serial_no AS serial
                    , m.id AS serial_id
                    , sp.serial_no AS serial_pictures_id
                    , s.state AS state
                    , s.id AS stateId
                    , SUM(m.stock_quantity) AS stock_quantity
                    , '' AS order_quantity
                    , '' AS provisional_shipment_quantity
                    , '' AS remaining_stock_quantity
                    , '' AS average_unit_price
                    , pvd.payee_price AS payee_price
                    , pvd.payee_price * SUM(m.stock_quantity) AS stock_amount
                    , pvh.purchase_date AS payee_date
                    , p.product_size_en AS product_size_en
                    , '0' AS reservation_quantity
                FROM dtb_stock_list_storehouse_unit m
               INNER JOIN dtb_product p
                  ON m.product_id = p.id
               INNER JOIN mtb_state s
                  ON m.state_id = s.id
                LEFT JOIN dtb_product_image pi
                  ON pi.product_id = m.product_id
                LEFT JOIN dtb_serial_pictures sp
                  ON sp.serial_no = m.serial_no
                LEFT JOIN dtb_payee_voucher_detail pvd
                  ON pvd.product_id = m.product_id
                 AND pvd.product_class_id = m.product_class_id
				 AND pvd.serial_no = m.serial_no
                 AND pvd.id = (
                     SELECT MAX(t.id)
                       FROM dtb_payee_voucher_detail t
                      WHERE t.product_id = pvd.product_id
					    AND t.product_class_id = pvd.product_class_id
						AND t.serial_no = pvd.serial_no
                     )
               LEFT JOIN dtb_payee_voucher_header pvh
                  ON pvh.payee_voucher_no = pvd.payee_voucher_no
               INNER JOIN (
                        SELECT
                            dpcs.product_id AS id
                            , dcs.category_name AS categoryname
                            , dcs.hierarchy AS hierarchy
                            , dpcs.category_id AS category_id
                        FROM
                            dtb_product_category dpcs
                        INNER JOIN dtb_category dcs
                                ON dcs.id = dpcs.category_id
                               AND dcs.hierarchy = 1
                        WHERE dpcs.category_sub_flag <> 1
                    ) AS dc4
                        ON dc4.id = m.product_id
                        AND dc4.hierarchy = 1
                    LEFT JOIN (
                        SELECT
                            dpcs.product_id AS id
                            , dcs.category_name AS categoryname
                            , dcs.hierarchy AS hierarchy
                            , dpcs.category_id AS category_id
                        FROM
                            dtb_product_category dpcs
                        INNER JOIN dtb_category dcs
                                ON dcs.id = dpcs.category_id
                               AND dcs.hierarchy = 2
                        WHERE dpcs.category_sub_flag <> 1
                    ) AS dc5
                        ON dc5.id = m.product_id
                        AND dc5.hierarchy = 2
                    LEFT JOIN (
                        SELECT
                            dpcs.product_id AS id
                            , dcs.category_name AS categoryname
                            , dcs.hierarchy AS hierarchy
                            , dpcs.category_id AS category_id
                        FROM
                            dtb_product_category dpcs
                        INNER JOIN dtb_category dcs
                                ON dcs.id = dpcs.category_id
                               AND dcs.hierarchy = 3
                        WHERE dpcs.category_sub_flag <> 1
                    ) AS dc6
                        ON dc6.id = m.product_id
                        AND dc6.hierarchy = 3
                    LEFT JOIN mtb_place pl
                        ON m.storehouse_id = pl.id
                WHERE
                    TRUE ";
            // purchase_date_start
            if (isset($searchData['purchase_date_start']) && StringUtil::isNotBlank($searchData['purchase_date_start'])) {
                $purchase_date_start = $searchData['purchase_date_start'];
                $purchaseDateStart = $purchase_date_start->setTime('0', '0', '0')
                    ->setTimezone(new \DateTimeZone('UTC'))
                    ->format('Y-m-d H:i:s');
                $sql = $sql.' AND pvh.purchase_date >= '."'".$purchaseDateStart."'";
            }

            // purchase_date_end
            if (isset($searchData['purchase_date_end']) && StringUtil::isNotBlank($searchData['purchase_date_end'])) {
                $purchase_date_end = $searchData['purchase_date_end'];
                $purchaseDateEnd = $purchase_date_end->setTime('23', '59', '59')
                    ->setTimezone(new \DateTimeZone('UTC'))
                    ->format('Y-m-d H:i:s');
                $sql = $sql.' AND pvh.purchase_date < '."'".$purchaseDateEnd."'";
            }
        }
        // mainCategory
        if (isset($searchData['main_category_id']) && !empty($searchData['main_category_id']) && $searchData['main_category_id']) {
            $Category = $searchData['main_category_id'];
            $category_id = 'category_id_'.$Category->getId();
            if (isset($searchData[$category_id]) && !empty($searchData[$category_id]) && $searchData[$category_id]) {
                $Categories = $searchData[$category_id]->getSelfAndDescendants();
            } else {
                $Categories = $Category->getSelfAndDescendants();
            }
            if ($Categories) {
                $sql = $sql.'AND dc4.category_id='."'".$searchData['main_category_id']['id']."'";
                if ($searchData[$category_id]) {
                    if ($searchData[$category_id]['hierarchy'] == '2') {
                        $sql = $sql.'AND  dc5.category_id='."'".$searchData[$category_id]['id']."'";
                    } else {
                        $sql = $sql.'AND  dc6.category_id='."'".$searchData[$category_id]['id']."'";
                    }
                }
            }
        }
        //state
        if (isset($searchData['state']) && StringUtil::isNotBlank($searchData['state'])) {
            $sql .= 'AND m.state_id = '."'".$searchData['state']->getId()."'";
        }
        //place
        if (isset($searchData['palce']) && StringUtil::isNotBlank($searchData['palce'])) {
            $sql .= 'AND pl.id='."'".$searchData['palce']->getId()."'";
        }
        //product_code
        if (isset($searchData['product_id']) && StringUtil::isNotBlank($searchData['product_id'])) {
            $sql .= 'AND  m.product_code like '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['product_id']))."%'";
        }

        //product_name
        if (isset($searchData['product_name']) && StringUtil::isNotBlank($searchData['product_name'])) {
            $sql .= 'AND  p.name like '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['product_name']))."%'";
        }

        $ExistFlg = false;
        $MinusFlg = false;

        $sql = $sql.' AND (';

        //在庫ありをチッェクオンの場合
        if ($inventoryExist == true) {
            $sql = $sql.' m.stock_quantity > 0 ';
            $ExistFlg = true;
        }

        if ($ExistFlg) {
            //マイナス在庫をチッェクオンの場合
            if ($inventoryMinus == true) {
                $sql = $sql.'OR m.stock_quantity < 0 ';
                $MinusFlg = true;
            }
        } else {
            if ($inventoryMinus == true) {
                $sql = $sql.' m.stock_quantity < 0 ';
                $MinusFlg = true;
            }
        }

        if ($ExistFlg or $MinusFlg) {
            //在庫なしをチッェクオンの場合
            if ($inventoryNonExist == true) {
                $sql = $sql.'OR m.stock_quantity = 0 ';
            }
        } else {
            if ($inventoryNonExist == true) {
                $sql = $sql.' m.stock_quantity = 0 ';
            }
        }

        $sql = $sql.')';

        // シリアル
        if ($inventorySerial) {
            if (isset($searchData['inventory_serial_no']) && StringUtil::isNotBlank($searchData['inventory_serial_no'])) {
                $sql = $sql.'AND m.serial_no like '."'%".str_replace(['%', '_'], ['\\%', '\\_'], $searchData['inventory_serial_no'])."%'";
            }
            $sql = $sql.'AND m.serial_no is not null ';
        }

        if ($inventoryStorehouse == false and $inventorySerial == false) {
            $sql = $sql.'
                ORDER BY place
                        ,product_name
                        ,state
                    ';
        } elseif ($inventoryStorehouse == true) {
            $sql = $sql.'
                GROUP BY product_code
                        ,product_name
                        ,state
                        ,place
                ORDER BY place
                        ,product_name
                        ,state
                        ';
        } elseif ($inventorySerial == true) {
            $sql = $sql.'
                GROUP BY product_code
                        ,product_name
                        ,state
                        ,place
                        ,serial
                ORDER BY place
                       , product_name
                       , state';
        }
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    /**
     * UTC時間を東京時間にする
     * @param string|null $date 時間文字列(yyyy-mm-dd HH:ii:ss)
     * @return string
     */
    public function makeDateStringUtcToAsiaTokyo(string $date = null)
    {
        if (!$date || $date !== date('Y-m-d H:i:s', strtotime($date))) {
            return '';
        }

        try {
            $date_utc = new \DateTime($date, new \DateTimeZone('UTC'));
            $date_asia_tokyo = $date_utc
                ->setTimezone(new \DateTimeZone('Asia/Tokyo'))
                ->format('Y/m/d');
        } catch (\Exception $exception) {
            return '';
        }

        return $date_asia_tokyo;
    }
}
