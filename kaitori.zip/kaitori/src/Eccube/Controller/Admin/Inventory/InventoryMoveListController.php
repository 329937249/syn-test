<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Inventory;

use Doctrine\ORM\EntityManagerInterface;
use Eccube\Controller\AbstractController;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\InventoryMoveListType;
use Eccube\Form\Type\Admin\SearchMemberType;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\InventoryMoveListRepository;
use Eccube\Util\FormUtil;
use Eccube\Service\InventoryPdfService;
use Knp\Component\Pager\Paginator;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Eccube\Repository\MemberRepository;
use Doctrine\ORM\QueryBuilder;

/**
 *プログラム名 ： InventoryMoveListController.php
 *概　　要     ： 在庫移動一覧
 *作　　成     ： 2021/8/12 CNC
 */
class InventoryMoveListController extends AbstractController
{
    /**
     * @var EntityManagerInterface
     */
    protected $entityManager;

    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;

    /**
     * @var MemberRepository
     */
    protected $memberRepository;

    /**
     * @var InventoryMoveListRepository
     */
    protected $inventoryMoveListRepository;

    /**
     * InventoryMoveListController constructor.
     * @param PageMaxRepository $pageMaxRepository Max page
     * @param EntityManagerInterface $entityManager Entity Manager
     * @param MemberRepository $memberRepository Member
     * @param InventoryMoveListRepository $inventoryMoveListRepository Inventory Move
     */
    public function __construct(
        PageMaxRepository $pageMaxRepository,
        EntityManagerInterface $entityManager,
        MemberRepository $memberRepository,
        InventoryMoveListRepository $inventoryMoveListRepository
    ) {
        $this->pageMaxRepository = $pageMaxRepository;
        $this->entityManager = $entityManager;
        $this->memberRepository = $memberRepository;
        $this->inventoryMoveListRepository = $inventoryMoveListRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/inventory_management/inventory_move_list", name="admin_inventory_move_list")
     * @Route("/%eccube_admin_route%/inventory_management/inventory_move_list/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_inventory_move_list_page")
     * @Template("@admin/Inventory/inventory_move_list.twig")
     * @param Request $request Request
     * @param null $page_no
     * @param Paginator $paginator Paginator
     * @param null $id
     * @return array
     */
    public function index(Request $request, $page_no = null, Paginator $paginator, $id = null)
    {
        $session = $this->session;
        $builder = $this->formFactory
            ->createBuilder(InventoryMoveListType ::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_INVENTORY_MOVE_LIST_INDEX_INITIALIZE, $event);

        $page_count = $this->session->get('eccube.admin.stock_adjust_list.search.page_count',
            $this->eccubeConfig->get('eccube_default_page_count'));

        $page_count_param = (int) $request->get('page_count');
        $pageMaxis = $this->pageMaxRepository->findAll();

        if ($page_count_param) {
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.admin.stock_adjust_list.search.page_count', $page_count);
                    break;
                }
            }
        }

        $searchForm = $builder->getForm();

        // 担当者検索フォーム
        $builder = $this->formFactory
            ->createBuilder(SearchMemberType::class);
        $searchMemberModalForm = $builder->getForm();

        $page_no_bk = $page_no;
        if ('POST' === $request->getMethod()) {
            $searchForm->handleRequest($request);

            if ($searchForm->isValid()) {
                $page_no = 1;
                $searchData = $searchForm->getData();
                $this->session->set('eccube.admin.stock_adjust_list.search', FormUtil::getViewData($searchForm));
                $this->session->set('eccube.admin.stock_adjust_list.search.page_no', $page_no);
            } else {
                return [
                    'searchForm' => $searchForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $page_count,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                if ($page_no) {
                    $this->session->set('eccube.admin.stock_adjust_list.search.page_no', (int) $page_no);
                } else {
                    $page_no = $this->session->get('eccube.admin.stock_adjust_list.search.page_no', 1);
                }
                $viewData = $this->session->get('eccube.admin.stock_adjust_list.search', []);
            } else {
                $page_no = 1;
                $viewData["purchase_date_end"] = date('Y-m-d', strtotime('now'));
                $viewData["purchase_date_start"] = date('Y-m-d', strtotime('now'));

            }
            // セッション中の検索条件, ページ番号を初期化.
            $this->session->set('eccube.admin.stock_adjust_list.search', $viewData);
            $this->session->set('eccube.admin.stock_adjust_list.search.page_no', $page_no);
            $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
        }

        $qb = '';
        $all_orders = [];
        if ('POST' === $request->getMethod() || null !== $page_no_bk){
            /** @var QueryBuilder $qb */
            $qb = $this->inventoryMoveListRepository->getQueryBuilderBySearchData($searchData);
            $all_orders = $qb->getQuery()->getResult();
        }

        // 結果の編集
        foreach ($all_orders as &$stock) {
            // シリアル番号表示処理
            if (strpos($stock['serialNo'], ',') !== false) {
                $stock['serialNo'] = str_replace(',', "\r\n", $stock['serialNo']);
            }

            // 在庫調整の置場表示処理
            if ($stock['processingType'] === trans('admin.inventory.adjust.inventory_adjust')) {
                if ($stock['transferQuantity'] < 0) {
                    $stock['FromPlace'] = $stock['placeAdjust'];
                }
                if ($stock['transferQuantity'] > 0) {
                    $stock['ToPlace'] = $stock['placeAdjust'];
                }
            }
        }
        $sort_orders = $this->sortOrder($all_orders, $searchData);

        $event = new EventArgs(
            [
                'qb' => $qb,
                'searchData' => $searchData,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_INVENTORY_MOVE_LIST_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $page_count
        );

        return [
            'searchForm' => $searchForm->createView(),
            'searchMemberModalForm' => $searchMemberModalForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'has_errors' => false,
            'request' => $request,
        ];
    }

    /**
     * @param $orders
     * @param $searchData
     * @return mixed
     */
    private function sortOrder($orders, $searchData)
    {
        if ($searchData['sort_by']) {
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case '伝票番号':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == "降順") {
                            return $a["stockAdjustVoucherNo"] > $b["stockAdjustVoucherNo"] ? -1 : 1;
                        }
                        return $a["stockAdjustVoucherNo"] < $b["stockAdjustVoucherNo"] ? -1 : 1;
                    });
                    break;
            }
        }
        return $orders;
    }

    /**
     * 担当者情報を検索する.
     *
     * @Route("/%eccube_admin_route%/inventory_management/inventory_move_list/html", name="admin_master_search_inventorymember_html")
     * @Route("/%eccube_admin_route%/inventory_management/inventory_move_list/html/page/{page_no}", requirements={"page_No" = "\d+"}, name="admin_master_search_inventorymember_html_page")
     * @Template("@admin/Inventory/search_member.twig")
     *
     * @param Request $request Request
     * @param int|null $page_no page no
     * @param Paginator $paginator Paginator
     * @return array
     */
    public function searchMemberHtml(Request $request, int $page_no = null, Paginator $paginator)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('search member start.');
            $page_count = $this->eccubeConfig['eccube_default_page_count'];
            $session = $this->session;

            if ('POST' === $request->getMethod()) {
                $page_no = 1;
                $searchData = [
                    'login_id' => $request->get('login_id'),
                    'name' => $request->get('name'),
                    'department' => $request->get('department'),
                    'Authority' => $request->get('Authority'),
                ];

                $session->set('eccube.master.member.search', $searchData);
                $session->set('eccube.master.member.search.page_no', $page_no);
            } else {
                $searchData = (array) $session->get('eccube.admin.master.member.search');
                if (is_null($page_no)) {
                    $page_no = intval($session->get('eccube.admin.master.member.search.page_no'));
                } else {
                    $session->set('eccube.admin.master.member.search.page_no', $page_no);
                }
            }

            $qb = $this->memberRepository->getQueryBuilderBySearchData($searchData);

            $event = new EventArgs(
                [
                    'qb' => $qb,
                    'data' => $searchData,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_INVENTORY_MOVE_LIST_SEARCH_MEMBER_SEARCH, $event);

            /** @var \Knp\Component\Pager\Pagination\SlidingPagination $pagination */
            $pagination = $paginator->paginate(
                $qb,
                $page_no,
                $page_count,
                ['wrap-queries' => true]
            );

            /** @var $Members \Eccube\Entity\Member[] */
            $Members = $pagination->getItems();

            if (empty($Members)) {
                log_debug('search member not found.');
            }

            $data = [];
            foreach ($Members as $Member) {
                $data[] = [
                    'id' => $Member->getId(),
                    'login_id' => $Member->getLoginId(),
                    'name' => $Member->getName(),
                    'department' => $Member->getDepartment(),
                    'Authority' => $Member->getAuthority()
                ];
            }

            $event = new EventArgs(
                [
                    'data' => $data,
                    'Members' => $pagination,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_INVENTORY_MOVE_LIST_SEARCH_MEMBER_COMPLETE, $event);
            $data = $event->getArgument('data');

            return [
                'data' => $data,
                'pagination' => $pagination,
            ];
        }
    }

    /**
     *  担当者情報をセットする.
     *
     * @Route("/%eccube_admin_route%/inventory_management/search/inventorymember/id", name="admin_master_search_inventorymember_by_id", methods={"POST"})
     *
     * @param Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchMemberById(Request $request)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('search member by id start.');

            /** @var $Member \Eccube\Entity\Member */
            $Member = $this->memberRepository
                ->find($request->get('id'));

            $event = new EventArgs(
                [
                    'Member' => $Member,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_INVENTORY_MOVE_LIST_SEARCH_MEMBER_BY_ID_INITIALIZE, $event);

            if (is_null($Member)) {
                log_debug('search member by id not found.');

                return $this->json([], 404);
            }

            log_debug('search member by id found.');

            $data = [
                'id' => $Member->getId(),
                'name' => $Member->getName(),
            ];

            $event = new EventArgs(
                [
                    'data' => $data,
                    'Member' => $Member,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_INVENTORY_MOVE_LIST_SEARCH_MEMBER_BY_ID_COMPLETE, $event);
            $data = $event->getArgument('data');
            return $this->json($data);
        }
    }

    /**
     *  PDFの出力.
     *
     * @Route("/%eccube_admin_route%/inventory_management/export/{id}/pdf", requirements={"id" = "\d+"}, name="admin_inventory_move_list_pdf", methods={"GET"})
     *
     * @param Request $request
     *
     * @return
     */
    public function pdfExport(Request $request, $id, InventoryPdfService $inventoryPdfService)
    {
        // PDFを作成する
        $inventoryPdfService->makePdf($id);
        // ダウンロードする
        $response = new Response(
            $inventoryPdfService->outputPdf(),
            200,
            ['content-type' => 'application/pdf']
        );
        $response->headers->set('Content-Disposition', 'attachment; filename="'.$inventoryPdfService->getPdfFileName().'"');
        return $response;
    }
}