<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Inventory;

use Eccube\Controller\AbstractController;
use Eccube\Entity\Master\CsvType;
use Eccube\Entity\Product;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\InputMultipleSerialType;
use Eccube\Form\Type\Admin\InventoryPaymentType;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\Master\ProductPriceRuleRepository;
use Eccube\Repository\Master\ProductStatusRepository;
use Eccube\Repository\Master\RankRepository;
use Eccube\Repository\Master\RankTypeRepository;
use Eccube\Repository\PayeeVoucherDetailRepository;
use Eccube\Repository\SalesVoucherDetailRepository;
use Eccube\Repository\StockListProductUnitRepository;
use Eccube\Repository\StockAdjustDetailRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\ProductPriceOptionRepository;
use Eccube\Repository\ProductImageRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\TagRepository;
use Eccube\Repository\TaxRuleRepository;
use Eccube\Service\CsvExportService;
use Eccube\Util\FormUtil;
use Knp\Component\Pager\Paginator;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Eccube\Util\StringUtil;
use Eccube\Repository\StateRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： InventoryPaymentController.php
 *概　　要     ： 受払照会照会
 *作　　成     ： 2021/8/15 CNC
 */
class InventoryPaymentController extends AbstractController
{
    // 一覧画面URL
    const PREVIOUS_PAGE_URL = 'inventory_management/inventory_inquire';

    /**
     * @var CsvExportService
     */
    protected $csvExportService;

    /**
     * @var ProductClassRepository
     */
    protected $productClassRepository;

    /**
     * @var ProductImageRepository
     */
    protected $productImageRepository;

    /**
     * @var TaxRuleRepository
     */
    protected $taxRuleRepository;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;

    /**
     * @var ProductStatusRepository
     */
    protected $productStatusRepository;

    /**
     * @var TagRepository
     */
    protected $tagRepository;

    /**
     * @var RankRepository
     */
    protected $rankRepository;

    /**
     * @var RankTypeRepository
     */
    protected $rankTypeRepository;

    /**
     * @var ProductPriceRuleRepository
     */
    protected $productPriceRuleRepository;

    /**
     * @var ProductPriceOptionRepository
     */
    protected $productPriceOptionRepository;

    /**
     * @var StockListProductUnitRepository
     */
    protected $stockListProductUnitRepository;

    /**
     * @var StockAdjustDetailRepository
     */
    protected $stockAdjustDetailRepository;

    /**
     * @var StateRepository
     */
    protected $stateRepository;

    /**
     * @var PayeeVoucherDetailRepository
     */
    protected $payeeVoucherDetailRepository;

    /**
     * @var SalesVoucherDetailRepository
     */
    protected $salesVoucherDetailRepository;

    /**
     * InventoryPaymentController constructor.
     * @param CsvExportService $csvExportService CSV output
     * @param CategoryRepository $categoryRepository Category
     * @param PageMaxRepository $pageMaxRepository Max Page
     * @param StateRepository $stateRepository State
     * @param ProductRepository $productRepository Product
     * @param StockListProductUnitRepository $stockListProductUnitRepository Stock by Product Unit
     * @param StockAdjustDetailRepository $stockAdjustDetailRepository Stock Adjust Detail
     * @param PayeeVoucherDetailRepository $payeeVoucherDetailRepository Payee Voucher Detail
     * @param SalesVoucherDetailRepository $salesVoucherDetailRepository Sales Voucher Detail
     */
    public function __construct(
        CsvExportService $csvExportService,
        CategoryRepository $categoryRepository,
        PageMaxRepository $pageMaxRepository,
        StateRepository $stateRepository,
        ProductRepository $productRepository,
        StockListProductUnitRepository $stockListProductUnitRepository,
        StockAdjustDetailRepository $stockAdjustDetailRepository,
        PayeeVoucherDetailRepository $payeeVoucherDetailRepository,
        SalesVoucherDetailRepository $salesVoucherDetailRepository
    ) {
        $this->csvExportService = $csvExportService;
        $this->categoryRepository = $categoryRepository;
        $this->pageMaxRepository = $pageMaxRepository;
        $this->stateRepository = $stateRepository;
        $this->productRepository = $productRepository;
        $this->stockListProductUnitRepository = $stockListProductUnitRepository;
        $this->stockAdjustDetailRepository = $stockAdjustDetailRepository;
        $this->payeeVoucherDetailRepository = $payeeVoucherDetailRepository;
        $this->salesVoucherDetailRepository = $salesVoucherDetailRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/inventory_management/payment_inquire", name="admin_payment_inquire")
     * @Route("/%eccube_admin_route%/inventory_management/payment_inquire/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_payment_inquire_page")
     * @Route("/%eccube_admin_route%/inventory_management/admin_payment_inquire/{stateId}/{category}/{id}", requirements={"stateId" = "\d+","category" = "\d+","id" = "\S+"}, name="admin_inventory_payment_product_code")
     * @Template("@admin/Inventory/inventory_payment.twig")
     * @param Request $request Request
     * @param null $page_no
     * @param null $category
     * @param null $id
     * @param null $stateId
     * @param Paginator $paginator Paginator
     * @return array
     */
    public function index(Request $request, $page_no = null, $category = null, $id = null, $stateId = null, Paginator $paginator)
    {
        $link =
            strpos($request->headers->get('referer'), self::PREVIOUS_PAGE_URL)
                ? 1
                : 0;
        $stockInTotal = 0;
        $stockOutTotal = 0;
        $stockTotalAmount = 0;

        $builder = $this->formFactory
            ->createBuilder(InventoryPaymentType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_INVENTORY_PAYMENT_INDEX_INITIALIZE, $event);

        $searchForm = $builder->getForm();

        /**
         * ページの表示件数は, 以下の順に優先される.
         * - リクエストパラメータ
         * - セッション
         * - デフォルト値
         * また, セッションに保存する際は mtb_page_maxと照合し, 一致した場合のみ保存する.
         **/
        $page_count = $this->session->get('eccube.admin.inventory.payment.search.page_count',
            $this->eccubeConfig->get('eccube_default_page_count'));

        $page_count_param = (int) $request->get('page_count');
        $pageMaxis = $this->pageMaxRepository->findAll();

        if ($page_count_param) {
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.admin.inventory.payment.search.page_count', $page_count);
                    break;
                }
            }
        }
        $searchFlg = false;
        // 初期表示Flg
        $intiFlg = false;

        $page_no_bk = $page_no;
        if ('POST' === $request->getMethod()) {
            $searchForm->handleRequest($request);
            $searchFlg = true;

            if ($searchForm->isValid()) {
                /**
                 * 検索が実行された場合は, セッションに検索条件を保存する.
                 * ページ番号は最初のページ番号に初期化する.
                 */
                $page_no = 1;
                $searchData = $searchForm->getData();

                // 検索条件, ページ番号をセッションに保持.
                $this->session->set('eccube.admin.inventory.payment.search', FormUtil::getViewData($searchForm));
                $this->session->set('eccube.admin.inventory.search.payment.page_no', $page_no);
                $this->session->set('eccube.admin.inventory.search.selected_state', $request->get('inventory_payment_master_state_select'));
                $this->session->set('eccube.admin.inventory.search.product_name', $request->get('product_name'));
                $this->session->set('eccube.admin.inventory.search.category', FormUtil::getViewData($searchForm)['category']);
            } else {
                // 検索エラーの際は, 詳細検索枠を開いてエラー表示する.
                return [
                    'searchForm' => $searchForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $page_count,
                    'has_errors' => true,
                    'searchFlg' => $searchFlg,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.admin.inventory.payment.search.page_no', (int) $page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.admin.inventory.payment.search.page_no', 1);
                }
                $viewData = $this->session->get('eccube.admin.inventory.payment.search', []);

                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
            } else {
                /**
                 * 初期表示の場合.
                 */
                $page_no = 1;

                $viewData = FormUtil::getViewData($searchForm);

                // 在庫照会から遷移の場合
                if (!$id == null) {
                    $viewData["product_code"] = $id;
                    $viewData["purchase_date_end"] = date('Y-m-d', strtotime('now'));
                    $qb = $this->getInventoryInfo($stateId, $id);
                    if ($qb) {
                        if ($qb[0]['purchase_date']) {
                            $viewData["purchase_date_start"] = date('Y-m-d', strtotime($qb[0]['purchase_date']));
                        }
                        $viewData["product_name"] = $qb[0]['product_name'];
                        $viewData["category"] = $category;
                    }
                }

                // セッション中の検索条件, ページ番号を初期化.
                $this->session->set('eccube.admin.inventory.payment.search', $viewData);
                $this->session->set('eccube.admin.inventory.payment.search.page_no', $page_no);
                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
                $intiFlg = true;
            }
        }

        // 状態
        $entity_state = $this->stateRepository->getStateByCategory();

        // 伝票明細登録用コントロール
        $builder_inventory_payment = $this->formFactory->createBuilder(InventoryPaymentType::class);
        $form_inventory_payment = $builder_inventory_payment->getForm();
        $qb = [];
        if ('POST' === $request->getMethod() || null !== $page_no_bk){
            $qb = $this->getSearchData($request, $searchData, $stateId, true);
        }

        $stockListProductUnits = $this->stockListProductUnitRepository->findBy(['productCode' => $searchData['product_code']]);
        foreach ($stockListProductUnits as $stockListProductUnit) {
            $stockTotalAmount = $stockTotalAmount + $stockListProductUnit->getStockQuantity() * $stockListProductUnit->getAverageUnitPrice();
        }

        foreach ($qb as &$stock) {
            $stockInTotal = $stockInTotal + $stock['in_count'];
            $stockOutTotal = $stockOutTotal + $stock['out_count'];
            $stock['purchase_date'] = $this->makeDateStringUtcToAsiaTokyo($stock['purchase_date']);
            $stock['0'] = $stock['purchase_date'];
            if ($stock['type'] === trans('admin.inventory.adjust.inventory_move') ||
                $stock['type'] === trans('admin.inventory.adjust.inventory_adjust')) {
                if (strpos($stock['serial_no_flg'], "\r\n") !== false) {
                    $stock['serial_no_flg'] = 'TRUE';
                } elseif (strpos($stock['serial_no_flg'], ',') !== false) {
                    $stock['serial_no_flg'] = 'TRUE';
                }
            }
        }

        $sort_orders = $this->sortOrder($qb, $searchData);
        $event = new EventArgs(
            [
                'qb' => $qb,
                'searchData' => $searchData,
            ],
            $request
        );
        $selected_stateId = null;
        $categoryID = null;
        $product_name = null;

        if ($link == 0) {
            if ($searchFlg) {
                $selected_stateId = $this->session->get('eccube.admin.inventory.search.selected_state');
                $categoryID = $this->session->get('eccube.admin.inventory.search.category');
                $product_name = $this->session->get('eccube.admin.inventory.search.product_name');
            }
        } else {
            $selected_stateId = $stateId;
            $categoryID = $category;
        }

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_INVENTORY_PAYMENT_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
           $sort_orders,
            $page_no,
            $page_count
        );

        foreach ($pagination as $i => $stock) {

            if($stock['type'] == '仕入')
            {
                $voucherDetails = $this->payeeVoucherDetailRepository->findBy
                (['payee_voucher_no' =>$stock['payee_voucher_no'],'State' =>$stock['state_id'],'product_code' =>$stock['product_code']]);

                $serialArray = '';
                foreach ($voucherDetails as $serialDetail) {

                    if($serialArray == ''){
                        $serialArray = $serialDetail['serial_no'];
                    }
                    else{
                        $serialArray = $serialArray.','.$serialDetail['serial_no'];
                    }
                }

                $stock['serialArray'] = $serialArray;
                $pagination[$i] = $stock;
            }
            elseif ($stock['type'] == '売上')
            {
                $voucherDetails = $this->salesVoucherDetailRepository->findBy
                (['sales_voucher_no' =>$stock['payee_voucher_no'],'State' =>$stock['state_id'],'product_code' =>$stock['product_code']]);

                $serialArray = '';
                foreach ($voucherDetails as $serialDetail) {

                    if($serialArray == ''){
                        $serialArray = $serialDetail['serial_no'];
                    }
                    else{
                        $serialArray = $serialArray.','.$serialDetail['serial_no'];
                    }
                }

                $stock['serialArray'] = $serialArray;
                $pagination[$i] = $stock;
            }
            else {
                $voucherDetails = $this->stockAdjustDetailRepository->findBy
                (['stockAdjustVoucherNo' =>$stock['payee_voucher_no'],'state' =>$stock['state_id'],'productCode' =>$stock['product_code']]);

                $serialArray = '';
                foreach ($voucherDetails as $serialDetail) {

                    if($serialArray == ''){
                        $serialArray = $serialDetail['serialNo'];
                    }
                    else{
                        $serialArray = $serialArray.','.$serialDetail['serialNo'];
                    }
                }

                $stock['serialArray'] = $serialArray;
                $pagination[$i] = $stock;
            }
        }

        if ($link == 0) {
            // 初期表示の場合.
            if ($intiFlg) {
                $pagination->setTotalItemCount(null);
            }
        } else {
            // 初期表示の場合.
            if (!isset($id)) {
                $pagination->setTotalItemCount(null);
            }
            $this->session->set('eccube.admin.inventory.search.selected_state', $stateId);
        }

        // 複数シリアル番号入力フォーム
        $builder_input_multiple_serial = $this->formFactory->createBuilder(InputMultipleSerialType::class);

        $input_multiple_serial_form = $builder_input_multiple_serial->getForm();

        return [
            'searchForm' => $searchForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'has_errors' => false,
            'request' => $request,
            'StateList' => $entity_state,
            'inventoryPaymentForm' => $form_inventory_payment->createView(),
            'inputMultipleSerialForm' => $input_multiple_serial_form->createView(),
            'link' => $link,
            'stockInTotal' => $stockInTotal,
            'stockOutTotal' => $stockOutTotal,
            'stockTotalAmount' => $stockTotalAmount,
            'searchFlg' => $searchFlg,
            'selectedID' => $selected_stateId,
            'category' => $categoryID,
            'product_name' => $product_name,
            'product_code' => $searchData['product_code'],
       ];
    }

    /**
     * @Route("/%eccube_admin_route%/inventory_payment/search/product", name="admin_payment_inquire_search_product")
     * @param Request $request リクエスト
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchProduct(Request $request)
    {
        $product_code = $request->get('code');

        log_info("Admin InventoryPayment searchProduct", [$product_code]);

        // 商品取得
        $array_entity_product = $this->productRepository->findProductsWithProductCode($product_code);

        $event = new EventArgs(
            [
                'ProductCode' => $product_code,
                'Product' => $array_entity_product,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_INVENTORY_PAYMENT_INDEX_SEARCH_PRODUCT_INITIALIZE, $event);

        if (!empty($array_entity_product) && !empty($array_entity_product[0])) {
            /** @var Product $entity_product */
            $entity_product = $array_entity_product[0][0];
            $data = [
                'target_product_id' => $entity_product->getId(),
                'target_product_name' => $entity_product->getName(),
                'target_product_serial_flg' => ($entity_product->getSerialFlg() ? '1' : '0'),
                'target_product_category_id' => $array_entity_product[0]['category_id'],
                'target_product_class_id' => $entity_product->getProductClasses()[0]->getId(),
            ];
        } else {
            log_debug('search product by code not found.');
            return $this->json([], 404);
        }
        $event = new EventArgs(
            [
                'ProductCode' => $product_code,
                'Product' => $entity_product,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_INVENTORY_PAYMENT_INDEX_SEARCH_PRODUCT_COMPLETE, $event);

        return $this->json($data);
    }

    /**
     * @param Request $request Request
     * @param array $searchData 検索条件
     * @param $stateId
     * @param $searchFlg
     * @return mixed[]
     */
    public function getSearchData(Request $request, array $searchData, $stateId, $searchFlg)
    {
        $str_inventory_move = trans('admin.inventory.adjust.inventory_move');
        $str_inventory_adjust = trans('admin.inventory.adjust.inventory_adjust');
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();
        $sql = "
            SELECT 
              * 
            FROM 
              ( 
                -- 仕入
                SELECT
                  dpvh.purchase_date AS purchase_date 
                  ,'仕入' AS type 
                  ,( 
                    CASE 
                      WHEN COUNT(dpvd.serial_no) > 1 
                        THEN 'TRUE' 
                      ELSE dpvd.serial_no 
                      END 
                  ) AS serial_no_flg 
                  ,dpvd.serial_no as serial_no 
                  ,s.state AS state 
                  ,s.id as state_id 
                  ,dpvd.payee_voucher_no AS payee_voucher_no 
                  ,mst.payee_name AS payee_name 
                  ,'' AS storehouse_from 
                  ,'' AS storehouse_to 
                  ,sum(dpvd.quantity) AS in_count 
                  ,0 AS out_count 
                  ,p.place AS place 
                  ,dpvd.product_code AS product_code 
                  ,dpvd.payee_price AS payee_price 
                  ,dpvd.quantity * dpvd.payee_price AS total_amount 
                FROM
                  dtb_payee_voucher_detail dpvd 
                  LEFT JOIN dtb_payee_voucher_header dpvh 
                    ON dpvd.payee_voucher_header_id = dpvh.id 
                  LEFT JOIN mtb_state s 
                    ON s.id = dpvd.state_id 
                  LEFT JOIN mtb_payee_mst mst 
                    ON  dpvh.payee_code = mst.id 
                  LEFT JOIN mtb_place p 
                    ON dpvh.storehouse_id = p.id 
                GROUP BY 
                  payee_voucher_no 
                  ,state 
                  ,place 
                  ,product_code 
                UNION ALL 
                -- 売上
                SELECT
                  dsvh.sales_date AS purchase_date
                  ,'売上' AS type
                  ,( 
                    CASE 
                      WHEN count(dsvd.serial_no) > 1 
                        THEN 'TRUE' 
                      ELSE dsvd.serial_no 
                      END 
                  ) AS serial_no_flg 
                  ,dsvd.serial_no as serial_no 
                  ,s.state as state 
                  ,s.id as state_id 
                  ,dsvh.sales_voucher_no AS payee_voucher_no 
                  ,cos.customer_name AS payee_name 
                  ,'' AS storehouse_from 
                  ,'' AS storehouse_to 
                  ,0 AS in_count 
                  ,sum(dsvd.quantity) AS out_count 
                  ,p1.place AS place 
                  ,dsvd.product_code AS product_code 
                  ,dsvd.sales_price AS sales_price 
                  ,dsvd.sales_price * sales_price AS total_amount 
                FROM
                  dtb_sales_voucher_detail dsvd 
                  LEFT JOIN dtb_sales_voucher_header dsvh 
                    ON dsvd.sales_voucher_header_id = dsvh.id 
                  INNER JOIN mtb_state s 
                    ON s.id = dsvd.state_id 
                  LEFT JOIN mtb_customer_mst cos 
                    ON dsvh.customer_id = cos.id 
                  INNER JOIN mtb_place p1 
                    ON dsvd.storehouse_id = p1.id 
                GROUP BY 
                  payee_voucher_no 
                  ,state 
                  ,place 
                  ,product_code 
                UNION ALL 
                -- 在庫調整と移動
                SELECT
                  dsal.stock_adjustments_date AS purchase_date
                  ,dsal.processing_type AS type
                  ,( 
					CASE 
                     	WHEN count(dsad.serial_no) > 1 
                        THEN 'TRUE' 
                      	ELSE dsad.serial_no 
                  	END 
                  ) AS serial_no_flg 
                  ,dsad.serial_no as serial_no 
                  ,s.state as state 
                  ,s.id as state_id 
                  ,dsal.stock_adjust_voucher_no AS payee_voucher_no 
                  ,'' AS payee_name
						,CASE 
							WHEN dsal.processing_type = '$str_inventory_move'
							THEN p_f.place 
							WHEN dsal.processing_type = '$str_inventory_adjust'
							THEN adj.place_from
							ELSE ''
						END AS storehouse_from 
						,CASE 
							WHEN dsal.processing_type = '$str_inventory_move'
							THEN p_t.place 
							WHEN dsal.processing_type = '$str_inventory_adjust'
							THEN adj.place_to
							ELSE ''
						END AS storehouse_to 
                  ,SUM(
							CASE 
								WHEN dsad.transfer_quantity > 0
								THEN dsad.transfer_quantity
								ELSE 0
							END
						) AS in_count 
                  ,SUM(
							CASE 
								WHEN dsad.transfer_quantity < 0
								THEN 0 - dsad.transfer_quantity
								ELSE 0
							END
						) AS out_count 
                  ,p1.place AS place 
                  ,dsad.product_code AS product_code 
                  ,'' AS sales_price 
                  ,sum(dsad.stock_quantity) AS total_amount 
                FROM
                  lcsdata.dtb_stock_adjust_detail dsad 
                  LEFT JOIN lcsdata.dtb_stock_adjust_list dsal 
                    ON dsad.stock_adjust_voucher_id = dsal.id 
                  INNER JOIN lcsdata.mtb_state s 
                    ON s.id = dsad.state_id 
                  INNER JOIN lcsdata.mtb_place p1 
                    ON dsad.storehouse_id = p1.id 
                  LEFT JOIN lcsdata.mtb_place p_f 
                    ON dsal.from_storehouse_id = p_f.id 
                  LEFT JOIN lcsdata.mtb_place p_t 
                    ON dsal.to_storehouse_id = p_t.id 
                  LEFT JOIN (
                  	SELECT sal.id AS id
                  	      ,sal.stock_adjust_voucher_no AS voucher_no
                  	      ,sal.processing_type AS processing_type
                  	      ,sad_f.storehouse_id AS storehouse_id_from
                  	      ,mp_f.place AS place_from
                  	      ,sad_t.storehouse_id AS storehouse_id_to
                  	      ,mp_t.place AS place_to
                  	  FROM lcsdata.dtb_stock_adjust_list sal
                  	      ,lcsdata.dtb_stock_adjust_detail sad_f
						  ,lcsdata.dtb_stock_adjust_detail sad_t
						  ,lcsdata.mtb_place mp_f
						  ,lcsdata.mtb_place mp_t
                  	 WHERE sal.processing_type = '$str_inventory_adjust'
                  	   AND sal.id = sad_f.stock_adjust_voucher_id
                  	   AND sal.id = sad_t.stock_adjust_voucher_id
                  	   AND sad_f.storehouse_id = mp_f.id
                  	   AND sad_t.storehouse_id = mp_t.id
                  	   AND sad_f.transfer_quantity < 0
                  	   AND sad_t.transfer_quantity > 0
                  ) adj
						  ON adj.id = dsad.stock_adjust_voucher_id
                GROUP BY 
                  payee_voucher_no 
                  ,state 
                  ,place 
                  ,product_code
              ) m1 
            WHERE TRUE 
        ";

        if (!$searchFlg) {
            $sql = $sql."AND m1.product_code='' ";
        } else {
            //product_code
            if (isset($searchData['product_code']) && StringUtil::isNotBlank($searchData['product_code'])) {
                $sql = $sql.'AND m1.product_code='."'".$searchData['product_code']."'";
            }
        }

        if (!$stateId) {
            $state = $request->get('inventory_payment_master_state_select');
            //state
            if (isset($state) && StringUtil::isNotBlank($state)) {
                $sql = $sql.'AND m1.state_id='."'".$state."'";
            }
        } else {
            $sql = $sql.'AND m1.state_id='."'".$stateId."'";
        }

        //state
        if (isset($searchData['purchase_date_start']) && StringUtil::isNotBlank($searchData['purchase_date_start'])) {
            $purchase_date_start = $searchData['purchase_date_start'];
            $purchaseDateStart = $purchase_date_start->setTime('0', '0', '0')
                ->setTimezone(new \DateTimeZone('UTC'))
                ->format('Y-m-d H:i:s');
            $sql = $sql.' AND  m1.purchase_date >= \''.$purchaseDateStart.'\'';
        }

        //state
        if (isset($searchData['purchase_date_end']) && StringUtil::isNotBlank($searchData['purchase_date_end'])) {
            $purchase_date_end = $searchData['purchase_date_end'];
            $purchaseDateEnd = $purchase_date_end->setTime('23', '59', '59')
                ->setTimezone(new \DateTimeZone('UTC'))
                ->format('Y-m-d H:i:s');
            $sql = $sql.' AND  m1.purchase_date <= \''.$purchaseDateEnd.'\'';
        }

        // INS-START CNC 2021/12/13
        // storehouse
        if (isset($searchData['storehouse']) && StringUtil::isNotBlank($searchData['storehouse'])) {

            $sql = $sql.' AND (m1.storehouse_from='."'".$searchData['storehouse']->getPlace()."'";
            $sql = $sql.' OR m1.storehouse_to='."'".$searchData['storehouse']->getPlace()."'";
            $sql = $sql.' OR m1.place='."'".$searchData['storehouse']->getPlace()."')";

        }
        // INS-END CNC 2021/12/13

        // INS-START CNC 2022/03/23
        $sql = $sql.' ORDER BY 
        m1.purchase_date DESC ';
        // INS-END CNC 2022/03/23

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    /**
     * @param Request $request Request
     * @param $searchData
     * @param $stateId
     * @param $stock
     * @return mixed[]
     */
//    public function getSearchDataAllSerial(Request $request, $searchData, $stateId,$stock)
//    {
//        $pdo = $this->entityManager->getConnection()->getWrappedConnection();
//
//        // INS-START CNC 2021/12/13
//        $str_inventory_move = trans('admin.inventory.adjust.inventory_move');
//        $str_inventory_adjust = trans('admin.inventory.adjust.inventory_adjust');
//        // INS-END CNC 2021/12/13
//
//        $sql = "SELECT
//                                 *
//                               FROM
//                                 (
//                                   SELECT
//                                      dpvh.purchase_date AS purchase_date
//                                      , '仕入' AS type
//                                     ,dpvd.serial_no as serial_no
//                                     ,s.state AS state
//                                     ,s.id as state_id
//                                     , dpvd.payee_voucher_no AS payee_voucher_no
//                                     , p.place AS place
//                                     , '' AS storehouse_from
//                                     , '' AS storehouse_to
//                                     , dpvd.product_code AS product_code
//                                   FROM
//                                     dtb_payee_voucher_detail dpvd
//                                     LEFT JOIN dtb_payee_voucher_header dpvh
//                                       ON dpvd.payee_voucher_header_id = dpvh.id
//                                     LEFT JOIN mtb_state s
//                                       ON s.id = dpvd.state_id
//                                     LEFT JOIN mtb_payee_mst mst
//                                       ON  dpvh.payee_code = mst.id
//                                     LEFT JOIN mtb_place p
//                                       ON dpvh.storehouse_id = p.id
//                                   UNION ALL
//                                   SELECT
//                                      dsvh.sales_date AS purchase_date
//                                      , '売上' AS type
//                                     ,dsvd.serial_no as serial_no
//                                     , s.state as state
//                                     ,s.id as state_id
//                                     , dsvh.sales_voucher_no AS payee_voucher_no
//                                     , p1.place AS place
//                                     , '' AS storehouse_from
//                                     , '' AS storehouse_to
//                                     , dsvd.product_code AS product_code
//                                   FROM
//                                     dtb_sales_voucher_detail dsvd
//                                     LEFT JOIN dtb_sales_voucher_header dsvh
//                                       ON dsvd.sales_voucher_header_id = dsvh.id
//                                     INNER JOIN mtb_state s
//                                       ON s.id = dsvd.state_id
//                                     LEFT JOIN mtb_customer_mst cos
//                                       ON dsvh.customer_id = cos.id
//                                     INNER JOIN mtb_place p1
//                                       ON dsvd.storehouse_id = p1.id
//                                    UNION ALL
//                                    SELECT
//                                      dsal.stock_adjustments_date AS purchase_date
//                                     ,dsal.processing_type AS type
//                                     ,dsad.serial_no as serial_no
//                                     ,s.state as state
//                                     ,s.id as state_id
//                                     ,dsal.stock_adjust_voucher_no AS payee_voucher_no
//                                     ,p1.place AS place
//                                     ,CASE
//                                        WHEN dsal.processing_type = '$str_inventory_move'
//                                        THEN p_f.place
//                                        WHEN dsal.processing_type = '$str_inventory_adjust'
//                                        THEN adj.place_from
//                                        ELSE ''
//                                    END AS storehouse_from
//                                    ,CASE
//                                        WHEN dsal.processing_type = '$str_inventory_move'
//                                        THEN p_t.place
//                                        WHEN dsal.processing_type = '$str_inventory_adjust'
//                                        THEN adj.place_to
//                                        ELSE ''
//                                    END AS storehouse_to
//                                     ,dsad.product_code AS product_code
//                                   FROM
//                                     lcsdata.dtb_stock_adjust_detail dsad
//                                     LEFT JOIN lcsdata.dtb_stock_adjust_list dsal
//                     						ON dsad.stock_adjust_voucher_id = dsal.id
//                                    INNER JOIN mtb_state s
//                                            ON s.id = dsad.state_id
//                  				     LEFT JOIN lcsdata.mtb_customer_mst cos
//						                    ON dsal.representative_id = cos.id
//						            INNER JOIN lcsdata.mtb_place p1
//						                    ON dsad.storehouse_id = p1.id
//						            LEFT JOIN lcsdata.mtb_place p_f
//                                            ON dsal.from_storehouse_id = p_f.id
//                                    LEFT JOIN lcsdata.mtb_place p_t
//                                            ON dsal.to_storehouse_id = p_t.id
//						            LEFT JOIN (
//                                        SELECT sal.id AS id
//                                              ,sal.stock_adjust_voucher_no AS voucher_no
//                                              ,sal.processing_type AS processing_type
//                                              ,sad_f.storehouse_id AS storehouse_id_from
//                                              ,mp_f.place AS place_from
//                                              ,sad_t.storehouse_id AS storehouse_id_to
//                                              ,mp_t.place AS place_to
//                                          FROM lcsdata.dtb_stock_adjust_list sal
//                                              ,lcsdata.dtb_stock_adjust_detail sad_f
//                                              ,lcsdata.dtb_stock_adjust_detail sad_t
//                                              ,lcsdata.mtb_place mp_f
//                                              ,lcsdata.mtb_place mp_t
//                                         WHERE sal.processing_type = '$str_inventory_adjust'
//                                           AND sal.id = sad_f.stock_adjust_voucher_id
//                                           AND sal.id = sad_t.stock_adjust_voucher_id
//                                           AND sad_f.storehouse_id = mp_f.id
//                                           AND sad_t.storehouse_id = mp_t.id
//                                           AND sad_f.transfer_quantity < 0
//                                           AND sad_t.transfer_quantity > 0
//                                      ) adj
//                                            ON adj.id = dsad.stock_adjust_voucher_id
//                                 ) m1
//                               WHERE TRUE ";
//
//        //product_code
//        if (isset($searchData['product_code']) && StringUtil::isNotBlank($searchData['product_code']))
//        {
//
//            $sql= $sql.'AND m1.product_code='."'".addslashes($searchData['product_code'])."'";
//        }
//
//        if(!$stateId)
//        {
//            $state=$request->get('inventory_payment_master_state_select');
//            //state
//            if (isset($state) && StringUtil::isNotBlank($state))
//            {
//                $sql= $sql.'AND m1.state_id='."'".$state."'";
//            }
//        }
//        else
//        {
//            $sql= $sql.'AND m1.state_id='."'".$stateId."'";
//        }
//
//        //state
//        if (isset($searchData['purchase_date_start']) && StringUtil::isNotBlank($searchData['purchase_date_start'])) {
//
//            $purchase_date_start = $searchData['purchase_date_start'];
//            $purchaseDateStart = $purchase_date_start->setTime('0', '0', '0')
//                ->setTimezone(new \DateTimeZone('UTC'))
//                ->format('Y-m-d H:i:s');
//            $sql = $sql.' AND  m1.purchase_date >= \''.$purchaseDateStart .'\'';
//        }
//
//        //state
//        if (isset($searchData['purchase_date_end']) && StringUtil::isNotBlank($searchData['purchase_date_end'])) {
//
//            $purchase_date_end = $searchData['purchase_date_end'];
//            $purchaseDateEnd = $purchase_date_end->setTime('23', '59', '59')
//                ->setTimezone(new \DateTimeZone('UTC'))
//                ->format('Y-m-d H:i:s');
//            $sql = $sql.' AND  m1.purchase_date <= \''.$purchaseDateEnd .'\'';
//        }
//
//        // INS-START CNC 2021/12/13
//        // storehouse
//        if (isset($searchData['storehouse']) && StringUtil::isNotBlank($searchData['storehouse'])) {
//
//            $sql = $sql.' AND (m1.storehouse_from='."'".$searchData['storehouse']->getPlace()."'";
//            $sql = $sql.' OR m1.storehouse_to='."'".$searchData['storehouse']->getPlace()."'";
//            $sql = $sql.' OR m1.place='."'".$searchData['storehouse']->getPlace()."')";
//
//        }
//        // INS-END CNC 2021/12/13
//
//        $sql= $sql.'AND m1.payee_voucher_no='."'".$stock['payee_voucher_no']."'";
//        $sql= $sql.'AND m1.state='."'".$stock['state']."'";
//        $sql= $sql.'AND m1.place='."'".$stock['place']."'";
//        $sql= $sql.'AND m1.product_code='."'".$stock['product_code']."'";
//
//        $stmt = $pdo->prepare($sql);
//        $stmt->execute();
//        $result = $stmt->fetchAll();
//        return $result;
//    }

    /**
     * CSVの出力.
     *
     * @Route("/%eccube_admin_route%/inventory_payment/export",name="admin_inventory_payment_export")
     *
     * @param Request $request Request
     *
     * @return StreamedResponse
     */
    public function export(Request $request)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        // sql loggerを無効にする.
        $em = $this->entityManager;
        $em->getConfiguration()->setSQLLogger(null);

        $response = new StreamedResponse();
        $response->setCallback(function () use ($request) {
            // CSV種別を元に初期化.
            $this->csvExportService->initCsvType(CsvType::CSV_TYPE_INVENTORY_PAYMENT);

            // ヘッダ行の出力.
            $this->csvExportService->exportHeader();

            $qb = $this->getInventoryPaymentQueryBuilder($request, $this->session->get('eccube.admin.inventory.search.selected_state'));
            // データ行の出力.
            $this->csvExportService->setExportDetailQueryBuilder($qb);

            $this->csvExportService->exportDataArrayCsv(function ($entity, csvExportService $csvService) use ($request) {
                $Csvs = $csvService->getCsvs();

                $InventoryPaymentCSV = new \Eccube\Entity\InventoryPaymentCSV();
                $InventoryPaymentCSV->setPurchaseDate(
                    (new \DateTime($entity['purchase_date'], new \DateTimeZone('UTC')))
                        ->setTimezone( new \DateTimeZone('Asia/Tokyo'))
                        ->format('Y/m/d')
                );

                $InventoryPaymentCSV->setType($entity['type']);
                $InventoryPaymentCSV->setPayeeVoucherNo($entity['payee_voucher_no']);
                $InventoryPaymentCSV->setState($entity['state']);
                $InventoryPaymentCSV->setPayeeName($entity['payee_name']);
                $InventoryPaymentCSV->setInCount($entity['in_count']);
                $InventoryPaymentCSV->setOutCount($entity['out_count']);
                $InventoryPaymentCSV->setPlace($entity['place']);
                $serialNos = [];
                if ($entity['serial_no_flg'] == 'TRUE') {
                    if ($entity['type'] == '仕入') {
                        $payeeVoucherDetails = $this->payeeVoucherDetailRepository->findBy(['product_code' => $entity['product_code'], 'payee_voucher_no' => $entity['payee_voucher_no'], 'State' => $entity['state_id']]);
                        foreach ($payeeVoucherDetails as $payeeVoucherDetail) {
                            $serialNos[] = $payeeVoucherDetail->getSerialNo();
                        }
                    } elseif ($entity['type'] == '売上') {
                        $salesVoucherDetails = $this->salesVoucherDetailRepository->findBy(['product_code' => $entity['product_code'], 'sales_voucher_no' => $entity['payee_voucher_no'], 'State' => $entity['state_id']]);
                        foreach ($salesVoucherDetails as $salesVoucherDetail) {
                            $serialNos[] = $salesVoucherDetail->getSerialNo();
                        }
                    }
                } else {
                    $serialNos[] = $entity['serial_no'];
                }
                $InventoryPaymentCSV->setSerialNo(implode(',', $serialNos));
                $ExportCsvRow = new \Eccube\Entity\ExportCsvRow();

                // CSV出力項目と合致するデータを取得.
                foreach ($Csvs as $Csv) {
                    $ExportCsvRow->setData($csvService->getData($Csv, $InventoryPaymentCSV));
                    $event = new EventArgs(
                        [
                            'csvService' => $csvService,
                            'Csv' => $Csv,
                            'Inventory_Payment_' => $entity,
                            'ExportCsvRow' => $ExportCsvRow,
                        ],
                        $request
                    );
                    $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_INVENTORY_PAYMENT_CSV_EXPORT, $event);

                    $ExportCsvRow->pushData();
                }

                // 出力.
                $csvService->fputcsv($ExportCsvRow->getRow());
            });
        });

        $now = new \DateTime();
        $filename = 'inventory_payment_'.$now->format('YmdHis').'.csv';
        $response->headers->set('Content-Type', 'application/octet-stream');
        $response->headers->set('Content-Disposition', 'attachment; filename='.$filename);
        $response->send();

        log_info('受付照会CSV出力ファイル名', [$filename]);

        return $response;
    }

    /**
     * 在庫照会用のクエリビルダを返す.
     *
     * @param Request $request Request
     *
     * @return \Doctrine\ORM\QueryBuilder
     */
    public function getInventoryPaymentQueryBuilder(Request $request, $stateId)
    {
        $session = $request->getSession();

        $builder = $this->formFactory
            ->createBuilder(InventoryPaymentType ::class);

        $searchForm = $builder->getForm();

        $viewData = $session->get('eccube.admin.inventory.payment.search', []);
        $searchData = FormUtil::submitAndGetData($searchForm, $viewData);

        $qb = $this->getSearchData($request, $searchData, $stateId, true);

        return $qb;
    }

    /**
     * 受付照会用のクエリビルダを返す.
     *
     * @param string $state_id 前画面状態ID
     * @param string $product_code 商品コード
     *
     * @return $result
     */
    public function getInventoryInfo(string $state_id, string $product_code)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();
        $sql = ' SELECT
                  p.name AS product_name
                , MIN(pvh.purchase_date) AS purchase_date
                 FROM
                dtb_payee_voucher_detail pvd
                LEFT JOIN dtb_product p 
                ON pvd.product_id = p.id 
                LEFT JOIN dtb_payee_voucher_header pvh 
                ON pvd.payee_voucher_header_id = pvh.id
                 ';

        $sql = $sql.' WHERE pvd.product_code = '."'".$product_code."'";
        $sql = $sql.' AND pvd.state_id = '."'".$state_id."'";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    /**
     * @param $orders
     * @param $searchData
     * @return mixed
     */
    private function sortOrder($orders, $searchData)
    {
        if ($searchData['sort_by']) {
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case '受払日':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == '降順') {
                            return $a['purchase_date'] > $b['purchase_date'] ? -1 : 1;
                        }
                        return $a['purchase_date'] < $b['purchase_date'] ? -1 : 1;
                    });
                    break;
                case '受払種類':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == '降順') {
                            return $a['type'] > $b['type'] ? -1 : 1;
                        }
                        return $a['type'] < $b['type'] ? -1 : 1;
                    });
                    break;
            }
        }
        return $orders;
    }

    /**
     * UTC時間を東京時間にする
     * @param string|null $date 時間文字列(yyyy-mm-dd HH:ii:ss)
     * @return string
     */
    public function makeDateStringUtcToAsiaTokyo(string $date = null)
    {
        if (!$date || $date !== date('Y-m-d H:i:s', strtotime($date))) {
            return '';
        }

        try {
            $date_utc = new \DateTime($date, new \DateTimeZone('UTC'));
            $date_asia_tokyo = $date_utc
                ->setTimezone(new \DateTimeZone('Asia/Tokyo'))
                ->format('Y-m-d H:i:s');
        } catch (\Exception $exception) {
            return '';
        }

        return $date_asia_tokyo;
    }
}