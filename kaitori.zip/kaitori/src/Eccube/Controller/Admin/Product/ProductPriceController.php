<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Product;

use Doctrine\DBAL\Exception\ForeignKeyConstraintViolationException;
use Eccube\Common\Constant;
use Eccube\Controller\AbstractController;
use Eccube\Entity\BaseInfo;
use Eccube\Entity\ExportCsvRow;
use Eccube\Entity\Master\CsvType;
use Eccube\Entity\Master\ProductStatus;
use Eccube\Entity\PriceUpdate;
use Eccube\Entity\Product;
use Eccube\Entity\ProductCategory;
use Eccube\Entity\ProductClass;
use Eccube\Entity\Alarm;
use Eccube\Entity\ProductPrice;
use Eccube\Entity\ProductImage;
use Eccube\Entity\ProductStock;
use Eccube\Entity\ProductStockHistory;
use Eccube\Entity\ProductTag;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\ProductType;
use Eccube\Form\Type\Admin\SearchProductForPriceType;
use Eccube\Repository\BaseInfoRepository;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\Master\ProductStatusRepository;
use Eccube\Repository\OrderItemRepository;
use Eccube\Repository\PriceUpdateRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\ProductStockRepository;
use Eccube\Repository\ProductStockHistoryRepository;
use Eccube\Repository\ProductImageRepository;
use Eccube\Repository\ProductPriceRepository;
use Eccube\Repository\ProductPriceHistoryRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\StateRepository;
use Eccube\Repository\StockListProductUnitRepository;
use Eccube\Repository\TagRepository;
use Eccube\Repository\TaxRuleRepository;
use Eccube\Repository\AlarmRepository;
use Eccube\Repository\OrderRepository;
use Eccube\Service\CsvExportService;
use Eccube\Util\CacheUtil;
use Eccube\Util\FormUtil;
use Eccube\Util\StringUtil;
use Knp\Component\Pager\Paginator;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\UnsupportedMediaTypeHttpException;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Routing\RouterInterface;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Validator\ValidatorInterface;
use DateTimeZone;
use Symfony\Component\Translation\TranslatorInterface;

class ProductPriceController extends AbstractController
{
    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;
    
     /**
     * @var OrderRepository
     */
    protected $orderRepository;
    
    /**
     * @var ProductStockRepository
     */
    protected $productStockRepository;
    
    /**
     * @var ProductClassRepository
     */
    protected $productClassRepository;
    
    /**
     * @var ProductStockHistoryRepository
     */
    protected $productStockHistoryRepository;

    /**
     * @var ProductPriceRepository
     */
    protected $productPriceRepository;

    /**
     * @var ProductPriceHistoryRepository
     */
    protected $productPriceHistoryRepository;

    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;

    /**
     * @var AlarmRepository
     */
    protected $alarmRepository;

    /**
     * @var ValidatorInterface
     */
    protected $validator;

    /**
     * @var StockListProductUnitRepository
     */
    protected $stockListProductUnitRepository;

    /**
     * @var OrderItemRepository
     */
    protected $orderItemRepository;

    /**
     * @var StateRepository
     */
    protected $stateRepository;

    /**
     * @var PriceUpdateRepository
     */
    protected $priceUpdateRepository;

    // INS-START CNC 2022/05/24
    /**
     * @var ProductRepository
     */
    protected $productRepository;
    // INS-END CNC 2022/05/24

    /**
     * ProductPriceController constructor.
     *
     * @param PageMaxRepository $pageMaxRepository
     * @param ProductPriceRepository $productPriceRepository
     * @param ProductPriceHistoryRepository $productPriceHistoryRepository
     * @param ValidatorInterface $validator
     */
    public function __construct(
        PageMaxRepository $pageMaxRepository,
        CategoryRepository $categoryRepository,
        ProductStockRepository $productStockRepository,
        ProductClassRepository $productClassRepository,
        ProductStockHistoryRepository $productStockHistoryRepository,
        ProductPriceRepository $productPriceRepository,
        AlarmRepository $alarmRepository,
        ProductPriceHistoryRepository $productPriceHistoryRepository,
        OrderRepository $orderRepository,
        ValidatorInterface $validator,
        StockListProductUnitRepository $stockListProductUnitRepository,
        OrderItemRepository $orderItemRepository,
        StateRepository $stateRepository,
        PriceUpdateRepository $priceUpdateRepository
        // INS-START CNC 2022/05/24
        , ProductRepository $productRepository
        // INS-END CNC 2022/05/24
    ) {
        ini_set('memory_limit', '2048M');

        $this->pageMaxRepository = $pageMaxRepository;
        $this->categoryRepository = $categoryRepository;
        $this->productStockRepository = $productStockRepository;
        $this->productClassRepository = $productClassRepository;
        $this->productStockHistoryRepository = $productStockHistoryRepository;
        $this->productPriceRepository = $productPriceRepository;
        $this->alarmRepository = $alarmRepository;
        $this->productPriceHistoryRepository = $productPriceHistoryRepository;
        $this->orderRepository = $orderRepository;
        $this->validator = $validator;
        $this->stockListProductUnitRepository = $stockListProductUnitRepository;
        $this->orderItemRepository = $orderItemRepository;
        $this->stateRepository = $stateRepository;
        $this->priceUpdateRepository = $priceUpdateRepository;
        // INS-START CNC 2022/05/24
        $this->productRepository = $productRepository;
        // INS-END CNC 2022/05/24
    }

    /**
     * @Route("/%eccube_admin_route%/product_price", name="admin_product_price")
     * @Route("/%eccube_admin_route%/product_price/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_product_price_page")
     * @Route("/%eccube_admin_route%/product_price/product/{productId}", requirements={"productId" = "\d+"}, name="admin_product_price_product")
     * @Template("@admin/Product/product_price.twig")
     */
    public function index(Request $request, $page_no = null, Paginator $paginator, $productId = null)
    {
        $builder = $this->formFactory
            ->createBuilder(SearchProductForPriceType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_PRICE_INDEX_INITIALIZE, $event);

        $searchForm = $builder->getForm();

        /**
         * ページの表示件数は, 以下の順に優先される.
         * - リクエストパラメータ
         * - セッション
         * - デフォルト値
         * また, セッションに保存する際は mtb_page_maxと照合し, 一致した場合のみ保存する.
         **/
//        $page_count = $this->session->get('eccube.admin.product.price.search.page_count',
//            $this->eccubeConfig->get('eccube_default_page_count'));
        $page_count = $this->session->get('eccube.admin.product.price.search.page_count',
            $this->eccubeConfig->get('eccube_page_count_max'));

        $page_count_param = (int) $request->get('page_count');
        //$page_count_param = 2000;
        $pageMaxis = $this->pageMaxRepository->findAll();

        if ($page_count_param) {
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.admin.product.price.search.page_count', $page_count);
                    break;
                }
            }
        }

        if ('POST' === $request->getMethod()) {
            log_info("POST");
            $searchForm->handleRequest($request);

            if ($searchForm->isValid()) {
                /**
                 * 検索が実行された場合は, セッションに検索条件を保存する.
                 * ページ番号は最初のページ番号に初期化する.
                 */
                $page_no = 1;
                $searchData = $searchForm->getData();

                log_info("viewData:", [FormUtil::getViewData($searchForm)]);
                log_info("searchData:", [$searchData]);

                // 検索条件, ページ番号をセッションに保持.
                $this->session->set('eccube.admin.product.price.search', FormUtil::getViewData($searchForm));
                $this->session->set('eccube.admin.product.price.search.page_no', $page_no);

                // 制限数リセット
                if($request->get('from_action') == 'reset'){
                    $this->resetProductStock($request);
                }
                                    
            } else {
                // 検索エラーの際は, 詳細検索枠を開いてエラー表示する.
                return [
                    'searchForm' => $searchForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $page_count,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                log_info("resume");
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.admin.product.price.search.page_no', (int) $page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.admin.product.price.search.page_no', 1);
                }
                $viewData = $this->session->get('eccube.admin.product.price.search', []);
                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
            } else {
                // INS-START CNC 2022/05/24

                if ($productId != null) {
                    log_info("home");
                    /**
                     * ホーム画面から遷移した場合
                     */
                    $page_no = 1;

                    // main category
                    $product = $this->productRepository->find($productId);

                    $productCode = $product->getProductClasses()[0]['code'];

                    $mainCategoryId = $product->getProductCategories()[0]['category_id'];
                    $mainCategory = $this->categoryRepository->find($mainCategoryId);
                    $subCategoryId = $product->getProductCategories()[2]['category_id'];
                    $subCategory = $this->categoryRepository->find($subCategoryId);

                    // submit default value
                    $viewData = FormUtil::getViewData($searchForm);
                    $viewData['id'] = $productCode;
                    $viewData['main_category_id'] = $mainCategory->getId();
                    $viewData['category_id_'.$mainCategory->getId()] = $subCategory->getId();

                    log_info("viewData:", [$viewData]);

                    $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
                    $searchData['id'] = $productCode;
                    $searchData['main_category_id'] = $mainCategory;
                    $searchData['category_id_'.$mainCategory->getId()] = $subCategory;

                    log_info("searchData:", [$searchData]);

                    // セッション中の検索条件, ページ番号を初期化.
                    $this->session->set('eccube.admin.product.price.search', $viewData);
                    $this->session->set('eccube.admin.product.price.search.page_no', $page_no);
                    // INS-END CNC 2022/05/24
                } else {
                    log_info("init");
                    /**
                     * 初期表示の場合.
                     */
                    $page_no = 1;

                    // main category
                    $categories = $this->categoryRepository->getList(null, false);
                    $mainCategory = null;
                    foreach($categories as $Category) {
                        if ($Category && ($Category->getHierarchy() == 1) ) {
                            $mainCategory = $Category;
                            break;
                        }
                    }

                    // submit default value
                    $viewData = FormUtil::getViewData($searchForm);
                    if ($mainCategory) {
                        $viewData['main_category_id'] = $mainCategory->getId();
                    }
                    log_info("viewData:", [$viewData]);

                    $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
                    if ($mainCategory) {
                        $searchData['main_category_id'] = $mainCategory;
                    }
                    log_info("searchData:", [$searchData]);

                    // セッション中の検索条件, ページ番号を初期化.
                    $this->session->set('eccube.admin.product.price.search', $viewData);
                    $this->session->set('eccube.admin.product.price.search.page_no', $page_no);
                }
            }
        }

        $qb = $this->productPriceRepository->getQueryBuilderBySearchDataForAdmin($searchData);
        $prices = $qb->getQuery()->getResult();

        // get warn price
        $prices_warn = [];
        $prices_normal = [];
        foreach($prices as $price) {
            if ($price->isPriceValid() == false) {
                $prices_warn[] = $price;
            } else {
                $prices_normal[] = $price;
            }
        }
        //add normal after warn 
        foreach($prices_normal as $normal) {
            $prices_warn[] = $normal;
        }

        //INS-START CNC 2022/12/09 他社最低売価、残在庫数、予約数
        $i = 0;

        foreach ($prices_warn as $price_stock) {
            if (!is_null($price_stock['ProductClass']['code']) && is_null($price_stock['parent_id'])) {
//                $stockListProductUnit = $this->stockListProductUnitRepository->findProductsWithNew($price_stock['ProductClass']['code']);
                $array_product_info = $this->getSearchProductData($price_stock['ProductClass']['code']);
            } else {
                $array_product_info = null;
            }

            $averageUnitPrice = isset($array_product_info[0]) ? $array_product_info[0]['average_unit_price'] : 0;
            $remainingStockQuantity = isset($array_product_info[0]) ? $array_product_info[0]['remaining_stock_quantity'] : 0;
            // 予約数
            $reservationQuantity = isset($array_product_info[0]) ? $array_product_info[0]['reservation_quantity'] : 0;
            // 他社最低売価
            // <a>-（wiki）</a></br><a>-（けん君）</a></br><a>-（楽園）</a></br><a>-（一丁）</a>
            if (isset($array_product_info[0])) {
                if (is_null($array_product_info[0]['competitors_selling_price1'])) {
                    $priceShopOtherList = '<a>-（楽天）</a></br>';
                } elseif ($array_product_info[0]['competitors_selling_price1'] == 999999999) {
                    $priceShopOtherList = '<a>-（楽天）</a></br>';
                } elseif ($array_product_info[0]['competitors_selling_price1'] < 600) {
                    $priceShopOtherList = '<a>'.$array_product_info[0]['competitors_selling_price1'].'（楽天）</a></br>';
                } else {
                    $priceShopOtherList = '<a>'.ceil(($array_product_info[0]['competitors_selling_price1'] - 600) * 0.92).'（楽天）</a></br>';
                }
                if (is_null($array_product_info[0]['competitors_selling_price2'])) {
                    $priceShopOtherList = $priceShopOtherList.'<a>-（Yahoo）</a></br>';
                } elseif ($array_product_info[0]['competitors_selling_price2'] == 999999999) {
                    $priceShopOtherList = $priceShopOtherList.'<a>-（Yahoo）</a></br>';
                } elseif ($array_product_info[0]['competitors_selling_price2'] < 600) {
                    $priceShopOtherList = $priceShopOtherList.'<a>'.$array_product_info[0]['competitors_selling_price2'].'（Yahoo）</a></br>';
                } else {
                    $priceShopOtherList = $priceShopOtherList.'<a>'.ceil(($array_product_info[0]['competitors_selling_price2'] - 600) * 0.92).'（Yahoo）</a></br>';
                }
                if (is_null($array_product_info[0]['competitors_selling_price3'])) {
                    $priceShopOtherList = $priceShopOtherList.'<a>-（Yahoo2）</a></br>';
                } elseif ($array_product_info[0]['competitors_selling_price3'] == 999999999) {
                    $priceShopOtherList = $priceShopOtherList.'<a>-（Yahoo2）</a></br>';
                } elseif ($array_product_info[0]['competitors_selling_price3'] < 600) {
                    $priceShopOtherList = $priceShopOtherList.'<a>'.$array_product_info[0]['competitors_selling_price3'].'（Yahoo2）</a></br>';
                } else {
                    $priceShopOtherList = $priceShopOtherList.'<a>'.ceil(($array_product_info[0]['competitors_selling_price3'] - 600) * 0.92).'（Yahoo2）</a></br>';
                }
                if (is_null($array_product_info[0]['competitors_selling_price4'])) {
                    $priceShopOtherList = $priceShopOtherList.'<a>-（Amazon）</a></br>';
                } elseif ($array_product_info[0]['competitors_selling_price4'] == 999999999) {
                    $priceShopOtherList = $priceShopOtherList.'<a>-（Amazon）</a></br>';
                } elseif ($array_product_info[0]['competitors_selling_price4'] < 600) {
                    $priceShopOtherList = $priceShopOtherList.'<a>'.$array_product_info[0]['competitors_selling_price4'].'（Amazon）</a></br>';
                } else {
                    $priceShopOtherList = $priceShopOtherList.'<a>'.ceil(($array_product_info[0]['competitors_selling_price4'] - 600) * 0.92).'（Amazon）</a></br>';
                }
                if (is_null($array_product_info[0]['competitors_selling_price5'])) {
                    $priceShopOtherList = $priceShopOtherList.'<a>-（自社）</a>';
                } elseif ($array_product_info[0]['competitors_selling_price5'] == 999999999) {
                    $priceShopOtherList = $priceShopOtherList.'<a>-（自社）</a>';
                } elseif ($array_product_info[0]['competitors_selling_price5'] < 600) {
                    $priceShopOtherList = $priceShopOtherList.'<a>'.$array_product_info[0]['competitors_selling_price5'].'（自社）</a>';
                } else {
                    $priceShopOtherList = $priceShopOtherList.'<a>'.ceil(($array_product_info[0]['competitors_selling_price5'] - 600) * 0.92).'（自社）</a>';
                }
            } else {
                $priceShopOtherList = null;
            }

            $price_stock->setAverageUnitPrice($averageUnitPrice);
            $price_stock->setRemainingStockQuantity($remainingStockQuantity);
            // 他社最低売価
            $price_stock->setPriceShopOtherList($priceShopOtherList);
            // 予約数
            $price_stock->setReservationQuantity($reservationQuantity);

            $prices_warn[$i] = $price_stock;
            $i++;
        }
        //INS-START CNC 2022/12/09 他社最低売価、残在庫数、予約数

        $prices_warn = $this->filterProductResult($prices_warn, $searchData);
        $prices_warn = $this->sortProductResult($prices_warn, $searchData);

        $pagination = $paginator->paginate(
            $prices_warn,
            $page_no,
            $page_count
        );
        $alarms = $this->alarmRepository->getList();
        $stock_alarms = $this->alarmRepository->getWarnList();
        return [
            'searchForm' => $searchForm->createView(),
            'pagination' => $pagination,
            'Prices' => $prices,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'alarms' => $alarms,
            'stock_alarms' => $stock_alarms,
            'has_errors' => false,
        ];
    }

    /**
     * Update to Price.
     *
     * @Route("/%eccube_admin_route%/product_price/{id}/price_update", requirements={"id" = "\d+"}, name="admin_product_update_price_single", methods={"PUT"})
     *
     * @param Request $request
     * @param ProductPrice $productPrice
     *
     * @return Response
     */
    public function updatePrice(Request $request, ProductPrice $productPrice)
    {
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
        }

        log_info("request->tracking_number",[$request->get('tracking_number')]);
        $price = intval(str_replace(',','',$request->get('tracking_number')));
        log_info("price",[$price]);
        /** @var \Symfony\Component\Validator\ConstraintViolationListInterface $errors */
        $errors = $this->validator->validate(
            $price,
            [
                new Assert\Length(['max' => $this->eccubeConfig['eccube_stext_len']]),
                new Assert\Regex(
                    ['pattern' => '/^[0-9]+$/u', 'message' => trans('admin.setting.shop.delivery.fee.invalid')]
                ),
            ]
        );

        if ($errors->count() != 0) {
            log_info('入力チェックエラー');
            $messages = [];
            /** @var \Symfony\Component\Validator\ConstraintViolationInterface $error */
            foreach ($errors as $error) {
                $messages[] = $error->getMessage();
            }

            return $this->json(['status' => 'NG', 'messages' => $messages], 400);
        }

        try {
            $productPrice->setPrice($price);
            $productPrice->setMember($this->getUser());
            $productPrice->setMemberUpdateDate(new \DateTime());
            $this->entityManager->flush($productPrice);
            log_info("productPrice->price",[$productPrice->getPrice()]);
            log_info('変更処理完了', [$productPrice->getId()]);
            //$message = ['status' => 'OK', 'price_id' => $productPrice->getId(), 'price' => $price];
            //$message = ['status' => 'OK', 'shipping_id' => $productPrice->getId(), 'tracking_number' => number_format($price)];
            $message = ['status' => 'OK', 'shipping_id' => $productPrice->getId(), 'tracking_number' => number_format($price), 'member' => $productPrice->getMember()->getName(), 'member_update_date' => $productPrice->getMemberUpdateDate()->setTimeZone(new DateTimeZone('Asia/Tokyo'))->format('Y-m-d H:i:s')];
            log_info("result message",[$message]);

            return $this->json($message);
        } catch (\Exception $e) {
            log_error('予期しないエラー', [$e->getMessage()]);

            return $this->json(['status' => 'NG'], 500);
        }
    }

    /**
     * Update to salelimit.
     *
     * @Route("/%eccube_admin_route%/product_price/{id}/sale_limit_update", requirements={"id" = "\d+"}, name="admin_product_update_sale_limit_single", methods={"PUT"})
     *
     * @param Request $request
     * @param ProductPrice $productPrice
     *
     * @return Response
     */
    public function updateSaleLimit(Request $request, ProductPrice $productPrice)
    {
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
        }

        log_info("request->sale_limit",[$request->get('sale_limit')]);
        $sale_limit = intval(str_replace(',','',$request->get('sale_limit')));
        log_info("sale_limit",[$sale_limit]);
        /** @var \Symfony\Component\Validator\ConstraintViolationListInterface $errors */
        $errors = $this->validator->validate(
            $sale_limit,
            [
                new Assert\Length(['max' => $this->eccubeConfig['eccube_stext_len']]),
                new Assert\Regex(
                    ['pattern' => '/^[0-9]+$/u', 'message' => trans('admin.setting.shop.delivery.fee.invalid')]
                ),
            ]
        );

        if ($errors->count() != 0) {
            log_info('入力チェックエラー');
            $messages = [];
            /** @var \Symfony\Component\Validator\ConstraintViolationInterface $error */
            foreach ($errors as $error) {
                $messages[] = $error->getMessage();
            }

            return $this->json(['status' => 'NG', 'messages' => $messages], 400);
        }

        try {
            $productClass = $productPrice->getProductClass();
            $productClass->setSaleLimit($sale_limit);
            $this->entityManager->flush($productClass);
            $productPrice->setMember($this->getUser());
            $productPrice->setMemberUpdateDate(new \DateTime());
            $this->entityManager->flush($productPrice);
            log_info("productClass->sale_limit",[$productClass->getSaleLimit()]);
            log_info('変更処理完了', [$productPrice->getId()]);
            //$message = ['status' => 'OK', 'price_id' => $productPrice->getId(), 'price' => $price];
            //$message = ['status' => 'OK', 'price_id' => $productPrice->getId(), 'sale_limit' => number_format($sale_limit)];
            $message = ['status' => 'OK', 'price_id' => $productPrice->getId(), 'sale_limit' => number_format($sale_limit), 'member' => $productPrice->getMember()->getName(), 'member_update_date' => $productPrice->getMemberUpdateDate()->setTimeZone(new DateTimeZone('Asia/Tokyo'))->format('Y-m-d H:i:s')];
            log_info("result message",[$message]);

            return $this->json($message);
        } catch (\Exception $e) {
            log_error('予期しないエラー', [$e->getMessage()]);

            return $this->json(['status' => 'NG'], 500);
        }
    }

    /**
     * Update to stocklimit.
     *
     * @Route("/%eccube_admin_route%/product_price/{id}/stock_limit_update", requirements={"id" = "\d+"}, name="admin_product_update_stock_limit_single", methods={"PUT"})
     *
     * @param Request $request
     * @param ProductPrice $productPrice
     *
     * @return Response
     */
    public function updateStockLimit(Request $request, ProductPrice $productPrice)
    {
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
        }

        log_info("request->stock_limit",[$request->get('stock_limit')]);
        $stock_limit = intval(str_replace(',','',$request->get('stock_limit')));
        log_info("stock_limit",[$stock_limit]);
        /** @var \Symfony\Component\Validator\ConstraintViolationListInterface $errors */
        $errors = $this->validator->validate(
            $stock_limit,
            [
                new Assert\Length(['max' => $this->eccubeConfig['eccube_stext_len']]),
                new Assert\Regex(
                    ['pattern' => '/^[0-9]+$/u', 'message' => trans('admin.setting.shop.delivery.fee.invalid')]
                ),
            ]
        );

        if ($errors->count() != 0) {
            log_info('入力チェックエラー');
            $messages = [];
            /** @var \Symfony\Component\Validator\ConstraintViolationInterface $error */
            foreach ($errors as $error) {
                $messages[] = $error->getMessage();
            }

            return $this->json(['status' => 'NG', 'messages' => $messages], 400);
        }

        try {
            $productClass = $productPrice->getProductClass();
            if ($stock_limit > 0) {
                $productClass->setStock($stock_limit);
                $productClass->setStockUnlimited(false);
            } else {
                $productClass->setStock(0);
                $productClass->setStockUnlimited(true);
            }
            $this->entityManager->flush($productClass);
            $productPrice->setMember($this->getUser());
            $productPrice->setMemberUpdateDate(new \DateTime());
            $this->entityManager->flush($productPrice);
            log_info("productClass->stock_limit",[$productClass->getStock()]);
            log_info('変更処理完了', [$productPrice->getId()]);
            //$message = ['status' => 'OK', 'price_id' => $productPrice->getId(), 'price' => $price];
            $message = ['status' => 'OK', 'price_id' => $productPrice->getId(), 'stock_limit' => number_format($stock_limit), 'member' => $productPrice->getMember()->getName(), 'member_update_date' => $productPrice->getMemberUpdateDate()->setTimeZone(new DateTimeZone('Asia/Tokyo'))->format('Y-m-d H:i:s')];
            log_info("result message",[$message]);

            return $this->json($message);
        } catch (\Exception $e) {
            log_error('予期しないエラー', [$e->getMessage()]);

            return $this->json(['status' => 'NG'], 500);
        }
    }

    /**
     * @Route("/%eccube_admin_route%/product_price/bulk_price_update_index", name="admin_product_update_price_index")
     * @Template("@admin/Product/bulk_price_update_index.twig")
     */
    public function bulkUpdateProductPrice_test()
    {
        return [];
    }

    /**
     * Update to Price.
     *
     * @Route("/%eccube_admin_route%/product_price/bulk_price_update", name="admin_product_update_price", methods={"POST"})
     *
     * @param Request $request
     *
     * @return Response
     */
    public function bulkUpdateProductPrice(Request $request)
    {
        // if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
        //     return $this->json(['status' => 'NG'], 400);
        // }

        // check token
        $bulk_token = $request->get('_bulk_token');
        log_info("_bulk_token", [$bulk_token]);
        if (!($bulk_token && $bulk_token === "e56f431577eb42f5b67fd624bfa47d4d")) {
            return $this->json(['status' => 'NG'], 400); 
        }

        $ProductPrices = $this->productPriceRepository->findAll();

        $count = 0;
        foreach ($ProductPrices as $ProductPrice) {
            try {
                log_info("id", [$ProductPrice->getId(), $ProductPrice->getPrice()]);
                $ProductPrice->setPrice($ProductPrice->getPrice());
                $count++;
            } catch (\Exception $e) {
                log_info("status1", ['NG, 500']);
                return $this->json(['status' => 'NG'], 500); 
            }
        }

        try {
            if ($count > 0) {
                $this->entityManager->flush(); 
            }
        } catch (\Exception $e) {
            log_info("status2", ['NG, 500']);
            return $this->json(['status' => 'NG'], 500); 
        }

        return $this->json(['status' => 'OK'], 200);
    }

    /**
     * Bulk public action
     *
     * @Route("/%eccube_admin_route%/product_price/bulk/product-price/{id}", requirements={"id" = "\d+"}, name="admin_product_bulk_product_price", methods={"POST"})
     *
     * @param Request $request
     *
     * @return RedirectResponse
     */
    public function bulkProductPrice(Request $request, CacheUtil $cacheUtil)
    {
        log_info("bulkProductPrice");
        $this->isTokenValid();

        log_info("ids", [$request->get('ids')]);
        /** @var ProductPrice[] $ProductPrices */
        $ProductPrices = $this->productPriceRepository->findBy(['id' => $request->get('ids')]);
        $count = 0;
        foreach ($ProductPrices as $ProductPrice) {
            try {
                log_info("id", [$ProductPrice->getId(), $ProductPrice->getPrice()]);
                $ProductPrice->setPrice($ProductPrice->getPrice());
                $this->productPriceRepository->save($ProductPrice);
                $count++;
            } catch (\Exception $e) {
                $this->addError($e->getMessage(), 'admin');
            }
        }
        try {
            if ($count) {
                $this->entityManager->flush();
                // $msg = $this->translator->trans('admin.product.bulk_change_status_complete', [
                //     '%count%' => $count,
                //     '%status%' => $ProductStatus->getName(),
                // ]);
                // $this->addSuccess($msg, 'admin');
                $cacheUtil->clearDoctrineCache();
            }
        } catch (\Exception $e) {
            //$this->addError($e->getMessage(), 'admin');
        }

        return $this->redirectToRoute('admin_product_price', ['resume' => Constant::ENABLED]);
    }


    private function getProductPriceHistoryByPriceId($priceId, $scale){
        $maxSize = 10;
        if($scale){
            switch($scale){
                case "day10" :
                    $maxSize = 10;
                    break;
                case "month1" :
                    $maxSize = 30;
                    break;
                case "month3" :
                    $maxSize = 90;
                    break;
                case "year1" :
                    $maxSize = 365;
                    break;
            }
        }
        $histories = $this->productPriceHistoryRepository->findByPriceId($priceId, $maxSize);
        $labels = [];
        $price = [];
        $price_sale = [];
        $price_other = [];
        foreach ($histories as $history) {
            $history->getCreateDate()->setTimeZone(new DateTimeZone('UTC'));
            $labels[] = date_format($history->getCreateDate(), 'm月d日');
            $price[] = $history->getPrice();
            $price_sale[] = $history->getPriceSale();
            $price_other[] = $history->getPriceOther();
        }
        $count = count($histories);        
        $lastDate = new \DateTime(end($histories)->getCreateDate()->format('Y-m-d H:i:s'));
        $lastDate->setTimeZone(new DateTimeZone('UTC'));
        while ($count < $maxSize){
            $dummyDate = $lastDate->modify("-1 day");
            $labels[] = date_format($dummyDate, 'm月d日');
            $price[] = 0;
            $price_sale[] = 0;
            $price_other[] = 0;
            $count++;
        }
        $product_price = $this->productPriceRepository->find($priceId);
        return [
            'title' => $product_price->getProductClass()->formattedProductName().'(ID:'.$product_price->getId().')',
            'labels' => array_reverse($labels),
            'price' => array_reverse($price),
            'price_sale' => array_reverse($price_sale),
            'price_other' => array_reverse($price_other)
        ];
    }
    /**
     * get porduct Price History.
     *
     * @Route("/%eccube_admin_route%/price_history/{id}/history", requirements={"id" = "\d+"}, name="admin_product_price_history", methods={"GET"})
     *
     * @param Request $request
     *
     * @return Response
     */
    public function getProductPriceHistory(Request $request)
    {
        $scale = $request->query->get('scale');
        $result = $this->getProductPriceHistoryByPriceId($request->get('id'), $scale);
        return $this->json($result, 200);
    }

    /**
     * get porduct Price History.
     *
     * @Route("/%eccube_admin_route%/price_history_by_class/{id}/history/{rank}/", requirements={"id" = "\d+", "rank" = "\d+"}, name="admin_product_price_history_by_class", methods={"GET"})
     *
     * @param Request $request
     *
     * @return Response
     */
    public function getProductPriceHistoryByClass(Request $request)
    {
        $ProductPrices = $this->productPriceRepository->findBy(['ProductClass' => $request->get('id')]);
        $priceId = $ProductPrices[0]["id"];
        //中古
        if(count($ProductPrices) > 1){
            if($request->get('rank') == 2){
                $priceIds = array_filter($ProductPrices, function($v, $k){
                    return $v->getParentId() != null;
                }, ARRAY_FILTER_USE_BOTH);
                $ProductPrice = array_shift($priceIds);
                $priceId = $ProductPrice->getId();
            }
        }
        $scale = $request->query->get('scale');
        $result = $this->getProductPriceHistoryByPriceId($priceId, $scale);
        return $this->json($result, 200);
    }

    /**
     * getNotFinishOrderCount
     *
     * @Route("/%eccube_admin_route%/product_price/not_finish_order_count/{class_id}",name="admin_product_price_get_not_finish_order_count")
     *
     * @param Request $request
     * @param null $class_id
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getNotFinishOrderCount(Request $request,$class_id = null)
    {
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
         }
         $result = []; 
         try {
           if($class_id){
             $ProductClass = $this->productClassRepository->find($class_id);
             if($ProductClass){
               $isAllFinishFlag = $this->orderRepository->checkOrderStatusByProductClass($ProductClass);
               $result['isAllFinishFlag'] = $isAllFinishFlag; 
             }
           }
           return $this->json(array_merge(['status' => 'OK'], $result));
         } catch (\Exception $e) {
            log_error('予期しないエラー', [$e->getMessage()]);

            return $this->json(['status' => 'NG'], 500);
        }
     }

    private function filterProductResult($prices, $searchData){
        //販売額
        if($searchData['price_sale_start'] != null){
            $filter = $searchData['price_sale_start'];
            $prices = array_filter($prices, function($v, $k) use ($filter){
                return $v->getPriceSale() >= $filter;
            }, ARRAY_FILTER_USE_BOTH);
        }
        if($searchData['price_sale_end'] != null){
            $filter = $searchData['price_sale_end'];
            $prices = array_filter($prices, function($v, $k) use ($filter){
                return $v->getPriceSale() <= $filter;
            }, ARRAY_FILTER_USE_BOTH);
        }
        //買取額
        if($searchData['price_start'] != null){
            $filter = $searchData['price_start'];
            $prices = array_filter($prices, function($v, $k) use ($filter){
                return $v->getPrice() >= $filter;
            }, ARRAY_FILTER_USE_BOTH);
        }
        if($searchData['price_end'] != null){
            $filter = $searchData['price_end'];
            $prices = array_filter($prices, function($v, $k) use ($filter){
                return $v->getPrice() <= $filter;
            }, ARRAY_FILTER_USE_BOTH);
        }
        //販売と買取の差額
        if($searchData['price_diff_start'] != null){
            $filter = $searchData['price_diff_start'];
            $prices = array_filter($prices, function($v, $k) use ($filter){
                return $v->getPriceSale() - $v->getPrice() >= $filter;
            }, ARRAY_FILTER_USE_BOTH);
        }
        if($searchData['price_diff_end'] != null){
            $filter = $searchData['price_diff_end'];
            $prices = array_filter($prices, function($v, $k) use ($filter){
                return $v->getPriceSale() - $v->getPrice() <= $filter;
            }, ARRAY_FILTER_USE_BOTH);
        }
        //他社買取額
        if($searchData['price_other_start'] != null){
            $filter = $searchData['price_other_start'];
            $prices = array_filter($prices, function($v, $k) use ($filter){
                return $v->getPriceOther() >= $filter;
            }, ARRAY_FILTER_USE_BOTH);
        }
        if($searchData['price_other_end'] != null){
            $filter = $searchData['price_other_end'];
            $prices = array_filter($prices, function($v, $k) use ($filter){
                return $v->getPriceOther() <= $filter;
            }, ARRAY_FILTER_USE_BOTH);
        }
        //本社と他社の増減額
        if($searchData['price_updown_start'] != null){
            $filter = $searchData['price_updown_start'];
            $prices = array_filter($prices, function($v, $k) use ($filter){
                return $v->getPrice() - $v->getPriceOther() >= $filter;
            }, ARRAY_FILTER_USE_BOTH);
        }
        if($searchData['price_updown_end'] != null){
            $filter = $searchData['price_updown_end'];
            $prices = array_filter($prices, function($v, $k) use ($filter){
                return $v->getPrice() - $v->getPriceOther() <= $filter;
            }, ARRAY_FILTER_USE_BOTH);
        }
        //kakakuランキング
        if($searchData['sale_rank_start'] != null){
            $filter = $searchData['sale_rank_start'];
            $prices = array_filter($prices, function($v, $k) use ($filter){
                $rank = $v->getSaleRank() == '―' ? 999999 : $v->getSaleRank();
                $rank = $rank == '' ? 999999 : $rank;
                return $rank >= $filter && $v->getSaleRank() != null;
            }, ARRAY_FILTER_USE_BOTH);
        }
        if($searchData['sale_rank_end'] != null){
            $filter = $searchData['sale_rank_end'];
            $prices = array_filter($prices, function($v, $k) use ($filter){
                $rank = $v->getSaleRank() == '―' ? 999999 : $v->getSaleRank();
                $rank = $rank == '' ? 999999 : $rank;
                return $rank <= $filter && $v->getSaleRank() != null;
            }, ARRAY_FILTER_USE_BOTH);
        }
        //買取数
        if($searchData['stock_start'] != null){
            $filter = $searchData['stock_start'];
            $prices = array_filter($prices, function($v, $k) use ($filter){
                return $v->getProductClass()->getProductStock()->getStock() >= $filter;
            }, ARRAY_FILTER_USE_BOTH);
        }
        if($searchData['stock_end'] != null){
            $filter = $searchData['stock_end'];
            $prices = array_filter($prices, function($v, $k) use ($filter){
                return $v->getProductClass()->getProductStock()->getStock() <= $filter;
            }, ARRAY_FILTER_USE_BOTH);
        }
        //お気に入り数
        if($searchData['fav_start'] != null){
            $filter = $searchData['fav_start'];
            $prices = array_filter($prices, function($v, $k) use ($filter){
                return $v->getProductClass()->getProduct()->getCustomerFavoriteProductCount() >= $filter;
            }, ARRAY_FILTER_USE_BOTH);
        }
        if($searchData['fav_end'] != null){
            $filter = $searchData['fav_end'];
            $prices = array_filter($prices, function($v, $k) use ($filter){
                return $v->getProductClass()->getProduct()->getCustomerFavoriteProductCount() <= $filter;
            }, ARRAY_FILTER_USE_BOTH);
        }
        return $prices;
    }

    private function sortProductResult($prices, $searchData){
        if($searchData['sort_by']){
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case '商品名':
                    usort($prices, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getProductClass()->formattedProductName() > $b->getProductClass()->formattedProductName() ? -1 : 1;
                        }
                        return $a->getProductClass()->formattedProductName() < $b->getProductClass()->formattedProductName() ? -1 : 1;
                    });
                    break;
                case '新古':
                    usort($prices, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getParentId() > $b->getParentId() ? -1 : 1;
                        }
                        return $a->getParentId() < $b->getParentId() ? -1 : 1;
                    });
                    break;
                case '調整ルール':
                    usort($prices, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getProductPriceRule()->getName() > $b->getProductPriceRule()->getName() ? -1 : 1;
                        }
                        return $a->getProductPriceRule()->getName() < $b->getProductPriceRule()->getName() ? -1 : 1;
                    });
                    break;
                case '販売額':
                    usort($prices, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getPriceSale() > $b->getPriceSale() ? -1 : 1;
                        }
                        return $a->getPriceSale() < $b->getPriceSale() ? -1 : 1;
                    });
                    break;
                case 'ランキング':
                    usort($prices, function ($a, $b) use ($order_by)  {
                        $rankA = $a->getSaleRank() == '―' ? 999999 : $a->getSaleRank();
                        $rankA = $rankA == '' ? 999999 : $rankA;
                        $rankB = $b->getSaleRank() == '―' ? 999999 : $b->getSaleRank();
                        $rankB = $rankB == '' ? 999999 : $rankB;
                        if($order_by == "降順"){
                            return $rankA > $rankB ? -1 : 1;
                        }
                        return $rankA < $rankB ? -1 : 1;
                    });
                    break;
                case '差額':
                    usort($prices, function ($a, $b) use ($order_by)  {
                        if($order_by == "降順"){
                            return $a->getPriceSale() - $a->getPrice() > $b->getPriceSale() - $b->getPrice() ? -1 : 1;
                        }
                        return $a->getPriceSale() - $a->getPrice() < $b->getPriceSale() - $b->getPrice() ? -1 : 1;
                    });
                    break;
                case '差額率':
                    usort($prices, function ($a, $b) use ($order_by)  {
                        $rankA = $a->getPrice() > 0 ? ($a->getPriceSale() - $a->getPrice())/$a->getPrice() : 999999;
                        $rankB = $b->getPrice() > 0 ? ($b->getPriceSale() - $b->getPrice())/$b->getPrice() : 999999;
                        if($order_by == "降順"){
                            $rankA = $a->getPrice() > 0 ? ($a->getPriceSale() - $a->getPrice())/$a->getPrice() : -999999;
                            $rankB = $b->getPrice() > 0 ? ($b->getPriceSale() - $b->getPrice())/$b->getPrice() : -999999;
                            return  $rankA > $rankB ? -1 : 1;
                        }
                        return $rankA < $rankB ? -1 : 1;
                    });
                    break;
                case '買取額':
                    usort($prices, function ($a, $b) use ($order_by)  {
                        if($order_by == "降順"){
                            return $a->getPrice() > $b->getPrice() ? -1 : 1;
                        }
                        return $a->getPrice() < $b->getPrice() ? -1 : 1;
                    });
                    break;
                case '買取額(他社)':
                    usort($prices, function ($a, $b) use ($order_by)  {
                        if($order_by == "降順"){
                            return $a->getPriceOther() > $b->getPriceOther() ? -1 : 1;
                        }
                        return $a->getPriceOther() < $b->getPriceOther() ? -1 : 1;
                    });
                    break;
                case '増減額':
                    usort($prices, function ($a, $b) use ($order_by)  {
                        if($order_by == "降順"){
                            return $a->getPrice() - $a->getPriceOther() > $b->getPrice() - $b->getPriceOther() ? -1 : 1;
                        }
                        return $a->getPrice() - $a->getPriceOther() < $b->getPrice() - $b->getPriceOther() ? -1 : 1;
                    });
                    break;
                case '買取数':
                    usort($prices, function ($a, $b) use ($order_by)  {
                        //if($order_by == "降順"){
                        //    return $a->getProductClass()->getProductStock()->getStock() > $b->getProductClass()->getProductStock()->getStock() ? -1 : 1;
                        //}
                        //return $a->getProductClass()->getProductStock()->getStock() < $b->getProductClass()->getProductStock()->getStock() ? -1 : 1;
                        $s_a = ($a->getProductClass()->isStockUnlimited()) ? 0 : $a->getProductClass()->getStock() - $a->getProductClass()->getProductStock()->getStock();
                        $s_b = ($b->getProductClass()->isStockUnlimited()) ? 0 : $b->getProductClass()->getStock() - $b->getProductClass()->getProductStock()->getStock();
                        if($order_by == "降順"){
                            if($a->getProductClass()->isStockUnlimited()){
                                $s_a = -9999;
                            }
                            if($b->getProductClass()->isStockUnlimited()){
                                $s_b = -9999;
                            }
                            return $s_a > $s_b ? -1 : 1;
                        }
                        if($a->getProductClass()->isStockUnlimited()){
                             $s_a = 9999;
                        }
                        if($b->getProductClass()->isStockUnlimited()){
                             $s_b = 9999;
                        }
                        return $s_a < $s_b ? -1 : 1;
                    });
                    break;
                case '買取制限数':
                    usort($prices, function ($a, $b) use ($order_by)  {
                        $s_a = $a->getProductClass()->getStock();
                        $s_b = $b->getProductClass()->getStock();
                        if($order_by == "降順"){
                            if($a->getProductClass()->isStockUnlimited()){
                                $s_a = -9999;
                            }
                            if($b->getProductClass()->isStockUnlimited()){
                                $s_b = -9999;
                            }
                            return $s_a > $s_b ? -1 : 1;
                        }
                        if($a->getProductClass()->isStockUnlimited()){
                             $s_a = 9999;
                        }
                        if($b->getProductClass()->isStockUnlimited()){
                             $s_b = 9999;
                        }
                        return $s_a < $s_b ? -1 : 1;
                    });
                    break;
                case '会員限定数':
                    usort($prices, function ($a, $b) use ($order_by)  {
                        if($order_by == "降順"){
                            return $a->getProductClass()->getSaleLimit() > $b->getProductClass()->getSaleLimit() ? -1 : 1;
                        }
                        return $a->getProductClass()->getSaleLimit() < $b->getProductClass()->getSaleLimit() ? -1 : 1;
                    });
                    break;
                case '残在庫数':
                    usort($prices, function ($a, $b) use ($order_by)  {
                        if($order_by == "降順"){
                            return $a->getRemainingStockQuantity() > $b->getRemainingStockQuantity() ? -1 : 1;
                        }
                        return $a->getRemainingStockQuantity() < $b->getRemainingStockQuantity() ? -1 : 1;
                    });
                    break;
                case 'お気に入り数':
                    usort($prices, function ($a, $b) use ($order_by)  {
                        if($order_by == "降順"){
                            return $a->getProductClass()->getProduct()->getCustomerFavoriteProductCount() > $b->getProductClass()->getProduct()->getCustomerFavoriteProductCount() ? -1 : 1;
                        }
                        return $a->getProductClass()->getProduct()->getCustomerFavoriteProductCount() < $b->getProductClass()->getProduct()->getCustomerFavoriteProductCount() ? -1 : 1;
                    });
                    break;
            }
        }
        return $prices;
    }

    private function resetProductStock(Request $request)
    {
       try {
         $ProductStock = null;
         $ProductClass = null;
         if($stock_id = $request->get('stock_id')){
              $ProductStock = $this->productStockRepository->find($stock_id);
         }
         if($class_id = $request->get('class_id')){
              $ProductClass = $this->productClassRepository->find($class_id);
         }
         if(null != $ProductStock && null != $ProductClass){
              $ProductStockHistory = $this->copyProductStock($ProductStock,$ProductClass);
              $this->productStockHistoryRepository->save($ProductStockHistory);
              $ProductStock->setStock(0);
              $this->productStockRepository->save($ProductStock);
              $ProductClass->setStock(NULL);
              $ProductClass->setStockUnlimited(1);
              $this->entityManager->persist($ProductClass);
              $this->entityManager->flush();
         }
       } catch (\Exception $e) {
            log_error('予期しないエラー', [$e->getMessage()]);
       }
    }

    private function copyProductStock(ProductStock $ProductStock ,ProductClass $ProductClass)
    {
        $ProductStockHistory = new ProductStockHistory();
        $ProductStockHistory->setProductClass($ProductClass);
        $ProductStockHistory->setCreator($ProductStock->getCreator());
        $ProductStockHistory->setStock($ProductStock->getStock());
        $ProductStockHistory->setClassStock($ProductClass->getStock());
        $ProductStockHistory->setClassStockUnlimited($ProductClass->isStockUnlimited());
        return $ProductStockHistory;
    }
    
    /**
     * @Route("/%eccube_admin_route%/product_price/{id}/delete", requirements={"id" = "\d+"}, name="admin_product_price_delete", methods={"DELETE"})
     */
    public function delete(Request $request, $id, TranslatorInterface $translator)
    {
        $this->isTokenValid();
        log_info('商品価格削除開始', [$id]);

        $page_no = intval($this->session->get('eccube.admin.product.price.search.page_no'));
        $page_no = $page_no ? $page_no : Constant::ENABLED;

        $ProductPrice = $this->productPriceRepository->find($id);

        if (!$ProductPrice) {
            $this->deleteMessage();

            return $this->redirect($this->generateUrl('admin_product_price_page',
                    ['page_no' => $page_no]).'?resume='.Constant::ENABLED);
        }

        try {
            $ProductPrice = $this->productPriceRepository->updateVisible($ProductPrice);
            $this->addSuccess('admin.common.delete_complete', 'admin');
        } catch (ForeignKeyConstraintViolationException $e) {
            log_error('商品価格削除失敗', [$e], 'admin');

            $message = trans('admin.common.delete_error_foreign_key', ['%name%' => $ProductPrice->getId()]);
            $this->addError($message, 'admin');
        }

        log_info('商品価格削除完了', [$id]);

        $event = new EventArgs(
            [
                'ProductPrice' => $ProductPrice,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_PRICE_DELETE_COMPLETE, $event);

        return $this->redirect($this->generateUrl('admin_product_price_page',
                ['page_no' => $page_no]).'?resume='.Constant::ENABLED);
    }

    // INS-START CNC 2022/05/19
    /**
     * getPriceUpdate
     *
     * @Route("/%eccube_admin_route%/product_price/price_update", requirements={"id" = "\S+"}, name="admin_paying_update_price", methods={"PUT"})
     *
     * @param Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function PriceUpdate(Request $request)
    {
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
        }

        $productId = $request->get('id');

        $product = $this->productRepository->find($productId);

        $productCode = $product->getProductClasses()[0]['code'];

        $orderNos = [];
        $orderItems = $this->orderItemRepository->findBy(['Product' => $productId]);

        if ($orderItems) {
            foreach ($orderItems as $orderItem) {
                $order = $orderItem['order'];

                if ($order['order_no'] != null && $order['OrderStatus']['id'] == 1) {
                    // 価格連携情報存在チェック
                    $price_update = $this->priceUpdateRepository->findOneBy(['orderNo' => $orderItem['order']['order_no']]);

                    if (!$price_update) {
                        $price_update = new priceUpdate();

                        $price_update->setOrderNo($order['order_no']);

                        $price_update->setProductCode($productCode);

                        $price_update->setCreateUserName($this->getUser());

                        $price_update->setOrderUpdateDate($order['update_date']);

                        $price_update->setUpdateUserName($this->getUser());

                        $this->entityManager->persist($price_update);
                    } else {
                        if ($price_update->getOrderUpdateDate() != $order['update_date']) {

                            $price_update->setProductCode($productCode);

                            $price_update->setOrderUpdateDate($order['update_date']);

                            $price_update->setUpdateUserName($this->getUser());

                            $this->entityManager->persist($price_update);
                        } else {
                            if ($price_update->getProductCode() == null) {
                                $productCodeArray = $productCode;
                            } else {
                                $productCodeArray = $price_update->getProductCode().','.$productCode;
                            }

                            $price_update->setProductCode($productCodeArray);

                            $this->entityManager->persist($price_update);
                        }
                    }

                    $orderNoFlg = 0;
                    foreach ($orderNos as $orderNo) {
                        if ($orderNo['orderNo'] == $order['order_no']) {
                            $orderNoFlg = 1;
                        }
                    }

                    if ($orderNoFlg == 0) {
                        $orderNos[] = [
                            'orderNo' => $order['order_no'],
                        ];
                    }
                }
            }
            $this->entityManager->flush();
        }

        return $this->json(['orderNos' => $orderNos]);
    }
    // INS-END CNC 2022/05/19

    //INS-START CNC 2022/12/09 他社最低売価、残在庫数、予約数
    public function getSearchProductData($product)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();

        $sql = "
                SELECT
                    slpu.average_unit_price AS average_unit_price
                  , slpu.remaining_stock_quantity AS remaining_stock_quantity
                  , CASE WHEN s.state = '新品' THEN
                        CASE WHEN son2.sumqua IS NULL THEN
                            0
                        ELSE
                            son2.sumqua
                        END
                            +
                        CASE WHEN son4.sumqua IS NULL THEN
                            0
                        ELSE
                            son4.sumqua
                        END
                    ELSE
                        CASE WHEN son2.sumqua IS NULL THEN
                            0
                        ELSE
                            son2.sumqua
                        END
                    END AS reservation_quantity
                  , nr1.competitors_selling_price AS competitors_selling_price1
                  , nr2.competitors_selling_price AS competitors_selling_price2
                  , nr3.competitors_selling_price AS competitors_selling_price3
                  , nr4.competitors_selling_price AS competitors_selling_price4
                  , nr5.competitors_selling_price AS competitors_selling_price5
                FROM
                    dtb_stock_list_product_unit slpu
                INNER JOIN dtb_product_class pc
                ON  pc.product_code = slpu.product_code
                INNER JOIN dtb_product p
                ON  p.id = pc.product_id
                INNER JOIN dtb_product_category pcs
                ON  pcs.product_id = p.id
                INNER JOIN mtb_state s
                ON  s.id = slpu.state_id
                INNER JOIN dtb_category c
                ON  c.id = pcs.category_id
                LEFT JOIN (
                    SELECT
                        son1.product_id,
                        son1.product_code,
                        son1.conversion_after_state_id,
                        son1.sumqua
                    FROM
                        (
                            SELECT
                                dori.product_id,
                                dori.product_code,
                                dori.conversion_after_state_id,
                                SUM(dori.quantity) AS sumqua
                            FROM
                                dtb_order_item dori
                            INNER JOIN dtb_order dor ON dor.id = dori.order_id
                            AND dor.order_status_id = '9'
                            INNER JOIN dtb_shipping dsp ON dor.id = dsp.order_id
                            AND (
                                dsp.delivery_id = '3'
                                OR dsp.delivery_id = '4'
                            )
                            GROUP BY
                                dori.product_id,
                                dori.product_code,
                                dori.conversion_after_state_id
                        ) son1
                ) son2 ON slpu.product_id = son2.product_id
                AND slpu.product_code = son2.product_code
                AND s.id = son2.conversion_after_state_id
                LEFT JOIN (
                    SELECT
                        son3.product_id,
                        son3.product_code,
                        son3.conversion_after_state_id,
                        son3.sumqua
                    FROM
                        (
                            SELECT
                                dori2.product_id,
                                dori2.product_code,
                                dori2.conversion_after_state_id,
                                SUM(dori2.quantity) AS sumqua
                            FROM
                                dtb_order_item dori2
                            INNER JOIN dtb_order dor2 ON dor2.id = dori2.order_id
                            AND dor2.order_status_id = '9'
                            INNER JOIN dtb_shipping dsp2 ON dor2.id = dsp2.order_id
                            AND (
                                dsp2.delivery_id = '3'
                                OR dsp2.delivery_id = '4'
                            )
                            GROUP BY
                                dori2.product_id,
                                dori2.product_code,
                                dori2.conversion_after_state_id
                        ) son3
                    WHERE
                        son3.conversion_after_state_id IS NULL
                ) son4 ON slpu.product_id = son4.product_id
                AND slpu.product_code = son4.product_code
                LEFT JOIN mtb_netshopAI_product_info npi
                ON  npi.product_code = slpu.product_code
                AND npi.state_id = s.id
                LEFT JOIN dtb_netshopAI_result nr1
                ON  nr1.ai_product_id = npi.id
                AND nr1.shop_id = '1'
                LEFT JOIN dtb_netshopAI_result nr2
                ON  nr2.ai_product_id = npi.id
                AND nr2.shop_id = '2'
                LEFT JOIN dtb_netshopAI_result nr3
                ON  nr3.ai_product_id = npi.id
                AND nr3.shop_id = '5'
                LEFT JOIN dtb_netshopAI_result nr4
                ON  nr4.ai_product_id = npi.id
                AND nr4.shop_id = '3'
                LEFT JOIN dtb_netshopAI_result nr5
                ON  nr5.ai_product_id = npi.id
                AND nr5.shop_id = '4'
                WHERE
                    s.state = '新品'
                AND pcs.category_sub_flag = '0'
                AND c.hierarchy = '1'
                AND slpu.product_code = '".$product."'"
        ;

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }
    //INS-END CNC 2022/12/09 他社最低売価、残在庫数、予約数
}
