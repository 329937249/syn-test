<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Product;

use Doctrine\ORM\NoResultException;
use Eccube\Controller\AbstractController;
use Eccube\Entity\ClassName;
use Eccube\Entity\ProductPrice;
use Eccube\Entity\Master\ProductPriceRule;
use Eccube\Entity\ProductPriceRuleset;
use Eccube\Form\Type\Master\ProductPriceRuleType;
use Eccube\Form\Type\Admin\ProductPriceRulesetsType;
use Eccube\Form\Type\Admin\ProductPriceRulesetType;
use Eccube\Form\Type\Admin\ProductPriceRulesetEditType;
use Eccube\Repository\Master\ProductPriceRuleRepository;
use Eccube\Repository\ProductPriceRepository;
use Eccube\Repository\ProductPriceRulesetRepository;
use Eccube\Util\CacheUtil;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;

class ProductPriceRulesetController extends AbstractController
{
    /**
     * @var ProductPriceRepository
     */
    protected $productPriceRepository;

    /**
     * @var ProductPriceRulesetRepository
     */
    protected $productPriceRulesetRepository;

    /**
     * @var ProductPriceRuleRepository
     */
    protected $productPriceRuleRepository;

    /**
     * ProductPriceRulesetController constructor.
     *
     * @param ProductPriceRepository $productPriceRepository
     * @param ProductPriceRulesetRepository $productPriceRulesetRepository
     * @param ProductPriceRuleRepository $productPriceRuleRepository
     */
    public function __construct(
        ProductPriceRepository $productPriceRepository,
        ProductPriceRulesetRepository $productPriceRulesetRepository,
        ProductPriceRuleRepository $productPriceRuleRepository
    ) {
        $this->productPriceRepository = $productPriceRepository;
        $this->productPriceRulesetRepository = $productPriceRulesetRepository;
        $this->productPriceRuleRepository = $productPriceRuleRepository;
    }

    /**
     * 商品ルール設定の初期表示
     *
     * @Route("/%eccube_admin_route%/product/product/price_ruleset/{id}", requirements={"id" = "\d+"}, name="admin_product_product_price_ruleset")
     * @Template("@admin/Product/product_price_ruleset.twig")
     */
    public function index(Request $request, $id)
    {
        log_info("index", [$id]);
        // find ProductPrice
        $ProductPrice = $this->productPriceRepository->find($id);
        if (!$ProductPrice) {
            throw new NotFoundHttpException();
        }
        $ProductPriceRule = $ProductPrice->getProductPriceRule();

        // ProductPriceRulesets
        $ProductPriceRulesets = $ProductPrice->getProductPriceRulesets();
        
        // create TargetProductPriceRuleset
        $TargetProductPriceRuleset = $ProductPrice->getDefaultProductPriceRuleset();

        if ($TargetProductPriceRuleset !== null) {
            log_info("TargetProductPriceRuleset is Existed.");
        } else {
            log_info("create TargetProductPriceRuleset");
            $TargetProductPriceRuleset = $this->createDefaualtPriceRuleset($ProductPrice);

            $ProductPrice->addProductPriceRuleset($TargetProductPriceRuleset);
        }
        $TargetProductPriceRuleset->setPriceSaleUrl($ProductPrice->getPriceDefaultUrl());

        // create NewProductPriceRuleset
        $NewProductPriceRuleset = $this->createNewPriceRulesetObject($ProductPrice, $TargetProductPriceRuleset);

        $form = $this->createPriceRulesetForm($TargetProductPriceRuleset, $NewProductPriceRuleset, $ProductPriceRulesets);

        return [
            'ProductPrice' => $ProductPrice,
            'TargetProductPriceRuleset' => $TargetProductPriceRuleset,
            'NewProductPriceRuleset' => $NewProductPriceRuleset,
            'ProductPriceRulesets' => $ProductPriceRulesets,
            'form' => $form->createView(),
        ];
    }

    /**
     * 商品価格範囲の登録
     *
     * @Route("/%eccube_admin_route%/product/product/price_ruleset/{id}/save", requirements={"id" = "\d+"}, name="admin_product_product_price_ruleset_save", methods={"POST"})
     * @Template("@admin/Product/product_price_ruleset.twig")
     */
    public function save_rule(Request $request, $id)
    {
        log_info("index", ['save_rule', $id]);

        // find ProductPrice
        $ProductPrice = $this->productPriceRepository->find($id);
        if (!$ProductPrice) {
            throw new NotFoundHttpException();
        }

        $ProductPriceRule = $ProductPrice->getProductPriceRule();

        // ProductPriceRulesets
        $ProductPriceRulesets = $ProductPrice->getProductPriceRulesets();
        
        // create TargetProductPriceRuleset
        $TargetProductPriceRuleset = $ProductPrice->getDefaultProductPriceRuleset();

        if ($TargetProductPriceRuleset !== null) {
            log_info("TargetProductPriceRuleset is Existed.");
        } else {
            log_info("create TargetProductPriceRuleset");
            $TargetProductPriceRuleset = $this->createDefaualtPriceRuleset($ProductPrice);

            $ProductPrice->addProductPriceRuleset($TargetProductPriceRuleset);
        }
        $TargetProductPriceRuleset->setPriceSaleUrl($ProductPrice->getPriceDefaultUrl());

        $form = $this->createPriceRulesetForm($TargetProductPriceRuleset);
        $form->handleRequest($request);

        // 価格範囲保存
        log_info("isSubmitted", [$form->isSubmitted()]);
        log_info("isValid", [$form->isValid()]);
        if ($form->isSubmitted() && $form->isValid()) {
            $Data = $form['price_ruleset_main']->getData();
            log_info("data->PriceMin,Max,Unit", [$Data->getPriceMin(),$Data->getPriceMax(),$Data->getPriceUnit()]);
            log_info("data->getPriceSaleUrl", [$Data->getPriceSaleUrl()]);

            // DefaultProductPriceRuleset
            $this->entityManager->persist($Data);
            $this->entityManager->flush();
            log_info("data->PriceMin,Max,Unit", [$Data->getPriceMin(),$Data->getPriceMax(),$Data->getPriceUnit()]);

            // ProductPriceRulesets
            $ProductPriceRulesets = $ProductPrice->getProductPriceRulesets();
            if ($ProductPrice->hasProductPriceRulesets()) {
                foreach ($ProductPriceRulesets as $ProductPriceRuleset) {
                    $ProductPriceRuleset->setProductPriceRule($Data->getProductPriceRule());
                    $ProductPriceRuleset->setPriceMin($Data->getPriceMin());
                    $ProductPriceRuleset->setPriceMax($Data->getPriceMax());
                    $ProductPriceRuleset->setPriceUnit($Data->getPriceUnit());
                    $this->entityManager->persist($ProductPriceRuleset);
                }
            }
            $this->entityManager->flush();

            // ProductPrice
            $ProductPrice->setPrice($ProductPrice->getPrice());
            $ProductPrice->setMember($this->getUser());
            $ProductPrice->setMemberUpdateDate(new \DateTime());
            $ProductPrice->setProductPriceRule($Data->getProductPriceRule());
            $ProductPrice->setPriceDefaultUrl($Data->getPriceSaleUrl());
            $this->entityManager->persist($ProductPrice);
            $this->entityManager->flush();

            $ProductPriceRulesets = $ProductPrice->getProductPriceRulesets();
        }

        // create NewProductPriceRuleset
        log_info("create NewProductPriceRuleset");
        $NewProductPriceRuleset = $this->createNewPriceRulesetObject($ProductPrice, $TargetProductPriceRuleset);

        $form = $this->createPriceRulesetForm($TargetProductPriceRuleset, $NewProductPriceRuleset, $ProductPriceRulesets);

        return [
            'ProductPrice' => $ProductPrice,
            'TargetProductPriceRuleset' => $TargetProductPriceRuleset,
            'NewProductPriceRuleset' => $NewProductPriceRuleset,
            'ProductPriceRulesets' => $ProductPriceRulesets,
            'form' => $form->createView(),
        ];
    }

    /**
     * 商品ルール設定の登録
     *
     * @Route("/%eccube_admin_route%/product/product/price_ruleset/{id}/new", requirements={"id" = "\d+"}, name="admin_product_product_price_ruleset_new", methods={"POST"})
     * @Template("@admin/Product/product_price_ruleset.twig")
     */
    public function create_ruleset(Request $request, $id)
    {
        log_info("index", ['create_ruleset', $id]);

        // find ProductPrice
        $ProductPrice = $this->productPriceRepository->find($id);
        if (!$ProductPrice) {
            throw new NotFoundHttpException();
        }
        $ProductPriceRule = $ProductPrice->getProductPriceRule();
        log_info("ProductPriceRule",[$ProductPrice->getProductPriceRule()]);

        // ProductPriceRulesets
        $ProductPriceRulesets = $ProductPrice->getProductPriceRulesets();
        log_info("ProductPriceRulesets",[$ProductPriceRulesets->count()]);
        
        // create TargetProductPriceRuleset
        $TargetProductPriceRuleset = $ProductPrice->getDefaultProductPriceRuleset();
        log_info("TargetProductPriceRuleset",[$TargetProductPriceRuleset]);

        if ($TargetProductPriceRuleset !== null) {
            log_info("TargetProductPriceRuleset is Existed.");
        } else {
            log_info("create TargetProductPriceRuleset");
            $TargetProductPriceRuleset = $this->createDefaualtPriceRuleset($ProductPrice);
            $ProductPrice->addProductPriceRuleset($TargetProductPriceRuleset);
        }
        $TargetProductPriceRuleset->setPriceSaleUrl($ProductPrice->getPriceDefaultUrl());

        // create NewProductPriceRuleset
        log_info("NewProductPriceRuleset");
        $NewProductPriceRuleset = new ProductPriceRuleset();
        $NewProductPriceRuleset->setProductPrice($ProductPrice);
        $NewProductPriceRuleset->setRuleDefault(false);
        $NewProductPriceRuleset->setVisible(true);

        $form = $this->createPriceRulesetForm(null, $NewProductPriceRuleset);
        $form->handleRequest($request);

        // 価格ルール新規
        log_info("isSubmitted", [$form->isSubmitted()]);
        log_info("isValid", [$form->isValid()]);
        if ($form->isSubmitted() && $form->isValid()) {
            $Data = $form['price_ruleset_new']->getData();
            
            $Data->setProductPriceRule($ProductPriceRule);
            $Data->setPriceMin($TargetProductPriceRuleset->getPriceMin());
            $Data->setPriceMax($TargetProductPriceRuleset->getPriceMax());
            $Data->setPriceUnit($TargetProductPriceRuleset->getPriceUnit());
            $this->entityManager->persist($Data);
            $this->entityManager->flush();

            $ProductPrice->setMember($this->getUser());
            $ProductPrice->setMemberUpdateDate(new \DateTime());
            $this->entityManager->persist($ProductPrice);
            $this->entityManager->flush();
            $ProductPrice->addProductPriceRuleset($Data);
            $ProductPriceRulesets = $ProductPrice->getProductPriceRulesets();
    
        }

        // create NewProductPriceRuleset
        log_info("TargetProductPriceRuleset#new ProductPriceRule");
        $NewProductPriceRuleset = $this->createNewPriceRulesetObject($ProductPrice, $TargetProductPriceRuleset);

        $form = $this->createPriceRulesetForm($TargetProductPriceRuleset, $NewProductPriceRuleset, $ProductPriceRulesets);

        return [
            'ProductPrice' => $ProductPrice,
            'TargetProductPriceRuleset' => $TargetProductPriceRuleset,
            'NewProductPriceRuleset' => $NewProductPriceRuleset,
            'ProductPriceRulesets' => $ProductPriceRulesets,
            'form' => $form->createView(),
        ];
    }

    /**
     * 商品ルール設定の編集・削除
     *
     * @Route("/%eccube_admin_route%/product/product/price_ruleset/{id}/edit", requirements={"id" = "\d+"}, name="admin_product_product_price_ruleset_upd", methods={"POST", "DELETE"})
     * @Template("@admin/Product/product_price_ruleset.twig")
     */
    public function update_ruleset(Request $request, $id)
    {
        log_info("index", ['update_ruleset', $id]);

        // find ProductPrice
        $ProductPrice = $this->productPriceRepository->find($id);
        if (!$ProductPrice) {
            throw new NotFoundHttpException();
        }
        $ProductPriceRule = $ProductPrice->getProductPriceRule();
        log_info("ProductPriceRule",[$ProductPrice->getProductPriceRule()]);

        // ProductPriceRulesets
        $ProductPriceRulesets = $ProductPrice->getProductPriceRulesets();
        log_info("ProductPriceRulesets",[$ProductPriceRulesets->count()]);
        
        // create TargetProductPriceRuleset
        $TargetProductPriceRuleset = $ProductPrice->getDefaultProductPriceRuleset();
        log_info("TargetProductPriceRuleset",[$TargetProductPriceRuleset]);

        if ($TargetProductPriceRuleset !== null) {
            log_info("TargetProductPriceRuleset is Existed.");
        } else {
            log_info("create TargetProductPriceRuleset");
            $TargetProductPriceRuleset = $this->createDefaualtPriceRuleset($ProductPrice);
            $ProductPrice->addProductPriceRuleset($TargetProductPriceRuleset);
        }
        $TargetProductPriceRuleset->setPriceSaleUrl($ProductPrice->getPriceDefaultUrl());

        $ruleid = $request->get('ruleid');
        log_info("ruleid", [$ruleid]);

        // 価格ルール削除
        if ($request->getMethod() === 'DELETE') {
            log_info("delete", [$ruleid]);
            $ProductPrice->setMember($this->getUser());
            $ProductPrice->setMemberUpdateDate(new \DateTime());
            $this->entityManager->persist($ProductPrice);
            $this->entityManager->flush();

            foreach ($ProductPriceRulesets as $Data)  {
                log_info("filter", [$Data->getId()]);
                if ($Data->getId() == $ruleid) {
                    log_info("delete start", [$ruleid]);
                    $ProductPrice->removeProductPriceRuleset($Data);
                    $this->productPriceRulesetRepository->delete($Data);
                    log_info("delete end", [$ruleid]);

                    $ProductPriceRulesets = $ProductPrice->getProductPriceRulesets();
                    log_info("ProductPriceRulesets",[$ProductPriceRulesets->count()]);
                    break;
                }
            }
        } else if ($request->getMethod() === 'POST') {

            // create NewProductPriceRuleset
            // log_info("TargetProductPriceRuleset#new ProductPriceRule");
            // $NewProductPriceRuleset = new ProductPriceRuleset();
            // $NewProductPriceRuleset->setProductPrice($ProductPrice);
            // $NewProductPriceRuleset->setRuleDefault(false);
            // $NewProductPriceRuleset->setVisible(true);

            $form = $this->createPriceRulesetForm(null, null, $ProductPriceRulesets);
            $form->handleRequest($request);
            
            // 価格ルール編集
            log_info("isSubmitted", [$form->isSubmitted()]);
            log_info("isValid", [$form->isValid()]);
            if ($form->isSubmitted() && $form->isValid()) {
                $Datas = $form['price_ruleset_list']->getData();

                foreach ($Datas as $Data)  {
                    log_info("Data->id", [$Data->getId(), $Data->getPriceMin(), $Data->getStockMin(), $Data->getPriceAdjust()]);
                    if ($Data->getId() == $ruleid) {
                        log_info("update", [$ruleid]);
                        $Data->setProductPriceRule($TargetProductPriceRuleset->getProductPriceRule());
                        $Data->setPriceMin($TargetProductPriceRuleset->getPriceMin());
                        $Data->setPriceMax($TargetProductPriceRuleset->getPriceMax());
                        $Data->setPriceUnit($TargetProductPriceRuleset->getPriceUnit());
                        
                        $this->entityManager->persist($Data);
                        $this->entityManager->flush();
                        $ProductPrice->setMember($this->getUser());
                        $ProductPrice->setMemberUpdateDate(new \DateTime());
                        $this->entityManager->persist($ProductPrice);
                        $this->entityManager->flush();
                        log_info("Data->id", [$Data->getId(), $Data->getPriceMin(), $Data->getStockMin(), $Data->getPriceAdjust()]);
                        break;
                    }
                }
                
                $ProductPriceRulesets = $ProductPrice->getProductPriceRulesets();
                log_info("ProductPriceRulesets",[$ProductPriceRulesets->count()]);
        
            }
        }

        // create NewProductPriceRuleset
        log_info("TargetProductPriceRuleset#new ProductPriceRule");
        $NewProductPriceRuleset = $this->createNewPriceRulesetObject($ProductPrice, $TargetProductPriceRuleset);

        $form = $this->createPriceRulesetForm($TargetProductPriceRuleset, $NewProductPriceRuleset, $ProductPriceRulesets);
        
        return [
            'ProductPrice' => $ProductPrice,
            'TargetProductPriceRuleset' => $TargetProductPriceRuleset,
            'NewProductPriceRuleset' => $NewProductPriceRuleset,
            'ProductPriceRulesets' => $ProductPriceRulesets,
            'form' => $form->createView(),
        ];
    }


    /**
     * 商品価格ルール登録フォームを生成する.
     *
     * @param ProductPriceRuleset|null $ProductPriceRuleset
     * @param ProductPriceRuleset|null $ProductPriceRulesetNew
     * @param array $ProductPriceRulesets
     * @param array $options
     *
     * @return \Symfony\Component\Form\FormInterface
     */
    protected function createPriceRulesetForm(
        ProductPriceRuleset $ProductPriceRuleset = null,
        ProductPriceRuleset $ProductPriceRulesetNew = null,
        $ProductPriceRulesets = [],
        array $options = []
    ) {
        //$options = array_merge(['csrf_protection' => false], $options);
        $builder = $this->formFactory->createBuilder(ProductPriceRulesetsType::class, [
            'price_ruleset_main' => $ProductPriceRuleset,
            'price_ruleset_new' => $ProductPriceRulesetNew,
            'price_ruleset_list' => $ProductPriceRulesets,
        ], $options);

        return $builder->getForm();
    }

    /**
     * 商品価格ルール（デフォルト）を生成する.
     *
     * @param ProductPrice|null $ProductPrice
     * 
     * @return ProductPriceRuleset
     */
    protected function createDefaualtPriceRuleset(
        ProductPrice $ProductPrice = null
    ) {
        log_info("createDefaualtPriceRuleset start");
        $TargetProductPriceRuleset = new ProductPriceRuleset();
        //$ProductPriceRule = $this->productPriceRuleRepository->find(ProductPriceRule::RULE_DEFAULT);
        $TargetProductPriceRuleset->setProductPrice($ProductPrice);
        $TargetProductPriceRuleset->setProductPriceRule($ProductPrice->getProductPriceRule());
        $TargetProductPriceRuleset->setRuleDefault(true);
        $TargetProductPriceRuleset->setVisible(true);
        log_info("createDefaualtPriceRuleset->id",[$TargetProductPriceRuleset->getId()]);
        $this->entityManager->persist($TargetProductPriceRuleset);
        $this->entityManager->flush();
        log_info("createDefaualtPriceRuleset end->id",[$TargetProductPriceRuleset->getId()]);

        return $TargetProductPriceRuleset;

    }

    /**
     * 商品価格ルール（デフォルト）を生成する.
     *
     * @param ProductPrice|null $ProductPrice
     * @param ProductPriceRuleset|null $TargetProductPriceRuleset
     * 
     * @return ProductPriceRuleset
     */
    protected function createNewPriceRulesetObject(
        ProductPrice $ProductPrice = null,
        ProductPriceRuleset $TargetProductPriceRuleset = null
    ) {
        $NewProductPriceRuleset = new ProductPriceRuleset();
        $NewProductPriceRuleset->setProductPrice($ProductPrice);
        $NewProductPriceRuleset->setProductPriceRule($ProductPrice->getProductPriceRule());
        $NewProductPriceRuleset->setRuleDefault(false);
        $NewProductPriceRuleset->setVisible(true);
        $NewProductPriceRuleset->setPriceMin($TargetProductPriceRuleset->getPriceMin());
        $NewProductPriceRuleset->setPriceMax($TargetProductPriceRuleset->getPriceMax());
        $NewProductPriceRuleset->setPriceUnit($TargetProductPriceRuleset->getPriceUnit());

        return $NewProductPriceRuleset;

    }

}
