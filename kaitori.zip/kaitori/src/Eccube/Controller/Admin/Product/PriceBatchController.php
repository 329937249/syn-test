<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Product;

use Eccube\Entity\ProductSearchExt;
use Eccube\Controller\AbstractController;
use Eccube\Form\Type\Admin\SearchProductForPriceType;
use Eccube\Form\Type\Admin\ProductSearchOrgType;
use Eccube\Form\Type\Admin\ProductSearchCategoryType;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\ProductPriceRepository;
use Eccube\Repository\ProductSearchExtRepository;
use Eccube\Repository\ProductSearchOrgRepository;
use Eccube\Repository\ProductSearchCategoryRepository;
use Eccube\Repository\ProductSearchMatchHistoryRepository;
use Eccube\Repository\BatchRepository;
use Eccube\Util\FormUtil;
use Eccube\Util\CacheUtil;
use Knp\Component\Pager\Paginator;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class PriceBatchController extends AbstractController
{
    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var ProductPriceRepository
     */
    protected $productPriceRepository;

    /**
     * @var ProductSearchExtRepository
     */
    protected $productSearchExtRepository;

    /**
     * @var ProductSearchOrgRepository
     */
    protected $productSearchOrgRepository;

    /**
     * @var ProductSearchCategoryRepository
     */
    protected $productSearchCategoryRepository;

    /**
     * @var ProductSearchMatchHistoryRepository
     */
    protected $productSearchMatchHistoryRepository;
    
    /**
     * @var BatchRepository
     */
    protected $batchRepository;
    
    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;

    /**
     * ProductPriceController constructor.
     *
     * @param PageMaxRepository $pageMaxRepository
     * @param ProductPriceRepository $productPriceRepository
     * @param ProductSearchExtRepository $productPriceExtRepository
     * @param ProductSearchOrgRepository $productSearchOrgRepository
     * @param ProductSearchCategoryRepository $productSearchCategoryRepository
     * @param ProductSearchMatchHistoryRepository $productSearchMatchHistoryRepository
     * @param BatchRepository $batchRepository
     */
    public function __construct(
        PageMaxRepository $pageMaxRepository,
        CategoryRepository $categoryRepository,
        ProductPriceRepository $productPriceRepository,
        ProductSearchExtRepository $productSearchExtRepository,
        ProductSearchOrgRepository $productSearchOrgRepository,
        ProductSearchCategoryRepository $productSearchCategoryRepository,
        ProductSearchMatchHistoryRepository $productSearchMatchHistoryRepository,
        BatchRepository $batchRepository
    ) {
        $this->pageMaxRepository = $pageMaxRepository;
        $this->categoryRepository = $categoryRepository;
        $this->productPriceRepository = $productPriceRepository;
        $this->productSearchExtRepository = $productSearchExtRepository;
        $this->productSearchOrgRepository = $productSearchOrgRepository;
        $this->productSearchCategoryRepository = $productSearchCategoryRepository;
        $this->productSearchMatchHistoryRepository = $productSearchMatchHistoryRepository;
        $this->batchRepository = $batchRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/price_batch", name="admin_price_batch")
     * @Route("/%eccube_admin_route%/price_batch/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_price_batch_page")
     * @Template("@admin/Product/product_price_batch.twig")
     */
    public function index(Request $request, $page_no = null, Paginator $paginator)
    {        
        $builder = $this->formFactory
            ->createBuilder(SearchProductForPriceType::class);
            
        $searchForm = $builder->getForm();

        /**
         * ページの表示件数は, 以下の順に優先される.
         * - リクエストパラメータ
         * - セッション
         * - デフォルト値
         * また, セッションに保存する際は mtb_page_maxと照合し, 一致した場合のみ保存する.
         **/
        $page_count = $this->session->get('eccube.admin.product.price.batch.search.page_count',
            $this->eccubeConfig->get('eccube_default_page_count'));

        $page_count_param = (int) $request->get('page_count');
        $pageMaxis = $this->pageMaxRepository->findAll();

        if ($page_count_param) {
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.admin.product.price.batch.search.page_count', $page_count);
                    break;
                }
            }
        }

        if ('POST' === $request->getMethod()) {
            log_info("POST");
            $searchForm->handleRequest($request);

            if ($searchForm->isValid()) {
                /**
                 * 検索が実行された場合は, セッションに検索条件を保存する.
                 * ページ番号は最初のページ番号に初期化する.
                 */
                $page_no = 1;
                $searchData = $searchForm->getData();

                log_info("viewData:", [FormUtil::getViewData($searchForm)]);
                log_info("searchData:", [$searchData]);

                // 検索条件, ページ番号をセッションに保持.
                $this->session->set('eccube.admin.product.price.batch.search', FormUtil::getViewData($searchForm));
                $this->session->set('eccube.admin.product.price.batch.search.page_no', $page_no);
            } else {
                // 検索エラーの際は, 詳細検索枠を開いてエラー表示する.
                return [
                    'searchForm' => $searchForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $page_count,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                log_info("resume");
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.admin.product.price.batch.search.page_no', (int) $page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.admin.product.price.batch.search.page_no', 1);
                }
                $viewData = $this->session->get('eccube.admin.product.price.batch.search', []);
                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
            } else {
                log_info("init");
                /**
                 * 初期表示の場合.
                 */
                $page_no = 1;

                // main category
                $categories = $this->categoryRepository->getList(null, false);
                $mainCategory = null;
                foreach($categories as $Category) {
                    if ($Category && ($Category->getHierarchy() == 1) ) {
                        $mainCategory = $Category;
                        break;
                    }
                }

                // submit default value
                $viewData = FormUtil::getViewData($searchForm);
                if ($mainCategory) {
                    $viewData['main_category_id'] = $mainCategory->getId();
                }
                log_info("viewData:", [$viewData]);

                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
                if ($mainCategory) {
                    $searchData['main_category_id'] = $mainCategory;
                }
                log_info("searchData:", [$searchData]);

                // セッション中の検索条件, ページ番号を初期化.
                $this->session->set('eccube.admin.product.price.batch.search', $viewData);
                $this->session->set('eccube.admin.product.price.batch.search.page_no', $page_no);
            }
        }

        $qb = $this->productPriceRepository->getQueryBuilderBySearchDataForAdmin($searchData);
        $prices = $qb->getQuery()->getResult();

        // get warn price
        $prices_warn = [];
        $prices_normal = [];
        foreach($prices as $price) {
            if ($price->isPriceValid() == false) {
                $prices_warn[] = $price;
            } else {
                $prices_normal[] = $price;
            }
        }
        //add normal after warn 
        foreach($prices_normal as $normal) {
            $prices_warn[] = $normal;
        }


        //pagination
        $pagination = $paginator->paginate(
            $prices_warn,
            $page_no,
            $page_count
        );

        //add search ext data
        $searchExt = $this->productSearchExtRepository->findAll();
        foreach($pagination as $price){
            $filter = $price->getProductClass()->getId();
            $extSet = array_filter($searchExt, function($v, $k) use ($filter){
                return $v->getProductClassId() == $filter;
            }, ARRAY_FILTER_USE_BOTH);
            $arr = [];
            foreach($extSet as $ext){
                $arr[$ext->getOrgCode()] = $ext;
            }
            $price->setProductSearchExt($arr);
        }

        return [
            'searchForm' => $searchForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'has_errors' => false,
        ];
    }

    private function curlElasticsearch($url, $data){
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
        $response = curl_exec($curl);
        // curlの処理を終了
        curl_close($curl);
        return json_decode($response);
    }

    /**
     * @Route("/%eccube_admin_route%/price_batch_search", name="admin_price_batch_search", methods={"GET"})
     * @Template("@admin/Product/product_price_search.twig")
     */
    public function priceBatchSearch(Request $request)
    {
        // curlの処理を始める合図
        $query = $request->get("name");
        $org_code = $request->get("org_code");
        $sele_type = $request->get("sale_type");
        $score = $request->get("score");

        if(!$org_code || !$sele_type){
            throw new BadRequestHttpException();
        }

        $org_list = $this->productSearchOrgRepository->findAll();

        $org = array_filter($org_list, function($v, $k) use ($org_code){
            return $v->getOrgCode() == $org_code;
        }, ARRAY_FILTER_USE_BOTH);

        if(count($org) == 0){
            throw new NotFoundHttpException();
        }

        $category_list = $this->productSearchCategoryRepository->findBy(['SaleType' => $sele_type, 'org_code' => $org_code]);

        $org_info = array_shift($org);

        $url = "http://172.31.32.250:9200/".$org_code."_0". $sele_type ."*/_search";
        $code = $request->get("jancode");
        if($code){
            $data = array(
                "size" => 10,
                "query" => array (
                    "match" => array (
                        "JAN" => $code
                    )
                )
            );
            $result = $this->curlElasticsearch($url, $data);
            if($result->hits->total->value > 0){
                //foreach($result->hits->total->value as )
                return [
                    'score' => $score,
                    'org_info' => $org_info,
                    'match_by' => $code,
                    'result' => $result,
                ];
            }
        }
        
        $data = array(
            "size" => 10,
            "query" => array (
                "match" => array (
                    "商品名" => $query
                )
            )
        );
        $result = $this->curlElasticsearch($url, $data);
        // foreach($result->hits->hits as $item){
        //     $index = $item->_index;
        //     $min_score = array_filter($category_list, function($v, $k) use ($index){
        //         return $v->getOrgCode() . "_" . $v->getOrgCategoryCode() == $index;
        //     }, ARRAY_FILTER_USE_BOTH);
        //     if(count($min_score) > 0){
        //         $item->min_score = array_shift($min_score)->getMinScore();
        //     }
        // }
        return [
            'score' => $score,
            'org_info' => $org_info,
            'match_by' => $query,
            'result' => $result,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/price_batch_save", name="admin_price_batch_save", methods={"POST"})
     */
    public function priceBatchSave(Request $request)
    {
        if (!$request->isXmlHttpRequest()) {
            throw new BadRequestHttpException();
        }
        $json = json_decode($request->getContent(), true);
        $org_list = $this->productSearchOrgRepository->findAll();
        $ext = $json["ext"];
        foreach($org_list as $org) {
            if (array_key_exists('id' . $org->getOrgCode(), $ext)) {
                //変更
                $pe = $this->productSearchExtRepository->find($ext['id' . $org->getOrgCode()]);
                if($pe){
                    if(array_key_exists('code' . $org->getOrgCode(), $ext)){
                        $pe->setKakakuCategoryCode(trim($ext['code' . $org->getOrgCode()]));
                    }
                    if(array_key_exists('name' . $org->getOrgCode(), $ext)){
                        $pe->setOrgSearchName(trim($ext['name' . $org->getOrgCode()]));
                    }
                    if(array_key_exists('score' . $org->getOrgCode(), $ext)){
                        $pe->setMinScore(trim($ext['score' . $org->getOrgCode()]));
                    }
                    $this->productSearchExtRepository->save($pe);
                }
                continue;
            }
            //新規
            $pe = new ProductSearchExt();
            $pe->setOrgCode($org->getOrgCode());
            $pe->setProductClassId($json["pcid"]);
            $pe->setProductName($json["name"]);

            //code 新規
            if (array_key_exists('code' . $org->getOrgCode(), $ext)) {
                $pe->setKakakuCategoryCode(trim($ext['code' . $org->getOrgCode()]));
                if(array_key_exists('name' . $org->getOrgCode(), $ext)){
                    $pe->setOrgSearchName(trim($ext['name' . $org->getOrgCode()]));
                }
                $this->productSearchExtRepository->save($pe);
                continue;
            }
            
            //name 新規
            if (array_key_exists('name' . $org->getOrgCode(), $ext)) {
                $pe->setOrgSearchName(trim($ext['name' . $org->getOrgCode()]));
                if (array_key_exists('score' . $org->getOrgCode(), $ext)){
                    $pe->setMinScore(trim($ext['score' . $org->getOrgCode()]));
                }
                $this->productSearchExtRepository->save($pe);
                continue;
            }

            //score 新規
            if (array_key_exists('score' . $org->getOrgCode(), $ext)){
                $pe->setMinScore(trim($ext['score' . $org->getOrgCode()]));
                $this->productSearchExtRepository->save($pe);
            }
        }
        return $this->json( ['result' => 'success'], 200);
    }

    /**
     * @Route("/%eccube_admin_route%/price_batch_search_org", name="admin_price_batch_search_org", methods={"GET"})
     * @Route("/%eccube_admin_route%/price_batch_search_org/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_price_batch_search_org_page")
     * @Template("@admin/Product/product_price_batch_org.twig")
     */
    public function priceBatchSearchOrg(Request $request, $page_no = 1, Paginator $paginator)
    {
        $org_list = $this->productSearchOrgRepository->findAll();
        $pagination = $paginator->paginate(
            $org_list,
            $page_no,
            $this->eccubeConfig->get('eccube_default_page_count')
        );

        return [
            'pagination' => $pagination,
        ];
    }

    /**
     * 新着情報を登録・編集する。
     *
     * @Route("/%eccube_admin_route%/price_batch_search_org/new", name="admin_price_batch_search_org_new")
     * @Route("/%eccube_admin_route%/price_batch_search_org/{id}/edit", requirements={"id" = "\d+"}, name="admin_price_batch_search_org_edit")
     * @Template("@admin/Product/product_price_batch_org_edit.twig")
     *
     * @param Request $request
     * @param null $id
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function priceBatchSearchOrgEdit(Request $request, $id = null, CacheUtil $cacheUtil)
    {
        if ($id) {
            $org = $this->productSearchOrgRepository->find($id);
            if (!$org) {
                throw new NotFoundHttpException();
            }
        } else {
            $org = new \Eccube\Entity\ProductSearchOrg();
        }

        $builder = $this->formFactory
            ->createBuilder(ProductSearchOrgType::class, $org);

        $form = $builder->getForm();
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->productSearchOrgRepository->save($org);

            $this->addSuccess('admin.common.save_complete', 'admin');

            // キャッシュの削除
            $cacheUtil->clearDoctrineCache();

            return $this->redirectToRoute('admin_price_batch_search_org_edit', ['id' => $org->getId()]);
        }

        return [
            'form' => $form->createView(),
            'org' => $org,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/admin_price_batch_bootstrap", name="admin_price_batch_bootstrap", methods={"GET"})
     * @Template("@admin/Product/product_price_batch_bootstrap.twig")
     */
    public function priceBatchBootstrap(Request $request)
    {
        $batch_list = $this->batchRepository->findAll();
        return [
            'batch_list' => $batch_list,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/price_batch_search_category", name="admin_price_batch_search_category", methods={"GET"})
     * @Route("/%eccube_admin_route%/price_batch_search_category/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_price_batch_search_category_page")
     * @Template("@admin/Product/product_price_batch_category.twig")
     */
    public function priceBatchSearchCategory(Request $request, $page_no = 1, Paginator $paginator)
    {
        $category_list = $this->productSearchCategoryRepository->findAll();
        $pagination = $paginator->paginate(
            $category_list,
            $page_no,
            $this->eccubeConfig->get('eccube_default_page_count')
        );

        return [
            'pagination' => $pagination,
        ];
    }

    /**
     * 新着情報を登録・編集する。
     *
     * @Route("/%eccube_admin_route%/price_batch_search_category/new", name="admin_price_batch_search_category_new")
     * @Route("/%eccube_admin_route%/price_batch_search_category/{id}/edit", requirements={"id" = "\d+"}, name="admin_price_batch_search_category_edit")
     * @Template("@admin/Product/product_price_batch_category_edit.twig")
     *
     * @param Request $request
     * @param null $id
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function priceBatchSearchCategoryEdit(Request $request, $id = null, CacheUtil $cacheUtil)
    {
        if ($id) {
            $category = $this->productSearchCategoryRepository->find($id);
            if (!$category) {
                throw new NotFoundHttpException();
            }
        } else {
            $category = new \Eccube\Entity\ProductSearchCategory();
        }

        $builder = $this->formFactory
            ->createBuilder(ProductSearchCategoryType::class, $category);

        $form = $builder->getForm();
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->productSearchCategoryRepository->save($category);

            $this->addSuccess('admin.common.save_complete', 'admin');

            // キャッシュの削除
            $cacheUtil->clearDoctrineCache();

            return $this->redirectToRoute('admin_price_batch_search_category_edit', ['id' => $category->getId()]);
        }

        return [
            'form' => $form->createView(),
            'category' => $category,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/price_batch_search_history", name="admin_price_batch_search_history")
     * @Route("/%eccube_admin_route%/price_batch_search_history/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_price_batch_search_history_page")
     * @Template("@admin/Product/product_price_batch_history.twig")
     */
    public function priceBatchSearchHistory(Request $request, $page_no = null, Paginator $paginator)
    {
        $builder = $this->formFactory
            ->createBuilder(SearchProductForPriceType::class);

        $searchForm = $builder->getForm();

        /**
         * ページの表示件数は, 以下の順に優先される.
         * - リクエストパラメータ
         * - セッション
         * - デフォルト値
         * また, セッションに保存する際は mtb_page_maxと照合し, 一致した場合のみ保存する.
         **/
        $page_count = $this->session->get('eccube.admin.product.price.batch.search.history.page_count',
            $this->eccubeConfig->get('eccube_default_page_count'));

        $page_count_param = (int) $request->get('page_count');
        $pageMaxis = $this->pageMaxRepository->findAll();

        if ($page_count_param) {
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.admin.product.price.batch.search.history.page_count', $page_count);
                    break;
                }
            }
        }

        if ('POST' === $request->getMethod()) {
            log_info("POST");
            $searchForm->handleRequest($request);

            if ($searchForm->isValid()) {
                /**
                 * 検索が実行された場合は, セッションに検索条件を保存する.
                 * ページ番号は最初のページ番号に初期化する.
                 */
                $page_no = 1;
                $searchData = $searchForm->getData();

                log_info("viewData:", [FormUtil::getViewData($searchForm)]);
                log_info("searchData:", [$searchData]);

                // 検索条件, ページ番号をセッションに保持.
                $this->session->set('eccube.admin.product.price.batch.search.history', FormUtil::getViewData($searchForm));
                $this->session->set('eccube.admin.product.price.batch.search.history.page_no', $page_no);
            } else {
                // 検索エラーの際は, 詳細検索枠を開いてエラー表示する.
                return [
                    'searchForm' => $searchForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $page_count,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                log_info("resume");
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.admin.product.price.batch.search.history.page_no', (int) $page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.admin.product.price.batch.search.history.page_no', 1);
                }
                $viewData = $this->session->get('eccube.admin.product.price.batch.search.history', []);
                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
            } else {
                log_info("init");
                /**
                 * 初期表示の場合.
                 */
                $page_no = 1;

                // main category
                $categories = $this->categoryRepository->getList(null, false);
                $mainCategory = null;
                foreach($categories as $Category) {
                    if ($Category && ($Category->getHierarchy() == 1) ) {
                        $mainCategory = $Category;
                        break;
                    }
                }
                // submit default value
                $viewData = FormUtil::getViewData($searchForm);
                if ($mainCategory) {
                    $viewData['main_category_id'] = $mainCategory->getId();
                }
                $org_list = $this->productSearchOrgRepository->findALL();
                if(count($org_list) > 0){
                    $viewData['batch_org'] = $org_list[0]->getOrgCode();
                }
                
                log_info("viewData:", [$viewData]);

                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
                if ($mainCategory) {
                    $searchData['main_category_id'] = $mainCategory;
                }
                if(count($org_list) > 0){
                    $searchData['batch_org'] = $org_list[0];
                }

                // セッション中の検索条件, ページ番号を初期化.
                $this->session->set('eccube.admin.product.price.batch.search.history', $viewData);
                $this->session->set('eccube.admin.product.price.batch.search.history.page_no', $page_no);
            }
        }

        $qb = $this->productPriceRepository->getQueryBuilderBySearchDataForAdmin($searchData);
        $prices = $qb->getQuery()->getResult();

        // get warn price
        $prices_warn = [];
        $prices_normal = [];
        foreach($prices as $price) {
            if ($price->isPriceValid() == false) {
                $prices_warn[] = $price;
            } else {
                $prices_normal[] = $price;
            }
        }
        //add normal after warn 
        foreach($prices_normal as $normal) {
            $prices_warn[] = $normal;
        }
        
        //add search histories
        $histories = $this->productSearchMatchHistoryRepository->findByOrgCode($searchData["batch_org"], $searchData["batch_exec_date"]);
        //add search ext data
        $searchExt = $this->productSearchExtRepository->findByOrgCode($searchData["batch_org"]);
        foreach($prices_warn as $price){
            $filter = $price->getProductClass()->getId();
            $history = array_filter($histories, function($v, $k) use ($filter){
                return $v->getProductClass()->getId() == $filter;
            }, ARRAY_FILTER_USE_BOTH);
            if(count($history) > 0){
                $price->setProductSearchMatchHistory(array_values($history)[0]);
            }
            $extSet = array_filter($searchExt, function($v, $k) use ($filter){
                return $v->getProductClassId() == $filter;
            }, ARRAY_FILTER_USE_BOTH);
            $arr = [];
            foreach($extSet as $ext){
                $arr[$ext->getOrgCode()] = $ext;
            }
            $price->setProductSearchExt($arr);
        }

        //filter
        $prices_warn = $this->filterSearchResult($prices_warn, $searchData);

        //pagination
        $pagination = $paginator->paginate(
            $prices_warn,
            $page_no,
            $page_count
        );

        return [
            'searchForm' => $searchForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'has_errors' => false,
        ];
    }

    private function filterSearchResult($prices, $searchData){
        //買取種別
        if($searchData['batch_sale_type'] != null){
            $filter = $searchData['batch_sale_type'];
            $prices = array_filter($prices, function($v, $k) use ($filter){
                return $v->getProductSearchMatchHistory() && $v->getProductSearchMatchHistory()->getSaleType()->getId() == $filter->getId();
            }, ARRAY_FILTER_USE_BOTH);
        }
        //適合度
        if($searchData['batch_match_score_start'] != null){
            $filter = $searchData['batch_match_score_start'];
            $prices = array_filter($prices, function($v, $k) use ($filter){
                return $v->getProductSearchMatchHistory() && $v->getProductSearchMatchHistory()->getProductMatchScore() >= $filter;
            }, ARRAY_FILTER_USE_BOTH);
        }
        if($searchData['batch_match_score_end'] != null){
            $filter = $searchData['batch_match_score_end'];
            $prices = array_filter($prices, function($v, $k) use ($filter){
                return $v->getProductSearchMatchHistory() && $v->getProductSearchMatchHistory()->getProductMatchScore() <= $filter;
            }, ARRAY_FILTER_USE_BOTH);
        }
        //マッチ
        if($searchData['batch_ismatch'] != null){
            $filter = array_values($searchData['batch_ismatch']);
            $prices = array_filter($prices, function($v, $k) use ($filter){
                return $v->getProductSearchMatchHistory() && in_array($v->getProductSearchMatchHistory()->getIsMatched(), $filter);
            }, ARRAY_FILTER_USE_BOTH);
        }
        return $prices;
    }

    /**
     * @Route("/%eccube_admin_route%/price_batch_start", name="admin_price_batch_start", methods={"POST"})
     */
    public function priceBatchStart(Request $request)
    {
        if (!$request->isXmlHttpRequest()) {
            throw new BadRequestHttpException();
        }
        $json = json_decode($request->getContent(), true);
        if(!$json["batch_id"]){
            throw new BadRequestHttpException();
        }
        $batch = $this->batchRepository->find($json["batch_id"]);
        if(!$batch){
            return $this->json( ['result' => 'error', "message"  => 'バッチが存在しません' ], 200);
        }
        if($batch->getStatus() == "RUN"){
            return $this->json( ['result' => 'error', "message"  => '前回実行中のバッチが終了しません' ], 200);
        }
        $data = array("batch_id" => $json["batch_id"]);
        $this->curlElasticsearch($batch->getJenkinsToken(), $data);
        return $this->json( ['result' => 'success'], 200);
    }
}
