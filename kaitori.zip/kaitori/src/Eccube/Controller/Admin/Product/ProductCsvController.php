<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Product;

use Eccube\Controller\AbstractController;
use Eccube\Entity\Master\CsvType;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Repository\CsvRepository;
use Eccube\Repository\Master\CsvTypeRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Routing\RouterInterface;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Class ProductCsvController
 */
class ProductCsvController extends AbstractController
{
    /**
     * @var CsvRepository
     */
    protected $csvRepository;

    /**
     * @var CsvTypeRepository
     */
    protected $csvTypeRepository;

    /**
     * ProductCsvController constructor.
     *
     * @param CsvRepository $csvRepository
     * @param CsvTypeRepository $csvTypeRepository
     */
    public function __construct(CsvRepository $csvRepository, CsvTypeRepository $csvTypeRepository)
    {
        $this->csvRepository = $csvRepository;
        $this->csvTypeRepository = $csvTypeRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/product/setting/csv/{id}",
     *     requirements={"id" = "\d+"},
     *     defaults={"id" = CsvType::CSV_TYPE_PRODUCT},
     *     name="admin_setting_product_csv"
     * )
     * @Template("@admin/Setting/Shop/csv_product.twig")
     */
    public function index_product(Request $request, RouterInterface $router, CsvType $CsvType)
    {
        return $this->index($request, $router, $CsvType, false);
    }

    /**
     * @Route("/%eccube_admin_route%/product_price/setting/csv/{id}",
     *     requirements={"id" = "\d+"},
     *     defaults={"id" = CsvType::CSV_TYPE_PRODUCT},
     *     name="admin_setting_product_price_csv"
     * )
     * @Template("@admin/Setting/Shop/csv_product.twig")
     */
    public function index_product_price(Request $request, RouterInterface $router, CsvType $CsvType)
    {
        return $this->index($request, $router, $CsvType, false, true);
    }

    /**
     * @Route("/%eccube_admin_route%/product/category/setting/csv/{id}",
     *     requirements={"id" = "\d+"},
     *     defaults={"id" = CsvType::CSV_TYPE_CATEGORY},
     *     name="admin_setting_product_category_csv"
     * )
     * @Template("@admin/Setting/Shop/csv_product_category.twig")
     */
    public function index_product_category(Request $request, CsvType $CsvType)
    {
        return $this->index($request, $CsvType);
    }

    /**
     * @Route("/%eccube_admin_route%/product/setting/csvs/{id}",
     *     requirements={"id" = "\d+"},
     *     defaults={"id" = CsvType::CSV_TYPE_PRODUCT},
     *     name="admin_setting_product_all_csv"
     * )
     * @Template("@admin/Setting/Shop/csv_product.twig")
     */
    public function index(Request $request, RouterInterface $router, CsvType $CsvType, $CsvTypeSelected = true, $isProductPriceCSV = false)
    {
        $builder = $this->createFormBuilder();

        $builder->add(
            'csv_type',
            \Eccube\Form\Type\Master\CsvType::class,
            [
                'label' => 'admin.setting.shop.csv.csv_columns',
                'choices' => $this->csvTypeRepository->findBy(['id' => [
                              1,
                              5,
                          ]]),
                'required' => true,
                'constraints' => [
                    new Assert\NotBlank(),
                ],
                'data' => $CsvType,
            ]
        );

        $CsvNotOutput = $this->csvRepository->findBy(
            ['CsvType' => $CsvType, 'enabled' => false],
            ['sort_no' => 'ASC']
        );

        $builder->add(
            'csv_not_output',
            EntityType::class,
            [
                'class' => 'Eccube\Entity\Csv',
                'choice_label' => 'disp_name',
                'required' => false,
                'expanded' => false,
                'multiple' => true,
                'choices' => $CsvNotOutput,
            ]
        );

        $CsvOutput = $this->csvRepository->findBy(
            ['CsvType' => $CsvType, 'enabled' => true],
            ['sort_no' => 'ASC']
        );

        $builder->add(
            'csv_output',
            EntityType::class,
            [
                'class' => 'Eccube\Entity\Csv',
                'choice_label' => 'disp_name',
                'required' => false,
                'expanded' => false,
                'multiple' => true,
                'choices' => $CsvOutput,
            ]
        );

        $builder->add('return_link', HiddenType::class, [
            'mapped' => false,
        ]);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'CsvOutput' => $CsvOutput,
                'CsvType' => $CsvType,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_CSV_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();

        // csv_output/csv_not_outputのチェックに引っかかるため, tokenチェックは個別に行う
        if ('POST' === $request->getMethod() && $this->isTokenValid()) {
            $data = $request->get('form');
            if (isset($data['csv_not_output'])) {
                $Csvs = $data['csv_not_output'];
                $sortNo = 1;
                foreach ($Csvs as $csv) {
                    $c = $this->csvRepository->find($csv);
                    $c->setSortNo($sortNo);
                    $c->setEnabled(false);
                    $sortNo++;
                }
            }

            if (isset($data['csv_output'])) {
                $Csvs = $data['csv_output'];
                $sortNo = 1;
                foreach ($Csvs as $csv) {
                    $c = $this->csvRepository->find($csv);
                    $c->setSortNo($sortNo);
                    $c->setEnabled(true);
                    $sortNo++;
                }
            }

            $this->entityManager->flush();

            $event = new EventArgs(
                [
                    'form' => $form,
                    'CsvOutput' => $CsvOutput,
                    'CsvType' => $CsvType,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_CSV_INDEX_COMPLETE, $event);

            $this->addSuccess('admin.common.save_complete', 'admin');

            if (isset($data['return_link']) && $returnLink = $data['return_link']) {
                try {
                    // $returnLinkはpathの形式で渡される. pathが存在するかをルータでチェックする.
                    $pattern = '/^'.preg_quote($request->getBasePath(), '/').'/';
                    $returnLink = preg_replace($pattern, '', $returnLink);
                    $result = $router->match($returnLink);
                    // パラメータのみ抽出
                    $params = array_filter($result, function ($key) {
                        return 0 !== \strpos($key, '_');
                    }, ARRAY_FILTER_USE_KEY);

                    // pathからurlを再構築してリダイレクト.
                    return $this->redirectToRoute($result['_route'], $params);
                } catch (\Exception $e) {
                    // マッチしない場合はログ出力してスキップ.
                    log_warning('URLの形式が不正です。');
                }

            } else {
                if ($CsvTypeSelected) {
                    // システム設定
                    return $this->redirectToRoute('admin_setting_product_all_csv', ['id' => $CsvType->getId()]);
                } else {
                    if($isProductPriceCSV) {
                        // 商品価格一覧
                        return $this->redirectToRoute('admin_setting_product_price_csv', ['id' => $CsvType->getId()]);
                    } else {
                        // 商品一覧
                        return $this->redirectToRoute('admin_setting_product_csv', ['id' => $CsvType->getId()]);
                    }
                }
            }
        }

        return [
            'form' => $form->createView(),
            'id' => $CsvType->getId(),
            'CsvTypeSelected' => $CsvTypeSelected,
            'isProductPriceCSV' => $isProductPriceCSV,
        ];
    }
}
