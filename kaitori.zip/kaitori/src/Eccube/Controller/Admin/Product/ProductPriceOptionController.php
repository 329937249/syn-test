<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Product;

use Eccube\Controller\AbstractController;
use Eccube\Entity\ProductPriceOption;
use Eccube\Entity\ProductPrice;
use Eccube\Entity\Master\CsvType;
use Eccube\Entity\Master\RankType;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\ProductPriceOptionType;
use Eccube\Repository\Master\RankTypeRepository;
use Eccube\Repository\ProductPriceOptionRepository;
use Eccube\Repository\ProductPriceRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Service\CsvExportService;
use Eccube\Util\CacheUtil;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;

class ProductPriceOptionController extends AbstractController
{
    /**
     * @var CsvExportService
     */
    protected $csvExportService;

    /**
     * @var  $productClassRepository
     */
    protected $productClassRepository;

    /**
     * @var ProductPriceOptionRepository
     */
    protected $productPriceOptionRepository;

    /**
     * @var ProductPriceRepository
     */
    protected $productPriceRepository;

    /**
     * @var RankTypeRepository
     */
    protected $rankTypeRepository;

    /**
     * ProductPriceOptionCProductPriceOptionRepositoryontroller constructor.
     *
     * @param CsvExportService $csvExportService
     * @param ProductClassRepository $productClassRepository
     * @param RankTypeRepository $rankTypeRepository
     * @param ProductPriceOptionRepository $productPriceOptionRepository
     * @param ProductPriceRepository $productPriceRepository
     */
    public function __construct(
        CsvExportService $csvExportService,
        ProductClassRepository $productClassRepository,
        RankTypeRepository $rankTypeRepository,
        ProductPriceOptionRepository $productPriceOptionRepository,
        ProductPriceRepository $productPriceRepository
    ) {
        $this->csvExportService = $csvExportService;
        $this->productClassRepository = $productClassRepository;
        $this->rankTypeRepository = $rankTypeRepository;
        $this->productPriceOptionRepository = $productPriceOptionRepository;
        $this->productPriceRepository = $productPriceRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/product/priceoption/{product_class_id}", requirements={"product_class_id" = "\d+"}, name="admin_product_price_option")
     * @Route("/%eccube_admin_route%/product/priceoption/{parent_id}/show", requirements={"parent_id" = "\d+"}, name="admin_product_price_option_show")
     * @Route("/%eccube_admin_route%/product/priceoption/{id}/edit", requirements={"id" = "\d+"}, name="admin_product_price_option_edit")
     * @Template("@admin/Product/product_price_option.twig")
     */
    public function index(Request $request, $product_class_id = null, $parent_id = null, $id = null, CacheUtil $cacheUtil)
    {
        log_info("product_class_id, parent_id, id",[$product_class_id, $parent_id, $id]);
        if ($product_class_id) {
            /** @var ProductClass $Parent */
            $ProductClass = $this->productClassRepository->find($product_class_id);
            if (!$ProductClass) {
                throw new NotFoundHttpException();
            }

            $FilterProductPriceOptions = $this->productPriceOptionRepository->getList($ProductClass, null);
            $OptionNew = null;
            $OptionOld = null;
            foreach($FilterProductPriceOptions as $option) {
                if ($option->getHierarchy() == 1 && $option->getRankType() && $option->getRankType()->getId() == RankType::RANK_TYPE_NEW) {
                    $OptionNew = $option;
                }
                if ($option->getHierarchy() == 1 && $option->getRankType() && $option->getRankType()->getId() == RankType::RANK_TYPE_OLD) {
                    $OptionOld = $option;
                }
            }
            if ($ProductClass->getPriceNew() && $ProductClass->getPriceNew() > 0) {
                if (is_null($OptionNew)) {
                    // add
                    $RankType = $this->rankTypeRepository->find(RankType::RANK_TYPE_NEW);

                    $OptionNew = new \Eccube\Entity\ProductPriceOption();
                    $OptionNew->setProductClass($ProductClass);
                    $OptionNew->setRankType($RankType);
                    $OptionNew->setOptionName($RankType->getName());
                    $OptionNew->setHierarchy(1);
                    $OptionNew->setVisible(true);
                    $this->productPriceOptionRepository->save($OptionNew);
                }
            } else {
                if (!is_null($OptionNew)) {
                    // delete
                    $this->productPriceOptionRepository->delete($OptionNew);
                }
            }
            if ($ProductClass->getPriceOld() && $ProductClass->getPriceOld() > 0) {
                if (is_null($OptionOld)) {
                    // add
                    $RankType = $this->rankTypeRepository->find(RankType::RANK_TYPE_OLD);

                    $OptionOld = new \Eccube\Entity\ProductPriceOption();
                    $OptionOld->setProductClass($ProductClass);
                    $OptionOld->setRankType($RankType);
                    $OptionOld->setOptionName($RankType->getName());
                    $OptionOld->setHierarchy(1);
                    $OptionOld->setVisible(true);
                    $this->productPriceOptionRepository->save($OptionOld);
                }
                
            } else {
                if (!is_null($OptionOld)) {
                    // delete
                    //$this->productPriceOptionRepository->delete($OptionOld);
                }
            }
            $cacheUtil->clearDoctrineCache();
        }

        if ($parent_id) {
            /** @var ProductPriceOption $Parent */
            $Parent = $this->productPriceOptionRepository->find($parent_id);
            if (!$Parent) {
                throw new NotFoundHttpException();
            }
            $ProductClass = $Parent->getProductClass();
        } else {
            $Parent = null;
        }
        if ($id) {
            $TargetProductPriceOption = $this->productPriceOptionRepository->find($id);
            if (!$TargetProductPriceOption) {
                throw new NotFoundHttpException();
            }
            $Parent = $TargetProductPriceOption->getParent();
            $ProductClass = $Parent->getProductClass();
        } else {
            $TargetProductPriceOption = new \Eccube\Entity\ProductPriceOption();
            $TargetProductPriceOption->setParent($Parent);
            if ($Parent) {
                $TargetProductPriceOption->setHierarchy($Parent->getHierarchy() + 1);
            } else {
                $TargetProductPriceOption->setHierarchy(1);
            }
        }
        if (!isset($ProductClass)) {
            throw new NotFoundHttpException();
        }

        $ProductPriceOptions = $this->productPriceOptionRepository->getList($ProductClass, $Parent);

        // ツリー表示のため、ルートからのカテゴリを取得
        $TopProductPriceOptions = $this->productPriceOptionRepository->getList($ProductClass, null);

        $builder = $this->formFactory
            ->createBuilder(ProductPriceOptionType::class, $TargetProductPriceOption);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'Parent' => $Parent,
                'TargetProductPriceOption' => $TargetProductPriceOption,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_PRICE_OPTION_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();

        $forms = [];
        foreach ($ProductPriceOptions as $ProductPriceOption) {
            $forms[$ProductPriceOption->getId()] = $this->formFactory
                ->createNamed('productpriceoption_'.$ProductPriceOption->getId(), ProductPriceOptionType::class, $ProductPriceOption);
        }

        if ($request->getMethod() === 'POST') {
            $form->handleRequest($request);
            if ($form->isValid()) {
                if ($this->eccubeConfig['eccube_category_nest_level'] < $TargetProductPriceOption->getHierarchy()) {
                    throw new BadRequestHttpException();
                }
                log_info('ランク登録開始', [$id, $ProductClass]);

                $TargetProductPriceOption->setProductClass($ProductClass);
                $TargetProductPriceOption->setVisible(true);
                if ($Parent) {
                    $TargetProductPriceOption->setRankType($Parent->getRankType());
                }
                $this->productPriceOptionRepository->save($TargetProductPriceOption);

                $this->productPriceRepository->updateProductPriceMember($ProductClass,$TargetProductPriceOption->getRankType()->getId(),$this->getUser());
                log_info('ランク登録完了', [$id]);

                // $formが保存されたフォーム
                // 下の編集用フォームの場合とイベント名が共通のため
                // このイベントのリスナーではsubmitされているフォームを判定する必要がある
                $event = new EventArgs(
                    [
                        'form' => $form,
                        'Parent' => $Parent,
                        'TargetProductPriceOption' => $TargetProductPriceOption,
                    ],
                    $request
                );
                $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_PRICE_OPTION_INDEX_COMPLETE, $event);

                $this->addSuccess('admin.common.save_complete', 'admin');

                $cacheUtil->clearDoctrineCache();

                if ($Parent) {
                    return $this->redirectToRoute('admin_product_price_option_show', ['parent_id' => $Parent->getId()]);
                } else {
                    return $this->redirectToRoute('admin_product_price_option', ['product_class_id' => $ProductClass->getId()]);
                }
            }

            foreach ($forms as $editForm) {
                $editForm->handleRequest($request);
                if ($editForm->isSubmitted() && $editForm->isValid()) {
                    $editForm->getData()->setVisible(true);
                    $this->productPriceOptionRepository->save($editForm->getData());
                    $this->productPriceRepository->updateProductPriceMember($ProductClass,$editForm->getData()->getRankType()->getId(),$this->getUser());

                    // $editFormが保存されたフォーム
                    // 上の新規登録用フォームの場合とイベント名が共通のため
                    // このイベントのリスナーではsubmitされているフォームを判定する必要がある
                    $event = new EventArgs(
                        [
                            'form' => $form,
                            'editForm' => $editForm,
                            'Parent' => $Parent,
                            'TargetProductPriceOption' => $editForm->getData(),
                        ],
                        $request
                    );

                    $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_PRICE_OPTION_INDEX_COMPLETE, $event);

                    $this->addSuccess('admin.common.save_complete', 'admin');

                    $cacheUtil->clearDoctrineCache();

                    if ($Parent) {
                        return $this->redirectToRoute('admin_product_price_option_show', ['parent_id' => $Parent->getId()]);
                    } else {
                        return $this->redirectToRoute('admin_product_price_option', ['product_class_id' => $ProductClass->getId()]);
                    }
                }
            }
        }

        $formViews = [];
        foreach ($forms as $key => $value) {
            $formViews[$key] = $value->createView();
        }

        $Ids = [];
        if ($Parent && $Parent->getParents()) {
            foreach ($Parent->getParents() as $item) {
                $Ids[] = $item['id'];
            }
        }
        $Ids[] = intval($parent_id);

        return [
            'form' => $form->createView(),
            'Parent' => $Parent,
            'Ids' => $Ids,
            'ProductClass' => $ProductClass,
            'ProductPriceOptions' => $ProductPriceOptions,
            'TopProductPriceOptions' => $TopProductPriceOptions,
            'TargetProductPriceOption' => $TargetProductPriceOption,
            'forms' => $formViews,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/product/priceoption/{id}/delete", requirements={"id" = "\d+"}, name="admin_product_price_option_delete", methods={"DELETE"})
     */
    public function delete(Request $request, $id, CacheUtil $cacheUtil)
    {
        $this->isTokenValid();

        $TargetProductPriceOption = $this->productPriceOptionRepository->find($id);
        if (!$TargetProductPriceOption) {
            $this->deleteMessage();

            return $this->redirectToRoute('admin_product_price_option');
        }
        $Parent = $TargetProductPriceOption->getParent();
        $ProductClass = $TargetProductPriceOption->getProductClass();

        log_info('ランク削除開始', [$id]);

        try {
            $this->productPriceOptionRepository->delete($TargetProductPriceOption);
            $this->productPriceRepository->updateProductPriceMember($ProductClass,$TargetProductPriceOption->getRankType()->getId(),$this->getUser());
            
            $event = new EventArgs(
                [
                    'Parent' => $Parent,
                    'TargetProductPriceOption' => $TargetProductPriceOption,
                ], $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_PRICE_OPTION_DELETE_COMPLETE, $event);

            $this->addSuccess('admin.common.delete_complete', 'admin');

            log_info('ランク削除完了', [$id]);

            $cacheUtil->clearDoctrineCache();
        } catch (\Exception $e) {
            log_info('ランク削除エラー', [$id, $e]);

            $message = trans('admin.common.delete_error_foreign_key', ['%name%' => $TargetProductPriceOption->getName()]);
            $this->addError($message, 'admin');
        }

        if ($Parent) {
            return $this->redirectToRoute('admin_product_price_option_show', ['parent_id' => $Parent->getId()]);
        } else {
            return $this->redirectToRoute('admin_product_price_option', ['product_class_id' => $ProductClass->getId()]);
        }
    }

    /**
     * @Route("/%eccube_admin_route%/product/priceoption/sort_no/move", name="admin_product_price_option_sort_no_move", methods={"POST"})
     */
    public function moveSortNo(Request $request, CacheUtil $cacheUtil)
    {
        if (!$request->isXmlHttpRequest()) {
            throw new BadRequestHttpException();
        }

        if ($this->isTokenValid()) {
            $sortNos = $request->request->all();
            foreach ($sortNos as $productPriceOptionId => $sortNo) {
                /* @var $ProductPriceOption \Eccube\Entity\ProductPriceOption */
                $ProductPriceOption = $this->productPriceOptionRepository
                    ->find($productPriceOptionId);
                $ProductPriceOption->setSortNo($sortNo);
                $this->entityManager->persist($ProductPriceOption);
            }
            $this->entityManager->flush();

            $cacheUtil->clearDoctrineCache();

            return new Response('Successful');
        }
    }

    /**
     * カテゴリCSVの出力.
     *
     * @Route("/%eccube_admin_route%/product/priceoption/export", name="admin_product_price_option_export")
     *
     * @param Request $request
     *
     * @return StreamedResponse
     */
    public function export(Request $request)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        // sql loggerを無効にする.
        $em = $this->entityManager;
        $em->getConfiguration()->setSQLLogger(null);

        $response = new StreamedResponse();
        $response->setCallback(function () use ($request) {
            // CSV種別を元に初期化.
            $this->csvExportService->initCsvType(CsvType::CSV_TYPE_CATEGORY);

            // ヘッダ行の出力.
            $this->csvExportService->exportHeader();

            $qb = $this->productPriceOptionRepository
                ->createQueryBuilder('c')
                ->orderBy('c.sort_no', 'DESC');

            // データ行の出力.
            $this->csvExportService->setExportQueryBuilder($qb);
            $this->csvExportService->exportData(function ($entity, $csvService) use ($request) {
                $Csvs = $csvService->getCsvs();

                /** @var $ProductPriceOption \Eccube\Entity\ProductPriceOption */
                $ProductPriceOption = $entity;

                // CSV出力項目と合致するデータを取得.
                $ExportCsvRow = new \Eccube\Entity\ExportCsvRow();
                foreach ($Csvs as $Csv) {
                    $ExportCsvRow->setData($csvService->getData($Csv, $ProductPriceOption));

                    $event = new EventArgs(
                        [
                            'csvService' => $csvService,
                            'Csv' => $Csv,
                            'ProductPriceOption' => $ProductPriceOption,
                            'ExportCsvRow' => $ExportCsvRow,
                        ],
                        $request
                    );
                    $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_PRICE_OPTION_CSV_EXPORT, $event);

                    $ExportCsvRow->pushData();
                }

                //$row[] = number_format(memory_get_usage(true));
                // 出力.
                $csvService->fputcsv($ExportCsvRow->getRow());
            });
        });

        $now = new \DateTime();
        $filename = 'product_price_option_'.$now->format('YmdHis').'.csv';
        $response->headers->set('Content-Type', 'application/octet-stream');
        $response->headers->set('Content-Disposition', 'attachment; filename='.$filename);
        $response->send();

        log_info('カテゴリCSV出力ファイル名', [$filename]);

        return $response;
    }
}
