<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Product;

use Eccube\Controller\AbstractController;
use Eccube\Entity\Master\Rank;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\RankType;
use Eccube\Repository\Master\RankRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class RankController extends AbstractController
{
    /**
     * @var RankRepository
     */
    protected $rankRepository;

    public function __construct(RankRepository $rankRepository)
    {
        $this->rankRepository = $rankRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/product/rank", name="admin_product_rank")
     * @Template("@admin/Product/rank.twig")
     *
     * @param Request $request
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function index(Request $request)
    {
        $Rank = new Rank();
        $Ranks = $this->rankRepository->getList();

        /**
         * 新規登録用フォーム
         **/
        $builder = $this->formFactory
            ->createBuilder(RankType::class, $Rank);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'rank' => $Rank,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_RANK_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();

        /**
         * 編集用フォーム
         */
        $forms = [];
        foreach ($Ranks as $EditRank) {
            $id = $EditRank->getId();
            $forms[$id] = $this
                ->formFactory
                ->createNamed('rank_'.$id, RankType::class, $EditRank);
        }

        if ('POST' === $request->getMethod()) {
            /*
             * 登録処理
             */
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()) {
                $this->rankRepository->save($form->getData());

                $this->dispatchComplete($request, $form, $form->getData());

                $this->addSuccess('admin.common.save_complete', 'admin');

                return $this->redirectToRoute('admin_product_rank');
            }
            /*
             * 編集処理
             */
            foreach ($forms as $editForm) {
                $editForm->handleRequest($request);
                if ($editForm->isSubmitted() && $editForm->isValid()) {
                    $this->rankRepository->save($editForm->getData());

                    $this->dispatchComplete($request, $editForm, $editForm->getData());

                    $this->addSuccess('admin.common.save_complete', 'admin');

                    return $this->redirectToRoute('admin_product_rank');
                }
            }
        }

        $formViews = [];
        foreach ($forms as $key => $value) {
            $formViews[$key] = $value->createView();
        }

        return [
            'form' => $form->createView(),
            'Rank' => $Rank,
            'Ranks' => $Ranks,
            'forms' => $formViews,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/product/rank/{id}/delete", requirements={"id" = "\d+"}, name="admin_product_rank_delete", methods={"DELETE"})
     */
    public function delete(Request $request, Rank $Rank)
    {
        $this->isTokenValid();

        log_info('タグ削除開始', [$Rank->getId(), $Rank->getName(), $Rank->getRankType(), $Rank->getPriceChange()]);

        try {
            $this->rankRepository->delete($Rank);

            $event = new EventArgs(
                [
                    'Rank' => $Rank,
                ], $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_RANK_DELETE_COMPLETE, $event);

            $this->addSuccess('admin.common.delete_complete', 'admin');

            log_info('タグ削除完了', [$Rank->getId()]);
        } catch (\Exception $e) {
            log_info('タグ削除エラー', [$Rank->getId(), $e]);

            $message = trans('admin.common.delete_error.foreign_key', ['%name%' => $Rank->getName()]);
            $this->addError($message, 'admin');
        }

        return $this->redirectToRoute('admin_product_rank');
    }

    /**
     * @Route("/%eccube_admin_route%/product/rank/sort_no/move", name="admin_product_rank_sort_no_move", methods={"POST"})
     */
    public function moveSortNo(Request $request)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            $sortNos = $request->request->all();
            foreach ($sortNos as $rankId => $sortNo) {
                /* @var $Rank \Eccube\Entity\Master\Rank */
                $Rank = $this->rankRepository
                    ->find($rankId);
                $Rank->setSortNo($sortNo);
                $this->entityManager->persist($Rank);
            }
            $this->entityManager->flush();
        }

        return new Response();
    }

    protected function dispatchComplete(Request $request, FormInterface $form, Rank $Rank)
    {
        $event = new EventArgs(
            [
                'form' => $form,
                'Rank' => $Rank,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_RANK_INDEX_COMPLETE, $event);
    }
}
