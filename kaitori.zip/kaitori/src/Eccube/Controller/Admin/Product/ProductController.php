<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\Product;

use Doctrine\DBAL\Exception\ForeignKeyConstraintViolationException;
use Eccube\Common\Constant;
use Eccube\Controller\AbstractController;
use Eccube\Entity\BaseInfo;
use Eccube\Entity\ExportCsvRow;
use Eccube\Entity\Master\CsvType;
use Eccube\Entity\Master\ProductStatus;
use Eccube\Entity\Master\Rank;
use Eccube\Entity\Master\SaleType;
use Eccube\Entity\Master\RankType;
use Eccube\Entity\Master\ProductPriceRule;
use Eccube\Entity\Product;
use Eccube\Entity\ProductCategory;
use Eccube\Entity\ProductClass;
use Eccube\Entity\ProductPrice;
use Eccube\Entity\ProductImage;
use Eccube\Entity\ProductStock;
use Eccube\Entity\ProductTag;
use Eccube\Entity\ProductRank;
use Eccube\Entity\ProductPriceOption;
use Eccube\Entity\StockListStorehouseUnit;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\ProductType;
use Eccube\Form\Type\Admin\SearchProductType;
use Eccube\Repository\BaseInfoRepository;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\Master\ProductPriceRuleRepository;
use Eccube\Repository\Master\ProductStatusRepository;
use Eccube\Repository\Master\RankRepository;
use Eccube\Repository\PlaceRepository;
use Eccube\Repository\StateRepository;
use Eccube\Repository\StockListStorehouseUnitRepository;
use Eccube\Repository\StockListProductUnitRepository;
use Eccube\Repository\Master\RankTypeRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\ProductPriceOptionRepository;
use Eccube\Repository\ProductImageRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\TagRepository;
use Eccube\Repository\TaxRuleRepository;
use Eccube\Service\CsvExportService;
use Eccube\Util\CacheUtil;
use Eccube\Util\FormUtil;
use Knp\Component\Pager\Paginator;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\UnsupportedMediaTypeHttpException;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Routing\RouterInterface;

class ProductController extends AbstractController
{
    /**
     * @var CsvExportService
     */
    protected $csvExportService;

    /**
     * @var ProductClassRepository
     */
    protected $productClassRepository;

    /**
     * @var ProductImageRepository
     */
    protected $productImageRepository;

    /**
     * @var TaxRuleRepository
     */
    protected $taxRuleRepository;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var BaseInfo
     */
    protected $BaseInfo;

    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;

    /**
     * @var ProductStatusRepository
     */
    protected $productStatusRepository;

    /**
     * @var TagRepository
     */
    protected $tagRepository;

    /**
     * @var StockListStorehouseUnitRepository
     */
    protected $stockListStorehouseUnitRepository;

    /**
     * @var StockListProductUnitRepository
     */
    protected $stockListProductUnitRepository;

    /**
     * @var RankRepository
     */
    protected $rankRepository;

    /**
     * @var RankTypeRepository
     */
    protected $rankTypeRepository;

    /**
     * @var ProductPriceRuleRepository
     */
    protected $productPriceRuleRepository;

    /**
     * @var ProductPriceOptionRepository
     */
    protected $productPriceOptionRepository;

    /**
     * @var StateRepository
     */
    protected $stateRepository;

    /**
     * @var PlaceRepository
     */
    protected $placeRepository;

    /**
     * ProductController constructor.
     *
     * @param CsvExportService $csvExportService
     * @param ProductClassRepository $productClassRepository
     * @param ProductImageRepository $productImageRepository
     * @param TaxRuleRepository $taxRuleRepository
     * @param CategoryRepository $categoryRepository
     * @param ProductRepository $productRepository
     * @param BaseInfoRepository $baseInfoRepository
     * @param PageMaxRepository $pageMaxRepository
     * @param ProductPriceRuleRepository $productPriceRuleRepository
     * @param ProductStatusRepository $productStatusRepository
     * @param TagRepository $tagRepository
     * @param StockListStorehouseUnitRepository $stockListStorehouseUnitRepository
     * @param StockListProductUnitRepository $stockListProductUnitRepository
     * @param RankRepository $rankRepository
     * @param StateRepository $stateRepository
     * @param PlaceRepository $placeRepository
     */
    public function __construct(
        CsvExportService $csvExportService,
        ProductClassRepository $productClassRepository,
        ProductImageRepository $productImageRepository,
        TaxRuleRepository $taxRuleRepository,
        CategoryRepository $categoryRepository,
        ProductRepository $productRepository,
        BaseInfoRepository $baseInfoRepository,
        PageMaxRepository $pageMaxRepository,
        ProductStatusRepository $productStatusRepository,
        ProductPriceRuleRepository $productPriceRuleRepository,
        ProductPriceOptionRepository $productPriceOptionRepository,
        RankTypeRepository $rankTypeRepository,
        TagRepository $tagRepository,
        // INS-START CNC 2021/12/10
        StockListStorehouseUnitRepository $stockListStorehouseUnitRepository,
        StockListProductUnitRepository $stockListProductUnitRepository,
        // INS-END CNC 2021/12/10
        RankRepository $rankRepository
        // INS-START CNC 2022/12/30
        , StateRepository $stateRepository
        , PlaceRepository $placeRepository
        // INS-END CNC 2022/12/30
    ) {
        $this->csvExportService = $csvExportService;
        $this->productClassRepository = $productClassRepository;
        $this->productImageRepository = $productImageRepository;
        $this->taxRuleRepository = $taxRuleRepository;
        $this->categoryRepository = $categoryRepository;
        $this->productRepository = $productRepository;
        $this->BaseInfo = $baseInfoRepository->get();
        $this->pageMaxRepository = $pageMaxRepository;
        $this->productStatusRepository = $productStatusRepository;
        $this->productPriceRuleRepository = $productPriceRuleRepository;
        $this->productPriceOptionRepository = $productPriceOptionRepository;
        $this->rankTypeRepository = $rankTypeRepository;
        $this->tagRepository = $tagRepository;
        $this->rankRepository = $rankRepository;
        // INS-START CNC 2021/12/10
        $this->stockListStorehouseUnitRepository = $stockListStorehouseUnitRepository;
        $this->stockListProductUnitRepository = $stockListProductUnitRepository;
        // INS-END CNC 2021/12/10
        // INS-START CNC 2022/12/30
        $this->stateRepository = $stateRepository;
        $this->placeRepository = $placeRepository;
        // INS-END CNC 2022/12/30
    }

    /**
     * @Route("/%eccube_admin_route%/product", name="admin_product")
     * @Route("/%eccube_admin_route%/product/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_product_page")
     * @Template("@admin/Product/index.twig")
     */
    public function index(Request $request, $page_no = null, Paginator $paginator)
    {
        $builder = $this->formFactory
            ->createBuilder(SearchProductType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_INDEX_INITIALIZE, $event);

        $searchForm = $builder->getForm();

        /**
         * ページの表示件数は, 以下の順に優先される.
         * - リクエストパラメータ
         * - セッション
         * - デフォルト値
         * また, セッションに保存する際は mtb_page_maxと照合し, 一致した場合のみ保存する.
         **/
        $page_count = $this->session->get('eccube.admin.product.search.page_count',
            $this->eccubeConfig->get('eccube_default_page_count'));

        $page_count_param = (int) $request->get('page_count');
        $pageMaxis = $this->pageMaxRepository->findAll();

        if ($page_count_param) {
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.admin.product.search.page_count', $page_count);
                    break;
                }
            }
        }

        if ('POST' === $request->getMethod()) {
            $searchForm->handleRequest($request);

            if ($searchForm->isValid()) {
                /**
                 * 検索が実行された場合は, セッションに検索条件を保存する.
                 * ページ番号は最初のページ番号に初期化する.
                 */
                $page_no = 1;
                $searchData = $searchForm->getData();

                // 検索条件, ページ番号をセッションに保持.
                $this->session->set('eccube.admin.product.search', FormUtil::getViewData($searchForm));
                $this->session->set('eccube.admin.product.search.page_no', $page_no);
            } else {
                // 検索エラーの際は, 詳細検索枠を開いてエラー表示する.
                return [
                    'searchForm' => $searchForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $page_count,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.admin.product.search.page_no', (int) $page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.admin.product.search.page_no', 1);
                }
                $viewData = $this->session->get('eccube.admin.product.search', []);
                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
            } else {
                /**
                 * 初期表示の場合.
                 */
                $page_no = 1;

                // main category
                $categories = $this->categoryRepository->getList(null, false);
                $mainCategory = null;
                foreach($categories as $Category) {
                    if ($Category && ($Category->getHierarchy() == 1) ) {
                        $mainCategory = $Category;
                        break;
                    }
                }

                // submit default value
                $viewData = FormUtil::getViewData($searchForm);
                if ($mainCategory) {
                    $viewData['main_category_id'] = $mainCategory->getId();
                }

                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
                if ($mainCategory) {
                    $searchData['main_category_id'] = $mainCategory;
                }
                //log_info("searchData", [$searchData]);

                // セッション中の検索条件, ページ番号を初期化.
                $this->session->set('eccube.admin.product.search', $viewData);
                $this->session->set('eccube.admin.product.search.page_no', $page_no);
            }
        }

        $qb = $this->productRepository->getQueryBuilderBySearchDataForAdmin($searchData);

        $event = new EventArgs(
            [
                'qb' => $qb,
                'searchData' => $searchData,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $qb,
            $page_no,
            $page_count
        );

        return [
            'searchForm' => $searchForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'has_errors' => false,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/product/classes/{id}/load", name="admin_product_classes_load", methods={"GET"}, requirements={"id" = "\d+"})
     * @Template("@admin/Product/product_class_popup.twig")
     * @ParamConverter("Product")
     */
    public function loadProductClasses(Request $request, Product $Product)
    {
        if (!$request->isXmlHttpRequest()) {
            throw new BadRequestHttpException();
        }

        $data = [];
        /** @var $Product ProductRepository */
        if (!$Product) {
            throw new NotFoundHttpException();
        }

        if ($Product->hasProductClass()) {
            $class = $Product->getProductClasses();
            foreach ($class as $item) {
                if ($item['visible']) {
                    $data[] = $item;
                }
            }
        }

        return [
            'data' => $data,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/product/product/image/add", name="admin_product_image_add", methods={"POST"})
     */
    public function addImage(Request $request)
    {
        if (!$request->isXmlHttpRequest()) {
            throw new BadRequestHttpException();
        }

        $images = $request->files->get('admin_product');

        $allowExtensions = ['gif', 'jpg', 'jpeg', 'png'];
        $files = [];
        if (count($images) > 0) {
            foreach ($images as $img) {
                foreach ($img as $image) {
                    //ファイルフォーマット検証
                    $mimeType = $image->getMimeType();
                    if (0 !== strpos($mimeType, 'image')) {
                        throw new UnsupportedMediaTypeHttpException();
                    }

                    // 拡張子
                    $extension = $image->getClientOriginalExtension();
                    if (!in_array(strtolower($extension), $allowExtensions)) {
                        throw new UnsupportedMediaTypeHttpException();
                    }

                    $filename = date('mdHis').uniqid('_').'.'.$extension;
                    $image->move($this->eccubeConfig['eccube_temp_image_dir'], $filename);
                    $files[] = $filename;
                }
            }
        }

        $event = new EventArgs(
            [
                'images' => $images,
                'files' => $files,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_ADD_IMAGE_COMPLETE, $event);
        $files = $event->getArgument('files');

        return $this->json(['files' => $files], 200);
    }

    /**
     * @Route("/%eccube_admin_route%/product/product/new", name="admin_product_product_new")
     * @Route("/%eccube_admin_route%/product/product/{id}/edit", requirements={"id" = "\d+"}, name="admin_product_product_edit")
     * @Template("@admin/Product/product.twig")
     */
    public function edit(Request $request, $id = null, RouterInterface $router, CacheUtil $cacheUtil)
    {

        $has_class = false;
        $has_error = false;
        //$is_new_product = false;

        // INS-START CNC 2021/12/10
        $serialChangedAuthFlg = 1;
        $dbSerialFlg = 1;
        // INS-END CNC 2021/12/10

        if (is_null($id)) {
            $Product = new Product();
            $ProductClass = new ProductClass();
            $ProductStatus = $this->productStatusRepository->find(ProductStatus::DISPLAY_HIDE);
            $Product
                ->addProductClass($ProductClass)
                ->setStatus($ProductStatus)
                // INS-START CNC 2021/9/13
                // 画面に買取種別のデフォルトは「携帯」だから
                ->setSerialFlg(true);
                // INS-END CNC 2021/9/13
            $ProductClass
                ->setVisible(true)
                ->setStockUnlimited(true)
                ->setProduct($Product);
            $ProductStock = new ProductStock();
            $ProductClass->setProductStock($ProductStock);
            $ProductStock->setProductClass($ProductClass);
            //$is_new_product = true;
        } else {
            $Product = $this->productRepository->find($id);
            if (!$Product) {
                throw new NotFoundHttpException();
            }
            // 規格無しの商品の場合は、デフォルト規格を表示用に取得する
            $has_class = $Product->hasProductClass();
            if (!$has_class) {
                $ProductClasses = $Product->getProductClasses();
                foreach ($ProductClasses as $pc) {
                    if (!is_null($pc->getClassCategory1())) {
                        continue;
                    }
                    if ($pc->isVisible()) {
                        $ProductClass = $pc;
                        break;
                    }
                }
                if ($this->BaseInfo->isOptionProductTaxRule() && $ProductClass->getTaxRule()) {
                    $ProductClass->setTaxRate($ProductClass->getTaxRule()->getTaxRate());
                }
                $ProductStock = $ProductClass->getProductStock();

            }
            // INS-START CNC 2021/12/10
            if (count($Product->getProductClasses()) > 0) {

                $dbSerialFlg = $Product->getSerialFlg();
                if ($dbSerialFlg) {
                    $dbSerialFlg = 1;
                } else {
                    $dbSerialFlg = 0;
                }

                $productCode = $Product->getProductClasses()[0]->getCode();

                if ($productCode !== null && $productCode !== '') {
                    $serialStockInfo = $this->stockListStorehouseUnitRepository->getStockListStorehouseUnitByKeyForSerial($productCode);

                    $serialStockProductInfo = $this->stockListProductUnitRepository->getStockListProductUnitByKeyForSerial($productCode);

                    if (($serialStockInfo && count($serialStockInfo) > 0) || ($serialStockProductInfo && count($serialStockProductInfo) > 0)) {
                        $serialChangedAuthFlg = 0;

                    }
                }
            }
            // INS-END CNC 2021/12/10
        }

        $builder = $this->formFactory
            ->createBuilder(ProductType::class, $Product);

        // 規格あり商品の場合、規格関連情報をFormから除外
        if ($has_class) {
            $builder->remove('class');
        }

        $event = new EventArgs(
            [
                'builder' => $builder,
                'Product' => $Product,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_EDIT_INITIALIZE, $event);

        $form = $builder->getForm();

        if (!$has_class) {
            $ProductClass->setStockUnlimited($ProductClass->isStockUnlimited());
            $form['class']->setData($ProductClass);
        }

        // ファイルの登録
        $images = [];
        $ProductImages = $Product->getProductImage();
        foreach ($ProductImages as $ProductImage) {
            $images[] = $ProductImage->getFileName();
        }
        $form['images']->setData($images);

        // AFT-START CNC 2021/7/13
        $categories = [];
        $vicecategories = [];
        $ProductCategories = $Product->getProductCategories();
        foreach ($ProductCategories as $ProductCategory) {
            $category_sub_flag = $ProductCategory->getCategorySubFlg();
            if($category_sub_flag==0){
                /* @var $ProductCategory \Eccube\Entity\ProductCategory */
                $categories[] = $ProductCategory->getCategory();
            }else {
                $vicecategories[] = $ProductCategory->getCategory();
            }
        }
        $form['Category']->setData($categories);
        $form['viceCategory']->setData($vicecategories);
        // AFT-END CNC 2021/7/13

        $Tags = $Product->getTags();

        $form['Tag']->setData($Tags);

        $Ranks = $Product->getRanks();
        $form['Rank']->setData($Ranks);

        if ('POST' === $request->getMethod()) {
            $form->handleRequest($request);
            if ($form->isValid()) {
                log_info('商品登録開始', [$id]);
                $Product = $form->getData();

                if (!$has_class) {
                    $ProductClass = $form['class']->getData();

                    // 個別消費税
                    if ($this->BaseInfo->isOptionProductTaxRule()) {
                        if ($ProductClass->getTaxRate() !== null) {
                            if ($ProductClass->getTaxRule()) {
                                $ProductClass->getTaxRule()->setTaxRate($ProductClass->getTaxRate());
                            } else {
                                $taxrule = $this->taxRuleRepository->newTaxRule();
                                $taxrule->setTaxRate($ProductClass->getTaxRate());
                                $taxrule->setApplyDate(new \DateTime());
                                $taxrule->setProduct($Product);
                                $taxrule->setProductClass($ProductClass);
                                $ProductClass->setTaxRule($taxrule);
                            }

                            $ProductClass->getTaxRule()->setTaxRate($ProductClass->getTaxRate());
                        } else {
                            if ($ProductClass->getTaxRule()) {
                                $this->taxRuleRepository->delete($ProductClass->getTaxRule());
                                $ProductClass->setTaxRule(null);
                            }
                        }
                    }
                    if($this->isProductExists($Product,$ProductClass)){
                       $this->addError('admin.common.product_edit_invalid_exist', 'admin');
                       $has_error = true;
                    }else{
                       $this->entityManager->persist($ProductClass);
                    }

                    // 在庫情報を作成 (買取では不要)
                    // if (!$ProductClass->isStockUnlimited()) {
                    //     $ProductStock->setStock($ProductClass->getStock());
                    // } else {
                    //     // 在庫無制限時はnullを設定
                    //     $ProductStock->setStock(null);
                    // }
                    // $this->entityManager->persist($ProductStock);
                }
                if(!$has_error){
                    // カテゴリの登録
                    // 一度クリア
                    /* @var $Product \Eccube\Entity\Product */
                    foreach ($Product->getProductCategories() as $ProductCategory) {
                        $Product->removeProductCategory($ProductCategory);
                        $this->entityManager->remove($ProductCategory);
                    }
                    $this->entityManager->persist($Product);
                    $this->entityManager->flush();

                    $count = 1;
                    $Categories = $form->get('Category')->getData();
                    $categoriesIdList = [];
                    foreach ($Categories as $Category) {
                        foreach ($Category->getPath() as $ParentCategory) {
                            if (!isset($categoriesIdList[$ParentCategory->getId()])) {
                                $ProductCategory = $this->createProductCategory($Product, $ParentCategory, $count);
                                $this->entityManager->persist($ProductCategory);
                                $count++;
                                /* @var $Product \Eccube\Entity\Product */
                                $Product->addProductCategory($ProductCategory);
                                $categoriesIdList[$ParentCategory->getId()] = true;
                            }
                        }
                        if (!isset($categoriesIdList[$Category->getId()])) {
                            $ProductCategory = $this->createProductCategory($Product, $Category, $count);
                            $this->entityManager->persist($ProductCategory);
                            $count++;
                            /* @var $Product \Eccube\Entity\Product */
                            $Product->addProductCategory($ProductCategory);
                            $categoriesIdList[$ParentCategory->getId()] = true;
                        }
                    }

                    //  INS-START CNC 2021/7/13
                    $viceCategories = $form->get('viceCategory')->getData();
                    $vicecategoriesIdList = [];
                    foreach ($viceCategories as $viceCategory) {
                        foreach ($viceCategory->getPath() as $ParentCategory) {
                            if (!isset($vicecategoriesIdList[$ParentCategory->getId()])) {
                                $ProductCategory = $this->createProductViceCategory($Product, $ParentCategory, $count);
                                $this->entityManager->persist($ProductCategory);
                                $count++;
                                /* @var $Product \Eccube\Entity\Product */
                                $Product->addProductCategory($ProductCategory);
                                $vicecategoriesIdList[$ParentCategory->getId()] = true;
                            }
                        }
                        if (!isset($vicecategoriesIdList[$viceCategory->getId()]) && $vicecategoriesIdList[$viceCategory->getHierarchy()]) {
                            $ProductCategory = $this->createProductViceCategory($Product, $viceCategory, $count);
                            $this->entityManager->persist($ProductCategory);
                            $count++;
                            /* @var $Product \Eccube\Entity\Product */
                            $Product->addProductCategory($ProductCategory);
                            $vicecategoriesIdList[$ParentCategory->getId()] = true;
                        }
                    }
                    //  INS-END CNC 2021/7/13

                    // 画像の登録
                    $add_images = $form->get('add_images')->getData();
                    foreach ($add_images as $add_image) {
                        $ProductImage = new \Eccube\Entity\ProductImage();
                        $ProductImage
                            ->setFileName($add_image)
                            ->setProduct($Product)
                            ->setSortNo(1);
                        $Product->addProductImage($ProductImage);
                        $this->entityManager->persist($ProductImage);

                        // 移動
                        $file = new File($this->eccubeConfig['eccube_temp_image_dir'].'/'.$add_image);
                        $file->move($this->eccubeConfig['eccube_save_image_dir']);
                    }

                    // 画像の削除
                    $delete_images = $form->get('delete_images')->getData();
                    foreach ($delete_images as $delete_image) {
                        $ProductImage = null;
                        if ($id) {
                            $ProductImage = $this->productImageRepository
                                ->findOneBy(['file_name' => $delete_image, 'Product' => $Product]);
                        } else {
                            $ProductImage = $this->productImageRepository
                                ->findOneBy(['file_name' => $delete_image]);
                        }

                        // 追加してすぐに削除した画像は、Entityに追加されない
                        if ($ProductImage instanceof ProductImage) {
                            $Product->removeProductImage($ProductImage);
                            $this->entityManager->remove($ProductImage);
                        }
                        $this->entityManager->persist($Product);

                        // 削除
                        $fs = new Filesystem();
                        $fs->remove($this->eccubeConfig['eccube_save_image_dir'].'/'.$delete_image);
                    }
                    $this->entityManager->persist($Product);
                    $this->entityManager->flush();

                    $sortNos = $request->get('sort_no_images');
                    if ($sortNos) {
                        foreach ($sortNos as $sortNo) {
                            list($filename, $sortNo_val) = explode('//', $sortNo);
                            $ProductImage = $this->productImageRepository
                                ->findOneBy([
                                    'file_name' => $filename,
                                    'Product' => $Product,
                                ]);
                            $ProductImage->setSortNo($sortNo_val);
                            $this->entityManager->persist($ProductImage);
                        }
                    }
                    $this->entityManager->flush();

                    // 商品タグの登録
                    // 商品タグを一度クリア
                    $ProductTags = $Product->getProductTag();
                    foreach ($ProductTags as $ProductTag) {
                        $Product->removeProductTag($ProductTag);
                        $this->entityManager->remove($ProductTag);
                    }
                    $this->entityManager->flush();

                    // 商品タグの登録
                    $Tags = $form->get('Tag')->getData();

                    foreach ($Tags as $Tag) {
                        $ProductTag = new ProductTag();
                        $ProductTag
                            ->setProduct($Product)
                            ->setTag($Tag);
                        $Product->addProductTag($ProductTag);
                        $this->entityManager->persist($ProductTag);
                    }
                    $this->entityManager->flush();

                    // 商品ランクの登録
                    // // 商品ランクを一度クリア
                    // $ProductRanks = $Product->getProductRank();
                    // foreach ($ProductRanks as $ProductRank) {
                    //     //$Product->removeProductRank($ProductRank);
                    //     //$this->entityManager->remove($ProductRank);
                    //     $ProductRank->setVisible(false);
                    //     $this->entityManager->flush($ProductRank);
                    // }

                    // // 商品ランクの登録
                    // $Ranks = $form->get('Rank')->getData();
                    // foreach ($Ranks as $Rank) {
                    //     $ProductRank = new ProductRank();
                    //     $ProductRank
                    //         ->setProduct($Product)
                    //         ->setRank($Rank)
                    //         ->setRankType($Rank->getRankType())
                    //         ->setPriceChange($Rank->getPriceChange())
                    //         ->setVisible(true);
                    //     $Product->addProductRank($ProductRank);
                    //     $this->entityManager->persist($ProductRank);
                    // }

                    // 価格管理情報、ランク情報を作成
                    if (!$has_class) {
                        $ProductPriceNew = null;
                        $ProductPriceOld = null;
                        foreach ($ProductClass->getProductPrices() as $ProductPrice) {
                            // 新品
                            if (is_null($ProductPrice->getParentId())) {
                                $ProductPriceNew = $ProductPrice;
                            }
                            // 中古
                            if (!is_null($ProductPrice->getParentId())) {
                                $ProductPriceOld = $ProductPrice;
                            }
                        }
                        if (is_null($ProductPriceNew)) {
                            // 新品
                            $ProductPriceRule = $this->productPriceRuleRepository->find(ProductPriceRule::RULE_DEFAULT);

                            $ProductPriceNew = new ProductPrice();
                            $ProductPriceNew->setProductClass($ProductClass);
                            $ProductPriceNew->setProductPriceRule($ProductPriceRule);
                            $ProductPriceNew->setPrice($ProductClass->getPrice02());
                            $this->entityManager->persist($ProductPriceNew);

                            // ランク情報
                            $RankType = $this->rankTypeRepository->find(RankType::RANK_TYPE_NEW);

                            $OptionNew = new \Eccube\Entity\ProductPriceOption();
                            $OptionNew->setProductClass($ProductClass);
                            $OptionNew->setRankType($RankType);
                            $OptionNew->setOptionName($RankType->getName());
                            $OptionNew->setHierarchy(1);
                            $OptionNew->setVisible(true);
                            $this->productPriceOptionRepository->save($OptionNew);
                        } else {
                            if ((!$ProductPriceNew->getPrice() > 0)) {
                                $ProductPriceNew->setPrice($ProductClass->getPrice02());
                                $this->entityManager->flush($ProductPriceNew);
                            }
                        }

                        $Product->setUpdateDate(new \DateTime());
                        $this->entityManager->flush();

                        if ($ProductClass->getPrice01() > 0 && is_null($ProductPriceOld)) {
                            // 中古
                            $ProductPriceRule = $this->productPriceRuleRepository->find(ProductPriceRule::RULE_DEFAULT);

                            $ProductPriceOld = new ProductPrice();
                            $ProductPriceOld->setProductClass($ProductClass);
                            $ProductPriceOld->setProductPriceRule($ProductPriceRule);
                            $ProductPriceOld->setPrice($ProductClass->getPrice01());
                            $ProductPriceOld->setParentId($ProductPriceNew->getId());
                            $this->entityManager->persist($ProductPriceOld);
                            log_info("ProductPriceOld", [$ProductPriceOld->getId()]);

                            // ランク情報
                            $RankType = $this->rankTypeRepository->find(RankType::RANK_TYPE_OLD);

                            $OptionOld = new \Eccube\Entity\ProductPriceOption();
                            $OptionOld->setProductClass($ProductClass);
                            $OptionOld->setRankType($RankType);
                            $OptionOld->setOptionName($RankType->getName());
                            $OptionOld->setHierarchy(1);
                            $OptionOld->setVisible(true);
                            $this->productPriceOptionRepository->save($OptionOld);
                        }

                        $Product->setUpdateDate(new \DateTime());
                        $this->entityManager->flush();
                    }

                    //  INS-START CNC 2022/12/30 シリアルFLG 有効->無効の場合、全て状態と置場の初期データ追加
                    if ($Product->getSerialFlg() == false && $dbSerialFlg == 1) {
                        $stateList = $this->stateRepository->getStateByCategory($Product->getProductCategories()->getValues()[0]->getCategory());
                        $placeList = $this->placeRepository->getList();

                        foreach ($stateList as $state) {
                            foreach ($placeList as $place) {
                                $StockListStorehouseUnit = $this->stockListStorehouseUnitRepository->findOneBy([
                                    'productCode' => $Product->getProductClasses()[0]->getCode(),
                                    'State' => $state,
                                    'Storehouse' => $place,
                                    'stockQuantity' => 0,
                                    'serialNo' => null
                                ]);

                                if (isset($StockListStorehouseUnit)) {
                                    $StockListStorehouseUnit
                                        ->setUpdateUserName($this->getUser())
                                        ->setUpdateDate(new \DateTime());

                                    $this->entityManager->persist($StockListStorehouseUnit);
                                } else {
                                    $StockListStorehouseUnit = $this->stockListStorehouseUnitRepository->findOneBy([
                                        'productCode' => $Product->getProductClasses()[0]->getCode(),
                                        'State' => $state,
                                        'Storehouse' => $place,
                                        'stockQuantity' => 0,
                                        'serialNo' => ''
                                    ]);

                                    if (isset($StockListStorehouseUnit)) {
                                        $StockListStorehouseUnit
                                            ->setUpdateUserName($this->getUser())
                                            ->setUpdateDate(new \DateTime());

                                        $this->entityManager->persist($StockListStorehouseUnit);
                                    } else {
                                        $addStockListStorehouseUnit = new StockListStorehouseUnit();

                                        $addStockListStorehouseUnit
                                            ->setProductId($Product->getId())
                                            ->setProductClass($Product->getProductClasses()[0])
                                            ->setProductCode($Product->getProductClasses()[0]->getCode())
                                            ->setSerialNo(null)
                                            ->setState($state)
                                            ->setStorehouse($place)
                                            ->setStockQuantity(0)
                                            ->setCreateUserName($this->getUser())
                                            ->setCreateDate(new \DateTime())
                                            ->setUpdateUserName($this->getUser())
                                            ->setUpdateDate(new \DateTime());

                                        $this->entityManager->persist($addStockListStorehouseUnit);
                                    }
                                }
                                $this->entityManager->flush();
                            }
                        }
                    }
                    //  INS-END CNC 2021/12/30

                    log_info('商品登録完了', [$id]);

                    $event = new EventArgs(
                        [
                            'form' => $form,
                            'Product' => $Product,
                        ],
                        $request
                    );
                    $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_EDIT_COMPLETE, $event);

                    $this->addSuccess('admin.common.save_complete', 'admin');

                    if ($returnLink = $form->get('return_link')->getData()) {
                        try {
                            // $returnLinkはpathの形式で渡される. pathが存在するかをルータでチェックする.
                            $pattern = '/^'.preg_quote($request->getBasePath(), '/').'/';
                            $returnLink = preg_replace($pattern, '', $returnLink);
                            $result = $router->match($returnLink);
                            // パラメータのみ抽出
                            $params = array_filter($result, function ($key) {
                                return 0 !== \strpos($key, '_');
                            }, ARRAY_FILTER_USE_KEY);

                            // pathからurlを再構築してリダイレクト.
                            return $this->redirectToRoute($result['_route'], $params);
                        } catch (\Exception $e) {
                            // マッチしない場合はログ出力してスキップ.
                            log_warning('URLの形式が不正です。');
                        }
                    }

                    $cacheUtil->clearDoctrineCache();

                    return $this->redirectToRoute('admin_product_product_edit', ['id' => $Product->getId()]);
               } 
           }
        }

        // 検索結果の保持
        $builder = $this->formFactory
            ->createBuilder(SearchProductType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'Product' => $Product,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_EDIT_SEARCH, $event);

        $searchForm = $builder->getForm();

        if ('POST' === $request->getMethod()) {
            $searchForm->handleRequest($request);
        }

        // Get Tags
         $TagsList = $this->tagRepository->getList();

        // Get Ranks
         $RanksList = $this->rankRepository->getList();

        // ツリー表示のため、ルートからのカテゴリを取得
        $TopCategories = $this->categoryRepository->getList(null);
        $ChoicedCategoryIds = array_map(function ($Category) {
            return $Category->getId();
        }, $form->get('Category')->getData());

        //  INS-START CNC 2021/7/13
        $TopViceCategories = $this->categoryRepository->getList(null);
        $ChoicedViceCategoryIds = array_map(function ($viceCategory) {
            return $viceCategory->getId();
        }, $form->get('viceCategory')->getData());
        //  INS-END CNC 2021/7/13

        //  INS-START CNC 2022/05/12
        $hasStockListProduct = $this->stockListProductUnitRepository->findOneBy(['productCode' => $Product->getProductClasses()[0]->getCode()]);
        $hasStockListStorehouseUnit = $this->stockListStorehouseUnitRepository->findOneBy(['productCode' => $Product->getProductClasses()[0]->getCode()]);
        if (isset($hasStockListProduct) || isset($hasStockListStorehouseUnit)) {
            $stockListFlg = 1;
        } else {
            $stockListFlg = 0;
        }
        //  INS-END CNC 2022/05/12

        return [
            'Product' => $Product,
            'Tags' => $Tags,
            'TagsList' => $TagsList,
            'Ranks' => $Ranks,
            'RanksList' => $RanksList,
            'form' => $form->createView(),
            'searchForm' => $searchForm->createView(),
            'has_class' => $has_class,
            'id' => $id,
            'TopCategories' => $TopCategories,
            'ChoicedCategoryIds' => $ChoicedCategoryIds,
            // INS-START CNC 2021/7/13
            'TopViceCategories' => $TopViceCategories,
            'ChoicedViceCategoryIds' => $ChoicedViceCategoryIds,
            // INS-END CNC 2021/7/13
            // INS-START CNC 2022/01/24
            'serialChangedAuthFlg' => $serialChangedAuthFlg,
            'dbSerialFlg' => $dbSerialFlg,
            // INS-END CNC 2022/01/24
            // INS-START CNC 2022/05/12
            'stockListFlg' => $stockListFlg,
            // INS-END CNC 2022/05/12
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/product/product/{id}/delete", requirements={"id" = "\d+"}, name="admin_product_product_delete", methods={"DELETE"})
     */
    public function delete(Request $request, $id = null, CacheUtil $cacheUtil)
    {
        $this->isTokenValid();
        $session = $request->getSession();
        $page_no = intval($session->get('eccube.admin.product.search.page_no'));
        $page_no = $page_no ? $page_no : Constant::ENABLED;
        $message = null;
        $success = false;

        if (!is_null($id)) {
            /* @var $Product \Eccube\Entity\Product */
            $Product = $this->productRepository->find($id);
            if (!$Product) {
                if ($request->isXmlHttpRequest()) {
                    $message = trans('admin.common.delete_error_already_deleted');

                    return $this->json(['success' => $success, 'message' => $message]);
                } else {
                    $this->deleteMessage();
                    $rUrl = $this->generateUrl('admin_product_page', ['page_no' => $page_no]).'?resume='.Constant::ENABLED;

                    return $this->redirect($rUrl);
                }
            }

            if ($Product instanceof Product) {
                log_info('商品削除開始', [$id]);

                $deleteImages = $Product->getProductImage();
                $ProductClasses = $Product->getProductClasses();

                try {
                    $this->productRepository->delete($Product);
                    $this->entityManager->flush();

                    $event = new EventArgs(
                        [
                            'Product' => $Product,
                            'ProductClass' => $ProductClasses,
                            'deleteImages' => $deleteImages,
                        ],
                        $request
                    );
                    $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_DELETE_COMPLETE, $event);
                    $deleteImages = $event->getArgument('deleteImages');

                    // 画像ファイルの削除(commit後に削除させる)
                    foreach ($deleteImages as $deleteImage) {
                        try {
                            $fs = new Filesystem();
                            $fs->remove($this->eccubeConfig['eccube_save_image_dir'].'/'.$deleteImage);
                        } catch (\Exception $e) {
                            // エラーが発生しても無視する
                        }
                    }

                    log_info('商品削除完了', [$id]);

                    $success = true;
                    $message = trans('admin.common.delete_complete');

                    $cacheUtil->clearDoctrineCache();
                } catch (ForeignKeyConstraintViolationException $e) {
                    log_info('商品削除エラー', [$id]);
                    $message = trans('admin.common.delete_error_foreign_key', ['%name%' => $Product->getName()]);
                }
            } else {
                log_info('商品削除エラー', [$id]);
                $message = trans('admin.common.delete_error');
            }
        } else {
            log_info('商品削除エラー', [$id]);
            $message = trans('admin.common.delete_error');
        }

        if ($request->isXmlHttpRequest()) {
            return $this->json(['success' => $success, 'message' => $message]);
        } else {
            if ($success) {
                $this->addSuccess($message, 'admin');
            } else {
                $this->addError($message, 'admin');
            }

            $rUrl = $this->generateUrl('admin_product_page', ['page_no' => $page_no]).'?resume='.Constant::ENABLED;

            return $this->redirect($rUrl);
        }
    }

    /**
     * @Route("/%eccube_admin_route%/product/product/{id}/copy", requirements={"id" = "\d+"}, name="admin_product_product_copy", methods={"POST"})
     */
    public function copy(Request $request, $id = null)
    {
        $this->isTokenValid();

        if (!is_null($id)) {
            $Product = $this->productRepository->find($id);
            if ($Product instanceof Product) {
                $CopyProduct = clone $Product;
                $CopyProduct->copy();
                $ProductStatus = $this->productStatusRepository->find(ProductStatus::DISPLAY_HIDE);
                $CopyProduct->setStatus($ProductStatus);

                $CopyProductCategories = $CopyProduct->getProductCategories();
                foreach ($CopyProductCategories as $Category) {
                    $this->entityManager->persist($Category);
                }

                // 規格あり商品の場合は, デフォルトの商品規格を取得し登録する.
                if ($CopyProduct->hasProductClass()) {
                    $dummyClass = $this->productClassRepository->findOneBy([
                        'visible' => false,
                        'ClassCategory1' => null,
                        'ClassCategory2' => null,
                        'Product' => $Product,
                    ]);
                    $dummyClass = clone $dummyClass;
                    $dummyClass->setProduct($CopyProduct);
                    $CopyProduct->addProductClass($dummyClass);
                }

                $CopyProductClasses = $CopyProduct->getProductClasses();
                foreach ($CopyProductClasses as $Class) {
                    $Stock = $Class->getProductStock();
                    $CopyStock = clone $Stock;
                    $CopyStock->setProductClass($Class);
                    $this->entityManager->persist($CopyStock);

                    $TaxRule = $Class->getTaxRule();
                    if ($TaxRule) {
                        $CopyTaxRule = clone $TaxRule;
                        $CopyTaxRule->setProductClass($Class);
                        $CopyTaxRule->setProduct($CopyProduct);
                        $this->entityManager->persist($CopyTaxRule);
                    }
                    $this->entityManager->persist($Class);
                }
                $Images = $CopyProduct->getProductImage();
                foreach ($Images as $Image) {
                    // 画像ファイルを新規作成
                    $extension = pathinfo($Image->getFileName(), PATHINFO_EXTENSION);
                    $filename = date('mdHis').uniqid('_').'.'.$extension;
                    try {
                        $fs = new Filesystem();
                        $fs->copy($this->eccubeConfig['eccube_save_image_dir'].'/'.$Image->getFileName(), $this->eccubeConfig['eccube_save_image_dir'].'/'.$filename);
                    } catch (\Exception $e) {
                        // エラーが発生しても無視する
                    }
                    $Image->setFileName($filename);

                    $this->entityManager->persist($Image);
                }
                $Tags = $CopyProduct->getProductTag();
                foreach ($Tags as $Tag) {
                    $this->entityManager->persist($Tag);
                }

                $Ranks = $CopyProduct->getProductRank();
                foreach ($Ranks as $Rank) {
                    $this->entityManager->persist($Rank);
                }

                $this->entityManager->persist($CopyProduct);

                $this->entityManager->flush();

                $event = new EventArgs(
                    [
                        'Product' => $Product,
                        'CopyProduct' => $CopyProduct,
                        'CopyProductCategories' => $CopyProductCategories,
                        'CopyProductClasses' => $CopyProductClasses,
                        'images' => $Images,
                        'Tags' => $Tags,
                        'Ranks' => $Ranks,
                    ],
                    $request
                );
                $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_COPY_COMPLETE, $event);

                $this->addSuccess('admin.product.copy_complete', 'admin');

                return $this->redirectToRoute('admin_product_product_edit', ['id' => $CopyProduct->getId()]);
            } else {
                $this->addError('admin.product.copy_error', 'admin');
            }
        } else {
            $msg = trans('admin.product.copy_error');
            $this->addError($msg, 'admin');
        }

        return $this->redirectToRoute('admin_product');
    }

    /**
     * @Route("/%eccube_admin_route%/product/product/{id}/display", requirements={"id" = "\d+"}, name="admin_product_product_display")
     */
    public function display(Request $request, $id = null)
    {
        $event = new EventArgs(
            [],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_DISPLAY_COMPLETE, $event);

        if (!is_null($id)) {
            return $this->redirectToRoute('product_detail', ['id' => $id, 'admin' => '1']);
        }

        return $this->redirectToRoute('admin_product');
    }

    /**
     * 商品CSVの出力.
     *
     * @Route("/%eccube_admin_route%/product/export", name="admin_product_export")
     * @Route("/%eccube_admin_route%/product_price/export", name="admin_product_price_export")
     *
     * @param Request $request
     *
     * @return StreamedResponse
     */
    public function export(Request $request)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        // sql loggerを無効にする.
        $em = $this->entityManager;
        $em->getConfiguration()->setSQLLogger(null);

        $response = new StreamedResponse();
        $response->setCallback(function () use ($request) {
            // CSV種別を元に初期化.
            $this->csvExportService->initCsvType(CsvType::CSV_TYPE_PRODUCT);

            // ヘッダ行の出力.
            $this->csvExportService->exportHeader();

            // 商品データ検索用のクエリビルダを取得.
             $qb = $this->csvExportService
                ->getProductQueryBuilder($request);
            if($request->getRequestUri() && strpos($request->getRequestUri(), 'product_price')){
               $qb = $this->csvExportService->getProductPriceQueryBuilder($request);
            }

            // Get stock status
            $isOutOfStock = 0;
            $session = $request->getSession();
            if ($session->has('eccube.admin.product.search')) {
                $searchData = $session->get('eccube.admin.product.search', []);
                if (isset($searchData['stock_status']) && $searchData['stock_status'] === 0) {
                    $isOutOfStock = 1;
                }
            }

            // joinする場合はiterateが使えないため, select句をdistinctする.
            // http://qiita.com/suin/items/2b1e98105fa3ef89beb7
            // distinctのmysqlとpgsqlの挙動をあわせる.
            // http://uedatakeshi.blogspot.jp/2010/04/distinct-oeder-by-postgresmysql.html
            $qb->resetDQLPart('select')
                ->resetDQLPart('orderBy')
                ->orderBy('p.update_date', 'DESC');

            if ($isOutOfStock) {
                $qb->select('p, pc')
                    ->distinct();
            } else {
                $qb->select('p')
                    ->distinct();
            }
            // データ行の出力.
            $this->csvExportService->setExportQueryBuilder($qb);

            $this->csvExportService->exportData(function ($entity, CsvExportService $csvService) use ($request) {
                $Csvs = $csvService->getCsvs();

                /** @var $Product \Eccube\Entity\Product */
                $Product = $entity;

                /** @var $ProductClasses \Eccube\Entity\ProductClass[] */
                $ProductClasses = $Product->getProductClasses();

                foreach ($ProductClasses as $ProductClass) {
                    $ProductPriceOptions = $this->getProductPriceOptionByCsv($ProductClass);
                    $ExportCsvRow = new ExportCsvRow();

                    // CSV出力項目と合致するデータを取得.
                    foreach ($Csvs as $Csv) {
                        // 商品データを検索.
                        $ExportCsvRow->setData($csvService->getData($Csv, $Product));
                        if ($ExportCsvRow->isDataNull()) {
                            // 商品規格情報を検索.
                            $ExportCsvRow->setData($csvService->getData($Csv, $ProductClass));
                        }
                        // 商品価格情報を検索.
                       if ($ExportCsvRow->isDataNull() && $Csv->getFieldName() == 'option_name') {
                           log_info('$ProductPriceOptions',[$ProductPriceOptions]);
                               if(array_key_exists($Csv->getDispName(), $ProductPriceOptions)){
                                 $ExportCsvRow->setData($ProductPriceOptions[$Csv->getDispName()]);
                               }else{
                                 $ExportCsvRow->setData(null);
                               }
                       }

                        $event = new EventArgs(
                            [
                                'csvService' => $csvService,
                                'Csv' => $Csv,
                                'ProductClass' => $ProductClass,
                                'ExportCsvRow' => $ExportCsvRow,
                            ],
                            $request
                        );
                        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_CSV_EXPORT, $event);

                        $ExportCsvRow->pushData();
                    }

                    // $row[] = number_format(memory_get_usage(true));
                    // 出力.
                    $csvService->fputcsv($ExportCsvRow->getRow());
                }
            });
        });

        $now = new \DateTime();
        $filename = 'product_'.$now->format('YmdHis').'.csv';
        $response->headers->set('Content-Type', 'application/octet-stream');
        $response->headers->set('Content-Disposition', 'attachment; filename='.$filename);
        $response->send();

        log_info('商品CSV出力ファイル名', [$filename]);

        return $response;
    }
    
    /**
     * 商品CSV登録の出力.
     *
     * @Route("/%eccube_admin_route%/product_csv/{type}/export", requirements={"type" = "\S+"},name="admin_product_csv_export")
     *
     * @param Request $request
     *
     * @return StreamedResponse
     */
    public function exportCsv(Request $request,$type)
    {
     
        // タイムアウトを無効にする.
        set_time_limit(0);

        // sql loggerを無効にする.
        $em = $this->entityManager;
        $em->getConfiguration()->setSQLLogger(null);

        $response = new StreamedResponse();
        $response->setCallback(function () use ($request,$type) {
            // CSV種別を元に初期化.
            $this->csvExportService->initCsvType(CsvType::CSV_TYPE_PRODUCT);

            // ヘッダ行の出力.
            $this->csvExportService->exportHeader();

            // 商品データ検索用のクエリビルダを取得.
            $qb = $this->csvExportService->getProductCsvQueryBuilder($type);

            // Get stock status
            //$isOutOfStock = 0;
            //$session = $request->getSession();
            //if ($session->has('eccube.admin.product.search')) {
            //    $searchData = $session->get('eccube.admin.product.search', []);
            //    if (isset($searchData['stock_status']) && $searchData['stock_status'] === 0) {
            //        $isOutOfStock = 1;
            //    }
            //}

            // joinする場合はiterateが使えないため, select句をdistinctする.
            // http://qiita.com/suin/items/2b1e98105fa3ef89beb7
            // distinctのmysqlとpgsqlの挙動をあわせる.
            // http://uedatakeshi.blogspot.jp/2010/04/distinct-oeder-by-postgresmysql.html
            //$qb->resetDQLPart('select')
            //    ->resetDQLPart('orderBy')
            //    ->orderBy('p.update_date', 'DESC');

            //if ($isOutOfStock) {
            //    $qb->select('p, pc')
            //        ->distinct();
            //} else {
                $qb->select('p')
                    ->distinct();
            //}
            // データ行の出力.
            $this->csvExportService->setExportQueryBuilder($qb);

            $this->csvExportService->exportData(function ($entity, CsvExportService $csvService) use ($request) {
                $Csvs = $csvService->getCsvs();

                /** @var $Product \Eccube\Entity\Product */
                $Product = $entity;

                /** @var $ProductClasses \Eccube\Entity\ProductClass[] */
                $ProductClasses = $Product->getProductClasses();

                foreach ($ProductClasses as $ProductClass) {
                    $ProductPriceOptions = $this-> getProductPriceOptionByCsv($ProductClass);
                    $ExportCsvRow = new ExportCsvRow();

                    // CSV出力項目と合致するデータを取得.
                    foreach ($Csvs as $Csv) {
                        // 商品データを検索.
                        $ExportCsvRow->setData($csvService->getData($Csv, $Product));
                        if ($ExportCsvRow->isDataNull()) {
                            // 商品規格情報を検索.
                            $ExportCsvRow->setData($csvService->getData($Csv, $ProductClass));
                        }

                       // 商品価格情報を検索.
                       if ($ExportCsvRow->isDataNull() && $Csv->getFieldName() == 'option_name') {
                           log_info('$ProductPriceOptions',[$ProductPriceOptions]);
                               if(array_key_exists($Csv->getDispName(), $ProductPriceOptions)){
                                 $ExportCsvRow->setData($ProductPriceOptions[$Csv->getDispName()]);
                               }else{
                                 $ExportCsvRow->setData(null);
                               }
                       }

                        $event = new EventArgs(
                            [
                                'csvService' => $csvService,
                                'Csv' => $Csv,
                                'ProductClass' => $ProductClass,
                                'ExportCsvRow' => $ExportCsvRow,
                            ],
                            $request
                        );
                        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_PRODUCT_CSV_EXPORT, $event);

                        $ExportCsvRow->pushData();
                    }

                    // $row[] = number_format(memory_get_usage(true));
                    // 出力.
                    $csvService->fputcsv($ExportCsvRow->getRow());
                }
            });
        });

        $now = new \DateTime();
        $filename = 'product_'.$now->format('YmdHis').'.csv';
        $response->headers->set('Content-Type', 'application/octet-stream');
        $response->headers->set('Content-Disposition', 'attachment; filename='.$filename);
        $response->send();

        log_info('商品CSV登録出力ファイル名', [$filename]);

        return $response;
    }

    /**
     * ProductCategory作成
     *
     * @param \Eccube\Entity\Product $Product
     * @param \Eccube\Entity\Category $Category
     * @param integer $count
     *
     * @return \Eccube\Entity\ProductCategory
     */
    private function createProductCategory($Product, $Category, $count)
    {
        $ProductCategory = new ProductCategory();
        $ProductCategory->setProduct($Product);
        $ProductCategory->setProductId($Product->getId());
        $ProductCategory->setCategory($Category);
        $ProductCategory->setCategoryId($Category->getId());

        return $ProductCategory;
    }

    // INS-START CNC 2021/7/13
    /**
     * ProductCategory作成
     *
     * @param \Eccube\Entity\Product $Product
     * @param \Eccube\Entity\Category $viceCategory
     * @param integer $count
     *
     * @return \Eccube\Entity\ProductCategory
     */
    private function createProductViceCategory($Product, $viceCategory, $count)
    {
        $ProductCategory = new ProductCategory();
        $ProductCategory->setProduct($Product);
        $ProductCategory->setProductId($Product->getId());
        $ProductCategory->setCategory($viceCategory);
        $ProductCategory->setCategoryId($viceCategory->getId());
        $ProductCategory->setCategorySubFlg(1);
        return $ProductCategory;
    }
    // INS-END CNC 2021/7/13

    /**
     * Bulk public action
     *
     * @Route("/%eccube_admin_route%/product/bulk/product-status/{id}", requirements={"id" = "\d+"}, name="admin_product_bulk_product_status", methods={"POST"})
     *
     * @param Request $request
     * @param ProductStatus $ProductStatus
     *
     * @return RedirectResponse
     */
    public function bulkProductStatus(Request $request, ProductStatus $ProductStatus, CacheUtil $cacheUtil)
    {
        $this->isTokenValid();

        /** @var Product[] $Products */
        $Products = $this->productRepository->findBy(['id' => $request->get('ids')]);
        $count = 0;
        foreach ($Products as $Product) {
            try {
                $Product->setStatus($ProductStatus);
                $this->productRepository->save($Product);
                $count++;
            } catch (\Exception $e) {
                $this->addError($e->getMessage(), 'admin');
            }
        }
        try {
            if ($count) {
                $this->entityManager->flush();
                $msg = $this->translator->trans('admin.product.bulk_change_status_complete', [
                    '%count%' => $count,
                    '%status%' => $ProductStatus->getName(),
                ]);
                $this->addSuccess($msg, 'admin');
                $cacheUtil->clearDoctrineCache();
            }
        } catch (\Exception $e) {
            $this->addError($e->getMessage(), 'admin');
        }

        return $this->redirectToRoute('admin_product', ['resume' => Constant::ENABLED]);
    }

    /**
     * @Route("/%eccube_admin_route%/product/sort_no/move", name="admin_product_sort_no_move", methods={"POST"})
     */
    public function moveSortNo(Request $request)
    {
        if (!$request->isXmlHttpRequest()) {
            throw new BadRequestHttpException();
        }

        if ($this->isTokenValid()) {
            $sortNos = $request->request->all();
            foreach ($sortNos as $productId => $sortNo) {
                /* @var $Category \Eccube\Entity\Category */
                $product = $this->productRepository
                    ->find($productId);
                $product->setSortNo($sortNo);
                $this->entityManager->persist($product);
            }
            $this->entityManager->flush();

            //$cacheUtil->clearDoctrineCache();

            return new Response();
        }
    }

     /**
     * 商品価格オプション階層を取得.
     *
     * @param 
     *
     * @return 
     */
    public function getProductPriceOptionByCsv(ProductClass $ProductClass)
    {
        $result = [];
        $parent_option_new = $ProductClass->getProductPriceOption1(RankType::RANK_TYPE_NEW);
        $parent_option_old = $ProductClass->getProductPriceOption1(RankType::RANK_TYPE_OLD);
        $parent_new_id = is_null($parent_option_new) ? null : $parent_option_new->getId();
        $parent_old_id = is_null($parent_option_old) ? null : $parent_option_old->getId();

        // 階層１
        if(($parent_new_id && is_null($parent_old_id)) || ($parent_new_id && $parent_old_id && $parent_new_id < $parent_old_id)){
              $result['価格オプション１（階層１）'] = RankType::RANK_TYPE_NEW;
        }
        if(($parent_old_id && is_null($parent_new_id)) || ($parent_new_id && $parent_old_id && $parent_new_id > $parent_old_id)){
              $result['価格オプション１（階層１）'] = RankType::RANK_TYPE_OLD;
        }

        if(array_key_exists('価格オプション１（階層１）', $result)){
              $new_loop = 0;
              if($parent_new_id){
                    // 階層2
                    $ProductPriceOptions1 = $ProductClass->getProductPriceOptions1ById(RankType::RANK_TYPE_NEW,$parent_new_id);
                    if(count($ProductPriceOptions1) > 0){
                        $loop = 1;
                        foreach ($ProductPriceOptions1 as $ProductPriceOption) {
                           //$str1 = mb_convert_kana('価格オプション'.$ProductPriceOption->getSortNo().'（階層２）', "N");
                           $str1 = mb_convert_kana('価格オプション'.$loop.'（階層２）', "N");
                           $result[$str1] = $ProductPriceOption->getOptionName();
                           //$str2 = mb_convert_kana('価格オプション'.$ProductPriceOption->getSortNo().'（階層１）', "N");
                           $str2 = mb_convert_kana('価格オプション'.$loop.'（階層１）', "N");
                           $result[$str2] = RankType::RANK_TYPE_NEW;
                           // 階層3
                           $ProductPriceOptions2 = $ProductClass->getProductPriceOptions2ById(RankType::RANK_TYPE_NEW,$ProductPriceOption->getId());
                           $index = 1;
                           foreach ($ProductPriceOptions2 as $key=>$option) {
                             //$str3 = mb_convert_kana('価格オプション'.$ProductPriceOption->getSortNo().'（階層３の'.$option->getSortNo().'）', "N");
                             $str3 = mb_convert_kana('価格オプション'.$loop.'（階層３の'.$index.'）', "N");
                             $result[$str3] = $option->getOptionName();
                             $index++;
                           }
                           $loop++;
                        }
                        $new_loop = $loop;
                    }else{
                       if($result['価格オプション１（階層１）'] == RankType::RANK_TYPE_OLD){
                           //$str1 = mb_convert_kana('価格オプション'.$parent_option_new->getSortNo().'（階層１）', "N");
                           $result['価格オプション２（階層１）'] = RankType::RANK_TYPE_NEW;
                       }else{
                           ;
                       }
                    }
              }

              if($parent_old_id){
                   // 階層2
                   $ProductPriceOptions1 = $ProductClass->getProductPriceOptions1ById(RankType::RANK_TYPE_OLD,$parent_old_id);
                   if(count($ProductPriceOptions1) > 0){
                        $loop = 1;
                        if($new_loop > 0){
                          $loop = $new_loop;
                        }

                        foreach ($ProductPriceOptions1 as $ProductPriceOption) {
                            //$str1 = mb_convert_kana('価格オプション'.$ProductPriceOption->getSortNo().'（階層２）', "N");
                            $str1 = mb_convert_kana('価格オプション'.$loop.'（階層２）', "N");
                            $result[$str1] = $ProductPriceOption->getOptionName();
                            // $str2 = mb_convert_kana('価格オプション'.$ProductPriceOption->getSortNo().'（階層１）', "N");
                            $str2 = mb_convert_kana('価格オプション'.$loop.'（階層１）', "N");
                            $result[$str2] = RankType::RANK_TYPE_OLD;
                            // 階層3
                            $ProductPriceOptions2 = $ProductClass->getProductPriceOptions2ById(RankType::RANK_TYPE_OLD,$ProductPriceOption->getId());
                            $index = 1;
                            foreach ($ProductPriceOptions2 as $option) {
                              $str3 = mb_convert_kana('価格オプション'.$loop.'（階層３の'.$index.'）', "N");
                              $result[$str3] = $option->getOptionName();
                              $index++;
                            }
                            $loop++;
                        }
                   }else{
                       if($result['価格オプション１（階層１）'] == RankType::RANK_TYPE_NEW){
                          // $str1 = mb_convert_kana('価格オプション'.$parent_option_new->getSortNo().'（階層１）', "N");
                           $result['価格オプション２（階層１）'] = RankType::RANK_TYPE_OLD;
                       }else{
                           ;
                       }
                   }
              }
         }     
         return  $result;  
     }

    /**
     * 商品存在することを判断
     *
     * @param Product
     * @param ProductClass
     *
     * @return boolean
     */
    private function isProductExists($Product,$ProductClass)
    {
       $is_product_exist = true;
       $SaleType = $ProductClass->getSaleType();
       if($SaleType && $SaleType->getId() == SaleType :: SALE_TYPE_KEITAI){
          $is_product_exist = $this->productRepository->isKetaiProductExist($Product->getId(),$Product->getName(), $ProductClass->getCode(),$ProductClass->getClassCategory1(),$ProductClass->getClassCategory2());
       }else if($SaleType && ($SaleType->getId() ==  SaleType :: SALE_TYPE_KADEN || $SaleType->getId() == SaleType :: SALE_TYPE_NITIYOUHIN)){
          $is_product_exist = $this->productRepository->isProductExists($Product->getId(),$Product->getName(), $ProductClass->getCode());
       }else{
          ;
       }
        return $is_product_exist;
    }

}