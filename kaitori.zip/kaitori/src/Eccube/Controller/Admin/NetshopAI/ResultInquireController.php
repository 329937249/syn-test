<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\NetshopAI;

use Doctrine\ORM\QueryBuilder;
use Eccube\Controller\AbstractController;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\ResultInquireType;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\NetshopaiResultRepository;
use Eccube\Repository\StockListProductUnitRepository;
use Eccube\Util\FormUtil;
use Knp\Component\Pager\Paginator;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Style\Color;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： ResultInquireController.php
 *概　　要     ： ネットショップ連動結果照会
 *作　　成     ： 2021/8/23 CNC
 */
class ResultInquireController extends AbstractController
{
    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var NetshopaiResultRepository
     */
    protected $netshopaiResultRepository;

    /**
     * @var StockListProductUnitRepository
     */
    protected $stockListProductUnitRepository;

    /**
     * ResultInquireController constructor.
     *
     * @param CategoryRepository $categoryRepository
     * @param NetshopaiResultRepository $netshopaiResultRepository
     * @param PageMaxRepository $pageMaxRepository
     */
    public function __construct(
        CategoryRepository $categoryRepository,
        NetshopaiResultRepository $netshopaiResultRepository,
        PageMaxRepository $pageMaxRepository,
        StockListProductUnitRepository $stockListProductUnitRepository
    ) {
        $this->categoryRepository = $categoryRepository;
        $this->netshopaiResultRepository = $netshopaiResultRepository;
        $this->pageMaxRepository = $pageMaxRepository;
        $this->stockListProductUnitRepository = $stockListProductUnitRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/result_inquire", name="admin_netshopAI_result_inquire")
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/result_inquire/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_netshopAI_result_inquire_page")
     * @Template("@admin/NetshopAI/result_inquire.twig")
     */
    public function index(Request $request, $page_no = null, Paginator $paginator)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        ini_set('memory_limit', '2048M');

        $builder = $this->formFactory
            ->createBuilder(ResultInquireType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_RESULT_INQUIRE_INDEX_INITIALIZE, $event);

        $searchForm = $builder->getForm();

        /**
         * ページの表示件数は, 以下の順に優先される.
         * - リクエストパラメータ
         * - セッション
         * - デフォルト値
         * また, セッションに保存する際は mtb_page_maxと照合し, 一致した場合のみ保存する.
         **/
        $page_count = $this->session->get('eccube.admin.netshopAI.search.page_count',
            $this->eccubeConfig->get('eccube_mltext_len'));

        $page_count_param = (int) $request->get('page_count');
        $pageMaxis = $this->pageMaxRepository->findAll();

        if ($page_count_param) {
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.admin.netshopAI.search.page_count', $page_count);
                    break;
                }
            }
        }

        $page_no_bk = $page_no;
        if ('POST' === $request->getMethod()) {
            $searchForm->handleRequest($request);

            if ($searchForm->isValid()) {
                /**
                 * 検索が実行された場合は, セッションに検索条件を保存する.
                 * ページ番号は最初のページ番号に初期化する.
                 */
                $page_no = 1;
                $searchData = $searchForm->getData();

                // 検索条件, ページ番号をセッションに保持.
                $this->session->set('eccube.admin.netshopAI.search', FormUtil::getViewData($searchForm));
                $this->session->set('eccube.admin.netshopAI.search.page_no', $page_no);
            } else {
                // 検索エラーの際は, 詳細検索枠を開いてエラー表示する.
                return [
                    'searchForm' => $searchForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $page_count,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.admin.netshopAI..search.page_no', (int) $page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.admin.netshopAI.search.page_no', 1);
                }
                $viewData = $this->session->get('eccube.admin.netshopAI.search', []);
                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
            } else {
                /**
                 * 初期表示の場合.
                 */
                $page_no = 1;
                // main category
                $categories = $this->categoryRepository->getList(null, false);
                $mainCategory = null;
                foreach ($categories as $Category) {
                    if ($Category && ($Category->getHierarchy() == 1)) {
                        $mainCategory = $Category;
                        break;
                    }
                }

//                if ($mainCategory) {
//                    $viewData['main_category_id'] = $mainCategory->getId();
//                }

//                if ($mainCategory) {
//                    $searchData['main_category_id'] = $mainCategory;
//                }
                $viewData["stock_auto_interlocking"] =  true;
                $viewData["stock_auto_interlocking_err"] =  true;
                $viewData["price_auto_interlocking"] =  true;
                $viewData["price_auto_interlocking_err"] =  true;
                $viewData["get_lowest_price_err"] =  true;
                $viewData["lowest_price_over_err"] =  true;

                $viewData["price_interlocking_level_1"] =  true;
                $viewData["price_interlocking_level_2"] =  true;
                $viewData["price_interlocking_level_3"] =  true;
                $viewData["stock_0"] =  true;
                $viewData["stock_1"] =  true;

                // INS-START CNC 2022/12/22 在庫連動：手動のみ、売価連動：手動のみ、ショップ売価初期データ
                $viewData["stock_manual_only"] =  false;
                $viewData["price_manual_only"] =  false;
                $viewData["netshop_price_initdata"] =  true;
                // INS-END CNC 2022/12/22

                // セッション中の検索条件, ページ番号を初期化.
                $this->session->set('eccube.admin.netshopAI.search', $viewData);
                $this->session->set('eccube.admin.netshopAI.search.page_no', $page_no);
                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
            }
        }

        $qb = '';
        $all_orders = [];
        if ('POST' === $request->getMethod() || null !== $page_no_bk){
            /** @var QueryBuilder $qb */
            $qb = $this->netshopaiResultRepository->getQueryBuilderBySearchData($searchData);
            $all_orders = $qb->getQuery()->getResult();
        }

        if (!$searchData['stock_0'] || !$searchData['stock_1']) {

            if (!$searchData['stock_0'] && !$searchData['stock_1']) {
                $all_orders = [];
            } else if (!$searchData['stock_0']) {
                foreach ($all_orders as $index => $resultInfo) {
                    $stockInfo = $this->stockListProductUnitRepository->findStockListProductUnitByKey($resultInfo['aiProduct']["productCode"], $resultInfo['aiProduct']["state"]["id"]);
                    if ($stockInfo[0]['remainingStockQuantity'] === 0) {
                        unset($all_orders[$index]);
                    }
                }
            } else {
                foreach ($all_orders as $index => $resultInfo) {
                    $stockInfo = $this->stockListProductUnitRepository->findStockListProductUnitByKey($resultInfo['aiProduct']["productCode"], $resultInfo['aiProduct']["state"]["id"]);
                    if (!($stockInfo[0]['remainingStockQuantity'] === 0)) {
                        unset($all_orders[$index]);
                    }
                }
            }
        }

        $sort_orders = $this->sortOrder($all_orders, $searchData);

        $event = new EventArgs(
            [
                'qb' => $qb,
                'searchData' => $searchData,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_RESULT_INQUIRE_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $page_count
        );

        return [
            'searchForm' => $searchForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'has_errors' => false,
            'request' => $request,
        ];
    }

    private function sortOrder($orders, $searchData){
        if($searchData['sort_by']){
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case '在庫連動':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getStockAiResult().$a->getStockAiType() > $b->getStockAiResult().$b->getStockAiType() ? -1 : 1;
                        }
                        return $a->getStockAiResult().$a->getStockAiType() < $b->getStockAiResult().$b->getStockAiType() ? -1 : 1;
                    });
                    break;
                case '売価連動':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getPriceAiResult().$a->getPriceAiType() > $b->getPriceAiResult().$b->getPriceAiType() ? -1 : 1;
                        }
                        return $a->getPriceAiResult().$a->getPriceAiType() < $b->getPriceAiResult().$b->getPriceAiType() ? -1 : 1;
                    });
                    break;
                case 'ネットショップ名':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getShop()->getName() > $b->getShop()->getName() ? -1 : 1;
                        }
                        return $a->getShop()->getName() < $b->getShop()->getName() ? -1 : 1;
                    });
                    break;
                case '商品コード':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getAiProduct()->getProductClass()->getCode() > $b->getAiProduct()->getProductClass()->getCode() ? -1 : 1;
                        }
                        return $a->getAiProduct()->getProductClass()->getCode() < $b->getAiProduct()->getProductClass()->getCode() ? -1 : 1;
                    });
                    break;
                case '状態':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getAiProduct()->getState()->getState() > $b->getAiProduct()->getState()->getState() ? -1 : 1;
                        }
                        return $a->getAiProduct()->getState()->getState() < $b->getAiProduct()->getState()->getState() ? -1 : 1;
                    });
                    break;
                case '在庫数':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getStock() > $b->getStock() ? -1 : 1;
                        }
                        return $a->getStock() < $b->getStock() ? -1 : 1;
                    });
                    break;
                case '残在庫数':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getRemainingShipmentQuantity() > $b->getRemainingShipmentQuantity() ? -1 : 1;
                        }
                        return $a->getRemainingShipmentQuantity() < $b->getRemainingShipmentQuantity() ? -1 : 1;
                    });
                    break;
                case '連動在庫数':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getAiShipmentQuantity() > $b->getAiShipmentQuantity() ? -1 : 1;
                        }
                        return $a->getAiShipmentQuantity() < $b->getAiShipmentQuantity() ? -1 : 1;
                    });
                    break;
                case '利益率':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getProfitRate() > $b->getProfitRate() ? -1 : 1;
                        }
                        return $a->getProfitRate() < $b->getProfitRate() ? -1 : 1;
                    });
                    break;
                case '粗利金額':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getGrossProfit() > $b->getGrossProfit() ? -1 : 1;
                        }
                        return $a->getGrossProfit() < $b->getGrossProfit() ? -1 : 1;
                    });
                    break;
                case '売価ランキング':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getPriceRanking() > $b->getPriceRanking() ? -1 : 1;
                        }
                        return $a->getPriceRanking() < $b->getPriceRanking() ? -1 : 1;
                    });
                    break;
            }
        }
        return $orders;
    }

    /**
     * 連動結果情報出力.
     *
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/result/xlsx", name="admin_netshopAI_result_xlsx")
     *
     * @param Request $request Request
     *
     * @return StreamedResponse
     *
     * @throws \Exception
     */
    public function xlsxExportResult(Request $request)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        ini_set('memory_limit', '2048M');

        $response = new StreamedResponse();
        $response->setCallback(function () use ($request) {

            // searchData
            $builder = $this->formFactory
                ->createBuilder(ResultInquireType::class);

            $event = new EventArgs(
                [
                    'builder' => $builder,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_RESULT_INQUIRE_INDEX_INITIALIZE, $event);

            $searchForm = $builder->getForm();

            $searchForm->handleRequest($request);

            $searchData = $searchForm->getData();

            // 明細開始行
            $count = 3;

            // xlsxファイル設定
            $xlsxPath = $this->eccubeConfig->get('eccube_html_dir').'/template/admin/assets/xlsx/連動結果照会.xlsx';
            $spreadsheet = IOFactory::load($xlsxPath);

            $qb = $this->netshopaiResultRepository->getQueryBuilderBySearchData($searchData);;
            $all_orders = $qb->getQuery()->getResult();

            if (!$searchData['stock_0'] || !$searchData['stock_1']) {

                if (!$searchData['stock_0'] && !$searchData['stock_1']) {
                    $all_orders = [];
                } else if (!$searchData['stock_0']) {
                    foreach ($all_orders as $index => $resultInfo) {
                        $stockInfo = $this->stockListProductUnitRepository->findStockListProductUnitByKey($resultInfo['aiProduct']["productCode"], $resultInfo['aiProduct']["state"]["id"]);
                        if ($stockInfo[0]['remainingStockQuantity'] === 0) {
                            unset($all_orders[$index]);
                        }
                    }
                } else {
                    foreach ($all_orders as $index => $resultInfo) {
                        $stockInfo = $this->stockListProductUnitRepository->findStockListProductUnitByKey($resultInfo['aiProduct']["productCode"], $resultInfo['aiProduct']["state"]["id"]);
                        if (!($stockInfo[0]['remainingStockQuantity'] === 0)) {
                            unset($all_orders[$index]);
                        }
                    }
                }
            }

            $xlsxDatasAll = $this->sortOrder($all_orders, $searchData);

            foreach ($xlsxDatasAll as $xlsxData) {

                $spreadsheet->setActiveSheetIndex(0)
                    ->setCellValue('C'.$count, $xlsxData->getStockAiMessage() != null ? ($xlsxData->getStockAiType() == '1' ? '自動' : '手動').'-'.$xlsxData->getStockAiMessage() : ($xlsxData->getStockAiType() == '1' ? '自動' : '手動'))
//                    ->setCellValue('D'.$count, $xlsxData->getPriceAiMessage() != null ? ($xlsxData->getPriceAiType() == '1' ? '自動' : '手動').'-'.$xlsxData->getPriceAiMessage() : ($xlsxData->getPriceAiType() == '1' ? '自動' : '手動'))
                    ->setCellValue('D'.$count, $xlsxData->getPriceAiMessage() != null ?
                        (($xlsxData->getShop()['name'] == '楽天' && $xlsxData->getAiProduct()['rakutenLowerSellingPriceSetting'] == 'true') ||
                        ($xlsxData->getShop()['name'] == 'Yahoo' && $xlsxData->getAiProduct()['yahooLowerSellingPriceSetting'] == 'true') ||
                        ($xlsxData->getShop()['name'] == 'Yahoo2' && $xlsxData->getAiProduct()['yahoo2LowerSellingPriceSetting'] == 'true') ||
                        ($xlsxData->getShop()['name'] == 'Amazon' && $xlsxData->getAiProduct()['amazonLowerSellingPriceSetting'] == 'true') ||
                        ($xlsxData->getShop()['name'] == '価格' && $xlsxData->getAiProduct()['kakakuLowerSellingPriceSetting'] == 'true')  ? '手動' : '自動').'-'.$xlsxData->getPriceAiMessage() :
                        (($xlsxData->getShop()['name'] == '楽天' && $xlsxData->getAiProduct()['rakutenLowerSellingPriceSetting'] == 'true') ||
                        ($xlsxData->getShop()['name'] == 'Yahoo' && $xlsxData->getAiProduct()['yahooLowerSellingPriceSetting'] == 'true') ||
                        ($xlsxData->getShop()['name'] == 'Yahoo2' && $xlsxData->getAiProduct()['yahoo2LowerSellingPriceSetting'] == 'true') ||
                        ($xlsxData->getShop()['name'] == 'Amazon' && $xlsxData->getAiProduct()['amazonLowerSellingPriceSetting'] == 'true') ||
                        ($xlsxData->getShop()['name'] == '価格' && $xlsxData->getAiProduct()['kakakuLowerSellingPriceSetting'] == 'true')  ? '手動' : '自動'))
                    ->setCellValue('E'.$count, $xlsxData->getShop()['name'])
                    ->setCellValue('F'.$count, "\t".$xlsxData->getAiProduct()['productClass']['code']."\t")
                    ->setCellValue('G'.$count, $xlsxData->getAiProduct()['productClass']['product']['name'])
                    ->setCellValue('H'.$count, $xlsxData->getAiProduct()['state']['state'])
                    ->setCellValue('I'.$count, $xlsxData->getAvaregePrice())
                    ->setCellValue('J'.$count, $xlsxData->getPriceAIResult() != 1 && $xlsxData->getPriceRanking() <= 1 && $xlsxData->getShopPrice() > $xlsxData->getCompetitorsSellingPrice() ? '' : $xlsxData->getShopPrice())
                    ->setCellValue('K'.$count, $xlsxData->getGrossProfit())
                    ->setCellValue('L'.$count, $xlsxData->getProfitRate() != null ? $xlsxData->getProfitRate() / 100 : '')
                    ->setCellValue('M'.$count, $xlsxData->getCompetitorsSellingPrice())
                    ->setCellValue('N'.$count, $xlsxData->getCompetitorsUrl())
                    ->setCellValue('O'.$count, $xlsxData->getLowerSellingPrice())
//                    ->setCellValue('P'.$count, $xlsxData->getPriceRanking() > 10 ? '10+位' : $xlsxData->getPriceRanking().'位')
                    ->setCellValue('Q'.$count, $xlsxData->getCompetitorsDifference())
                    ->setCellValue('R'.$count, $xlsxData->getAdjustmentRule())
                    ->setCellValue('S'.$count, $xlsxData->getUpperSellingPrice())
                    ->setCellValue('T'.$count, $xlsxData->getAiProduct()['priceInterlockingLevel']['name'])
                    ->setCellValue('U'.$count, $xlsxData->getStock())
                    ->setCellValue('V'.$count, $xlsxData->getOrderQuantity())
                    ->setCellValue('W'.$count, $xlsxData->getTempShipmentQuantity())
                    ->setCellValue('X'.$count, $xlsxData->getRemainingShipmentQuantity())
                    ->setCellValue('Y'.$count, $xlsxData->getAiShipmentQuantity());

                if ($xlsxData->getPriceRanking() != null) {
                    $spreadsheet->getActiveSheet()->setCellValue('P'.$count, $xlsxData->getPriceRanking() > 10 ? '10+位' : $xlsxData->getPriceRanking().'位');
                }

//                if ($xlsxData->getPriceAiResult() != 1) {
//                    if ($xlsxData->getPriceRanking() > 1) {
//                        $spreadsheet->getActiveSheet()->getStyle('J'.$count)->getFont()->getColor()->setARGB(Color::COLOR_RED);
//                    }
//                    elseif ($xlsxData->getShopPrice() < $xlsxData->getCompetitorsSellingPrice()) {
//                        $spreadsheet->getActiveSheet()->getStyle('J'.$count)->getFont()->getColor()->setARGB('FF00C80A');
//                    }
//                    elseif ($xlsxData->getShopPrice() == $xlsxData->getCompetitorsSellingPrice()) {
//                        $spreadsheet->getActiveSheet()->getStyle('J'.$count)->getFont()->getColor()->setARGB('FFFFA500');
//                    }
//                }

                $count = $count + 1;
            }

            $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');

            $writer->save('php://output');
        });

        $sysDate = (new \DateTime())->format('YmdHis');

        $filename = 'attachment;filename="連動商品結果照会_'.$sysDate.'.xlsx"';

        $response->headers->set('Content-Disposition', $filename);
        header("Content-Type:application/force-download");
        header("Content-Type:application/vnd.ms-excel");
        header("Content-Type:application/octet-stream");
        header("Content-Type:application/download");
        header("Pragma: no-cache");

        $response->send();

        return $response;
    }

}
