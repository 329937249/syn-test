<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\NetshopAI;

use Eccube\Controller\AbstractController;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\NetshopaiOrderUpdateHistoryType;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Util\FormUtil;
use Eccube\Util\StringUtil;
use Knp\Component\Pager\Paginator;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： NetshopaiOrderUpdateHistoryController.php
 *概　　要     ： ネットショップ在庫/受注更新履歴
 *作　　成     ： 2022/03/23 CNC
 */
class NetshopaiOrderUpdateHistoryController extends AbstractController
{
    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    public function __construct(
        PageMaxRepository $pageMaxRepository
        , ProductRepository $productRepository
    ) {
        $this->pageMaxRepository = $pageMaxRepository;
        $this->productRepository = $productRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/order_update_history", name="admin_netshopAI_order_update_history")
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/order_update_history/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_netshopAI_order_update_history_page")
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/order_update_history/product_id/{productId}", requirements={"productId" = "\d+"}, name="admin_netshopAI_order_update_history_product_id")
     * @Template("@admin/NetshopAI/order_update_history.twig")
     *
     * @param Request $request
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function index(Request $request, $page_no = null, Paginator $paginator, $productId = null)
    {
        $session = $this->session;
        $builder = $this->formFactory
            ->createBuilder(NetshopaiOrderUpdateHistoryType::class, null);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_ORDER_UPDATE_HISTORY_INDEX_INITIALIZE, $event);

        $pageMaxis = $this->pageMaxRepository->findAll();

//        $pageCount = $session->get('eccube.admin.netshopAI.search.page_count', $this->eccubeConfig['eccube_default_page_count']);
        $pageCount = $session->get('eccube.admin.netshopAI.search.page_count', $this->eccubeConfig['eccube_page_count_max']);

        $pageCountParam = $request->get('page_count');
        if ($pageCountParam && is_numeric($pageCountParam)) {
            foreach ($pageMaxis as $pageMax) {
                if ($pageCountParam == $pageMax->getName()) {
                    $pageCount = $pageMax->getName();
                    $session->set('eccube.admin.netshopAI.search.page_count', $pageCount);
                    break;
                }
            }
        }
        $form = $builder->getForm();

        $page_no_bk = $page_no;
        if ('POST' === $request->getMethod()) {
            $form->handleRequest($request);
            if ($form->isValid()) {
                $searchData = $form->getData();
                $page_no = 1;

                $session->set('eccube.admin.netshopAI.search', FormUtil::getViewData($form));
                $session->set('eccube.admin.netshopAI.search.page_no', $page_no);
            } else {
                return [
                    'form' => $form->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $pageCount,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                if ($page_no) {
                    $session->set('eccube.admin.netshopAI.search.page_no', (int) $page_no);
                } else {
                    $page_no = $session->get('eccube.admin.netshopAI.search.page_no', 1);
                }
                $viewData = $session->get('eccube.admin.netshopAI.search', []);
            } else {
                $page_no = 1;
                $viewData = FormUtil::getViewData($form);
                if ($productId == null) {
                    $viewData["update_date_end"] =  date('Y-m-d', strtotime('now'));
                    $viewData["update_date_start"] =  date('Y-m-d', strtotime('now'));
                } else {
                    $product = $this->productRepository->find($productId);
                    $productCode = $product->getProductClasses()[0]['code'];
                    $viewData["product_code"] = $productCode;
                    $viewData["update_kubun"] = '1';
                    $viewData["update_date_end"] = date('Y-m-d', strtotime('now'));
                    $viewData["update_date_start"] = date('Y-m-d', strtotime('- 6 days'));
                }

                $session->set('eccube.admin.netshopAI.search', $viewData);
                $session->set('eccube.admin.netshopAI.search.page_no', $page_no);
            }
            $searchData = FormUtil::submitAndGetData($form, $viewData);
        }

        $qb = [];
        if ('POST' === $request->getMethod() || null !== $page_no_bk){
            /** @var QueryBuilder $qb */
            $qb = $this->getSearchData($searchData);
        }

        foreach ($qb as &$orderupdate) {

            if($orderupdate['update_kubun'] === '1'){
                $orderupdate['stockchange'] = $orderupdate['order_quantity_before'] ." → " . $orderupdate['order_quantity_after'];

            }else{
                $orderupdate['stockchange'] = "( ".$orderupdate['stock'] ." - " ."( " .$orderupdate['order_quantity_rakuten']." + ".$orderupdate['order_quantity_yahoo']." + ".$orderupdate['order_quantity_yahoo2'].
                    " + ".$orderupdate['order_quantity_amazon']." + ".$orderupdate['order_quantity_kakaku']." )"." - ".$orderupdate['temp_shipment_quantity']." )"." / ".
                           "4"." = ".$orderupdate['AI_shipment_quantity'];
            }
        }

        $event = new EventArgs(
            [
                'form' => $form,
                'qb' => $qb,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_ORDER_UPDATE_HISTORY_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $qb,
            $page_no,
            $pageCount
        );
        return [
            'form' => $form->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $pageCount,
            'has_errors' => false,
        ];
    }

    /**
     * ネットショップ在庫/受注更新履歴データを取得.
     *
     * @param $searchData
     *
     * @return null|result
     */
    protected function getSearchData($searchData)
    {
        $this->entityManager->getConfiguration()->setSQLLogger(null);
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();

        $sql = '
                SELECT
                  nouh.update_kubun AS update_kubun,
                  nouh.shop_id AS shop_id,
                  nouh.product_code AS product_code ,
                  nouh.state_id AS state_id,                
                  nouh.update_date AS update_date,
                  nouh.order_quantity_before AS order_quantity_before,
                  nouh.order_quantity_after AS order_quantity_after,
                  nouh.stock AS stock,                
                  nouh.order_quantity_rakuten AS order_quantity_rakuten,
                  nouh.order_quantity_yahoo AS order_quantity_yahoo,
                  nouh.order_quantity_yahoo2 AS order_quantity_yahoo2,
                  nouh.order_quantity_amazon AS order_quantity_amazon,
                  nouh.order_quantity_kakaku AS order_quantity_kakaku,
                  nouh.temp_shipment_quantity AS temp_shipment_quantity,
                  nouh.AI_shipment_quantity AS AI_shipment_quantity,
                  uk.name AS update_kubun_name,
                  ns.name AS shop_name,
                  sa.state AS state_name,
                  pc.product_id AS product_id,
                  p.name  AS product_name               
              FROM
                  dtb_netshopAI_order_update_history nouh 
                  LEFT JOIN mtb_updatekubun uk
                  ON uk.id = nouh.update_kubun
                  LEFT JOIN mtb_netshop ns
                  ON ns.id = nouh.shop_id
                  LEFT JOIN mtb_state sa
                  ON sa.id = nouh.state_id
                  LEFT JOIN dtb_product_class pc
                  ON pc.product_code = nouh.product_code
                  LEFT JOIN dtb_product p
                  ON p.id = pc.product_id                               
                  WHERE TRUE
                 ';

        //update_kubun
        if (isset($searchData['update_kubun']) && StringUtil::isNotBlank($searchData['update_kubun'])) {
            $sql = $sql.' AND   uk.id = '.$searchData['update_kubun']['id'];
        }

        //shop_id
        if (isset($searchData['shop_id']) && StringUtil::isNotBlank($searchData['shop_id'])) {
            $sql = $sql.' AND  nouh.shop_id = '.$searchData['shop_id']['id'];
        }

        //product_code
        if (isset($searchData['product_code']) && StringUtil::isNotBlank($searchData['product_code'])) {
            $sql = $sql.' AND  nouh.product_code LIKE '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['product_code']))."%'";
        }

        //product_name
        if (isset($searchData['product_name']) && StringUtil::isNotBlank($searchData['product_name'])) {
            $sql = $sql.' AND  p.name LIKE '."'%".str_replace(['%', '_'], ['\\%', '\\_'], addslashes($searchData['product_name']))."%'";
        }

        //update_date_start
        if (isset($searchData['update_date_start']) && StringUtil::isNotBlank($searchData['update_date_start'])) {
            /** @var \DateTime $update_date_start */
            $update_date_start = $searchData['update_date_start'];
            $updateDateStart = $update_date_start->setTimezone(new \DateTimeZone('Asia/Tokyo'))
                ->format('Y-m-d H:i:s');
            $sql = $sql.' AND  nouh.update_date >= \''.$updateDateStart.'\'';
        }

        //update_date_end
        if (isset($searchData['update_date_end']) && StringUtil::isNotBlank($searchData['update_date_end'])) {
            /** @var \DateTime $update_date_end */
            $date = clone $searchData['update_date_end'];
            $date->modify('+1 days');
            $updateDateEnd = $date->setTimezone(new \DateTimeZone('Asia/Tokyo'))
                ->format('Y-m-d H:i:s');

            $sql = $sql.' AND  nouh.update_date <= \''.$updateDateEnd.'\'';
        }

        $sql = $sql.' ORDER BY 
        nouh.update_date DESC
        ,nouh.update_kubun
        ,nouh.shop_id
        ,nouh.product_code
        ,nouh.state_id
        ';

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }
}
