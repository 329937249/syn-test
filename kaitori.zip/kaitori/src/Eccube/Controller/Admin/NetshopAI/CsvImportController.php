<?php


namespace Eccube\Controller\Admin\NetshopAI;

use Eccube\Controller\Admin\AbstractCsvImportController;
use Eccube\Entity\Master\Netshop;
use Eccube\Entity\NetshopaiProductInfo;
use Eccube\Entity\NetshopaiResult;
use Eccube\Entity\Product;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\Master\NetshopRepository;
use Eccube\Repository\Master\PriceInterlockingLevelRepository;
use Eccube\Repository\NetshopaiProductInfoRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\StateRepository;
use Eccube\Util\CacheUtil;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class CsvImportController extends AbstractCsvImportController
{
    /**
     * @var ProductRepository
     */
    private $productRepository;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var StateRepository
     */
    protected $stateRepository;

    /**
     * @var PriceInterlockingLevelRepository
     */
    protected $priceInterlockingLevelRepository;

    /**
     * @var NetshopRepository
     */
    protected $netshopRepository;

    /**
     * @var ProductClassRepository
     */
    protected $productClassRepository;

    /**
     * @var NetshopaiProductInfoRepository
     */
    protected $NetshopaiProductInfoRepository;

    private $errors = [];

    public function __construct(
        CategoryRepository $categoryRepository,
        StateRepository $stateRepository,
        PriceInterlockingLevelRepository $priceInterlockingLevelRepository,
        ProductClassRepository $productClassRepository,
        NetshopRepository $NetshopRepository,
        ProductRepository $productRepository,
        NetshopaiProductInfoRepository $NetshopaiProductInfoRepository
    ) {
        $this->categoryRepository = $categoryRepository;
        $this->stateRepository = $stateRepository;
        $this->priceInterlockingLevelRepository = $priceInterlockingLevelRepository;
        $this->productClassRepository = $productClassRepository;
        $this->netshopRepository = $NetshopRepository;
        $this->productRepository = $productRepository;
        $this->NetshopaiProductInfoRepository = $NetshopaiProductInfoRepository;
    }

    /**
     * 仕入伝票CSVインポート
     *
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/netshopAI_xlsx_upload", name="admin_netshopAI_import_xlsx")
     * @param Request $request Request
     * @param CacheUtil $cache_util CacheUtil
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     * @throws \Doctrine\DBAL\ConnectionException
     */
    public function csvPayeeVoucher(Request $request, CacheUtil $cache_util)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        ini_set('memory_limit', '2048M');

        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('csv import start.');
            /** @var UploadedFile $uploaded_file */
            $uploaded_file = $request->files->get('admin_csv_import')['import_file'];
            $errorCount = 0;
            $normalCount = 0;
            // ショップ基本情報
            $rakutenNetshop = $this->netshopRepository->find(Netshop::RAKUTEN);
            $yahooNetshop = $this->netshopRepository->find(Netshop::YAHOO);
            $yahoo2Netshop = $this->netshopRepository->find(Netshop::YAHOO2);
            $amazonNetshop = $this->netshopRepository->find(Netshop::AMAZON);
            $makeshopNetshop = $this->netshopRepository->find(Netshop::KAKAKU);

            if (!empty($uploaded_file)) {
                log_info('連動商品一括登録開始');
                $spreadsheet = IOFactory::load($uploaded_file->getPathname());

                $uploadData = $spreadsheet->getSheet(0)->rangeToArray('C4:AF'.$spreadsheet->getSheet(0)->getHighestDataRow(),'',false,false);

                // データ存在チェック
                if ($uploadData[0][1] == null) {
                    $this->addErrors('データが存在しません');
                    return $this->renderWithError();
                }

                $shopName = $uploadData[0][1];

                if ($shopName == '楽天') {

                    $errorList = null;
                    foreach ($uploadData as $rowNum => $data) {

                        // 完了判断
                        if ($data[1] === null || $data[1] === '') {
                            break;
                        }

                        // 登録対象チェック
                        if ($data[0] != '〇') {
                            continue;
                        }

                        // 商品コード:必須チェック
                        $productCode = str_replace("\t", "", $data[2]);
                        $data[2] = $productCode;
                        if ($productCode == null || $productCode == '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「商品コード」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 状態ID:必須チェック
                        $stateId = $data[4];
                        if ($stateId === null || $stateId === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「状態ID」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 売価連動レベル:必須チェック
                        $productLevelId = $data[6];
                        if ($productLevelId === null || $productLevelId === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「売価連動レベル」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 在庫連動川口のみ:必須チェック
                        $stockInterlockingKawaguchiOnly = $data[7];
                        if ($stockInterlockingKawaguchiOnly === null || $stockInterlockingKawaguchiOnly === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「在庫連動川口のみ」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 在庫自動連携:必須チェック
                        $stockInterlocking = $data[15];
                        if ($stockInterlocking === null || $stockInterlocking === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「在庫自動連携」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 売価自動連携:必須チェック
                        $priceInterlocking = $data[16];
                        if ($priceInterlocking === null || $priceInterlocking === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「売価自動連携」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        if ($data[16] == '開始') {
                            // 最低売価手動設定:手動設定
                            if ($data[18] == '手動設定') {

                                // 最低売価:必須チェック
                                if ($data[19] === null || $data[19] === '') {
                                    $errorList[] = [
                                        'rowNum' => $rowNum + 1,
                                        'productCode' => $data[2] == null ? '' : $data[2],
                                        'productName' => $data[3] == null ? '' : $data[3],
                                        'state' => $data[5] == null ? '' : $data[5],
                                        'errorMessage' => trans('「最低売価手動設定：手動設定」の場合、「最低売価」が必須入力'),
                                    ];
                                    $errorCount++;
                                }
                            }
                            // 最低売価手動設定:自動設定
                            else {
                                // 送料:必須チェック
                                if ($data[21] === null || $data[21] === '') {
                                    $errorList[] = [
                                        'rowNum' => $rowNum + 1,
                                        'productCode' => $data[2] == null ? '' : $data[2],
                                        'productName' => $data[3] == null ? '' : $data[3],
                                        'state' => $data[5] == null ? '' : $data[5],
                                        'errorMessage' => trans('「最低売価手動設定：自動設定」の場合、「送料」が必須入力'),
                                    ];
                                    $errorCount++;
                                }

                                // 手数料率:必須チェック
                                if ($data[22] === null || $data[22] === '') {
                                    $errorList[] = [
                                        'rowNum' => $rowNum + 1,
                                        'productCode' => $data[2] == null ? '' : $data[2],
                                        'productName' => $data[3] == null ? '' : $data[3],
                                        'state' => $data[5] == null ? '' : $data[5],
                                        'errorMessage' => trans('「最低売価手動設定：自動設定」の場合、「手数料率」が必須入力'),
                                    ];
                                    $errorCount++;
                                }

                                // 最低利益率:必須チェック
                                if ($data[23] === null || $data[23] === '') {

                                    if (!($data[24] === null || $data[24] === '') && !($data[12] === null || $data[12] === '')) {
                                        $data[23] = number_format($data[24]/$data[12], 4);
                                    } else {
                                        $errorList[] = [
                                            'rowNum' => $rowNum + 1,
                                            'productCode' => $data[2] == null ? '' : $data[2],
                                            'productName' => $data[3] == null ? '' : $data[3],
                                            'state' => $data[5] == null ? '' : $data[5],
                                            'errorMessage' => trans('「最低売価手動設定：自動設定」の場合、「最低利益率」が必須入力'),
                                        ];
                                        $errorCount++;
                                    }
                                }

                                // 粗利金額:必須チェック
                                if ($data[24] === null || $data[24] === '') {
                                    $errorList[] = [
                                        'rowNum' => $rowNum + 1,
                                        'productCode' => $data[2] == null ? '' : $data[2],
                                        'productName' => $data[3] == null ? '' : $data[3],
                                        'state' => $data[5] == null ? '' : $data[5],
                                        'errorMessage' => trans('「最低売価手動設定：自動設定」の場合、「粗利金額」が必須入力'),
                                    ];
                                    $errorCount++;
                                }
                            }

                            // 上限売価:必須チェック
                            if ($data[20] === null || $data[20] === '') {
                                $errorList[] = [
                                    'rowNum' => $rowNum + 1,
                                    'productCode' => $data[2] == null ? '' : $data[2],
                                    'productName' => $data[3] == null ? '' : $data[3],
                                    'state' => $data[5] == null ? '' : $data[5],
                                    'errorMessage' => trans('「上限売価」が必須入力'),
                                ];
                                $errorCount++;
                            }

                            // 調整ルール:必須チェック
                            if ($data[25] === null || $data[25] === '') {
                                $errorList[] = [
                                    'rowNum' => $rowNum + 1,
                                    'productCode' => $data[2] == null ? '' : $data[2],
                                    'productName' => $data[3] == null ? '' : $data[3],
                                    'state' => $data[5] == null ? '' : $data[5],
                                    'errorMessage' => trans('「調整ルール」が必須入力'),
                                ];
                                $errorCount++;
                            }

                            // 売価調査下限価格除外:必須チェック
                            if ($data[26] === null || $data[26] === '') {
                                $errorList[] = [
                                    'rowNum' => $rowNum + 1,
                                    'productCode' => $data[2] == null ? '' : $data[2],
                                    'productName' => $data[3] == null ? '' : $data[3],
                                    'state' => $data[5] == null ? '' : $data[5],
                                    'errorMessage' => trans('「売価調査下限価格除外」が必須入力'),
                                ];
                                $errorCount++;
                            }
                        }

                        // 「商品クラスマスタ」チェック
                        $productClass = $this->productClassRepository->findOneBy(['code' => $productCode]);
                        if (empty($productClass)) {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「商品クラスマスタ」に対応商品コードがありません'),
                            ];
                            $errorCount++;
                        }

                        // 「状態マスタ」チェック
                        $stateInfo = $this->stateRepository->find($stateId);
                        if (empty($stateInfo)) {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「状態マスタ」に対応状態がありません'),
                            ];
                            $errorCount++;
                        }

                        // 「売価連動レベルマスタ」チェック
                        $productLevelInfo = $this->priceInterlockingLevelRepository->find($productLevelId);
                        if (empty($productLevelInfo)) {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「売価連動レベルマスタ」に対応レベルがありません'),
                            ];
                            $errorCount++;
                        }

                        // エラーなし場合、データを更新する。
                        if ($errorCount == 0) {

                            $insertFlg = false;

                            $netshopAIProductInfo = $this->NetshopaiProductInfoRepository->findOneBy([
                                'productCode' => $productCode,
                                'state' => $stateId,
                            ]);

                            // 新規の場合
                            if ($netshopAIProductInfo == null){

                                $insertFlg = true;
                                $netshopAIProductInfo = new NetshopaiProductInfo();

                                $netshopAIProductInfo->setProductCode($productCode);
                                $netshopAIProductInfo->setState($stateInfo);
                                $netshopAIProductInfo->setProductClass($productClass);

                                $netshopAIProductInfo->setRakutenOrderCsvInitQuantity(0);
                                $netshopAIProductInfo->setYahooOrderCsvInitQuantity(0);
                                $netshopAIProductInfo->setYahoo2OrderCsvInitQuantity(0);
                                $netshopAIProductInfo->setAmazonOrderCsvInitQuantity(0);
                                $netshopAIProductInfo->setKakakuOrderCsvInitQuantity(0);

                                $netshopAIProductInfo->setCreateUserName($this->getUser());
                                $netshopAIProductInfo->setUpdateUserName($this->getUser());
                            } else {
                                $netshopAIProductInfo->setUpdateUserName($this->getUser());
                            }

                            $netshopAIProductInfo->setPriceInterlockingLevel($productLevelInfo);
                            $netshopAIProductInfo->setStockInterlockingKawaguchiOnly($data[7] == '開始' ? true : false);
                            $netshopAIProductInfo->setRakutenShopKey($data[13]);
                            $netshopAIProductInfo->setRakutenProductCode($data[14]);
                            $netshopAIProductInfo->setRakutenStockInterlocking($data[15] == '開始' ? true : false);
                            $netshopAIProductInfo->setRakutenPriceInterlocking($data[16] == '開始' ? true : false);
                            $netshopAIProductInfo->setRakutenPostageFreeFlag($data[17] == 'すべての商品' ? false : true);
                            $netshopAIProductInfo->setRakutenLowerSellingPriceSetting($data[18] == '手動設定' ? true : false);
                            $netshopAIProductInfo->setRakutenLowerSellingPrice($data[18] == '手動設定' ? $data[19] : 0);
                            // INS-START CNC  2022/04/28 平均単価率利用フラグと平均単価率を追加する
                            $netshopAIProductInfo->setRakutenAverageUnitPriceRateFlg(false);
                            $netshopAIProductInfo->setRakutenAverageUnitPriceRate(100);
                            // INS-END CNC
                            $netshopAIProductInfo->setRakutenUpperSellingPrice(empty($data[20]) ? 0 : $data[20]);
                            $netshopAIProductInfo->setRakutenPostage(empty($data[21]) ? 0 : $data[21]);
                            $netshopAIProductInfo->setRakutenCommissionRate(empty($data[22]) ? 0 : $data[22]*100);
                            $netshopAIProductInfo->setRakutenLowerProfitRate(empty($data[23]) ? 0 : $data[23]*100);
                            $netshopAIProductInfo->setRakutenGrossProfit(empty($data[24]) ? 0 : $data[24]);
                            $netshopAIProductInfo->setRakutenAdjustmentRule(empty($data[25]) ? 0 : $data[25]);
                            $netshopAIProductInfo->setRakutenLowestSellingPrice(empty($data[26]) ? 0 : $data[26]);
                            $netshopAIProductInfo->setRakutenKeyword($data[27]);
                            $netshopAIProductInfo->setRakutenExcludedShop($data[28]);
                            $netshopAIProductInfo->setRakutenExcludedKeyword($data[29]);

                            $this->entityManager->persist($netshopAIProductInfo);
                            $this->entityManager->flush();

                            // 新規の場合
                            if ($insertFlg) {
                                // ネットショップ連動結果も新規
                                $this->createNetshopaiResult($netshopAIProductInfo, $rakutenNetshop, $yahooNetshop, $yahoo2Netshop, $amazonNetshop, $makeshopNetshop);
                                $this->entityManager->flush();
                            }

                            $normalCount++;

                        }
                        // エラーがある場合、チェック続行。（ループ後、rollbackが必要です）
                        else {
                            continue;
                        }
                    }

                }
                else if ($shopName == 'Yahoo') {

                    $errorList = null;
                    foreach ($uploadData as $rowNum => $data) {

                        // 完了判断
                        if ($data[1] === null || $data[1] === '') {
                            break;
                        }

                        // 登録対象チェック
                        if ($data[0] != '〇') {
                            continue;
                        }

                        // 商品コード:必須チェック
                        $productCode = str_replace("\t", "", $data[2]);
                        $data[2] = $productCode;
                        if ($productCode == null || $productCode == '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「商品コード」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 状態ID:必須チェック
                        $stateId = $data[4];
                        if ($stateId === null || $stateId === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「状態ID」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 売価連動レベル:必須チェック
                        $productLevelId = $data[6];
                        if ($productLevelId === null || $productLevelId === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「売価連動レベル」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 在庫連動川口のみ:必須チェック
                        $stockInterlockingKawaguchiOnly = $data[7];
                        if ($stockInterlockingKawaguchiOnly === null || $stockInterlockingKawaguchiOnly === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「在庫連動川口のみ」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 在庫自動連携:必須チェック
                        $stockInterlocking = $data[15];
                        if ($stockInterlocking === null || $stockInterlocking === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「在庫自動連携」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 売価自動連携:必須チェック
                        $priceInterlocking = $data[16];
                        if ($priceInterlocking === null || $priceInterlocking === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「売価自動連携」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        if ($data[16] == '開始') {
                            // 最低売価手動設定:手動設定
                            if ($data[18] == '手動設定') {

                                // 最低売価:必須チェック
                                if ($data[19] === null || $data[19] === '') {
                                    $errorList[] = [
                                        'rowNum' => $rowNum + 1,
                                        'productCode' => $data[2] == null ? '' : $data[2],
                                        'productName' => $data[3] == null ? '' : $data[3],
                                        'state' => $data[5] == null ? '' : $data[5],
                                        'errorMessage' => trans('「最低売価手動設定：手動設定」の場合、「最低売価」が必須入力'),
                                    ];
                                    $errorCount++;
                                }
                            }
                            // 最低売価手動設定:自動設定
                            else {
                                // 送料:必須チェック
                                if ($data[21] === null || $data[21] === '') {
                                    $errorList[] = [
                                        'rowNum' => $rowNum + 1,
                                        'productCode' => $data[2] == null ? '' : $data[2],
                                        'productName' => $data[3] == null ? '' : $data[3],
                                        'state' => $data[5] == null ? '' : $data[5],
                                        'errorMessage' => trans('「最低売価手動設定：自動設定」の場合、「送料」が必須入力'),
                                    ];
                                    $errorCount++;
                                }

                                // 手数料率:必須チェック
                                if ($data[22] === null || $data[22] === '') {
                                    $errorList[] = [
                                        'rowNum' => $rowNum + 1,
                                        'productCode' => $data[2] == null ? '' : $data[2],
                                        'productName' => $data[3] == null ? '' : $data[3],
                                        'state' => $data[5] == null ? '' : $data[5],
                                        'errorMessage' => trans('「最低売価手動設定：自動設定」の場合、「手数料率」が必須入力'),
                                    ];
                                    $errorCount++;
                                }

                                // 最低利益率:必須チェック
                                if ($data[23] === null || $data[23] === '') {

                                    if (!($data[24] === null || $data[24] === '') && !($data[12] === null || $data[12] === '')) {
                                        $data[23] = number_format($data[24]/$data[12], 4);
                                    } else {
                                        $errorList[] = [
                                            'rowNum' => $rowNum + 1,
                                            'productCode' => $data[2] == null ? '' : $data[2],
                                            'productName' => $data[3] == null ? '' : $data[3],
                                            'state' => $data[5] == null ? '' : $data[5],
                                            'errorMessage' => trans('「最低売価手動設定：自動設定」の場合、「最低利益率」が必須入力'),
                                        ];
                                        $errorCount++;
                                    }
                                }

                                // 粗利金額:必須チェック
                                if ($data[24] === null || $data[24] === '') {
                                    $errorList[] = [
                                        'rowNum' => $rowNum + 1,
                                        'productCode' => $data[2] == null ? '' : $data[2],
                                        'productName' => $data[3] == null ? '' : $data[3],
                                        'state' => $data[5] == null ? '' : $data[5],
                                        'errorMessage' => trans('「最低売価手動設定：自動設定」の場合、「粗利金額」が必須入力'),
                                    ];
                                    $errorCount++;
                                }
                            }

                            // 上限売価:必須チェック
                            if ($data[20] === null || $data[20] === '') {
                                $errorList[] = [
                                    'rowNum' => $rowNum + 1,
                                    'productCode' => $data[2] == null ? '' : $data[2],
                                    'productName' => $data[3] == null ? '' : $data[3],
                                    'state' => $data[5] == null ? '' : $data[5],
                                    'errorMessage' => trans('「上限売価」が必須入力'),
                                ];
                                $errorCount++;
                            }

                            // 調整ルール:必須チェック
                            if ($data[25] === null || $data[25] === '') {
                                $errorList[] = [
                                    'rowNum' => $rowNum + 1,
                                    'productCode' => $data[2] == null ? '' : $data[2],
                                    'productName' => $data[3] == null ? '' : $data[3],
                                    'state' => $data[5] == null ? '' : $data[5],
                                    'errorMessage' => trans('「調整ルール」が必須入力'),
                                ];
                                $errorCount++;
                            }

                            // 売価調査下限価格除外:必須チェック
                            if ($data[26] === null || $data[26] === '') {
                                $errorList[] = [
                                    'rowNum' => $rowNum + 1,
                                    'productCode' => $data[2] == null ? '' : $data[2],
                                    'productName' => $data[3] == null ? '' : $data[3],
                                    'state' => $data[5] == null ? '' : $data[5],
                                    'errorMessage' => trans('「売価調査下限価格除外」が必須入力'),
                                ];
                                $errorCount++;
                            }
                        }

                        // 「商品クラスマスタ」チェック
                        $productClass = $this->productClassRepository->findOneBy(['code' => $productCode]);
                        if (empty($productClass)) {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「商品クラスマスタ」に対応商品コードがありません'),
                            ];
                            $errorCount++;
                        }

                        // 「状態マスタ」チェック
                        $stateInfo = $this->stateRepository->find($stateId);
                        if (empty($stateInfo)) {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「状態マスタ」に対応状態がありません'),
                            ];
                            $errorCount++;
                        }

                        // 「売価連動レベルマスタ」チェック
                        $productLevelInfo = $this->priceInterlockingLevelRepository->find($productLevelId);
                        if (empty($productLevelInfo)) {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「売価連動レベルマスタ」に対応レベルがありません'),
                            ];
                            $errorCount++;
                        }

                        // エラーなし場合、データを更新する。
                        if ($errorCount == 0) {

                            $insertFlg = false;

                            $netshopAIProductInfo = $this->NetshopaiProductInfoRepository->findOneBy([
                                'productCode' => $productCode,
                                'state' => $stateId,
                            ]);

                            // 新規の場合
                            if ($netshopAIProductInfo == null){

                                $insertFlg = true;
                                $netshopAIProductInfo = new NetshopaiProductInfo();

                                $netshopAIProductInfo->setProductCode($productCode);
                                $netshopAIProductInfo->setState($stateInfo);
                                $netshopAIProductInfo->setProductClass($productClass);

                                $netshopAIProductInfo->setRakutenOrderCsvInitQuantity(0);
                                $netshopAIProductInfo->setYahooOrderCsvInitQuantity(0);
                                $netshopAIProductInfo->setYahoo2OrderCsvInitQuantity(0);
                                $netshopAIProductInfo->setAmazonOrderCsvInitQuantity(0);
                                $netshopAIProductInfo->setKakakuOrderCsvInitQuantity(0);

                                $netshopAIProductInfo->setCreateUserName($this->getUser());
                                $netshopAIProductInfo->setUpdateUserName($this->getUser());
                            } else {
                                $netshopAIProductInfo->setUpdateUserName($this->getUser());
                            }

                            $netshopAIProductInfo->setPriceInterlockingLevel($productLevelInfo);
                            $netshopAIProductInfo->setStockInterlockingKawaguchiOnly($data[7] == '開始' ? true : false);
                            $netshopAIProductInfo->setYahooShopKey($data[13]);
                            $netshopAIProductInfo->setYahooProductCode($data[14]);
                            $netshopAIProductInfo->setYahooStockInterlocking($data[15] == '開始' ? true : false);
                            $netshopAIProductInfo->setYahooPriceInterlocking($data[16] == '開始' ? true : false);
                            $netshopAIProductInfo->setYahooPostageFreeFlag($data[17] == 'すべての商品' ? false : true);
                            $netshopAIProductInfo->setYahooLowerSellingPriceSetting($data[18] == '手動設定' ? true : false);
                            // INS-START CNC  2022/04/28 平均単価率利用フラグと平均単価率を追加する
                            $netshopAIProductInfo->setYahooAverageUnitPriceRateFlg(false);
                            $netshopAIProductInfo->setYahooAverageUnitPriceRate(100);
                            // INS-END CNC
                            $netshopAIProductInfo->setYahooLowerSellingPrice($data[18] == '手動設定' ? $data[19] : 0);
                            $netshopAIProductInfo->setYahooUpperSellingPrice(empty($data[20]) ? 0 : $data[20]);
                            $netshopAIProductInfo->setYahooPostage(empty($data[21]) ? 0 : $data[21]);
                            $netshopAIProductInfo->setYahooCommissionRate(empty($data[22]) ? 0 : $data[22]*100);
                            $netshopAIProductInfo->setYahooLowerProfitRate(empty($data[23]) ? 0 : $data[23]*100);
                            $netshopAIProductInfo->setYahooGrossProfit(empty($data[24]) ? 0 : $data[24]);
                            $netshopAIProductInfo->setYahooAdjustmentRule(empty($data[25]) ? 0 : $data[25]);
                            $netshopAIProductInfo->setYahooLowestSellingPrice(empty($data[26]) ? 0 : $data[26]);
                            $netshopAIProductInfo->setYahooKeyword($data[27]);
                            $netshopAIProductInfo->setYahooExcludedShop($data[28]);
                            $netshopAIProductInfo->setYahooExcludedKeyword($data[29]);

                            $this->entityManager->persist($netshopAIProductInfo);
                            $this->entityManager->flush();

                            // 新規の場合
                            if ($insertFlg) {
                                // ネットショップ連動結果も新規
                                $this->createNetshopaiResult($netshopAIProductInfo, $rakutenNetshop, $yahooNetshop, $yahoo2Netshop, $amazonNetshop, $makeshopNetshop);
                                $this->entityManager->flush();
                            }

                            $normalCount++;

                        }
                        // エラーがある場合、チェック続行。（ループ後、rollbackが必要です）
                        else {
                            continue;
                        }
                    }

                }
                else if ($shopName == 'Yahoo2') {

                    $errorList = null;
                    foreach ($uploadData as $rowNum => $data) {

                        // 完了判断
                        if ($data[1] === null || $data[1] === '') {
                            break;
                        }

                        // 登録対象チェック
                        if ($data[0] != '〇') {
                            continue;
                        }

                        // 商品コード:必須チェック
                        $productCode = str_replace("\t", "", $data[2]);
                        $data[2] = $productCode;
                        if ($productCode == null || $productCode == '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「商品コード」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 状態ID:必須チェック
                        $stateId = $data[4];
                        if ($stateId === null || $stateId === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「状態ID」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 売価連動レベル:必須チェック
                        $productLevelId = $data[6];
                        if ($productLevelId === null || $productLevelId === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「売価連動レベル」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 在庫連動川口のみ:必須チェック
                        $stockInterlockingKawaguchiOnly = $data[7];
                        if ($stockInterlockingKawaguchiOnly === null || $stockInterlockingKawaguchiOnly === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「在庫連動川口のみ」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 在庫自動連携:必須チェック
                        $stockInterlocking = $data[15];
                        if ($stockInterlocking === null || $stockInterlocking === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「在庫自動連携」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 売価自動連携:必須チェック
                        $priceInterlocking = $data[16];
                        if ($priceInterlocking === null || $priceInterlocking === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「売価自動連携」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        if ($data[16] == '開始') {
                            // 最低売価手動設定:手動設定
                            if ($data[18] == '手動設定') {

                                // 最低売価:必須チェック
                                if ($data[19] === null || $data[19] === '') {
                                    $errorList[] = [
                                        'rowNum' => $rowNum + 1,
                                        'productCode' => $data[2] == null ? '' : $data[2],
                                        'productName' => $data[3] == null ? '' : $data[3],
                                        'state' => $data[5] == null ? '' : $data[5],
                                        'errorMessage' => trans('「最低売価手動設定：手動設定」の場合、「最低売価」が必須入力'),
                                    ];
                                    $errorCount++;
                                }
                            }
                            // 最低売価手動設定:自動設定
                            else {
                                // 送料:必須チェック
                                if ($data[21] === null || $data[21] === '') {
                                    $errorList[] = [
                                        'rowNum' => $rowNum + 1,
                                        'productCode' => $data[2] == null ? '' : $data[2],
                                        'productName' => $data[3] == null ? '' : $data[3],
                                        'state' => $data[5] == null ? '' : $data[5],
                                        'errorMessage' => trans('「最低売価手動設定：自動設定」の場合、「送料」が必須入力'),
                                    ];
                                    $errorCount++;
                                }

                                // 手数料率:必須チェック
                                if ($data[22] === null || $data[22] === '') {
                                    $errorList[] = [
                                        'rowNum' => $rowNum + 1,
                                        'productCode' => $data[2] == null ? '' : $data[2],
                                        'productName' => $data[3] == null ? '' : $data[3],
                                        'state' => $data[5] == null ? '' : $data[5],
                                        'errorMessage' => trans('「最低売価手動設定：自動設定」の場合、「手数料率」が必須入力'),
                                    ];
                                    $errorCount++;
                                }

                                // 最低利益率:必須チェック
                                if ($data[23] === null || $data[23] === '') {

                                    if (!($data[24] === null || $data[24] === '') && !($data[12] === null || $data[12] === '')) {
                                        $data[23] = number_format($data[24]/$data[12], 4);
                                    } else {
                                        $errorList[] = [
                                            'rowNum' => $rowNum + 1,
                                            'productCode' => $data[2] == null ? '' : $data[2],
                                            'productName' => $data[3] == null ? '' : $data[3],
                                            'state' => $data[5] == null ? '' : $data[5],
                                            'errorMessage' => trans('「最低売価手動設定：自動設定」の場合、「最低利益率」が必須入力'),
                                        ];
                                        $errorCount++;
                                    }
                                }

                                // 粗利金額:必須チェック
                                if ($data[24] === null || $data[24] === '') {
                                    $errorList[] = [
                                        'rowNum' => $rowNum + 1,
                                        'productCode' => $data[2] == null ? '' : $data[2],
                                        'productName' => $data[3] == null ? '' : $data[3],
                                        'state' => $data[5] == null ? '' : $data[5],
                                        'errorMessage' => trans('「最低売価手動設定：自動設定」の場合、「粗利金額」が必須入力'),
                                    ];
                                    $errorCount++;
                                }
                            }

                            // 上限売価:必須チェック
                            if ($data[20] === null || $data[20] === '') {
                                $errorList[] = [
                                    'rowNum' => $rowNum + 1,
                                    'productCode' => $data[2] == null ? '' : $data[2],
                                    'productName' => $data[3] == null ? '' : $data[3],
                                    'state' => $data[5] == null ? '' : $data[5],
                                    'errorMessage' => trans('「上限売価」が必須入力'),
                                ];
                                $errorCount++;
                            }

                            // 調整ルール:必須チェック
                            if ($data[25] === null || $data[25] === '') {
                                $errorList[] = [
                                    'rowNum' => $rowNum + 1,
                                    'productCode' => $data[2] == null ? '' : $data[2],
                                    'productName' => $data[3] == null ? '' : $data[3],
                                    'state' => $data[5] == null ? '' : $data[5],
                                    'errorMessage' => trans('「調整ルール」が必須入力'),
                                ];
                                $errorCount++;
                            }

                            // 売価調査下限価格除外:必須チェック
                            if ($data[26] === null || $data[26] === '') {
                                $errorList[] = [
                                    'rowNum' => $rowNum + 1,
                                    'productCode' => $data[2] == null ? '' : $data[2],
                                    'productName' => $data[3] == null ? '' : $data[3],
                                    'state' => $data[5] == null ? '' : $data[5],
                                    'errorMessage' => trans('「売価調査下限価格除外」が必須入力'),
                                ];
                                $errorCount++;
                            }
                        }

                        // 「商品クラスマスタ」チェック
                        $productClass = $this->productClassRepository->findOneBy(['code' => $productCode]);
                        if (empty($productClass)) {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「商品クラスマスタ」に対応商品コードがありません'),
                            ];
                            $errorCount++;
                        }

                        // 「状態マスタ」チェック
                        $stateInfo = $this->stateRepository->find($stateId);
                        if (empty($stateInfo)) {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「状態マスタ」に対応状態がありません'),
                            ];
                            $errorCount++;
                        }

                        // 「売価連動レベルマスタ」チェック
                        $productLevelInfo = $this->priceInterlockingLevelRepository->find($productLevelId);
                        if (empty($productLevelInfo)) {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「売価連動レベルマスタ」に対応レベルがありません'),
                            ];
                            $errorCount++;
                        }

                        // エラーなし場合、データを更新する。
                        if ($errorCount == 0) {

                            $insertFlg = false;

                            $netshopAIProductInfo = $this->NetshopaiProductInfoRepository->findOneBy([
                                'productCode' => $productCode,
                                'state' => $stateId,
                            ]);

                            // 新規の場合
                            if ($netshopAIProductInfo == null){

                                $insertFlg = true;
                                $netshopAIProductInfo = new NetshopaiProductInfo();

                                $netshopAIProductInfo->setProductCode($productCode);
                                $netshopAIProductInfo->setState($stateInfo);
                                $netshopAIProductInfo->setProductClass($productClass);

                                $netshopAIProductInfo->setRakutenOrderCsvInitQuantity(0);
                                $netshopAIProductInfo->setYahooOrderCsvInitQuantity(0);
                                $netshopAIProductInfo->setYahoo2OrderCsvInitQuantity(0);
                                $netshopAIProductInfo->setAmazonOrderCsvInitQuantity(0);
                                $netshopAIProductInfo->setKakakuOrderCsvInitQuantity(0);

                                $netshopAIProductInfo->setCreateUserName($this->getUser());
                                $netshopAIProductInfo->setUpdateUserName($this->getUser());
                            } else {
                                $netshopAIProductInfo->setUpdateUserName($this->getUser());
                            }

                            $netshopAIProductInfo->setPriceInterlockingLevel($productLevelInfo);
                            $netshopAIProductInfo->setStockInterlockingKawaguchiOnly($data[7] == '開始' ? true : false);
                            $netshopAIProductInfo->setYahoo2ShopKey($data[13]);
                            $netshopAIProductInfo->setYahoo2ProductCode($data[14]);
                            $netshopAIProductInfo->setYahoo2StockInterlocking($data[15] == '開始' ? true : false);
                            $netshopAIProductInfo->setYahoo2PriceInterlocking($data[16] == '開始' ? true : false);
                            $netshopAIProductInfo->setYahoo2PostageFreeFlag($data[17] == 'すべての商品' ? false : true);
                            $netshopAIProductInfo->setYahoo2LowerSellingPriceSetting($data[18] == '手動設定' ? true : false);
                            $netshopAIProductInfo->setYahoo2AverageUnitPriceRateFlg(false);
                            $netshopAIProductInfo->setYahoo2AverageUnitPriceRate(100);
                            $netshopAIProductInfo->setYahoo2LowerSellingPrice($data[18] == '手動設定' ? $data[19] : 0);
                            $netshopAIProductInfo->setYahoo2UpperSellingPrice(empty($data[20]) ? 0 : $data[20]);
                            $netshopAIProductInfo->setYahoo2Postage(empty($data[21]) ? 0 : $data[21]);
                            $netshopAIProductInfo->setYahoo2CommissionRate(empty($data[22]) ? 0 : $data[22]*100);
                            $netshopAIProductInfo->setYahoo2LowerProfitRate(empty($data[23]) ? 0 : $data[23]*100);
                            $netshopAIProductInfo->setYahoo2GrossProfit(empty($data[24]) ? 0 : $data[24]);
                            $netshopAIProductInfo->setYahoo2AdjustmentRule(empty($data[25]) ? 0 : $data[25]);
                            $netshopAIProductInfo->setYahoo2LowestSellingPrice(empty($data[26]) ? 0 : $data[26]);
                            $netshopAIProductInfo->setYahoo2Keyword($data[27]);
                            $netshopAIProductInfo->setYahoo2ExcludedShop($data[28]);
                            $netshopAIProductInfo->setYahoo2ExcludedKeyword($data[29]);

                            $this->entityManager->persist($netshopAIProductInfo);
                            $this->entityManager->flush();

                            // 新規の場合
                            if ($insertFlg) {
                                // ネットショップ連動結果も新規
                                $this->createNetshopaiResult($netshopAIProductInfo, $rakutenNetshop, $yahooNetshop, $yahoo2Netshop, $amazonNetshop, $makeshopNetshop);
                                $this->entityManager->flush();
                            }

                            $normalCount++;

                        }
                        // エラーがある場合、チェック続行。（ループ後、rollbackが必要です）
                        else {
                            continue;
                        }
                    }

                }
                else if ($shopName == 'Amazon') {

                    $errorList = null;
                    foreach ($uploadData as $rowNum => $data) {

                        // 完了判断
                        if ($data[1] === null || $data[1] === '') {
                            break;
                        }

                        // 登録対象チェック
                        if ($data[0] != '〇') {
                            continue;
                        }

                        // 商品コード:必須チェック
                        $productCode = str_replace("\t", "", $data[2]);
                        $data[2] = $productCode;
                        if ($productCode == null || $productCode == '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「商品コード」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 状態ID:必須チェック
                        $stateId = $data[4];
                        if ($stateId === null || $stateId === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「状態ID」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 売価連動レベル:必須チェック
                        $productLevelId = $data[6];
                        if ($productLevelId === null || $productLevelId === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「売価連動レベル」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 在庫連動川口のみ:必須チェック
                        $stockInterlockingKawaguchiOnly = $data[7];
                        if ($stockInterlockingKawaguchiOnly === null || $stockInterlockingKawaguchiOnly === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「在庫連動川口のみ」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 在庫自動連携:必須チェック
                        $stockInterlocking = $data[16];
                        if ($stockInterlocking === null || $stockInterlocking === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「在庫自動連携」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 売価自動連携:必須チェック
                        $priceInterlocking = $data[17];
                        if ($priceInterlocking === null || $priceInterlocking === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「売価自動連携」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        if ($data[17] == '開始') {
                            // 最低売価手動設定:手動設定
                            if ($data[18] == '手動設定') {

                                // 最低売価:必須チェック
                                if ($data[19] === null || $data[19] === '') {
                                    $errorList[] = [
                                        'rowNum' => $rowNum + 1,
                                        'productCode' => $data[2] == null ? '' : $data[2],
                                        'productName' => $data[3] == null ? '' : $data[3],
                                        'state' => $data[5] == null ? '' : $data[5],
                                        'errorMessage' => trans('「最低売価手動設定：手動設定」の場合、「最低売価」が必須入力'),
                                    ];
                                    $errorCount++;
                                }
                            }
                            // 最低売価手動設定:自動設定
                            else {
                                // 送料:必須チェック
                                if ($data[21] === null || $data[21] === '') {
                                    $errorList[] = [
                                        'rowNum' => $rowNum + 1,
                                        'productCode' => $data[2] == null ? '' : $data[2],
                                        'productName' => $data[3] == null ? '' : $data[3],
                                        'state' => $data[5] == null ? '' : $data[5],
                                        'errorMessage' => trans('「最低売価手動設定：自動設定」の場合、「送料」が必須入力'),
                                    ];
                                    $errorCount++;
                                }

                                // 手数料率:必須チェック
                                if ($data[22] === null || $data[22] === '') {
                                    $errorList[] = [
                                        'rowNum' => $rowNum + 1,
                                        'productCode' => $data[2] == null ? '' : $data[2],
                                        'productName' => $data[3] == null ? '' : $data[3],
                                        'state' => $data[5] == null ? '' : $data[5],
                                        'errorMessage' => trans('「最低売価手動設定：自動設定」の場合、「手数料率」が必須入力'),
                                    ];
                                    $errorCount++;
                                }

                                // 最低利益率:必須チェック
                                if ($data[23] === null || $data[23] === '') {

                                    if (!($data[24] === null || $data[24] === '') && !($data[12] === null || $data[12] === '')) {
                                        $data[23] = number_format($data[24]/$data[12], 4);
                                    } else {
                                        $errorList[] = [
                                            'rowNum' => $rowNum + 1,
                                            'productCode' => $data[2] == null ? '' : $data[2],
                                            'productName' => $data[3] == null ? '' : $data[3],
                                            'state' => $data[5] == null ? '' : $data[5],
                                            'errorMessage' => trans('「最低売価手動設定：自動設定」の場合、「最低利益率」が必須入力'),
                                        ];
                                        $errorCount++;
                                    }
                                }

                                // 粗利金額:必須チェック
                                if ($data[24] === null || $data[24] === '') {
                                    $errorList[] = [
                                        'rowNum' => $rowNum + 1,
                                        'productCode' => $data[2] == null ? '' : $data[2],
                                        'productName' => $data[3] == null ? '' : $data[3],
                                        'state' => $data[5] == null ? '' : $data[5],
                                        'errorMessage' => trans('「最低売価手動設定：自動設定」の場合、「粗利金額」が必須入力'),
                                    ];
                                    $errorCount++;
                                }
                            }

                            // 上限売価:必須チェック
                            if ($data[20] === null || $data[20] === '') {
                                $errorList[] = [
                                    'rowNum' => $rowNum + 1,
                                    'productCode' => $data[2] == null ? '' : $data[2],
                                    'productName' => $data[3] == null ? '' : $data[3],
                                    'state' => $data[5] == null ? '' : $data[5],
                                    'errorMessage' => trans('「上限売価」が必須入力'),
                                ];
                                $errorCount++;
                            }

                            // 調整ルール:必須チェック
                            if ($data[25] === null || $data[25] === '') {
                                $errorList[] = [
                                    'rowNum' => $rowNum + 1,
                                    'productCode' => $data[2] == null ? '' : $data[2],
                                    'productName' => $data[3] == null ? '' : $data[3],
                                    'state' => $data[5] == null ? '' : $data[5],
                                    'errorMessage' => trans('「調整ルール」が必須入力'),
                                ];
                                $errorCount++;
                            }
                        }

                        // 「商品クラスマスタ」チェック
                        $productClass = $this->productClassRepository->findOneBy(['code' => $productCode]);
                        if (empty($productClass)) {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「商品クラスマスタ」に対応商品コードがありません'),
                            ];
                            $errorCount++;
                        }

                        // 「状態マスタ」チェック
                        $stateInfo = $this->stateRepository->find($stateId);
                        if (empty($stateInfo)) {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「状態マスタ」に対応状態がありません'),
                            ];
                            $errorCount++;
                        }

                        // 「売価連動レベルマスタ」チェック
                        $productLevelInfo = $this->priceInterlockingLevelRepository->find($productLevelId);
                        if (empty($productLevelInfo)) {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「売価連動レベルマスタ」に対応レベルがありません'),
                            ];
                            $errorCount++;
                        }

                        // エラーなし場合、データを更新する。
                        if ($errorCount == 0) {

                            $insertFlg = false;

                            $netshopAIProductInfo = $this->NetshopaiProductInfoRepository->findOneBy([
                                'productCode' => $productCode,
                                'state' => $stateId,
                            ]);

                            // 新規の場合
                            if ($netshopAIProductInfo == null){

                                $insertFlg = true;
                                $netshopAIProductInfo = new NetshopaiProductInfo();

                                $netshopAIProductInfo->setProductCode($productCode);
                                $netshopAIProductInfo->setState($stateInfo);
                                $netshopAIProductInfo->setProductClass($productClass);

                                $netshopAIProductInfo->setRakutenOrderCsvInitQuantity(0);
                                $netshopAIProductInfo->setYahooOrderCsvInitQuantity(0);
                                $netshopAIProductInfo->setYahoo2OrderCsvInitQuantity(0);
                                $netshopAIProductInfo->setAmazonOrderCsvInitQuantity(0);
                                $netshopAIProductInfo->setKakakuOrderCsvInitQuantity(0);

                                $netshopAIProductInfo->setCreateUserName($this->getUser());
                                $netshopAIProductInfo->setUpdateUserName($this->getUser());
                            } else {
                                $netshopAIProductInfo->setUpdateUserName($this->getUser());
                            }

                            $netshopAIProductInfo->setPriceInterlockingLevel($productLevelInfo);
                            $netshopAIProductInfo->setStockInterlockingKawaguchiOnly($data[7] == '開始' ? true : false);
                            $netshopAIProductInfo->setAmazonShopKey($data[13]);
                            $netshopAIProductInfo->setAmazonAsinCode($data[14]);
                            $netshopAIProductInfo->setAmazonAsinCode2($data[15]);
                            $netshopAIProductInfo->setAmazonStockInterlocking($data[16] == '開始' ? true : false);
                            $netshopAIProductInfo->setAmazonPriceInterlocking($data[17] == '開始' ? true : false);
                            $netshopAIProductInfo->setAmazonLowerSellingPriceSetting($data[18] == '手動設定' ? true : false);
                            // INS-START CNC  2022/04/28 平均単価率利用フラグと平均単価率を追加する
                            $netshopAIProductInfo->setAmazonAverageUnitPriceRateFlg(false);
                            $netshopAIProductInfo->setAmazonAverageUnitPriceRate(100);
                            // INS-END CNC
                            $netshopAIProductInfo->setAmazonLowerSellingPrice($data[18] == '手動設定' ? $data[19] : 0);
                            $netshopAIProductInfo->setAmazonUpperSellingPrice(empty($data[20]) ? 0 : $data[20]);
                            $netshopAIProductInfo->setAmazonPostage(empty($data[21]) ? 0 : $data[21]);
                            $netshopAIProductInfo->setAmazonCommissionRate(empty($data[22]) ? 0 : $data[22]*100);
                            $netshopAIProductInfo->setAmazonLowerProfitRate(empty($data[23]) ? 0 : $data[23]*100);
                            $netshopAIProductInfo->setAmazonGrossProfit(empty($data[24]) ? 0 : $data[24]);
                            $netshopAIProductInfo->setAmazonAdjustmentRule(empty($data[25]) ? 0 : $data[25]);

                            $this->entityManager->persist($netshopAIProductInfo);
                            $this->entityManager->flush();

                            // 新規の場合
                            if ($insertFlg) {
                                // ネットショップ連動結果も新規
                                $this->createNetshopaiResult($netshopAIProductInfo, $rakutenNetshop, $yahooNetshop, $yahoo2Netshop, $amazonNetshop, $makeshopNetshop);
                                $this->entityManager->flush();
                            }

                            $normalCount++;

                        }
                        // エラーがある場合、チェック続行。（ループ後、rollbackが必要です）
                        else {
                            continue;
                        }
                    }
                }
                else if ($shopName == 'MakeShop') {

                    $errorList = null;
                    foreach ($uploadData as $rowNum => $data) {

                        // 完了判断
                        if ($data[1] === null || $data[1] === '') {
                            break;
                        }

                        // 登録対象チェック
                        if ($data[0] != '〇') {
                            continue;
                        }

                        // 商品コード:必須チェック
                        $productCode = str_replace("\t", "", $data[2]);
                        $data[2] = $productCode;
                        if ($productCode == null || $productCode == '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「商品コード」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 状態ID:必須チェック
                        $stateId = $data[4];
                        if ($stateId === null || $stateId === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「状態ID」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 売価連動レベル:必須チェック
                        $productLevelId = $data[6];
                        if ($productLevelId === null || $productLevelId === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「売価連動レベル」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 在庫連動川口のみ:必須チェック
                        $stockInterlockingKawaguchiOnly = $data[7];
                        if ($stockInterlockingKawaguchiOnly === null || $stockInterlockingKawaguchiOnly === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「在庫連動川口のみ」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 在庫自動連携:必須チェック
                        $stockInterlocking = $data[15];
                        if ($stockInterlocking === null || $stockInterlocking === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「在庫自動連携」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        // 売価自動連携:必須チェック
                        $priceInterlocking = $data[16];
                        if ($priceInterlocking === null || $priceInterlocking === '') {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「売価自動連携」が必須入力'),
                            ];
                            $errorCount++;
                        }

                        if ($data[16] == '開始') {
                            // 最低売価手動設定:手動設定
                            if ($data[17] == '手動設定') {

                                // 最低売価:必須チェック
                                // MOD-START CNC  2022/04/28 平均単価率利用フラグと平均単価率を追加する
                                //if ($data[17] === null || $data[17] === '') {
                                if ($data[19] === null || $data[19] === '') {
                                    // MOD-END CNC
                                    $errorList[] = [
                                        'rowNum' => $rowNum + 1,
                                        'productCode' => $data[2] == null ? '' : $data[2],
                                        'productName' => $data[3] == null ? '' : $data[3],
                                        'state' => $data[5] == null ? '' : $data[5],
                                        'errorMessage' => trans('「最低売価手動設定：手動設定」の場合、「最低売価」が必須入力'),
                                    ];
                                    $errorCount++;
                                }
                            }
                            // 最低売価手動設定:自動設定
                            else {
                                // ADD-START CNC  2022/04/28 平均単価率利用フラグと平均単価率を追加する
//                            // 平均単価率:必須チェック
//                            if ($data[18] === null || $data[18] === '') {
//                                $errorList[] = [
//                                    'rowNum' => $rowNum + 1,
//                                    'productCode' => $data[2] == null ? '' : $data[2],
//                                    'productName' => $data[3] == null ? '' : $data[3],
//                                    'state' => $data[5] == null ? '' : $data[5],
//                                    'errorMessage' => trans('「売価連動レベル：自動設定」の場合、「平均単価率」が必須入力'),
//                                ];
//                                $errorCount++;
//                            }
                                // ADD-END CNC

                                // 送料:必須チェック
                                // MOD-START CNC  2022/04/28 平均単価率利用フラグと平均単価率を追加する
                                //if ($data[19] === null || $data[19] === '') {
                                if ($data[21] === null || $data[21] === '') {
                                    // MOD-END CNC
                                    $errorList[] = [
                                        'rowNum' => $rowNum + 1,
                                        'productCode' => $data[2] == null ? '' : $data[2],
                                        'productName' => $data[3] == null ? '' : $data[3],
                                        'state' => $data[5] == null ? '' : $data[5],
                                        'errorMessage' => trans('「最低売価手動設定：自動設定」の場合、「送料」が必須入力'),
                                    ];
                                    $errorCount++;
                                }

                                // 手数料率:必須チェック
                                // MOD-START CNC  2022/04/28 平均単価率利用フラグと平均単価率を追加する
                                //if ($data[20] === null || $data[20] === '') {
                                if ($data[22] === null || $data[22] === '') {
                                    // MOD-END CNC
                                    $errorList[] = [
                                        'rowNum' => $rowNum + 1,
                                        'productCode' => $data[2] == null ? '' : $data[2],
                                        'productName' => $data[3] == null ? '' : $data[3],
                                        'state' => $data[5] == null ? '' : $data[5],
                                        'errorMessage' => trans('「最低売価手動設定：自動設定」の場合、「手数料率」が必須入力'),
                                    ];
                                    $errorCount++;
                                }

                                // 最低利益率:必須チェック
                                // MOD-START CNC  2022/04/28 平均単価率利用フラグと平均単価率を追加する
//                            if ($data[21] === null || $data[21] === '') {
//
//                                if (!($data[22] === null || $data[22] === '') && !($data[11] === null || $data[11] === '')) {
//                                    $data[21] = number_format($data[22]/$data[11], 4);
                                if ($data[23] === null || $data[23] === '') {

                                    if (!($data[24] === null || $data[24] === '') && !($data[12] === null || $data[12] === '')) {
                                        $data[23] = number_format($data[24]/$data[12], 4);
                                        // MOD-END CNC
                                    } else {
                                        $errorList[] = [
                                            'rowNum' => $rowNum + 1,
                                            'productCode' => $data[2] == null ? '' : $data[2],
                                            'productName' => $data[3] == null ? '' : $data[3],
                                            'state' => $data[5] == null ? '' : $data[5],
                                            'errorMessage' => trans('「最低売価手動設定：自動設定」の場合、「最低利益率」が必須入力'),
                                        ];
                                        $errorCount++;
                                    }
                                }

                                // 粗利金額:必須チェック
                                // MOD-START CNC  2022/04/28 平均単価率利用フラグと平均単価率を追加する
                                //if ($data[22] === null || $data[22] === '') {
                                if ($data[24] === null || $data[24] === '') {
                                    // MOD-END CNC
                                    $errorList[] = [
                                        'rowNum' => $rowNum + 1,
                                        'productCode' => $data[2] == null ? '' : $data[2],
                                        'productName' => $data[3] == null ? '' : $data[3],
                                        'state' => $data[5] == null ? '' : $data[5],
                                        'errorMessage' => trans('「最低売価手動設定：自動設定」の場合、「粗利金額」が必須入力'),
                                    ];
                                    $errorCount++;
                                }
                            }

                            // 上限売価:必須チェック
                            // MOD-START CNC  2022/04/28 平均単価率利用フラグと平均単価率を追加する
                            //if ($data[18] === null || $data[18] === '') {
                            if ($data[20] === null || $data[20] === '') {
                                // MOD-END CNC
                                $errorList[] = [
                                    'rowNum' => $rowNum + 1,
                                    'productCode' => $data[2] == null ? '' : $data[2],
                                    'productName' => $data[3] == null ? '' : $data[3],
                                    'state' => $data[5] == null ? '' : $data[5],
                                    'errorMessage' => trans('「上限売価」が必須入力'),
                                ];
                                $errorCount++;
                            }

                            // 調整ルール:必須チェック
                            // MOD-START CNC  2022/04/28 平均単価率利用フラグと平均単価率を追加する
                            //if ($data[23] === null || $data[23] === '') {
                            if ($data[25] === null || $data[25] === '') {
                                // MOD-END CNC
                                $errorList[] = [
                                    'rowNum' => $rowNum + 1,
                                    'productCode' => $data[2] == null ? '' : $data[2],
                                    'productName' => $data[3] == null ? '' : $data[3],
                                    'state' => $data[5] == null ? '' : $data[5],
                                    'errorMessage' => trans('「調整ルール」が必須入力'),
                                ];
                                $errorCount++;
                            }
                        }

                        // 「商品クラスマスタ」チェック
                        $productClass = $this->productClassRepository->findOneBy(['code' => $productCode]);
                        if (empty($productClass)) {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「商品クラスマスタ」に対応商品コードがありません'),
                            ];
                            $errorCount++;
                        }

                        // 「状態マスタ」チェック
                        $stateInfo = $this->stateRepository->find($stateId);
                        if (empty($stateInfo)) {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「状態マスタ」に対応状態がありません'),
                            ];
                            $errorCount++;
                        }

                        // 「売価連動レベルマスタ」チェック
                        $productLevelInfo = $this->priceInterlockingLevelRepository->find($productLevelId);
                        if (empty($productLevelInfo)) {
                            $errorList[] = [
                                'rowNum' => $rowNum + 1,
                                'productCode' => $data[2] == null ? '' : $data[2],
                                'productName' => $data[3] == null ? '' : $data[3],
                                'state' => $data[5] == null ? '' : $data[5],
                                'errorMessage' => trans('「売価連動レベルマスタ」に対応レベルがありません'),
                            ];
                            $errorCount++;
                        }

                        // エラーなし場合、データを更新する。
                        if ($errorCount == 0) {

                            $insertFlg = false;

                            $netshopAIProductInfo = $this->NetshopaiProductInfoRepository->findOneBy([
                                'productCode' => $productCode,
                                'state' => $stateId,
                            ]);

                            // 新規の場合
                            if ($netshopAIProductInfo == null){

                                $insertFlg = true;
                                $netshopAIProductInfo = new NetshopaiProductInfo();

                                $netshopAIProductInfo->setProductCode($productCode);
                                $netshopAIProductInfo->setState($stateInfo);
                                $netshopAIProductInfo->setProductClass($productClass);

                                $netshopAIProductInfo->setRakutenOrderCsvInitQuantity(0);
                                $netshopAIProductInfo->setYahooOrderCsvInitQuantity(0);
                                $netshopAIProductInfo->setYahoo2OrderCsvInitQuantity(0);
                                $netshopAIProductInfo->setAmazonOrderCsvInitQuantity(0);
                                $netshopAIProductInfo->setKakakuOrderCsvInitQuantity(0);

                                $netshopAIProductInfo->setCreateUserName($this->getUser());
                                $netshopAIProductInfo->setUpdateUserName($this->getUser());
                            } else {
                                $netshopAIProductInfo->setUpdateUserName($this->getUser());
                            }

                            $netshopAIProductInfo->setPriceInterlockingLevel($productLevelInfo);
                            $netshopAIProductInfo->setStockInterlockingKawaguchiOnly($data[7] == '開始' ? true : false);
                            $netshopAIProductInfo->setKakakuShopKey($data[13]);
                            $netshopAIProductInfo->setKakakuProductId($data[14]);
                            $netshopAIProductInfo->setKakakuStockInterlocking($data[15] == '開始' ? true : false);
                            $netshopAIProductInfo->setKakakuPriceInterlocking($data[16] == '開始' ? true : false);
                            $netshopAIProductInfo->setKakakuLowerSellingPriceSetting($data[17] == '手動設定' ? true : false);
                            // INS-START CNC  2022/04/28 平均単価率利用フラグと平均単価率を追加する
                            $netshopAIProductInfo->setKakakuAverageUnitPriceRateFlg($data[18] == '利用する' ? true : false);
                            $netshopAIProductInfo->setKakakuAverageUnitPriceRate(100);
                            // INS-END CNC
                            // MOD-START CNC  2022/04/28 平均単価率利用フラグと平均単価率を追加する
                            $netshopAIProductInfo->setKakakuLowerSellingPrice($data[17] == '手動設定' ? $data[19] : 0);
                            $netshopAIProductInfo->setKakakuUpperSellingPrice(empty($data[20]) ? 0 : $data[20]);
                            $netshopAIProductInfo->setKakakuPostage(empty($data[21]) ? 0 : $data[21]);
                            $netshopAIProductInfo->setKakakuCommissionRate(empty($data[22]) ? 0 : $data[22]*100);
                            $netshopAIProductInfo->setKakakuLowerProfitRate(empty($data[23]) ? 0 : $data[23]*100);
                            $netshopAIProductInfo->setKakakuGrossProfit(empty($data[24]) ? 0 : $data[24]);
                            $netshopAIProductInfo->setKakakuAdjustmentRule(empty($data[25]) ? 0 : $data[25]);
                            // MOD-END CNC

                            $this->entityManager->persist($netshopAIProductInfo);
                            $this->entityManager->flush();

                            // 新規の場合
                            if ($insertFlg) {
                                // ネットショップ連動結果も新規
                                $this->createNetshopaiResult($netshopAIProductInfo, $rakutenNetshop, $yahooNetshop, $yahoo2Netshop, $amazonNetshop, $makeshopNetshop);
                                $this->entityManager->flush();
                            }

                            $normalCount++;

                        }
                        // エラーがある場合、チェック続行。（ループ後、rollbackが必要です）
                        else {
                            continue;
                        }
                    }
                }
                else {
                    $this->addErrors('ショップ名が不正');
                    return $this->renderWithError();
                }

                $this->removeUploadedFile();

                if ($errorCount > 0) {
                    $this->entityManager->rollback();
                    return $this->json(['data' => $errorList]);
                } else {
                    if ($normalCount == 0) {
                        $this->addErrors('登録対象がありません');
                        return $this->renderWithError();
                    } else {
                        $this->entityManager->flush();
                        $this->addErrors('連動商品一括登録完了しました。');
                        return $this->renderWithError();
                    }
                }

            }
        }
    }

    /**
     * 登録、更新時のエラー画面表示
     */
    protected function addErrors($message)
    {
        $this->errors[] = $message;
    }

    /**
     * 登録、更新時のエラー画面表示
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     *
     * @throws \Doctrine\DBAL\ConnectionException
     */
    protected function renderWithError()
    {
        $this->removeUploadedFile();

        return $this->json([
            'errors' => $this->errors,
        ]);
    }

    /**
     * ネットショップ連動結果の情報設定
     */
    private function createNetshopaiResult($netshopAIProductInfo, $rakutenNetshop, $yahooNetshop, $yahoo2Netshop, $amazonNetshop, $makeshopNetshop){

        // 楽天
        $rakutenNetshopaiResult = new NetshopaiResult();
        $rakutenNetshopaiResult->setAiProduct($netshopAIProductInfo);
        $rakutenNetshopaiResult->setShop($rakutenNetshop);
        $rakutenNetshopaiResult->setPriceJobid(0);
        $rakutenNetshopaiResult->setStockJobid(0);
        $rakutenNetshopaiResult->setPriceAiDate(new \DateTime());
        $rakutenNetshopaiResult->setStockAiDate(new \DateTime());
        $rakutenNetshopaiResult->setStock(0);
        $rakutenNetshopaiResult->setOrderQuantity(0);
        $rakutenNetshopaiResult->setTempShipmentQuantity(0);
        $rakutenNetshopaiResult->setRemainingShipmentQuantity(0);
        $rakutenNetshopaiResult->setAiShipmentQuantity(0);
        $rakutenNetshopaiResult->setAvaregePrice(999999999);
        $rakutenNetshopaiResult->setShopPrice(999999999);
        $rakutenNetshopaiResult->setProfitRate(999.99);
        $rakutenNetshopaiResult->setGrossProfit(999999999);
        $rakutenNetshopaiResult->setLowerSellingPrice(999999999);
        $rakutenNetshopaiResult->setUpperSellingPrice(999999999);
        $rakutenNetshopaiResult->setCompetitorsSellingPrice(999999999);
        $rakutenNetshopaiResult->setPriceRanking(99);
        $rakutenNetshopaiResult->setCompetitorsDifference(999999999);
        $rakutenNetshopaiResult->setAdjustmentRule(999999999);
        $rakutenNetshopaiResult->setCreateUserName($this->getUser());
        $rakutenNetshopaiResult->setUpdateUserName($this->getUser());
        $this->entityManager->persist($rakutenNetshopaiResult);

        // Yahoo!ショッピング
        $yahooNetshopaiResult = new NetshopaiResult();
        $yahooNetshopaiResult->setAiProduct($netshopAIProductInfo);
        $yahooNetshopaiResult->setShop($yahooNetshop);
        $yahooNetshopaiResult->setPriceJobid(0);
        $yahooNetshopaiResult->setStockJobid(0);
        $yahooNetshopaiResult->setPriceAiDate(new \DateTime());
        $yahooNetshopaiResult->setStockAiDate(new \DateTime());
        $yahooNetshopaiResult->setStock(0);
        $yahooNetshopaiResult->setOrderQuantity(0);
        $yahooNetshopaiResult->setTempShipmentQuantity(0);
        $yahooNetshopaiResult->setRemainingShipmentQuantity(0);
        $yahooNetshopaiResult->setAiShipmentQuantity(0);
        $yahooNetshopaiResult->setAvaregePrice(999999999);
        $yahooNetshopaiResult->setShopPrice(999999999);
        $yahooNetshopaiResult->setProfitRate(999.99);
        $yahooNetshopaiResult->setGrossProfit(999999999);
        $yahooNetshopaiResult->setLowerSellingPrice(999999999);
        $yahooNetshopaiResult->setUpperSellingPrice(999999999);
        $yahooNetshopaiResult->setCompetitorsSellingPrice(999999999);
        $yahooNetshopaiResult->setPriceRanking(99);
        $yahooNetshopaiResult->setCompetitorsDifference(999999999);
        $yahooNetshopaiResult->setAdjustmentRule(999999999);
        $yahooNetshopaiResult->setCreateUserName($this->getUser());
        $yahooNetshopaiResult->setUpdateUserName($this->getUser());
        $this->entityManager->persist($yahooNetshopaiResult);

        // Yahoo2!ショッピング
        $yahoo2NetshopaiResult = new NetshopaiResult();
        $yahoo2NetshopaiResult->setAiProduct($netshopAIProductInfo);
        $yahoo2NetshopaiResult->setShop($yahoo2Netshop);
        $yahoo2NetshopaiResult->setPriceJobid(0);
        $yahoo2NetshopaiResult->setStockJobid(0);
        $yahoo2NetshopaiResult->setPriceAiDate(new \DateTime());
        $yahoo2NetshopaiResult->setStockAiDate(new \DateTime());
        $yahoo2NetshopaiResult->setStock(0);
        $yahoo2NetshopaiResult->setOrderQuantity(0);
        $yahoo2NetshopaiResult->setTempShipmentQuantity(0);
        $yahoo2NetshopaiResult->setRemainingShipmentQuantity(0);
        $yahoo2NetshopaiResult->setAiShipmentQuantity(0);
        $yahoo2NetshopaiResult->setAvaregePrice(999999999);
        $yahoo2NetshopaiResult->setShopPrice(999999999);
        $yahoo2NetshopaiResult->setProfitRate(999.99);
        $yahoo2NetshopaiResult->setGrossProfit(999999999);
        $yahoo2NetshopaiResult->setLowerSellingPrice(999999999);
        $yahoo2NetshopaiResult->setUpperSellingPrice(999999999);
        $yahoo2NetshopaiResult->setCompetitorsSellingPrice(999999999);
        $yahoo2NetshopaiResult->setPriceRanking(99);
        $yahoo2NetshopaiResult->setCompetitorsDifference(999999999);
        $yahoo2NetshopaiResult->setAdjustmentRule(999999999);
        $yahoo2NetshopaiResult->setCreateUserName($this->getUser());
        $yahoo2NetshopaiResult->setUpdateUserName($this->getUser());
        $this->entityManager->persist($yahoo2NetshopaiResult);

        // Amazon
        $amazonNetshopaiResult = new NetshopaiResult();
        $amazonNetshopaiResult->setAiProduct($netshopAIProductInfo);
        $amazonNetshopaiResult->setShop($amazonNetshop);
        $amazonNetshopaiResult->setPriceJobid(0);
        $amazonNetshopaiResult->setStockJobid(0);
        $amazonNetshopaiResult->setPriceAiDate(new \DateTime());
        $amazonNetshopaiResult->setStockAiDate(new \DateTime());
        $amazonNetshopaiResult->setStock(0);
        $amazonNetshopaiResult->setOrderQuantity(0);
        $amazonNetshopaiResult->setTempShipmentQuantity(0);
        $amazonNetshopaiResult->setRemainingShipmentQuantity(0);
        $amazonNetshopaiResult->setAiShipmentQuantity(0);
        $amazonNetshopaiResult->setAvaregePrice(999999999);
        $amazonNetshopaiResult->setShopPrice(999999999);
        $amazonNetshopaiResult->setProfitRate(999.99);
        $amazonNetshopaiResult->setGrossProfit(999999999);
        $amazonNetshopaiResult->setLowerSellingPrice(999999999);
        $amazonNetshopaiResult->setUpperSellingPrice(999999999);
        $amazonNetshopaiResult->setCompetitorsSellingPrice(999999999);
        $amazonNetshopaiResult->setPriceRanking(99);
        $amazonNetshopaiResult->setCompetitorsDifference(999999999);
        $amazonNetshopaiResult->setAdjustmentRule(999999999);
        $amazonNetshopaiResult->setCreateUserName($this->getUser());
        $amazonNetshopaiResult->setUpdateUserName($this->getUser());
        $this->entityManager->persist($amazonNetshopaiResult);

        // 価格.com
        $kakakuNetshopaiResult = new NetshopaiResult();
        $kakakuNetshopaiResult->setAiProduct($netshopAIProductInfo);
        $kakakuNetshopaiResult->setShop($makeshopNetshop);
        $kakakuNetshopaiResult->setPriceJobid(0);
        $kakakuNetshopaiResult->setStockJobid(0);
        $kakakuNetshopaiResult->setPriceAiDate(new \DateTime());
        $kakakuNetshopaiResult->setStockAiDate(new \DateTime());
        $kakakuNetshopaiResult->setStock(0);
        $kakakuNetshopaiResult->setOrderQuantity(0);
        $kakakuNetshopaiResult->setTempShipmentQuantity(0);
        $kakakuNetshopaiResult->setRemainingShipmentQuantity(0);
        $kakakuNetshopaiResult->setAiShipmentQuantity(0);
        $kakakuNetshopaiResult->setAvaregePrice(999999999);
        $kakakuNetshopaiResult->setShopPrice(999999999);
        $kakakuNetshopaiResult->setProfitRate(999.99);
        $kakakuNetshopaiResult->setGrossProfit(999999999);
        $kakakuNetshopaiResult->setLowerSellingPrice(999999999);
        $kakakuNetshopaiResult->setUpperSellingPrice(999999999);
        $kakakuNetshopaiResult->setCompetitorsSellingPrice(999999999);
        $kakakuNetshopaiResult->setPriceRanking(99);
        $kakakuNetshopaiResult->setCompetitorsDifference(999999999);
        $kakakuNetshopaiResult->setAdjustmentRule(999999999);
        $kakakuNetshopaiResult->setCreateUserName($this->getUser());
        $kakakuNetshopaiResult->setUpdateUserName($this->getUser());
        $this->entityManager->persist($kakakuNetshopaiResult);
    }
}
