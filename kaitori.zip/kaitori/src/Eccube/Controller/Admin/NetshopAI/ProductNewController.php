<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\NetshopAI;

use Eccube\Controller\AbstractController;
use Eccube\Entity\Master\Netshop;
use Eccube\Entity\NetshopaiProductInfo;
use Eccube\Entity\NetshopaiResult;
use Eccube\Entity\Product;
use Eccube\Entity\StockListProductUnit;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\AddCartType;
use Eccube\Form\Type\Admin\NetshopAIProductSearchType;
use Eccube\Form\Type\Admin\ProductNewType;
use Eccube\Form\Type\Admin\SearchProductType;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\Master\NetshopRepository;
use Eccube\Repository\NetshopaiProductInfoRepository;
use Eccube\Repository\NetshopInfoRepository;
use Eccube\Repository\NetshopaiResultRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\StateRepository;
use Eccube\Repository\StockListProductUnitRepository;
use Eccube\Util\CacheUtil;
use Knp\Component\Pager\Paginator;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Twig_Environment;
use Eccube\Common\Constant;

/**
*プログラム名 ： ProductNewController.php
*概　　要     ： ネットショップ連動商品登録
*作　　成     ： 2021/7/29 CNC
*/
class ProductNewController extends AbstractController
{
    // 一覧画面URL
    const PREVIOUS_PAGE_URL_LIST = 'netshopAI_serial_action/product_list';

    // 一覧画面URL
    const PREVIOUS_PAGE_URL_INQUIRE = 'netshopAI_serial_action/result_inquire';

    /**
     * @var Twig_Environment
     */
    protected $twig;

    /**
     * @var NetshopInfoRepository
     */
    protected $NetshopInfoRepository;

    /**
     * @var NetshopaiProductInfoRepository
     */
    protected $NetshopaiProductInfoRepository;

    /**
     * @var StockListProductUnitRepository
     */
    protected $stockListProductUnitRepository;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var ProductClassRepository
     */
    protected $productClassRepository;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var StateRepository
     */
    protected $StateRepository;

    /**
     * @var NetshopRepository
     */
    protected $NetshopRepository;

    /**
     * @var NetshopaiResultRepository
     */
    protected $NetshopaiResultRepository;


    /**
     * ProductNewController constructor.
     * @param NetshopInfoRepository $NetshopInfoRepository
     * @param NetshopaiProductInfoRepository $NetshopaiProductInfoRepository
     * @param ProductRepository $productRepository
     * @param ProductClassRepository $productClassRepository
     * @param CategoryRepository $categoryRepository
     * @param StateRepository $StateRepository
     * @param NetshopRepository $NetshopRepository
     * @param NetshopaiResultRepository $NetshopaiResultRepository
     */
    public function __construct(
        Twig_Environment $twig,
        NetshopInfoRepository $NetshopInfoRepository,
        NetshopaiProductInfoRepository $NetshopaiProductInfoRepository,
        StockListProductUnitRepository $stockListProductUnitRepository,
        ProductRepository $productRepository,
        ProductClassRepository $productClassRepository,
        CategoryRepository $categoryRepository,
        StateRepository $StateRepository,
        NetshopRepository $NetshopRepository,
        NetshopaiResultRepository $NetshopaiResultRepository
    )
    {
        $this->twig = $twig;
        $this->NetshopInfoRepository = $NetshopInfoRepository;
        $this->NetshopaiProductInfoRepository = $NetshopaiProductInfoRepository;
        $this->stockListProductUnitRepository = $stockListProductUnitRepository;
        $this->productRepository = $productRepository;
        $this->productClassRepository = $productClassRepository;
        $this->categoryRepository = $categoryRepository;
        $this->StateRepository = $StateRepository;
        $this->NetshopRepository = $NetshopRepository;
        $this->NetshopaiResultRepository = $NetshopaiResultRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/product_new", name="admin_netshopAI_product_new")
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/product_new/edit/{id}", requirements={"id" = "\d+"}, name="admin_netshopAI_product_edit")
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/product_new/edit/new/{stateId}_{productCode}", requirements={"stateId" = "\d+", "productCode" = "\S+"}, name="admin_netshopAI_product_edit_new")
     * @Template("@admin/NetshopAI/product_new.twig")
     *
     * @param Request $request
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function index(Request $request, CacheUtil $cacheUtil, $id = null, $productCode = null, $stateId = null)
    {
        // 前ページurl
        if (strpos($request->headers->get('referer'), self::PREVIOUS_PAGE_URL_LIST)) {
            $link = 1;
        } else {
            if (strpos($request->headers->get('referer'), self::PREVIOUS_PAGE_URL_INQUIRE)) {
                $link = 2;
            } else {
                $link = 0;
            }
        }

        // 状態変更の場合、処理対象再取込
        if ('POST' === $request->getMethod()){
            $productCode = $request->get('netshopAIProductInfo')['productCode'];

            // 状態変更の場合
            if ($request->get('netshopAIProductInfo')['stateChangeFlag']) {
                // 商品コードと状態チェック
                $updateData = $this->NetshopaiProductInfoRepository->findOneBy(
                    [
                        'productCode' => $request->get('netshopAIProductInfo')['productCode'],
                        'state' => $request->get('netshopAIProductInfo')['state'],
                    ]
                );

                if (is_null($updateData)) {
                    return $this->redirectToRoute('admin_netshopAI_product_edit_new', ['productCode' => $request->get('netshopAIProductInfo')['productCode'], 'stateId' => $request->get('netshopAIProductInfo')['state']]);
                } else {
                    return $this->redirectToRoute('admin_netshopAI_product_edit', ['id' => $updateData->getId()]);
                }
            }
        }

        // 新規登録
        if($id == null){
            $netshopAIProductInfo = new NetshopaiProductInfo();
            $stockList = new StockListProductUnit();

            // 送料、手数料、利益、差額、除外店舗、除外キーワードはショップ情報から取得する。
            $netshopInfo = $this->NetshopInfoRepository->find(0);

            // 新規登録の場合、在庫連動川口のみをチェックオンに設定する
            $netshopAIProductInfo->setStockInterlockingKawaguchiOnly(true);

            $netshopAIProductInfo->setRakutenPostage($netshopInfo->getRakutenPostage());
            $netshopAIProductInfo->setRakutenCommissionRate($netshopInfo->getRakutenCommissionRate());
            $netshopAIProductInfo->setRakutenLowerProfitRate($netshopInfo->getRakutenLowerProfitRate());
            $netshopAIProductInfo->setRakutenAdjustmentRule($netshopInfo->getRakutenAdjustmentRule());
            $netshopAIProductInfo->setRakutenExcludedShop($netshopInfo->getRakutenExcludedShop());
            $netshopAIProductInfo->setRakutenExcludedKeyword($netshopInfo->getRakutenExcludedKeyword());

            $netshopAIProductInfo->setYahooPostage($netshopInfo->getYahooPostage());
            $netshopAIProductInfo->setYahooCommissionRate($netshopInfo->getYahooCommissionRate());
            $netshopAIProductInfo->setYahooLowerProfitRate($netshopInfo->getYahooLowerProfitRate());
            $netshopAIProductInfo->setYahooAdjustmentRule($netshopInfo->getYahooAdjustmentRule());
            $netshopAIProductInfo->setYahooExcludedShop($netshopInfo->getYahooExcludedShop());
            $netshopAIProductInfo->setYahooExcludedKeyword($netshopInfo->getYahooExcludedKeyword());

            $netshopAIProductInfo->setYahoo2Postage($netshopInfo->getYahoo2Postage());
            $netshopAIProductInfo->setYahoo2CommissionRate($netshopInfo->getYahoo2CommissionRate());
            $netshopAIProductInfo->setYahoo2LowerProfitRate($netshopInfo->getYahoo2LowerProfitRate());
            $netshopAIProductInfo->setYahoo2AdjustmentRule($netshopInfo->getYahoo2AdjustmentRule());
            $netshopAIProductInfo->setYahoo2ExcludedShop($netshopInfo->getYahoo2ExcludedShop());
            $netshopAIProductInfo->setYahoo2ExcludedKeyword($netshopInfo->getYahoo2ExcludedKeyword());

            $netshopAIProductInfo->setAmazonPostage($netshopInfo->getAmazonPostage());
            $netshopAIProductInfo->setAmazonCommissionRate($netshopInfo->getAmazonCommissionRate());
            $netshopAIProductInfo->setAmazonLowerProfitRate($netshopInfo->getAmazonLowerProfitRate());
            $netshopAIProductInfo->setAmazonAdjustmentRule($netshopInfo->getAmazonAdjustmentRule());
            $netshopAIProductInfo->setAmazonExcludedShop($netshopInfo->getAmazonExcludedShop());
            $netshopAIProductInfo->setAmazonExcludedKeyword($netshopInfo->getAmazonExcludedKeyword());

            $netshopAIProductInfo->setKakakuPostage($netshopInfo->getKakakuPostage());
            $netshopAIProductInfo->setKakakuCommissionRate($netshopInfo->getKakakuCommissionRate());
            $netshopAIProductInfo->setKakakuLowerProfitRate($netshopInfo->getKakakuLowerProfitRate());
            $netshopAIProductInfo->setKakakuAdjustmentRule($netshopInfo->getKakakuAdjustmentRule());
            $netshopAIProductInfo->setKakakuExcludedShop($netshopInfo->getKakakuExcludedShop());
            $netshopAIProductInfo->setKakakuExcludedKeyword($netshopInfo->getKakakuExcludedKeyword());

            // 手動設定金額
            $netshopAIProductInfo->setRakutenLowerSellingPrice(0);
            $netshopAIProductInfo->setYahooLowerSellingPrice(0);
            $netshopAIProductInfo->setYahoo2LowerSellingPrice(0);
            $netshopAIProductInfo->setAmazonLowerSellingPrice(0);
            $netshopAIProductInfo->setKakakuLowerSellingPrice(0);
            // 下限売価
            $netshopAIProductInfo->setRakutenLowestSellingPrice(0);
            $netshopAIProductInfo->setYahooLowestSellingPrice(0);
            $netshopAIProductInfo->setYahoo2LowestSellingPrice(0);
            $netshopAIProductInfo->setAmazonLowestSellingPrice(0);
            $netshopAIProductInfo->setKakakuLowestSellingPrice(0);
            // 上限売価
            $netshopAIProductInfo->setRakutenUpperSellingPrice(999999999);
            $netshopAIProductInfo->setYahooUpperSellingPrice(999999999);
            $netshopAIProductInfo->setYahoo2UpperSellingPrice(999999999);
            $netshopAIProductInfo->setAmazonUpperSellingPrice(999999999);
            $netshopAIProductInfo->setKakakuUpperSellingPrice(999999999);

            // amazon非表示ＤＢ項目設定
            // Amazon市場下限売価
            $netshopAIProductInfo->setAmazonLowestSellingPrice(0);
            // Amazon除外店舗
            $netshopAIProductInfo->setAmazonExcludedShop(null);
            // Amazon除外キーワード
            $netshopAIProductInfo->setAmazonExcludedKeyword(null);
            // Amazonキーワード
            $netshopAIProductInfo->setAmazonKeyword(null);

            // 価格com非表示ＤＢ項目設定
            // 価格com市場下限売価
            $netshopAIProductInfo->setKakakuLowestSellingPrice(0);
            // 価格com除外店舗
            $netshopAIProductInfo->setKakakuExcludedShop(null);
            // 価格comキーワード
            $netshopAIProductInfo->setKakakuKeyword(null);
            // 価格com除外キーワード
            $netshopAIProductInfo->setKakakuExcludedKeyword(null);

            // INS-START CNC  2022/04/28 平均単価率利用フラグと平均単価率を追加する
            // makeshop以外平均単価率利用フラグと平均単価率設定
            $netshopAIProductInfo->setRakutenAverageUnitPriceRateFlg(0);
            $netshopAIProductInfo->setRakutenAverageUnitPriceRate(100);
            $netshopAIProductInfo->setYahooAverageUnitPriceRateFlg(0);
            $netshopAIProductInfo->setYahooAverageUnitPriceRate(100);
            $netshopAIProductInfo->setYahoo2AverageUnitPriceRateFlg(0);
            $netshopAIProductInfo->setYahoo2AverageUnitPriceRate(100);
            $netshopAIProductInfo->setAmazonAverageUnitPriceRateFlg(0);
            $netshopAIProductInfo->setAmazonAverageUnitPriceRate(100);
            // INS-START CNC  2022/04/28

            // 更新情報未設定
            $update_date = null;
            $update_User_Name = null;

            // 作成者追加
            $netshopAIProductInfo->setCreateUserName($this->getUser());

            // 商品コードと状態選択の場合
            if ($productCode != null && $stateId !=null){
                $netshopAIProductInfo->setProductCode($productCode);

                // 商品名取得
                $productClass = $this->productClassRepository->findOneBy(
                    [
                        'code' => $productCode
                    ]
                );
                $netshopAIProductInfo->setName($productClass->getProduct()->getName());

                // 商品情報追加
                $productClass = $this->productClassRepository->findOneBy(
                    [
                        'code'=> $netshopAIProductInfo->getProductCode()
                    ]
                );
                $netshopAIProductInfo->setProductClass($productClass);

                // 状態取得
                $state = $this->StateRepository->find($stateId);
                $netshopAIProductInfo->setState($state);

                // CSVで初期化受注数
                $netshopAIProductInfo->setRakutenOrderCsvInitQuantity(0);
                $netshopAIProductInfo->setYahooOrderCsvInitQuantity(0);
                $netshopAIProductInfo->setYahoo2OrderCsvInitQuantity(0);
                $netshopAIProductInfo->setAmazonOrderCsvInitQuantity(0);
                $netshopAIProductInfo->setKakakuOrderCsvInitQuantity(0);

                // 在庫情報取得
                $stockInfo = $this->stockListProductUnitRepository->findOneBy(
                    [
                        'productCode' => $netshopAIProductInfo->getProductCode(),
                        'State' => $netshopAIProductInfo->getState(),
                    ]
                );

                if (is_null($stockInfo)){
                    $stockList->setStockQuantity(0);
                    $stockList->setProvisionalShipmentQuantity(0);
                    $stockList->setOrderQuantity(0);
                    $stockList->setRemainingStockQuantity(0);
                    $stockList->setAverageUnitPrice(0);
                } else {
                    $stockList->setStockQuantity($stockInfo->getStockQuantity());
                    $stockList->setProvisionalShipmentQuantity($stockInfo->getProvisionalShipmentQuantity());
                    $stockList->setOrderQuantity($stockInfo->getOrderQuantity());
                    $stockList->setRemainingStockQuantity($stockInfo->getRemainingStockQuantity());
                    $stockList->setAverageUnitPrice($stockInfo->getAverageUnitPrice());

                    // 粗利金額設定(1000)
                    $netshopAIProductInfo->setRakutenGrossProfit(1000);
                    $netshopAIProductInfo->setYahooGrossProfit(1000);
                    $netshopAIProductInfo->setYahoo2GrossProfit(1000);
                    $netshopAIProductInfo->setAmazonGrossProfit(1000);
                    $netshopAIProductInfo->setKakakuGrossProfit(1000);

                    // 売価調査下限価格除外設定(平均単価)
                    $netshopAIProductInfo->setRakutenLowestSellingPrice($stockInfo->getAverageUnitPrice());
                    $netshopAIProductInfo->setYahooLowestSellingPrice($stockInfo->getAverageUnitPrice());
                    $netshopAIProductInfo->setYahoo2LowestSellingPrice($stockInfo->getAverageUnitPrice());
//                    $netshopAIProductInfo->setAmazonLowestSellingPrice(0);
//                    $netshopAIProductInfo->setKakakuLowestSellingPrice(0);
                }

                // 状態が新品の場合、在庫自動連携と売価自動連携チェックオン
                // 状態が新品以外の場合、在庫自動連携と売価自動連携チェックオフ
//                if (strpos($state->getState(), "新品") !== false) {
//                    $netshopAIProductInfo->setRakutenPriceInterlocking(true);
//                    $netshopAIProductInfo->setRakutenStockInterlocking(true);
//                    $netshopAIProductInfo->setYahooPriceInterlocking(true);
//                    $netshopAIProductInfo->setYahooStockInterlocking(true);
//                    $netshopAIProductInfo->setAmazonPriceInterlocking(true);
//                    $netshopAIProductInfo->setAmazonStockInterlocking(true);
//                    $netshopAIProductInfo->setKakakuPriceInterlocking(true);
//                    $netshopAIProductInfo->setKakakuStockInterlocking(true);
//                } else {
                    $netshopAIProductInfo->setRakutenPriceInterlocking(false);
                    $netshopAIProductInfo->setRakutenStockInterlocking(false);
                    $netshopAIProductInfo->setYahooPriceInterlocking(false);
                    $netshopAIProductInfo->setYahooStockInterlocking(false);
                    $netshopAIProductInfo->setYahoo2PriceInterlocking(false);
                    $netshopAIProductInfo->setYahoo2StockInterlocking(false);
                    $netshopAIProductInfo->setAmazonPriceInterlocking(false);
                    $netshopAIProductInfo->setAmazonStockInterlocking(false);
                    $netshopAIProductInfo->setKakakuPriceInterlocking(false);
                    $netshopAIProductInfo->setKakakuStockInterlocking(false);
//                }

                $netshopAIProductInfo->setRakutenPostageFreeFlag(true);
                $netshopAIProductInfo->setYahooPostageFreeFlag(true);
                $netshopAIProductInfo->setYahoo2PostageFreeFlag(true);

//                // 金額連動
//                // ルール１：粗利金額=平均単価*最低利益率
//                // ルール２：最低売価=(平均単価+送料+粗利金額)/(1-手数料率)
//
//                // 楽天市場
//                // 平均単価
//                $averageUnitPrice = $stockList->getAverageUnitPrice();
//                // 楽天市場送料
//                $rakutenPostage = $netshopAIProductInfo->getRakutenPostage() == null ? 0 : $netshopAIProductInfo->getRakutenPostage();
//                // 楽天市場手数料率
//                $rakutenCommissionRate = $netshopAIProductInfo->getRakutenCommissionRate() == null ? 0 : $netshopAIProductInfo->getRakutenCommissionRate();
//                // 楽天市場最低利益率
//                $rakutenLowerProfitRate = $netshopAIProductInfo->getRakutenLowerProfitRate() == null ? 0 : $netshopAIProductInfo->getRakutenLowerProfitRate();
//
//                // 楽天市場粗利金額設定
//                $netshopAIProductInfo->setRakutenGrossProfit(null);
//                // 楽天市場最低売価設定
//                $netshopAIProductInfo->setRakutenLowerSellingPrice(null);
//                // 平均単価と最低利益率があるの場合
//                if ($averageUnitPrice !== '0' && $rakutenLowerProfitRate !== '0'){
//                    // 楽天市場粗利金額計算
//                    // 粗利金額=平均単価*最低利益率
//                    $rakutenGrossProfit = $averageUnitPrice * $rakutenLowerProfitRate / 100;
//                    // 楽天市場粗利金額設定
//                    $netshopAIProductInfo->setRakutenGrossProfit(ceil($rakutenGrossProfit));
//
//                    // 送料と手数料率があるの場合
//                    if ($rakutenPostage !== '0' && $rakutenCommissionRate !== '0'){
//                        // 楽天市場最低売価計算
//                        // 最低売価=(平均単価+送料+粗利金額)/(1-手数料率)
//                        $rakutenLowerSellingPrice = ($averageUnitPrice + $rakutenPostage + $rakutenGrossProfit) / (100 - $rakutenCommissionRate) * 100;
//                        // 楽天市場最低売価設定
//                        $netshopAIProductInfo->setRakutenLowerSellingPrice(ceil($rakutenLowerSellingPrice));
//                    }
//                }
//
//                // Yahoo!ショッピング
//                // 平均単価
//                $averageUnitPrice = $stockList->getAverageUnitPrice();
//                // Yahoo!ショッピング送料
//                $yahooPostage = $netshopAIProductInfo->getYahooPostage() == null ? 0 : $netshopAIProductInfo->getYahooPostage();
//                // Yahoo!ショッピング手数料率
//                $yahooCommissionRate = $netshopAIProductInfo->getYahooCommissionRate() == null ? 0 : $netshopAIProductInfo->getYahooCommissionRate();
//                // Yahoo!ショッピング最低利益率
//                $yahooLowerProfitRate = $netshopAIProductInfo->getYahooLowerProfitRate() == null ? 0 : $netshopAIProductInfo->getYahooLowerProfitRate();
//
//                // Yahoo!ショッピング粗利金額設定
//                $netshopAIProductInfo->setYahooGrossProfit(null);
//                // Yahoo!ショッピング最低売価設定
//                $netshopAIProductInfo->setYahooLowerSellingPrice(null);
//                // 平均単価と最低利益率があるの場合
//                if ($averageUnitPrice !== '0' && $yahooLowerProfitRate !== '0'){
//                    // Yahoo!ショッピング粗利金額計算
//                    // 粗利金額=平均単価*最低利益率
//                    $yahooGrossProfit = $averageUnitPrice * $yahooLowerProfitRate / 100;
//                    // Yahoo!ショッピング粗利金額設定
//                    $netshopAIProductInfo->setYahooGrossProfit(ceil($yahooGrossProfit));
//
//                    // 送料と手数料率があるの場合
//                    if ($yahooPostage !== '0' && $yahooCommissionRate !== '0'){
//                        // Yahoo!ショッピング最低売価計算
//                        // 最低売価=(平均単価+送料+粗利金額)/(1-手数料率)
//                        $yahooLowerSellingPrice = ($averageUnitPrice + $yahooPostage + $yahooGrossProfit) / (100 - $yahooCommissionRate) * 100;
//                        // Yahoo!ショッピング最低売価設定
//                        $netshopAIProductInfo->setYahooLowerSellingPrice(ceil($yahooLowerSellingPrice));
//                    }
//                }
//
//                // Amazon
//                // 平均単価
//                $averageUnitPrice = $stockList->getAverageUnitPrice();
//                // Amazon送料
//                $AmazonPostage = $netshopAIProductInfo->getAmazonPostage() == null ? 0 : $netshopAIProductInfo->getAmazonPostage();
//                // Amazon手数料率
//                $AmazonCommissionRate = $netshopAIProductInfo->getAmazonCommissionRate() == null ? 0 : $netshopAIProductInfo->getAmazonCommissionRate();
//                // Amazon最低利益率
//                $AmazonLowerProfitRate = $netshopAIProductInfo->getAmazonLowerProfitRate() == null ? 0 : $netshopAIProductInfo->getAmazonLowerProfitRate();
//
//                // Amazon粗利金額設定
//                $netshopAIProductInfo->setAmazonGrossProfit(null);
//                // Amazon最低売価設定
//                $netshopAIProductInfo->setAmazonLowerSellingPrice(null);
//                // 平均単価と最低利益率があるの場合
//                if ($averageUnitPrice !== '0' && $AmazonLowerProfitRate !== '0'){
//                    // Amazon粗利金額計算
//                    // 粗利金額=平均単価*最低利益率
//                    $AmazonGrossProfit = $averageUnitPrice * $AmazonLowerProfitRate / 100;
//                    // Amazon粗利金額設定
//                    $netshopAIProductInfo->setAmazonGrossProfit(ceil($AmazonGrossProfit));
//
//                    // 送料と手数料率があるの場合
//                    if ($AmazonPostage !== '0' && $AmazonCommissionRate !== '0'){
//                        // Amazon最低売価計算
//                        // 最低売価=(平均単価+送料+粗利金額)/(1-手数料率)
//                        $AmazonLowerSellingPrice = ($averageUnitPrice + $AmazonPostage + $AmazonGrossProfit) / (100 - $AmazonCommissionRate) * 100;
//                        // Amazon最低売価設定
//                        $netshopAIProductInfo->setAmazonLowerSellingPrice(ceil($AmazonLowerSellingPrice));
//                    }
//                }
//
//                // 自社ショップ
//                // 平均単価
//                $averageUnitPrice = $stockList->getAverageUnitPrice();
//                // 自社ショップ送料
//                $KakakuPostage = $netshopAIProductInfo->getKakakuPostage() == null ? 0 : $netshopAIProductInfo->getKakakuPostage();
//                // 自社ショップ手数料率
//                $KakakuCommissionRate = $netshopAIProductInfo->getKakakuCommissionRate() == null ? 0 : $netshopAIProductInfo->getKakakuCommissionRate();
//                // 自社ショップ最低利益率
//                $KakakuLowerProfitRate = $netshopAIProductInfo->getKakakuLowerProfitRate() == null ? 0 : $netshopAIProductInfo->getKakakuLowerProfitRate();
//
//                // 自社ショップ粗利金額設定
//                $netshopAIProductInfo->setKakakuGrossProfit(null);
//                // 自社ショップ最低売価設定
//                $netshopAIProductInfo->setKakakuLowerSellingPrice(null);
//                // 平均単価と最低利益率があるの場合
//                if ($averageUnitPrice !== '0' && $KakakuLowerProfitRate !== '0'){
//                    // 自社ショップ粗利金額計算
//                    // 粗利金額=平均単価*最低利益率
//                    $KakakuGrossProfit = $averageUnitPrice * $KakakuLowerProfitRate / 100;
//                    // 自社ショップ粗利金額設定
//                    $netshopAIProductInfo->setKakakuGrossProfit(ceil($KakakuGrossProfit));
//
//                    // 送料と手数料率があるの場合
//                    if ($KakakuPostage !== '0' && $KakakuCommissionRate !== '0'){
//                        // 自社ショップ最低売価計算
//                        // 最低売価=(平均単価+送料+粗利金額)/(1-手数料率)
//                        $KakakuLowerSellingPrice = ($averageUnitPrice + $KakakuPostage + $KakakuGrossProfit) / (100 - $KakakuCommissionRate) * 100;
//                        // 自社ショップ最低売価設定
//                        $netshopAIProductInfo->setKakakuLowerSellingPrice(ceil($KakakuLowerSellingPrice));
//                    }
//                }
            }
        } else {
            // 連動商品
            $netshopAIProductInfo = $this->NetshopaiProductInfoRepository->find($id);

            // 商品名取得
            $name = $netshopAIProductInfo->getProductClass()->getProduct()->getName();

            // 商品数取得
            $productQuantity = $this->NetshopaiProductInfoRepository
                ->createQueryBuilder('n')
                ->Select('count(n.id)')
                ->where('n.priceInterlockingLevel = :level')
                ->setParameter('level', $netshopAIProductInfo->getPriceInterlockingLevel())
                ->getQuery()
                ->getSingleScalarResult();

            $netshopAIProductInfo->setName($name);
            $netshopAIProductInfo->setProductQuantity($productQuantity);

            // 更新情報取得
            $update_date = $netshopAIProductInfo->getUpdateDate()->format('Y/m/d H:i:s');
            $update_User_Name = $netshopAIProductInfo->getUpdateUserName();

            // 在庫情報
            $stockList = $this->stockListProductUnitRepository
                ->findOneBy(
                    [
                        'productCode' => $netshopAIProductInfo->getProductCode(),
                        'State' => $netshopAIProductInfo->getState(),
                    ]
                );

            // 在庫情報なしの場合、初期値設定
            if (is_null($stockList)){
                $stockList = new StockListProductUnit();
                $stockList->setProductCode($netshopAIProductInfo->getProductCode());
                $stockList->setStockQuantity(0);
                $stockList->setProvisionalShipmentQuantity(0);
                $stockList->setOrderQuantity(0);
                $stockList->setRemainingStockQuantity(0);
                $stockList->setAverageUnitPrice(0);
                // 平均単価
                $averageUnitPrice = 0;
            } else {
                $averageUnitPrice = $stockList->getAverageUnitPrice();
            }

            // 最新の平均単価に手動設定金額計算
            if ($averageUnitPrice == 0) {
                $netshopAIProductInfo->setRakutenLowerSellingPrice(0);
                $netshopAIProductInfo->setYahooLowerSellingPrice(0);
                $netshopAIProductInfo->setYahoo2LowerSellingPrice(0);
                $netshopAIProductInfo->setAmazonLowerSellingPrice(0);
                $netshopAIProductInfo->setKakakuLowerSellingPrice(0);
            } else {

                // 楽天市場
                if ($netshopAIProductInfo->getRakutenLowerSellingPriceSetting() == false || $netshopAIProductInfo->getRakutenLowerSellingPriceSetting() == '0') {
                    // 楽天市場送料
                    $rakutenPostage = $netshopAIProductInfo->getRakutenPostage();
                    // 楽天市場手数料率
                    $rakutenCommissionRate = $netshopAIProductInfo->getRakutenCommissionRate();
                    // 楽天市場粗利金額
                    $rakutenGrossProfit = $netshopAIProductInfo->getRakutenGrossProfit();
                    // 最低売価計算(=(平均単価+送料+粗利金額)/(1-手数料率))
                    if ($rakutenCommissionRate == 100) {
                        $rakutenLowerSellingPrice = null;
                    } else {
                        $rakutenLowerSellingPrice = ($averageUnitPrice + $rakutenPostage + $rakutenGrossProfit) / (100 - $rakutenCommissionRate) * 100;
                    }
                    // 楽天市場最低売価設定
                    $netshopAIProductInfo->setRakutenLowerSellingPrice(ceil($rakutenLowerSellingPrice));
                }



                // Yahoo!ショッピング
                if ($netshopAIProductInfo->getYahooLowerSellingPriceSetting() == false || $netshopAIProductInfo->getYahooLowerSellingPriceSetting() == '0') {
                    // Yahoo!ショッピング送料
                    $yahooPostage = $netshopAIProductInfo->getYahooPostage();
                    // Yahoo!ショッピング手数料率
                    $yahooCommissionRate = $netshopAIProductInfo->getYahooCommissionRate();
                    // Yahoo!ショッピング粗利金額
                    $yahooGrossProfit = $netshopAIProductInfo->getYahooGrossProfit();
                    // 最低売価計算(=(平均単価+送料+粗利金額)/(1-手数料率))
                    if ($yahooCommissionRate == 100) {
                        $yahooLowerSellingPrice = null;
                    } else {
                        $yahooLowerSellingPrice = ($averageUnitPrice + $yahooPostage + $yahooGrossProfit) / (100 - $yahooCommissionRate) * 100;
                    }
                    // Yahoo!ショッピング最低売価設定
                    $netshopAIProductInfo->setYahooLowerSellingPrice(ceil($yahooLowerSellingPrice));
                }

                // Yahoo2!ショッピング
                if ($netshopAIProductInfo->getYahoo2LowerSellingPriceSetting() == false || $netshopAIProductInfo->getYahoo2LowerSellingPriceSetting() == '0') {
                    // Yahoo2!ショッピング送料
                    $yahoo2Postage = $netshopAIProductInfo->getYahoo2Postage();
                    // Yahoo2!ショッピング手数料率
                    $yahoo2CommissionRate = $netshopAIProductInfo->getYahoo2CommissionRate();
                    // Yahoo2!ショッピング粗利金額
                    $yahoo2GrossProfit = $netshopAIProductInfo->getYahoo2GrossProfit();
                    // 最低売価計算(=(平均単価+送料+粗利金額)/(1-手数料率))
                    if ($yahoo2CommissionRate == 100) {
                        $yahoo2LowerSellingPrice = null;
                    } else {
                        $yahoo2LowerSellingPrice = ($averageUnitPrice + $yahoo2Postage + $yahoo2GrossProfit) / (100 - $yahoo2CommissionRate) * 100;
                    }
                    // Yahoo2!ショッピング最低売価設定
                    $netshopAIProductInfo->setYahoo2LowerSellingPrice(ceil($yahoo2LowerSellingPrice));
                }

                // Amazon
                if ($netshopAIProductInfo->getAmazonLowerSellingPriceSetting() == false || $netshopAIProductInfo->getAmazonLowerSellingPriceSetting() == '0') {
                    // Amazon送料
                    $amazonPostage = $netshopAIProductInfo->getAmazonPostage();
                    // Amazon手数料率
                    $amazonCommissionRate = $netshopAIProductInfo->getAmazonCommissionRate();
                    // Amazon粗利金額
                    $amazonGrossProfit = $netshopAIProductInfo->getAmazonGrossProfit();
                    // 最低売価計算(=(平均単価+送料+粗利金額)/(1-手数料率))
                    if ($amazonCommissionRate == 100) {
                        $amazonLowerSellingPrice = null;
                    } else {
                        $amazonLowerSellingPrice = ($averageUnitPrice + $amazonPostage + $amazonGrossProfit) / (100 - $amazonCommissionRate) * 100;
                    }
                    // Amazon最低売価設定
                    $netshopAIProductInfo->setAmazonLowerSellingPrice(ceil($amazonLowerSellingPrice));
                }

                // 自社ショップ
                if ($netshopAIProductInfo->getKakakuLowerSellingPriceSetting() == false || $netshopAIProductInfo->getKakakuLowerSellingPriceSetting() == '0') {
                    // 自社ショップ送料
                    $kakakuPostage = $netshopAIProductInfo->getKakakuPostage();
                    // 自社ショップ手数料率
                    $kakakuCommissionRate = $netshopAIProductInfo->getKakakuCommissionRate();
                    // 自社ショップ粗利金額
                    $kakakuGrossProfit = $netshopAIProductInfo->getKakakuGrossProfit();
                    // 最低売価計算(=(平均単価+送料+粗利金額)/(1-手数料率))
                    if ($kakakuCommissionRate == 100) {
                        $kakakuLowerSellingPrice = null;
                    } else {
                        $kakakuLowerSellingPrice = ($averageUnitPrice + $kakakuPostage + $kakakuGrossProfit) / (100 - $kakakuCommissionRate) * 100;
                    }
                    // 自社ショップ最低売価設定
                    $netshopAIProductInfo->setKakakuLowerSellingPrice(ceil($kakakuLowerSellingPrice));
                }
            }
        }

        // 在庫フォーム
        $builder = $this->formFactory
            ->createBuilder(NetshopAIProductSearchType::class, $stockList);

        $event = new EventArgs(
            [
                'builder' => $builder,
                '$stockList' => $stockList,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_NEW_SEARCH_STOCK_INITIALIZE, $event);

        $searchForm = $builder->getForm();

        $searchForm->handleRequest($request);

        // 商品選択フォーム
        $builder = $this->formFactory
            ->createBuilder(SearchProductType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_NEW_SEARCH_PRODUCT_INITIALIZE, $event);

        $searchProductModalForm = $builder->getForm();

        // 更新者にログインユーザー設定
        $netshopAIProductInfo->setUpdateUserName($this->getUser());

        // 連動商品フォーム
        $builder = $this->formFactory->createBuilder(ProductNewType::class, $netshopAIProductInfo);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'netshopAIProductInfo' => $netshopAIProductInfo,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_NEW_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();

        if (!is_null($productCode)) {
            /** @var $Product \Eccube\Entity\Product */
            $product = $this->productRepository->findProductsWithProductCode($productCode);

            if (!empty($product) && !empty($product[0])) {
                /** @var Product $entity_product */
                $category_id = $product[0]['category_id'];
            } else {
                $category_id = null;
            }
        } else {
            $category_id = null;
        }

        // 状態
        $entity_state = $this->StateRepository->getStateByCategory();
//        if (!is_null($productCode)) {
//            /** @var $Product \Eccube\Entity\Product */
//            $product = $this->productRepository->findProductsWithProductCode($productCode);
//
//            if (!empty($product) && !empty($product[0])) {
//                /** @var Product $entity_product */
//                $category_id = $product[0]['category_id'];
//
//                /** @var $Category \Eccube\Entity\Category */
//                $category = $this->categoryRepository->find($category_id);
//
//                /** @var $State \Eccube\Entity\State */
//                $entity_state = $this->StateRepository->getStateByCategory($category);
//            } else {
//                // 状態
//                $entity_state = $this->StateRepository->getStateByCategory();
//            }
//        } else {
//            // 状態
//            $entity_state = $this->StateRepository->getStateByCategory();
//        }

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // 商品情報追加
            $productClass = $this->productClassRepository->findOneBy(
                [
                    'code'=> $netshopAIProductInfo->getProductCode()
                ]
            );
            $netshopAIProductInfo->setProductClass($productClass);

            // 最低売価自動設定の場合、「0」で「最低売価」を登録
            // 楽天市場
            if ($netshopAIProductInfo->getRakutenLowerSellingPriceSetting() == false){
                $netshopAIProductInfo->setRakutenLowerSellingPrice(0);
            }
            // Yahoo!ショッピング
            if ($netshopAIProductInfo->getYahooLowerSellingPriceSetting() == false){
                $netshopAIProductInfo->setYahooLowerSellingPrice(0);
            }

            // Yahoo2!ショッピング
            if ($netshopAIProductInfo->getYahoo2LowerSellingPriceSetting() == false){
                $netshopAIProductInfo->setYahoo2LowerSellingPrice(0);
            }

            // Amazon
            if ($netshopAIProductInfo->getAmazonLowerSellingPriceSetting() == false){
                $netshopAIProductInfo->setAmazonLowerSellingPrice(0);
            }

            // 自社ショップ
            if ($netshopAIProductInfo->getKakakuLowerSellingPriceSetting() == false){
                $netshopAIProductInfo->setKakakuLowerSellingPrice(0);
            }

            // 新規の場合、ネットショップ連動結果にデータを登録する。
            if ($id == null){
                // 楽天市場
                $rakutenNetshopaiResult = new NetshopaiResult();
                $rakutenNetshopaiResult->setAiProduct($netshopAIProductInfo);
                $rakutenNetshop = $this->NetshopRepository->find(Netshop::RAKUTEN);
                $rakutenNetshopaiResult->setShop($rakutenNetshop);
                // 初期値と作成者追加
                $rakutenNetshopaiResult->setPriceJobid(0);
                $rakutenNetshopaiResult->setStockJobid(0);
                $rakutenNetshopaiResult->setPriceAiDate(new \DateTime());
                $rakutenNetshopaiResult->setStockAiDate(new \DateTime());
                $rakutenNetshopaiResult->setStock(0);
                $rakutenNetshopaiResult->setOrderQuantity(0);
                $rakutenNetshopaiResult->setTempShipmentQuantity(0);
                $rakutenNetshopaiResult->setRemainingShipmentQuantity(0);
                $rakutenNetshopaiResult->setAiShipmentQuantity(0);
                $rakutenNetshopaiResult->setAvaregePrice(999999999);
                $rakutenNetshopaiResult->setShopPrice(999999999);
                $rakutenNetshopaiResult->setProfitRate(999.99);
                $rakutenNetshopaiResult->setGrossProfit(999999999);
                $rakutenNetshopaiResult->setLowerSellingPrice(999999999);
                $rakutenNetshopaiResult->setUpperSellingPrice(999999999);
                $rakutenNetshopaiResult->setCompetitorsSellingPrice(999999999);
                $rakutenNetshopaiResult->setPriceRanking(99);
                $rakutenNetshopaiResult->setCompetitorsDifference(999999999);
                $rakutenNetshopaiResult->setAdjustmentRule(999999999);
                $rakutenNetshopaiResult->setCreateUserName($this->getUser());
                $rakutenNetshopaiResult->setUpdateUserName($this->getUser());
                $this->entityManager->persist($rakutenNetshopaiResult);

                // Yahoo!ショッピング
                $yahooNetshopaiResult = new NetshopaiResult();
                $yahooNetshopaiResult->setAiProduct($netshopAIProductInfo);
                $yahooNetshop = $this->NetshopRepository->find(Netshop::YAHOO);
                $yahooNetshopaiResult->setShop($yahooNetshop);
                // 初期値と作成者追加
                $yahooNetshopaiResult->setPriceJobid(0);
                $yahooNetshopaiResult->setStockJobid(0);
                $yahooNetshopaiResult->setPriceAiDate(new \DateTime());
                $yahooNetshopaiResult->setStockAiDate(new \DateTime());
                $yahooNetshopaiResult->setStock(0);
                $yahooNetshopaiResult->setOrderQuantity(0);
                $yahooNetshopaiResult->setTempShipmentQuantity(0);
                $yahooNetshopaiResult->setRemainingShipmentQuantity(0);
                $yahooNetshopaiResult->setAiShipmentQuantity(0);
                $yahooNetshopaiResult->setAvaregePrice(999999999);
                $yahooNetshopaiResult->setShopPrice(999999999);
                $yahooNetshopaiResult->setProfitRate(999.99);
                $yahooNetshopaiResult->setGrossProfit(999999999);
                $yahooNetshopaiResult->setLowerSellingPrice(999999999);
                $yahooNetshopaiResult->setUpperSellingPrice(999999999);
                $yahooNetshopaiResult->setCompetitorsSellingPrice(999999999);
                $yahooNetshopaiResult->setPriceRanking(99);
                $yahooNetshopaiResult->setCompetitorsDifference(999999999);
                $yahooNetshopaiResult->setAdjustmentRule(999999999);
                $yahooNetshopaiResult->setCreateUserName($this->getUser());
                $yahooNetshopaiResult->setUpdateUserName($this->getUser());
                $this->entityManager->persist($yahooNetshopaiResult);

                // Yahoo2!ショッピング
                $yahoo2NetshopaiResult = new NetshopaiResult();
                $yahoo2NetshopaiResult->setAiProduct($netshopAIProductInfo);
                $yahoo2Netshop = $this->NetshopRepository->find(Netshop::YAHOO2);
                $yahoo2NetshopaiResult->setShop($yahoo2Netshop);
                // 初期値と作成者追加
                $yahoo2NetshopaiResult->setPriceJobid(0);
                $yahoo2NetshopaiResult->setStockJobid(0);
                $yahoo2NetshopaiResult->setPriceAiDate(new \DateTime());
                $yahoo2NetshopaiResult->setStockAiDate(new \DateTime());
                $yahoo2NetshopaiResult->setStock(0);
                $yahoo2NetshopaiResult->setOrderQuantity(0);
                $yahoo2NetshopaiResult->setTempShipmentQuantity(0);
                $yahoo2NetshopaiResult->setRemainingShipmentQuantity(0);
                $yahoo2NetshopaiResult->setAiShipmentQuantity(0);
                $yahoo2NetshopaiResult->setAvaregePrice(999999999);
                $yahoo2NetshopaiResult->setShopPrice(999999999);
                $yahoo2NetshopaiResult->setProfitRate(999.99);
                $yahoo2NetshopaiResult->setGrossProfit(999999999);
                $yahoo2NetshopaiResult->setLowerSellingPrice(999999999);
                $yahoo2NetshopaiResult->setUpperSellingPrice(999999999);
                $yahoo2NetshopaiResult->setCompetitorsSellingPrice(999999999);
                $yahoo2NetshopaiResult->setPriceRanking(99);
                $yahoo2NetshopaiResult->setCompetitorsDifference(999999999);
                $yahoo2NetshopaiResult->setAdjustmentRule(999999999);
                $yahoo2NetshopaiResult->setCreateUserName($this->getUser());
                $yahoo2NetshopaiResult->setUpdateUserName($this->getUser());
                $this->entityManager->persist($yahoo2NetshopaiResult);

                // Yahoo!ショッピング
                $amazonNetshopaiResult = new NetshopaiResult();
                $amazonNetshopaiResult->setAiProduct($netshopAIProductInfo);
                $amazonNetshop = $this->NetshopRepository->find(Netshop::AMAZON);
                $amazonNetshopaiResult->setShop($amazonNetshop);
                // 初期値と作成者追加
                $amazonNetshopaiResult->setPriceJobid(0);
                $amazonNetshopaiResult->setStockJobid(0);
                $amazonNetshopaiResult->setPriceAiDate(new \DateTime());
                $amazonNetshopaiResult->setStockAiDate(new \DateTime());
                $amazonNetshopaiResult->setStock(0);
                $amazonNetshopaiResult->setOrderQuantity(0);
                $amazonNetshopaiResult->setTempShipmentQuantity(0);
                $amazonNetshopaiResult->setRemainingShipmentQuantity(0);
                $amazonNetshopaiResult->setAiShipmentQuantity(0);
                $amazonNetshopaiResult->setAvaregePrice(999999999);
                $amazonNetshopaiResult->setShopPrice(999999999);
                $amazonNetshopaiResult->setProfitRate(999.99);
                $amazonNetshopaiResult->setGrossProfit(999999999);
                $amazonNetshopaiResult->setLowerSellingPrice(999999999);
                $amazonNetshopaiResult->setUpperSellingPrice(999999999);
                $amazonNetshopaiResult->setCompetitorsSellingPrice(999999999);
                $amazonNetshopaiResult->setPriceRanking(99);
                $amazonNetshopaiResult->setCompetitorsDifference(999999999);
                $amazonNetshopaiResult->setAdjustmentRule(999999999);
                $amazonNetshopaiResult->setCreateUserName($this->getUser());
                $amazonNetshopaiResult->setUpdateUserName($this->getUser());
                $this->entityManager->persist($amazonNetshopaiResult);

                // 価格.com
                $kakakuNetshopaiResult = new NetshopaiResult();
                $kakakuNetshopaiResult->setAiProduct($netshopAIProductInfo);
                $kakakuNetshop = $this->NetshopRepository->find(Netshop::KAKAKU);
                $kakakuNetshopaiResult->setShop($kakakuNetshop);
                // 初期値と作成者追加
                $kakakuNetshopaiResult->setPriceJobid(0);
                $kakakuNetshopaiResult->setStockJobid(0);
                $kakakuNetshopaiResult->setPriceAiDate(new \DateTime());
                $kakakuNetshopaiResult->setStockAiDate(new \DateTime());
                $kakakuNetshopaiResult->setStock(0);
                $kakakuNetshopaiResult->setOrderQuantity(0);
                $kakakuNetshopaiResult->setTempShipmentQuantity(0);
                $kakakuNetshopaiResult->setRemainingShipmentQuantity(0);
                $kakakuNetshopaiResult->setAiShipmentQuantity(0);
                $kakakuNetshopaiResult->setAvaregePrice(999999999);
                $kakakuNetshopaiResult->setShopPrice(999999999);
                $kakakuNetshopaiResult->setProfitRate(999.99);
                $kakakuNetshopaiResult->setGrossProfit(999999999);
                $kakakuNetshopaiResult->setLowerSellingPrice(999999999);
                $kakakuNetshopaiResult->setUpperSellingPrice(999999999);
                $kakakuNetshopaiResult->setCompetitorsSellingPrice(999999999);
                $kakakuNetshopaiResult->setPriceRanking(99);
                $kakakuNetshopaiResult->setCompetitorsDifference(999999999);
                $kakakuNetshopaiResult->setAdjustmentRule(999999999);
                $kakakuNetshopaiResult->setCreateUserName($this->getUser());
                $kakakuNetshopaiResult->setUpdateUserName($this->getUser());
                $this->entityManager->persist($kakakuNetshopaiResult);
            }

            $this->entityManager->persist($netshopAIProductInfo);
            $this->entityManager->flush();

            $event = new EventArgs(
                [
                    'form' => $form,
                    'netshopInfo' => $netshopAIProductInfo,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(
                EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_NEW_INDEX_COMPLETE,
                $event
            );

            // キャッシュの削除
            $cacheUtil->clearDoctrineCache();

            $this->addSuccess('admin.common.save_complete', 'admin');

            return $this->redirectToRoute('admin_netshopAI_product_edit', ['id' => $netshopAIProductInfo->getId()]);
        }

        return [
            'form' => $form->createView(),
            'searchProductModalForm' => $searchProductModalForm->createView(),
            'searchForm' => $searchForm->createView(),
            'StateList' => $entity_state,
            'id' => $id,
            'productCode' => $productCode,
            'stateId' => $stateId,
            'update_date' => $update_date,
            'update_user_name' => $update_User_Name,
            'link' => $link,
            'category_id' => $category_id,
        ];
    }

    /**
     *  連動商品選択
     *
     * @Route("/%eccube_admin_route%/netshopAI/search/product", name="admin_netshopAI_search_product")
     * @Route("/%eccube_admin_route%/netshopAI/search/product/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_netshopAI_search_product_page")
     * @Template("@admin/NetshopAI/search_product.twig")
     */
    public function searchProduct(Request $request, $page_no = null, Paginator $paginator)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()) {
            log_debug('search product start.');
            $page_count = $this->eccubeConfig['eccube_default_page_count'];
            $session = $this->session;

            if ('POST' === $request->getMethod()) {
                $page_no = 1;

                $searchData = [
                    'id' => $request->get('id'),
                ];

                if ($categoryId = $request->get('category_id')) {
                    $Category = $this->categoryRepository->find($categoryId);
                    $searchData['category_id'] = $Category;
                }

                $session->set('eccube.admin.netshopAI.product.search', $searchData);
                $session->set('eccube.admin.netshopAI.product.search.page_no', $page_no);
            } else {
                $searchData = (array) $session->get('eccube.admin.netshopAI.product.search');
                if (is_null($page_no)) {
                    $page_no = intval($session->get('eccube.admin.netshopAI.product.search.page_no'));
                } else {
                    $session->set('eccube.admin.netshopAI.product.search.page_no', $page_no);
                }
            }

            $qb = $this->productRepository
                ->getQueryBuilderBySearchDataForAdmin($searchData);

            $event = new EventArgs(
                [
                    'qb' => $qb,
                    'searchData' => $searchData,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_SEARCH_PRODUCT_SEARCH, $event);

            /** @var \Knp\Component\Pager\Pagination\SlidingPagination $pagination */
            $pagination = $paginator->paginate(
                $qb,
                $page_no,
                $page_count,
                ['wrap-queries' => true]
            );

            /** @var $Products \Eccube\Entity\Product[] */
            $Products = $pagination->getItems();

            if (empty($Products)) {
                log_debug('search product not found.');
            }

            $forms = [];
            foreach ($Products as $Product) {
                /* @var $builder \Symfony\Component\Form\FormBuilderInterface */
                $builder = $this->formFactory->createNamedBuilder('', AddCartType::class, null, [
                    'product' => $this->productRepository->findWithSortedClassCategories($Product->getId()),
                ]);
                $addCartForm = $builder->getForm();
                $forms[$Product->getId()] = $addCartForm->createView();
            }

            $event = new EventArgs(
                [
                    'forms' => $forms,
                    'Products' => $Products,
                    'pagination' => $pagination,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_SEARCH_PRODUCT_COMPLETE, $event);

            return [
                'forms' => $forms,
                'Products' => $Products,
                'pagination' => $pagination,
            ];
        }
    }

    /**
     *  伝票更新時間取得
     *
     * @Route("/%eccube_admin_route%/netshopAI/search/date", name="admin_netshopAI_product_search_date")
     * @param Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function searchOrderUpdateDate(Request $request, Paginator $paginator)
    {
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
        }

        $result = [];
        $id = $request->get('id');

        if (!is_null($id)) {
            $netshopaiProductInfo = $this->NetshopaiProductInfoRepository->find($id);
            if ($netshopaiProductInfo) {
                $UpdateTimeNew = $netshopaiProductInfo->getUpdateDate()->format('Y/m/d H:i:s');
                $result['UpdateTimeNew'] = $UpdateTimeNew;
            } else {
                $result['UpdateTimeNew'] = "";
            }
        }

        return $this->json(array_merge(['status' => 'OK'], $result));
    }

    /**
     * 連動商品削除
     * @Route("/%eccube_admin_route%/netshopAI/{id}/delete", requirements={"id" = "\d+"}, name="admin_netshopAI_product_delete", methods={"DELETE"})
     * @param Request $request Request
     * @param int|null $id ID
     * @param CacheUtil|null $cacheUtil CacheUtil
     * @return \Symfony\Component\HttpFoundation\JsonResponse|RedirectResponse
     * @throws \Exception
     */
    public function delete(Request $request, int $id = null, CacheUtil $cacheUtil = null)
    {
        $this->isTokenValid();
        $session = $request->getSession();
        $page_no = intval($session->get('eccube.admin.netshopAI.search.page_count'));
        $page_no = $page_no ? $page_no : Constant::ENABLED;
        $message = null;
        $success = false;
        $member = $this->getUser();

        if (!is_null($id)) {
            /** @var NetshopaiProductInfo $netshopaiProductInfo */
            $netshopaiProductInfo = $this->NetshopaiProductInfoRepository->find($id);
            if (!$netshopaiProductInfo) {
                if ($request->isXmlHttpRequest()) {
                    $message = trans('admin.common.delete_error_already_deleted');

                    return $this->json(['success' => $success, 'message' => $message]);
                } else {
                    $this->deleteMessage();
                    $rUrl = $this->generateUrl('admin_netshopAI_product_list', ['page_no' => $page_no]).'?resume='.Constant::ENABLED;

                    return $this->redirect($rUrl);
                }
            }

            if ($netshopaiProductInfo instanceof netshopaiProductInfo) {
                log_info('連動商品削除開始', [$id]);

                $netshopaiResult = $this->NetshopaiResultRepository->findBy(
                    [
                        'aiProduct' => $netshopaiProductInfo->getId(),
                    ]);

                try {
                    // ネットショップ連動結果削除
                    if (isset($netshopaiResult)) {
                        foreach ($netshopaiResult as $detail) {
                            $this->NetshopaiResultRepository->delete($detail);
                        }
                    }

                    $stockListProductUnit = $this->stockListProductUnitRepository->findOneBy(['productCode' => $netshopaiProductInfo['productCode'], 'State' => $netshopaiProductInfo['state']]);

                    $this->NetshopaiProductInfoRepository->delete($netshopaiProductInfo);

                    if($stockListProductUnit){
                        $stockListProductUnit->setOrderQuantity(0);
                        $stockListProductUnit->setRemainingStockQuantity($stockListProductUnit->getStockQuantity() - $stockListProductUnit->getProvisionalShipmentQuantity());
                        $stockListProductUnit->setUpdateUserName($this->getUser()['name']);
                        $stockListProductUnit->setUpdateDate(new \DateTime());
                        $this->entityManager->persist($stockListProductUnit);
                    }

                    $this->entityManager->flush();

                    $event = new EventArgs(
                        [
                            'NetshopaiProductInfo' => $netshopaiProductInfo,
                            'NetshopaiResult' => $netshopaiResult,
                        ],
                        $request
                    );
                    $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_DELETE_COMPLETE, $event);

                    log_info('連動商品削除完了', [$id]);

                    $success = true;
                    $message = trans('admin.common.delete_complete');

                    $cacheUtil->clearDoctrineCache();
                } catch (ForeignKeyConstraintViolationException $e) {
                    log_info('連動商品ー削除エラー', [$id]);
                    $message = trans('admin.common.delete_error_foreign_key', ['%name%' => $netshopaiProductInfo->getId()]);
                } catch (\Exception $e) {
                    log_info('連動商品ー削除エラー', [$id]);
                    $message = trans('admin.common.delete_error');
                }
            } else {
                log_info('連動商品ー削除エラー', [$id]);
                $message = trans('admin.common.delete_error');
            }
        } else {
            log_info('連動商品ー削除エラー', [$id]);
            $message = trans('admin.common.delete_error');
        }

        if ($request->isXmlHttpRequest()) {
            return $this->json(['success' => $success, 'message' => $message]);
        } else {
            if ($success) {
                $this->addSuccess($message, 'admin');
                $rUrl = $this->generateUrl('admin_netshopAI_product_list', ['page_no' => $page_no]).'?resume='.Constant::ENABLED;
            } else {
                $this->addError($message, 'admin');
                $rUrl = $this->generateUrl('admin_netshopAI_product_edit', ['id' => $id]);
            }

            return $this->redirect($rUrl);
        }
    }
}
