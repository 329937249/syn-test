<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\NetshopAI;

use Eccube\Controller\Admin\AbstractCsvImportController;
use Eccube\Entity\Master\Netshop;
use Eccube\Entity\NetshopaiCSVSaleErrDetail;
use Eccube\Entity\NetshopaiProductInfo;
use Eccube\Form\Type\Admin\NetshopAICsvImportType;
use Eccube\Repository\NetshopaiProductInfoRepository;
use Eccube\Repository\NetshopaiCSVHistoryRepository;
use Eccube\Repository\NetshopaiCSVErrDetailRepository;
use Eccube\Repository\NetshopInfoRepository;
use Eccube\Repository\StockListProductUnitRepository;
use Eccube\Repository\NetshopaiCSVSaleErrDetailRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Util\CacheUtil;
use Eccube\Util\FormUtil;
use Eccube\Util\StringUtil;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Validator\Validator\ValidatorInterface;

class NetshopAICsvImportController extends AbstractCsvImportController
{

    /**
     * @var NetshopaiProductInfoRepository
     */
    protected $netshopaiProductInfoRepository;

    /**
     * @var NetshopInfoRepository
     */
    protected $netshopInfoRepository;

    /**
     * @var StockListProductUnitRepository
     */
    protected $stockListProductUnitRepository;

    /**
     * @var NetshopaiCSVHistoryRepository
     */
    protected $netshopaiCSVHistoryRepository;

    /**
     * @var NetshopaiCSVSaleErrDetailRepository
     */
    protected $netshopaiCSVSaleErrDetailRepository;

    /**
     * @var NetshopaiCSVErrDetailRepository
     */
    protected $netshopaiCSVErrDetailRepository;

    /**
     * @var ProductRepository
     */
    protected $productRepository;


    /**
     * @var ValidatorInterface
     */
    protected $validator;

    private $errors = [];

    /**
     * CsvImportController constructor.
     *
     * @param NetshopaiProductInfoRepository $netshopaiProductInfoRepository
     * @param NetshopInfoRepository $netshopInfoRepository
     * @param StockListProductUnitRepository $stockListProductUnitRepository
     * @param NetshopaiCSVHistoryRepository $netshopaiCSVHistoryRepository
     * @param NetshopaiCSVSaleErrDetailRepository $netshopaiCSVSaleErrDetailRepository
     * @param NetshopaiCSVErrDetailRepository $netshopaiCSVErrDetailRepository
     * @param ProductRepository $productRepository
     * @throws \Exception
     */
    public function __construct(
        NetshopaiProductInfoRepository $netshopaiProductInfoRepository,
        NetshopInfoRepository $netshopInfoRepository,
        StockListProductUnitRepository $stockListProductUnitRepository,
        NetshopaiCSVHistoryRepository $netshopaiCSVHistoryRepository,
        NetshopaiCSVSaleErrDetailRepository $netshopaiCSVSaleErrDetailRepository,
        NetshopaiCSVErrDetailRepository $netshopaiCSVErrDetailRepository,
        ProductRepository $productRepository
    ) {
        $this->netshopaiProductInfoRepository = $netshopaiProductInfoRepository;
        $this->netshopInfoRepository = $netshopInfoRepository;
        $this->stockListProductUnitRepository = $stockListProductUnitRepository;
        $this->netshopaiCSVHistoryRepository = $netshopaiCSVHistoryRepository;
        $this->netshopaiCSVSaleErrDetailRepository = $netshopaiCSVSaleErrDetailRepository;
        $this->netshopaiCSVErrDetailRepository = $netshopaiCSVErrDetailRepository;
        $this->productRepository = $productRepository;
    }

    /**
     * ネットショップCSVアップロード
     *
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/netshopAI_csv_upload", name="admin_netshopAI_csv_import")
     * @Template("@admin/NetshopAI/csv_product.twig")
     *
     * @return array
     *
     * @throws \Doctrine\DBAL\ConnectionException
     * @throws \Doctrine\ORM\NoResultException
     */
    public function csvProduct(Request $request, CacheUtil $cacheUtil)
    {
        ini_set('memory_limit', '2048M');

        $form = $this->formFactory->createBuilder(NetshopAICsvImportType::class)->getForm();

//        $headers = $this->getProductCsvHeader();
        $rakutenHeaders = $this->getRakutenCsvHeader();
        $yahooHeaders = $this->getYahooCsvHeader();
        $yahoo2Headers = $this->getYahoo2CsvHeader();
        $amazonHeaders = $this->getAmazonCsvHeader();
        $kakakuHeaders = $this->getKakakuCsvHeader();

        $rakutenErrList = [];
        $yahooErrList = [];
        $yahoo2ErrList = [];
        $amazonErrList = [];
        $kakakuErrList = [];

        $rakutenCsvErrList = [];
        $yahooCsvErrList = [];
        $yahoo2CsvErrList = [];
        $amazonCsvErrList = [];
        $kakakuCsvErrList = [];

        // 操作履歴
        $netshopaiCSVHistories = $this->getSearchData();
        foreach ($netshopaiCSVHistories as $key => $netshopaiCSVHistory){
            $netshopaiCSVHistories[$key]['update_date'] = $this->makeDateStringUtcToAsiaTokyo($netshopaiCSVHistory['update_date']);

            if ($netshopaiCSVHistory['shop'] == 1 && $netshopaiCSVHistory['upload_method'] == 2) {
                $rakutenErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 2 && $netshopaiCSVHistory['upload_method'] == 2) {
                $yahooErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 5 && $netshopaiCSVHistory['upload_method'] == 2) {
                $yahoo2ErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if ($netshopaiCSVHistory['shop'] == 3 && $netshopaiCSVHistory['upload_method'] == 2) {
                $amazonErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 4 && $netshopaiCSVHistory['upload_method'] == 2) {
                $kakakuErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 1 && $netshopaiCSVHistory['upload_method'] == 1) {
                $rakutenCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 2 && $netshopaiCSVHistory['upload_method'] == 1) {
                $yahooCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 5 && $netshopaiCSVHistory['upload_method'] == 1) {
                $yahoo2CsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 3 && $netshopaiCSVHistory['upload_method'] == 1) {
                $amazonCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 4 && $netshopaiCSVHistory['upload_method'] == 1) {
                $kakakuCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
        }

        if ('POST' === $request->getMethod()) {
            // 画面入力取得
            $upload_method = $request->get('admin_csv_import')['upload_method'];
            $shop_id_csv = $request->get('admin_csv_import')['shop_id_csv'];

            // CSVメソッド
            if ($upload_method === '1') {

                // ファイルチェック
                switch ($shop_id_csv) {
                    // 楽天
                    case Netshop::RAKUTEN :
//                        return $this->rakutenCsvProduct($request, $cacheUtil, $form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders);
                        return $this->rakutenCsvProduct($request, $cacheUtil, $form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList);
                        break;
                    // Yahoo
                    case Netshop::YAHOO :
//                        return $this->yahooCsvProduct($request, $cacheUtil, $form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders);
                        return $this->yahooCsvProduct($request, $cacheUtil, $form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList);
                        break;
                    // Amazon
                    case Netshop::AMAZON :
//                        return $this->amazonCsvProduct($request, $cacheUtil, $form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders);
                        return $this->amazonCsvProduct($request, $cacheUtil, $form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList);
                        break;
                    // 自社ショップ
                    case Netshop::KAKAKU :
//                        return $this->kakakuCsvProduct($request, $cacheUtil, $form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders);
                        return $this->kakakuCsvProduct($request, $cacheUtil, $form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList);
                        break;
                    // Yahoo2
                    case Netshop::YAHOO2 :
//                        return $this->yahooCsvProduct($request, $cacheUtil, $form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders);
                        return $this->yahoo2CsvProduct($request, $cacheUtil, $form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList);
                        break;
                }
            }
            // 売上メソッド
            else if ($upload_method === '2') {

                $sales_date_start = $request->get('admin_csv_import')['sales_date_start'];
                $sales_date_end = $request->get('admin_csv_import')['sales_date_end'];

                if (!(isset($sales_date_start) && $sales_date_start !== '' && isset($sales_date_end) && $sales_date_end !== '')) {
                    $this->addErrors(trans('admin.netshopAI.csv.upload_sales_date_error'));
//                    return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders, false);
                    return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                        $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList, false);
                }

//                return $this->updateOrderQuantityBySales($request, $cacheUtil, $form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders);
                return $this->updateOrderQuantityBySales($request, $cacheUtil, $form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                    $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList);

            }

        }

//        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders);
        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList);
    }


    /**
     * 楽天
     */
    protected function rakutenCsvProduct(Request $request, CacheUtil $cacheUtil, $form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories, $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList) {

        if ('POST' === $request->getMethod()) {
            $form->handleRequest($request);
            if ($form->isValid()) {
                $formFile = $form['import_file']->getData();
                if (!empty($formFile)) {
                    log_info('ネットショップCSV登録開始');
                    $data = $this->getImportData($formFile);
                    if ($data === false) {
                        $this->addErrors(trans('admin.common.csv_invalid_format'));
//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders, false);
                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList, false);
                    }
                    $getId = function ($item) {
                        return $item['id'];
                    };

                    $requireHeader = array('0' => '注文番号', '1' => 'ステータス', '2' => '注文日時', '3' => '商品管理番号', '4' => '個数');
                    $columnHeaders = $data->getColumnHeaders();

                    if (count(array_diff($requireHeader, $columnHeaders)) > 0) {
                        $this->addErrors(trans('admin.common.csv_invalid_format'));

//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders, false);
                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories, $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList,
                            $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList, false);
                    }

                    $size = count($data);

                    if ($size < 1) {
                        $this->addErrors(trans('admin.common.csv_invalid_no_data'));

//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders, false);
                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList,false);
                    }

                    $headerByKey = array_flip(array_map($getId, $rakutenHeaders));

                    $this->entityManager->getConfiguration()->setSQLLogger(null);
                    $this->entityManager->getConnection()->beginTransaction();
                    $productItems = [];
                    $time = date('Y-m-d H:i:s', strtotime('2020/01/01 00:00:00'));
                    $successCount = 0;
                    // CSVファイルの登録処理
                    foreach ($data as $row) {
                        $line = $data->key() + 1;
                        if (count($columnHeaders) != count($row)) {
                            $message = trans('admin.common.csv_invalid_format_line', ['%line%' => $line]);
                            $this->addErrors($message);
                            continue;
                        }

                        if (!isset($row[$headerByKey['status']]) || StringUtil::isBlank($row[$headerByKey['status']])) {
                            $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => 'ステータス']);
                            $this->addErrors($message);
                            continue;
                        } else if (!isset($row[$headerByKey['order_time']]) || StringUtil::isBlank($row[$headerByKey['order_time']])) {
                            $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => '注文日時']);
                            $this->addErrors($message);
                            continue;
                        } else if (!isset($row[$headerByKey['product_shop_key']]) || StringUtil::isBlank($row[$headerByKey['product_shop_key']])) {
                            $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => '商品管理番号']);
                            $this->addErrors($message);
                            continue;
                        } else if (!isset($row[$headerByKey['quantity']]) || StringUtil::isBlank($row[$headerByKey['quantity']])) {
                            $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => '個数']);
                            $this->addErrors($message);
                            continue;
                        }

                        $timeCsv = date('Y/m/d H:i:s', strtotime($row[$headerByKey['order_time']]));
                        if ($time < $timeCsv) {
                            $time = $timeCsv;
                        }

                        if ($row[$headerByKey['status']] == '100' || $row[$headerByKey['status']] == '200' || $row[$headerByKey['status']] == '300' || $row[$headerByKey['status']] == '400') {

                            $key = $row[$headerByKey['product_shop_key']];

                            if(!isset($productItems[$key])){

                                // DEL-START CNC 2022/12/28 サーバロジックを修正
//                              // DB check
//                                $netshopaiProductInfo = $this->netshopaiProductInfoRepository->findOneBy(['rakutenShopKey' => $row[$headerByKey['product_shop_key']]]);
//                                if (!$netshopaiProductInfo) {
//                                    continue;
//                                } else {
//                                    $stockListProductUnit = $this->stockListProductUnitRepository
//                                        ->findOneBy([
//                                            'productCode' => $netshopaiProductInfo->getProductCode(),
//                                            'State' => $netshopaiProductInfo->getState()
//                                        ]);
//                                    if (!$stockListProductUnit) {
//                                        $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => '商品の在庫情報']);
//                                        $this->addErrors($message);
//                                        continue;
//                                    }
//                                }
                                // DEL-END CNC 2022/12/28

                                $productDetail = [
                                    'product_shop_key' => $row[$headerByKey['product_shop_key']],
                                    'quantity' => $row[$headerByKey['quantity']]
                                ];
                                $productItems[$key] = $productDetail;
                            }else{
                                $productItems[$key]['quantity'] = 0 + (
                                    isset($productItems[$key]['quantity'])
                                        ? $productItems[$key]['quantity']
                                        : 0
                                    ) + (
                                    (isset($row[$headerByKey['quantity']]) && StringUtil::isNotBlank($row[$headerByKey['quantity']]))
                                        ? $row[$headerByKey['quantity']]
                                        : 0
                                    );
                            }

                            $successCount = $successCount + 1;
                        } else {
                            continue;
                        }
                    }

                    if ($this->hasErrors()) {
//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders);
                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList);
                    }

//                    if ($successCount == 0) {
//                        log_info('ネットショップCSV登録完了');
//                        $message = 'admin.common.csv_upload_complete';
//                        $this->session->getFlashBag()->add('eccube.admin.success', $message);
//
//                        $cacheUtil->clearDoctrineCache();
//
//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders);
//                    }

                    $netshop = $this->netshopInfoRepository->findOneBy(['id' => '0']);
                    $netshop->setRakutenOrderSearchSuccessDatetime($time);
                    $netshop->setUpdateUserName($this->getUser()['name']);
                    $this->entityManager->persist($netshop);

                    // DEL-START CNC 2022/12/28 サーバロジックを修正
//                    $productInfos = [];
                    // DEL-END CNC 2022/12/28

                    $qb = $this->netshopaiProductInfoRepository->getQueryBuilderBySearchDataForCsvUpload('1');
                    $productInfoDbs = $qb->getQuery()->getResult();
                    // DEL-START CNC 2022/12/28 サーバロジックを修正
//                    foreach ($productInfoDbs as $productInfoDb) {
//                        $productInfos[$productInfoDb["productCode"].'_'.$productInfoDb["state"]["id"]]['productCode'] = $productInfoDb["productCode"];
//                        $productInfos[$productInfoDb["productCode"].'_'.$productInfoDb["state"]["id"]]['state'] = $productInfoDb["state"]["id"];
//                        $productInfos[$productInfoDb["productCode"].'_'.$productInfoDb["state"]["id"]]['quantity'] = 0;
//                    }
//
//                    foreach ($productItems as $productItem) {
//                        $netshopaiProductInfo = $this->netshopaiProductInfoRepository->findOneBy(['rakutenShopKey' => $productItem['product_shop_key']]);
//                        $netshopaiProductInfo->setRakutenOrderCsvInitQuantity($productItem['quantity']);
//                        $netshopaiProductInfo->setUpdateUserName($this->getUser()['name']);
//                        $this->entityManager->persist($netshopaiProductInfo);
//
//                        $quantity = 0 + $productItem['quantity']
//                            + $netshopaiProductInfo->getYahooOrderCsvInitQuantity()
//                            + $netshopaiProductInfo->getYahoo2OrderCsvInitQuantity()
//                            + $netshopaiProductInfo->getAmazonOrderCsvInitQuantity()
//                            + $netshopaiProductInfo->getKakakuOrderCsvInitQuantity();
//                        $productCode = $netshopaiProductInfo->getProductCode();
//                        $state = $netshopaiProductInfo->getState()->getId();
//
//                        $productInfos[$productCode.'_'.$state]['productCode'] = $productCode;
//                        $productInfos[$productCode.'_'.$state]['state'] = $state;
//                        $productInfos[$productCode.'_'.$state]['quantity'] = $quantity;
//
//                    }
                    // DEL-END CNC 2022/12/28
                    $i = 0;
                    $saleErrDetails = [];
//                    $this->stockListProductUnitRepository->updateOrderQuantity();
//                    foreach ($productInfos as $productInfo) {
                    /** @var NetshopaiProductInfo $productInfo */
                    foreach ($productInfoDbs as $productInfo) {
                        // INS-START CNC 2022/12/28 サーバロジックを修正
                        $rakutenOrderQuantity = 0;

                        // CSVから受注数量取得
                        if (isset($productItems[$productInfo->getRakutenShopKey()])) {
                            $rakutenOrderQuantity = $productItems[$productInfo->getRakutenShopKey()]['quantity'];
                        }

                        $orderQuantity = 0 + $rakutenOrderQuantity
                            + $productInfo->getYahooOrderCsvInitQuantity()
                            + $productInfo->getYahoo2OrderCsvInitQuantity()
                            + $productInfo->getAmazonOrderCsvInitQuantity()
                            + $productInfo->getKakakuOrderCsvInitQuantity();

                        $productInfo->setRakutenOrderCsvInitQuantity($rakutenOrderQuantity);
                        $productInfo->setUpdateUserName($this->getUser()['name']);
                        $this->entityManager->persist($productInfo);

                        $stockListProduct = $this->stockListProductUnitRepository->findOneBy(['productCode' => $productInfo->getProductCode(), 'State' => $productInfo->getState()->getId()]);
                        if ($stockListProduct) {
                            // 受注数量
                            $stockListProduct->setOrderQuantity($orderQuantity);
                            // 残在庫数量　= 在庫数量-受注数量-仮出荷数量
                            $remainingStockQuantity = 0 + $stockListProduct->getStockQuantity() - $orderQuantity - $stockListProduct->getProvisionalShipmentQuantity();
                            $stockListProduct->setRemainingStockQuantity($remainingStockQuantity);
                            $stockListProduct->setUpdateUserName($this->getUser()['name']);
                            $this->entityManager->persist($stockListProduct);

                            if (isset($productItems[$productInfo->getRakutenShopKey()])) {
                                $product = $this->productRepository->findOneBy(['id' => $stockListProduct->getProductId()]);
                                if ($stockListProduct->getStockQuantity() - $orderQuantity < 0){
                                    $saleErrDetails[$i] = [
                                        'productCode' => $productInfo->getProductCode(),
                                        'productName' => $product->getName(),
                                        'stateName' => $stockListProduct->getState()->getState(),
                                        'orderQuantity' => $orderQuantity,
                                        'stockQuantity' => $stockListProduct->getStockQuantity(),
                                    ];
                                    $i++;
                                }
                            }
                        }
                        // INS-END CNC 2022/12/28

                        // DEL-START CNC 2022/12/28 サーバロジックを修正
//                        $before_quantity = $productInfo['quantity'];
//
//                        if ($productInfo['quantity'] === 0) {
//                            $netshopaiProductInfo = $this->netshopaiProductInfoRepository->findOneBy(['productCode' => $productInfo['productCode'], 'state' => $productInfo['state']]);
//                            $netshopaiProductInfo->setRakutenOrderCsvInitQuantity(0);
//                            $netshopaiProductInfo->setUpdateUserName($this->getUser()['name']);
//                            $this->entityManager->persist($netshopaiProductInfo);
//
//                            $productInfo['quantity'] = 0+ 0
//                                + $netshopaiProductInfo->getYahooOrderCsvInitQuantity()
//                                + $netshopaiProductInfo->getYahoo2OrderCsvInitQuantity()
//                                + $netshopaiProductInfo->getAmazonOrderCsvInitQuantity()
//                                + $netshopaiProductInfo->getKakakuOrderCsvInitQuantity();
//                        }
//
//                        $stockListProduct = $this->stockListProductUnitRepository->findOneBy(['productCode' => $productInfo['productCode'], 'State' => $productInfo['state']]);
//                        if ($stockListProduct) {
//                            // 受注数量
//                            $stockListProduct->setOrderQuantity($productInfo['quantity']);
//                            // 残在庫数量　= 在庫数量-受注数量-仮出荷数量
//                            $remainingStockQuantity = 0 + $stockListProduct->getStockQuantity() - $productInfo['quantity'] - $stockListProduct->getProvisionalShipmentQuantity();
//                            $stockListProduct->setRemainingStockQuantity($remainingStockQuantity);
//                            $stockListProduct->setUpdateUserName($this->getUser()['name']);
//                            $this->entityManager->persist($stockListProduct);
//
//                            $product = $this->productRepository->findOneBy(['id' => $stockListProduct->getProductId()]);
//                            if($before_quantity > 0 && $stockListProduct->getStockQuantity() - $productInfo['quantity'] < 0){
//                                $saleErrDetails[$i] = [
//                                    'productCode' => $productInfo['productCode'],
//                                    'productName' => $product->getName(),
//                                    'stateName' => $stockListProduct->getState()->getState(),
//                                    'orderQuantity' => $productInfo['quantity'],
//                                    'stockQuantity' => $stockListProduct->getStockQuantity(),
//                                ];
//                                $i++;
//                            }
//                        }
                        // DEL-END CNC 2022/12/28
                    }

                    $this->netshopaiCSVHistoryRepository->insertNetshopaiCSVHistory('1','1','', '',$this->getUser()['name']);

                    $newCSVHistory = $this->netshopaiCSVHistoryRepository->findOneBy(['shop' => 1, 'upload_method' => 1], ['updateDate' => 'DESC']);
                    $newCSVHistory_id = $newCSVHistory->getId();
                    if($saleErrDetails != null){
                        foreach ($saleErrDetails as $saleErrDetail){
                            $this->netshopaiCSVErrDetailRepository->insertNetshopaiCSVErrInfo($newCSVHistory_id, $saleErrDetail['productCode'], $saleErrDetail['productName'],
                                $saleErrDetail['stateName'], $saleErrDetail['orderQuantity'], $saleErrDetail['stockQuantity'], $this->getUser()['name']);
                        }
                    }

                    $this->entityManager->flush();
                    $this->entityManager->getConnection()->commit();

                    log_info('ネットショップCSV登録完了');
                    $message = 'admin.common.csv_upload_complete';
                    $this->session->getFlashBag()->add('eccube.admin.success', $message);

                    $cacheUtil->clearDoctrineCache();
                }
            }
        }
        // 操作履歴
        $netshopaiCSVHistories = $this->getSearchData();
        foreach ($netshopaiCSVHistories as $key => $netshopaiCSVHistory){
            $netshopaiCSVHistories[$key]['update_date'] = $this->makeDateStringUtcToAsiaTokyo($netshopaiCSVHistory['update_date']);

            if ($netshopaiCSVHistory['shop'] == 1 && $netshopaiCSVHistory['upload_method'] == 2) {
                $rakutenErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 2 && $netshopaiCSVHistory['upload_method'] == 2) {
                $yahooErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 5 && $netshopaiCSVHistory['upload_method'] == 2) {
                $yahoo2ErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if ($netshopaiCSVHistory['shop'] == 3 && $netshopaiCSVHistory['upload_method'] == 2) {
                $amazonErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 4 && $netshopaiCSVHistory['upload_method'] == 2) {
                $kakakuErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 1 && $netshopaiCSVHistory['upload_method'] == 1) {
                $rakutenCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 2 && $netshopaiCSVHistory['upload_method'] == 1) {
                $yahooCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 5 && $netshopaiCSVHistory['upload_method'] == 1) {
                $yahoo2CsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 3 && $netshopaiCSVHistory['upload_method'] == 1) {
                $amazonCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 4 && $netshopaiCSVHistory['upload_method'] == 1) {
                $kakakuCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
        }
//        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders);
        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList);
    }

    /**
     * Yahoo
     */
    protected function yahooCsvProduct(Request $request, CacheUtil $cacheUtil, $form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories, $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList) {

        if ('POST' === $request->getMethod()) {
            $form->handleRequest($request);
            if ($form->isValid()) {
                $formFile = $form['import_file']->getData();
                if (!empty($formFile)) {
                    log_info('ネットショップCSV登録開始');
                    $data = $this->getImportData($formFile);
                    if ($data === false) {
                        $this->addErrors(trans('admin.common.csv_invalid_format'));
//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders, false);
                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList, false);
                    }
                    $getId = function ($item) {
                        return $item['id'];
                    };

                    $requireHeader = array('0' => 'OrderId', '1' => 'OrderTime', '2' => 'OrderStatus', '3' => 'ItemId', '4' => 'QuantityDetail');
                    $columnHeaders = $data->getColumnHeaders();

                    if (count(array_diff($requireHeader, $columnHeaders)) > 0) {
                        $this->addErrors(trans('admin.common.csv_invalid_format'));

//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders, false);
                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList, false);
                    }

                    $size = count($data);

                    if ($size < 1) {
                        $this->addErrors(trans('admin.common.csv_invalid_no_data'));

//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders, false);
                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList, false);
                    }

                    $headerByKey = array_flip(array_map($getId, $yahooHeaders));

                    $this->entityManager->getConfiguration()->setSQLLogger(null);
                    $this->entityManager->getConnection()->beginTransaction();
                    $productItems = [];
                    $time = date('Y/m/d H:i:s', strtotime('2020/01/01 00:00:00'));
                    $successCount = 0;
                    // CSVファイルの登録処理
                    foreach ($data as $row) {
                        $line = $data->key() + 1;
                        if (count($columnHeaders) != count($row)) {
                            $message = trans('admin.common.csv_invalid_format_line', ['%line%' => $line]);
                            $this->addErrors($message);
                            continue;
                        }

                        if (!isset($row[$headerByKey['order_time']]) || StringUtil::isBlank($row[$headerByKey['order_time']])) {
                            $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => 'OrderTime']);
                            $this->addErrors($message);
                            continue;
                        } else if (!isset($row[$headerByKey['status']]) || StringUtil::isBlank($row[$headerByKey['status']])) {
                            $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => 'OrderStatus']);
                            $this->addErrors($message);
                            continue;
                        } else if (!isset($row[$headerByKey['product_shop_key']]) || StringUtil::isBlank($row[$headerByKey['product_shop_key']])) {
                            $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => 'ItemId']);
                            $this->addErrors($message);
                            continue;
                        } else if (!isset($row[$headerByKey['quantity']]) || StringUtil::isBlank($row[$headerByKey['quantity']])) {
                            $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => 'QuantityDetail']);
                            $this->addErrors($message);
                            continue;
                        }

                        $timeCsv = date('Y/m/d H:i:s', strtotime($row[$headerByKey['order_time']]));
                        if ($time < $timeCsv) {
                            $time = $timeCsv;
                        }

                        if ($row[$headerByKey['status']] == '新規注文' || $row[$headerByKey['status']] == '実行中') {

                            if (strpos($row[$headerByKey['product_shop_key']], "L1=") !== false) {
                                $row[$headerByKey['product_shop_key']] = str_replace("L1=", "",
                                    str_replace("L2=", "",
                                        str_replace("L3=", "",
                                            str_replace("L4=", "",
                                                str_replace("L5=", "",
                                                    str_replace("L6=", "",
                                                        str_replace("L7=", "",
                                                            str_replace("L8=", "",
                                                                str_replace("L9=", "",
                                                                    str_replace("L10=", "", $row[$headerByKey['product_shop_key']]))))))))));

                                $row[$headerByKey['quantity']] = str_replace("L1=", "",
                                    str_replace("L2=", "",
                                        str_replace("L3=", "",
                                            str_replace("L4=", "",
                                                str_replace("L5=", "",
                                                    str_replace("L6=", "",
                                                        str_replace("L7=", "",
                                                            str_replace("L8=", "",
                                                                str_replace("L9=", "",
                                                                    str_replace("L10=", "", $row[$headerByKey['quantity']]))))))))));
                            }

                            $key = $row[$headerByKey['product_shop_key']];

                            if (strpos($key, "&") !== false) {

                                $arrKeys = explode("&", $key);
                                $arrCounts = explode("&", $row[$headerByKey['quantity']]);

                                foreach ($arrKeys as $inum => $arrKey) {

                                    $arrCount = $arrCounts[$inum];

                                    if(!isset($productItems[$arrKey])){

                                        // DEL-START CNC 2022/12/28 サーバロジックを修正
//                                        // DB check
//                                        $netshopaiProductInfo = $this->netshopaiProductInfoRepository->findOneBy(['yahooShopKey' => $arrKey]);
//                                        if (!$netshopaiProductInfo) {
//                                            continue;
//                                        } else {
//                                            $stockListProductUnit = $this->stockListProductUnitRepository
//                                                ->findOneBy([
//                                                    'productCode' => $netshopaiProductInfo->getProductCode(),
//                                                    'State' => $netshopaiProductInfo->getState()
//                                                ]);
//                                            if (!$stockListProductUnit) {
//                                                $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => '商品の在庫情報']);
//                                                $this->addErrors($message);
//                                                continue;
//                                            }
//                                        }
                                        // DEL-END CNC 2022/12/28

                                        $productDetail = [
                                            'product_shop_key' => $arrKey,
                                            'quantity' => $arrCount
                                        ];
                                        $productItems[$arrKey] = $productDetail;

                                    } else {

                                        $productItems[$arrKey]['quantity'] = 0 + (
                                            isset($productItems[$arrKey]['quantity'])
                                                ? $productItems[$arrKey]['quantity']
                                                : 0
                                            ) + (
                                            (isset($arrCount) && StringUtil::isNotBlank($arrCount))
                                                ? $arrCount
                                                : 0
                                            );
                                    }
                                }

                            } else {

                                if(!isset($productItems[$key])){

                                    // DEL-START CNC 2022/12/28 サーバロジックを修正
                                    // DB check
//                                    $netshopaiProductInfo = $this->netshopaiProductInfoRepository->findOneBy(['yahooShopKey' => $row[$headerByKey['product_shop_key']]]);
//                                    if (!$netshopaiProductInfo) {
//                                        continue;
//                                    } else {
//                                        $stockListProductUnit = $this->stockListProductUnitRepository
//                                            ->findOneBy([
//                                                'productCode' => $netshopaiProductInfo->getProductCode(),
//                                                'State' => $netshopaiProductInfo->getState()
//                                            ]);
//                                        if (!$stockListProductUnit) {
//                                            $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => '商品の在庫情報']);
//                                            $this->addErrors($message);
//                                            continue;
//                                        }
//                                    }
                                    // DEL-END CNC 2022/12/28

                                    $productDetail = [
                                        'product_shop_key' => $row[$headerByKey['product_shop_key']],
                                        'quantity' => $row[$headerByKey['quantity']]
                                    ];
                                    $productItems[$key] = $productDetail;

                                } else {

                                    $productItems[$key]['quantity'] = 0 + (
                                        isset($productItems[$key]['quantity'])
                                            ? $productItems[$key]['quantity']
                                            : 0
                                        ) + (
                                        (isset($row[$headerByKey['quantity']]) && StringUtil::isNotBlank($row[$headerByKey['quantity']]))
                                            ? $row[$headerByKey['quantity']]
                                            : 0
                                        );
                                }
                            }

                            $successCount = $successCount + 1;
                        } else {
                            continue;
                        }
                    }

                    if ($this->hasErrors()) {
//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders);
                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList);
                    }

//                    if ($successCount == 0) {
//                        log_info('ネットショップCSV登録完了');
//                        $message = 'admin.common.csv_upload_complete';
//                        $this->session->getFlashBag()->add('eccube.admin.success', $message);
//
//                        $cacheUtil->clearDoctrineCache();
//
//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders);
//                    }

                    $netshop = $this->netshopInfoRepository->findOneBy(['id' => '0']);
                    $netshop->setYahooOrderSearchSuccessDatetime($time);
                    $netshop->setUpdateUserName($this->getUser()['name']);
                    $this->entityManager->persist($netshop);

                    // DEL-START CNC 2022/12/28 サーバロジックを修正
//                    $productInfos = [];
                    // DEL-END CNC 2022/12/28

                    $qb = $this->netshopaiProductInfoRepository->getQueryBuilderBySearchDataForCsvUpload('2');
                    $productInfoDbs = $qb->getQuery()->getResult();
                    // DEL-START CNC 2022/12/28 サーバロジックを修正
//                    foreach ($productInfoDbs as $productInfoDb) {
//                        $productInfos[$productInfoDb["productCode"].'_'.$productInfoDb["state"]["id"]]['productCode'] = $productInfoDb["productCode"];
//                        $productInfos[$productInfoDb["productCode"].'_'.$productInfoDb["state"]["id"]]['state'] = $productInfoDb["state"]["id"];
//                        $productInfos[$productInfoDb["productCode"].'_'.$productInfoDb["state"]["id"]]['quantity'] = 0;
//                    }
//
//                    foreach ($productItems as $productItem) {
//                        $netshopaiProductInfo = $this->netshopaiProductInfoRepository->findOneBy(['yahooShopKey' => $productItem['product_shop_key']]);
//                        $netshopaiProductInfo->setYahooOrderCsvInitQuantity($productItem['quantity']);
//                        $netshopaiProductInfo->setUpdateUserName($this->getUser()['name']);
//                        $this->entityManager->persist($netshopaiProductInfo);
//
//                        $quantity = 0 + $netshopaiProductInfo->getRakutenOrderCsvInitQuantity()
//                            + $productItem['quantity']
//                            + $netshopaiProductInfo->getYahoo2OrderCsvInitQuantity()
//                            + $netshopaiProductInfo->getAmazonOrderCsvInitQuantity()
//                            + $netshopaiProductInfo->getKakakuOrderCsvInitQuantity();
//                        $productCode = $netshopaiProductInfo->getProductCode();
//                        $state = $netshopaiProductInfo->getState()->getId();
//
//                        $productInfos[$productCode.'_'.$state]['productCode'] = $productCode;
//                        $productInfos[$productCode.'_'.$state]['state'] = $state;
//                        $productInfos[$productCode.'_'.$state]['quantity'] = $quantity;
//
//                    }
                    // DEL-END CNC 2022/12/28
                    $i = 0;
                    $saleErrDetails = [];
//                    $this->stockListProductUnitRepository->updateOrderQuantity();
//                    foreach ($productInfos as $productInfo) {
                    /** @var NetshopaiProductInfo $productInfo */
                    foreach ($productInfoDbs as $productInfo) {
                        // INS-START CNC 2022/12/28 サーバロジックを修正
                        $yahooOrderQuantity = 0;

                        // CSVから受注数量取得
                        if (isset($productItems[$productInfo->getYahooShopKey()])) {
                            $yahooOrderQuantity = $productItems[$productInfo->getYahooShopKey()]['quantity'];
                        }

                        $orderQuantity = 0 + $productInfo->getRakutenOrderCsvInitQuantity()
                            + $yahooOrderQuantity
                            + $productInfo->getYahoo2OrderCsvInitQuantity()
                            + $productInfo->getAmazonOrderCsvInitQuantity()
                            + $productInfo->getKakakuOrderCsvInitQuantity();

                        $productInfo->setYahooOrderCsvInitQuantity($yahooOrderQuantity);
                        $productInfo->setUpdateUserName($this->getUser()['name']);
                        $this->entityManager->persist($productInfo);

                        $stockListProduct = $this->stockListProductUnitRepository->findOneBy(['productCode' => $productInfo->getProductCode(), 'State' => $productInfo->getState()->getId()]);
                        if ($stockListProduct) {
                            // 受注数量
                            $stockListProduct->setOrderQuantity($orderQuantity);
                            // 残在庫数量　= 在庫数量-受注数量-仮出荷数量
                            $remainingStockQuantity = 0 + $stockListProduct->getStockQuantity() - $orderQuantity - $stockListProduct->getProvisionalShipmentQuantity();
                            $stockListProduct->setRemainingStockQuantity($remainingStockQuantity);
                            $stockListProduct->setUpdateUserName($this->getUser()['name']);
                            $this->entityManager->persist($stockListProduct);

                            if (isset($productItems[$productInfo->getYahooShopKey()])) {
                                $product = $this->productRepository->findOneBy(['id' => $stockListProduct->getProductId()]);
                                if ($stockListProduct->getStockQuantity() - $orderQuantity < 0){
                                    $saleErrDetails[$i] = [
                                        'productCode' => $productInfo->getProductCode(),
                                        'productName' => $product->getName(),
                                        'stateName' => $stockListProduct->getState()->getState(),
                                        'orderQuantity' => $orderQuantity,
                                        'stockQuantity' => $stockListProduct->getStockQuantity(),
                                    ];
                                    $i++;
                                }
                            }
                        }
                        // INS-END CNC 2022/12/28

                        // DEL-START CNC 2022/12/28 サーバロジックを修正
//                        $before_quantity = $productInfo['quantity'];
//
//                        if ($productInfo['quantity'] === 0) {
//                            $netshopaiProductInfo = $this->netshopaiProductInfoRepository->findOneBy(['productCode' => $productInfo['productCode'], 'state' => $productInfo['state']]);
//                            $netshopaiProductInfo->setYahooOrderCsvInitQuantity(0);
//                            $netshopaiProductInfo->setUpdateUserName($this->getUser()['name']);
//                            $this->entityManager->persist($netshopaiProductInfo);
//
//                            $productInfo['quantity'] = 0+ $netshopaiProductInfo->getRakutenOrderCsvInitQuantity()
//                                + 0
//                                + $netshopaiProductInfo->getYahoo2OrderCsvInitQuantity()
//                                + $netshopaiProductInfo->getAmazonOrderCsvInitQuantity()
//                                + $netshopaiProductInfo->getKakakuOrderCsvInitQuantity();
//                        }
//
//                        $stockListProduct = $this->stockListProductUnitRepository->findOneBy(['productCode' => $productInfo['productCode'], 'State' => $productInfo['state']]);
//                        if ($stockListProduct) {
//                            // 受注数量
//                            $stockListProduct->setOrderQuantity($productInfo['quantity']);
//                            // 残在庫数量　= 在庫数量-受注数量-仮出荷数量
//                            $remainingStockQuantity = 0 + $stockListProduct->getStockQuantity() - $productInfo['quantity'] - $stockListProduct->getProvisionalShipmentQuantity();
//                            $stockListProduct->setRemainingStockQuantity($remainingStockQuantity);
//                            $stockListProduct->setUpdateUserName($this->getUser()['name']);
//                            $this->entityManager->persist($stockListProduct);
//
//                            $product = $this->productRepository->findOneBy(['id' => $stockListProduct->getProductId()]);
//                            if($before_quantity > 0 && $stockListProduct->getStockQuantity() - $productInfo['quantity'] < 0){
//                                $saleErrDetails[$i] = [
//                                    'productCode' => $productInfo['productCode'],
//                                    'productName' => $product->getName(),
//                                    'stateName' => $stockListProduct->getState()->getState(),
//                                    'orderQuantity' => $productInfo['quantity'],
//                                    'stockQuantity' => $stockListProduct->getStockQuantity(),
//                                ];
//                                $i++;
//                            }
//                        }
                        // DEL-END CNC 2022/12/28
                    }

                    $this->netshopaiCSVHistoryRepository->insertNetshopaiCSVHistory('2','1','', '',$this->getUser()['name']);

                    $newCSVHistory = $this->netshopaiCSVHistoryRepository->findOneBy(['shop' => 2, 'upload_method' => 1], ['updateDate' => 'DESC']);
                    $newCSVHistory_id = $newCSVHistory->getId();
                    if($saleErrDetails != null){
                        foreach ($saleErrDetails as $saleErrDetail){
                            $this->netshopaiCSVErrDetailRepository->insertNetshopaiCSVErrInfo($newCSVHistory_id, $saleErrDetail['productCode'], $saleErrDetail['productName'],
                                $saleErrDetail['stateName'], $saleErrDetail['orderQuantity'], $saleErrDetail['stockQuantity'], $this->getUser()['name']);
                        }
                    }

                    $this->entityManager->flush();
                    $this->entityManager->getConnection()->commit();

                    log_info('ネットショップCSV登録完了');
                    $message = 'admin.common.csv_upload_complete';
                    $this->session->getFlashBag()->add('eccube.admin.success', $message);

                    $cacheUtil->clearDoctrineCache();
                }
            }
        }
        // 操作履歴
        $netshopaiCSVHistories = $this->getSearchData();
        foreach ($netshopaiCSVHistories as $key => $netshopaiCSVHistory){
            $netshopaiCSVHistories[$key]['update_date'] = $this->makeDateStringUtcToAsiaTokyo($netshopaiCSVHistory['update_date']);

            if ($netshopaiCSVHistory['shop'] == 1 && $netshopaiCSVHistory['upload_method'] == 2) {
                $rakutenErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 2 && $netshopaiCSVHistory['upload_method'] == 2) {
                $yahooErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 5 && $netshopaiCSVHistory['upload_method'] == 2) {
                $yahoo2ErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if ($netshopaiCSVHistory['shop'] == 3 && $netshopaiCSVHistory['upload_method'] == 2) {
                $amazonErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 4 && $netshopaiCSVHistory['upload_method'] == 2) {
                $kakakuErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 1 && $netshopaiCSVHistory['upload_method'] == 1) {
                $rakutenCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 2 && $netshopaiCSVHistory['upload_method'] == 1) {
                $yahooCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 5 && $netshopaiCSVHistory['upload_method'] == 1) {
                $yahoo2CsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 3 && $netshopaiCSVHistory['upload_method'] == 1) {
                $amazonCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 4 && $netshopaiCSVHistory['upload_method'] == 1) {
                $kakakuCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
        }
//        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders);
        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList);
    }

    /**
     * Yahoo2
     */
    protected function yahoo2CsvProduct(Request $request, CacheUtil $cacheUtil, $form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories, $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList) {

        if ('POST' === $request->getMethod()) {
            $form->handleRequest($request);
            if ($form->isValid()) {
                $formFile = $form['import_file']->getData();
                if (!empty($formFile)) {
                    log_info('ネットショップCSV登録開始');
                    $data = $this->getImportData($formFile);
                    if ($data === false) {
                        $this->addErrors(trans('admin.common.csv_invalid_format'));
//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders, false);
                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList, false);
                    }
                    $getId = function ($item) {
                        return $item['id'];
                    };

                    $requireHeader = array('0' => 'OrderId', '1' => 'OrderTime', '2' => 'OrderStatus', '3' => 'ItemId', '4' => 'QuantityDetail');
                    $columnHeaders = $data->getColumnHeaders();

                    if (count(array_diff($requireHeader, $columnHeaders)) > 0) {
                        $this->addErrors(trans('admin.common.csv_invalid_format'));

//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders, false);
                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList, false);
                    }

                    $size = count($data);

                    if ($size < 1) {
                        $this->addErrors(trans('admin.common.csv_invalid_no_data'));

//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders, false);
                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList, false);
                    }

                    $headerByKey = array_flip(array_map($getId, $yahoo2Headers));

                    $this->entityManager->getConfiguration()->setSQLLogger(null);
                    $this->entityManager->getConnection()->beginTransaction();
                    $productItems = [];
                    $time = date('Y/m/d H:i:s', strtotime('2020/01/01 00:00:00'));
                    $successCount = 0;
                    // CSVファイルの登録処理
                    foreach ($data as $row) {
                        $line = $data->key() + 1;
                        if (count($columnHeaders) != count($row)) {
                            $message = trans('admin.common.csv_invalid_format_line', ['%line%' => $line]);
                            $this->addErrors($message);
                            continue;
                        }

                        if (!isset($row[$headerByKey['order_time']]) || StringUtil::isBlank($row[$headerByKey['order_time']])) {
                            $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => 'OrderTime']);
                            $this->addErrors($message);
                            continue;
                        } else if (!isset($row[$headerByKey['status']]) || StringUtil::isBlank($row[$headerByKey['status']])) {
                            $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => 'OrderStatus']);
                            $this->addErrors($message);
                            continue;
                        } else if (!isset($row[$headerByKey['product_shop_key']]) || StringUtil::isBlank($row[$headerByKey['product_shop_key']])) {
                            $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => 'ItemId']);
                            $this->addErrors($message);
                            continue;
                        } else if (!isset($row[$headerByKey['quantity']]) || StringUtil::isBlank($row[$headerByKey['quantity']])) {
                            $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => 'QuantityDetail']);
                            $this->addErrors($message);
                            continue;
                        }

                        $timeCsv = date('Y/m/d H:i:s', strtotime($row[$headerByKey['order_time']]));
                        if ($time < $timeCsv) {
                            $time = $timeCsv;
                        }

                        if ($row[$headerByKey['status']] == '新規注文' || $row[$headerByKey['status']] == '実行中') {

                            if (strpos($row[$headerByKey['product_shop_key']], "L1=") !== false) {
                                $row[$headerByKey['product_shop_key']] = str_replace("L1=", "",
                                    str_replace("L2=", "",
                                        str_replace("L3=", "",
                                            str_replace("L4=", "",
                                                str_replace("L5=", "",
                                                    str_replace("L6=", "",
                                                        str_replace("L7=", "",
                                                            str_replace("L8=", "",
                                                                str_replace("L9=", "",
                                                                    str_replace("L10=", "", $row[$headerByKey['product_shop_key']]))))))))));

                                $row[$headerByKey['quantity']] = str_replace("L1=", "",
                                    str_replace("L2=", "",
                                        str_replace("L3=", "",
                                            str_replace("L4=", "",
                                                str_replace("L5=", "",
                                                    str_replace("L6=", "",
                                                        str_replace("L7=", "",
                                                            str_replace("L8=", "",
                                                                str_replace("L9=", "",
                                                                    str_replace("L10=", "", $row[$headerByKey['quantity']]))))))))));
                            }

                            $key = $row[$headerByKey['product_shop_key']];

                            if (strpos($key, "&") !== false) {

                                $arrKeys = explode("&", $key);
                                $arrCounts = explode("&", $row[$headerByKey['quantity']]);

                                foreach ($arrKeys as $inum => $arrKey) {

                                    $arrCount = $arrCounts[$inum];

                                    if(!isset($productItems[$arrKey])){

                                        // DEL-START CNC 2022/12/28 サーバロジックを修正
                                        // DB check
//                                        $netshopaiProductInfo = $this->netshopaiProductInfoRepository->findOneBy(['yahoo2ShopKey' => $arrKey]);
//                                        if (!$netshopaiProductInfo) {
//                                            continue;
//                                        } else {
//                                            $stockListProductUnit = $this->stockListProductUnitRepository
//                                                ->findOneBy([
//                                                    'productCode' => $netshopaiProductInfo->getProductCode(),
//                                                    'State' => $netshopaiProductInfo->getState()
//                                                ]);
//                                            if (!$stockListProductUnit) {
//                                                $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => '商品の在庫情報']);
//                                                $this->addErrors($message);
//                                                continue;
//                                            }
//                                        }
                                        // DEL-END CNC 2022/12/28

                                        $productDetail = [
                                            'product_shop_key' => $arrKey,
                                            'quantity' => $arrCount
                                        ];
                                        $productItems[$arrKey] = $productDetail;

                                    } else {

                                        $productItems[$arrKey]['quantity'] = 0 + (
                                            isset($productItems[$arrKey]['quantity'])
                                                ? $productItems[$arrKey]['quantity']
                                                : 0
                                            ) + (
                                            (isset($arrCount) && StringUtil::isNotBlank($arrCount))
                                                ? $arrCount
                                                : 0
                                            );
                                    }
                                }

                            } else {

                                if(!isset($productItems[$key])){

                                    // DEL-START CNC 2022/12/28 サーバロジックを修正
                                    // DB check
//                                    $netshopaiProductInfo = $this->netshopaiProductInfoRepository->findOneBy(['yahoo2ShopKey' => $row[$headerByKey['product_shop_key']]]);
//                                    if (!$netshopaiProductInfo) {
//                                        continue;
//                                    } else {
//                                        $stockListProductUnit = $this->stockListProductUnitRepository
//                                            ->findOneBy([
//                                                'productCode' => $netshopaiProductInfo->getProductCode(),
//                                                'State' => $netshopaiProductInfo->getState()
//                                            ]);
//                                        if (!$stockListProductUnit) {
//                                            $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => '商品の在庫情報']);
//                                            $this->addErrors($message);
//                                            continue;
//                                        }
//                                    }
                                    // DEL-END CNC 2022/12/28

                                    $productDetail = [
                                        'product_shop_key' => $row[$headerByKey['product_shop_key']],
                                        'quantity' => $row[$headerByKey['quantity']]
                                    ];
                                    $productItems[$key] = $productDetail;

                                } else {

                                    $productItems[$key]['quantity'] = 0 + (
                                        isset($productItems[$key]['quantity'])
                                            ? $productItems[$key]['quantity']
                                            : 0
                                        ) + (
                                        (isset($row[$headerByKey['quantity']]) && StringUtil::isNotBlank($row[$headerByKey['quantity']]))
                                            ? $row[$headerByKey['quantity']]
                                            : 0
                                        );
                                }
                            }

                            $successCount = $successCount + 1;
                        } else {
                            continue;
                        }
                    }

                    if ($this->hasErrors()) {
//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders);
                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList);
                    }

//                    if ($successCount == 0) {
//                        log_info('ネットショップCSV登録完了');
//                        $message = 'admin.common.csv_upload_complete';
//                        $this->session->getFlashBag()->add('eccube.admin.success', $message);
//
//                        $cacheUtil->clearDoctrineCache();
//
//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders);
//                    }

                    $netshop = $this->netshopInfoRepository->findOneBy(['id' => '0']);
                    $netshop->setYahoo2OrderSearchSuccessDatetime($time);
                    $netshop->setUpdateUserName($this->getUser()['name']);
                    $this->entityManager->persist($netshop);

                    // DEL-START CNC 2022/12/28 サーバロジックを修正
//                    $productInfos = [];
                    // DEL-END CNC 2022/12/28

                    $qb = $this->netshopaiProductInfoRepository->getQueryBuilderBySearchDataForCsvUpload('5');
                    $productInfoDbs = $qb->getQuery()->getResult();
                    // DEL-START CNC 2022/12/28 サーバロジックを修正
//                    foreach ($productInfoDbs as $productInfoDb) {
//                        $productInfos[$productInfoDb["productCode"].'_'.$productInfoDb["state"]["id"]]['productCode'] = $productInfoDb["productCode"];
//                        $productInfos[$productInfoDb["productCode"].'_'.$productInfoDb["state"]["id"]]['state'] = $productInfoDb["state"]["id"];
//                        $productInfos[$productInfoDb["productCode"].'_'.$productInfoDb["state"]["id"]]['quantity'] = 0;
//                    }
//
//                    foreach ($productItems as $productItem) {
//                        $netshopaiProductInfo = $this->netshopaiProductInfoRepository->findOneBy(['yahoo2ShopKey' => $productItem['product_shop_key']]);
//                        $netshopaiProductInfo->setYahoo2OrderCsvInitQuantity($productItem['quantity']);
//                        $netshopaiProductInfo->setUpdateUserName($this->getUser()['name']);
//                        $this->entityManager->persist($netshopaiProductInfo);
//
//                        $quantity = 0 + $netshopaiProductInfo->getRakutenOrderCsvInitQuantity()
//                            + $netshopaiProductInfo->getYahooOrderCsvInitQuantity()
//                            + $productItem['quantity']
//                            + $netshopaiProductInfo->getAmazonOrderCsvInitQuantity()
//                            + $netshopaiProductInfo->getKakakuOrderCsvInitQuantity();
//                        $productCode = $netshopaiProductInfo->getProductCode();
//                        $state = $netshopaiProductInfo->getState()->getId();
//
//                        $productInfos[$productCode.'_'.$state]['productCode'] = $productCode;
//                        $productInfos[$productCode.'_'.$state]['state'] = $state;
//                        $productInfos[$productCode.'_'.$state]['quantity'] = $quantity;
//
//                    }
                    // DEL-END CNC 2022/12/28
                    $i = 0;
                    $saleErrDetails = [];
//                    $this->stockListProductUnitRepository->updateOrderQuantity();
//                    foreach ($productInfos as $productInfo) {
                    /** @var NetshopaiProductInfo $productInfo */
                    foreach ($productInfoDbs as $productInfo) {
                        // INS-START CNC 2022/12/28 サーバロジックを修正
                        $yahoo2OrderQuantity = 0;

                        // CSVから受注数量取得
                        if (isset($productItems[$productInfo->getYahoo2ShopKey()])) {
                            $yahoo2OrderQuantity = $productItems[$productInfo->getYahoo2ShopKey()]['quantity'];
                        }

                        $orderQuantity = 0 + $productInfo->getRakutenOrderCsvInitQuantity()
                            + $productInfo->getYahooOrderCsvInitQuantity()
                            + $yahoo2OrderQuantity
                            + $productInfo->getAmazonOrderCsvInitQuantity()
                            + $productInfo->getKakakuOrderCsvInitQuantity();

                        $productInfo->setYahoo2OrderCsvInitQuantity($yahoo2OrderQuantity);
                        $productInfo->setUpdateUserName($this->getUser()['name']);
                        $this->entityManager->persist($productInfo);

                        $stockListProduct = $this->stockListProductUnitRepository->findOneBy(['productCode' => $productInfo->getProductCode(), 'State' => $productInfo->getState()->getId()]);
                        if ($stockListProduct) {
                            // 受注数量
                            $stockListProduct->setOrderQuantity($orderQuantity);
                            // 残在庫数量　= 在庫数量-受注数量-仮出荷数量
                            $remainingStockQuantity = 0 + $stockListProduct->getStockQuantity() - $orderQuantity - $stockListProduct->getProvisionalShipmentQuantity();
                            $stockListProduct->setRemainingStockQuantity($remainingStockQuantity);
                            $stockListProduct->setUpdateUserName($this->getUser()['name']);
                            $this->entityManager->persist($stockListProduct);

                            if (isset($productItems[$productInfo->getYahoo2ShopKey()])) {
                                $product = $this->productRepository->findOneBy(['id' => $stockListProduct->getProductId()]);
                                if ($stockListProduct->getStockQuantity() - $orderQuantity < 0){
                                    $saleErrDetails[$i] = [
                                        'productCode' => $productInfo->getProductCode(),
                                        'productName' => $product->getName(),
                                        'stateName' => $stockListProduct->getState()->getState(),
                                        'orderQuantity' => $orderQuantity,
                                        'stockQuantity' => $stockListProduct->getStockQuantity(),
                                    ];
                                    $i++;
                                }
                            }
                        }
                        // INS-END CNC 2022/12/28

                        // DEL-START CNC 2022/12/28 サーバロジックを修正
//                        $before_quantity = $productInfo['quantity'];
//
//                        if ($productInfo['quantity'] === 0) {
//                            $netshopaiProductInfo = $this->netshopaiProductInfoRepository->findOneBy(['productCode' => $productInfo['productCode'], 'state' => $productInfo['state']]);
//                            $netshopaiProductInfo->setYahoo2OrderCsvInitQuantity(0);
//                            $netshopaiProductInfo->setUpdateUserName($this->getUser()['name']);
//                            $this->entityManager->persist($netshopaiProductInfo);
//
//                            $productInfo['quantity'] = 0+ $netshopaiProductInfo->getRakutenOrderCsvInitQuantity()
//                                + $netshopaiProductInfo->getYahooOrderCsvInitQuantity()
//                                + 0
//                                + $netshopaiProductInfo->getAmazonOrderCsvInitQuantity()
//                                + $netshopaiProductInfo->getKakakuOrderCsvInitQuantity();
//                        }
//
//                        $stockListProduct = $this->stockListProductUnitRepository->findOneBy(['productCode' => $productInfo['productCode'], 'State' => $productInfo['state']]);
//                        if ($stockListProduct) {
//                            // 受注数量
//                            $stockListProduct->setOrderQuantity($productInfo['quantity']);
//                            // 残在庫数量　= 在庫数量-受注数量-仮出荷数量
//                            $remainingStockQuantity = 0 + $stockListProduct->getStockQuantity() - $productInfo['quantity'] - $stockListProduct->getProvisionalShipmentQuantity();
//                            $stockListProduct->setRemainingStockQuantity($remainingStockQuantity);
//                            $stockListProduct->setUpdateUserName($this->getUser()['name']);
//                            $this->entityManager->persist($stockListProduct);
//
//                            $product = $this->productRepository->findOneBy(['id' => $stockListProduct->getProductId()]);
//                            if($before_quantity > 0 && $stockListProduct->getStockQuantity() - $productInfo['quantity'] < 0){
//                                $saleErrDetails[$i] = [
//                                    'productCode' => $productInfo['productCode'],
//                                    'productName' => $product->getName(),
//                                    'stateName' => $stockListProduct->getState()->getState(),
//                                    'orderQuantity' => $productInfo['quantity'],
//                                    'stockQuantity' => $stockListProduct->getStockQuantity(),
//                                ];
//                                $i++;
//                            }
//                        }
                        // DEL-END CNC 2022/12/28
                    }

                    $this->netshopaiCSVHistoryRepository->insertNetshopaiCSVHistory('5','1','', '',$this->getUser()['name']);

                    $newCSVHistory = $this->netshopaiCSVHistoryRepository->findOneBy(['shop' => 5, 'upload_method' => 1], ['updateDate' => 'DESC']);
                    $newCSVHistory_id = $newCSVHistory->getId();
                    if($saleErrDetails != null){
                        foreach ($saleErrDetails as $saleErrDetail){
                            $this->netshopaiCSVErrDetailRepository->insertNetshopaiCSVErrInfo($newCSVHistory_id, $saleErrDetail['productCode'], $saleErrDetail['productName'],
                                $saleErrDetail['stateName'], $saleErrDetail['orderQuantity'], $saleErrDetail['stockQuantity'], $this->getUser()['name']);
                        }
                    }

                    $this->entityManager->flush();
                    $this->entityManager->getConnection()->commit();

                    log_info('ネットショップCSV登録完了');
                    $message = 'admin.common.csv_upload_complete';
                    $this->session->getFlashBag()->add('eccube.admin.success', $message);

                    $cacheUtil->clearDoctrineCache();
                }
            }
        }
        // 操作履歴
        $netshopaiCSVHistories = $this->getSearchData();
        foreach ($netshopaiCSVHistories as $key => $netshopaiCSVHistory){
            $netshopaiCSVHistories[$key]['update_date'] = $this->makeDateStringUtcToAsiaTokyo($netshopaiCSVHistory['update_date']);

            if ($netshopaiCSVHistory['shop'] == 1 && $netshopaiCSVHistory['upload_method'] == 2) {
                $rakutenErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 2 && $netshopaiCSVHistory['upload_method'] == 2) {
                $yahooErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 5 && $netshopaiCSVHistory['upload_method'] == 2) {
                $yahoo2ErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if ($netshopaiCSVHistory['shop'] == 3 && $netshopaiCSVHistory['upload_method'] == 2) {
                $amazonErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 4 && $netshopaiCSVHistory['upload_method'] == 2) {
                $kakakuErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 1 && $netshopaiCSVHistory['upload_method'] == 1) {
                $rakutenCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 2 && $netshopaiCSVHistory['upload_method'] == 1) {
                $yahooCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 5 && $netshopaiCSVHistory['upload_method'] == 1) {
                $yahoo2CsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 3 && $netshopaiCSVHistory['upload_method'] == 1) {
                $amazonCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 4 && $netshopaiCSVHistory['upload_method'] == 1) {
                $kakakuCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
        }
//        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders);
        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList);
    }

    /**
     * Amazon
     */
    protected function amazonCsvProduct(Request $request, CacheUtil $cacheUtil, $form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories, $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList) {

        if ('POST' === $request->getMethod()) {
            $form->handleRequest($request);
            if ($form->isValid()) {
                $formFile = $form['import_file']->getData();
                if (!empty($formFile)) {
                    log_info('ネットショップCSV登録開始');
                    $data = $this->getImportData($formFile);
                    if ($data === false) {
                        $this->addErrors(trans('admin.common.csv_invalid_format'));
//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders, false);
                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList, false);
                    }
                    $getId = function ($item) {
                        return $item['id'];
                    };

                    $requireHeader = array('0' => 'order-id', '1' => 'purchase-date', '2' => 'sku', '3' => 'quantity-purchased');
                    $columnHeaders = $data->getColumnHeaders();

                    if (count(array_diff($requireHeader, $columnHeaders)) > 0) {
                        $this->addErrors(trans('admin.common.csv_invalid_format'));

//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders, false);
                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList, false);
                    }

                    $size = count($data);

                    if ($size < 1) {
                        $this->addErrors(trans('admin.common.csv_invalid_no_data'));

//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders, false);
                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList, false);
                    }

                    $headerByKey = array_flip(array_map($getId, $amazonHeaders));

                    $this->entityManager->getConfiguration()->setSQLLogger(null);
                    $this->entityManager->getConnection()->beginTransaction();
                    $productItems = [];
                    $time = date('Y/m/d H:i:s', strtotime('2020/01/01 00:00:00'));
                    $successCount = 0;
                    // CSVファイルの登録処理
                    foreach ($data as $row) {
                        $line = $data->key() + 1;
                        if (count($columnHeaders) != count($row)) {
                            $message = trans('admin.common.csv_invalid_format_line', ['%line%' => $line]);
                            $this->addErrors($message);
                            continue;
                        }

                        if (!isset($row[$headerByKey['order_time']]) || StringUtil::isBlank($row[$headerByKey['order_time']])) {
                            $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => 'purchase-date']);
                            $this->addErrors($message);
                            continue;
                        } else if (!isset($row[$headerByKey['product_shop_key']]) || StringUtil::isBlank($row[$headerByKey['product_shop_key']])) {
                            $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => 'sku']);
                            $this->addErrors($message);
                            continue;
                        } else if (!isset($row[$headerByKey['quantity']]) || StringUtil::isBlank($row[$headerByKey['quantity']])) {
                            $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => 'quantity-purchased']);
                            $this->addErrors($message);
                            continue;
                        }

                        $timeCsv = date('Y/m/d H:i:s', strtotime($row[$headerByKey['order_time']]));
                        if ($time < $timeCsv) {
                            $time = $timeCsv;
                        }

                        $key = $row[$headerByKey['product_shop_key']];

                        if(!isset($productItems[$key])){

                            // DEL-START CNC 2022/12/28 サーバロジックを修正
//                            // DB check
//                            $netshopaiProductInfo = $this->netshopaiProductInfoRepository->findOneBy(['amazonShopKey' => $row[$headerByKey['product_shop_key']]]);
//                            if (!$netshopaiProductInfo) {
//                                continue;
//                            } else {
//                                $stockListProductUnit = $this->stockListProductUnitRepository
//                                    ->findOneBy([
//                                        'productCode' => $netshopaiProductInfo->getProductCode(),
//                                        'State' => $netshopaiProductInfo->getState()
//                                    ]);
//                                if (!$stockListProductUnit) {
//                                    $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => '商品の在庫情報']);
//                                    $this->addErrors($message);
//                                    continue;
//                                }
//                            }
                            // DEL-END CNC 2022/12/28

                            $productDetail = [
                                'product_shop_key' => $row[$headerByKey['product_shop_key']],
                                'quantity' => $row[$headerByKey['quantity']]
                            ];
                            $productItems[$key] = $productDetail;
                        }else{
                            $productItems[$key]['quantity'] = 0 + (
                                isset($productItems[$key]['quantity'])
                                    ? $productItems[$key]['quantity']
                                    : 0
                                ) + (
                                (isset($row[$headerByKey['quantity']]) && StringUtil::isNotBlank($row[$headerByKey['quantity']]))
                                    ? $row[$headerByKey['quantity']]
                                    : 0
                                );
                        }

                        $successCount = $successCount + 1;

                    }

                    if ($this->hasErrors()) {
//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders);
                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList);
                    }

//                    if ($successCount == 0) {
//                        log_info('ネットショップCSV登録完了');
//                        $message = 'admin.common.csv_upload_complete';
//                        $this->session->getFlashBag()->add('eccube.admin.success', $message);
//
//                        $cacheUtil->clearDoctrineCache();
//
//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders);
//                    }

                    $netshop = $this->netshopInfoRepository->findOneBy(['id' => '0']);
                    $netshop->setAmazonOrderSearchSuccessDatetime($time);
                    $netshop->setUpdateUserName($this->getUser()['name']);
                    $this->entityManager->persist($netshop);

                    // DEL-START CNC 2022/12/28 サーバロジックを修正
//                    $productInfos = [];
                    // DEL-END CNC 2022/12/28

                    $qb = $this->netshopaiProductInfoRepository->getQueryBuilderBySearchDataForCsvUpload('3');
                    $productInfoDbs = $qb->getQuery()->getResult();
                    // DEL-START CNC 2022/12/28 サーバロジックを修正
//                    foreach ($productInfoDbs as $productInfoDb) {
//                        $productInfos[$productInfoDb["productCode"].'_'.$productInfoDb["state"]["id"]]['productCode'] = $productInfoDb["productCode"];
//                        $productInfos[$productInfoDb["productCode"].'_'.$productInfoDb["state"]["id"]]['state'] = $productInfoDb["state"]["id"];
//                        $productInfos[$productInfoDb["productCode"].'_'.$productInfoDb["state"]["id"]]['quantity'] = 0;
//                    }
//
//                    foreach ($productItems as $productItem) {
//                        $netshopaiProductInfo = $this->netshopaiProductInfoRepository->findOneBy(['amazonShopKey' => $productItem['product_shop_key']]);
//                        $netshopaiProductInfo->setAmazonOrderCsvInitQuantity($productItem['quantity']);
//                        $netshopaiProductInfo->setUpdateUserName($this->getUser()['name']);
//                        $this->entityManager->persist($netshopaiProductInfo);
//
//                        $quantity = 0+ $netshopaiProductInfo->getRakutenOrderCsvInitQuantity()
//                            + $netshopaiProductInfo->getYahooOrderCsvInitQuantity()
//                            + $netshopaiProductInfo->getYahoo2OrderCsvInitQuantity()
//                            + $productItem['quantity']
//                            + $netshopaiProductInfo->getKakakuOrderCsvInitQuantity();
//                        $productCode = $netshopaiProductInfo->getProductCode();
//                        $state = $netshopaiProductInfo->getState()->getId();
//
//                        $productInfos[$productCode.'_'.$state]['productCode'] = $productCode;
//                        $productInfos[$productCode.'_'.$state]['state'] = $state;
//                        $productInfos[$productCode.'_'.$state]['quantity'] = $quantity;
//
//                    }
                    // DEL-END CNC 2022/12/28
                    $i = 0;
                    $saleErrDetails = [];
//                    $this->stockListProductUnitRepository->updateOrderQuantity();
//                    foreach ($productInfos as $productInfo) {
                    /** @var NetshopaiProductInfo $productInfo */
                    foreach ($productInfoDbs as $productInfo) {
                        // INS-START CNC 2022/12/28 サーバロジックを修正
                        $amazonOrderQuantity = 0;

                        // CSVから受注数量取得
                        if (isset($productItems[$productInfo->getAmazonShopKey()])) {
                            $amazonOrderQuantity = $productItems[$productInfo->getAmazonShopKey()]['quantity'];
                        }

                        $orderQuantity = 0 + $productInfo->getRakutenOrderCsvInitQuantity()
                            + $productInfo->getYahooOrderCsvInitQuantity()
                            + $productInfo->getYahoo2OrderCsvInitQuantity()
                            + $amazonOrderQuantity
                            + $productInfo->getKakakuOrderCsvInitQuantity();

                        $productInfo->setAmazonOrderCsvInitQuantity($amazonOrderQuantity);
                        $productInfo->setUpdateUserName($this->getUser()['name']);
                        $this->entityManager->persist($productInfo);

                        $stockListProduct = $this->stockListProductUnitRepository->findOneBy(['productCode' => $productInfo->getProductCode(), 'State' => $productInfo->getState()->getId()]);
                        if ($stockListProduct) {
                            // 受注数量
                            $stockListProduct->setOrderQuantity($orderQuantity);
                            // 残在庫数量　= 在庫数量-受注数量-仮出荷数量
                            $remainingStockQuantity = 0 + $stockListProduct->getStockQuantity() - $orderQuantity - $stockListProduct->getProvisionalShipmentQuantity();
                            $stockListProduct->setRemainingStockQuantity($remainingStockQuantity);
                            $stockListProduct->setUpdateUserName($this->getUser()['name']);
                            $this->entityManager->persist($stockListProduct);

                            if (isset($productItems[$productInfo->getAmazonShopKey()])) {
                                $product = $this->productRepository->findOneBy(['id' => $stockListProduct->getProductId()]);
                                if ($stockListProduct->getStockQuantity() - $orderQuantity < 0){
                                    $saleErrDetails[$i] = [
                                        'productCode' => $productInfo->getProductCode(),
                                        'productName' => $product->getName(),
                                        'stateName' => $stockListProduct->getState()->getState(),
                                        'orderQuantity' => $orderQuantity,
                                        'stockQuantity' => $stockListProduct->getStockQuantity(),
                                    ];
                                    $i++;
                                }
                            }
                        }
                        // INS-END CNC 2022/12/28

                        // DEL-START CNC 2022/12/28 サーバロジックを修正
//                        $before_quantity = $productInfo['quantity'];
//
//                        if ($productInfo['quantity'] === 0) {
//                            $netshopaiProductInfo = $this->netshopaiProductInfoRepository->findOneBy(['productCode' => $productInfo['productCode'], 'state' => $productInfo['state']]);
//                            $netshopaiProductInfo->setAmazonOrderCsvInitQuantity(0);
//                            $netshopaiProductInfo->setUpdateUserName($this->getUser()['name']);
//                            $this->entityManager->persist($netshopaiProductInfo);
//
//                            $productInfo['quantity'] = 0+ $netshopaiProductInfo->getRakutenOrderCsvInitQuantity()
//                                + $netshopaiProductInfo->getYahooOrderCsvInitQuantity()
//                                + $netshopaiProductInfo->getYahoo2OrderCsvInitQuantity()
//                                + 0
//                                + $netshopaiProductInfo->getKakakuOrderCsvInitQuantity();
//                        }
//
//                        $stockListProduct = $this->stockListProductUnitRepository->findOneBy(['productCode' => $productInfo['productCode'], 'State' => $productInfo['state']]);
//                        if ($stockListProduct) {
//                            // 受注数量
//                            $stockListProduct->setOrderQuantity($productInfo['quantity']);
//                            // 残在庫数量　= 在庫数量-受注数量-仮出荷数量
//                            $remainingStockQuantity = 0 + $stockListProduct->getStockQuantity() - $productInfo['quantity'] - $stockListProduct->getProvisionalShipmentQuantity();
//                            $stockListProduct->setRemainingStockQuantity($remainingStockQuantity);
//                            $stockListProduct->setUpdateUserName($this->getUser()['name']);
//                            $this->entityManager->persist($stockListProduct);
//
//                            $product = $this->productRepository->findOneBy(['id' => $stockListProduct->getProductId()]);
//                            if($before_quantity > 0 && $stockListProduct->getStockQuantity() - $productInfo['quantity'] < 0){
//                                $saleErrDetails[$i] = [
//                                    'productCode' => $productInfo['productCode'],
//                                    'productName' => $product->getName(),
//                                    'stateName' => $stockListProduct->getState()->getState(),
//                                    'orderQuantity' => $productInfo['quantity'],
//                                    'stockQuantity' => $stockListProduct->getStockQuantity(),
//                                ];
//                                $i++;
//                            }
//                        }
                        // DEL-END CNC 2022/12/28
                    }

                    $this->netshopaiCSVHistoryRepository->insertNetshopaiCSVHistory('3','1','', '',$this->getUser()['name']);

                    $newCSVHistory = $this->netshopaiCSVHistoryRepository->findOneBy(['shop' => 3, 'upload_method' => 1], ['updateDate' => 'DESC']);
                    $newCSVHistory_id = $newCSVHistory->getId();
                    if($saleErrDetails != null){
                        foreach ($saleErrDetails as $saleErrDetail){
                            $this->netshopaiCSVErrDetailRepository->insertNetshopaiCSVErrInfo($newCSVHistory_id, $saleErrDetail['productCode'], $saleErrDetail['productName'],
                                $saleErrDetail['stateName'], $saleErrDetail['orderQuantity'], $saleErrDetail['stockQuantity'], $this->getUser()['name']);
                        }
                    }

                    $this->entityManager->flush();
                    $this->entityManager->getConnection()->commit();

                    log_info('ネットショップCSV登録完了');
                    $message = 'admin.common.csv_upload_complete';
                    $this->session->getFlashBag()->add('eccube.admin.success', $message);

                    $cacheUtil->clearDoctrineCache();
                }
            }
        }
        // 操作履歴
        $netshopaiCSVHistories = $this->getSearchData();
        foreach ($netshopaiCSVHistories as $key => $netshopaiCSVHistory){
            $netshopaiCSVHistories[$key]['update_date'] = $this->makeDateStringUtcToAsiaTokyo($netshopaiCSVHistory['update_date']);

            if ($netshopaiCSVHistory['shop'] == 1 && $netshopaiCSVHistory['upload_method'] == 2) {
                $rakutenErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 2 && $netshopaiCSVHistory['upload_method'] == 2) {
                $yahooErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 5 && $netshopaiCSVHistory['upload_method'] == 2) {
                $yahoo2ErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if ($netshopaiCSVHistory['shop'] == 3 && $netshopaiCSVHistory['upload_method'] == 2) {
                $amazonErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 4 && $netshopaiCSVHistory['upload_method'] == 2) {
                $kakakuErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 1 && $netshopaiCSVHistory['upload_method'] == 1) {
                $rakutenCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 2 && $netshopaiCSVHistory['upload_method'] == 1) {
                $yahooCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 5 && $netshopaiCSVHistory['upload_method'] == 1) {
                $yahoo2CsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 3 && $netshopaiCSVHistory['upload_method'] == 1) {
                $amazonCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 4 && $netshopaiCSVHistory['upload_method'] == 1) {
                $kakakuCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
        }
//        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders);
        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList);
    }

    /**
     * 自社ショップ
     */
    protected function kakakuCsvProduct(Request $request, CacheUtil $cacheUtil, $form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories, $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList) {

        if ('POST' === $request->getMethod()) {
            $form->handleRequest($request);
            if ($form->isValid()) {
                $formFile = $form['import_file']->getData();
                if (!empty($formFile)) {
                    log_info('ネットショップCSV登録開始');
                    $data = $this->getImportData($formFile);
                    if ($data === false) {
                        $this->addErrors(trans('admin.common.csv_invalid_format'));
//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders, false);
                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList, false);
                    }
                    $getId = function ($item) {
                        return $item['id'];
                    };

                    $requireHeader = array('0' => '日付', '1' => '注文時間', '2' => '処理状況', '3' => '個数', '4' => '注文番号', '5' => 'JANコード', '6' => '商品コード');
                    $columnHeaders = $data->getColumnHeaders();

                    if (count(array_diff($requireHeader, $columnHeaders)) > 0) {
                        $this->addErrors(trans('admin.common.csv_invalid_format'));

//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders, false);
                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList, false);
                    }

                    $size = count($data);

                    if ($size < 1) {
                        $this->addErrors(trans('admin.common.csv_invalid_no_data'));

//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders, false);
                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList, false);
                    }

                    $headerByKey = array_flip(array_map($getId, $kakakuHeaders));

                    $this->entityManager->getConfiguration()->setSQLLogger(null);
                    $this->entityManager->getConnection()->beginTransaction();
                    $productItems = [];
                    $time = date('Y/m/d H:i:s', strtotime('2020/01/01 00:00:00'));
                    $successCount = 0;
                    // CSVファイルの登録処理
                    foreach ($data as $row) {
                        $line = $data->key() + 1;
                        if (count($columnHeaders) != count($row)) {
                            $message = trans('admin.common.csv_invalid_format_line', ['%line%' => $line]);
                            $this->addErrors($message);
                            continue;
                        }

                        if (!isset($row[$headerByKey['order_date']]) || StringUtil::isBlank($row[$headerByKey['order_date']])) {
                            $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => '日付']);
                            $this->addErrors($message);
                            continue;
                        } else if (!isset($row[$headerByKey['order_time']]) || StringUtil::isBlank($row[$headerByKey['order_time']])) {
                            $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => '注文時間']);
                            $this->addErrors($message);
                            continue;
                        } else if (!isset($row[$headerByKey['status']]) || StringUtil::isBlank($row[$headerByKey['status']])) {
                            $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => '処理状況']);
                            $this->addErrors($message);
                            continue;
                        } else if (!isset($row[$headerByKey['quantity']]) || StringUtil::isBlank($row[$headerByKey['quantity']])) {
                            $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => '個数']);
                            $this->addErrors($message);
                            continue;
                        } else if (!isset($row[$headerByKey['product_shop_key']]) || StringUtil::isBlank($row[$headerByKey['product_shop_key']])) {
                            $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => '商品コード']);
                            $this->addErrors($message);
                            continue;
                        }

                        $timeCsv = date('Y/m/d H:i:s', strtotime($row[$headerByKey['order_date']].' '.$row[$headerByKey['order_time']]));
                        if ($time < $timeCsv) {
                            $time = $timeCsv;
                        }

                        if ($row[$headerByKey['status']] == '未処理' || $row[$headerByKey['status']] == '配送指示済み' || $row[$headerByKey['status']] == '配送準備中' || $row[$headerByKey['status']] == '未配送') {
                            $key = $row[$headerByKey['product_shop_key']];

                            if(!isset($productItems[$key])){

                                // DEL-START CNC 2022/12/28 サーバロジックを修正
//                                // DB check
//                                $netshopaiProductInfo = $this->netshopaiProductInfoRepository->findOneBy(['kakakuShopKey' => $row[$headerByKey['product_shop_key']]]);
//                                if (!$netshopaiProductInfo) {
//                                    continue;
//                                } else {
//                                    $stockListProductUnit = $this->stockListProductUnitRepository
//                                        ->findOneBy([
//                                            'productCode' => $netshopaiProductInfo->getProductCode(),
//                                            'State' => $netshopaiProductInfo->getState()
//                                        ]);
//                                    if (!$stockListProductUnit) {
//                                        $message = trans('admin.common.csv_invalid_not_found', ['%line%' => $line, '%name%' => '商品の在庫情報']);
//                                        $this->addErrors($message);
//                                        continue;
//                                    }
//                                }
                                // DEL-END CNC 2022/12/28

                                $productDetail = [
                                    'product_shop_key' => $row[$headerByKey['product_shop_key']],
                                    'quantity' => $row[$headerByKey['quantity']]
                                ];
                                $productItems[$key] = $productDetail;
                            }else{
                                $productItems[$key]['quantity'] = 0 + (
                                    isset($productItems[$key]['quantity'])
                                        ? $productItems[$key]['quantity']
                                        : 0
                                    ) + (
                                    (isset($row[$headerByKey['quantity']]) && StringUtil::isNotBlank($row[$headerByKey['quantity']]))
                                        ? $row[$headerByKey['quantity']]
                                        : 0
                                    );
                            }

                            $successCount = $successCount + 1;
                        } else {
                            continue;
                        }
                    }

                    if ($this->hasErrors()) {
//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders);
                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList);
                    }

//                    if ($successCount == 0) {
//                        log_info('ネットショップCSV登録完了');
//                        $message = 'admin.common.csv_upload_complete';
//                        $this->session->getFlashBag()->add('eccube.admin.success', $message);
//
//                        $cacheUtil->clearDoctrineCache();
//
//                        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders);
//                    }

                    $netshop = $this->netshopInfoRepository->findOneBy(['id' => '0']);
                    $netshop->setKakakuOrderSearchSuccessDatetime($time);
                    $netshop->setUpdateUserName($this->getUser()['name']);
                    $this->entityManager->persist($netshop);

                    // DEL-START CNC 2022/12/28 サーバロジックを修正
//                    $productInfos = [];
                    // DEL-END CNC 2022/12/28

                    $qb = $this->netshopaiProductInfoRepository->getQueryBuilderBySearchDataForCsvUpload('4');
                    $productInfoDbs = $qb->getQuery()->getResult();
                    // DEL-START CNC 2022/12/28 サーバロジックを修正
//                    foreach ($productInfoDbs as $productInfoDb) {
//                        $productInfos[$productInfoDb["productCode"].'_'.$productInfoDb["state"]["id"]]['productCode'] = $productInfoDb["productCode"];
//                        $productInfos[$productInfoDb["productCode"].'_'.$productInfoDb["state"]["id"]]['state'] = $productInfoDb["state"]["id"];
//                        $productInfos[$productInfoDb["productCode"].'_'.$productInfoDb["state"]["id"]]['quantity'] = 0;
//                    }
//
//                    foreach ($productItems as $productItem) {
//                        $netshopaiProductInfo = $this->netshopaiProductInfoRepository->findOneBy(['kakakuShopKey' => $productItem['product_shop_key']]);
//                        $netshopaiProductInfo->setKakakuOrderCsvInitQuantity($productItem['quantity']);
//                        $netshopaiProductInfo->setUpdateUserName($this->getUser()['name']);
//                        $this->entityManager->persist($netshopaiProductInfo);
//
//                        $quantity = 0 + $netshopaiProductInfo->getRakutenOrderCsvInitQuantity()
//                            + $netshopaiProductInfo->getYahooOrderCsvInitQuantity()
//                            + $netshopaiProductInfo->getYahoo2OrderCsvInitQuantity()
//                            + $netshopaiProductInfo->getAmazonOrderCsvInitQuantity()
//                            + $productItem['quantity'] ;
//                        $productCode = $netshopaiProductInfo->getProductCode();
//                        $state = $netshopaiProductInfo->getState()->getId();
//
//                        $productInfos[$productCode.'_'.$state]['productCode'] = $productCode;
//                        $productInfos[$productCode.'_'.$state]['state'] = $state;
//                        $productInfos[$productCode.'_'.$state]['quantity'] = $quantity;
//
//                    }
                    // DEL-END CNC 2022/12/28
                    $i = 0;
                    $saleErrDetails = [];
//                    $this->stockListProductUnitRepository->updateOrderQuantity();
//                    foreach ($productInfos as $productInfo) {
                    /** @var NetshopaiProductInfo $productInfo */
                    foreach ($productInfoDbs as $productInfo) {
                        // INS-START CNC 2022/12/28 サーバロジックを修正
                        $kakakuOrderQuantity = 0;

                        // CSVから受注数量取得
                        if (isset($productItems[$productInfo->getKakakuShopKey()])) {
                            $kakakuOrderQuantity = $productItems[$productInfo->getKakakuShopKey()]['quantity'];
                        }

                        $orderQuantity = 0 + $productInfo->getRakutenOrderCsvInitQuantity()
                            + $productInfo->getYahooOrderCsvInitQuantity()
                            + $productInfo->getYahoo2OrderCsvInitQuantity()
                            + $productInfo->getAmazonOrderCsvInitQuantity()
                            + $kakakuOrderQuantity;

                        $productInfo->setKakakuOrderCsvInitQuantity($kakakuOrderQuantity);
                        $productInfo->setUpdateUserName($this->getUser()['name']);
                        $this->entityManager->persist($productInfo);

                        $stockListProduct = $this->stockListProductUnitRepository->findOneBy(['productCode' => $productInfo->getProductCode(), 'State' => $productInfo->getState()->getId()]);
                        if ($stockListProduct) {
                            // 受注数量
                            $stockListProduct->setOrderQuantity($orderQuantity);
                            // 残在庫数量　= 在庫数量-受注数量-仮出荷数量
                            $remainingStockQuantity = 0 + $stockListProduct->getStockQuantity() - $orderQuantity - $stockListProduct->getProvisionalShipmentQuantity();
                            $stockListProduct->setRemainingStockQuantity($remainingStockQuantity);
                            $stockListProduct->setUpdateUserName($this->getUser()['name']);
                            $this->entityManager->persist($stockListProduct);

                            if (isset($productItems[$productInfo->getKakakuShopKey()])) {
                                $product = $this->productRepository->findOneBy(['id' => $stockListProduct->getProductId()]);
                                if ($stockListProduct->getStockQuantity() - $orderQuantity < 0){
                                    $saleErrDetails[$i] = [
                                        'productCode' => $productInfo->getProductCode(),
                                        'productName' => $product->getName(),
                                        'stateName' => $stockListProduct->getState()->getState(),
                                        'orderQuantity' => $orderQuantity,
                                        'stockQuantity' => $stockListProduct->getStockQuantity(),
                                    ];
                                    $i++;
                                }
                            }
                        }
                        // INS-END CNC 2022/12/28

                        // DEL-START CNC 2022/12/28 サーバロジックを修正
//                        $before_quantity = $productInfo['quantity'];
//
//                        if ($productInfo['quantity'] === 0) {
//                            $netshopaiProductInfo = $this->netshopaiProductInfoRepository->findOneBy(['productCode' => $productInfo['productCode'], 'state' => $productInfo['state']]);
//                            $netshopaiProductInfo->setKakakuOrderCsvInitQuantity(0);
//                            $netshopaiProductInfo->setUpdateUserName($this->getUser()['name']);
//                            $this->entityManager->persist($netshopaiProductInfo);
//
//                            $productInfo['quantity'] = 0+ $netshopaiProductInfo->getRakutenOrderCsvInitQuantity()
//                                + $netshopaiProductInfo->getYahooOrderCsvInitQuantity()
//                                + $netshopaiProductInfo->getYahoo2OrderCsvInitQuantity()
//                                + $netshopaiProductInfo->getAmazonOrderCsvInitQuantity()
//                                + 0;
//                        }
//
//                        $stockListProduct = $this->stockListProductUnitRepository->findOneBy(['productCode' => $productInfo['productCode'], 'State' => $productInfo['state']]);
//                        if ($stockListProduct) {
//                            // 受注数量
//                            $stockListProduct->setOrderQuantity($productInfo['quantity']);
//                            // 残在庫数量　= 在庫数量-受注数量-仮出荷数量
//                            $remainingStockQuantity = 0 + $stockListProduct->getStockQuantity() - $productInfo['quantity'] - $stockListProduct->getProvisionalShipmentQuantity();
//                            $stockListProduct->setRemainingStockQuantity($remainingStockQuantity);
//                            $stockListProduct->setUpdateUserName($this->getUser()['name']);
//                            $this->entityManager->persist($stockListProduct);
//
//                            $product = $this->productRepository->findOneBy(['id' => $stockListProduct->getProductId()]);
//                            if($before_quantity > 0 && $stockListProduct->getStockQuantity() - $productInfo['quantity'] < 0){
//                                $saleErrDetails[$i] = [
//                                    'productCode' => $productInfo['productCode'],
//                                    'productName' => $product->getName(),
//                                    'stateName' => $stockListProduct->getState()->getState(),
//                                    'orderQuantity' => $productInfo['quantity'],
//                                    'stockQuantity' => $stockListProduct->getStockQuantity(),
//                                ];
//                                $i++;
//                            }
//                        }
                        // DEL-END CNC 2022/12/28
                    }

                    $this->netshopaiCSVHistoryRepository->insertNetshopaiCSVHistory('4','1','', '',$this->getUser()['name']);

                    $newCSVHistory = $this->netshopaiCSVHistoryRepository->findOneBy(['shop' => 4, 'upload_method' => 1], ['updateDate' => 'DESC']);
                    $newCSVHistory_id = $newCSVHistory->getId();
                    if($saleErrDetails != null){
                        foreach ($saleErrDetails as $saleErrDetail){
                            $this->netshopaiCSVErrDetailRepository->insertNetshopaiCSVErrInfo($newCSVHistory_id, $saleErrDetail['productCode'], $saleErrDetail['productName'],
                                $saleErrDetail['stateName'], $saleErrDetail['orderQuantity'], $saleErrDetail['stockQuantity'], $this->getUser()['name']);
                        }
                    }

                    $this->entityManager->flush();
                    $this->entityManager->getConnection()->commit();

                    log_info('ネットショップCSV登録完了');
                    $message = 'admin.common.csv_upload_complete';
                    $this->session->getFlashBag()->add('eccube.admin.success', $message);

                    $cacheUtil->clearDoctrineCache();
                }
            }
        }
        // 操作履歴
        $netshopaiCSVHistories = $this->getSearchData();
        foreach ($netshopaiCSVHistories as $key => $netshopaiCSVHistory){
            $netshopaiCSVHistories[$key]['update_date'] = $this->makeDateStringUtcToAsiaTokyo($netshopaiCSVHistory['update_date']);

            if ($netshopaiCSVHistory['shop'] == 1 && $netshopaiCSVHistory['upload_method'] == 2) {
                $rakutenErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 2 && $netshopaiCSVHistory['upload_method'] == 2) {
                $yahooErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 5 && $netshopaiCSVHistory['upload_method'] == 2) {
                $yahoo2ErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if ($netshopaiCSVHistory['shop'] == 3 && $netshopaiCSVHistory['upload_method'] == 2) {
                $amazonErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 4 && $netshopaiCSVHistory['upload_method'] == 2) {
                $kakakuErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 1 && $netshopaiCSVHistory['upload_method'] == 1) {
                $rakutenCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 2 && $netshopaiCSVHistory['upload_method'] == 1) {
                $yahooCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 5 && $netshopaiCSVHistory['upload_method'] == 1) {
                $yahoo2CsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 3 && $netshopaiCSVHistory['upload_method'] == 1) {
                $amazonCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 4 && $netshopaiCSVHistory['upload_method'] == 1) {
                $kakakuCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
        }
//        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders);
        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList);
    }

    /**
     * 登録、更新時のエラー画面表示
     *
     * @param FormInterface $form
     * @param array $yahooHeaders
     * @param array $yahoo2Headers
     * @param array $amazonHeaders
     * @param array $kakakuHeaders
     * @param bool $rollback
     * @param array $netshopaiCSVHistories
     *
     * @return array
     *
     * @throws \Doctrine\DBAL\ConnectionException
     */
    protected function renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories, $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList, $rollback = true)
    {
        if ($this->hasErrors()) {
            if ($rollback) {
                $this->entityManager->getConnection()->rollback();
            }
        }

        $this->removeUploadedFile();

        if ($form->get('upload_method')->getData() === '2') {
            return [
                'form' => $form->createView(),
                'rakutenHeaders' => $rakutenHeaders,
                'yahooHeaders' => $yahooHeaders,
                'yahoo2Headers' => $yahoo2Headers,
                'amazonHeaders' => $amazonHeaders,
                'kakakuHeaders' => $kakakuHeaders,
                'errors' => null,
                'errors_sales' => $this->errors,
                'shopId' => $form->createView()->offsetGet('shop_id_csv')->vars['value'],
                'upload_method' => $form->createView()->offsetGet('upload_method')->vars['value'],
                'netshopaiCSVHistories' => $netshopaiCSVHistories,
                'rakutenErrList' => $rakutenErrList,
                'yahooErrList' => $yahooErrList,
                'yahoo2ErrList' => $yahoo2ErrList,
                'amazonErrList' => $amazonErrList,
                'kakakuErrList' => $kakakuErrList,
                'rakutenCsvErrList' => $rakutenCsvErrList,
                'yahooCsvErrList' => $yahooCsvErrList,
                'yahoo2CsvErrList' => $yahoo2CsvErrList,
                'amazonCsvErrList' => $amazonCsvErrList,
                'kakakuCsvErrList' => $kakakuCsvErrList,
            ];
        }
        else {
            return [
                'form' => $form->createView(),
                'rakutenHeaders' => $rakutenHeaders,
                'yahooHeaders' => $yahooHeaders,
                'yahoo2Headers' => $yahoo2Headers,
                'amazonHeaders' => $amazonHeaders,
                'kakakuHeaders' => $kakakuHeaders,
                'errors' => $this->errors,
                'errors_sales' => null,
                'shopId' => $form->createView()->offsetGet('shop_id_csv')->vars['value'],
                'upload_method' => $form->createView()->offsetGet('upload_method')->vars['value'],
                'netshopaiCSVHistories' => $netshopaiCSVHistories,
                'rakutenErrList' => $rakutenErrList,
                'yahooErrList' => $yahooErrList,
                'yahoo2ErrList' => $yahoo2ErrList,
                'amazonErrList' => $amazonErrList,
                'kakakuErrList' => $kakakuErrList,
                'rakutenCsvErrList' => $rakutenCsvErrList,
                'yahooCsvErrList' => $yahooCsvErrList,
                'yahoo2CsvErrList' => $yahoo2CsvErrList,
                'amazonCsvErrList' => $amazonCsvErrList,
                'kakakuCsvErrList' => $kakakuCsvErrList,
            ];
        }

    }

    /**
     * 登録、更新時のエラー画面表示
     */
    protected function addErrors($message)
    {
        $this->errors[] = $message;
    }

    /**
     * @return array
     */
    protected function getErrors()
    {
        return $this->errors;
    }

    /**
     * @return boolean
     */
    protected function hasErrors()
    {
        return count($this->getErrors()) > 0;
    }

    /**
     * 楽天注文CSVヘッダー定義
     *
     * @return array
     */
    protected function getRakutenCsvHeader()
    {
        return [
            trans('admin.netshopAI.csv.rakuten.order_id') => [
                'id' => 'order_id',
                'description' => 'admin.netshopAI.csv.rakuten.description',
                'required' => false,
            ],
            trans('admin.netshopAI.csv.rakuten.status') => [
                'id' => 'status',
                'description' => 'admin.netshopAI.csv.rakuten.description',
                'required' => false,
            ],
            trans('admin.netshopAI.csv.rakuten.order_time') => [
                'id' => 'order_time',
                'description' => 'admin.netshopAI.csv.rakuten.description',
                'required' => false,
            ],
            trans('admin.netshopAI.csv.rakuten.product_shop_key') => [
                'id' => 'product_shop_key',
                'description' => 'admin.netshopAI.csv.rakuten.description',
                'required' => false,
            ],
            trans('admin.netshopAI.csv.rakuten.quantity') => [
                'id' => 'quantity',
                'description' => 'admin.netshopAI.csv.rakuten.description',
                'required' => false,
            ],
        ];
    }

    /**
     * Yahoo注文CSVヘッダー定義
     *
     * @return array
     */
    protected function getYahooCsvHeader()
    {
        return [
            trans('admin.netshopAI.csv.yahoo.order_id') => [
                'id' => 'order_id',
                'description' => 'admin.netshopAI.csv.yahoo.description',
                'required' => false,
            ],
            trans('admin.netshopAI.csv.yahoo.order_time') => [
                'id' => 'order_time',
                'description' => 'admin.netshopAI.csv.yahoo.description',
                'required' => false,
            ],
            trans('admin.netshopAI.csv.yahoo.status') => [
                'id' => 'status',
                'description' => 'admin.netshopAI.csv.yahoo.description',
                'required' => false,
            ],
            trans('admin.netshopAI.csv.yahoo.product_shop_key') => [
                'id' => 'product_shop_key',
                'description' => 'admin.netshopAI.csv.yahoo.description',
                'required' => false,
            ],
            trans('admin.netshopAI.csv.yahoo.quantity') => [
                'id' => 'quantity',
                'description' => 'admin.netshopAI.csv.yahoo.description',
                'required' => false,
            ],
        ];
    }

    /**
     * Yahoo2注文CSVヘッダー定義
     *
     * @return array
     */
    protected function getYahoo2CsvHeader()
    {
        return [
            trans('admin.netshopAI.csv.yahoo.order_id') => [
                'id' => 'order_id',
                'description' => 'admin.netshopAI.csv.yahoo2.description',
                'required' => false,
            ],
            trans('admin.netshopAI.csv.yahoo.order_time') => [
                'id' => 'order_time',
                'description' => 'admin.netshopAI.csv.yahoo2.description',
                'required' => false,
            ],
            trans('admin.netshopAI.csv.yahoo.status') => [
                'id' => 'status',
                'description' => 'admin.netshopAI.csv.yahoo2.description',
                'required' => false,
            ],
            trans('admin.netshopAI.csv.yahoo.product_shop_key') => [
                'id' => 'product_shop_key',
                'description' => 'admin.netshopAI.csv.yahoo2.description',
                'required' => false,
            ],
            trans('admin.netshopAI.csv.yahoo.quantity') => [
                'id' => 'quantity',
                'description' => 'admin.netshopAI.csv.yahoo2.description',
                'required' => false,
            ],
        ];
    }

    /**
     * Amazon注文CSVヘッダー定義
     *
     * @return array
     */
    protected function getAmazonCsvHeader()
    {
        return [
            trans('admin.netshopAI.csv.amazon.order_id') => [
                'id' => 'order_id',
                'description' => 'admin.netshopAI.csv.amazon.description',
                'required' => false,
            ],
            trans('admin.netshopAI.csv.amazon.order_time') => [
                'id' => 'order_time',
                'description' => 'admin.netshopAI.csv.amazon.description',
                'required' => false,
            ],
            trans('admin.netshopAI.csv.amazon.product_shop_key') => [
                'id' => 'product_shop_key',
                'description' => 'admin.netshopAI.csv.amazon.description',
                'required' => false,
            ],
            trans('admin.netshopAI.csv.amazon.quantity') => [
                'id' => 'quantity',
                'description' => 'admin.netshopAI.csv.amazon.description',
                'required' => false,
            ],
        ];
    }

    /**
     * 自社ショップ注文CSVヘッダー定義
     *
     * @return array
     */
    protected function getKakakuCsvHeader()
    {
        return [
            trans('admin.netshopAI.csv.kakaku.order_date') => [
                'id' => 'order_date',
                'description' => 'admin.netshopAI.csv.kakaku.description',
                'required' => false,
            ],
            trans('admin.netshopAI.csv.kakaku.order_time') => [
                'id' => 'order_time',
                'description' => 'admin.netshopAI.csv.kakaku.description',
                'required' => false,
            ],
            trans('admin.netshopAI.csv.kakaku.status') => [
                'id' => 'status',
                'description' => 'admin.netshopAI.csv.kakaku.description',
                'required' => false,
            ],
            trans('admin.netshopAI.csv.kakaku.quantity') => [
                'id' => 'quantity',
                'description' => 'admin.netshopAI.csv.kakaku.description',
                'required' => false,
            ],
            trans('admin.netshopAI.csv.kakaku.order_id') => [
                'id' => 'order_id',
                'description' => 'admin.netshopAI.csv.kakaku.description',
                'required' => false,
            ],
            trans('admin.netshopAI.csv.kakaku.product_cd') => [
                'id' => 'product_cd',
                'description' => 'admin.netshopAI.csv.kakaku.description',
                'required' => false,
            ],
            trans('admin.netshopAI.csv.kakaku.product_shop_key') => [
                'id' => 'product_shop_key',
                'description' => 'admin.netshopAI.csv.kakaku.description',
                'required' => false,
            ],
        ];
    }

    /**
     * 対象ネットショップから収集された売上明細情報により、商品の最新情報を更新する。
     *
     * @return array
     */
    protected function updateOrderQuantityBySales(Request $request, CacheUtil $cacheUtil, $form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories, $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList) {

        if ('POST' === $request->getMethod()) {
            $form->handleRequest($request);

            $pdo = $this->entityManager->getConnection()->getWrappedConnection();

            $sqlRunstatus = 'SELECT batch_runstate FROM dtb_netshopAI_runstatus WHERE shop_id = \'5\' AND batch_cd = \'50\';';
            $stmt = $pdo->prepare($sqlRunstatus);
            $stmt->execute();
            $runstatusResult = $stmt->fetchAll();

            foreach ($runstatusResult as $runstatusInfo) {
                if ($runstatusInfo['batch_runstate'] === '1') {
                    $this->addErrors(trans('admin.netshopAI.csv.upload_sales_runstatus_error'));
//                    return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders, false);
                    return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
                        $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList, false);
                }
            }

//            $sth = $pdo->prepare('UPDATE dtb_netshopAI_runstatus set batch_runstate = :batch_runstate, update_date = current_timestamp WHERE shop_id = :shop_id AND batch_cd = :batch_cd;');
//            $sth->execute([
//                ':batch_runstate' => '2',
//                ':shop_id' => '5',
//                ':batch_cd' => '50',
//            ]);
//            $pdo->commit();
//
//            $pdo = $this->entityManager->getConnection()->getWrappedConnection();
            $shopCd = '0';
            $shopId = '';
            if ($form['shop_id_csv']->getData()->getId() == Netshop::RAKUTEN) {
                // 楽天ショッピング
                $shopCd = '002';
                $shopId = '1';
            }
            else if ($form['shop_id_csv']->getData()->getId() == Netshop::YAHOO) {
                // Yahooショッピング
                $shopCd = '004';
                $shopId = '2';
            }
            else if ($form['shop_id_csv']->getData()->getId() == Netshop::YAHOO2) {
                // Yahoo2ショッピング
                $shopCd = '004';
                $shopId = '5';
            }
            else if ($form['shop_id_csv']->getData()->getId() == Netshop::AMAZON) {
                // amazon
                $shopCd = '003';
                $shopId = '3';
            }
            else if ($form['shop_id_csv']->getData()->getId() == Netshop::KAKAKU) {
                // 価格com
                $shopCd = '001';
                $shopId = '4';
            }

            $sql = '
                SELECT
                    \'\' AS id,
                    \'\' AS sales_date,
                    \'\' AS customer_code,
                    \'\' AS customerId,
                    \'\' AS customerName,
                    \'\' AS sales_voucher_no,
                    dc4.category_id AS category_id1,
                    dc4.categoryName AS categoryName1,
                    dc5.category_id AS category_id2,
                    dc5.categoryName as categoryName2,
                    dc6.category_id AS category_id3,
                    dc6.categoryName as categoryName3,
                    dsvd.product_code,
                    dsvd.state_id,
                    dp.name AS productName,
                    ms.state AS stateName,
                    \'\' AS serial_no,
                    SUM(dsvd.quantity) AS quantity,
                    dsvd.sales_price_extax,
                    dsvd.sales_price,
                    SUM(dsvd.total_sales_amount) AS total_sales_amount,
                    \'\' AS personnelMemoId,
                    \'\' AS personnelName,
                    \'\' AS place,
                    \'\' AS update_user_name,
                    \'\' AS update_date,
                    round(AVG(dsvd.average_unit_price)) AS averageUnitPrice,
                    dsvh.export_Address_id AS exportAddressId,
                    dsvh.tax_rate_category_id AS taxRateCategoryId,
                    SUM(gp.grossProfit) AS grossProfit
                FROM
                    dtb_sales_voucher_detail dsvd
                INNER JOIN dtb_sales_voucher_header dsvh
                    ON dsvd.sales_voucher_header_id = dsvh.id
                INNER JOIN mtb_customer_mst mcm
                    ON mcm.id=dsvh.customer_id
                INNER JOIN dtb_product dp
                    ON dp.id=dsvd.product_id
                INNER JOIN mtb_state ms
                    ON ms.id=dsvd.state_id
                INNER JOIN mtb_place mp
                    ON mp.id=dsvd.storehouse_id
                INNER JOIN dtb_member dm
                    ON dm.id=dsvh.personnel_id
                LEFT JOIN (
                    SELECT
                        dsvd2.id,
                        CASE WHEN dsvh2.export_Address_id IS NULL
                            THEN (sales_price - average_unit_price) * quantity
                            ELSE round((sales_price - average_unit_price / (1 + mtc.tax_rate / 100)) * quantity)
                        END AS grossProfit
                    FROM
                        dtb_sales_voucher_detail dsvd2
                        INNER JOIN dtb_sales_voucher_header dsvh2
                            ON dsvd2.sales_voucher_header_id = dsvh2.id
                        LEFT JOIN mtb_tax_code mtc
                            ON mtc.id = dsvh2.tax_rate_category_id
                ) AS gp
                ON gp.id = dsvd.id
                LEFT JOIN dtb_stock_list_product_unit dslpu
                    ON dsvd.product_id=dslpu.product_id
                    AND dsvd.state_id = dslpu.state_id
                    AND dsvd.product_code = dslpu.product_code
                INNER JOIN (
                    SELECT
                        dsvds.id,
                        dpcs.category_id,
                        dcs.category_name AS categoryName,
                        dcs.hierarchy
                    FROM
                        dtb_sales_voucher_detail dsvds
                        INNER JOIN dtb_product dps
                            ON dsvds.product_id = dps.id
                        INNER JOIN dtb_product_category dpcs
                            ON dsvds.product_id = dpcs.product_id
                        INNER JOIN dtb_category dcs
                            ON dcs.id = dpcs.category_id
                         WHERE dpcs.category_sub_flag <>1
                ) AS dc4
                    ON dc4.id = dsvd.id
                    AND dc4.hierarchy = 1
                LEFT JOIN (
                    SELECT
                        dsvds.id,
                        dpcs.category_id,
                        dcs.category_name AS categoryName,
                        dcs.hierarchy
                    FROM
                        dtb_sales_voucher_detail dsvds
                        INNER JOIN dtb_product dps
                            ON dsvds.product_id = dps.id
                        INNER JOIN dtb_product_category dpcs
                            ON dsvds.product_id = dpcs.product_id
                        INNER JOIN dtb_category dcs
                            ON dcs.id = dpcs.category_id
                         WHERE dpcs.category_sub_flag <>1
                ) AS dc5
                    ON dc5.id = dsvd.id
                    AND dc5.hierarchy = 2
                LEFT JOIN (
                    SELECT
                        dsvds.id,
                        dpcs.category_id,
                        dcs.category_name AS categoryName,
                        dcs.hierarchy
                    FROM
                        dtb_sales_voucher_detail dsvds
                        INNER JOIN dtb_product dps
                            ON dsvds.product_id = dps.id
                        INNER JOIN dtb_product_category dpcs
                            ON dsvds.product_id = dpcs.product_id
                        INNER JOIN dtb_category dcs
                            ON dcs.id = dpcs.category_id
                         WHERE dpcs.category_sub_flag <>1
                ) AS dc6
                    ON dc6.id = dsvd.id
                    AND dc6.hierarchy = 3
                WHERE TRUE
            ';

            $sql = $sql.' AND  mcm.customer_code = '.$shopCd;

            $sales_date_start = $form['sales_date_start']->getData();
            $salesDateStart = $sales_date_start->setTime('0', '0', '0')
                ->setTimezone(new \DateTimeZone('UTC'))
                ->format('Y-m-d H:i:s');
            $sql = $sql.' AND  dsvh.sales_date >= \''.$salesDateStart .'\'';

            $sales_date_end = $form['sales_date_end']->getData();
            $salesDateEnd = $sales_date_end->setTime('23', '59', '59')
                ->setTimezone(new \DateTimeZone('UTC'))
                ->format('Y-m-d H:i:s');
            $sql = $sql . ' AND  dsvh.sales_date <= \'' .$salesDateEnd  . '\'';

            $sql = $sql.'
                GROUP BY
                dsvd.product_code
                ,dsvd.state_id
                ,dsvd.sales_price_extax
                ,dsvd.sales_price
                ORDER BY
                dsvd.update_date DESC
                ,dsvh.sales_date
                ,mcm.customer_name
                ,dsvd.sales_voucher_no
                ,dsvd.sales_details_no
                ';

            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $salesResult = $stmt->fetchAll();

            $i = 0;
            // 売上明細エラー
            $saleErrDetails = [];
            foreach ($salesResult as $saleInfo) {

                $product_code = $saleInfo['product_code'];
                $state_id = $saleInfo['state_id'];
                $quantity = $saleInfo['quantity'] + 0;

                if ($quantity > 0) {
                    $netshopaiProductInfo = $this->netshopaiProductInfoRepository->findOneBy(['productCode' => $product_code, 'state' => $state_id]);
                    $stockListProduct = $this->stockListProductUnitRepository->findOneBy(['productCode' => $product_code, 'State' => $state_id]);

                    if (!$netshopaiProductInfo || !$stockListProduct) {
                        continue;
                    }
                    else {

                        $shopOrderBefore = 0;
                        $shopOrderChange = 0;
                        $shopOrderAfter = 0;
                        $allOrderBefore = $stockListProduct->getOrderQuantity();
                        $allRemainBefore = $stockListProduct->getRemainingStockQuantity();

                        // ネットショップ連動商品マスタ
                        if ($form['shop_id_csv']->getData()->getId() == Netshop::RAKUTEN) {

                            $shopOrderBefore = $netshopaiProductInfo->getRakutenOrderCsvInitQuantity() + 0;
                            if ($shopOrderBefore - $quantity <= 0) {
                                $shopOrderChange = $shopOrderBefore;
                                $shopOrderAfter = 0;

                                if($shopOrderBefore - $quantity < 0){
                                    $saleErrDetails[$i] = [
                                        'productCode' => $product_code,
                                        'productName' => $saleInfo['productName'],
                                        'stateName' => $saleInfo['stateName'],
                                        'orderQuantity' => $shopOrderBefore,
                                        'salesQuantity' => $quantity,
                                    ];
                                }
                            }
                            else {
                                $shopOrderChange = $quantity;
                                $shopOrderAfter = $shopOrderBefore - $quantity;
                            }

                            $netshopaiProductInfo->setRakutenOrderCsvInitQuantity($shopOrderAfter);
                            $netshopaiProductInfo->setUpdateUserName($this->getUser()['name']);
                            $this->entityManager->persist($netshopaiProductInfo);

                        }
                        else if ($form['shop_id_csv']->getData()->getId() == Netshop::YAHOO) {

                            $shopOrderBefore = $netshopaiProductInfo->getYahooOrderCsvInitQuantity() + 0;
                            if ($shopOrderBefore - $quantity <= 0) {
                                $shopOrderChange = $shopOrderBefore;
                                $shopOrderAfter = 0;

                                if($shopOrderBefore - $quantity < 0){
                                    $saleErrDetails[$i] = [
                                        'productCode' => $product_code,
                                        'productName' => $saleInfo['productName'],
                                        'stateName' => $saleInfo['stateName'],
                                        'orderQuantity' => $shopOrderBefore,
                                        'salesQuantity' => $quantity,
                                    ];
                                }
                            }
                            else {
                                $shopOrderChange = $quantity;
                                $shopOrderAfter = $shopOrderBefore - $quantity;
                            }

                            $netshopaiProductInfo->setYahooOrderCsvInitQuantity($shopOrderAfter);
                            $netshopaiProductInfo->setUpdateUserName($this->getUser()['name']);
                            $this->entityManager->persist($netshopaiProductInfo);

                        }
                        else if ($form['shop_id_csv']->getData()->getId() == Netshop::YAHOO2) {

                            $shopOrderBefore = $netshopaiProductInfo->getYahoo2OrderCsvInitQuantity() + 0;
                            if ($shopOrderBefore - $quantity <= 0) {
                                $shopOrderChange = $shopOrderBefore;
                                $shopOrderAfter = 0;

                                if($shopOrderBefore - $quantity < 0){
                                    $saleErrDetails[$i] = [
                                        'productCode' => $product_code,
                                        'productName' => $saleInfo['productName'],
                                        'stateName' => $saleInfo['stateName'],
                                        'orderQuantity' => $shopOrderBefore,
                                        'salesQuantity' => $quantity,
                                    ];
                                }
                            }
                            else {
                                $shopOrderChange = $quantity;
                                $shopOrderAfter = $shopOrderBefore - $quantity;
                            }

                            $netshopaiProductInfo->setYahoo2OrderCsvInitQuantity($shopOrderAfter);
                            $netshopaiProductInfo->setUpdateUserName($this->getUser()['name']);
                            $this->entityManager->persist($netshopaiProductInfo);

                        }
                        else if ($form['shop_id_csv']->getData()->getId() == Netshop::AMAZON) {

                            $shopOrderBefore = $netshopaiProductInfo->getAmazonOrderCsvInitQuantity() + 0;
                            if ($shopOrderBefore - $quantity <= 0) {
                                $shopOrderChange = $shopOrderBefore;
                                $shopOrderAfter = 0;

                                if($shopOrderBefore - $quantity < 0){
                                    $saleErrDetails[$i] = [
                                        'productCode' => $product_code,
                                        'productName' => $saleInfo['productName'],
                                        'stateName' => $saleInfo['stateName'],
                                        'orderQuantity' => $shopOrderBefore,
                                        'salesQuantity' => $quantity,
                                    ];
                                }
                            }
                            else {
                                $shopOrderChange = $quantity;
                                $shopOrderAfter = $shopOrderBefore - $quantity;
                            }

                            $netshopaiProductInfo->setAmazonOrderCsvInitQuantity($shopOrderAfter);
                            $netshopaiProductInfo->setUpdateUserName($this->getUser()['name']);
                            $this->entityManager->persist($netshopaiProductInfo);

                        }
                        else if ($form['shop_id_csv']->getData()->getId() == Netshop::KAKAKU) {

                            $shopOrderBefore = $netshopaiProductInfo->getKakakuOrderCsvInitQuantity() + 0;
                            if ($shopOrderBefore - $quantity <= 0) {
                                $shopOrderChange = $shopOrderBefore;
                                $shopOrderAfter = 0;

                                if($shopOrderBefore - $quantity < 0){
                                    $saleErrDetails[$i] = [
                                        'productCode' => $product_code,
                                        'productName' => $saleInfo['productName'],
                                        'stateName' => $saleInfo['stateName'],
                                        'orderQuantity' => $shopOrderBefore,
                                        'salesQuantity' => $quantity,
                                    ];
                                }
                            }
                            else {
                                $shopOrderChange = $quantity;
                                $shopOrderAfter = $shopOrderBefore - $quantity;
                            }

                            $netshopaiProductInfo->setKakakuOrderCsvInitQuantity($shopOrderAfter);
                            $netshopaiProductInfo->setUpdateUserName($this->getUser()['name']);
                            $this->entityManager->persist($netshopaiProductInfo);

                        }
                        $i++;
                        // 在庫一覧（商品単位）
                        $stockListProduct->setOrderQuantity($allOrderBefore - $shopOrderChange);
                        $stockListProduct->setRemainingStockQuantity($allRemainBefore + $shopOrderChange);
                        $stockListProduct->setUpdateUserName($this->getUser()['name']);
                        $this->entityManager->persist($stockListProduct);
                    }
                }

            }

            $salesDateFrom = $form['sales_date_start']->getViewData();
            $salesDateTo = $form['sales_date_end']->getViewData();
            $this->netshopaiCSVHistoryRepository->insertNetshopaiCSVHistory($shopId,'2',$salesDateFrom, $salesDateTo,$this->getUser()['name']);

            $newCSVHistory = $this->netshopaiCSVHistoryRepository->findOneBy(['shop' => $shopId, 'upload_method' => 2], ['updateDate' => 'DESC']);
            $newCSVHistory_id = $newCSVHistory->getId();

            if($saleErrDetails != null){

                foreach ($saleErrDetails as $saleErrDetail){
                    $netshopaiCSVSaleErrDetail = new NetshopaiCSVSaleErrDetail();

                    $netshopaiCSVSaleErrDetail
                        ->setNetshopaiCsvId($newCSVHistory_id)
                        ->setProductCode($saleErrDetail['productCode'])
                        ->setProductName($saleErrDetail['productName'])
                        ->setStateName($saleErrDetail['stateName'])
                        ->setOrderQuantity($saleErrDetail['orderQuantity'])
                        ->setSalesQuantity($saleErrDetail['salesQuantity'])
                        ->setCreateUserName($this->getUser()['name'])
                        ->setUpdateUserName($this->getUser()['name']);

                    $this->entityManager->persist($netshopaiCSVSaleErrDetail);
                }

            }

            $this->entityManager->flush();
            $this->entityManager->getConnection()->commit();

//            $sth = $pdo->prepare('UPDATE dtb_netshopAI_runstatus set batch_runstate = :batch_runstate, update_date = current_timestamp WHERE shop_id = :shop_id AND batch_cd = :batch_cd;');
//            $sth->execute([
//                ':batch_runstate' => '0',
//                ':shop_id' => '5',
//                ':batch_cd' => '50',
//            ]);
//            $pdo->commit();

            $message = 'admin.common.csv_upload_sales_complete';
            $this->session->getFlashBag()->add('eccube.admin.success', $message);
        }
        // 操作履歴
        $netshopaiCSVHistories = $this->getSearchData();
        foreach ($netshopaiCSVHistories as $key => $netshopaiCSVHistory){
            $netshopaiCSVHistories[$key]['update_date'] = $this->makeDateStringUtcToAsiaTokyo($netshopaiCSVHistory['update_date']);
            if ($netshopaiCSVHistory['shop'] == 1 && $netshopaiCSVHistory['upload_method'] == 2) {
                $rakutenErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 2 && $netshopaiCSVHistory['upload_method'] == 2) {
                $yahooErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 5 && $netshopaiCSVHistory['upload_method'] == 2) {
                $yahoo2ErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if ($netshopaiCSVHistory['shop'] == 3 && $netshopaiCSVHistory['upload_method'] == 2) {
                $amazonErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 4 && $netshopaiCSVHistory['upload_method'] == 2) {
                $kakakuErrList = $this->netshopaiCSVSaleErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 1 && $netshopaiCSVHistory['upload_method'] == 1) {
                $rakutenCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 2 && $netshopaiCSVHistory['upload_method'] == 1) {
                $yahooCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 5 && $netshopaiCSVHistory['upload_method'] == 1) {
                $yahoo2CsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 3 && $netshopaiCSVHistory['upload_method'] == 1) {
                $amazonCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }
            else if($netshopaiCSVHistory['shop'] == 4 && $netshopaiCSVHistory['upload_method'] == 1) {
                $kakakuCsvErrList = $this->netshopaiCSVErrDetailRepository->findby(['netshopai_csv_id' => $netshopaiCSVHistory['id']]);
            }

        }
//        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $amazonHeaders, $kakakuHeaders);
        return $this->renderWithError($form, $rakutenHeaders, $yahooHeaders, $yahoo2Headers, $amazonHeaders, $kakakuHeaders, $netshopaiCSVHistories,
            $rakutenErrList, $yahooErrList, $yahoo2ErrList, $amazonErrList, $kakakuErrList, $rakutenCsvErrList, $yahooCsvErrList, $yahoo2CsvErrList, $amazonCsvErrList, $kakakuCsvErrList);
    }

    /**
     * ネットショップ操作履歴を取得.
     *
     * @return null|result
     */
    protected function getSearchData()
    {
        $this->entityManager->getConfiguration()->setSQLLogger(null);
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();

        $sql = '
                SELECT
                  a.*
                FROM
                  dtb_netshopAI_CSV_history a
                INNER JOIN (
                  SELECT
		             MAX(update_date) AS update_date,
		                 shop,
		                 upload_method
	            FROM
		        dtb_netshopAI_CSV_history
	            GROUP BY
		           shop,
		           upload_method
                   ) b
                   ON a.shop = b.shop
                   AND a.upload_method = b.upload_method
                   AND a.update_date = b.update_date
                   WHERE TRUE
                 ';

        $sql = $sql.' ORDER BY
        a.shop
        ,a.upload_method
        ';

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    /**
     * UTC時間を東京時間にする
     * @param string|null $date 時間文字列(yyyy-mm-dd HH:ii:ss)
     * @return string
     */
    public function makeDateStringUtcToAsiaTokyo(string $date = null)
    {
        if (!$date || $date !== date('Y-m-d H:i:s', strtotime($date))) {
            return '';
        }

        try {
            $date_utc = new \DateTime($date, new \DateTimeZone('UTC'));
            $date_asia_tokyo = $date_utc
                ->setTimezone(new \DateTimeZone('Asia/Tokyo'))
                ->format('Y-m-d H:i:s');
        } catch (\Exception $exception) {
            return '';
        }

        return $date_asia_tokyo;
    }
}