<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\NetshopAI;

use Eccube\Controller\AbstractController;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Entity\NetshopInfo;
use Eccube\Form\Type\Admin\NetshopInfoType;
use Eccube\Repository\NetshopInfoRepository;
use Eccube\Util\CacheUtil;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Twig_Environment;

/**
 *プログラム名 ： InfoSettingController.php
 *概　　要     ： ネットショップ情報設定
 *作　　成     ： 2021/7/2 CNC
 */
class InfoSettingController extends AbstractController
{
    /**
     * @var Twig_Environment
     */
    protected $twig;

    /**
     * @var NetshopInfoRepository
     */
    protected $NetshopInfoRepository;

    /**
     * InfoSettingController constructor.
     */
    public function __construct(Twig_Environment $twig, NetshopInfoRepository $NetshopInfoRepository)
    {
        $this->NetshopInfoRepository = $NetshopInfoRepository;
        $this->twig = $twig;
    }

    /**
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/information_setting", name="admin_netshopAI_infoSetting")
     * @Template("@admin/NetshopAI/info_setting.twig")
     *
     * @param Request $request
     *
     * @return array|\Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function index(Request $request, CacheUtil $cacheUtil)
    {
        $netshopInfo = $this->NetshopInfoRepository->get();

        // ネットショップ情報未設定の場合
        if ($netshopInfo === null) {
            $netshopInfo = new NetshopInfo();

            // 更新情報未設定
            $update_date = null;
            $update_User_Name = null;

            // 売価連動、在庫連動の開始にチェックオン
            $netshopInfo->setRakutenPriceInterlocking(true);
            $netshopInfo->setRakutenStockInterlocking(true);
            $netshopInfo->setYahooPriceInterlocking(true);
            $netshopInfo->setYahooStockInterlocking(true);
            $netshopInfo->setYahoo2PriceInterlocking(true);
            $netshopInfo->setYahoo2StockInterlocking(true);
            $netshopInfo->setAmazonPriceInterlocking(true);
            $netshopInfo->setAmazonStockInterlocking(true);
            $netshopInfo->setKakakuPriceInterlocking(true);
            $netshopInfo->setKakakuStockInterlocking(true);

        }
        else
        {
            // 更新情報取得
            $update_date = $netshopInfo->getUpdateDate()->format('Y/m/d H:i:s');
            $update_User_Name = $netshopInfo->getUpdateUserName();

            // 更新者にログインユーザー設定
            $netshopInfo->setUpdateUserName($this->getUser());
        }

        $builder = $this->formFactory->createBuilder(NetshopInfoType::class, $netshopInfo);

        $CloneInfo = clone $netshopInfo;
        $this->entityManager->detach($CloneInfo);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'netshopInfo' => $netshopInfo,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_INFOSETTING_INDEX_INITIALIZE, $event);

        $form = $builder->getForm();
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            if ($netshopInfo->getId() === null){
                $sysDateTime = new \datetime();
                $netshopInfo->setCreateUserName($this->getUser());
                $netshopInfo->setUpdateUserName($this->getUser());
                $netshopInfo->setCreateDate($sysDateTime);
                $netshopInfo->setUpdateDate($sysDateTime);
                $netshopInfo->setRakutenOrderSearchSuccessDatetime($sysDateTime->format('Y/m/d H:i:s'));
                $netshopInfo->setYahooOrderSearchSuccessDatetime($sysDateTime->format('Y/m/d H:i:s'));
                $netshopInfo->setYahoo2OrderSearchSuccessDatetime($sysDateTime->format('Y/m/d H:i:s'));
                $netshopInfo->setAmazonOrderSearchSuccessDatetime($sysDateTime->format('Y/m/d H:i:s'));
                $netshopInfo->setKakakuOrderSearchSuccessDatetime($sysDateTime->format('Y/m/d H:i:s'));
            }

            $this->entityManager->persist($netshopInfo);
            $this->entityManager->flush();

            $event = new EventArgs(
                [
                    'form' => $form,
                    'netshopInfo' => $netshopInfo,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(
                EccubeEvents::ADMIN_NETSHOPAI_INFOSETTING_INDEX_COMPLETE,
                $event
            );

            // キャッシュの削除
            $cacheUtil->clearDoctrineCache();

            $this->addSuccess('admin.common.save_complete', 'admin');

            return $this->redirectToRoute('admin_netshopAI_infoSetting');
        }

        $this->twig->addGlobal('NetshopInfo', $CloneInfo);

        return [
            'form' => $form->createView(),
            'update_date' => $update_date,
            'update_user_name' => $update_User_Name,
        ];
    }

    /**
     *  楽天市場接続テスト
     *
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/information_setting/connect_test_rakuten", name="admin_netshopAI_connect_test_rakuten")
     *
     * @param Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function connect_test_rakuten(Request $request)
    {
        if (($request->get('rakutenServiceSecret')) !== null && ($request->get('rakutenLicenseKey')) !== null) {
            $serviceSecret = $request->get('rakutenServiceSecret');
            $licenseKey = $request->get('rakutenLicenseKey');
            $encode = 'ESA '.base64_encode($serviceSecret.':'.$licenseKey);

            $keyword = '12345678901234567890';
            $url = "https://api.rms.rakuten.co.jp/es/2.0/product/search?keyword=$keyword";
            $header = $encode;

            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

            $headers = array(
                'Accept: application/json',
                "Authorization: $header",
            );

            curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

            $resp = curl_exec($curl);

            $code = curl_getinfo($curl, CURLINFO_HTTP_CODE);

            curl_close($curl);

        } else {
            $resp = false;
        }

        if (!$resp) {
            $result = [
                'success' => 0,
                'result' => "接続失敗。",
                '$resp' => $resp,
            ];
        } else {
            if (strpos($resp,'AuthError') || $code !== 200) {
                $result = [
                    'success' => 0,
                    'result' => "接続失敗。",
                    '$resp' => $resp,
                ];
            } else {
                $result = [
                    'success' => 1,
                    'result' => "接続成功。",
                    '$resp' => $resp,
                ];
            }
        }

        return $this->json($result);
    }

    /**
     *  Yahoo!ショッピングトークン取得
     *
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/information_setting/connect_test_yahoo", name="admin_netshopAI_connect_test_yahoo")
     *
     * @param Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function connect_test_yahoo(Request $request)
    {
        if (($request->get('yahooApplicationId')) !== null && ($request->get('yahooSecretId')) !== null && ($request->get('yahooAuthorizationCode')) !== null) {
            $applicationId = $request->get('yahooApplicationId');
            $secretId = $request->get('yahooSecretId');
            $authorizationCode = $request->get('yahooAuthorizationCode');
            $encode = 'Basic '.base64_encode($applicationId.':'.$secretId);

            $url = "https://auth.login.yahoo.co.jp/yconnect/v2/token";
            $header = $encode;
            $redirect_uri = "https://www.kaitorishouten-co.jp/";

            $headers = [
                'Content-Type: application/x-www-form-urlencoded',
                'Authorization: ' . $header,
            ];

            $param = array(
                'grant_type' => 'authorization_code',
                'code' => $authorizationCode,
                'redirect_uri' => $redirect_uri,
            );

            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');
            curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($param));

            $resp = curl_exec($curl);

            $code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            $token = json_decode($resp, true);

            curl_close($curl);

        } else {
            $resp = false;
        }

        if (!$resp) {
            $result = [
                'success' => 0,
                'result' => "取得失敗。",
                'resp' => $resp,
                'code' => $code,
                'token' => $token,
            ];
        } else {
            if ($token == null || $code !== 200) {
                $result = [
                    'success' => 0,
                    'result' => "取得失敗。",
                    'resp' => $resp,
                    'code' => $code,
                    'token' => $token,
                ];
            } else {
                $result = [
                    'success' => 1,
                    'result' => "取得成功。",
                    'resp' => $resp,
                    'code' => $code,
                    'token' => $token,
                    'refresh_token' => $token['refresh_token'],
                ];
            }
        }

        return $this->json($result);
    }
}
