<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\NetshopAI;

use Eccube\Controller\AbstractController;
use Eccube\Entity\BaseInfo;
use Eccube\Entity\Master\Netshop;
use Eccube\Entity\Product;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\Admin\CsvImportType;
use Eccube\Form\Type\Admin\ProductListType;
use Eccube\Repository\BaseInfoRepository;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\Master\NetshopRepository;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\Master\ProductPriceRuleRepository;
use Eccube\Repository\Master\ProductStatusRepository;
use Eccube\Repository\Master\RankRepository;
use Eccube\Repository\Master\RankTypeRepository;
use Eccube\Repository\NetshopaiProductInfoRepository;
use Eccube\Repository\NetshopInfoRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\ProductPriceOptionRepository;
use Eccube\Repository\ProductImageRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\StockListProductUnitRepository;
use Eccube\Repository\StateRepository;
use Eccube\Repository\TagRepository;
use Eccube\Repository\TaxRuleRepository;
use Eccube\Service\CsvExportService;
use Eccube\Util\FormUtil;
use Knp\Component\Pager\Paginator;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： ProductListController.php
 *概　　要     ： ネットショップ連動商品一覧
 *作　　成     ： 2021/7/15 CNC
 */
class ProductListController extends AbstractController
{
    /**
     * @var CsvExportService
     */
    protected $csvExportService;

    /**
     * @var ProductClassRepository
     */
    protected $productClassRepository;

    /**
     * @var ProductImageRepository
     */
    protected $productImageRepository;

    /**
     * @var TaxRuleRepository
     */
    protected $taxRuleRepository;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var StockListProductUnitRepository
     */
    protected $stockListProductUnitRepository;

    /**
     * @var BaseInfo
     */
    protected $BaseInfo;

    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;

    /**
     * @var ProductStatusRepository
     */
    protected $productStatusRepository;

    /**
     * @var TagRepository
     */
    protected $tagRepository;

    /**
     * @var RankRepository
     */
    protected $rankRepository;

    /**
     * @var RankTypeRepository
     */
    protected $rankTypeRepository;

    /**
     * @var ProductPriceRuleRepository
     */
    protected $productPriceRuleRepository;

    /**
     * @var ProductPriceOptionRepository
     */
    protected $productPriceOptionRepository;

    /**
     * @var NetshopaiProductInfoRepository
     */
    protected $netshopaiProductInfoRepository;

    /**
     * @var StateRepository
     */
    protected $stateRepository;

    /**
     * @var NetshopRepository
     */
    protected $netshopRepository;

    /**
     * @var NetshopInfoRepository
     */
    protected $NetshopInfoRepository;

    /**
     * ProductController constructor.
     *
     * @param CategoryRepository $categoryRepository
     * @param ProductRepository $productRepository
     * @param PageMaxRepository $pageMaxRepository
     * @param NetshopaiProductInfoRepository $netshopaiProductInfoRepository
     * @param StateRepository $stateRepository
     * @param NetshopRepository $netshopRepository
     * @param NetshopInfoRepository $NetshopInfoRepository
     */
    public function __construct(
        CategoryRepository $categoryRepository,
        ProductRepository $productRepository,
        StockListProductUnitRepository $stockListProductUnitRepository,
        PageMaxRepository $pageMaxRepository,
        NetshopaiProductInfoRepository $netshopaiProductInfoRepository,
        StateRepository $stateRepository,
        NetshopRepository $netshopRepository,
        NetshopInfoRepository $NetshopInfoRepository
    ) {
        $this->categoryRepository = $categoryRepository;
        $this->productRepository = $productRepository;
        $this->stockListProductUnitRepository = $stockListProductUnitRepository;
        $this->pageMaxRepository = $pageMaxRepository;
        $this->netshopaiProductInfoRepository = $netshopaiProductInfoRepository;
        $this->stateRepository = $stateRepository;
        $this->netshopRepository = $netshopRepository;
        $this->NetshopInfoRepository = $NetshopInfoRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/product_list", name="admin_netshopAI_product_list")
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/product_list/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_netshopAI_product_list_page")
     * @Template("@admin/NetshopAI/product_list.twig")
     */
    public function index(Request $request, $page_no = null, Paginator $paginator)
    {
        $builder = $this->formFactory
            ->createBuilder(ProductListType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_LIST_INDEX_INITIALIZE, $event);

        $searchForm = $builder->getForm();

        /**
         * ページの表示件数は, 以下の順に優先される.
         * - リクエストパラメータ
         * - セッション
         * - デフォルト値
         * また, セッションに保存する際は mtb_page_maxと照合し, 一致した場合のみ保存する.
         **/
        $page_count = $this->session->get('eccube.admin.netshopAI.search.page_count',
            $this->eccubeConfig->get('eccube_mltext_len'));

        $page_count_param = (int) $request->get('page_count');
        $pageMaxis = $this->pageMaxRepository->findAll();

        if ($page_count_param) {
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.admin.netshopAI.search.page_count', $page_count);
                    break;
                }
            }
        }

        // 状態
        $stateList = $this->stateRepository->getStateByCategory();

        $page_no_bk = $page_no;
        if ('POST' === $request->getMethod()) {
            $searchForm->handleRequest($request);

            if ($searchForm->isValid()) {
                /**
                 * 検索が実行された場合は, セッションに検索条件を保存する.
                 * ページ番号は最初のページ番号に初期化する.
                 */
                $page_no = 1;
                $searchData = $searchForm->getData();

                // 検索条件, ページ番号をセッションに保持.
                $this->session->set('eccube.admin.netshopAI.search', FormUtil::getViewData($searchForm));
                $this->session->set('eccube.admin.netshopAI.search.page_no', $page_no);
            } else {
                // 検索エラーの際は, 詳細検索枠を開いてエラー表示する.
                return [
                    'searchForm' => $searchForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $page_count,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.admin.netshopAI.search.page_no', (int) $page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.admin.netshopAI.search.page_no', 1);
                }
                $viewData = $this->session->get('eccube.admin.netshopAI.search', []);
                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
            } else {
                /**
                 * 初期表示の場合.
                 */
                $page_no = 1;

                // main category
                $categories = $this->categoryRepository->getList(null, false);
                $mainCategory = null;
                foreach($categories as $Category) {
                    if ($Category && ($Category->getHierarchy() == 1) ) {
                        $mainCategory = $Category;
                        break;
                    }
                }

                // submit default value
                $viewData = FormUtil::getViewData($searchForm);
//                if ($mainCategory) {
//                    $viewData['main_category_id'] = $mainCategory->getId();
//                }

                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
//                if ($mainCategory) {
//                    $searchData['main_category_id'] = $mainCategory;
//                }
                //log_info("searchData", [$searchData]);

                // セッション中の検索条件, ページ番号を初期化.
                $this->session->set('eccube.admin.netshopAI.search', $viewData);
                $this->session->set('eccube.admin.netshopAI.search.page_no', $page_no);
            }
        }

        $qb = '';
        $all_orders = [];
        if ('POST' === $request->getMethod() || null !== $page_no_bk){
            $qb = $this->netshopaiProductInfoRepository->getQueryBuilderBySearchDataForAdmin($searchData);
            $all_orders = $qb->getQuery()->getResult();
        }

        $sort_orders = $this->sortOrder($all_orders, $searchData);

        $event = new EventArgs(
            [
                'qb' => $qb,
                'searchData' => $searchData,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_LIST_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $page_count
        );

        // xlsxImportType
        $builder_xlsx_import = $this->formFactory
            ->createBuilder(CsvImportType::class);

        $event = new EventArgs(
            [
                'builder' => $builder_xlsx_import,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_LIST_INDEX_CSV_IMPORT_INITIALIZE, $event);

        $xlsx_import_form = $builder_xlsx_import->getForm();

        return [
            'searchForm' => $searchForm->createView(),
            'xlsxImportForm' => $xlsx_import_form->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'has_errors' => false,
            'request' => $request,
            'StateList' => $stateList,
        ];
    }

    private function sortOrder($orders, $searchData) {
        if ($searchData['sort_by']) {
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case '商品コード':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == "降順") {
                            return $a["productCode"] > $b["productCode"] ? -1 : 1;
                        }
                        return $a["productCode"] < $b["productCode"] ? -1 : 1;
                    });
                    break;
                case '状態':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == "降順") {
                            return $a["state"] > $b["state"] ? -1 : 1;
                        }
                        return $a["state"] < $b["state"] ? -1 : 1;
                    });
                    break;
            }
        }
        return $orders;
    }

    /**
     * 連動商品情報出力.
     *
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/export/xlsx", name="admin_netshopAI_export_xlsx")
     *
     * @param Request $request Request
     *
     * @return StreamedResponse
     *
     * @throws \Exception
     */
    public function xlsxExport(Request $request)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        ini_set('memory_limit', '2048M');

        $response = new StreamedResponse();
        $response->setCallback(function () use ($request) {

            // searchData
            $builder = $this->formFactory
                ->createBuilder(ProductListType::class);

            $event = new EventArgs(
                [
                    'builder' => $builder,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_LIST_INDEX_INITIALIZE, $event);

            $searchForm = $builder->getForm();

            $searchForm->handleRequest($request);

            $searchData = $searchForm->getData();

            // 画面入力取得
            $shop_id_csv = $searchData['shop_id_csv']->getId();
            $registered_product = $searchData['registered_product'];
            $unregistered_product = $searchData['unregistered_product'];

            // 明細開始行
            $count = 4;

            // xlsxファイル設定
            // Rakuten
            if ($shop_id_csv == '1') {
                $xlsxPath = $this->eccubeConfig->get('eccube_html_dir') . '/template/admin/assets/xlsx/Rakuten_連動商品一括登録.xlsx';
                $spreadsheet = IOFactory::load($xlsxPath);
                // 登録済商品
                if ($registered_product) {
                    $qb = $this->netshopaiProductInfoRepository->getQueryBuilderBySearchDataForCsv($shop_id_csv);
                    $xlsxDatasAll = $qb->getQuery()->getResult();

                    foreach ($xlsxDatasAll as $xlsxData) {

                        $spreadsheet->setActiveSheetIndex(0)
                            ->setCellValue('D' . $count, '楽天')
                            ->setCellValue('E' . $count, "\t" . $xlsxData[0]["productCode"] . "\t")
                            ->setCellValue('F' . $count, $xlsxData["p_productName"])
                            ->setCellValue('G' . $count, $xlsxData[0]["state"]["id"])
                            ->setCellValue('H' . $count, $xlsxData["st_state"])
                            ->setCellValue('I' . $count, $xlsxData[0]["priceInterlockingLevel"])
                            ->setCellValue('J' . $count, $xlsxData[0]["stockInterlockingKawaguchiOnly"] == true ? '開始' : '停止')
                            ->setCellValue('K' . $count, $xlsxData["slpu_stockQuantity"])
                            ->setCellValue('L' . $count, $xlsxData["slpu_provisionalShipmentQuantity"])
                            ->setCellValue('M' . $count, $xlsxData["slpu_orderQuantity"])
                            ->setCellValue('N' . $count, $xlsxData["slpu_remainingStockQuantity"])
                            ->setCellValue('O' . $count, $xlsxData["slpu_averageUnitPrice"])
                            ->setCellValue('P' . $count, $xlsxData[0]["rakutenShopKey"])
                            ->setCellValue('Q' . $count, $xlsxData[0]["rakutenProductCode"])
                            ->setCellValue('R' . $count, $xlsxData[0]["rakutenStockInterlocking"] == true ? '開始' : '停止')
                            ->setCellValue('S' . $count, $xlsxData[0]["rakutenPriceInterlocking"] == true ? '開始' : '停止')
                            ->setCellValue('T' . $count, $xlsxData[0]["rakutenPostageFreeFlag"] == true ? '送料無料' : 'すべての商品')
                            ->setCellValue('U' . $count, $xlsxData[0]["rakutenLowerSellingPriceSetting"] == true ? '手動設定' : '自動設定')
                            ->setCellValue('V' . $count, $xlsxData[0]["rakutenLowerSellingPrice"])
                            ->setCellValue('W' . $count, $xlsxData[0]["rakutenUpperSellingPrice"])
                            ->setCellValue('X' . $count, $xlsxData[0]["rakutenPostage"])
                            ->setCellValue('Y' . $count, $xlsxData[0]["rakutenCommissionRate"] / 100)
                            ->setCellValue('Z' . $count, $xlsxData[0]["rakutenLowerProfitRate"] / 100)
                            ->setCellValue('AA' . $count, $xlsxData[0]["rakutenGrossProfit"])
                            ->setCellValue('AB' . $count, $xlsxData[0]["rakutenAdjustmentRule"])
                            ->setCellValue('AC' . $count, $xlsxData[0]["rakutenLowestSellingPrice"])
                            ->setCellValue('AD' . $count, $xlsxData[0]["rakutenKeyword"])
                            ->setCellValue('AE' . $count, $xlsxData[0]["rakutenExcludedShop"])
                            ->setCellValue('AF' . $count, $xlsxData[0]["rakutenExcludedKeyword"])
                            ->setCellValue('AG' . $count, $xlsxData["nr_avaregePrice"])
                            ->setCellValue('AH' . $count, $xlsxData["nr_shopPrice"])
                            ->setCellValue('AI' . $count, $xlsxData["nr_grossProfit"])
                            ->setCellValue('AJ' . $count, $xlsxData["nr_profitRate"] / 100)
                            ->setCellValue('AK' . $count, $xlsxData["nr_lowerSellingPrice"])
                            ->setCellValue('AL' . $count, $xlsxData["nr_competitorsSellingPrice"])
                            ->setCellValue('AM' . $count, $xlsxData["nr_priceRanking"])
                            ->setCellValue('AN' . $count, $xlsxData["nr_competitorsDifference"])
                            ->setCellValue('AO' . $count, $xlsxData["nr_adjustmentRule"])
                            ->setCellValue('AP' . $count, $xlsxData["cpp_name"])
                            ->setCellValue('AQ' . $count, $xlsxData["c_name"]);

                        $count = $count + 1;
                    }
                }

                // 未登録商品
                if ($unregistered_product) {
                    $qb = $this->stockListProductUnitRepository->findProductsWithoutNetshopAIProductInfo($shop_id_csv);

                    $xlsxDatasAllWithout = $qb->getQuery()->getResult();

                    foreach ($xlsxDatasAllWithout as $xlsxData) {

                        $spreadsheet->setActiveSheetIndex(0)
                            ->setCellValue('A' . $count, '未')
                            ->setCellValue('D' . $count, '楽天')
                            ->setCellValue('E' . $count, "\t" . $xlsxData[0]["productCode"] . "\t")
                            ->setCellValue('F' . $count, $xlsxData["p_productName"])
                            ->setCellValue('G' . $count, $xlsxData[0]["State"]["id"])
                            ->setCellValue('H' . $count, $xlsxData["s_state"])
//                            ->setCellValue('I'.$count, $xlsxData["priceInterlockingLevel"])
                            ->setCellValue('K' . $count, $xlsxData[0]["stockQuantity"])
                            ->setCellValue('L' . $count, $xlsxData[0]["provisionalShipmentQuantity"])
                            ->setCellValue('M' . $count, $xlsxData[0]["orderQuantity"])
                            ->setCellValue('N' . $count, $xlsxData[0]["remainingStockQuantity"])
                            ->setCellValue('O' . $count, $xlsxData[0]["averageUnitPrice"])
                            ->setCellValue('AP' . $count, $xlsxData["cpp_name"])
                            ->setCellValue('AQ' . $count, $xlsxData["c_name"]);

                        $count = $count + 1;
                    }
                }
            } // Yahoo
            else if ($shop_id_csv == '2') {
                $xlsxPath = $this->eccubeConfig->get('eccube_html_dir') . '/template/admin/assets/xlsx/Yahoo_連動商品一括登録.xlsx';
                $spreadsheet = IOFactory::load($xlsxPath);

                // 登録済商品
                if ($registered_product) {
                    $qb = $this->netshopaiProductInfoRepository->getQueryBuilderBySearchDataForCsv($shop_id_csv);
                    $xlsxDatasAll = $qb->getQuery()->getResult();

                    foreach ($xlsxDatasAll as $xlsxData) {

                        $spreadsheet->setActiveSheetIndex(0)
                            ->setCellValue('D' . $count, 'Yahoo')
                            ->setCellValue('E' . $count, "\t" . $xlsxData[0]["productCode"] . "\t")
                            ->setCellValue('F' . $count, $xlsxData["p_productName"])
                            ->setCellValue('G' . $count, $xlsxData[0]["state"]["id"])
                            ->setCellValue('H' . $count, $xlsxData["st_state"])
                            ->setCellValue('I' . $count, $xlsxData[0]["priceInterlockingLevel"])
                            ->setCellValue('J' . $count, $xlsxData[0]["stockInterlockingKawaguchiOnly"] == true ? '開始' : '停止')
                            ->setCellValue('K' . $count, $xlsxData["slpu_stockQuantity"])
                            ->setCellValue('L' . $count, $xlsxData["slpu_provisionalShipmentQuantity"])
                            ->setCellValue('M' . $count, $xlsxData["slpu_orderQuantity"])
                            ->setCellValue('N' . $count, $xlsxData["slpu_remainingStockQuantity"])
                            ->setCellValue('O' . $count, $xlsxData["slpu_averageUnitPrice"])
                            ->setCellValue('P' . $count, $xlsxData[0]["yahooShopKey"])
                            ->setCellValue('Q' . $count, $xlsxData[0]["yahooProductCode"])
                            ->setCellValue('R' . $count, $xlsxData[0]["yahooStockInterlocking"] == true ? '開始' : '停止')
                            ->setCellValue('S' . $count, $xlsxData[0]["yahooPriceInterlocking"] == true ? '開始' : '停止')
                            ->setCellValue('T' . $count, $xlsxData[0]["yahooPostageFreeFlag"] == true ? '送料無料' : 'すべての商品')
                            ->setCellValue('U' . $count, $xlsxData[0]["yahooLowerSellingPriceSetting"] == true ? '手動設定' : '自動設定')
                            ->setCellValue('V' . $count, $xlsxData[0]["yahooLowerSellingPrice"])
                            ->setCellValue('W' . $count, $xlsxData[0]["yahooUpperSellingPrice"])
                            ->setCellValue('X' . $count, $xlsxData[0]["yahooPostage"])
                            ->setCellValue('Y' . $count, $xlsxData[0]["yahooCommissionRate"] / 100)
                            ->setCellValue('Z' . $count, $xlsxData[0]["yahooLowerProfitRate"] / 100)
                            ->setCellValue('AA' . $count, $xlsxData[0]["yahooGrossProfit"])
                            ->setCellValue('AB' . $count, $xlsxData[0]["yahooAdjustmentRule"])
                            ->setCellValue('AC' . $count, $xlsxData[0]["yahooLowestSellingPrice"])
                            ->setCellValue('AD' . $count, $xlsxData[0]["yahooKeyword"])
                            ->setCellValue('AE' . $count, $xlsxData[0]["yahooExcludedShop"])
                            ->setCellValue('AF' . $count, $xlsxData[0]["yahooExcludedKeyword"])
                            ->setCellValue('AG' . $count, $xlsxData["nr_avaregePrice"])
                            ->setCellValue('AH' . $count, $xlsxData["nr_shopPrice"])
                            ->setCellValue('AI' . $count, $xlsxData["nr_grossProfit"])
                            ->setCellValue('AJ' . $count, $xlsxData["nr_profitRate"] / 100)
                            ->setCellValue('AK' . $count, $xlsxData["nr_lowerSellingPrice"])
                            ->setCellValue('AL' . $count, $xlsxData["nr_competitorsSellingPrice"])
                            ->setCellValue('AM' . $count, $xlsxData["nr_priceRanking"])
                            ->setCellValue('AN' . $count, $xlsxData["nr_competitorsDifference"])
                            ->setCellValue('AO' . $count, $xlsxData["nr_adjustmentRule"])
                            ->setCellValue('AP' . $count, $xlsxData["cpp_name"])
                            ->setCellValue('AQ' . $count, $xlsxData["c_name"]);

                        $count = $count + 1;
                    }
                }

                // 未登録商品
                if ($unregistered_product) {
                    $qb = $this->stockListProductUnitRepository->findProductsWithoutNetshopAIProductInfo($shop_id_csv);

                    $xlsxDatasAllWithout = $qb->getQuery()->getResult();

                    foreach ($xlsxDatasAllWithout as $xlsxData) {

                        $spreadsheet->setActiveSheetIndex(0)
                            ->setCellValue('A' . $count, '未')
                            ->setCellValue('D' . $count, 'Yahoo')
                            ->setCellValue('E' . $count, "\t" . $xlsxData[0]["productCode"] . "\t")
                            ->setCellValue('F' . $count, $xlsxData["p_productName"])
                            ->setCellValue('G' . $count, $xlsxData[0]["State"]["id"])
                            ->setCellValue('H' . $count, $xlsxData["s_state"])
//                            ->setCellValue('I'.$count, $xlsxData["priceInterlockingLevel"])
                            ->setCellValue('K' . $count, $xlsxData[0]["stockQuantity"])
                            ->setCellValue('L' . $count, $xlsxData[0]["provisionalShipmentQuantity"])
                            ->setCellValue('M' . $count, $xlsxData[0]["orderQuantity"])
                            ->setCellValue('N' . $count, $xlsxData[0]["remainingStockQuantity"])
                            ->setCellValue('O' . $count, $xlsxData[0]["averageUnitPrice"])
                            ->setCellValue('AP' . $count, $xlsxData["cpp_name"])
                            ->setCellValue('AQ' . $count, $xlsxData["c_name"]);

                        $count = $count + 1;
                    }
                }
            } // Yahoo2
            else if ($shop_id_csv == '5') {
                $xlsxPath = $this->eccubeConfig->get('eccube_html_dir') . '/template/admin/assets/xlsx/Yahoo2_連動商品一括登録.xlsx';
                $spreadsheet = IOFactory::load($xlsxPath);

                // 登録済商品
                if ($registered_product) {
                    $qb = $this->netshopaiProductInfoRepository->getQueryBuilderBySearchDataForCsv($shop_id_csv);
                    $xlsxDatasAll = $qb->getQuery()->getResult();

                    foreach ($xlsxDatasAll as $xlsxData) {

                        $spreadsheet->setActiveSheetIndex(0)
                            ->setCellValue('D' . $count, 'Yahoo2')
                            ->setCellValue('E' . $count, "\t" . $xlsxData[0]["productCode"] . "\t")
                            ->setCellValue('F' . $count, $xlsxData["p_productName"])
                            ->setCellValue('G' . $count, $xlsxData[0]["state"]["id"])
                            ->setCellValue('H' . $count, $xlsxData["st_state"])
                            ->setCellValue('I' . $count, $xlsxData[0]["priceInterlockingLevel"])
                            ->setCellValue('J' . $count, $xlsxData[0]["stockInterlockingKawaguchiOnly"] == true ? '開始' : '停止')
                            ->setCellValue('K' . $count, $xlsxData["slpu_stockQuantity"])
                            ->setCellValue('L' . $count, $xlsxData["slpu_provisionalShipmentQuantity"])
                            ->setCellValue('M' . $count, $xlsxData["slpu_orderQuantity"])
                            ->setCellValue('N' . $count, $xlsxData["slpu_remainingStockQuantity"])
                            ->setCellValue('O' . $count, $xlsxData["slpu_averageUnitPrice"])
                            ->setCellValue('P' . $count, $xlsxData[0]["yahoo2ShopKey"])
                            ->setCellValue('Q' . $count, $xlsxData[0]["yahoo2ProductCode"])
                            ->setCellValue('R' . $count, $xlsxData[0]["yahoo2StockInterlocking"] == true ? '開始' : '停止')
                            ->setCellValue('S' . $count, $xlsxData[0]["yahoo2PriceInterlocking"] == true ? '開始' : '停止')
                            ->setCellValue('T' . $count, $xlsxData[0]["yahoo2PostageFreeFlag"] == true ? '送料無料' : 'すべての商品')
                            ->setCellValue('U' . $count, $xlsxData[0]["yahoo2LowerSellingPriceSetting"] == true ? '手動設定' : '自動設定')
                            ->setCellValue('V' . $count, $xlsxData[0]["yahoo2LowerSellingPrice"])
                            ->setCellValue('W' . $count, $xlsxData[0]["yahoo2UpperSellingPrice"])
                            ->setCellValue('X' . $count, $xlsxData[0]["yahoo2Postage"])
                            ->setCellValue('Y' . $count, $xlsxData[0]["yahoo2CommissionRate"] / 100)
                            ->setCellValue('Z' . $count, $xlsxData[0]["yahoo2LowerProfitRate"] / 100)
                            ->setCellValue('AA' . $count, $xlsxData[0]["yahoo2GrossProfit"])
                            ->setCellValue('AB' . $count, $xlsxData[0]["yahoo2AdjustmentRule"])
                            ->setCellValue('AC' . $count, $xlsxData[0]["yahoo2LowestSellingPrice"])
                            ->setCellValue('AD' . $count, $xlsxData[0]["yahoo2Keyword"])
                            ->setCellValue('AE' . $count, $xlsxData[0]["yahoo2ExcludedShop"])
                            ->setCellValue('AF' . $count, $xlsxData[0]["yahoo2ExcludedKeyword"])
                            ->setCellValue('AG' . $count, $xlsxData["nr_avaregePrice"])
                            ->setCellValue('AH' . $count, $xlsxData["nr_shopPrice"])
                            ->setCellValue('AI' . $count, $xlsxData["nr_grossProfit"])
                            ->setCellValue('AJ' . $count, $xlsxData["nr_profitRate"] / 100)
                            ->setCellValue('AK' . $count, $xlsxData["nr_lowerSellingPrice"])
                            ->setCellValue('AL' . $count, $xlsxData["nr_competitorsSellingPrice"])
                            ->setCellValue('AM' . $count, $xlsxData["nr_priceRanking"])
                            ->setCellValue('AN' . $count, $xlsxData["nr_competitorsDifference"])
                            ->setCellValue('AO' . $count, $xlsxData["nr_adjustmentRule"])
                            ->setCellValue('AP' . $count, $xlsxData["cpp_name"])
                            ->setCellValue('AQ' . $count, $xlsxData["c_name"]);

                        $count = $count + 1;
                    }
                }

                // 未登録商品
                if ($unregistered_product) {
                    $qb = $this->stockListProductUnitRepository->findProductsWithoutNetshopAIProductInfo($shop_id_csv);

                    $xlsxDatasAllWithout = $qb->getQuery()->getResult();

                    foreach ($xlsxDatasAllWithout as $xlsxData) {

                        $spreadsheet->setActiveSheetIndex(0)
                            ->setCellValue('A' . $count, '未')
                            ->setCellValue('D' . $count, 'Yahoo2')
                            ->setCellValue('E' . $count, "\t" . $xlsxData[0]["productCode"] . "\t")
                            ->setCellValue('F' . $count, $xlsxData["p_productName"])
                            ->setCellValue('G' . $count, $xlsxData[0]["State"]["id"])
                            ->setCellValue('H' . $count, $xlsxData["s_state"])
//                            ->setCellValue('I'.$count, $xlsxData["priceInterlockingLevel"])
                            ->setCellValue('K' . $count, $xlsxData[0]["stockQuantity"])
                            ->setCellValue('L' . $count, $xlsxData[0]["provisionalShipmentQuantity"])
                            ->setCellValue('M' . $count, $xlsxData[0]["orderQuantity"])
                            ->setCellValue('N' . $count, $xlsxData[0]["remainingStockQuantity"])
                            ->setCellValue('O' . $count, $xlsxData[0]["averageUnitPrice"])
                            ->setCellValue('AP' . $count, $xlsxData["cpp_name"])
                            ->setCellValue('AQ' . $count, $xlsxData["c_name"]);

                        $count = $count + 1;
                    }
                }
            } // Amazon
            else if ($shop_id_csv == '3') {
                $xlsxPath = $this->eccubeConfig->get('eccube_html_dir') . '/template/admin/assets/xlsx/Amazon_連動商品一括登録.xlsx';
                $spreadsheet = IOFactory::load($xlsxPath);

                // 登録済商品
                if ($registered_product) {
                    $qb = $this->netshopaiProductInfoRepository->getQueryBuilderBySearchDataForCsv($shop_id_csv);
                    $xlsxDatasAll = $qb->getQuery()->getResult();

                    foreach ($xlsxDatasAll as $xlsxData) {

                        $spreadsheet->setActiveSheetIndex(0)
                            ->setCellValue('D' . $count, 'Amazon')
                            ->setCellValue('E' . $count, "\t" . $xlsxData[0]["productCode"] . "\t")
                            ->setCellValue('F' . $count, $xlsxData["p_productName"])
                            ->setCellValue('G' . $count, $xlsxData[0]["state"]["id"])
                            ->setCellValue('H' . $count, $xlsxData["st_state"])
                            ->setCellValue('I' . $count, $xlsxData[0]["priceInterlockingLevel"])
                            ->setCellValue('J' . $count, $xlsxData[0]["stockInterlockingKawaguchiOnly"] == true ? '開始' : '停止')
                            ->setCellValue('K' . $count, $xlsxData["slpu_stockQuantity"])
                            ->setCellValue('L' . $count, $xlsxData["slpu_provisionalShipmentQuantity"])
                            ->setCellValue('M' . $count, $xlsxData["slpu_orderQuantity"])
                            ->setCellValue('N' . $count, $xlsxData["slpu_remainingStockQuantity"])
                            ->setCellValue('O' . $count, $xlsxData["slpu_averageUnitPrice"])
                            ->setCellValue('P' . $count, $xlsxData[0]["amazonShopKey"])
                            ->setCellValue('Q' . $count, $xlsxData[0]["amazonAsinCode"])
                            ->setCellValue('R' . $count, $xlsxData[0]["amazonAsinCode2"])
                            ->setCellValue('S' . $count, $xlsxData[0]["amazonStockInterlocking"] == true ? '開始' : '停止')
                            ->setCellValue('T' . $count, $xlsxData[0]["amazonPriceInterlocking"] == true ? '開始' : '停止')
                            ->setCellValue('U' . $count, $xlsxData[0]["amazonLowerSellingPriceSetting"] == true ? '手動設定' : '自動設定')
                            ->setCellValue('V' . $count, $xlsxData[0]["amazonLowerSellingPrice"])
                            ->setCellValue('W' . $count, $xlsxData[0]["amazonUpperSellingPrice"])
                            ->setCellValue('X' . $count, $xlsxData[0]["amazonPostage"])
                            ->setCellValue('Y' . $count, $xlsxData[0]["amazonCommissionRate"] / 100)
                            ->setCellValue('Z' . $count, $xlsxData[0]["amazonLowerProfitRate"] / 100)
                            ->setCellValue('AA' . $count, $xlsxData[0]["amazonGrossProfit"])
                            ->setCellValue('AB' . $count, $xlsxData[0]["amazonAdjustmentRule"])
                            ->setCellValue('AC' . $count, $xlsxData["nr_avaregePrice"])
                            ->setCellValue('AD' . $count, $xlsxData["nr_shopPrice"])
                            ->setCellValue('AE' . $count, $xlsxData["nr_grossProfit"])
                            ->setCellValue('AF' . $count, $xlsxData["nr_profitRate"] / 100)
                            ->setCellValue('AG' . $count, $xlsxData["nr_lowerSellingPrice"])
                            ->setCellValue('AH' . $count, $xlsxData["nr_competitorsSellingPrice"])
                            ->setCellValue('AI' . $count, $xlsxData["nr_priceRanking"])
                            ->setCellValue('AJ' . $count, $xlsxData["nr_competitorsDifference"])
                            ->setCellValue('AK' . $count, $xlsxData["nr_adjustmentRule"])
                            ->setCellValue('AL' . $count, $xlsxData["cpp_name"])
                            ->setCellValue('AM' . $count, $xlsxData["c_name"]);

                        $count = $count + 1;
                    }
                }

                // 未登録商品
                if ($unregistered_product) {
                    $qb = $this->stockListProductUnitRepository->findProductsWithoutNetshopAIProductInfo($shop_id_csv);

                    $xlsxDatasAllWithout = $qb->getQuery()->getResult();

                    foreach ($xlsxDatasAllWithout as $xlsxData) {

                        $spreadsheet->setActiveSheetIndex(0)
                            ->setCellValue('A' . $count, '未')
                            ->setCellValue('D' . $count, 'Amazon')
                            ->setCellValue('E' . $count, "\t" . $xlsxData[0]["productCode"] . "\t")
                            ->setCellValue('F' . $count, $xlsxData["p_productName"])
                            ->setCellValue('G' . $count, $xlsxData[0]["State"]["id"])
                            ->setCellValue('H' . $count, $xlsxData["s_state"])
//                            ->setCellValue('I'.$count, $xlsxData["priceInterlockingLevel"])
                            ->setCellValue('K' . $count, $xlsxData[0]["stockQuantity"])
                            ->setCellValue('L' . $count, $xlsxData[0]["provisionalShipmentQuantity"])
                            ->setCellValue('M' . $count, $xlsxData[0]["orderQuantity"])
                            ->setCellValue('N' . $count, $xlsxData[0]["remainingStockQuantity"])
                            ->setCellValue('O' . $count, $xlsxData[0]["averageUnitPrice"])
                            ->setCellValue('AL' . $count, $xlsxData["cpp_name"])
                            ->setCellValue('AM' . $count, $xlsxData["c_name"]);

                        $count = $count + 1;
                    }
                }
            } // Kakaku
            else {
                $xlsxPath = $this->eccubeConfig->get('eccube_html_dir') . '/template/admin/assets/xlsx/Makeshop_連動商品一括登録.xlsx';
                $spreadsheet = IOFactory::load($xlsxPath);

                // 登録済商品
                if ($registered_product) {
                    $qb = $this->netshopaiProductInfoRepository->getQueryBuilderBySearchDataForCsv($shop_id_csv);
                    $xlsxDatasAll = $qb->getQuery()->getResult();

                    foreach ($xlsxDatasAll as $xlsxData) {

                        $spreadsheet->setActiveSheetIndex(0)
                            ->setCellValue('D' . $count, 'MakeShop')
                            ->setCellValue('E' . $count, "\t" . $xlsxData[0]["productCode"] . "\t")
                            ->setCellValue('F' . $count, $xlsxData["p_productName"])
                            ->setCellValue('G' . $count, $xlsxData[0]["state"]["id"])
                            ->setCellValue('H' . $count, $xlsxData["st_state"])
                            ->setCellValue('I' . $count, $xlsxData[0]["priceInterlockingLevel"])
                            ->setCellValue('J' . $count, $xlsxData[0]["stockInterlockingKawaguchiOnly"] == true ? '開始' : '停止')
                            ->setCellValue('K' . $count, $xlsxData["slpu_stockQuantity"])
                            ->setCellValue('L' . $count, $xlsxData["slpu_provisionalShipmentQuantity"])
                            ->setCellValue('M' . $count, $xlsxData["slpu_orderQuantity"])
                            ->setCellValue('N' . $count, $xlsxData["slpu_remainingStockQuantity"])
                            ->setCellValue('O' . $count, $xlsxData["slpu_averageUnitPrice"])
                            ->setCellValue('P' . $count, $xlsxData[0]["kakakuShopKey"])
                            ->setCellValue('Q' . $count, $xlsxData[0]["kakakuProductId"])
                            ->setCellValue('R' . $count, $xlsxData[0]["kakakuStockInterlocking"] == true ? '開始' : '停止')
                            ->setCellValue('S' . $count, $xlsxData[0]["kakakuPriceInterlocking"] == true ? '開始' : '停止')
                            ->setCellValue('T' . $count, $xlsxData[0]["kakakuLowerSellingPriceSetting"] == true ? '手動設定' : '自動設定')
                            // INS-START CNC  2022/04/28 平均単価率利用フラグと平均単価率を追加する
                            ->setCellValue('U' . $count, $xlsxData[0]["kakakuAverageUnitPriceRateFlg"] == true ? '利用する' : '利用なし')
//                            ->setCellValue('U'.$count, $xlsxData[0]["kakakuAverageUnitPriceRate"] / 100 )
                            // INS-END CNC
                            // MOD-START CNC  2022/04/28 平均単価率利用フラグと平均単価率を追加する
                            ->setCellValue('V' . $count, $xlsxData[0]["kakakuLowerSellingPrice"])
                            ->setCellValue('W' . $count, $xlsxData[0]["kakakuUpperSellingPrice"])
                            ->setCellValue('X' . $count, $xlsxData[0]["kakakuPostage"])
                            ->setCellValue('Y' . $count, $xlsxData[0]["kakakuCommissionRate"] / 100)
                            ->setCellValue('Z' . $count, $xlsxData[0]["kakakuLowerProfitRate"] / 100)
                            ->setCellValue('AA' . $count, $xlsxData[0]["kakakuGrossProfit"])
                            ->setCellValue('AB' . $count, $xlsxData[0]["kakakuAdjustmentRule"])
                            ->setCellValue('AC' . $count, $xlsxData["nr_avaregePrice"])
                            ->setCellValue('AD' . $count, $xlsxData["nr_shopPrice"])
                            ->setCellValue('AE' . $count, $xlsxData["nr_grossProfit"])
                            ->setCellValue('AF' . $count, $xlsxData["nr_profitRate"] / 100)
                            ->setCellValue('AG' . $count, $xlsxData["nr_lowerSellingPrice"])
                            ->setCellValue('AH' . $count, $xlsxData["nr_competitorsSellingPrice"])
                            ->setCellValue('AI' . $count, $xlsxData["nr_priceRanking"])
                            ->setCellValue('AJ' . $count, $xlsxData["nr_competitorsDifference"])
                            ->setCellValue('AK' . $count, $xlsxData["nr_adjustmentRule"])
                            ->setCellValue('AL' . $count, $xlsxData["cpp_name"])
                            ->setCellValue('AM' . $count, $xlsxData["c_name"]);
                        // MOD-END CNC

                        $count = $count + 1;
                    }
                }

                // 未登録商品
                if ($unregistered_product) {
                    $qb = $this->stockListProductUnitRepository->findProductsWithoutNetshopAIProductInfo($shop_id_csv);

                    $xlsxDatasAllWithout = $qb->getQuery()->getResult();

                    foreach ($xlsxDatasAllWithout as $xlsxData) {

                        $spreadsheet->setActiveSheetIndex(0)
                            ->setCellValue('A' . $count, '未')
                            ->setCellValue('D' . $count, 'MakeShop')
                            ->setCellValue('E' . $count, "\t" . $xlsxData[0]["productCode"] . "\t")
                            ->setCellValue('F' . $count, $xlsxData["p_productName"])
                            ->setCellValue('G' . $count, $xlsxData[0]["State"]["id"])
                            ->setCellValue('H' . $count, $xlsxData["s_state"])
//                            ->setCellValue('I'.$count, $xlsxData["priceInterlockingLevel"])
                            ->setCellValue('K' . $count, $xlsxData[0]["stockQuantity"])
                            ->setCellValue('L' . $count, $xlsxData[0]["provisionalShipmentQuantity"])
                            ->setCellValue('M' . $count, $xlsxData[0]["orderQuantity"])
                            ->setCellValue('N' . $count, $xlsxData[0]["remainingStockQuantity"])
                            ->setCellValue('O' . $count, $xlsxData[0]["averageUnitPrice"])
                            ->setCellValue('AL' . $count, $xlsxData["cpp_name"])
                            ->setCellValue('AM' . $count, $xlsxData["c_name"]);

                        $count = $count + 1;
                    }
                }
            }

            $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');

            $writer->save('php://output');
        });

        $sysDate = (new \DateTime())->format('YmdHis');

        $filename = 'attachment;filename="連動商品一括登録_' . $sysDate . '.xlsx"';

        $response->headers->set('Content-Disposition', $filename);
        header("Content-Type:application/force-download");
        header("Content-Type:application/vnd.ms-excel");
        header("Content-Type:application/octet-stream");
        header("Content-Type:application/download");
        header("Pragma: no-cache");

        $response->send();

        return $response;
    }
}
