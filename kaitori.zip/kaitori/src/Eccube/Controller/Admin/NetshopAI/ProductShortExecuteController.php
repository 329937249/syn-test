<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\NetshopAI;

use Eccube\Common\Constant;
use Eccube\Controller\AbstractController;
use Eccube\Entity\Master\Netshop;
use Eccube\Entity\NetshopaiShortExecuteProduct;
use Eccube\Entity\Product;
use Eccube\Entity\ProductClass;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\EventListener\SecurityListener;
use Eccube\Form\Type\Admin\ProductShortExecuteType;
use Eccube\Repository\Master\NetshopRepository;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\NetshopaiShortExecuteProductRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Util\FormUtil;
use Eccube\Util\StringUtil;
use Knp\Component\Pager\Paginator;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： ProductShortExecuteController.php
 *概　　要     ： ネット連動一瞬連動商品管理
 *作　　成     ： 2023/01/28 CNC
 */
class ProductShortExecuteController extends AbstractController
{
    /**
     * @var ProductClassRepository
     */
    protected $productClassRepository;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;

    /**
     * @var NetshopRepository
     */
    protected $netshopRepository;

    /**
     * @var NetshopaiShortExecuteProductRepository
     */
    protected $NetshopaiShortExecuteProductRepository;

    /**
     * ProductController constructor.
     *
     * @param ProductRepository $productRepository
     * @param ProductClassRepository $productClassRepository
     * @param PageMaxRepository $pageMaxRepository
     * @param NetshopRepository $netshopRepository
     * @param NetshopaiShortExecuteProductRepository $NetshopaiShortExecuteProductRepository
     */
    public function __construct(
        ProductRepository $productRepository,
        ProductClassRepository $productClassRepository,
        PageMaxRepository $pageMaxRepository,
        NetshopRepository $netshopRepository,
        NetshopaiShortExecuteProductRepository $NetshopaiShortExecuteProductRepository
    ) {
        $this->productRepository = $productRepository;
        $this->productClassRepository = $productClassRepository;
        $this->pageMaxRepository = $pageMaxRepository;
        $this->netshopRepository = $netshopRepository;
        $this->NetshopaiShortExecuteProductRepository = $NetshopaiShortExecuteProductRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/product_short_execute", name="admin_netshopAI_product_short_execute")
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/product_short_execute/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_netshopAI_product_short_execute_page")
     * @Template("@admin/NetshopAI/product_short_execute.twig")
     */
    public function index(Request $request, $page_no = null, Paginator $paginator)
    {
        $builder = $this->formFactory
            ->createBuilder(ProductShortExecuteType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_SHORT_EXECUTE_INDEX_INITIALIZE, $event);

        $searchForm = $builder->getForm();

        /**
         * ページの表示件数は, 以下の順に優先される.
         * - リクエストパラメータ
         * - セッション
         * - デフォルト値
         * また, セッションに保存する際は mtb_page_maxと照合し, 一致した場合のみ保存する.
         **/
        $page_count = $this->session->get('eccube.admin.netshopAI.search.short.execute.page_count',
            $this->eccubeConfig->get('eccube_mltext_len'));

        $page_count_param = (int) $request->get('page_count');
        $pageMaxis = $this->pageMaxRepository->findAll();

        if ($page_count_param) {
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.admin.netshopAI.search.short.execute.page_count', $page_count);
                    break;
                }
            }
        }

        $page_no_bk = $page_no;
        if ('POST' === $request->getMethod()) {
            $searchForm->handleRequest($request);

            if ($searchForm->isValid()) {
                /**
                 * 検索が実行された場合は, セッションに検索条件を保存する.
                 * ページ番号は最初のページ番号に初期化する.
                 */
                $page_no = 1;
                $searchData = $searchForm->getData();

                // 検索条件, ページ番号をセッションに保持.
                $this->session->set('eccube.admin.netshopAI.search.short.execute', FormUtil::getViewData($searchForm));
                $this->session->set('eccube.admin.netshopAI.search.short.execute.page_no', $page_no);
            } else {
                // 検索エラーの際は, 詳細検索枠を開いてエラー表示する.
                return [
                    'searchForm' => $searchForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $page_count,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.admin.netshopAI.search.short.execute.page_no', (int) $page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.admin.netshopAI.search.short.execute.page_no', 1);
                }
                $viewData = $this->session->get('eccube.admin.netshopAI.search.short.execute', []);
                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
            } else {
                /**
                 * 初期表示の場合.
                 */
                $page_no = 1;

                // submit default value
                $viewData = FormUtil::getViewData($searchForm);

                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);

                // セッション中の検索条件, ページ番号を初期化.
                $this->session->set('eccube.admin.netshopAI.short.execute.search', $viewData);
                $this->session->set('eccube.admin.netshopAI.search.short.execute.page_no', $page_no);
            }
        }

        $qb = '';
        $all_orders = [];
        if ('POST' === $request->getMethod() || null !== $page_no_bk){
            // TODO
            $qb = $this->NetshopaiShortExecuteProductRepository->getQueryBuilderBySearchData($searchData);
            $all_orders = $qb->getQuery()->getResult();
        }

        $sort_orders = $this->sortOrder($all_orders, $searchData);

        $event = new EventArgs(
            [
                'qb' => $qb,
                'searchData' => $searchData,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_SHORT_EXECUTE_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $page_count
        );

        return [
            'searchForm' => $searchForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'has_errors' => false,
            'request' => $request,
        ];
    }

    private function sortOrder($orders, $searchData) {
        if ($searchData['sort_by']) {
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case 'ショップ名':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == "降順") {
                            return $a["shop"]["id"] > $b["shop"]["id"] ? -1 : 1;
                        }
                        return $a["shop"]["id"] < $b["shop"]["id"] ? -1 : 1;
                    });
                    break;
                case '商品コード':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == "降順") {
                            return $a["productCode"] > $b["productCode"] ? -1 : 1;
                        }
                        return $a["productCode"] < $b["productCode"] ? -1 : 1;
                    });
                    break;
            }
        }
        return $orders;
    }

    /**
     *
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/shortExecute/new", name="admin_netshopAI_shortExecute_new", methods={"POST"})
     *
     * @param Request $request Request
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function shortExecuteNew(Request $request)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()){
            $shop_id = $request->get('shop_id');
            $product_id = $request->get('product_id');
            $product_name = $request->get('product_name');
            $product_class_id = $request->get('product_class_id');
            $product_code = $request->get('product_code');

            /** @var $NetshopaiShortExecuteProduct NetshopaiShortExecuteProduct */
            $EntityNetshopaiShortExecuteProduct = $this->NetshopaiShortExecuteProductRepository->findOneBy([
                'Shop' => $shop_id,
                'productCode' => $product_code,
            ]);

            if ($EntityNetshopaiShortExecuteProduct) {

                $EntityNetshopaiShortExecuteProduct->setExecuteKbn("0");
                $EntityNetshopaiShortExecuteProduct->setHistoryJobId("0");

                $EntityNetshopaiShortExecuteProduct->setUpdateUserName($this->getUser()['name']);
                $EntityNetshopaiShortExecuteProduct->setUpdateDate(new \DateTime());

                $this->entityManager->persist($EntityNetshopaiShortExecuteProduct);
                $this->entityManager->flush();

                $data = ['error_flg' => '0',];

            } else {

                $EntityNetshopaiShortExecuteProduct = new NetshopaiShortExecuteProduct();

                /** @var $netShop Netshop */
                $netShop = $this->netshopRepository->find($shop_id);
                /** @var $product Product */
                $product = $this->productRepository->find($product_id);
                /** @var $productClass ProductClass */
                $productClass = $this->productClassRepository->find($product_class_id);

                $EntityNetshopaiShortExecuteProduct->setShop($netShop);
                $EntityNetshopaiShortExecuteProduct->setProduct($product);
                $EntityNetshopaiShortExecuteProduct->setProductClass($productClass);
                $EntityNetshopaiShortExecuteProduct->setProductName($product_name);
                $EntityNetshopaiShortExecuteProduct->setProductCode($product_code);
                $EntityNetshopaiShortExecuteProduct->setExecuteKbn("0");
                $EntityNetshopaiShortExecuteProduct->setHistoryJobId("0");

                $EntityNetshopaiShortExecuteProduct->setCreateUserName($this->getUser());
                $EntityNetshopaiShortExecuteProduct->setUpdateUserName($this->getUser());

                $this->entityManager->persist($EntityNetshopaiShortExecuteProduct);
                $this->entityManager->flush();

                $data = ['error_flg' => '0',];
            }

        }
        return $this->json($data);
    }

    /**
     *
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/shortExecute/new/list", name="admin_netshopAI_shortExecute_new_list", methods={"POST"})
     *
     * @param Request $request Request
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function shortExecuteNewList(Request $request)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()){
            $shop_id = $request->get('shop_id');
            $product_id = "";
            $product_name = "";
            $product_class_id = "";
            $product_code_list = $request->get('product_code_list');
            $err_product_code = "";

            $product_code_list_array = explode(',', $product_code_list);

            foreach ($product_code_list_array as $product_code) {

                // 商品取得
                $array_entity_product = $product_code
                    ? $this->productRepository->findProductsWithProductCode($product_code)
                    : [];

                if (!empty($array_entity_product) && !empty($array_entity_product[0]) && !empty($array_entity_product[0][0])) {
                    /** @var Product $entity_product */
                    $entity_product = $array_entity_product[0][0];
                    $product_id = $entity_product->getId();
                    $product_name = $entity_product->getName();
                    $product_class_id = $entity_product->getProductClasses()[0]->getId();

                } else {
                    $err_product_code = $err_product_code." ".$product_code;
                    continue;
                }

                /** @var $NetshopaiShortExecuteProduct NetshopaiShortExecuteProduct */
                $EntityNetshopaiShortExecuteProduct = $this->NetshopaiShortExecuteProductRepository->findOneBy([
                    'Shop' => $shop_id,
                    'productCode' => $product_code,
                ]);

                if ($EntityNetshopaiShortExecuteProduct) {

                    $EntityNetshopaiShortExecuteProduct->setExecuteKbn("0");
                    $EntityNetshopaiShortExecuteProduct->setHistoryJobId("0");

                    $EntityNetshopaiShortExecuteProduct->setUpdateUserName($this->getUser()['name']);
                    $EntityNetshopaiShortExecuteProduct->setUpdateDate(new \DateTime());

                    $this->entityManager->persist($EntityNetshopaiShortExecuteProduct);
                    $this->entityManager->flush();

                } else {

                    $EntityNetshopaiShortExecuteProduct = new NetshopaiShortExecuteProduct();

                    /** @var $netShop Netshop */
                    $netShop = $this->netshopRepository->find($shop_id);
                    /** @var $product Product */
                    $product = $this->productRepository->find($product_id);
                    /** @var $productClass ProductClass */
                    $productClass = $this->productClassRepository->find($product_class_id);

                    $EntityNetshopaiShortExecuteProduct->setShop($netShop);
                    $EntityNetshopaiShortExecuteProduct->setProduct($product);
                    $EntityNetshopaiShortExecuteProduct->setProductClass($productClass);
                    $EntityNetshopaiShortExecuteProduct->setProductName($product_name);
                    $EntityNetshopaiShortExecuteProduct->setProductCode($product_code);
                    $EntityNetshopaiShortExecuteProduct->setExecuteKbn("0");
                    $EntityNetshopaiShortExecuteProduct->setHistoryJobId("0");

                    $EntityNetshopaiShortExecuteProduct->setCreateUserName($this->getUser());
                    $EntityNetshopaiShortExecuteProduct->setUpdateUserName($this->getUser());

                    $this->entityManager->persist($EntityNetshopaiShortExecuteProduct);
                    $this->entityManager->flush();

                }
            }

            $data = ['err_product_code' => $err_product_code,];

        }
        return $this->json($data);
    }

    /**
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/shortExecute/{id}/delete", requirements={"id" = "\d+"}, name="admin_netshopAI_shortExecute_delete", methods={"DELETE"})
     */
    public function delete(Request $request, int $id = null)
    {
        $this->isTokenValid();

        if (!is_null($id)) {
            /** @var $NetshopaiShortExecuteProduct NetshopaiShortExecuteProduct */
            $NetshopaiShortExecuteProduct = $this->NetshopaiShortExecuteProductRepository->find($id);

            if (!$NetshopaiShortExecuteProduct) {
                $message = trans('admin.common.delete_error_already_deleted');

                $this->addError($message, 'admin');
            } else {
                log_info('ネット一瞬連動商品削除開始', [$id]);

                $name = $NetshopaiShortExecuteProduct->getProductName();

                try {
                    $this->NetshopaiShortExecuteProductRepository->delete($NetshopaiShortExecuteProduct);
                    $this->entityManager->flush();

                    $event = new EventArgs(
                        [
                            'NetshopaiShortExecuteProduct' => $NetshopaiShortExecuteProduct,
                        ],
                        $request
                    );
                    $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_SHORT_EXECUTE_DELETE_COMPLETE, $event);

                    $this->addSuccess('admin.common.delete_complete', 'admin');

                    log_info('ネット一瞬連動商品削除完了', [$id]);

                } catch (\Exception $e) {
                    log_info('ネット一瞬連動商品削除エラー', [$id, $e]);

                    $message = trans('admin.common.delete_error.foreign_key', ['%name%' => $name]);
                    $this->addError($message, 'admin');
                }
            }
        } else {
            log_info('ネット一瞬連動商品削除エラー', [$id]);

            $message = trans('admin.common.delete_error');
            $this->addError($message, 'admin');
        }

        return $this->redirect($this->generateUrl('admin_netshopAI_product_short_execute').'?resume='.Constant::ENABLED);
    }

}
