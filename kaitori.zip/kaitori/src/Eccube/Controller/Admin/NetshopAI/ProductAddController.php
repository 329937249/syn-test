<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\NetshopAI;

use Eccube\Controller\AbstractController;
use Eccube\Entity\BaseInfo;
use Eccube\Entity\Master\Netshop;
use Eccube\Entity\Product;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\EventListener\SecurityListener;
use Eccube\Form\Type\Admin\CsvImportType;
use Eccube\Form\Type\Admin\ProductAddType;
use Eccube\Form\Type\Admin\ProductListType;
use Eccube\Repository\BaseInfoRepository;
use Eccube\Repository\CategoryRepository;
use Eccube\Repository\Master\NetshopRepository;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\Master\ProductPriceRuleRepository;
use Eccube\Repository\Master\ProductStatusRepository;
use Eccube\Repository\Master\RankRepository;
use Eccube\Repository\Master\RankTypeRepository;
use Eccube\Repository\NetshopaiProductInfoRepository;
use Eccube\Repository\NetshopInfoRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\ProductPriceOptionRepository;
use Eccube\Repository\ProductImageRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\StockListProductUnitRepository;
use Eccube\Repository\StateRepository;
use Eccube\Repository\TagRepository;
use Eccube\Repository\TaxRuleRepository;
use Eccube\Service\CsvExportService;
use Eccube\Util\FormUtil;
use Eccube\Util\StringUtil;
use Knp\Component\Pager\Paginator;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： ProductAddController.php
 *概　　要     ： ネットショップ連動商品一覧
 *作　　成     ： 2021/7/15 CNC
 */
class ProductAddController extends AbstractController
{
    /**
     * @var CsvExportService
     */
    protected $csvExportService;

    /**
     * @var ProductClassRepository
     */
    protected $productClassRepository;

    /**
     * @var ProductImageRepository
     */
    protected $productImageRepository;

    /**
     * @var TaxRuleRepository
     */
    protected $taxRuleRepository;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var StockListProductUnitRepository
     */
    protected $stockListProductUnitRepository;

    /**
     * @var BaseInfo
     */
    protected $BaseInfo;

    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;

    /**
     * @var ProductStatusRepository
     */
    protected $productStatusRepository;

    /**
     * @var TagRepository
     */
    protected $tagRepository;

    /**
     * @var RankRepository
     */
    protected $rankRepository;

    /**
     * @var RankTypeRepository
     */
    protected $rankTypeRepository;

    /**
     * @var ProductPriceRuleRepository
     */
    protected $productPriceRuleRepository;

    /**
     * @var ProductPriceOptionRepository
     */
    protected $productPriceOptionRepository;

    /**
     * @var NetshopaiProductInfoRepository
     */
    protected $netshopaiProductInfoRepository;

    /**
     * @var StateRepository
     */
    protected $stateRepository;

    /**
     * @var NetshopRepository
     */
    protected $netshopRepository;

    /**
     * @var NetshopInfoRepository
     */
    protected $NetshopInfoRepository;

    /**
     * ProductController constructor.
     *
     * @param CategoryRepository $categoryRepository
     * @param ProductRepository $productRepository
     * @param PageMaxRepository $pageMaxRepository
     * @param NetshopaiProductInfoRepository $netshopaiProductInfoRepository
     * @param StateRepository $stateRepository
     * @param NetshopRepository $netshopRepository
     * @param NetshopInfoRepository $NetshopInfoRepository
     */
    public function __construct(
        CategoryRepository $categoryRepository,
        ProductRepository $productRepository,
        StockListProductUnitRepository $stockListProductUnitRepository,
        PageMaxRepository $pageMaxRepository,
        NetshopaiProductInfoRepository $netshopaiProductInfoRepository,
        StateRepository $stateRepository,
        NetshopRepository $netshopRepository,
        NetshopInfoRepository $NetshopInfoRepository
    ) {
        $this->categoryRepository = $categoryRepository;
        $this->productRepository = $productRepository;
        $this->stockListProductUnitRepository = $stockListProductUnitRepository;
        $this->pageMaxRepository = $pageMaxRepository;
        $this->netshopaiProductInfoRepository = $netshopaiProductInfoRepository;
        $this->stateRepository = $stateRepository;
        $this->netshopRepository = $netshopRepository;
        $this->NetshopInfoRepository = $NetshopInfoRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/product_add", name="admin_netshopAI_product_add")
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/product_add/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_netshopAI_product_add_page")
     * @Template("@admin/NetshopAI/product_add.twig")
     */
    public function index(Request $request, $page_no = null, Paginator $paginator)
    {
        $builder = $this->formFactory
            ->createBuilder(ProductAddType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_ADD_INDEX_INITIALIZE, $event);

        $searchForm = $builder->getForm();

        /**
         * ページの表示件数は, 以下の順に優先される.
         * - リクエストパラメータ
         * - セッション
         * - デフォルト値
         * また, セッションに保存する際は mtb_page_maxと照合し, 一致した場合のみ保存する.
         **/
        $page_count = $this->session->get('eccube.admin.netshopAI.search.page_count',
            $this->eccubeConfig->get('eccube_mltext_len'));

        $page_count_param = (int) $request->get('page_count');
        $pageMaxis = $this->pageMaxRepository->findAll();

        if ($page_count_param) {
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.admin.netshopAI.search.page_count', $page_count);
                    break;
                }
            }
        }

        $page_no_bk = $page_no;
        if ('POST' === $request->getMethod()) {
            $searchForm->handleRequest($request);

            if ($searchForm->isValid()) {
                /**
                 * 検索が実行された場合は, セッションに検索条件を保存する.
                 * ページ番号は最初のページ番号に初期化する.
                 */
                $page_no = 1;
                $searchData = $searchForm->getData();

                // 検索条件, ページ番号をセッションに保持.
                $this->session->set('eccube.admin.netshopAI.search', FormUtil::getViewData($searchForm));
                $this->session->set('eccube.admin.netshopAI.search.page_no', $page_no);
            } else {
                // 検索エラーの際は, 詳細検索枠を開いてエラー表示する.
                return [
                    'searchForm' => $searchForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $page_count,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.admin.netshopAI.search.page_no', (int) $page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.admin.netshopAI.search.page_no', 1);
                }
                $viewData = $this->session->get('eccube.admin.netshopAI.search', []);
                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
            } else {
                /**
                 * 初期表示の場合.
                 */
                $page_no = 1;

                // main category
                $categories = $this->categoryRepository->getList(null, false);
                $mainCategory = null;
                foreach($categories as $Category) {
                    if ($Category && ($Category->getHierarchy() == 1) ) {
                        $mainCategory = $Category;
                        break;
                    }
                }

                // submit default value
                $viewData = FormUtil::getViewData($searchForm);

                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);

                // セッション中の検索条件, ページ番号を初期化.
                $this->session->set('eccube.admin.netshopAI.search', $viewData);
                $this->session->set('eccube.admin.netshopAI.search.page_no', $page_no);
            }
        }

        $qb = '';
        $all_orders = [];
        if ('POST' === $request->getMethod() || null !== $page_no_bk){
            if($searchData['processingType'] == '0')
            {
                $qb = $this->netshopaiProductInfoRepository->getQueryBuilderBySearchDataAddForAdmin($searchData);
                $all_orders = $qb->getQuery()->getResult();
                $sort_orders = $this->sortOrder($all_orders, $searchData);
            }
            elseif ($searchData['processingType'] == '1')
            {
                $qb = $this->getSearchStockData($searchData);
                $sort_orders = $this->sortOrder($qb, $searchData);
            }
        }

        if($qb == '')
        {
            $sort_orders = $this->sortOrder($all_orders, $searchData);
        }

        $event = new EventArgs(
            [
                'qb' => $qb,
                'searchData' => $searchData,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_ADD_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $page_count
        );

        // xlsxImportType
        $builder_xlsx_import = $this->formFactory
            ->createBuilder(CsvImportType::class);

        $event = new EventArgs(
            [
                'builder' => $builder_xlsx_import,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_ADD_INDEX_CSV_IMPORT_INITIALIZE, $event);

        $xlsx_import_form = $builder_xlsx_import->getForm();

        return [
            'searchForm' => $searchForm->createView(),
            'xlsxImportForm' => $xlsx_import_form->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'has_errors' => false,
            'request' => $request,
        ];
    }

    private function sortOrder($orders, $searchData) {
        if ($searchData['sort_by']) {
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case '商品コード':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == "降順") {
                            return $a["productCode"] > $b["productCode"] ? -1 : 1;
                        }
                        return $a["productCode"] < $b["productCode"] ? -1 : 1;
                    });
                    break;
                case '状態':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == "降順") {
                            return $a["state"] > $b["state"] ? -1 : 1;
                        }
                        return $a["state"] < $b["state"] ? -1 : 1;
                    });
                    break;
            }
        }
        return $orders;
    }

    /**
     * 連動商品情報出力.
     *
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/export_all/xlsx", name="admin_netshopAI_export_all_xlsx")
     *
     * @param Request $request Request
     *
     * @return StreamedResponse
     *
     * @throws \Exception
     */
    public function xlsxExport(Request $request)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        ini_set('memory_limit', '2048M');

        $response = new StreamedResponse();
        $response->setCallback(function () use ($request) {

            // searchData
            $builder = $this->formFactory
                ->createBuilder(ProductAddType::class);

            $event = new EventArgs(
                [
                    'builder' => $builder,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_ADD_INDEX_INITIALIZE, $event);

            $searchForm = $builder->getForm();

            $searchForm->handleRequest($request);

            $searchData = $searchForm->getData();

            // 明細開始行
            $count = 4;

            $shop_id = $searchData['shop_id']->getId();

            $shop_name = '';

            switch ($shop_id) {
                case Netshop::RAKUTEN:
                    // 楽天店舗登録なし
                    $shop_name = '楽天';
                    // xlsxファイル設定
                    $xlsxPath = $this->eccubeConfig->get('eccube_html_dir').'/template/admin/assets/xlsx/Rakuten_連動商品一括登録.xlsx';
                    $spreadsheet = IOFactory::load($xlsxPath);
                    break;

                case Netshop::YAHOO:
                    // Yahoo店舗登録なし
                    $shop_name = 'Yahoo';
                    // xlsxファイル設定
                    $xlsxPath = $this->eccubeConfig->get('eccube_html_dir').'/template/admin/assets/xlsx/Yahoo_連動商品一括登録.xlsx';
                    $spreadsheet = IOFactory::load($xlsxPath);
                    break;

                case Netshop::YAHOO2:
                    // Yahoo2店舗登録なし
                    $shop_name = 'Yahoo2';
                    // xlsxファイル設定
                    $xlsxPath = $this->eccubeConfig->get('eccube_html_dir') . '/template/admin/assets/xlsx/Yahoo2_連動商品一括登録.xlsx';
                    $spreadsheet = IOFactory::load($xlsxPath);
                    break;

                case Netshop::AMAZON:
                    // Amazon店舗登録なし
                    $shop_name = 'Amazon';
                    // xlsxファイル設定
                    $xlsxPath = $this->eccubeConfig->get('eccube_html_dir').'/template/admin/assets/xlsx/Amazon_連動商品一括登録.xlsx';
                    $spreadsheet = IOFactory::load($xlsxPath);
                    break;

                case Netshop::KAKAKU:
                    // 自社店舗登録なし
                    $shop_name = '価格';
                    // xlsxファイル設定
                    $xlsxPath = $this->eccubeConfig->get('eccube_html_dir').'/template/admin/assets/xlsx/Makeshop_連動商品一括登録.xlsx';
                    $spreadsheet = IOFactory::load($xlsxPath);
            }

            if($searchData['processingType'] == '0')
            {
                $qb = $this->netshopaiProductInfoRepository->getQueryBuilderBySearchDataAddForCsv($searchData);
                $xlsxDatasAll = $qb->getQuery()->getResult();

                foreach ($xlsxDatasAll as $xlsxData) {

                    $spreadsheet->setActiveSheetIndex(0)
                        ->setCellValue('D'.$count, $shop_name)
                        ->setCellValue('E'.$count, "\t".$xlsxData[0]["productCode"]."\t")
                        ->setCellValue('F'.$count, $xlsxData["p_productName"])
                        ->setCellValue('G'.$count, $xlsxData[0]["state"]["id"])
                        ->setCellValue('H'.$count, $xlsxData["st_state"])
                        ->setCellValue('I'.$count, $xlsxData[0]["priceInterlockingLevel"])
                        ->setCellValue('J'.$count, $xlsxData[0]["stockInterlockingKawaguchiOnly"] == true ? '開始' : '停止')
                        ->setCellValue('K'.$count, $xlsxData["slpu_stockQuantity"])
                        ->setCellValue('L'.$count, $xlsxData["slpu_provisionalShipmentQuantity"])
                        ->setCellValue('M'.$count, $xlsxData["slpu_orderQuantity"])
                        ->setCellValue('N'.$count, $xlsxData["slpu_remainingStockQuantity"])
                        ->setCellValue('O'.$count, $xlsxData["slpu_averageUnitPrice"])
                        ->setCellValue('P'.$count, $xlsxData[0]["rakutenShopKey"])
                        ->setCellValue('Q'.$count, $xlsxData[0]["rakutenProductCode"])
                        ->setCellValue('R'.$count, $xlsxData[0]["rakutenStockInterlocking"] == true ? '開始' : '停止')
                        ->setCellValue('S'.$count, $xlsxData[0]["rakutenPriceInterlocking"] == true ? '開始' : '停止')
                        ->setCellValue('T'.$count, $xlsxData[0]["rakutenPostageFreeFlag"] == true ? '送料無料' : 'すべての商品')
                        ->setCellValue('U'.$count, $xlsxData[0]["rakutenLowerSellingPriceSetting"] == true ? '手動設定' : '自動設定')
                        ->setCellValue('V'.$count, $xlsxData[0]["rakutenLowerSellingPrice"])
                        ->setCellValue('W'.$count, $xlsxData[0]["rakutenUpperSellingPrice"])
                        ->setCellValue('X'.$count, $xlsxData[0]["rakutenPostage"])
                        ->setCellValue('Y'.$count, $xlsxData[0]["rakutenCommissionRate"] / 100 )
                        ->setCellValue('Z'.$count, $xlsxData[0]["rakutenLowerProfitRate"] / 100 )
                        ->setCellValue('AA'.$count, $xlsxData[0]["rakutenGrossProfit"])
                        ->setCellValue('AB'.$count, $xlsxData[0]["rakutenAdjustmentRule"])
                        ->setCellValue('AC'.$count, $xlsxData[0]["rakutenLowestSellingPrice"])
                        ->setCellValue('AD'.$count, $xlsxData[0]["rakutenKeyword"])
                        ->setCellValue('AE'.$count, $xlsxData[0]["rakutenExcludedShop"])
                        ->setCellValue('AF'.$count, $xlsxData[0]["rakutenExcludedKeyword"])
                        ->setCellValue('AG'.$count, $xlsxData["nr_avaregePrice"])
                        ->setCellValue('AH'.$count, $xlsxData["nr_shopPrice"])
                        ->setCellValue('AI'.$count, $xlsxData["nr_grossProfit"])
                        ->setCellValue('AJ'.$count, $xlsxData["nr_profitRate"] / 100)
                        ->setCellValue('AK'.$count, $xlsxData["nr_lowerSellingPrice"])
                        ->setCellValue('AL'.$count, $xlsxData["nr_competitorsSellingPrice"])
                        ->setCellValue('AM'.$count, $xlsxData["nr_priceRanking"])
                        ->setCellValue('AN'.$count, $xlsxData["nr_competitorsDifference"])
                        ->setCellValue('AO'.$count, $xlsxData["nr_adjustmentRule"])
                        ->setCellValue('AP'.$count, $xlsxData["cpp_name"])
                        ->setCellValue('AQ'.$count, $xlsxData["c_name"]);

                    $count = $count + 1;
                }
            }
            elseif ($searchData['processingType'] == '1')
            {
                $qb = $this->getSearchStockDataForCsv($searchData);
                $xlsxDatasAll = $this->sortOrder($qb, $searchData);

                foreach ($xlsxDatasAll as $xlsxData) {

                    // 在庫数 > 0、かつ、データが存在しない
                    if($xlsxData["id"] == null || $xlsxData["id"] == '')
                    {
                        // 楽天 yahoo
                        if($shop_id == '1' || $shop_id == '2'|| $shop_id == '5')
                        {
                            $spreadsheet->setActiveSheetIndex(0)
                                ->setCellValue('A'.$count, '未')
                                ->setCellValue('D'.$count, $shop_name)
                                ->setCellValue('E'.$count, "\t".$xlsxData["productCode"]."\t")
                                ->setCellValue('F'.$count, $xlsxData["productName"])
                                ->setCellValue('G'.$count, $xlsxData["stateId"])
                                ->setCellValue('H'.$count, $xlsxData["stateName"])
                                ->setCellValue('K'.$count, $xlsxData["stockQuantity"])
                                ->setCellValue('L'.$count, $xlsxData["provisionalShipmentQuantity"])
                                ->setCellValue('M'.$count, $xlsxData["orderQuantity"])
                                ->setCellValue('N'.$count, $xlsxData["remainingStockQuantity"])
                                ->setCellValue('O'.$count, $xlsxData["averageUnitPrice"])
                                ->setCellValue('AP'.$count, $xlsxData["cp_name"])
                                ->setCellValue('AQ'.$count, $xlsxData["cpp_name2"] != '' ? $xlsxData["cpp_name2"]  : $xlsxData["cpp_name1"] );
                        }
                        // Amazon 価格
                        elseif ($shop_id == '3' || $shop_id == '4')
                        {
                            $spreadsheet->setActiveSheetIndex(0)
                                ->setCellValue('A'.$count, '未')
                                ->setCellValue('D'.$count, $shop_name)
                                ->setCellValue('E'.$count, "\t".$xlsxData["productCode"]."\t")
                                ->setCellValue('F'.$count, $xlsxData["productName"])
                                ->setCellValue('G'.$count, $xlsxData["stateId"])
                                ->setCellValue('H'.$count, $xlsxData["stateName"])
                                ->setCellValue('K'.$count, $xlsxData["stockQuantity"])
                                ->setCellValue('L'.$count, $xlsxData["provisionalShipmentQuantity"])
                                ->setCellValue('M'.$count, $xlsxData["orderQuantity"])
                                ->setCellValue('N'.$count, $xlsxData["remainingStockQuantity"])
                                ->setCellValue('O'.$count, $xlsxData["averageUnitPrice"])
                                ->setCellValue('AL'.$count, $xlsxData["cp_name"])
                                ->setCellValue('AM'.$count, $xlsxData["cpp_name2"] != '' ? $xlsxData["cpp_name2"]  : $xlsxData["cpp_name1"] );
                        }
                    }
                    else {
                        // 楽天
                        if($shop_id == '1')
                        {
                            $spreadsheet->setActiveSheetIndex(0)
                                ->setCellValue('D'.$count, $shop_name)
                                ->setCellValue('E'.$count, "\t".$xlsxData["productCode"]."\t")
                                ->setCellValue('F'.$count, $xlsxData["productName"])
                                ->setCellValue('G'.$count, $xlsxData["stateId"])
                                ->setCellValue('H'.$count, $xlsxData["stateName"])
                                ->setCellValue('I'.$count, $xlsxData["priceInterlockingLevel"])
                                ->setCellValue('J'.$count, $xlsxData["stockInterlockingKawaguchiOnly"] == true ? '開始' : '停止')
                                ->setCellValue('K'.$count, $xlsxData["stockQuantity"])
                                ->setCellValue('L'.$count, $xlsxData["provisionalShipmentQuantity"])
                                ->setCellValue('M'.$count, $xlsxData["orderQuantity"])
                                ->setCellValue('N'.$count, $xlsxData["remainingStockQuantity"])
                                ->setCellValue('O'.$count, $xlsxData["averageUnitPrice"])
                                ->setCellValue('P'.$count, $xlsxData["rakutenShopKey"])
                                ->setCellValue('Q'.$count, $xlsxData["rakutenProductCode"])
                                ->setCellValue('R'.$count, $xlsxData["rakutenStockInterlocking"] == true ? '開始' : '停止')
                                ->setCellValue('S'.$count, $xlsxData["rakutenPriceInterlocking"] == true ? '開始' : '停止')
                                ->setCellValue('T'.$count, $xlsxData["rakutenPostageFreeFlag"] == true ? '送料無料' : 'すべての商品')
                                ->setCellValue('U'.$count, $xlsxData["rakutenLowerSellingPriceSetting"] == true ? '手動設定' : '自動設定')
                                ->setCellValue('V'.$count, $xlsxData["rakutenLowerSellingPrice"])
                                ->setCellValue('W'.$count, $xlsxData["rakutenUpperSellingPrice"])
                                ->setCellValue('X'.$count, $xlsxData["rakutenPostage"])
                                ->setCellValue('Y'.$count, $xlsxData["rakutenCommissionRate"] / 100 )
                                ->setCellValue('Z'.$count, $xlsxData["rakutenLowerProfitRate"] / 100 )
                                ->setCellValue('AA'.$count, $xlsxData["rakutenGrossProfit"])
                                ->setCellValue('AB'.$count, $xlsxData["rakutenAdjustmentRule"])
                                ->setCellValue('AC'.$count, $xlsxData["rakutenLowestSellingPrice"])
                                ->setCellValue('AD'.$count, $xlsxData["rakutenKeyword"])
                                ->setCellValue('AE'.$count, $xlsxData["rakutenExcludedShop"])
                                ->setCellValue('AF'.$count, $xlsxData["rakutenExcludedKeyword"])
                                ->setCellValue('AG'.$count, $xlsxData["nr_avaregePrice"])
                                ->setCellValue('AH'.$count, $xlsxData["nr_shopPrice"])
                                ->setCellValue('AI'.$count, $xlsxData["nr_grossProfit"])
                                ->setCellValue('AJ'.$count, $xlsxData["nr_profitRate"] / 100)
                                ->setCellValue('AK'.$count, $xlsxData["nr_lowerSellingPrice"])
                                ->setCellValue('AL'.$count, $xlsxData["nr_competitorsSellingPrice"])
                                ->setCellValue('AM'.$count, $xlsxData["nr_priceRanking"])
                                ->setCellValue('AN'.$count, $xlsxData["nr_competitorsDifference"])
                                ->setCellValue('AO'.$count, $xlsxData["nr_adjustmentRule"])
                                ->setCellValue('AP'.$count, $xlsxData["cp_name"])
                                ->setCellValue('AQ'.$count, $xlsxData["cpp_name2"] != '' ? $xlsxData["cpp_name2"]  : $xlsxData["cpp_name1"] );
                        }
                        // yahoo
                        elseif ($shop_id == '2')
                        {
                            $spreadsheet->setActiveSheetIndex(0)
                                ->setCellValue('D'.$count, $shop_name)
                                ->setCellValue('E'.$count, "\t".$xlsxData["productCode"]."\t")
                                ->setCellValue('F'.$count, $xlsxData["productName"])
                                ->setCellValue('G'.$count, $xlsxData["stateId"])
                                ->setCellValue('H'.$count, $xlsxData["stateName"])
                                ->setCellValue('I'.$count, $xlsxData["priceInterlockingLevel"])
                                ->setCellValue('J'.$count, $xlsxData["stockInterlockingKawaguchiOnly"] == true ? '開始' : '停止')
                                ->setCellValue('K'.$count, $xlsxData["stockQuantity"])
                                ->setCellValue('L'.$count, $xlsxData["provisionalShipmentQuantity"])
                                ->setCellValue('M'.$count, $xlsxData["orderQuantity"])
                                ->setCellValue('N'.$count, $xlsxData["remainingStockQuantity"])
                                ->setCellValue('O'.$count, $xlsxData["averageUnitPrice"])
                                ->setCellValue('P'.$count, $xlsxData["yahooShopKey"])
                                ->setCellValue('Q'.$count, $xlsxData["yahooProductCode"])
                                ->setCellValue('R'.$count, $xlsxData["yahooStockInterlocking"] == true ? '開始' : '停止')
                                ->setCellValue('S'.$count, $xlsxData["yahooPriceInterlocking"] == true ? '開始' : '停止')
                                ->setCellValue('T'.$count, $xlsxData["yahooPostageFreeFlag"] == true ? '送料無料' : 'すべての商品')
                                ->setCellValue('U'.$count, $xlsxData["yahooLowerSellingPriceSetting"] == true ? '手動設定' : '自動設定')
                                ->setCellValue('V'.$count, $xlsxData["yahooLowerSellingPrice"])
                                ->setCellValue('W'.$count, $xlsxData["yahooUpperSellingPrice"])
                                ->setCellValue('X'.$count, $xlsxData["yahooPostage"])
                                ->setCellValue('Y'.$count, $xlsxData["yahooCommissionRate"] / 100 )
                                ->setCellValue('Z'.$count, $xlsxData["yahooLowerProfitRate"] / 100 )
                                ->setCellValue('AA'.$count, $xlsxData["yahooGrossProfit"])
                                ->setCellValue('AB'.$count, $xlsxData["yahooAdjustmentRule"])
                                ->setCellValue('AC'.$count, $xlsxData["yahooLowestSellingPrice"])
                                ->setCellValue('AD'.$count, $xlsxData["yahooKeyword"])
                                ->setCellValue('AE'.$count, $xlsxData["yahooExcludedShop"])
                                ->setCellValue('AF'.$count, $xlsxData["yahooExcludedKeyword"])
                                ->setCellValue('AG'.$count, $xlsxData["nr_avaregePrice"])
                                ->setCellValue('AH'.$count, $xlsxData["nr_shopPrice"])
                                ->setCellValue('AI'.$count, $xlsxData["nr_grossProfit"])
                                ->setCellValue('AJ'.$count, $xlsxData["nr_profitRate"] / 100)
                                ->setCellValue('AK'.$count, $xlsxData["nr_lowerSellingPrice"])
                                ->setCellValue('AL'.$count, $xlsxData["nr_competitorsSellingPrice"])
                                ->setCellValue('AM'.$count, $xlsxData["nr_priceRanking"])
                                ->setCellValue('AN'.$count, $xlsxData["nr_competitorsDifference"])
                                ->setCellValue('AO'.$count, $xlsxData["nr_adjustmentRule"])
                                ->setCellValue('AP'.$count, $xlsxData["cp_name"])
                                ->setCellValue('AQ'.$count, $xlsxData["cpp_name2"] != '' ? $xlsxData["cpp_name2"]  : $xlsxData["cpp_name1"] );
                        }
                        // Amazon
                        elseif ($shop_id == '3')
                        {
                            $spreadsheet->setActiveSheetIndex(0)
                                ->setCellValue('D'.$count, $shop_name)
                                ->setCellValue('E'.$count, "\t".$xlsxData["productCode"]."\t")
                                ->setCellValue('F'.$count, $xlsxData["productName"])
                                ->setCellValue('G'.$count, $xlsxData["stateId"])
                                ->setCellValue('H'.$count, $xlsxData["stateName"])
                                ->setCellValue('I'.$count, $xlsxData["priceInterlockingLevel"])
                                ->setCellValue('J'.$count, $xlsxData["stockInterlockingKawaguchiOnly"] == true ? '開始' : '停止')
                                ->setCellValue('K'.$count, $xlsxData["stockQuantity"])
                                ->setCellValue('L'.$count, $xlsxData["provisionalShipmentQuantity"])
                                ->setCellValue('M'.$count, $xlsxData["orderQuantity"])
                                ->setCellValue('N'.$count, $xlsxData["remainingStockQuantity"])
                                ->setCellValue('O'.$count, $xlsxData["averageUnitPrice"])
                                ->setCellValue('P'.$count, $xlsxData["amazonShopKey"])
                                ->setCellValue('Q'.$count, $xlsxData["amazonAsinCode"])
                                ->setCellValue('R'.$count, $xlsxData["amazonAsinCode2"])
                                ->setCellValue('S'.$count, $xlsxData["amazonStockInterlocking"] == true ? '開始' : '停止')
                                ->setCellValue('T'.$count, $xlsxData["amazonPriceInterlocking"] == true ? '開始' : '停止')
                                ->setCellValue('U'.$count, $xlsxData["amazonLowerSellingPriceSetting"] == true ? '手動設定' : '自動設定')
                                ->setCellValue('V'.$count, $xlsxData["amazonLowerSellingPrice"])
                                ->setCellValue('W'.$count, $xlsxData["amazonUpperSellingPrice"])
                                ->setCellValue('X'.$count, $xlsxData["amazonPostage"])
                                ->setCellValue('Y'.$count, $xlsxData["amazonCommissionRate"] / 100 )
                                ->setCellValue('Z'.$count, $xlsxData["amazonLowerProfitRate"] / 100 )
                                ->setCellValue('AA'.$count, $xlsxData["amazonGrossProfit"])
                                ->setCellValue('AB'.$count, $xlsxData["amazonAdjustmentRule"])
                                ->setCellValue('AC'.$count, $xlsxData["nr_avaregePrice"])
                                ->setCellValue('AD'.$count, $xlsxData["nr_shopPrice"])
                                ->setCellValue('AE'.$count, $xlsxData["nr_grossProfit"])
                                ->setCellValue('AF'.$count, $xlsxData["nr_profitRate"] / 100)
                                ->setCellValue('AG'.$count, $xlsxData["nr_lowerSellingPrice"])
                                ->setCellValue('AH'.$count, $xlsxData["nr_competitorsSellingPrice"])
                                ->setCellValue('AI'.$count, $xlsxData["nr_priceRanking"])
                                ->setCellValue('AJ'.$count, $xlsxData["nr_competitorsDifference"])
                                ->setCellValue('AK'.$count, $xlsxData["nr_adjustmentRule"])
                                ->setCellValue('AL'.$count, $xlsxData["cp_name"])
                                ->setCellValue('AM'.$count, $xlsxData["cpp_name2"] != '' ? $xlsxData["cpp_name2"]  : $xlsxData["cpp_name1"] );
                        }
                        // 価格
                        elseif ($shop_id == '4')
                        {
                            $spreadsheet->setActiveSheetIndex(0)
                                ->setCellValue('D'.$count, $shop_name)
                                ->setCellValue('E'.$count, "\t".$xlsxData["productCode"]."\t")
                                ->setCellValue('F'.$count, $xlsxData["productName"])
                                ->setCellValue('G'.$count, $xlsxData["stateId"])
                                ->setCellValue('H'.$count, $xlsxData["stateName"])
                                ->setCellValue('I'.$count, $xlsxData["priceInterlockingLevel"])
                                ->setCellValue('J'.$count, $xlsxData["stockInterlockingKawaguchiOnly"] == true ? '開始' : '停止')
                                ->setCellValue('K'.$count, $xlsxData["stockQuantity"])
                                ->setCellValue('L'.$count, $xlsxData["provisionalShipmentQuantity"])
                                ->setCellValue('M'.$count, $xlsxData["orderQuantity"])
                                ->setCellValue('N'.$count, $xlsxData["remainingStockQuantity"])
                                ->setCellValue('O'.$count, $xlsxData["averageUnitPrice"])
                                ->setCellValue('P'.$count, $xlsxData["kakakuShopKey"])
                                ->setCellValue('Q'.$count, $xlsxData["kakakuProductId"])
                                ->setCellValue('R'.$count, $xlsxData["kakakuStockInterlocking"] == true ? '開始' : '停止')
                                ->setCellValue('S'.$count, $xlsxData["kakakuPriceInterlocking"] == true ? '開始' : '停止')
                                ->setCellValue('T'.$count, $xlsxData["kakakuLowerSellingPriceSetting"] == true ? '手動設定' : '自動設定')
                                ->setCellValue('U'.$count, $xlsxData["kakakuAverageUnitPriceRateFlg"] == true ? '利用する' : '利用なし')
                                ->setCellValue('V'.$count, $xlsxData["kakakuLowerSellingPrice"])
                                ->setCellValue('W'.$count, $xlsxData["kakakuUpperSellingPrice"])
                                ->setCellValue('X'.$count, $xlsxData["kakakuPostage"])
                                ->setCellValue('Y'.$count, $xlsxData["kakakuCommissionRate"] / 100 )
                                ->setCellValue('Z'.$count, $xlsxData["kakakuLowerProfitRate"] / 100 )
                                ->setCellValue('AA'.$count, $xlsxData["kakakuGrossProfit"])
                                ->setCellValue('AB'.$count, $xlsxData["kakakuAdjustmentRule"])
                                ->setCellValue('AC'.$count, $xlsxData["nr_avaregePrice"])
                                ->setCellValue('AD'.$count, $xlsxData["nr_shopPrice"])
                                ->setCellValue('AE'.$count, $xlsxData["nr_grossProfit"])
                                ->setCellValue('AF'.$count, $xlsxData["nr_profitRate"] / 100)
                                ->setCellValue('AG'.$count, $xlsxData["nr_lowerSellingPrice"])
                                ->setCellValue('AH'.$count, $xlsxData["nr_competitorsSellingPrice"])
                                ->setCellValue('AI'.$count, $xlsxData["nr_priceRanking"])
                                ->setCellValue('AJ'.$count, $xlsxData["nr_competitorsDifference"])
                                ->setCellValue('AK'.$count, $xlsxData["nr_adjustmentRule"])
                                ->setCellValue('AL'.$count, $xlsxData["cp_name"])
                                ->setCellValue('AM'.$count, $xlsxData["cpp_name2"] != '' ? $xlsxData["cpp_name2"]  : $xlsxData["cpp_name1"] );
                        }
                        // Yahoo2
                        elseif ($shop_id == '5')
                        {
                            $spreadsheet->setActiveSheetIndex(0)
                                ->setCellValue('D' . $count, $shop_name)
                                ->setCellValue('E' . $count, "\t" . $xlsxData["productCode"] . "\t")
                                ->setCellValue('F' . $count, $xlsxData["productName"])
                                ->setCellValue('G' . $count, $xlsxData["stateId"])
                                ->setCellValue('H' . $count, $xlsxData["stateName"])
                                ->setCellValue('I' . $count, $xlsxData["priceInterlockingLevel"])
                                ->setCellValue('J' . $count, $xlsxData["stockInterlockingKawaguchiOnly"] == true ? '開始' : '停止')
                                ->setCellValue('K'.$count, $xlsxData["stockQuantity"])
                                ->setCellValue('L'.$count, $xlsxData["provisionalShipmentQuantity"])
                                ->setCellValue('M'.$count, $xlsxData["orderQuantity"])
                                ->setCellValue('N'.$count, $xlsxData["remainingStockQuantity"])
                                ->setCellValue('O'.$count, $xlsxData["averageUnitPrice"])
                                ->setCellValue('P' . $count, $xlsxData["yahoo2ShopKey"])
                                ->setCellValue('Q' . $count, $xlsxData["yahoo2ProductCode"])
                                ->setCellValue('R' . $count, $xlsxData["yahoo2StockInterlocking"] == true ? '開始' : '停止')
                                ->setCellValue('S' . $count, $xlsxData["yahoo2PriceInterlocking"] == true ? '開始' : '停止')
                                ->setCellValue('T' . $count, $xlsxData["yahoo2PostageFreeFlag"] == true ? '送料無料' : 'すべての商品')
                                ->setCellValue('U' . $count, $xlsxData["yahoo2LowerSellingPriceSetting"] == true ? '手動設定' : '自動設定')
                                ->setCellValue('V' . $count, $xlsxData["yahoo2LowerSellingPrice"])
                                ->setCellValue('W' . $count, $xlsxData["yahoo2UpperSellingPrice"])
                                ->setCellValue('X' . $count, $xlsxData["yahoo2Postage"])
                                ->setCellValue('Y' . $count, $xlsxData["yahoo2CommissionRate"] / 100)
                                ->setCellValue('Z' . $count, $xlsxData["yahoo2LowerProfitRate"] / 100)
                                ->setCellValue('AA' . $count, $xlsxData["yahoo2GrossProfit"])
                                ->setCellValue('AB' . $count, $xlsxData["yahoo2AdjustmentRule"])
                                ->setCellValue('AC' . $count, $xlsxData["yahoo2LowestSellingPrice"])
                                ->setCellValue('AD' . $count, $xlsxData["yahoo2Keyword"])
                                ->setCellValue('AE' . $count, $xlsxData["yahoo2ExcludedShop"])
                                ->setCellValue('AF' . $count, $xlsxData["yahoo2ExcludedKeyword"])
                                ->setCellValue('AG' . $count, $xlsxData["nr_avaregePrice"])
                                ->setCellValue('AH' . $count, $xlsxData["nr_shopPrice"])
                                ->setCellValue('AI' . $count, $xlsxData["nr_grossProfit"])
                                ->setCellValue('AJ' . $count, $xlsxData["nr_profitRate"] / 100)
                                ->setCellValue('AK' . $count, $xlsxData["nr_lowerSellingPrice"])
                                ->setCellValue('AL' . $count, $xlsxData["nr_competitorsSellingPrice"])
                                ->setCellValue('AM' . $count, $xlsxData["nr_priceRanking"])
                                ->setCellValue('AN' . $count, $xlsxData["nr_competitorsDifference"])
                                ->setCellValue('AO' . $count, $xlsxData["nr_adjustmentRule"])
                                ->setCellValue('AP' . $count, $xlsxData["cp_name"])
                                ->setCellValue('AQ' . $count, $xlsxData["cpp_name2"] != '' ? $xlsxData["cpp_name2"]  : $xlsxData["cpp_name1"] );
                        }
                    }

                    $count = $count + 1;
                }
            }

            $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');

            $writer->save('php://output');
        });

        $sysDate = (new \DateTime())->format('YmdHis');

        $filename = 'attachment;filename="連動商品一括新規登録_'.$sysDate.'.xlsx"';

        $response->headers->set('Content-Disposition', $filename);
        header("Content-Type:application/force-download");
        header("Content-Type:application/vnd.ms-excel");
        header("Content-Type:application/octet-stream");
        header("Content-Type:application/download");
        header("Pragma: no-cache");

        $response->send();

        return $response;
    }

    /**
     * 商品一覧表示.
     *
     * @param $searchData
     *
     * @return mixed[]
     */
    public function getSearchStockData($searchData)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();
        $sql = '
                 SELECT
                    slpu.product_code AS productCode,
                    p.name AS productName,
                    s.state AS stateName,
                    npi.id AS id,
                    npi.rakuten_stock_interlocking AS rakutenStockInterlocking,
                    npi.rakuten_price_interlocking AS rakutenPriceInterlocking,
                    npi.yahoo_stock_interlocking AS yahooStockInterlocking,
                    npi.yahoo_price_interlocking AS yahooPriceInterlocking,
                    npi.yahoo2_stock_interlocking AS yahoo2StockInterlocking,
                    npi.yahoo2_price_interlocking AS yahoo2PriceInterlocking,
                    npi.amazon_stock_interlocking AS amazonStockInterlocking,
                    npi.amazon_price_interlocking AS amazonPriceInterlocking,
                    npi.kakaku_stock_interlocking AS kakakuStockInterlocking,
                    npi.kakaku_price_interlocking AS kakakuPriceInterlocking,
                    npi.update_user_name AS updateUserName,
                    npi.update_date AS updateDate,
                    slpu.stock_quantity
                FROM dtb_stock_list_product_unit slpu
                INNER JOIN dtb_product_class pc 
                ON slpu.product_class_id = pc.id 
                INNER JOIN dtb_product p 
                ON pc.product_id = p.id 
                INNER JOIN mtb_state s 
                ON slpu.state_id = s.id 
                LEFT JOIN mtb_netshopAI_product_info npi
                ON slpu.product_code = npi.product_code
                AND slpu.state_id = npi.state_id
                WHERE 
                slpu.stock_quantity > 0 
                AND (npi.id is null OR (npi.id is not null AND 
            ';

        if (!empty($searchData['shop_id']) && $searchData['shop_id'])
        {
            $shop_id = $searchData['shop_id']->getId();
            switch ($shop_id) {
                case Netshop::RAKUTEN:
                    // 楽天店舗登録なし
                    $sql = $sql .
                        '(npi.rakuten_shop_key is null OR npi.rakuten_shop_key = \'\')))';
                    break;

                case Netshop::YAHOO:
                    // Yahoo店舗登録なし
                    $sql= $sql.
                        '(npi.yahoo_shop_key is null OR npi.yahoo_shop_key = \'\')))';
                    break;

                case Netshop::YAHOO2:
                    // Yahoo2店舗登録なし
                    $sql= $sql.
                        '(npi.yahoo2_shop_key is null OR npi.yahoo2_shop_key = \'\')))';
                    break;

                case Netshop::AMAZON:
                    // Amazon店舗登録なし
                    $sql= $sql.
                        '(npi.amazon_shop_key is null OR npi.amazon_shop_key = \'\')))';
                    break;

                case Netshop::KAKAKU:
                    // 自社店舗登録なし
                    $sql= $sql.
                        '(npi.kakaku_shop_key is null OR npi.kakaku_shop_key = \'\')))';
            }

            // ネット連動以外商品
            $sql= $sql.'AND slpu.product_code NOT IN (SELECT nep.product_code from dtb_netshopAI_exception_product nep WHERE nep.shop_id = \''.$shop_id.'\')';
        }

        // state_simple_kubun
        if (isset($searchData['state_simple_kubun']) && StringUtil::isNotBlank($searchData['state_simple_kubun'])) {
            // 新品
            if ($searchData['state_simple_kubun']->getId() == '1') {
                $sql.= 'AND s.state = \'新品\'';
            }
            // 新品以外
            else if ($searchData['state_simple_kubun']->getId() == '2') {
                $sql.= 'AND s.state <> \'新品\'';
            }
        }
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    /**
     * 商品一覧表示.
     *
     * @param $searchData
     *
     * @return mixed[]
     */
    public function getSearchStockDataForCsv($searchData)
    {
        $pdo = $this->entityManager->getConnection()->getWrappedConnection();
        $sql = '
                 SELECT
                    slpu.product_code AS productCode,
                    p.name AS productName,
                    s.id AS stateId,
                    s.state AS stateName,
                    npi.id AS id,
                    npi.price_interlocking_level AS priceInterlockingLevel,
                    npi.stock_interlocking_kawaguchi_only AS stockInterlockingKawaguchiOnly,
                    npi.rakuten_shop_key AS rakutenShopKey,
                    npi.rakuten_product_code AS rakutenProductCode,
                    npi.rakuten_stock_interlocking AS rakutenStockInterlocking,
                    npi.rakuten_price_interlocking AS rakutenPriceInterlocking,
                    npi.rakuten_postage_free_flag AS rakutenPostageFreeFlag,
                    npi.rakuten_lower_selling_price_setting AS rakutenLowerSellingPriceSetting,
                    npi.rakuten_lower_selling_price AS rakutenLowerSellingPrice,
                    npi.rakuten_upper_selling_price AS rakutenUpperSellingPrice,
                    npi.rakuten_postage AS rakutenPostage,
                    npi.rakuten_commission_rate AS rakutenCommissionRate,
                    npi.rakuten_lower_profit_rate AS rakutenLowerProfitRate,
                    npi.rakuten_gross_profit AS rakutenGrossProfit,
                    npi.rakuten_adjustment_rule AS rakutenAdjustmentRule,
                    npi.rakuten_lowest_selling_price AS rakutenLowestSellingPrice,
                    npi.rakuten_keyword AS rakutenKeyword,
                    npi.rakuten_excluded_shop AS rakutenExcludedShop,
                    npi.rakuten_excluded_keyword AS rakutenExcludedKeyword,
                    npi.yahoo_shop_key AS yahooShopKey,
                    npi.yahoo_product_code AS yahooProductCode,
                    npi.yahoo_stock_interlocking AS yahooStockInterlocking,
                    npi.yahoo_price_interlocking AS yahooPriceInterlocking,
                    npi.yahoo_postage_free_flag AS yahooPostageFreeFlag,
                    npi.yahoo_lower_selling_price_setting AS yahooLowerSellingPriceSetting,
                    npi.yahoo_lower_selling_price AS yahooLowerSellingPrice,
                    npi.yahoo_upper_selling_price AS yahooUpperSellingPrice,
                    npi.yahoo_postage AS yahooPostage,
                    npi.yahoo_commission_rate AS yahooCommissionRate,
                    npi.yahoo_lower_profit_rate AS yahooLowerProfitRate,
                    npi.yahoo_gross_profit AS yahooGrossProfit,
                    npi.yahoo_adjustment_rule AS yahooAdjustmentRule,
                    npi.yahoo_lowest_selling_price AS yahooLowestSellingPrice,
                    npi.yahoo_keyword AS yahooKeyword,
                    npi.yahoo_excluded_shop AS yahooExcludedShop,
                    npi.yahoo_excluded_keyword AS yahooExcludedKeyword,
                    npi.amazon_shop_key AS amazonShopKey,
                    npi.amazon_asin_code AS amazonAsinCode,
                    npi.amazon_asin_code2 AS amazonAsinCode2,
                    npi.amazon_stock_interlocking AS amazonStockInterlocking,
                    npi.amazon_price_interlocking AS amazonPriceInterlocking,
                    npi.amazon_lower_selling_price_setting AS amazonLowerSellingPriceSetting,
                    npi.amazon_lower_selling_price AS amazonLowerSellingPrice,
                    npi.amazon_upper_selling_price AS amazonUpperSellingPrice,
                    npi.amazon_postage AS amazonPostage,
                    npi.amazon_commission_rate AS amazonCommissionRate,
                    npi.amazon_lower_profit_rate AS amazonLowerProfitRate,
                    npi.amazon_gross_profit AS amazonGrossProfit,
                    npi.amazon_adjustment_rule AS amazonAdjustmentRule,
                    npi.kakaku_shop_key AS kakakuShopKey,
                    npi.kakaku_product_id AS kakakuProductId,
                    npi.kakaku_stock_interlocking AS kakakuStockInterlocking,
                    npi.kakaku_price_interlocking AS kakakuPriceInterlocking,
                    npi.kakaku_lower_selling_price_setting AS kakakuLowerSellingPriceSetting,
                    npi.kakaku_average_unit_price_rate_flg AS kakakuAverageUnitPriceRateFlg,
                    npi.kakaku_lower_selling_price AS kakakuLowerSellingPrice,
                    npi.kakaku_upper_selling_price AS kakakuUpperSellingPrice,
                    npi.kakaku_postage AS kakakuPostage,
                    npi.kakaku_commission_rate AS kakakuCommissionRate,
                    npi.kakaku_lower_profit_rate AS kakakuLowerProfitRate,
                    npi.kakaku_gross_profit AS kakakuGrossProfit,
                    npi.kakaku_adjustment_rule AS kakakuAdjustmentRule,
                    npi.yahoo2_shop_key AS yahoo2ShopKey,
                    npi.yahoo2_product_code AS yahoo2ProductCode,
                    npi.yahoo2_stock_interlocking AS yahoo2StockInterlocking,
                    npi.yahoo2_price_interlocking AS yahoo2PriceInterlocking,
                    npi.yahoo2_postage_free_flag AS yahoo2PostageFreeFlag,
                    npi.yahoo2_lower_selling_price_setting AS yahoo2LowerSellingPriceSetting,
                    npi.yahoo2_lower_selling_price AS yahoo2LowerSellingPrice,
                    npi.yahoo2_upper_selling_price AS yahoo2UpperSellingPrice,
                    npi.yahoo2_postage AS yahoo2Postage,
                    npi.yahoo2_commission_rate AS yahoo2CommissionRate,
                    npi.yahoo2_lower_profit_rate AS yahoo2LowerProfitRate,
                    npi.yahoo2_gross_profit AS yahoo2GrossProfit,
                    npi.yahoo2_adjustment_rule AS yahoo2AdjustmentRule,
                    npi.yahoo2_lowest_selling_price AS yahoo2LowestSellingPrice,
                    npi.yahoo2_keyword AS yahoo2Keyword,
                    npi.yahoo2_excluded_shop AS yahoo2ExcludedShop,
                    npi.yahoo2_excluded_keyword AS yahoo2ExcludedKeyword,
                    slpu.stock_quantity AS stockQuantity,
                    slpu.provisional_shipment_quantity AS provisionalShipmentQuantity,
                    slpu.order_quantity AS orderQuantity,
                    slpu.remaining_stock_quantity AS remainingStockQuantity,
                    slpu.average_unit_price AS averageUnitPrice,
                    dc4.categoryname AS cp_name,
                    dc5.categoryname AS cpp_name1,
                    dc6.categoryname AS cpp_name2,
                    nr.avarege_price AS nr_avaregePrice,
                    nr.shop_price AS nr_shopPrice,
                    nr.gross_profit AS nr_grossProfit,
                    nr.profit_rate AS nr_profitRate,
                    nr.lower_selling_price AS nr_lowerSellingPrice,
                    nr.competitors_selling_price AS nr_competitorsSellingPrice,
                    nr.adjustment_rule AS nr_adjustmentRule,
                    nr.price_ranking AS nr_priceRanking,
                    nr.competitors_difference AS nr_competitorsDifference
                FROM dtb_stock_list_product_unit slpu
                INNER JOIN dtb_product_class pc 
                ON slpu.product_class_id = pc.id 
                INNER JOIN dtb_product p 
                ON pc.product_id = p.id 
                INNER JOIN mtb_state s 
                ON slpu.state_id = s.id 
                LEFT JOIN mtb_netshopAI_product_info npi
                ON slpu.product_code = npi.product_code
                AND slpu.state_id = npi.state_id
                INNER JOIN ( 
                    SELECT
                        dslpu.id AS id
                        , dcs.category_name AS categoryname
                        , dcs.hierarchy AS hierarchy
                        , dpcs.category_id AS category_id 
                    FROM
                        dtb_stock_list_product_unit dslpu 
                    INNER JOIN dtb_product_class pc 
                    ON dslpu.product_class_id = pc.id 
                    INNER JOIN dtb_product dps 
                    ON pc.product_id = dps.id 
                    INNER JOIN dtb_product_category dpcs 
                    ON dslpu.product_id = dpcs.product_id 
                    AND dpcs.category_sub_flag <> 1 
                    INNER JOIN dtb_category dcs 
                    ON dcs.id = dpcs.category_id
                    ) AS dc4 
                        ON dc4.id = slpu.id 
                        AND dc4.hierarchy = 1 
                LEFT JOIN ( 
                    SELECT
                        dslpu.id AS id
                        , dcs.category_name AS categoryname
                        , dcs.hierarchy AS hierarchy
                        , dpcs.category_id AS category_id 
                    FROM
                        dtb_stock_list_product_unit dslpu 
                    INNER JOIN dtb_product_class pc 
                    ON dslpu.product_class_id = pc.id 
                    INNER JOIN dtb_product dps 
                    ON pc.product_id = dps.id 
                    INNER JOIN dtb_product_category dpcs 
                    ON dslpu.product_id = dpcs.product_id 
                    AND dpcs.category_sub_flag <> 1 
                    INNER JOIN dtb_category dcs 
                    ON dcs.id = dpcs.category_id
                    ) AS dc5
                        ON dc5.id = slpu.id 
                        AND dc5.hierarchy = 2 
                LEFT JOIN ( 
                    SELECT
                        dslpu.id AS id
                        , dcs.category_name AS categoryname
                        , dcs.hierarchy AS hierarchy
                        , dpcs.category_id AS category_id 
                    FROM
                        dtb_stock_list_product_unit dslpu 
                    INNER JOIN dtb_product_class pc 
                    ON dslpu.product_class_id = pc.id 
                    INNER JOIN dtb_product dps 
                    ON pc.product_id = dps.id 
                    INNER JOIN dtb_product_category dpcs 
                    ON dslpu.product_id = dpcs.product_id 
                    AND dpcs.category_sub_flag <> 1 
                    INNER JOIN dtb_category dcs 
                    ON dcs.id = dpcs.category_id
                    ) AS dc6 
                        ON dc6.id = slpu.id 
                        AND dc6.hierarchy = 3 
                LEFT JOIN dtb_netshopAI_result nr
                ON nr.ai_product_id = npi.id
            ';

        if (!empty($searchData['shop_id']) && $searchData['shop_id'])
        {
            $shop_id = $searchData['shop_id']->getId();

            switch ($shop_id) {
                case Netshop::RAKUTEN:
                    // 楽天店舗登録なし
                    $sql = $sql .
                        ' AND nr.shop_id =\'1\'
                        WHERE slpu.stock_quantity > 0 AND (npi.id is null OR (npi.id is not null and 
                        (npi.rakuten_shop_key is null OR npi.rakuten_shop_key = \'\')))';
                    break;

                case Netshop::YAHOO:
                    // Yahoo店舗登録なし
                    $sql= $sql.
                        '  AND nr.shop_id =\'2\' 
                        WHERE slpu.stock_quantity > 0 AND (npi.id is null OR (npi.id is not null and 
                        (npi.yahoo_shop_key is null OR npi.yahoo_shop_key = \'\')))';
                    break;

                case Netshop::YAHOO2:
                    // Yahoo2店舗登録なし
                    $sql= $sql.
                        ' AND nr.shop_id =\'5\' 
                        WHERE slpu.stock_quantity > 0 AND (npi.id is null OR (npi.id is not null and 
                        (npi.yahoo2_shop_key is null OR npi.yahoo2_shop_key = \'\')))';
                    break;

                case Netshop::AMAZON:
                    // Amazon店舗登録なし
                    $sql= $sql.
                        ' AND nr.shop_id =\'3\'
                        WHERE slpu.stock_quantity > 0 AND (npi.id is null OR (npi.id is not null and 
                        (npi.amazon_shop_key is null OR npi.amazon_shop_key = \'\')))';
                    break;

                case Netshop::KAKAKU:
                    // 自社店舗登録なし
                    $sql= $sql.
                        ' AND nr.shop_id =\'4\' 
                        WHERE slpu.stock_quantity > 0 AND (npi.id is null OR (npi.id is not null and 
                        (npi.kakaku_shop_key is null OR npi.kakaku_shop_key = \'\')))';
            }

            // ネット連動以外商品
            $sql= $sql.'AND slpu.product_code NOT IN (SELECT nep.product_code from dtb_netshopAI_exception_product nep WHERE nep.shop_id = \''.$shop_id.'\')';
        }

        // state_simple_kubun
        if (isset($searchData['state_simple_kubun']) && StringUtil::isNotBlank($searchData['state_simple_kubun'])) {
            // 新品
            if ($searchData['state_simple_kubun']->getId() == '1') {
                $sql.= 'AND s.state = \'新品\'';
            }
            // 新品以外
            else if ($searchData['state_simple_kubun']->getId() == '2') {
                $sql.= 'AND s.state <> \'新品\'';
            }
        }
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }
}
