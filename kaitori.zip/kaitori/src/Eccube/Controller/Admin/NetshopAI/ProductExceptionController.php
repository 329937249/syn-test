<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\NetshopAI;

use Eccube\Common\Constant;
use Eccube\Controller\AbstractController;
use Eccube\Entity\Master\Netshop;
use Eccube\Entity\NetshopaiExceptionProduct;
use Eccube\Entity\Product;
use Eccube\Entity\ProductClass;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\EventListener\SecurityListener;
use Eccube\Form\Type\Admin\ProductExceptionType;
use Eccube\Repository\Master\NetshopRepository;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\NetshopaiExceptionProductRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Util\FormUtil;
use Eccube\Util\StringUtil;
use Knp\Component\Pager\Paginator;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\Routing\Annotation\Route;

/**
 *プログラム名 ： ProductExceptionController.php
 *概　　要     ： ネット連動未登録以外商品管理
 *作　　成     ： 2022/10/25 CNC
 */
class ProductExceptionController extends AbstractController
{
    /**
     * @var ProductClassRepository
     */
    protected $productClassRepository;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;

    /**
     * @var NetshopRepository
     */
    protected $netshopRepository;

    /**
     * @var NetshopaiExceptionProductRepository
     */
    protected $NetshopaiExceptionProductRepository;

    /**
     * ProductController constructor.
     *
     * @param ProductRepository $productRepository
     * @param ProductClassRepository $productClassRepository
     * @param PageMaxRepository $pageMaxRepository
     * @param NetshopRepository $netshopRepository
     * @param NetshopaiExceptionProductRepository $NetshopaiExceptionProductRepository
     */
    public function __construct(
        ProductRepository $productRepository,
        ProductClassRepository $productClassRepository,
        PageMaxRepository $pageMaxRepository,
        NetshopRepository $netshopRepository,
        NetshopaiExceptionProductRepository $NetshopaiExceptionProductRepository
    ) {
        $this->productRepository = $productRepository;
        $this->productClassRepository = $productClassRepository;
        $this->pageMaxRepository = $pageMaxRepository;
        $this->netshopRepository = $netshopRepository;
        $this->NetshopaiExceptionProductRepository = $NetshopaiExceptionProductRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/product_exception", name="admin_netshopAI_product_exception")
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/product_exception/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_netshopAI_product_exception_page")
     * @Template("@admin/NetshopAI/product_exception.twig")
     */
    public function index(Request $request, $page_no = null, Paginator $paginator)
    {
        $builder = $this->formFactory
            ->createBuilder(ProductExceptionType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_EXCEPTION_INDEX_INITIALIZE, $event);

        $searchForm = $builder->getForm();

        /**
         * ページの表示件数は, 以下の順に優先される.
         * - リクエストパラメータ
         * - セッション
         * - デフォルト値
         * また, セッションに保存する際は mtb_page_maxと照合し, 一致した場合のみ保存する.
         **/
        $page_count = $this->session->get('eccube.admin.netshopAI.search.exception.page_count',
            $this->eccubeConfig->get('eccube_mltext_len'));

        $page_count_param = (int) $request->get('page_count');
        $pageMaxis = $this->pageMaxRepository->findAll();

        if ($page_count_param) {
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.admin.netshopAI.search.exception.page_count', $page_count);
                    break;
                }
            }
        }

        $page_no_bk = $page_no;
        if ('POST' === $request->getMethod()) {
            $searchForm->handleRequest($request);

            if ($searchForm->isValid()) {
                /**
                 * 検索が実行された場合は, セッションに検索条件を保存する.
                 * ページ番号は最初のページ番号に初期化する.
                 */
                $page_no = 1;
                $searchData = $searchForm->getData();

                // 検索条件, ページ番号をセッションに保持.
                $this->session->set('eccube.admin.netshopAI.search.exception', FormUtil::getViewData($searchForm));
                $this->session->set('eccube.admin.netshopAI.search.exception.page_no', $page_no);
            } else {
                // 検索エラーの際は, 詳細検索枠を開いてエラー表示する.
                return [
                    'searchForm' => $searchForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $page_count,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.admin.netshopAI.search.exception.page_no', (int) $page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.admin.netshopAI.search.exception.page_no', 1);
                }
                $viewData = $this->session->get('eccube.admin.netshopAI.search.exception', []);
                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
            } else {
                /**
                 * 初期表示の場合.
                 */
                $page_no = 1;

                // submit default value
                $viewData = FormUtil::getViewData($searchForm);

                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);

                // セッション中の検索条件, ページ番号を初期化.
                $this->session->set('eccube.admin.netshopAI.exception.search', $viewData);
                $this->session->set('eccube.admin.netshopAI.search.exception.page_no', $page_no);
            }
        }

        $qb = '';
        $all_orders = [];
        if ('POST' === $request->getMethod() || null !== $page_no_bk){
            $qb = $this->NetshopaiExceptionProductRepository->getQueryBuilderBySearchData($searchData);
            $all_orders = $qb->getQuery()->getResult();
        }

        $sort_orders = $this->sortOrder($all_orders, $searchData);

        $event = new EventArgs(
            [
                'qb' => $qb,
                'searchData' => $searchData,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_EXCEPTION_INDEX_SEARCH, $event);

        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $page_count
        );

        return [
            'searchForm' => $searchForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'has_errors' => false,
            'request' => $request,
        ];
    }

    private function sortOrder($orders, $searchData) {
        if ($searchData['sort_by']) {
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case 'ショップ名':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == "降順") {
                            return $a["shop"]["id"] > $b["shop"]["id"] ? -1 : 1;
                        }
                        return $a["shop"]["id"] < $b["shop"]["id"] ? -1 : 1;
                    });
                    break;
                case '商品コード':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if ($order_by == "降順") {
                            return $a["productCode"] > $b["productCode"] ? -1 : 1;
                        }
                        return $a["productCode"] < $b["productCode"] ? -1 : 1;
                    });
                    break;
            }
        }
        return $orders;
    }

   /**
    * @Route("/%eccube_admin_route%/netshopAI_serial_action/search/product", name="admin_netshopAI_search_product_name")
    * @param Request $request リクエスト
    * @return \Symfony\Component\HttpFoundation\JsonResponse
    */
    public function searchProduct(Request $request)
    {
        $product_code = $request->get('code');

        log_info('Admin netshopAI searchProduct', [$product_code]);

        // 商品取得
        $array_entity_product = $product_code
            ? $this->productRepository->findProductsWithProductCode($product_code)
            : [];

        $event = new EventArgs(
            [
                'ProductCode' => $product_code,
                'Product' => $array_entity_product,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_EXCEPTION_SEARCH_PRODUCT_INITIALIZE, $event);

        if (!empty($array_entity_product) && !empty($array_entity_product[0])) {
            /** @var Product $entity_product */
            $entity_product = $array_entity_product[0][0];
            $data = [
                'target_product_id' => $entity_product->getId(),
                'target_product_name' => $entity_product->getName(),
                'target_product_class_id' => $entity_product->getProductClasses()[0]->getId(),
            ];
        } else {
            log_debug('search product by code not found.');
            return $this->json([], 404);
        }

        $event = new EventArgs(
            [
                'ProductCode' => $product_code,
                'Product' => $entity_product,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_EXCEPTION_SEARCH_PRODUCT_COMPLETE, $event);

        return $this->json($data);
    }

    /**
//     *
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/exception/new", name="admin_netshopAI_exception_new", methods={"POST"})
     *
     * @param Request $request Request
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function exceptionNew(Request $request)
    {
        if ($request->isXmlHttpRequest() && $this->isTokenValid()){
            $shop_id = $request->get('shop_id');
            $product_id = $request->get('product_id');
            $product_name = $request->get('product_name');
            $product_class_id = $request->get('product_class_id');
            $product_code = $request->get('product_code');

            /** @var $NetshopaiExceptionProduct NetshopaiExceptionProduct */
            $NetshopaiExceptionProduct = $this->NetshopaiExceptionProductRepository->findBy([
                'Shop' => $shop_id,
                'productCode' => $product_code,
            ]);

            if (empty($NetshopaiExceptionProduct[0])) {
                $EntityNetshopaiExceptionProduct = new NetshopaiExceptionProduct();

                /** @var $netShop Netshop */
                $netShop = $this->netshopRepository->find($shop_id);
                /** @var $product Product */
                $product = $this->productRepository->find($product_id);
                /** @var $productClass ProductClass */
                $productClass = $this->productClassRepository->find($product_class_id);

                $EntityNetshopaiExceptionProduct->setShop($netShop);
                $EntityNetshopaiExceptionProduct->setProduct($product);
                $EntityNetshopaiExceptionProduct->setProductClass($productClass);
                $EntityNetshopaiExceptionProduct->setProductName($product_name);
                $EntityNetshopaiExceptionProduct->setProductCode($product_code);

                $EntityNetshopaiExceptionProduct->setCreateUserName($this->getUser());
                $EntityNetshopaiExceptionProduct->setUpdateUserName($this->getUser());

                $this->entityManager->persist($EntityNetshopaiExceptionProduct);
                $this->entityManager->flush();

                $data = ['error_flg' => '0',];
            } else {
                $data = [
                    'error_flg' => '1',
                    'error_message' => 'この商品はネット連動以外商品に存在しません。',
                ];
            }
        }
        return $this->json($data);
    }

    /**
     * @Route("/%eccube_admin_route%/netshopAI_serial_action/exception/{id}/delete", requirements={"id" = "\d+"}, name="admin_netshopAI_exception_delete", methods={"DELETE"})
     */
    public function delete(Request $request, int $id = null)
    {
        $this->isTokenValid();

        if (!is_null($id)) {
            /** @var NetshopaiExceptionProduct $NetshopaiExceptionProduct */
            $NetshopaiExceptionProduct = $this->NetshopaiExceptionProductRepository->find($id);

            if (!$NetshopaiExceptionProduct) {
                $message = trans('admin.common.delete_error_already_deleted');

                $this->addError($message, 'admin');
            } else {
                log_info('ネット連動以外商品削除開始', [$id]);

                $name = $NetshopaiExceptionProduct->getProductName();

                try {
                    $this->NetshopaiExceptionProductRepository->delete($NetshopaiExceptionProduct);
                    $this->entityManager->flush();

                    $event = new EventArgs(
                        [
                            'NetshopaiExceptionProduct' => $NetshopaiExceptionProduct,
                        ],
                        $request
                    );
                    $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NETSHOPAI_PRODUCT_EXCEPTION_DELETE_COMPLETE, $event);

                    $this->addSuccess('admin.common.delete_complete', 'admin');

                    log_info('ネット連動以外商品削除完了', [$id]);

                } catch (\Exception $e) {
                    log_info('ネット連動以外商品削除エラー', [$id, $e]);

                    $message = trans('admin.common.delete_error.foreign_key', ['%name%' => $name]);
                    $this->addError($message, 'admin');
                }
            }
        } else {
            log_info('ネット連動以外商品削除エラー', [$id]);

            $message = trans('admin.common.delete_error');
            $this->addError($message, 'admin');
        }

        return $this->redirect($this->generateUrl('admin_netshopAI_product_exception').'?resume='.Constant::ENABLED);
    }

}
