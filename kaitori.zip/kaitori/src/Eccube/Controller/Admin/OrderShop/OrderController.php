<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Admin\OrderShop;

use Eccube\Common\Constant;
use Eccube\Controller\AbstractController;
use Eccube\Entity\ExportCsvRow;
use Eccube\Entity\LogControllable;
use Eccube\Entity\Master\CsvType;
use Eccube\Entity\Master\KaitoriType;
use Eccube\Entity\Master\OrderStatus;
use Eccube\Entity\Master\OtherItemCodeChange;
use Eccube\Entity\Master\PayingStatus;
use Eccube\Entity\OrderPdf;
use Eccube\Entity\PayeeVoucherDetail;
use Eccube\Entity\PayeeVoucherDetailHistory;
use Eccube\Entity\PayeeVoucherHeaderHistory;
use Eccube\Entity\Place;
use Eccube\Entity\ProductClass;
use Eccube\Entity\Shipping;
use Eccube\Entity\State;
use Eccube\Entity\StateChange;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Event\OrderOpehist;
use Eccube\Event\PayeeVoucherHeader;
use Eccube\Form\Type\Admin\OrderPdfType;
use Eccube\Form\Type\Admin\SearchOrderType;
use Eccube\Repository\CustomerRepository;
use Eccube\Repository\Master\OrderStatusRepository;
use Eccube\Repository\Master\OtherItemCodeChangeRepository;
use Eccube\Repository\Master\PageMaxRepository;
use Eccube\Repository\Master\ProductStatusRepository;
use Eccube\Repository\Master\SexRepository;
use Eccube\Repository\OrderItemRepository;
use Eccube\Repository\OrderOpehistRepository;
use Eccube\Repository\OrderPdfRepository;
use Eccube\Repository\OrderRepository;
use Eccube\Repository\PayeeMstRepository;
use Eccube\Repository\PayeeVoucherDetailHistoryRepository;
use Eccube\Repository\PayeeVoucherHeaderHistoryRepository;
use Eccube\Repository\PayeeVoucherHeaderRepository;
use Eccube\Repository\PaymentRepository;
use Eccube\Repository\PlaceRepository;
use Eccube\Repository\PriceUpdateRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\ProductStockRepository;
use Eccube\Repository\ShopInfoRepository;
use Eccube\Repository\StateChangeRepository;
use Eccube\Repository\StateRepository;
use Eccube\Repository\StockListProductUnitRepository;
use Eccube\Repository\StockListStorehouseUnitRepository;
use Eccube\Service\CsvExportService;
use Eccube\Service\MailService;
use Eccube\Service\OrderHelper;
use Eccube\Service\OrderPdfService;
use Eccube\Service\OrderStateMachine;
use Eccube\Service\PurchaseFlow\PurchaseFlow;
use Eccube\Util\FormUtil;
use Knp\Component\Pager\PaginatorInterface;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Form\FormBuilder;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Validator\ValidatorInterface;

class OrderController extends AbstractController
{
    /**
     * @var PurchaseFlow
     */
    protected $purchaseFlow;

    /**
     * @var CsvExportService
     */
    protected $csvExportService;

    /**
     * @var CustomerRepository
     */
    protected $customerRepository;
    
    /**
     * @var OrderItemRepository
     */
    protected $orderItemRepository;
    
    /**
     * @var ProductClassRepository
     */
    protected $productClassRepository;

    /**
     * @var PaymentRepository
     */
    protected $paymentRepository;

    /**
     * @var SexRepository
     */
    protected $sexRepository;

    /**
     * @var OrderStatusRepository
     */
    protected $orderStatusRepository;

    /**
     * @var PageMaxRepository
     */
    protected $pageMaxRepository;

    /**
     * @var ProductStatusRepository
     */
    protected $productStatusRepository;

    /**
     * @var OrderRepository
     */
    protected $orderRepository;
    
    /**
     * @var ShopInfoRepository
     */
    protected $shopInfoRepository;

    /** @var OrderPdfRepository */
    protected $orderPdfRepository;
    
    /** @var OrderOpehistRepository */
    protected $orderOpehistRepository;

    /**
     * @var ProductStockRepository
     */
    protected $productStockRepository;

    /** @var OrderPdfService */
    protected $orderPdfService;

    /**
     * @var ValidatorInterface
     */
    protected $validator;

    /**
     * @var OrderStateMachine
     */
    protected $orderStateMachine;

    /**
     * @var MailService
     */
    protected $mailService;

    /**
     * @var OrderHelper
     */
    private $orderHelper;

    // INS-START CNC 2021/07/23
    /**
     * @var PayeeMstRepository
     */
    protected $payeeMstRepository;

    /** @var PlaceRepository */
    protected $placeRepository;
    /**
     * @var PayeeVoucherHeaderRepository
     */
    protected $payeeVoucherHeaderRepository;

    /**
     * @var PayeeVoucherHeaderHistoryRepository
     */
    protected $payeeVoucherHeaderHistoryRepository;

    /**
     * @var StateChangeRepository
     */
    protected $stateChangeRepository;
    /**
     * @var StateRepository
     */
    protected $stateRepository;

    /**
     * @var StockListStorehouseUnitRepository
     */
    protected $stockListStorehouseUnitRepository;

    /**
     * @var StockListProductUnitRepository
     */
    protected $stockListProductUnitRepository;

    /**
     * @var OtherItemCodeChangeRepository
     */
    protected $otherItemCodeChangeRepository;
    // INS-END CNC 2021/07/23

    // 2021/12/10 CNC ADD START
    /**
     * @var PayeeVoucherDetailHistoryRepository
     */
    protected $payeeVoucherDetailHistoryRepository;
    // 2021/12/10 CNC ADD END

    // INS-START CNC 2022/05/20
    /**
     * @var PriceUpdateRepository
     */
    protected $priceUpdateRepository;
    // INS-END CNC 2022/05/20

    // INS-START CNC 2022/05/24
    /**
     * @var ProductRepository
     */
    protected $productRepository;
    // INS-END CNC 2022/05/24

    /**
     * OrderController constructor.
     *
     * @param PurchaseFlow $orderPurchaseFlow
     * @param CsvExportService $csvExportService
     * @param CustomerRepository $customerRepository
     * @param PaymentRepository $paymentRepository 
     * @param OrderItemRepository $orderItemRepository 
     * @param SexRepository $sexRepository
     * @param OrderStatusRepository $orderStatusRepository
     * @param PageMaxRepository $pageMaxRepository
     * @param ProductStatusRepository $productStatusRepository
     * @param ProductStockRepository $productStockRepository
     * @param OrderRepository $orderRepository
     * @param ProductClassRepository $productClassRepository
     * @param ShopInfoRepository $shopInfoRepository  
     * @param OrderPdfRepository $orderPdfRepository
     * @param OrderOpehistRepository $orderOpehistRepository
     * @param ValidatorInterface $validator
     * @param OrderStateMachine $orderStateMachine ;
     * @param OrderHelper $orderHelper
     * @param PlaceRepository $placeRepository
     * @param PayeeMstRepository $payeeMstRepository
     * @param PayeeVoucherHeaderRepository $payeeVoucherHeaderRepository
     * @param PayeeVoucherHeaderHistoryRepository $payeeVoucherHeaderHistoryRepository
     * @param StateChangeRepository $stateChangeRepository
     * @param StateRepository $stateRepository
     * @param StockListStorehouseUnitRepository $stockListStorehouseUnitRepository
     * @param StockListProductUnitRepository $stockListProductUnitRepository
     * @param OtherItemCodeChangeRepository $otherItemCodeChangeRepository
     * @param PayeeVoucherDetailHistoryRepository $payeeVoucherDetailHistoryRepository
     */
    public function __construct(
        PurchaseFlow $orderPurchaseFlow,
        CsvExportService $csvExportService,
        CustomerRepository $customerRepository,
        PaymentRepository $paymentRepository,
        SexRepository $sexRepository,
        OrderStatusRepository $orderStatusRepository,
        PageMaxRepository $pageMaxRepository,
        ProductStatusRepository $productStatusRepository,
        ProductStockRepository $productStockRepository,
        OrderRepository $orderRepository,
        OrderItemRepository $orderItemRepository,
        ShopInfoRepository $shopInfoRepository,
        OrderPdfRepository $orderPdfRepository,
        ProductClassRepository $productClassRepository,
        OrderOpehistRepository $orderOpehistRepository,
        ValidatorInterface $validator,
        OrderStateMachine $orderStateMachine,
        MailService $mailService,
        // BFR-START CNC 2021/07/23
        //OrderHelper $orderHelper
        // BFR-START CNC 2021/07/23
        // AFT-START CNC 2021/07/23
        OrderHelper $orderHelper,
        PlaceRepository $placeRepository,
        PayeeMstRepository $payeeMstRepository,
        PayeeVoucherHeaderRepository $payeeVoucherHeaderRepository,
        PayeeVoucherHeaderHistoryRepository $payeeVoucherHeaderHistoryRepository,
        StateChangeRepository $stateChangeRepository,
        StateRepository $stateRepository,
        StockListStorehouseUnitRepository $stockListStorehouseUnitRepository,
        StockListProductUnitRepository $stockListProductUnitRepository,
        OtherItemCodeChangeRepository $otherItemCodeChangeRepository,
        // AFT-END CNC 2021/07/23
        // 2021/12/21 CNC ADD START
        PayeeVoucherDetailHistoryRepository $payeeVoucherDetailHistoryRepository
        // 2021/12/21 CNC ADD END
        // INS-START CNC 2022/05/20
        ,PriceUpdateRepository $priceUpdateRepository
        // INS-END CNC 2022/05/20
        // INS-START CNC 2022/05/24
        , ProductRepository $productRepository
        // INS-END CNC 2022/05/24
    ) {
        $this->purchaseFlow = $orderPurchaseFlow;
        $this->csvExportService = $csvExportService;
        $this->customerRepository = $customerRepository;
        $this->paymentRepository = $paymentRepository;
        $this->sexRepository = $sexRepository;
        $this->orderStatusRepository = $orderStatusRepository;
        $this->pageMaxRepository = $pageMaxRepository;
        $this->productStatusRepository = $productStatusRepository;
        $this->productStockRepository = $productStockRepository;
        $this->orderRepository = $orderRepository;
        $this->orderItemRepository = $orderItemRepository;
        $this->shopInfoRepository = $shopInfoRepository;
        $this->orderPdfRepository = $orderPdfRepository;
        $this->orderOpehistRepository = $orderOpehistRepository;
        $this->productClassRepository = $productClassRepository; 
        $this->validator = $validator;
        $this->orderStateMachine = $orderStateMachine;
        $this->mailService = $mailService;
        $this->orderHelper = $orderHelper;
        // INS-START CNC 2021/07/23
        $this->placeRepository = $placeRepository;
        $this->payeeMstRepository = $payeeMstRepository;
        $this->payeeVoucherHeaderRepository = $payeeVoucherHeaderRepository;
        $this->payeeVoucherHeaderHistoryRepository = $payeeVoucherHeaderHistoryRepository;
        $this->stateChangeRepository = $stateChangeRepository;
        $this->stateRepository = $stateRepository;
        $this->stockListStorehouseUnitRepository = $stockListStorehouseUnitRepository;
        $this->stockListProductUnitRepository = $stockListProductUnitRepository;
        $this->otherItemCodeChangeRepository = $otherItemCodeChangeRepository;
        // INS-END CNC 2021/07/23
        // 2021/12/21 CNC ADD START
        $this->payeeVoucherDetailHistoryRepository = $payeeVoucherDetailHistoryRepository;
        // 2021/12/21 CNC ADD END
        // INS-START CNC 2022/05/20
        $this->priceUpdateRepository = $priceUpdateRepository;
        // INS-END CNC 2022/05/20
        // INS-START CNC 2022/05/24
        $this->productRepository = $productRepository;
        // INS-END CNC 2022/05/24
    }

    /**
     * 受注一覧画面.
     *
     * - 検索条件, ページ番号, 表示件数はセッションに保持されます.
     * - クエリパラメータでresume=1が指定された場合、検索条件, ページ番号, 表示件数をセッションから復旧します.
     * - 各データの, セッションに保持するアクションは以下の通りです.
     *   - 検索ボタン押下時
     *      - 検索条件をセッションに保存します
     *      - ページ番号は1で初期化し、セッションに保存します。
     *   - 表示件数変更時
     *      - クエリパラメータpage_countをセッションに保存します。
     *      - ただし, mtb_page_maxと一致しない場合, eccube_default_page_countが保存されます.
     *   - ページング時
     *      - URLパラメータpage_noをセッションに保存します.
     *   - 初期表示
     *      - 検索条件は空配列, ページ番号は1で初期化し, セッションに保存します.
     *
     * @Route("/%eccube_admin_route%/order/shop", name="admin_order_shop")
     * @Route("/%eccube_admin_route%/order/shop/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_order_shop_page")
     * @Template("@admin/OrderShop/index.twig")
     */
    public function index(Request $request, $page_no = null, PaginatorInterface $paginator)
    {
        $this->entityManager->getFilters()->enable('order_status_processing_hidden'); 
        $builder = $this->formFactory->createBuilder(SearchOrderType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ORDER_INDEX_INITIALIZE, $event);

        $searchForm = $builder->getForm();

        /**
         * ページの表示件数は, 以下の順に優先される.
         * - リクエストパラメータ
         * - セッション
         * - デフォルト値
         * また, セッションに保存する際は mtb_page_maxと照合し, 一致した場合のみ保存する.
         **/
        $page_count = $this->session->get('eccube.admin.order.shop.search.page_count',
            $this->eccubeConfig->get('eccube_default_page_count'));

        $page_count_param = (int) $request->get('page_count');
        $pageMaxis = $this->pageMaxRepository->findAll();

        if ($page_count_param) {
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.admin.order.shop.search.page_count', $page_count);
                    break;
                }
            }
        }

        if ('POST' === $request->getMethod()) {
            $searchForm->handleRequest($request);

            if ($searchForm->isValid()) {
                /**
                 * 検索が実行された場合は, セッションに検索条件を保存する.
                 * ページ番号は最初のページ番号に初期化する.
                 */
                $page_no = 1;
                $searchData = $searchForm->getData();

                // 検索条件, ページ番号をセッションに保持.
                $this->session->set('eccube.admin.order.shop.search', FormUtil::getViewData($searchForm));
                $this->session->set('eccube.admin.order.shop.search.page_no', $page_no);
            } else {
                // 検索エラーの際は, 詳細検索枠を開いてエラー表示する.
                return [
                    'searchForm' => $searchForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $page_count,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.admin.order.shop.search.page_no', (int) $page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.admin.order.shop.search.page_no', 1);
                }
                $viewData = $this->session->get('eccube.admin.order.shop.search', []);
                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
            } else {
                /**
                 * 初期表示の場合.
                 */
                $page_no = 1;
                $viewData = [];

                if ($statusId = (int) $request->get('order_status_id')) {
                    $viewData = ['status' => $statusId];
                }

                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
               
                // セッション中の検索条件, ページ番号を初期化.
                $this->session->set('eccube.admin.order.shop.search', $viewData);
                $this->session->set('eccube.admin.order.shop.search.page_no', $page_no);
            }
        }

        // 店頭買取
        $KaitoriType = $this->entityManager
                     ->find(KaitoriType::class, KaitoriType::KAITORI_TYPE_SHOP);
        $searchData['KaitoriType'] = $KaitoriType;      
        $this->session->set('eccube.admin.order.kaitori.type', $KaitoriType); 

        // 来店場所
        if (!empty($searchData['shop_info']) && $searchData['shop_info']) {
              $shopId = $this->shopInfoRepository->getShopId($searchData['shop_info']);
              $searchData['shop_info'] = $shopId;   
        }
        $sort_orders = [];
        if ('POST' === $request->getMethod() || $page_no > 1){
            $qb = $this->orderRepository->getQueryBuilderBySearchDataForAdmin($searchData);
            $all_orders = $qb->getQuery()->getResult();
            $sort_orders = $this->sortOrder($all_orders, $searchData);
        }
        
        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $page_count
        );

        return [
            'searchForm' => $searchForm->createView(),
            'pending' => OrderStatus :: PROCESSING,
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'order_status_new' => OrderStatus :: NEW,
            'order_status_wait' => OrderStatus :: PENDING,
            'order_status_paid' => OrderStatus :: PAID,
            'order_status_cancel' => OrderStatus :: CANCEL,
            'order_status_return' => OrderStatus :: RETURNED,
            'order_status_customer_wait' => OrderStatus :: WAIT,
            'has_errors' => false,
            'OrderStatuses' => $this->orderStatusRepository->findBy([], ['sort_no' => 'ASC']),
        ];
    }
    
    /**
     * 新規受付画面.
     *
     * @Route("/%eccube_admin_route%/order/shop/status/new", name="admin_order_shop_status_new")
     * @Route("/%eccube_admin_route%/order/shop/status/new/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_order_shop_status_new_page")
     * @Route("/%eccube_admin_route%/order/shop/status/new/product/{productId}", requirements={"productId" = "\d+"}, name="admin_order_shop_status_new_product")
     * @Template("@admin/OrderShop/new_order.twig")
     */
    public function newOrder(Request $request, $page_no = null, $productId = null, PaginatorInterface $paginator)
    {
    
        $builder = $this->formFactory->createBuilder(SearchOrderType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NEW_ORDER_INDEX_INITIALIZE, $event);

        $searchForm = $builder->getForm();

        /**
         * ページの表示件数は, 以下の順に優先される.
         * - リクエストパラメータ
         * - セッション
         * - デフォルト値
         * また, セッションに保存する際は mtb_page_maxと照合し, 一致した場合のみ保存する.
         **/
        $page_count = $this->session->get('eccube.admin.order.shop.new.order.search.page_count',
            $this->eccubeConfig->get('eccube_default_page_count'));

        $page_count_param = (int) $request->get('page_count');
        $pageMaxis = $this->pageMaxRepository->findAll();

        if ($page_count_param) {
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.admin.order.shop.new.order.search.page_count', $page_count);
                    break;
                }
            }
        }

        if ('POST' === $request->getMethod()) {
            $searchForm->handleRequest($request);

            if ($searchForm->isValid()) {
                /**
                 * 検索が実行された場合は, セッションに検索条件を保存する.
                 * ページ番号は最初のページ番号に初期化する.
                 */
                $page_no = 1;
                $searchData = $searchForm->getData();

                // 検索条件, ページ番号をセッションに保持.
                $this->session->set('eccube.admin.order.shop.new.order.search', FormUtil::getViewData($searchForm));
                $this->session->set('eccube.admin.order.shop.new.order.search.page_no', $page_no);
            } else {
                // 検索エラーの際は, 詳細検索枠を開いてエラー表示する.
                return [
                    'searchForm' => $searchForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $page_count,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.admin.order.shop.new.order.search.page_no', (int) $page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.admin.order.shop.new.order.search.page_no', 1);
                }
                $viewData = $this->session->get('eccube.admin.order.shop.new.order.search', []);
                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
            } else {
                // INS-START CNC 2022/05/24
                if ($productId != null) {
                    log_info("home");
                    /**
                     * ホーム画面から遷移した場合
                     */
                    $page_no = 1;
                    $viewData = [];

                    $product = $this->productRepository->find($productId);

                    $productCode = $product->getProductClasses()[0]['code'];

                    $viewData['buy_product_code'] = $productCode;

                    if ($statusId = (int)$request->get('order_status_id')) {
                        $viewData = ['status' => $statusId];
                    }

                    $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
                    $searchData['buy_product_code'] = $productCode;

                    // セッション中の検索条件, ページ番号を初期化.
                    $this->session->set('eccube.admin.order.post.new.order.search', $viewData);
                    $this->session->set('eccube.admin.order.post.new.order.search.page_no', $page_no);
                    // INS-END CNC 2022/05/24
                } else {
                    /**
                     * 初期表示の場合.
                     */
                    $page_no = 1;
                    $viewData = [];

                    if ($statusId = (int)$request->get('order_status_id')) {
                        $viewData = ['status' => $statusId];
                    }

                    $searchData = FormUtil::submitAndGetData($searchForm, $viewData);

                    // セッション中の検索条件, ページ番号を初期化.
                    $this->session->set('eccube.admin.order.shop.new.order.search', $viewData);
                    $this->session->set('eccube.admin.order.shop.new.order.search.page_no', $page_no);
                }
            }
        }

        // 店頭買取
        $KaitoriType = $this->entityManager
                     ->find(KaitoriType::class, KaitoriType::KAITORI_TYPE_SHOP);
        $searchData['KaitoriType'] = $KaitoriType;      
        
        $qb = $this->orderRepository->getQueryBuilderBySearchDataForNew($searchData);
        $all_orders = $qb->getQuery()->getResult();

        // INS-START CNC 2022/05/20
        // 価格更新フラグ追加
        foreach ($all_orders as &$order) {
            $price_update = $this->priceUpdateRepository->findOneBy(['orderNo' => $order->getOrderNo()]);
            if ($price_update) {
                if ($price_update->getOrderUpdateDate() == $order->getUpdateDate()) {
                    $order->setPriceUpdateFlg(1);
                } else {
                    $order->setPriceUpdateFlg(0);
                }
            } else {
                $order->setPriceUpdateFlg(0);
            }
        }
        // INS-END CNC 2022/05/20

        $sort_orders = $this->sortOrder($all_orders, $searchData);

        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $page_count
        );

        return [
            'searchForm' => $searchForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'has_errors' => false,
            'OrderStatuses' => $this->orderStatusRepository->findBy([], ['sort_no' => 'ASC']),
        ];
    }
    
    /**
     * 顧客確認待ち画面.
     *
     * @Route("/%eccube_admin_route%/order/shop/status/approval", name="admin_order_shop_status_approval")
     * @Route("/%eccube_admin_route%/order/shop/status/approval/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_order_shop_status_approval_page")
     * @Template("@admin/OrderShop/approval_order.twig")
     */
    public function approvalOrder(Request $request, $page_no = null, PaginatorInterface $paginator)
    {
    
        $builder = $this->formFactory->createBuilder(SearchOrderType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NEW_ORDER_INDEX_INITIALIZE, $event);

        $searchForm = $builder->getForm();
        /**
         * ページの表示件数は, 以下の順に優先される.
         * - リクエストパラメータ
         * - セッション
         * - デフォルト値
         * また, セッションに保存する際は mtb_page_maxと照合し, 一致した場合のみ保存する.
         **/
        $page_count = $this->session->get('eccube.admin.order.shop.approval.order.search.page_count',
            $this->eccubeConfig->get('eccube_default_page_count'));

        $page_count_param = (int) $request->get('page_count');
        $pageMaxis = $this->pageMaxRepository->findAll();

        if ($page_count_param) {
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.admin.order.shop.approval.order.search.page_count', $page_count);
                    break;
                }
            }
        }

        if ('POST' === $request->getMethod()) {
            $searchForm->handleRequest($request);

            if ($searchForm->isValid()) {
                /**
                 * 検索が実行された場合は, セッションに検索条件を保存する.
                 * ページ番号は最初のページ番号に初期化する.
                 */
                $page_no = 1;
                $searchData = $searchForm->getData();

                // 検索条件, ページ番号をセッションに保持.
                $this->session->set('eccube.admin.order.shop.approval.order.search', FormUtil::getViewData($searchForm));
                $this->session->set('eccube.admin.order.shop.approval.order.search.page_no', $page_no);
            } else {
                // 検索エラーの際は, 詳細検索枠を開いてエラー表示する.
                return [
                    'searchForm' => $searchForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $page_count,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.admin.order.shop.approval.order.search.page_no', (int) $page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.admin.order.shop.approval.order.search.page_no', 1);
                }
                $viewData = $this->session->get('eccube.admin.order.shop.approval.order.search', []);
                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
            } else {
                /**
                 * 初期表示の場合.
                 */
                $page_no = 1;
                $viewData = [];

                if ($statusId = (int) $request->get('order_status_id')) {
                    $viewData = ['status' => $statusId];
                }

                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);

                // セッション中の検索条件, ページ番号を初期化.
                $this->session->set('eccube.admin.order.shop.approval.order.search', $viewData);
                $this->session->set('eccube.admin.order.shop.approval.order.search.page_no', $page_no);
            }
        }

        // 店頭買取
        $KaitoriType = $this->entityManager->find(KaitoriType::class, KaitoriType::KAITORI_TYPE_SHOP);
        $searchData['KaitoriType'] = $KaitoriType;      
        
        $qb = $this->orderRepository->getQueryBuilderBySearchDataForApproval($searchData);
        $all_orders = $qb->getQuery()->getResult();

        // INS-START CNC 2022/05/20
        // 価格更新フラグ追加
        foreach ($all_orders as &$order) {
            $price_update = $this->priceUpdateRepository->findOneBy(['orderNo' => $order->getOrderNo()]);
            if ($price_update) {
                if ($price_update->getOrderUpdateDate() == $order->getUpdateDate()) {
                    $order->setPriceUpdateFlg(1);
                } else {
                    $order->setPriceUpdateFlg(0);
                }
            } else {
                $order->setPriceUpdateFlg(0);
            }
        }
        // INS-END CNC 2022/05/20

        $sort_orders = $this->sortOrder($all_orders, $searchData);

        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $page_count
        );

        return [
            'searchForm' => $searchForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'has_errors' => false,
            'new' => OrderStatus :: NEW,
            'wait' => OrderStatus :: WAIT,
            'stock' => OrderStatus :: RETURNED,
            'cancel' => OrderStatus :: CANCEL,
            'OrderStatuses' => $this->orderStatusRepository->findBy([], ['sort_no' => 'ASC']),
        ];
    }
    
    /**
     * 入荷待ち画面.
     *
     * @Route("/%eccube_admin_route%/order/shop/status/stock", name="admin_order_shop_status_stock")
     * @Route("/%eccube_admin_route%/order/shop/status/stock/page/{page_no}", requirements={"page_no" = "\d+"}, name="admin_order_shop_status_stock_page")
     * @Route("/%eccube_admin_route%/order/shop/status/stock/product/{productId}", requirements={"productId" = "\d+"}, name="admin_order_shop_status_stock_product")
     * @Template("@admin/OrderShop/stock_order.twig")
     */
    public function stockOrder(Request $request, $page_no = null, $productId = null, PaginatorInterface $paginator)
    {
    
        $builder = $this->formFactory->createBuilder(SearchOrderType::class);

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_NEW_ORDER_INDEX_INITIALIZE, $event);

        $searchForm = $builder->getForm();

        /**
         * ページの表示件数は, 以下の順に優先される.
         * - リクエストパラメータ
         * - セッション
         * - デフォルト値
         * また, セッションに保存する際は mtb_page_maxと照合し, 一致した場合のみ保存する.
         **/
        $page_count = $this->session->get('eccube.admin.order.shop.stock.order.search.page_count',
            $this->eccubeConfig->get('eccube_default_page_count'));

        $page_count_param = (int) $request->get('page_count');
        $pageMaxis = $this->pageMaxRepository->findAll();

        if ($page_count_param) {
            foreach ($pageMaxis as $pageMax) {
                if ($page_count_param == $pageMax->getName()) {
                    $page_count = $pageMax->getName();
                    $this->session->set('eccube.admin.order.shop.stock.order.search.page_count', $page_count);
                    break;
                }
            }
        }

        if ('POST' === $request->getMethod()) {
            $searchForm->handleRequest($request);

            if ($searchForm->isValid()) {
                /**
                 * 検索が実行された場合は, セッションに検索条件を保存する.
                 * ページ番号は最初のページ番号に初期化する.
                 */
                $page_no = 1;
                $searchData = $searchForm->getData();

                // 検索条件, ページ番号をセッションに保持.
                $this->session->set('eccube.admin.order.shop.stock.order.search', FormUtil::getViewData($searchForm));
                $this->session->set('eccube.admin.order.shop.stock.order.search.page_no', $page_no);
            } else {
                // 検索エラーの際は, 詳細検索枠を開いてエラー表示する.
                return [
                    'searchForm' => $searchForm->createView(),
                    'pagination' => [],
                    'pageMaxis' => $pageMaxis,
                    'page_no' => $page_no,
                    'page_count' => $page_count,
                    'has_errors' => true,
                ];
            }
        } else {
            if (null !== $page_no || $request->get('resume')) {
                /*
                 * ページ送りの場合または、他画面から戻ってきた場合は, セッションから検索条件を復旧する.
                 */
                if ($page_no) {
                    // ページ送りで遷移した場合.
                    $this->session->set('eccube.admin.order.shop.stock.order.search.page_no', (int) $page_no);
                } else {
                    // 他画面から遷移した場合.
                    $page_no = $this->session->get('eccube.admin.order.shop.stock.order.search.page_no', 1);
                }
                $viewData = $this->session->get('eccube.admin.order.shop.stock.order.search', []);
                $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
            } else {
                // INS-START CNC 2022/05/24
                if ($productId != null) {
                    log_info("home");
                    /**
                     * ホーム画面から遷移した場合
                     */
                    $page_no = 1;
                    $viewData = [];

                    $product = $this->productRepository->find($productId);

                    $productCode = $product->getProductClasses()[0]['code'];

                    $viewData['buy_product_code'] = $productCode;

                    if ($statusId = (int)$request->get('order_status_id')) {
                        $viewData = ['status' => $statusId];
                    }

                    $searchData = FormUtil::submitAndGetData($searchForm, $viewData);
                    $searchData['buy_product_code'] = $productCode;

                    // セッション中の検索条件, ページ番号を初期化.
                    $this->session->set('eccube.admin.order.post.new.order.search', $viewData);
                    $this->session->set('eccube.admin.order.post.new.order.search.page_no', $page_no);
                    // INS-END CNC 2022/05/24
                } else {
                    /**
                     * 初期表示の場合.
                     */
                    $page_no = 1;
                    $viewData = [];

                    if ($statusId = (int)$request->get('order_status_id')) {
                        $viewData = ['status' => $statusId];
                    }

                    $searchData = FormUtil::submitAndGetData($searchForm, $viewData);

                    // セッション中の検索条件, ページ番号を初期化.
                    $this->session->set('eccube.admin.order.shop.stock.order.search', $viewData);
                    $this->session->set('eccube.admin.order.shop.stock.order.search.page_no', $page_no);
                }
            }
        }

        // 店頭買取
        $KaitoriType = $this->entityManager
                     ->find(KaitoriType::class, KaitoriType::KAITORI_TYPE_SHOP);
        $searchData['KaitoriType'] = $KaitoriType;      
        
        $qb = $this->orderRepository->getQueryBuilderBySearchDataForStock($searchData);
        $all_orders = $qb->getQuery()->getResult();

        // INS-START CNC 2022/05/20
        // 価格更新フラグ追加
        foreach ($all_orders as &$order) {
            $price_update = $this->priceUpdateRepository->findOneBy(['orderNo' => $order->getOrderNo()]);
            if ($price_update) {
                if ($price_update->getOrderUpdateDate() == $order->getUpdateDate()) {
                    $order->setPriceUpdateFlg(1);
                } else {
                    $order->setPriceUpdateFlg(0);
                }
            } else {
                $order->setPriceUpdateFlg(0);
            }
        }
        // INS-END CNC 2022/05/20

        $sort_orders = $this->sortOrder($all_orders, $searchData);

        $pagination = $paginator->paginate(
            $sort_orders,
            $page_no,
            $page_count
        );

        return [
            'searchForm' => $searchForm->createView(),
            'pagination' => $pagination,
            'pageMaxis' => $pageMaxis,
            'page_no' => $page_no,
            'page_count' => $page_count,
            'has_errors' => false,
            'OrderStatuses' => $this->orderStatusRepository->findBy([], ['sort_no' => 'ASC']),
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/order/shop/bulk_delete", name="admin_order_shop_bulk_delete", methods={"POST"})
     */
    public function bulkDelete(Request $request)
    {
        $this->isTokenValid();
        $ids = $request->get('ids');
        foreach ($ids as $order_id) {
            $Order = $this->orderRepository
                ->find($order_id);
            if ($Order) {
                $this->entityManager->remove($Order);
                log_info('受注削除', [$Order->getId()]);
            }
        }

        $this->entityManager->flush();

        $this->addSuccess('admin.common.delete_complete', 'admin');

        return $this->redirect($this->generateUrl('admin_order', ['resume' => Constant::ENABLED]));
    }

    /**
     * 受注CSVの出力.
     *
     * @Route("/%eccube_admin_route%/order/shop/export/order", name="admin_order_shop_export_order")
     *
     * @param Request $request
     *
     * @return StreamedResponse
     */
    public function exportOrder(Request $request)
    {
        $filename = 'order_'.(new \DateTime())->format('YmdHis').'.csv';
        $response = $this->exportCsv($request, CsvType::CSV_TYPE_ORDER, $filename);
        log_info('受注CSV出力ファイル名', [$filename]);

        return $response;
    }

    /**
     * 配送CSVの出力.
     *
     * @Route("/%eccube_admin_route%/order/shop/export/shipping", name="admin_order_shop_export_shipping")
     *
     * @param Request $request
     *
     * @return StreamedResponse
     */
    public function exportShipping(Request $request)
    {
        $filename = 'shipping_'.(new \DateTime())->format('YmdHis').'.csv';
        $response = $this->exportCsv($request, CsvType::CSV_TYPE_SHIPPING, $filename);
        log_info('配送CSV出力ファイル名', [$filename]);

        return $response;
    }

    /**
     * @param Request $request
     * @param $csvTypeId
     * @param string $fileName
     *
     * @return StreamedResponse
     */
    protected function exportCsv(Request $request, $csvTypeId, $fileName)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        // sql loggerを無効にする.
        $em = $this->entityManager;
        $em->getConfiguration()->setSQLLogger(null);

        $response = new StreamedResponse();
        $response->setCallback(function () use ($request, $csvTypeId) {
            // CSV種別を元に初期化.
            $this->csvExportService->initCsvType($csvTypeId);

            // ヘッダ行の出力.
            $this->csvExportService->exportHeader();

            // 受注データ検索用のクエリビルダを取得.
            $qb = $this->csvExportService
                ->getOrderQueryBuilder($request);

            // データ行の出力.
            $this->csvExportService->setExportQueryBuilder($qb);
            $this->csvExportService->exportData(function ($entity, $csvService) use ($request) {
                $Csvs = $csvService->getCsvs();

                $Order = $entity;
                $OrderItems = $Order->getOrderItems();

                foreach ($OrderItems as $OrderItem) {
                    $ExportCsvRow = new ExportCsvRow();

                    // CSV出力項目と合致するデータを取得.
                    foreach ($Csvs as $Csv) {
                        // 受注データを検索.
                        $ExportCsvRow->setData($csvService->getData($Csv, $Order));
                        if ($ExportCsvRow->isDataNull()) {
                            // 受注データにない場合は, 受注明細を検索.
                            $ExportCsvRow->setData($csvService->getData($Csv, $OrderItem));
                        }
                        if ($ExportCsvRow->isDataNull() && $Shipping = $OrderItem->getShipping()) {
                            // 受注明細データにない場合は, 出荷を検索.
                            $ExportCsvRow->setData($csvService->getData($Csv, $Shipping));
                        }

                        $event = new EventArgs(
                            [
                                'csvService' => $csvService,
                                'Csv' => $Csv,
                                'OrderItem' => $OrderItem,
                                'ExportCsvRow' => $ExportCsvRow,
                            ],
                            $request
                        );
                        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_ORDER_CSV_EXPORT_ORDER, $event);

                        $ExportCsvRow->pushData();
                    }

                    //$row[] = number_format(memory_get_usage(true));
                    // 出力.
                    $csvService->fputcsv($ExportCsvRow->getRow());
                }
            });
        });

        $response->headers->set('Content-Type', 'application/octet-stream');
        $response->headers->set('Content-Disposition', 'attachment; filename='.$fileName);
        $response->send();

        return $response;
    }

    /**
     * Update order status
     *
     * @Route("/%eccube_admin_route%/order_shop/{id}/order_status/{status}", requirements={"id" = "\d+","status" = "\S+"}, name="admin_shipping_update_order_shop_status", methods={"PUT"})
     *
     * @param Request $request
     * @param Shipping $Shipping
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
   public function updateOrderStatus(Request $request, Shipping $Shipping=null,$status=null)
    {
      try {
         if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
         }

        $Order = $Shipping->getOrder();
        $Member = $this->getUser(); 

        // 新規受付の場合 新規受付 --> 査定完了/顧客確認待ち
        if($this->entityManager->find(OrderStatus::class,  OrderStatus::NEW) === $Order->getOrderStatus()){
           if($status === 'status'){
              // 入荷待ち
               $OrderStatus = $this->entityManager->find(OrderStatus::class,  OrderStatus::RETURNED);
           }
           if($status === 'mail'){
              // 顧客確認待ち
               $OrderStatus = $this->entityManager->find(OrderStatus::class,  OrderStatus::WAIT);
           }
        }

        // 顧客確認待ちの場合 顧客確認待ち -->  入荷待ち
        if($this->entityManager->find(OrderStatus::class,  OrderStatus::WAIT) === $Order->getOrderStatus()){
           $OrderStatus = $this->entityManager->find(OrderStatus::class,  OrderStatus::RETURNED);
        }

        // INS-START CNC 2021/07/23
        // 入荷待ちの場合
        $stockStatus = false;
        // INS-END CNC 2021/07/23

        // 入荷待ちの場合 入荷待ち --> 送金待ち
        if($this->entityManager->find(OrderStatus::class,  OrderStatus::RETURNED) === $Order->getOrderStatus()){
           $OrderStatus = $this->entityManager->find(OrderStatus::class,  OrderStatus::PENDING);
           // 現金払いのOrderは、入荷待ち⇒送金待ち-->入荷待ち⇒送金完了
           if($Order->getPaymentMethod() == '現金払い'){
              $OrderStatus = $this->entityManager->find(OrderStatus::class,  OrderStatus::PAID);
           }else{
              if($Paying = $Order->getPaying()){
//                $Paying->setMember($Member);
                $Paying->setReturnOperateDate(new \DateTime());
                $Paying->setPayingOrderId($Order->getId());
                $Paying = $this->orderHelper->setShopInfo($Order, $Paying);
                $Paying = $this->orderRepository->getNotPayPrice($Paying);
                //$this->entityManager->persist($Paying);
                //$this->entityManager->flush($Paying);
              }
           }
            // INS-START CNC 2021/07/23
            $stockStatus = true;
            // INS-END CNC 2021/07/23
        }

        // 送金待ちの場合 送金待ち --> 送金完了
        if($this->entityManager->find(OrderStatus::class,  OrderStatus::PENDING) === $Order->getOrderStatus()){
           $OrderStatus = $this->entityManager->find(OrderStatus::class,  OrderStatus::PAID);
        }

        // $OrderStatus = $this->entityManager->find(OrderStatus::class, $request->get('order_status'));

        if (!$OrderStatus) {
            return $this->json(['status' => 'NG'], 400);
        }

        $result = [];

         if ($Order->getOrderStatus()->getId() == $OrderStatus->getId()) {
            log_info('対応状況一括変更スキップ');
                $result = ['message' => trans('admin.order.skip_change_status', ['%name%' => $Shipping->getId()])];
         } else {

            if ($this->orderStateMachine->can($Order, $OrderStatus)) {
                    $this->orderStateMachine->apply($Order, $OrderStatus);

                    if($Order->getOrderStatus()->getId() == OrderStatus::WAIT && $Order->getPreOrderStatus()->getId() == OrderStatus::NEW){
                       $PreOrderStatus = $this->entityManager->find(OrderStatus::class,  OrderStatus::CANCEL);
                       $Order->setPreOrderStatus($PreOrderStatus);
                    }

                    if($Order->getPaymentMethod() == '現金払い' && $Order->getOrderStatus()->getId() == OrderStatus::PAID){
                       $PreOrderStatus = $this->entityManager->find(OrderStatus::class,  OrderStatus::RETURNED);
                       $Order->setPreOrderStatus($PreOrderStatus);
                       $paidStatus = $this->entityManager->find(PayingStatus::class,  PayingStatus::FINISH);
                }

                    // 2021/12/20 CNC UPD START
                    // INS-START CNC 2021/07/23
                    // 入荷待ちの場合
                    if ($stockStatus) {
//                    $flg = true;
//                    $orderItems = $Shipping->getOrderItems();
//                    foreach ($orderItems as $orderItem) {
//                        if (!($orderItem->getOrderItemType()['id'] == OtherItemCodeChange::COMMISSION
//                            || $orderItem->getOrderItemType()['id'] == OtherItemCodeChange::POSTAGE
//                            || $orderItem->getOrderItemType()['id'] == OtherItemCodeChange::MAINPOINT)) {
//                            if ($orderItem->getProduct()->getSerialFlg()) {
//                                $flg = false;
//                                break;
//                            }
//                        }
//                    }
//                    $this->createPayeeVoucher($Shipping, $flg);

                        $serialNumberList = [];

                        if ($request->get('serial_number_list') !== null) {
                            if (count($request->get('serial_number_list')) !== count($Order->getOrderItems())) {
                                return $this->json(['status' => 'NG'], 400);
                            }
                            $serialNumberList = $request->get('serial_number_list');
                        }

                        $this->createPayeeVoucher($Shipping, true, $serialNumberList);
                    // 本登録
//                    if ($flg) {
                        $result = ['message' => trans('admin.order.payee.voucher.registration')];
//                    } else {
//                        $payeeVoucherHeader = $this->payeeVoucherHeaderRepository->findOneBy(['payee_voucher_no' => $Order->getOrderNo()]);
//                        $result = ['message' =>  trans('admin.order.payee.voucher.noregistration', ['%id%' => $payeeVoucherHeader->getId()])];
//                    }
                    }
                    // INS-END CNC 2021/07/23
                    // 2021/12/20 CNC UPD END

                   // 操作履歴に登録
                   /** @var OrderOpehist $OrderOpehist */
                    $this->orderOpehistRepository->insertOrderOpehist($Order, $Member,'対応状況変更');
                   // 顧客確認まちの場合
                   if ($Order->getOrderStatus()->getId() == OrderStatus::WAIT) {
                       // 更新フラグ1
                       $Order->setConfirmStatusFlag1(true); 
                   }
                    $this->orderHelper->checkPointItem($Order);

                    if($Order->getOrderStatus()->getId() == OrderStatus::RETURNED){
                        $Order->setOperateFinishShopDate(new \DateTime());
                    }else if($Order->getOrderStatus()->getId() == OrderStatus::CANCEL){
                        $Order->setOperateFinishShopDate(null);
                    }

                    $this->entityManager->flush($Order);

                    // 送信
                    // 顧客確認待ちの場合送信する
                    if($Order->getOrderStatus()->getId() == OrderStatus::WAIT){
                       // 顧客確認待ち
                       $mypage_url = $this->generateUrl('mypage_history', ['id' => $Order->getId()],UrlGeneratorInterface::ABSOLUTE_URL);
                       $this->mailService->sendOrderNotifyMail($Shipping,$mypage_url );
                       $Shipping->setMailSendDate(new \DateTime());
                    }else if($Order->getOrderStatus()->getId() == OrderStatus::PAID && $Order->getPaymentMethod() == '現金払い'){
                       $this->mailService->sendOrderPayingNotifyMail($Shipping);
                       $Shipping->setMailSendDate(new \DateTime());
                    }

                    if($Order->getOrderStatus()->getId() == OrderStatus::PAID){
                       // 送金完了
                       $Paying = $Order->getPaying();
                       if($Paying){
                          $this->mailService->sendPayingNotifyMail($Paying);
                       }
                       $Shipping->setMailSendDate(new \DateTime());

                       // 送金ステータス変更するか判断する
                       //$this->entityManager->flush($Paying);
                       $this->entityManager->flush($Shipping);

                       // 会員の場合、購入回数、購入金額などを更新
                       if ($Customer = $Order->getCustomer()) {
                          //$this->orderRepository->updateOrderSummary($Customer);
                          $this->orderRepository->updateCustomerSummary($Customer);
                          $this->entityManager->flush($Customer);
                        }

                       // 更新送金日
                       $Paying = $Order->getPaying();
                       if(null != $Paying and null != $Customer){
                          $Paying->setPayingDate(new \DateTime());
                          $notPaidCount = $this->orderRepository->getNotPaidOrderCount($Paying->getId(),$Customer->getId());

                         if($notPaidCount == 0){
                           $PayingStatus = $this->entityManager->find(PayingStatus::class, PayingStatus::FINISH);
                           $Paying->setPayingStatus($PayingStatus);
                         }
                        $this->entityManager->flush($Paying);
                       }
                    }

                     } else {
                    $from = $Order->getOrderStatus()->getName();
                    $to = $OrderStatus->getName();
                    $result = ['message' => trans('admin.order.failed_to_change_status', [
                    '%name%' => $Shipping->getId(),
                        '%from%' => $from,
                        '%to%' => $to,
                     ])];
                    }
             log_info('対応状況一括変更処理完了', [$Order->getId()]); 
             }
            } catch (\Exception $e) {
               log_error('予期しないエラーです', [$e->getMessage()]);

            }
            return $this->json(array_merge(['status' => 'OK'], $result));
        }

    /**
     * rollback order status
     *
     * @Route("/%eccube_admin_route%/shipping/{id}/rollback_order_shop_status/{type}", requirements={"id" = "\d+","type" = "\S+"}, name="admin_shipping_rollback_order_shop_status", methods={"PUT"})
     *
     * @param Request $request
     * @param Shipping $Shipping
     * @param $type
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function rollbackOrderStatus(Request $request, Shipping $Shipping,$type)
    {
       
       if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
          return $this->json(['status' => 'NG'], 400);
       }
            
       $Order = $Shipping->getOrder();
       $PreOrderStatus = $Order->getPreOrderStatus();
       if($Order->getOrderStatus()->getId() == OrderStatus::WAIT || $type='cancel'){
         $PreOrderStatus = $this->entityManager
                 ->find(OrderStatus::class, OrderStatus::CANCEL);
       }

       if (!$PreOrderStatus) {
        return $this->json(['status' => 'NG'], 400);
       }

        $result = [];
        try {
         if ($Order->getOrderStatus()->getId() == $PreOrderStatus->getId() || $Order->getOrderStatus()->getId() == OrderStatus::CANCEL) {
            log_info('対応状況一括変更スキップ');
                $result = ['message' => trans('admin.order.skip_change_status', ['%name%' => $Shipping->getId()])];
                } else {
                  
                  $Member = $this->getUser();  
                  if ($this->orderStateMachine->can($Order, $PreOrderStatus)) {
                //if ($OrderStatus->getId() == OrderStatus::DELIVERED) {
                  //  if (!$Shipping->isShipped()) {
                   //     $Shipping->setShippingDate(new \DateTime());
                   //         }
                   //      $allShipped = true;
                   //     foreach ($Order->getShippings() as $Ship) {
                    //    if (!$Ship->isShipped()) {
                    //        $allShipped = false;
                    //            break;
                    //            }
                    //        }
                    //    if ($allShipped) {
                    //     $this->orderStateMachine->apply($Order, $OrderStatus);
                    //        }
                     //   } else {
                    $this->orderStateMachine->apply($Order, $PreOrderStatus);
                     //   }
                    
                    //if ($request->get('notificationMail')) { // for SimpleStatusUpdate
                    //   $this->mailService->sendShippingNotifyMail($Shipping);
                    //    $Shipping->setMailSendDate(new \DateTime());
                    //    $result['mail'] = true;
                    //    }
                    //     else {
                    //$result['mail'] = false;
                    //    }

                    $this->entityManager->flush($Order);
                    $this->entityManager->flush($Shipping);
                    
                    // 操作履歴に登録
                    /** @var OrderOpehist $OrderOpehist */
                    $this->orderOpehistRepository->insertOrderOpehist($Order, $Member,'対応状況変更');
                    
                    // 会員の場合、購入回数、購入金額などを更新
                     if ($Customer = $Order->getCustomer()) {
                        $this->orderRepository->updateCustomerSummary($Customer);
                        $this->entityManager->flush($Customer);
                      }
                      
                      // roll back paying
                      if ($Order->getPreOrderStatus()->getId() == OrderStatus :: PAID && $Order->getOrderStatus()->getId() == OrderStatus :: PENDING) {
                          $Paying = $Order->getPaying();
                          if($Paying){
                              $notPaidCount = $this->orderRepository->getNotPaidOrderCount($Paying->getId(),$Order->getCustomer()->getId());
                              if($notPaidCount > 0){
                                 $PayingStatus = $this->entityManager->find(PayingStatus::class, PayingStatus::NEW);
                                 $Paying->setPayingStatus($PayingStatus);
                               }
                              $this->entityManager->flush($Paying);  
                          }
                         
                       }
                       // 在庫戻す
                       if ($Order->getOrderStatus()->getId() == OrderStatus::CANCEL) {
                          foreach ($Order->getOrderItems() as $OrderItem) {
                            $ProductClass = $OrderItem->getProductClass();
                            if ($OrderItem->isProduct() && !$ProductClass->isStockUnlimited()) {
                                $quantity = $OrderItem->getQuantity();
                                $this->entityManager->flush($ProductClass);
                                $ProductStock = $this->productStockRepository->findOneBy(['ProductClass' => $ProductClass]);
                                $nowStock = $ProductStock->getStock() == null ? 0 : $ProductStock->getStock();
                                $ProductStock->setStock($nowStock - $quantity);
                                $this->entityManager->flush($ProductStock);
                             }
                           }

                           // 該当会員のキャンセル回数を更新する
                           if ($Customer = $Order->getCustomer()) {
                             $this->orderRepository->updateCustomerCancelTimes($Customer);
                           }

                           if($Order->getPaying()){
                               // 該当会員の全ての申し込みをキャンセル場合送金を削除する
                               $this->orderRepository->refreshPayingData($Order->getPaying());
                           }

                           // send mail
                           $this->mailService->sendAdminCancelNotifyMail($Shipping);
                           $Shipping->setMailSendDate(new \DateTime());
                        }

                     } else {
                    $from = $Order->getOrderStatus()->getName();
                    $to = $PreOrderStatus->getName();
                    $result = ['message' => trans('admin.order.failed_to_change_status', [
                    '%name%' => $Shipping->getId(),
                        '%from%' => $from,
                        '%to%' => $to,
                        ])];
                    }
             log_info('対応状況一括変更処理完了', [$Order->getId()]);
             }
            } catch (\Exception $e) {
              log_error('予期しないエラーです', [$e->getMessage()]);
              return $this->json(['status' => 'NG'], 500);
          }
           return $this->json(array_merge(['status' => 'OK'], $result));
        }
        
    /**
     * Update to Tracking number.
     *
     * @Route("/%eccube_admin_route%/shipping/{id}/tracking_number", requirements={"id" = "\d+"}, name="admin_shipping_update_tracking_number", methods={"PUT"})
     *
     * @param Request $request
     * @param Shipping $shipping
     *
     * @return Response
     */
    public function updateTrackingNumber(Request $request, Shipping $shipping)
    {
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
            return $this->json(['status' => 'NG'], 400);
        }

        $trackingNumber = mb_convert_kana($request->get('tracking_number'), 'a', 'utf-8');
        /** @var \Symfony\Component\Validator\ConstraintViolationListInterface $errors */
        $errors = $this->validator->validate(
            $trackingNumber,
            [
                new Assert\Length(['max' => $this->eccubeConfig['eccube_stext_len']]),
                new Assert\Regex(
                    ['pattern' => '/^[0-9a-zA-Z-]+$/u', 'message' => trans('admin.order.tracking_number_error')]
                ),
            ]
        );

        if ($errors->count() != 0) {
            log_info('送り状番号入力チェックエラー');
            $messages = [];
            /** @var \Symfony\Component\Validator\ConstraintViolationInterface $error */
            foreach ($errors as $error) {
                $messages[] = $error->getMessage();
            }

            return $this->json(['status' => 'NG', 'messages' => $messages], 400);
        }

        try {
            $shipping->setTrackingNumber($trackingNumber);
            $this->entityManager->flush($shipping);
            log_info('送り状番号変更処理完了', [$shipping->getId()]);
            $message = ['status' => 'OK', 'shipping_id' => $shipping->getId(), 'tracking_number' => $trackingNumber];

            return $this->json($message);
        } catch (\Exception $e) {
            log_error('予期しないエラー', [$e->getMessage()]);

            return $this->json(['status' => 'NG'], 500);
        }
    }

    /**
     * @Route("/%eccube_admin_route%/order/shop/export/pdf", name="admin_order_shop_export_pdf")
     * @Template("@admin/OrderShop/order_pdf.twig")
     *
     * @param Request $request
     *
     * @return array|RedirectResponse
     */
    public function exportPdf(Request $request)
    {
        // requestから出荷番号IDの一覧を取得する.
        $ids = $request->get('ids', []);

        if (count($ids) == 0) {
            $this->addError('admin.order.delivery_note_parameter_error', 'admin');
            log_info('The Order cannot found!');

            return $this->redirectToRoute('admin_order');
        }

        /** @var OrderPdf $OrderPdf */
        $OrderPdf = $this->orderPdfRepository->find($this->getUser());

        if (!$OrderPdf) {
            $OrderPdf = new OrderPdf();
            $OrderPdf
                ->setTitle(trans('admin.order.delivery_note_title__default'))
                ->setMessage1(trans('admin.order.delivery_note_message__default1'))
                ->setMessage2(trans('admin.order.delivery_note_message__default2'))
                ->setMessage3(trans('admin.order.delivery_note_message__default3'));
        }

        /**
         * @var FormBuilder
         */
        $builder = $this->formFactory->createBuilder(OrderPdfType::class, $OrderPdf);

        /* @var \Symfony\Component\Form\Form $form */
        $form = $builder->getForm();

        // Formへの設定
        $form->get('ids')->setData(implode(',', $ids));

        return [
            'form' => $form->createView(),
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/order/shop/export/pdf/download", name="admin_order_shop_pdf_download")
     * @Template("@admin/OrderShop/order_pdf.twig")
     *
     * @param Request $request
     *
     * @return Response
     */
    public function exportPdfDownload(Request $request, OrderPdfService $orderPdfService)
    {
        /**
         * @var FormBuilder
         */
        $builder = $this->formFactory->createBuilder(OrderPdfType::class);

        /* @var \Symfony\Component\Form\Form $form */
        $form = $builder->getForm();
        $form->handleRequest($request);

        // Validation
        if (!$form->isValid()) {
            log_info('The parameter is invalid!');
            return $this->render('@admin/OrderShop/order_pdf.twig', [
                'form' => $form->createView(),
            ]);
        }

        $arrData = $form->getData();

        // 購入情報からPDFを作成する
        $status = $orderPdfService->makePdf($arrData);

        // 異常終了した場合の処理
        if (!$status) {
             $this->addError('admin.order.export.pdf.download.failure', 'admin');
             log_info('Unable to create pdf files! Process have problems!');
             return $this->render('@admin/OrderShop/order_pdf.twig', [
                    'form' => $form->createView(),
             ]);
        }

        // ダウンロードする
        $response = new Response(
             $orderPdfService->outputPdf(),
                200,
             ['content-type' => 'application/pdf']
        );

        $downloadKind = $form->get('download_kind')->getData();

        // レスポンスヘッダーにContent-Dispositionをセットし、ファイル名を指定
        if ($downloadKind == 1) {
                 $response->headers->set('Content-Disposition', 'attachment; filename="'.$orderPdfService->getPdfFileName().'"');
        } else {
                 $response->headers->set('Content-Disposition', 'inline; filename="'.$orderPdfService->getPdfFileName().'"');
        }

        log_info('OrderPdf download success!', ['Order ID' => implode(',', $request->get('ids', []))]);

        $isDefault = isset($arrData['default']) ? $arrData['default'] : false;
        if ($isDefault) {
            // Save input to DB
            $arrData['admin'] = $this->getUser();
                 $this->orderPdfRepository->save($arrData);
        }
            return $response;
    }
    
    /**
     * updateAcceptMemberName
     *
     * @Route("/%eccube_admin_route%/shipping/{id}/update_order_shop_member_name", requirements={"id" = "\d+"}, name="admin_shipping_update_order_shop_member_accept", methods={"PUT"})
     *
     * @param Request $request
     * @param Shipping $Shipping
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function updateAcceptMemberName(Request $request, Shipping $Shipping)
    {
        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
          return $this->json(['status' => 'NG'], 400);
         }
         
        $Member = $this->getUser();    
        $Order = $Shipping->getOrder();

        $result = [];
       
        try {
              
              if($Order->getMember() == null){
                 $Order->setMember($Member);
                 $this->entityManager->flush($Order);
              }else{
                
                 $result = ['message' => trans('admin.order.failed_to_change_member', [
                   '%name%' => $Order->getOrderNo(),
                  
                ])];

              }

            } catch (\Exception $e) {
             log_error('予期しないエラーです', [$e->getMessage()]);
            
            return $this->json(['status' => 'NG'], 500);
            }
            
        return $this->json(array_merge(['status' => 'OK'], $result));
     
     }
     
    /**
     * updateNotAcceptMemberName
     *
     * @Route("/%eccube_admin_route%/shipping/{id}/update_order_shop_not_accept_member_name", requirements={"id" = "\d+"}, name="admin_shipping_update_order_shop_member_not_accept", methods={"PUT"})
     *
     * @param Request $request
     * @param Shipping $Shipping
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function updateNotAcceptMemberName(Request $request, Shipping $Shipping)
    {

        if (!($request->isXmlHttpRequest() && $this->isTokenValid())) {
          return $this->json(['status' => 'NG'], 400);
         }
         
        $result = []; 
        $Member = $this->getUser();    
        $Order = $Shipping->getOrder();
        if($Order->getMember() == null){
          $result = ['message' => trans('admin.order.failed_to_change_not_accept_member_miss',[
           '%name%' => $Order->getOrderNo(),
          ])];
           return $this->json(array_merge(['status' => 'OK'], $result)); 
        }
        
        try {
              
              if($Order->getMember()->getName() == $Member->getName()){
                  $Order->setMember(NULL);
                  $this->entityManager->flush($Order);
              }else{
                 $from = $Order->getMember()->getName();
                 $to = $Member->getName();
                 $result = ['message' => trans('admin.order.failed_to_change_not_accept_member', [
                   '%name%' => $Order->getOrderNo(),
                   '%from%' => $Order->getMember()->getName(),
                   '%to%' => $Member->getName(),
                ])];
             
              }

            } catch (\Exception $e) {
             log_error('予期しないエラーです', [$e->getMessage()]);

            return $this->json(['status' => 'NG'], 500);
            }
            
        return $this->json(array_merge(['status' => 'OK'], $result));
     
    }

    private function sortOrder($orders, $searchData){
        if($searchData['sort_by']){
            $order_by = $searchData['order_by'];
            switch ($searchData['sort_by']) {
                case '来店場所':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getShippings()->first()->getShopInfo()->getId() > $b->getShippings()->first()->getShopInfo()->getId() ? -1 : 1;
                        }
                        return $a->getShippings()->first()->getShopInfo()->getId() < $b->getShippings()->first()->getShopInfo()->getId() ? -1 : 1;
                    });
                    break;
                case '支払方法':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getPayment()->getId() > $b->getPayment()->getId() ? -1 : 1;
                        }
                        return $a->getPayment()->getId() < $b->getPayment()->getId() ? -1 : 1;
                    });
                    break;
                case '対応状況':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getOrderStatus()->getSortNo() > $b->getOrderStatus()->getSortNo() ? -1 : 1;
                        }
                        return $a->getOrderStatus()->getSortNo() < $b->getOrderStatus()->getSortNo() ? -1 : 1;
                    });
                    break;
                case '書類確認':
                    usort($orders, function ($a, $b) use ($order_by) {
                        if($order_by == "降順"){
                            return $a->getModifiedVerified() > $b->getModifiedVerified() ? -1 : 1;
                        }
                        return $a->getModifiedVerified() < $b->getModifiedVerified() ? -1 : 1;
                    });
                    break;
            }
        }
        return $orders;
    }

    // INS-START CNC 2021/07/23
    /**
     * 仕入情報作成
     * @param Shipping $Shipping Shipping
     * @param $flg
     * @throws \Exception
     */
    private function createPayeeVoucher(Shipping $Shipping, $flg, $serialNumberList)
    {
        $Order = $Shipping->getOrder();
        $orderItems = $Order->getOrderItems();
        $payeeMoneyTotalAmount = 0;
        foreach ($orderItems as $orderItem) {
            $payeeMoneyTotalAmount = $payeeMoneyTotalAmount + $orderItem->getPrice() * $orderItem->getQuantity();
        }
        // todo
        $shopInfo = $this->shopInfoRepository->getShopInfo($Shipping->getShopInfo()->getId());
        $shopName = str_replace('店', '', $shopInfo->getName());
//        $payee = $this->payeeMstRepository->findOneBy(['payeeName' => '店頭（'.$shopName.'店）']);
        $payee = $this->payeeMstRepository->findOneLikePayeeName('店頭買取（'.$shopName);
        /** @var Place $place */
        $place = $this->placeRepository->findOneBy(['place' => $shopName]);
        // dtb_payee_voucher_header
        $payeeVoucherHeader = $this->payeeVoucherHeaderRepository->findOneBy(['payee_voucher_no' => $Order->getOrderNo()]);
        if ($payeeVoucherHeader) {
            // 更新
            $upd_flg = 1;
        } else {
            // 新規
            $upd_flg = 0;
            $payeeVoucherHeader = new \Eccube\Entity\PayeeVoucherHeader();
            $payeeVoucherHeader->setCreateUserName($this->getUser()['name']);
        }
//        if ($flg) {
//            // 本登録
//            $payeeVoucherHeader->setRegistrationStatus('本登録');
//            $payeeVoucherHeader->setUpdateUserName($this->getUser()['name']);
//        } else {
//            // 仮登録
//            $payeeVoucherHeader->setPayeeVoucherNo($Order->getOrderNo());
//            $payeeVoucherHeader->setPayment($Order->getPayment());
//            $payeeVoucherHeader->setPersonnel($this->getUser());
//            // $payeeVoucherHeader->setPurchaseDate($shop->getCreateDate());
//            $payeeVoucherHeader->setPurchaseDate(new \DateTime());
//            $payeeVoucherHeader->setPayee($payee);
//            $payeeVoucherHeader->setPlace($place);
//            $payeeVoucherHeader->setRegistrationStatus('仮登録');
//            $payeeVoucherHeader->setPayeeMoneyTotalAmount($payeeMoneyTotalAmount);
//            $payeeVoucherHeader->setPersonnelMemo($Order->getShopNote());
//            $payeeVoucherHeader->setUpdateUserName($this->getUser()['name']);
//        }

        // 本登録
        $payeeVoucherHeader->setPayeeVoucherNo($Order->getOrderNo());
        $payeeVoucherHeader->setPayment($Order->getPayment());
        $payeeVoucherHeader->setPersonnel($this->getUser());
        // $payeeVoucherHeader->setPurchaseDate($shop->getCreateDate());
        $payeeVoucherHeader->setPurchaseDate(new \DateTime());
        $payeeVoucherHeader->setPayee($payee);
        $payeeVoucherHeader->setPlace($place);
        $payeeVoucherHeader->setRegistrationStatus('本登録');
        $payeeVoucherHeader->setPayeeMoneyTotalAmount($payeeMoneyTotalAmount);
        $payeeVoucherHeader->setPersonnelMemo($Order->getShopNote());
        $payeeVoucherHeader->setUpdateUserName($this->getUser()['name']);

        // dtb_payee_voucher_header_history
        $payeeVoucherHeaderHistory = new PayeeVoucherHeaderHistory();
        $payeeVoucherHeaderHistory->setPayeeVoucherNo($Order->getOrderNo());
        $payeeVoucherHeaderHistory->setPaymentMethod($Order->getPayment());
        $payeeVoucherHeaderHistory->setPersonnel($this->getUser());
        // $payeeVoucherHeaderHistory->setPurchaseDate($Shipping->getCreateDate());
        $payeeVoucherHeaderHistory->setPurchaseDate(new \DateTime());
        $payeeVoucherHeaderHistory->setPayeeCode($payee);
        $payeeVoucherHeaderHistory->setStorehouse($place);

//        if ($flg) {
            $payeeVoucherHeaderHistory->setRegistrationStatus('本登録');
//        } else {
//            $payeeVoucherHeaderHistory->setRegistrationStatus('仮登録');
//        }
        $pastPayeeVoucherHeaderHistory = $this->payeeVoucherHeaderHistoryRepository->findOneBy(['payeeVoucherNo' => $Order->getOrderNo()], ['createDate' => 'DESC']);
        if ($pastPayeeVoucherHeaderHistory) {
            $revision_no = $this->payeeVoucherHeaderHistoryRepository->getMaxRevisionNo($payeeVoucherHeader) + 1;
            $payeeVoucherHeaderHistory->setProcessingBehavior(PayeeVoucherHeaderHistory::BEHAVIOR_CHANGE);
        } else {
            $revision_no = 0;
            $payeeVoucherHeaderHistory->setProcessingBehavior(PayeeVoucherHeaderHistory::BEHAVIOR_NEW);
        }
        $payeeVoucherHeaderHistory->setRevisionNo($revision_no);
        $payeeVoucherHeaderHistory->setPersonnelMemo($Order->getShopNote());
        $payeeVoucherHeaderHistory->setCreateUserName($this->getUser()['name']);
        $payeeVoucherHeaderHistory->setUpdateUserName($this->getUser()['name']);

        // 明細編集
//        if (!$flg) {
            // 仮登録
            // ・仕入明細と買取項目の間に関連関係がないため、買取側で「登録」する度に仕入明細を全部削除して、再追加する。
            if ($upd_flg) {
                foreach ($payeeVoucherHeader->getPayeeVoucherDetails() as $payeeVoucherDetail) {
                    $payeeVoucherHeader->removePayeeVoucherDetail($payeeVoucherDetail);
                    $this->entityManager->remove($payeeVoucherDetail);
                    $this->entityManager->flush($payeeVoucherDetail);
                }
            }
            $count = 1;
            foreach ($orderItems as $index => $orderItem) {
                // 変換後状態
                $conversionAfterState = new State();
                if ($orderItem->getOrderItemType()['id'] == OtherItemCodeChange::COMMISSION
                    || $orderItem->getOrderItemType()['id'] == OtherItemCodeChange::POSTAGE
                    || $orderItem->getOrderItemType()['id'] == OtherItemCodeChange::MAINPOINT) {
                    $productCode = $this->otherItemCodeChangeRepository->find($orderItem->getOrderItemType()['id'])['name'];
                } else {
                    $productCode = $orderItem->getProductClass()->getCode();
                    if ($orderItem->getConversionAfterState()) {
                        $conversionAfterState = $orderItem->getConversionAfterState();
                    } else {
                        $conversionAfterState = $this->changeState($orderItem->getProductClass()->getProduct()->getId(), $orderItem->getRanks());
                    }
                }
                /** @var ProductClass $productClass */
                $productClass = $this->productClassRepository->findOneBy(['code' => $productCode]);

                // dtb_payee_voucher_detail
                $payeeVoucherDetail = new PayeeVoucherDetail();
                $payeeVoucherDetail->setPayeeVoucherNo($Order->getOrderNo());
//                $payeeVoucherDetail->setPayeeDetailNo($count);
                $payeeVoucherDetail->setProductId($productClass->getProduct()->getId());
                $payeeVoucherDetail->setProductClass($productClass);
                $payeeVoucherDetail->setProductCode($productCode);
                if (!($orderItem->getOrderItemType()['id'] == OtherItemCodeChange::COMMISSION
                    || $orderItem->getOrderItemType()['id'] == OtherItemCodeChange::POSTAGE
                    || $orderItem->getOrderItemType()['id'] == OtherItemCodeChange::MAINPOINT)) {
                    $payeeVoucherDetail->setState($conversionAfterState);
                }
                $payeeVoucherDetail->setPayeePrice($orderItem->getPrice());

                $payeeVoucherDetail->setOrderItemId($orderItem->getId());

//                $payeeVoucherDetail->setQuantity($orderItem->getQuantity());
//                $payeeVoucherDetail->setPayeeMoneyAmount($orderItem->getPrice() * $orderItem->getQuantity());
                $payeeVoucherDetail->setCreateUserName($this->getUser()['name']);
                $payeeVoucherDetail->setUpdateUserName($this->getUser()['name']);

                // dtb_payee_voucher_detail_history
                $payeeVoucherDetailHistory = new PayeeVoucherDetailHistory();
                $payeeVoucherDetailHistory->setPayeeVoucherNo($Order->getOrderNo());
//                $payeeVoucherDetailHistory->setPayeeDetailNo($count);
                $payeeVoucherDetailHistory->setProductId($productClass->getProduct()->getId());
                $payeeVoucherDetailHistory->setProductClass($productClass);
                $payeeVoucherDetailHistory->setProductCode($productCode);
                if (!($orderItem->getOrderItemType()['id'] == OtherItemCodeChange::COMMISSION
                    || $orderItem->getOrderItemType()['id'] == OtherItemCodeChange::POSTAGE
                    || $orderItem->getOrderItemType()['id'] == OtherItemCodeChange::MAINPOINT)) {
                    $payeeVoucherDetailHistory->setState($conversionAfterState);
                }
                $payeeVoucherDetailHistory->setPayeePrice($orderItem->getPrice());
//                $payeeVoucherDetailHistory->setQuantity($orderItem->getQuantity());
//                $payeeVoucherDetailHistory->setPayeeMoneyAmount($orderItem->getPrice() * $orderItem->getQuantity());
                $payeeVoucherDetailHistory->setRevisionNo($revision_no);
                $payeeVoucherDetailHistory->setCreateUserName($this->getUser()['name']);
                $payeeVoucherDetailHistory->setUpdateUserName($this->getUser()['name']);

                // シリアル番号
                if ($orderItem->isProduct() && $orderItem->getProduct()->getSerialFlg()) {
                    $multiple_serial_numbers = $orderItem->getMultipleSerialNumbers();
                    $array_serial_numbers = explode("\r\n", $multiple_serial_numbers);
                    foreach ($array_serial_numbers as $serial_no) {
                        // シリアル番号
                        if (trim($serial_no) == null || trim($serial_no) == "") {
                            continue;
                        }

                        // dtb_payee_voucher_detail
                        $payeeVoucherDetailCut = new PayeeVoucherDetail();
                        // プロパティのコピー
                        $payeeVoucherDetailCut->copyProperties(
                            $payeeVoucherDetail,
                            [
                                'id',
                                'payee_detail_no',
                                'serial_no',
                                'quantity',
                                'payee_money_amount',
                            ]
                        );
//                        if (count($serialNumberList) !== 0) {
//                            $payeeVoucherDetailCut->setSerialNo(trim($serialNumberList[$index]));
//                        }
                        $payeeVoucherDetailCut->setSerialNo(trim($serial_no));
                        // 明細Ｎｏ
                        $payeeVoucherDetailCut->setPayeeDetailNo($count);
                        // 数量
                        $payeeVoucherDetailCut->setQuantity(1);
                        // 合計
                        $payeeVoucherDetailCut->setPayeeMoneyAmount($orderItem->getPrice());
                        $payeeVoucherDetailCut->setPayeeVoucherHeader($payeeVoucherHeader);
                        $payeeVoucherHeader->addPayeeVoucherDetail($payeeVoucherDetailCut);

                        // dtb_payee_voucher_detail_history
                        $payeeVoucherDetailCutHistory = new PayeeVoucherDetailHistory();
                        // プロパティのコピー
                        $payeeVoucherDetailCutHistory->copyProperties(
                            $payeeVoucherDetailHistory,
                            [
                                'id',
                                'payee_detail_no',
                                'serial_no',
                                'quantity',
                                'payee_money_amount',
                            ]
                        );
//                        if (count($serialNumberList) !== 0) {
//                            $payeeVoucherDetailCutHistory->setSerialNo(trim($serialNumberList[$index]));
//                        }
                        $payeeVoucherDetailCutHistory->setSerialNo(trim($serial_no));
                        // 明細Ｎｏ
                        $payeeVoucherDetailCutHistory->setPayeeDetailNo($count);
                        // 数量
                        $payeeVoucherDetailCutHistory->setQuantity(1);
                        // 合計
                        $payeeVoucherDetailCutHistory->setPayeeMoneyAmount($orderItem->getPrice() * $orderItem->getQuantity());
                        $payeeVoucherDetailCutHistory->setPayeeVoucherHeaderHistory($payeeVoucherHeaderHistory);
//                        $payeeVoucherHeaderHistory->addPayeeVoucherDetailHistory($payeeVoucherDetailCutHistory);

                        $count++;
                    }
                } else {
                    // dtb_payee_voucher_detail
                    // 明細Ｎｏ
                    $payeeVoucherDetail->setPayeeDetailNo($count);
                    // 数量
                    $payeeVoucherDetail->setQuantity($orderItem->getQuantity());
                    // 合計
                    $payeeVoucherDetail->setPayeeMoneyAmount($orderItem->getPrice() * $orderItem->getQuantity());
                    $payeeVoucherDetail->setPayeeVoucherHeader($payeeVoucherHeader);
                    $payeeVoucherHeader->addPayeeVoucherDetail($payeeVoucherDetail);

                    // dtb_payee_voucher_detail_history
                    // 明細Ｎｏ
                    $payeeVoucherDetailHistory->setPayeeDetailNo($count);
                    // 数量
                    $payeeVoucherDetailHistory->setQuantity($orderItem->getQuantity());
                    // 合計
                    $payeeVoucherDetailHistory->setPayeeMoneyAmount($orderItem->getPrice() * $orderItem->getQuantity());
                    $payeeVoucherDetailHistory->setPayeeVoucherHeaderHistory($payeeVoucherHeaderHistory);
//                    $payeeVoucherHeaderHistory->addPayeeVoucherDetailHistory($payeeVoucherDetailHistory);

                    $count++;
                }

                // 該当注文
                if (!($orderItem->getOrderItemType()['id'] == OtherItemCodeChange::COMMISSION
                    || $orderItem->getOrderItemType()['id'] == OtherItemCodeChange::POSTAGE
                    || $orderItem->getOrderItemType()['id'] == OtherItemCodeChange::MAINPOINT)) {
                    // 該当注文の「変更後状態」
                    $orderItem->setConversionAfterState($conversionAfterState);
                    $this->entityManager->persist($orderItem);
                }

//                $count++;
            }
//        } else {
            // 本登録
            $array_payee_voucher_details = $payeeVoucherHeader->getPayeeVoucherDetails();
            $productStorehouseItems = [];
            $productStateItems = [];

            // 特殊商品（料）
            $array_special_cost = [];
            $collection_special_cost = $this->otherItemCodeChangeRepository->findAll();
            /** @var OtherItemCodeChange $entity_special_cost */
            foreach ($collection_special_cost as $entity_special_cost) {
                $array_special_cost[$entity_special_cost->getName()] = $entity_special_cost->getId();
            }

            foreach ($array_payee_voucher_details as $detail) {
                // 明細履歴作成
                $payeeVoucherHeaderHistory->addPayeeVoucherDetailHistory(
                    $this->payeeVoucherDetailHistoryRepository->createPayeeVoucherDetailHistoryByDetail(
                        $detail,
                        $payeeVoucherHeaderHistory
                    )
                );

                // 入荷準備
                if (!isset($array_special_cost[$detail->getProductCode()])) {
                    // 置場在庫
                    $key_product_storehouse = $detail->getProductId().'_'.$detail->getProductCode().'_'.$place->getId().'_'.$detail->getState()->getId().'_'.$detail->getSerialNo();
                    if (!isset($productStorehouseItems[$key_product_storehouse])) {
                        $productDetail = [
                            'product_id' => $detail->getProductId(),
                            'product_code' => $detail->getProductCode(),
                            'storehouse_id' => $place,
                            'conversion_after_state_id' => $detail->getState(),
                            'priceAmount' => $detail->getPayeeMoneyAmount(),
                            'quantity' => $detail->getQuantity(),
                            'serialNo' => $detail->getSerialNo(),
                        ];
                        $productStorehouseItems[$key_product_storehouse] = $productDetail;
                    } else {
                        $productStorehouseItems[$key_product_storehouse]['quantity'] = 0 + $productStorehouseItems[$key_product_storehouse]['quantity'] + $detail->getQuantity();
                        $productStorehouseItems[$key_product_storehouse]['priceAmount'] = 0 + $productStorehouseItems[$key_product_storehouse]['priceAmount'] + $detail->getPayeeMoneyAmount();
                    }

                    // 商品在庫
                    $key_product_state = $detail->getProductId().'_'.$detail->getProductCode().'_'.$detail->getState()->getId();
                    if (!isset($productStateItems[$key_product_state])) {
                        $productDetail = [
                            'product_id' => $detail->getProductId(),
                            'product_code' => $detail->getProductCode(),
                            'conversion_after_state_id' => $detail->getState(),
                            'priceAmount' => $detail->getPayeeMoneyAmount(),
                            'quantity' => $detail->getQuantity(),
                        ];
                        $productStateItems[$key_product_state] = $productDetail;
                    } else {
                        $productStateItems[$key_product_state]['quantity'] = 0 + $productStateItems[$key_product_state]['quantity'] + $detail->getQuantity();
                        $productStateItems[$key_product_state]['priceAmount'] = 0 + $productStateItems[$key_product_state]['priceAmount'] + $detail->getPayeeMoneyAmount();
                    }
                }
            }

            // 置場在庫
            foreach ($productStorehouseItems as $productItem) {
                /** @var ProductClass $productClass */
                $productClass = $this->productClassRepository->findOneBy(['code' => $productItem['product_code']]);
                // 在庫一覧（置場単位）dtb_stock_list_storehouse_unit
                $stockListStorehouseUnit = new \Eccube\Entity\StockListStorehouseUnit();
                $stockListStorehouse = $this->stockListStorehouseUnitRepository->findOneBy([
                    'productId' => $productItem['product_id'],
                    'State' => $productItem['conversion_after_state_id'],
                    'Storehouse' => $productItem['storehouse_id'],
                    'serialNo' => $productItem['serialNo'],
                ], ['createDate' => 'DESC']);
                if ($stockListStorehouse) {
                    $stockListStorehouse->setStockQuantity(0 + $stockListStorehouse->getStockQuantity() + $productItem['quantity']);
                    $stockListStorehouse->setUpdateUserName($this->getUser()['name']);
                    $stockListStorehouseUnit = $stockListStorehouse;
                } else {
                    $stockListStorehouseUnit->setProductId($productItem['product_id']);
                    $stockListStorehouseUnit->setProductClass($productClass);
                    $stockListStorehouseUnit->setProductCode($productClass->getCode());
                    $stockListStorehouseUnit->setStorehouse($productItem['storehouse_id']);
                    $stockListStorehouseUnit->setState($productItem['conversion_after_state_id']);
                    $stockListStorehouseUnit->setSerialNo($productItem['serialNo']);
                    $stockListStorehouseUnit->setStockQuantity($productItem['quantity']);
                    $stockListStorehouseUnit->setCreateUserName($this->getUser()['name']);
                    $stockListStorehouseUnit->setUpdateUserName($this->getUser()['name']);
                }
                $this->entityManager->persist($stockListStorehouseUnit);
                $this->entityManager->flush($stockListStorehouseUnit);
                LogControllable::print_log(__FILE__, '########## Insert/update: stock list by storehouse', [$stockListStorehouseUnit->toArray()]);
            }

            // 商品在庫
            foreach ($productStateItems as $productItem) {
                $productClass = $this->productClassRepository->findOneBy(['code' => $productItem['product_code']]);
                // 在庫一覧（商品単位) dtb_stock_list_product_unit
                $stockListProductUnit = new \Eccube\Entity\StockListProductUnit();
                $stockListProduct = $this->stockListProductUnitRepository->findOneBy([
                    'productId' => $productItem['product_id'],
                    'State' => $productItem['conversion_after_state_id'],
                ]);
                if ($stockListProduct) {
                    $averageUnitPrice = $stockListProduct->getAverageUnitPrice();
                    $stockQuantity = $stockListProduct->getStockQuantity();
                    // 平均単価　=（平均単価＊在庫数量＋価格＊数量）/(在庫数量+数量)
                    if ($stockQuantity <= 0 || $stockQuantity + $productItem['quantity'] <= 0
                        || $averageUnitPrice * $stockQuantity <= 0
                        || ($averageUnitPrice * $stockQuantity + $productItem['priceAmount']) / ($stockQuantity + $productItem['quantity']) <= 0) {
                        $averageUnitPrice = round($productItem['priceAmount']/$productItem['quantity']);
                    }
                    else {
                        $averageUnitPrice = ($averageUnitPrice * $stockQuantity + $productItem['priceAmount']) / ($stockQuantity + $productItem['quantity']);
                    }
                    // 在庫数量　= 在庫数量+数量
                    $stockQuantity = $stockQuantity + $productItem['quantity'];
                    // 残在庫数量　= 在庫数量-受注数量-仮出荷数量
                    $remainingStockQuantity = $stockQuantity - $stockListProduct->getOrderQuantity() - $stockListProduct->getProvisionalShipmentQuantity();
                    $stockListProduct->setAverageUnitPrice($averageUnitPrice);
                    $stockListProduct->setStockQuantity($stockQuantity);
                    $stockListProduct->setRemainingStockQuantity($remainingStockQuantity);
                    $stockListProduct->setUpdateUserName($this->getUser()['name']);
                    $stockListProductUnit = $stockListProduct;
                } else {
                    $stockListProductUnit->setProductId($productItem['product_id']);
                    $stockListProductUnit->setProductClass($productClass);
                    $stockListProductUnit->setProductCode($productClass->getCode());
                    $stockListProductUnit->setState($productItem['conversion_after_state_id']);
                    $stockListProductUnit->setAverageUnitPrice($productItem['priceAmount'] / $productItem['quantity']);
                    $stockListProductUnit->setStockQuantity($productItem['quantity']);
                    $stockListProductUnit->setOrderQuantity(0);
                    $stockListProductUnit->setProvisionalShipmentQuantity(0);
                    $stockListProductUnit->setRemainingStockQuantity($productItem['quantity']);
                    $stockListProductUnit->setCreateUserName($this->getUser()['name']);
                    $stockListProductUnit->setUpdateUserName($this->getUser()['name']);
                }
                $this->entityManager->persist($stockListProductUnit);
                $this->entityManager->flush($stockListProductUnit);
                LogControllable::print_log(__FILE__, '########## Insert/update: stock list by product', [$stockListProductUnit->toArray()]);
            }
//        }

        $this->entityManager->persist($payeeVoucherHeader);
        $this->entityManager->persist($payeeVoucherHeaderHistory);

//        $this->entityManager->flush();
    }

    /**
     * @param $productId
     * @param $ranks
     * @return object|null
     */
    private function changeState($productId, $ranks)
    {
        $stateChanges = $this->stateChangeRepository->searchStateChangeByProductId($productId);
        $stateAfterChange = '';
        /** @var StateChange $stateChange */
        foreach ($stateChanges as $stateChange) {
            // 空白場合、「新品」にする
            if (trim($ranks) === '' && $ranks.'_' === $stateChange->getConversionBeforeState()) {
                $stateAfterChange = $stateChange->getConversionAfterState()->getId();
                break;
            }

            if (strstr($ranks, $stateChange->getConversionBeforeState())) {
                $stateAfterChange = $stateChange->getConversionAfterState()->getId();
                break;
            }
        }
        $stateAfterChangeEntity = $this->stateRepository->findOneBy(['id' => $stateAfterChange]);
        return $stateAfterChangeEntity;
    }
    // INS-END CNC 2021/07/23
}
