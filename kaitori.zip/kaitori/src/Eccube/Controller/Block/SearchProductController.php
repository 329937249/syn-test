<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller\Block;

use Eccube\Entity\Category;
use Eccube\Repository\CategoryRepository;
use Eccube\Entity\Master\SaleType;
use Eccube\Repository\Master\SaleTypeRepository;
use Eccube\Controller\AbstractController;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Form\Type\SearchProductBlockType;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\Routing\Annotation\Route;
use SunCat\MobileDetectBundle\DeviceDetector\MobileDetector;

class SearchProductController extends AbstractController
{
    /**
     * @var MobileDetector
     */
    private $mobileDetector;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var SaleTypeRepository
     */
    protected $saleTypeRepository;

    /**
     * @var RequestStack
     */
    protected $requestStack;

    public function __construct(RequestStack $requestStack,
                        CategoryRepository $categoryRepository,
                        SaleTypeRepository $saleTypeRepository,
                        MobileDetector $mobileDetector
    ) {
        $this->requestStack = $requestStack;
        $this->categoryRepository = $categoryRepository;
        $this->saleTypeRepository = $saleTypeRepository;
        $this->mobileDetector = $mobileDetector;
    }

    /**
     * @Route("/block/search_product", name="block_search_product")
     * @Route("/block/search_product_sp", name="block_search_product_sp")
     * @Template("Block/search_product.twig")
     */
    public function index(Request $request)
    {
        $builder = $this->formFactory
            ->createNamedBuilder('', SearchProductBlockType::class, ['sale_type' => null,])
            ->setMethod('GET');

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_BLOCK_SEARCH_PRODUCT_INDEX_INITIALIZE, $event);

        $request = $this->requestStack->getMasterRequest();

        $form = $builder->getForm();
        $form->handleRequest($request);

        return [
            'form' => $form->createView(),
        ];
    }

    /**
     * @Route("/block/top_search_product/{id}", requirements={"id" = "\d+"}, name="block_top_search_product")
     * @Route("/block/top_search_product_sp/{id}", requirements={"id" = "\d+"}, name="block_top_search_product_sp")
     * @Template("Block2/top_product_search.twig")
     */
    public function index_top(Request $request, $id = null)
    {
        log_info("block_top_search_product", [$id]);
        $builder = $this->formFactory
            ->createNamedBuilder('', SearchProductBlockType::class, ['sale_type' => $id,])
            ->setMethod('GET');

        $event = new EventArgs(
            [
                'builder' => $builder,
            ],
            $request
        );

        $this->eventDispatcher->dispatch(EccubeEvents::FRONT_BLOCK_SEARCH_PRODUCT_INDEX_INITIALIZE, $event);

        $request = $this->requestStack->getMasterRequest();

        $form = $builder->getForm();
        $form->handleRequest($request);

        return [
            'form' => $form->createView(),
            'page_type' => $id,
        ];
    }

    /**
     * @Route("/block/top_product_category/{id}", requirements={"id" = "\d+"}, name="block_top_product_category")
     * @Template("Block2/sidebar.twig")
     */
    public function index_top_categories(Request $request, $id = null)
    {
        $Categories = new \Doctrine\Common\Collections\ArrayCollection();

        $saleType = $this->saleTypeRepository
            ->find($id);
        if ($saleType) {
            $Categories = $this->categoryRepository
                ->getList($saleType->getCategory(), true);
        }

        // トップカテゴリを抽出.
        $topCategories = new \Doctrine\Common\Collections\ArrayCollection();
        /** @var Category $Category */
        foreach ($Categories as $Category) {
            if ($Category && ($Category->getHierarchy() == 2)) {
                $topCategories[] = $Category;
            }
        }

        // sort
        $iterator = $topCategories->getIterator();
        $iterator->uasort(function ($a, $b) {
            return ($a->getSortNo() < $b->getSortNo()) ? 1 : -1;
        });
        $topCategories = new \Doctrine\Common\Collections\ArrayCollection(iterator_to_array($iterator));

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/categories.twig', [
                'topCategories' => $topCategories,
                'page_type' => $id,
            ]);
        }

        return [
            'topCategories' => $topCategories,
            'page_type' => $id,
        ];
    }

}
