<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller;

use Eccube\Controller\AbstractController;
use Eccube\Entity\AmazonGift;
use Eccube\Entity\CartItem;
use Eccube\Entity\ProductClass;
use Eccube\Entity\Master\SaleType;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Service\CartService;
use Eccube\Service\PurchaseFlow\PurchaseContext;
use Eccube\Service\PurchaseFlow\PurchaseFlow;
use Eccube\Form\Type\AmazonGiftType;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\CartItemRepository;
use Eccube\Repository\Master\SaleTypeRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;
use SunCat\MobileDetectBundle\DeviceDetector\MobileDetector;

/**
 * Class AmazonGiftController
 */
class AmazonGiftController extends AbstractController
{
    /**
     * @var MobileDetector
     */
    private $mobileDetector;

    /**
     * @var PurchaseFlow
     */
    protected $purchaseFlow;

    /**
     * @var CustomerFavoriteProductRepository
     */
    protected $customerFavoriteProductRepository;

    /**
     * @var CartService
     */
    protected $cartService;

    /**
     * @var CartItemRepository
     */
    protected $cartItemRepository;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var SaleTypeRepository
     */
    protected $saleTypeRepository;

    /**
     * AmazonGiftController constructor.
     *
     * @param PurchaseFlow $cartPurchaseFlow
     * @param CartService $cartService
     * @param CartItemRepository $cartItemRepository
     * @param MobileDetector $mobileDetector
     */
    public function __construct(
        PurchaseFlow $cartPurchaseFlow,
        CartService $cartService,
        CartItemRepository $cartItemRepository,
        SaleTypeRepository $saleTypeRepository,
        ProductRepository $productRepository,
        MobileDetector $mobileDetector
    ) {
        $this->purchaseFlow = $cartPurchaseFlow;
        $this->cartService = $cartService;
        $this->cartItemRepository = $cartItemRepository;
        $this->saleTypeRepository = $saleTypeRepository;
        $this->productRepository = $productRepository;
        $this->mobileDetector = $mobileDetector;
    }

    /**
     * 初期表示・登録
     *
     * @Route("/amazongift/shop", name="amazongift_shop")
     * @Route("/amazongift/shop/new", name="amazongift_shop_new")
     * @Template("Gift/index.twig")
     */
    public function index(Request $request)
    {
        $saleType = $this->saleTypeRepository->find(SaleType::SALE_TYPE_AMAZONGIFT);
        $category = $saleType->getCategory();
        log_info("category", [$category->getId(),$category->getName()]);

        $Products = $this->productRepository->findProductsWithCategory($category);
        $Product = null;
        foreach($Products as $prod) {
            $Product = $prod;
            log_info("Product", [$Product->getId()]);
            break;
        }
        if (is_null($Product)) {
            return $this->redirectToRoute('amazongift_shop');
        }

        $ProductClass = $Product->getProductClasses()->first();

        $TargetAmazonGift = new CartItem();
        $builder = $this->formFactory
            ->createBuilder(AmazonGiftType::class, $TargetAmazonGift);

        $event = new EventArgs(
            [
                'builder' => $builder,
                'AmazonGift' => $TargetAmazonGift,
            ],
            $request
        );
        $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_TAX_RULE_INDEX_INITIALIZE, $event);

        if ($this->getUser()) {
            $form = $builder->getForm();

            $mode = $request->get('mode');
            if ($mode != 'edit_inline') {
                $form->handleRequest($request);
                if ($form->isSubmitted() && $form->isValid()) {
                    //初回申込みは30万までチェック
                    if($this->getUser()->getAmazonBuyTimes() == 0){
                        $Carts = $this->cartService->getCarts();
                        $totalPrice = $TargetAmazonGift->getPrice();
                        foreach ($Carts as $Cart) {
                            foreach ($Cart->getCartItems() as $CartItem) {
                                $SaleType = $CartItem->getProductClass()->getSaleType();
                                if (SaleType::SALE_TYPE_AMAZONGIFT == $SaleType->getId()) {
                                    $totalPrice += $CartItem->getPrice();
                                }
                            }
                        }
                        if($totalPrice > 300000){
                            $this->addError('初回申込みは30万までです');
                            return $this->redirectToRoute('amazongift_shop');
                        }
                    }
                    //番号未使用チェック
                    $Carts = $this->cartService->getCarts();
                    $currentGiftKey = $TargetAmazonGift->getGiftKey();
                    foreach ($Carts as $Cart) {
                          foreach ($Cart->getCartItems() as $CartItem) {
                             $giftKey = $CartItem->getGiftKey();
                             if ($currentGiftKey == $giftKey) {
                                   $this->addError('この番号は使用済みです');
                                   return $this->redirectToRoute('amazongift_shop');
                             }
                          }
                     }

                    $this->entityManager->persist($TargetAmazonGift);
                    $this->entityManager->flush();

                    // ギフト券種類
                    $Product->setName($TargetAmazonGift->getAmazonGiftType()->getName());
                    // ギフトコード
                    $ProductClass->setCode($TargetAmazonGift->getGiftKey());
                    log_info(
                        'カート追加処理開始',
                        [
                            'TargetAmazonGift' => $TargetAmazonGift,
                            'ProductClass' => $ProductClass,
                        ]
                    );
            
                    // カートへ追加
                    $this->cartService->addAmazonGift($ProductClass, 1, $TargetAmazonGift);
    
                    // 明細の正規化
                    $Carts = $this->cartService->getCarts();
                    $this->execPurchaseFlow($Carts);

                    foreach ($Carts as $Cart) {
                        $result = $this->purchaseFlow->validate($Cart, new PurchaseContext($Cart, $this->getUser()));
                        // 復旧不可のエラーが発生した場合は追加した明細を削除.
                        if ($result->hasError()) {
                            //$this->cartService->removeProduct($addCartData['product_class_id']);
                            foreach ($result->getErrors() as $error) {
                                $errorMessages[] = $error->getMessage();
                            }
                        }
                        foreach ($result->getWarning() as $warning) {
                            $errorMessages[] = $warning->getMessage();
                        }
                    }

                    $this->cartService->save();

                    log_info(
                        'カート追加処理完了',
                        [
                            'TargetAmazonGift' => $TargetAmazonGift,
                            'ProductClass' => $ProductClass,
                        ]
                    );

                    $event = new EventArgs(
                        [
                            'form' => $form,
                            'AmazonGift' => $TargetAmazonGift,
                        ],
                        $request
                    );
                    $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_TAX_RULE_INDEX_COMPLETE, $event);

                    $this->addSuccess('admin.common.save_complete', 'admin');

                    return $this->redirectToRoute('amazongift_shop');
                }
            }

            // カートを取得
            $Carts = $this->cartService->getCarts();

            // 一覧
            $GiftCart = null;
            $GiftCartItems = [];

            foreach ($Carts as $Cart) {
                foreach ($Cart->getCartItems() as $CartItem) {
                    $SaleType = $CartItem->getProductClass()->getSaleType();
                    if (SaleType::SALE_TYPE_AMAZONGIFT == $SaleType->getId()) {
                        $GiftCartItems[] = $CartItem;
                        $GiftCart = $Cart;
                    }
                }
            }

            // edit form
            $forms = [];
            $errors = [];
            /** @var AmazonGift $AmazonGift */
            foreach ($GiftCartItems as $GiftCartItem) {
                /* @var $builder \Symfony\Component\Form\FormBuilderInterface */
                $builder = $this->formFactory->createBuilder(AmazonGiftType::class, $GiftCartItem);

                $editForm = $builder->getForm();
                // error number
                $error = 0;
                if ($mode == 'edit_inline'
                    && $request->getMethod() === 'POST'
                    && (string) $GiftCartItem->getId() === $request->get('gift_id')
                ) {
                    $editForm->handleRequest($request);
                    if ($editForm->isValid()) {
                        $Data = $editForm->getData();

                        $this->entityManager->persist($Data);
                        $this->entityManager->flush();

                        //$this->addSuccess('admin.common.save_complete', 'admin');

                        return $this->redirectToRoute('amazongift_shop');
                    }
                    $error = count($editForm->getErrors(true));
                }

                $forms[$GiftCartItem->getId()] = $editForm->createView();
                $errors[$GiftCartItem->getId()] = $error;
            }

            $template = 'Gift/index.twig';
            if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
                $template = 'Mobile/gift.twig';
                return $this->render($template, [
                    'TargetAmazonGift' => $TargetAmazonGift,
                    'GiftCart' => $GiftCart,
                    'GiftCartItems' => $GiftCartItems,
                    'form' => $form->createView(),
                    'forms' => $forms,
                    'errors' => $errors,
                ]);
            }

            return $this->render($template, [
                'TargetAmazonGift' => $TargetAmazonGift,
                'GiftCart' => $GiftCart,
                'GiftCartItems' => $GiftCartItems,
                'form' => $form->createView(),
                'forms' => $forms,
                'errors' => $errors,
            ]);

        } else {
            // 非会員の場合、ログイン画面を表示
            //  ログイン後の画面遷移先を設定
            $this->setLoginTargetPath($this->generateUrl('amazongift_shop', [], UrlGeneratorInterface::ABSOLUTE_URL));
            $this->session->getFlashBag()->set('eccube.add.amazongift', true);

            $event = new EventArgs(
                [
                    'builder' => $builder,
                    'AmazonGift' => $TargetAmazonGift,
                ],
                $request
            );
            $this->eventDispatcher->dispatch(EccubeEvents::ADMIN_SETTING_SHOP_TAX_RULE_INDEX_COMPLETE, $event);

            return $this->redirectToRoute('mypage_login');
        }
    }

    /**
     * カート明細の削除を行う.
     *
     * @Route(
     *     path="/amazongift/remove/{cartItemId}",
     *     name="amazongift_cart_handle_item",
     *     methods={"PUT"},
     *     requirements={
     *          "cartItemId": "\d+"
     *     }
     * )
     */
    public function handleCartItem($cartItemId)
    {
        log_info('カート明細操作開始', ['cart_item_id' => $cartItemId]);

        $this->isTokenValid();

        /** @var CartItem $CartItem */
        $CartItem = $this->cartItemRepository->find($cartItemId);
        if (is_null($CartItem)) {
            log_info('商品が存在しないため、カート画面へredirect', ['cart_item_id' => $cartItemId]);

            return $this->redirectToRoute('amazongift_shop');
        }

        /** @var ProductClass $ProductClass */
        $ProductClass = $CartItem->getProductClass();
        if (is_null($ProductClass)) {
            log_info('商品が存在しないため、カート画面へredirect', ['product_class_id' => $cartItemId]);

            return $this->redirectToRoute('amazongift_shop');
        }

        // 明細の削除
        $this->cartService->removeProductToCartItem($CartItem);

        // カートを取得して明細の正規化を実行
        $Carts = $this->cartService->getCarts();
        $this->execPurchaseFlow($Carts);

        log_info('カート演算処理終了', ['cart_item_id' => $cartItemId]);

        return $this->redirectToRoute('amazongift_shop');
    }

    /**
     * @param $Carts
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     */
    protected function execPurchaseFlow($Carts)
    {
        /** @var PurchaseFlowResult[] $flowResults */
        $flowResults = array_map(function ($Cart) {
            $purchaseContext = new PurchaseContext($Cart, $this->getUser());

            return $this->purchaseFlow->validate($Cart, $purchaseContext);
        }, $Carts);

        // 復旧不可のエラーが発生した場合はカートをクリアして再描画
        $hasError = false;
        foreach ($flowResults as $result) {
            if ($result->hasError()) {
                $hasError = true;
                foreach ($result->getErrors() as $error) {
                    $this->addRequestError($error->getMessage());
                }
            }
        }
        if ($hasError) {
            $this->cartService->clear();

            return $this->redirectToRoute('cart');
        }

        $this->cartService->save();

        foreach ($flowResults as $index => $result) {
            foreach ($result->getWarning() as $warning) {
                if ($Carts[$index]->getItems()->count() > 0) {
                    $cart_key = $Carts[$index]->getCartKey();
                    $this->addRequestError($warning->getMessage(), "front.cart.${cart_key}");
                } else {
                    // キーが存在しない場合はグローバルにエラーを表示する
                    $this->addRequestError($warning->getMessage());
                }
            }
        }
    }

}
