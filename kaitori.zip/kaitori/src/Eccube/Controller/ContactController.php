<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Eccube\Controller;

use Eccube\Entity\Customer;
use Eccube\Entity\Contact;
use Eccube\Form\Type\Front\ContactType;
use Eccube\Repository\CategoryRepository;
use Eccube\Service\MailService;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use SunCat\MobileDetectBundle\DeviceDetector\MobileDetector;

class ContactController extends AbstractController
{
    /**
     * @var MobileDetector
     */
    private $mobileDetector;

    /**
     * @var MailService
     */
    protected $mailService;
    
    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * ContactController constructor.
     *
     * @param MailService $mailService
     * @param CategoryRepository $categoryRepository
     * @param MobileDetector $mobileDetector
     */
    public function __construct(MailService $mailService,
        CategoryRepository $categoryRepository,
        MobileDetector $mobileDetector
    ){
        $this->mailService = $mailService;
        $this->categoryRepository = $categoryRepository;
        $this->mobileDetector = $mobileDetector;
    }

    /**
     * お問い合わせ画面.
     *
     * @Route("/contact", name="contact")
     * @Template("Contact/index.twig")
     */
    public function index(Request $request)
    {
        $builder = $this->formFactory->createBuilder(ContactType::class);
        $is_customer = false;
        if ($this->isGranted('ROLE_USER')) {
            /** @var Customer $user */
            $user = $this->getUser();
            $Contact = new Contact();
            $Contact->setName01($user->getName01());
            $Contact->setName02($user->getName02());
            $Contact->setKana01($user->getKana01());
            $Contact->setKana02($user->getKana02());
            $Contact->setPostalCode($user->getPostalCode());
            $Contact->setPref($user->getPref());
            $Contact->setAddr01($user->getAddr01());
            $Contact->setAddr02($user->getAddr02());
            $Contact->setPhoneNumber($user->getPhoneNumber());
            $Contact->setEmail($user->getEmail());
            $Contact->setCustomer($user);
            $builder->setData($Contact);
            $is_customer = true;
        }

        $form = $builder->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            switch ($request->get('mode')) {
                case 'confirm':
                    $form = $builder->getForm();
                    $form->handleRequest($request);

                    if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
                        return $this->render('Mobile/contact/confirm.twig', [
                            'form' => $form->createView(),
                            'page_type' => '0',
                        ]);
                    }
                    return $this->render('Contact/confirm.twig', [
                        'form' => $form->createView(),
                        'page_type' => '0',
                    ]);
                case 'complete':
                    $Contact = $form->getData();
                    $this->entityManager->persist($Contact);
                    $this->entityManager->flush();

                    // メール送信
                    $this->mailService->sendContactMail($Contact);

                    return $this->redirect($this->generateUrl('contact_complete', ['id' => '0']));
            }
        }

        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/contact/index.twig', [
                'form' => $form->createView(),
                'page_type' => '0',
                'is_customer' => $is_customer,
            ]);
        }

        return [
            'form' => $form->createView(),
            'page_type' => '0',
            'is_customer' => $is_customer,
        ];
    }
    
    /**
     * お問い合わせ画面.
     *
     * @Route("/product/{id}/contact/{category_id}", name="product_contact", requirements={"id" = "\d+","category_id" = "\d+"})
     * @Template("Help/contact.twig")
     */
    public function product_index(Request $request, $id, $category_id)
    {
        
        $Category = $this->categoryRepository->find($category_id);

        $builder = $this->formFactory->createBuilder(ContactType::class);
        $is_customer = false;

        if ($this->isGranted('ROLE_USER')) {
            /** @var Customer $user */
            $user = $this->getUser();
            $Contact = new Contact();
            $Contact->setName01($user->getName01());
            $Contact->setName02($user->getName02());
            $Contact->setKana01($user->getKana01());
            $Contact->setKana02($user->getKana02());
            $Contact->setPostalCode($user->getPostalCode());
            $Contact->setPref($user->getPref());
            $Contact->setAddr01($user->getAddr01());
            $Contact->setAddr02($user->getAddr02());
            $Contact->setPhoneNumber($user->getPhoneNumber());
            $Contact->setEmail($user->getEmail());
            $Contact->setCustomer($user);
            $builder->setData($Contact);
            $is_customer = true;
        }

        $form = $builder->getForm();

        $form->handleRequest($request);

        foreach($Category->getPath() as $ss){
           log_info($ss->getName());
        }
        if ($form->isSubmitted() && $form->isValid()) {
            switch ($request->get('mode')) {
                 case 'product_confirm':
                    $form = $builder->getForm();
                    $form->handleRequest($request);

                    return $this->render('Main/index_confirm.twig', [
                        'form' => $form->createView(),
                        'page_type' => $id,
                        'Category' => $Category,
                        'is_customer' => $is_customer,
                    ]);
                case 'back':
                    $form = $builder->getForm();
                    $form->handleRequest($request);
                    return $this->render('Main/index_contact.twig', [
                        'form' => $form->createView(),
                        'page_type' => $id,
                        'Category' => $Category,
                        'is_customer' => $is_customer,
                    ]);
                case 'product_complete':

                    $Contact = $form->getData();
                    $this->entityManager->persist($Contact);
                    $this->entityManager->flush();

                    // メール送信
                    $this->mailService->sendContactMail($Contact);
                    return $this->render('Main/index_complete.twig', [
                        'form' => $form->createView(),
                        'page_type' => $id,
                        'Category' => $Category,
                    ]);
            }
        }

        return $this->render('Main/index_contact.twig', [
                     'form' => $form->createView(),
                     'page_type' => $id,
                     'Category' => $Category,
                     'is_customer' => $is_customer,
        ]);
    }

    /**
     * お問い合わせ完了画面.
     *
     * @Route("/contact/complete", name="contact_complete")
     * @Template("Contact/complete.twig")
     */
    public function complete()
    {
        if ($this->mobileDetector->isMobile() && !$this->mobileDetector->isTablet()) {
            return $this->render('Mobile/contact/complete.twig', [
                'page_type' => '0',
            ]);
        }

        return [
            'page_type' => '0',
        ];
    }
}
