# kaitori

## git設定
```shell
# Windows環境で必要
git config --global core.autoCRLF false
# remember passwordのため
git config --global credential.helper store
# 自分の名前
git config --global user.name "自分の名前"
# xxx@movacloud.co.jp
git config --global user.email "自分のメールアドレス"
# 自分のワークスペース 例えばC:¥¥git
cd ワークスペース
# メールアドレス@前の分
git clone https://自分のアカウント@bitbucket.org/movacloud/kaitori.git
cd kaitori
```

## docker-composeインストール
```shell
# コンテナの起動 (初回のみビルド処理あり)
docker-compose up -d

# 初回はインストールスクリプトを実行( **`www-data` ユーザで実行する点に注意！** )
docker-compose exec -u www-data ec-cube bin/console eccube:install
```
2回目以降の起動時も同様のコマンドを使用します。
```shell
# コンテナの起動
docker-compose up -d

# コンテナの停止
docker-compose down
```

## batch実行
### 収集元
+ 00 kakaku https://kakaku.com/
+ 01 買取Wiki https://iphonekaitori.tokyo/
+ 02 買取けんさく君 https://www.kaitorikensakukun.com/
+ 03 携帯楽園 http://keitairakuen.com/
+ 04 じゃんぱら https://www.janpara.co.jp/
+ 05 買取一丁目 https://www.1-chome.com/
+ 06 アバウテック https://www.aboutec.jp/

```shell
# 買取Wikiを収集　url -> html 保存先：batch/tmp/
docker-compose exec batch sh -c "cd /tmp/app/ && ruby /tmp/app/batch/crawler.rb 01"

# 買取Wikiを分析 html -> execl(確認用) & elaseticsearch(AI比較用) 保存先：batch/out/
docker-compose exec batch sh -c "cd /tmp/app/ && ruby /tmp/app/batch/analysis.rb 01"

# 買取サイトと統合 elaseticsearch -> mysql　（開発中）
docker-compose exec batch sh -c "cd /tmp/app/ && ruby /tmp/app/batch/combine.rb 01"
```

## ドキュメント

### [EC-CUBE 4.0 開発ドキュメント@doc4.ec-cube.net](https://doc4.ec-cube.net/)
